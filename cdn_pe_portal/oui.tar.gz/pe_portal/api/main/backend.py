from ci.common.models import LongUser
from django.contrib.auth.models import User
from django.contrib.auth.backends import ModelBackend
from ci.common.utils.crowds import CrowdServer


class PantherAPIModelBackend(ModelBackend):
    """
    Authenticates against django.contrib.auth.models.User.
    """
    def authenticate(self, username=None, password=None):
        try:
            user = User.objects.get(username=username)
            long_user = LongUser.objects.get(pk=user.pk)
            if long_user.is_migrated_to_AD():
                #authenticate from AD directly, since local db account has invalid password !
                cs = CrowdServer()
                success = cs.auth_user(username, password)
                if success:
                    return user
            if long_user.check_password(password):
                return user
        except User.DoesNotExist:
            return None

