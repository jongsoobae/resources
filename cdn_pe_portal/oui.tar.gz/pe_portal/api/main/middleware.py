###
# Copyright (c) 2006-2007, Jared Kuolt
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without 
# modification, are permitted provided that the following conditions are met:
# 
#     * Redistributions of source code must retain the above copyright notice, 
#       this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright 
#       notice, this list of conditions and the following disclaimer in the 
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the SuperJared.com nor the names of its 
#       contributors may be used to endorse or promote products derived from 
#       this software without specific prior written permission.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
###

from django.conf import settings
from django.http import HttpResponse, HttpResponseServerError, HttpResponseNotFound, HttpResponseRedirect
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from ZSI import ZSIException, Fault
from urllib import unquote
from ci.common.utils.regex import matches_any, match_list
from ci.common.utils.api import  APIException, APIErrorResponse, HttpResponseAPISafe
from api.rapi.utils import get_rest_username_password, get_rest_login_id_customer_id, RestResponse
from api.sapi.utils import get_soap_username_password, SoapResponse
from ci.common.utils.api import page_not_found
from _mysql_exceptions import OperationalError
from ci.common.utils.log import use_log_by_user
from ci.constants import INTSCP_PUBKEY
from api.rapi.utils import getOptionalParams
from ci.common.models.customer import Customer
import md5

REST_ROOT = getattr(settings, 'REST_ROOT', "/") 
REST_STAFF_REQUIRED = match_list(getattr(settings, 'STAFF_REST_LOGIN_REQUIRED', []))

SOAP_ROOT = getattr(settings, 'SOAP_ROOT', "/")
SOAP_STAFF_REQUIRED = match_list(getattr(settings, 'STAFF_SOAP_LOGIN_REQUIRED', []))

LEGACY_PATHS = match_list(getattr(settings,'LEGACY_PATHS', []))

API_STAFF_REQUIRED = REST_STAFF_REQUIRED + SOAP_STAFF_REQUIRED

class APIResponseMiddleware(object):
    """
    If request in SOAP path than process the response as follows:
    If response_code = 200 then assume proper SOAP response
    If response_code != 200 then return 
    """
    def process_response(self, request, response):
        raise_exception = False
        if matches_any(LEGACY_PATHS, request.path):
            #this means its legacy support for existing apis...
            #these were created before this middleware approach. Skip.
            return response

        if isinstance(response, HttpResponseNotFound):
            response =  page_not_found(request)
        if isinstance(response, HttpResponseRedirect) and response.has_header('location') and response._headers.get('location',('',''))[1].startswith('/accounts/login'):
            response = APIErrorResponse("Your user account does not have sufficient permissions to access this API - Contact Support", status=403)
        if isinstance(response, HttpResponseAPISafe):
            #This is a special class to say except the response as is
            return response
        if request.path.startswith(SOAP_ROOT):
            if not isinstance(response,SoapResponse):
                if isinstance(response,APIErrorResponse):
                    return HttpResponse(Fault(Fault.Client, str(response.content)).AsSOAP(), mimetype='text/xml')
                raise_exception = True
        elif request.path.startswith(REST_ROOT):
            if not isinstance(response,RestResponse):
                if isinstance(response, APIErrorResponse):
                    return RestResponse({}, error=str(response.content), status=response.status_code)
                raise_exception = True
        if raise_exception:
            if not settings.DEBUG or not isinstance(response, HttpResponseServerError):
                #This allows a server error in debug mode to bubble through
                return self.process_exception(request, Exception(str(type(response)) + ":" + str(response.status_code)))
        return response

    def process_exception(self, request, exception):
        handle_exception =  False
        if matches_any(LEGACY_PATHS, request.path):
            #this means its legacy support for existing apis...
            #these were created before this middleware approach. Skip.
            return

        if request.path.startswith(SOAP_ROOT) and (isinstance(exception, ZSIException) or isinstance(exception,APIException)):
            return HttpResponse(Fault(Fault.Client, str(exception)).AsSOAP(), mimetype='text/xml')
        elif request.path.startswith(REST_ROOT) and isinstance(exception,APIException):
            return RestResponse({}, error=str(exception), status=exception.status_code)

        generic_error = "500 Server Error: Internal Error - Contact Support"
        import traceback
        exc = traceback.format_exc()
        try:
            request_repr = repr(request)
        except:
            request_repr = "Request repr() unavailable"

        if exc == "None\n":
            exc = str(exception)
        if settings.DEBUG:
            generic_error += "\n" + str(exc) + "\n" + request_repr
        else:
            # When DEBUG is False, send an error message to the admins.
            # This copies django handling of an error...
            subject = 'Error (%s IP): %s' % ((request.META.get('REMOTE_ADDR') in settings.INTERNAL_IPS and 'internal' or 'EXTERNAL'), request.path)
            try:
                request_repr = repr(request)
            except:
                request_repr = "Request repr() unavailable"
            message = "%s\n\n%s" % (exc if exc else "", request_repr)
            from django.core.mail import mail_admins
            mail_admins(subject, message, fail_silently=True)

        if request.path.startswith(SOAP_ROOT):
            return HttpResponse(Fault(Fault.Client, generic_error).AsSOAP(), mimetype='text/xml')
        elif request.path.startswith(REST_ROOT):
            return RestResponse({}, error= generic_error, status=500)

def get_int_obj_list(str_src):
    temp_arr = str_src.split(':')
    int_obj_list = []
    try:
        if str_src != '':
            for obj in temp_arr:
                int_obj_list.append(int(obj))
        else:
            int_obj_list.append(-1)
    except:
        pass
    return int_obj_list
        
class APILoginMiddleware(object):
    """
    Based on Jared Kuolt's Require Login middleware.
    Reads three constants from settings.py:
    LOGIN_REST_REQUIRED, STAFF_REST_LOGIN_REQUIRED, 
    LOGIN_REST_NOT_REQUIRED, SOAP_REST_REQUIRED, 
    STAFF_SOAP_LOGIN_REQUIRED, LOGIN_SOAP_NOT_REQUIRED 
    each of which is a tuple
    
    containing regex strings to define what paths require what level of authentication.
    (LOGIN_REST_NOT_REQUIRED and LOGIN_SOAP_NOT_REQUIRED override the first two.)
    """
    def process_request(self, request):
        req_type = ''
        if matches_any(LEGACY_PATHS, request.path):
            #this means its legacy support for existing apis...
            #these were created before this middleware approach. Skip.
            return
        if request.path.startswith(SOAP_ROOT):
            username,password = get_soap_username_password(request)
            req_type = 'soap'
        elif request.path.startswith(REST_ROOT):
            username,password = get_rest_username_password(request)
            req_type = 'rest'
        else:
            #this means it isn't any existing API so fail with 404!
            return APIErrorResponse("404 Not Found: API Requested Not Found (Could not even determine API type)", 404)

        if username in  [None,""] or password in [None,""]:
            if username in  [None,""] and password in [None,""]:
                return APIErrorResponse("403 Forbidden: No username or password provided", 403)
            elif username in [None,""]:
                return APIErrorResponse("403 Forbidden: No username provided", 403)
            else:
                return APIErrorResponse("403 Forbidden: No password provided", 403)

        operr_flag = False
        user = None
        request.session = {}
        try:
            user = authenticate(username=username, password=password)
            if req_type == 'rest':
                use_log_by_user(user=user, url_function=request.path, desc='rest')
        except OperationalError, e:
            if e.args[0] == 2003:
                operr_flag = True
                request.session['operr_flag'] = True
                request.session['operr_user'] = username
                request.session['operr_password'] = password
        except:
            pass
        
        if operr_flag == False:
            if user and user.is_staff and not matches_any(API_STAFF_REQUIRED, request.path):
                login_id, customer_id = get_rest_login_id_customer_id(request)
                #login as this other user...
                if login_id:
                    try:
                        request.user = User.objects.get(id = login_id, userprofile__customer = customer_id)
                    except:
                        return APIErrorResponse('403 Forbidden: Invalid user credentials', 403)
                    if request.user.is_staff:
                        return APIErrorResponse('403 Forbidden: Invalid login for staff')
                else:
                    request.user = user
            else:
                request.user = user
        
            #did user login and modifying path...now verify...
            if request.user == None or not request.user.is_authenticated():
                return APIErrorResponse('403 Forbidden: Invalid login credentials', 403)

            if request.user.get_profile().password_reset:
                return APIErrorResponse('403 Forbidden: Password reset required, please change password via portal', 403)
            if (not request.user.is_staff and matches_any(API_STAFF_REQUIRED, request.path)):
                return APIErrorResponse('403 Forbidden: Staff access only', 403)
            if not request.user.get_profile().webservice_perm or not request.user.is_active or not request.user.userprofile.customer.status:
                return APIErrorResponse('403 Forbidden: Do not have webservice access enabled', 403)

            opt_params = getOptionalParams(request)
            #for aurora open api
            if opt_params.get('md5_dig', '') != '':
                md5_dig = opt_params.get('md5_dig', '')
                str_pad_list = opt_params.get('pad_list', '')
                str_ckey = opt_params.get('ckey', '')
                str_aurora_user_id = opt_params.get('aurora_user_id', '')
                str_aurora_user_key = opt_params.get('aurora_user_key', '')
                str_editable = opt_params.get('editable', '1')
                str_admin_flag = opt_params.get('admin_flag', '1')
                str_item_list = opt_params.get('item_list', '')

                str_parameter = '%s&pad_list=%s&ckey=%s&aurora_user_id=%s&aurora_user_key=%s&editable=%s&admin_flag=%s'% \
                                (INTSCP_PUBKEY, str_pad_list, str_ckey, str_aurora_user_id, str_aurora_user_key, str_editable, str_admin_flag)

                if not md5_dig == md5.new(str_parameter).hexdigest() or str_ckey == '':
                    return APIErrorResponse("403 Forbidden: Invalid login credentials", 403)

                try:
                    cust_obj = Customer.objects.get(id=str_ckey)
                except:
                    return APIErrorResponse('403 Forbidden: Invalid account parameter')

                restrict_pad_list = get_int_obj_list(str_pad_list)

                request.session['aurora_restrict_items'] = str_item_list.split(":")
                request.session['aurora_default_group'] = cust_obj
                request.session['aurora_restrict_pads'] = restrict_pad_list
                request.session['aurora_user'] = True
                request.session['aurora_user_id'] = str_aurora_user_id
                request.session['aurora_editable'] = True if str_editable == '1' else False
                request.session['aurora_admin_flag'] = True if str_admin_flag == '1' else False
