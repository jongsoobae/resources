from django.conf.urls.defaults import *
from api.rapi.views.int.filter_api import SiteView, ProductView, ServiceView, CustomerView

urlpatterns = patterns('api.rapi.views.int',
    (r'^int/oncall/list/$', 'oncall_list'),
    (r'^int/pop/list/$', 'pop_list'),
    #(r'^int/flush/range/(?P<time_in_seconds>[0-9]*)/$', 'getFlushRange'), #this one needs to be conformed not usable atm
)

urlpatterns += patterns('api.rapi.views.int.memcached_status',
    (r'^int/memcached/status/$', 'memcached_status')
)

urlpatterns += patterns('api.rapi.views.int.site',
    (r'^int/draft/view/(?P<pad>[\w\.\-\*]+)/$', 'draft_view'),
    (r'^int/draft/trace_internal/(?P<pad>[\w\.\-\*]+)/$', 'trace_internal'),
    (r'^int/draft/mail_template/(?P<pad>[\w\.\-\*]+)/$', 'mail_template_view'),
    (r'^int/draft/mail_logs/(?P<pad>[\w\.\-\*]+)/$', 'site_mail_logs'),
    (r'^int/draft/stage_diff/(?P<pad>[\w\.\-\*]+)/$', 'stage_diff_view'),
    (r'^int/draft/production_diff/(?P<pad>[\w\.\-\*]+)/$', 'production_diff_view'),
    (r'^int/production-site/add/$', 'site_add'),
    (r'^int/production-site/edit/(?P<site>[\w\.\-\*0-9]+)/$', 'site_edit'),
    (r'^int/site-product/edit/(?P<site>[\w\.\-\*0-9]+)/$','product_edit'),
    (r'^int/site-product/move/(?P<site>[\w\.\-\*0-9]+)/$','product_move'),
    (r'^int/site/alert/ddos_attack/$','ddos_attack_event'),
    (r'^int/site/ddos/fetch_queues/$','fetch_site_ddos_queues'),
    (r'^int/site/ddos/update_queue_status/$','update_site_ddos_queue_status'),
    (r'^int/site/ddos/automated/$','get_automated_site_ddos_rules'),
    (r'^int/site/ddos/convert_to_attack/$','ddos_convert_to_attack'),
    (r'^int/site/ddos/restore_to_normal/$','ddos_restore_to_normal'),
)

urlpatterns += patterns('api.rapi.views.int.site',
        (r'^int/search_server_action_rule/$', 'search_server_action_rule'),
        (r'^int/update_server_action_rule/$', 'update_server_action_rule'),
)

urlpatterns += patterns('api.rapi.views.int.get_info_api',
    (r'^int/get_response_stat/$','get_response_stat'),
    (r'^int/get_service_info/$','get_service_info'),
    (r'^int/get_service_vip/$', 'get_service_vip'),
    (r'^int/get_shield_info/$', 'get_shield_info'),
    (r'^int/get_edge_info/$', 'get_edge_info'),
    (r'^int/get_band_vip/$', 'get_band_vip'),
    (r'^int/get_pop_vip/$', 'get_pop_vip'),
    (r'^int/get_vip_customer/$', 'get_vip_customer'),
    (r'^int/get_pop_info/$', 'get_pop_info'),
    (r'^int/get_pops_in_service/$', 'get_pops_in_service')
)

urlpatterns += patterns('api.rapi.views.int.filter_api',
    (r'^int/get/site/$',SiteView.as_view()),
    (r'^int/get/product/$',ProductView.as_view()),
    (r'^int/get/service/$',ServiceView.as_view()),
    (r'^int/get/customer/$',CustomerView.as_view()),
)


urlpatterns += patterns('api.rapi.views.int.region',
    (r'^int/region/list/$', 'region_list'),
)

urlpatterns += patterns('api.rapi.views.int.node',
    (r'^int/node/add/$', 'node_add_or_edit'),
    #(r'^int/node/edit/(?P<name>[^/]+)/$', 'node_add_or_edit'),
    (r'^int/node/list/$', 'node_list'),
    #(r'^int/node/view/(?P<name>[^/]+)/$', 'node_view'),
)

urlpatterns += patterns('api.rapi.views.int.nodeip',
    (r'^int/nodeip_v6/register/$', 'register_ipv6'),
    (r'^int/nodeip_v6/delete/$', 'delete_ipv6'),
    (r'^int/nodeip_v6/list/$', 'list_ipv6'),
)

urlpatterns += patterns('api.rapi.views.int.hashpoint',
    (r'^int/hashpoint/modify/$', 'hashpoint_modify'),
    (r'^int/hashpoint/preview/$', 'hashpoint_preview'),
)

urlpatterns += patterns('api.rapi.views.int.service',
    (r'^int/service/list/$', 'service_list'),
    (r'^int/service/view/(?P<id>\d+)/$', 'service_view'),
)

urlpatterns += patterns('api.rapi.views.int.customer',
    (r'^int/customer/add/$', 'customer_add', {'name': None}),
    (r'^int/customer/edit/(?P<name>.+)/$', 'customer_add_or_edit'),
    (r'^int/customer/view/(?P<name>.+)/$', 'customer_view'),
    (r'^int/customer/list/$', 'customer_list'),
    (r'^int/customer/update/$', 'customer_name_update'),
    (r'^int/customer/view/$', 'customer_name_view'),
)
urlpatterns += patterns('api.rapi.views.int.operator',
    (r'^int/operator/lift_login_block/(?P<username>[^/]+)/$', 'lift_login_block'),
)


urlpatterns += patterns('api.rapi.views.int.portal-integration',
    (r'^int/ocsp-user/add/$', 'user_add_or_edit', {'user_id': None}),
    (r'^int/ocsp-user/edit/(?P<user_id>[0-9]+)/', 'user_add_or_edit'),
    (r'^int/ocsp-user/deactivate/(?P<user_id>[0-9]+)/', 'user_deactivate'),
)

urlpatterns += patterns('api.rapi.views.int.portal-integration',
    (r'^int/cop-user/add/$', 'user_add_or_edit', {'user_id': None, 'cop':True}),
    (r'^int/cop-user/edit/(?P<user_id>[0-9]+)/', 'user_add_or_edit', {'cop':True}),
    (r'^int/cop-user/deactivate/(?P<user_id>[0-9]+)/', 'user_deactivate'),
)

urlpatterns += patterns('api.rapi.views.int.alert',
    (r'^int/alert/add/$', 'alert_add'),
)

urlpatterns += patterns('api.rapi.views.int.keystore',
    (r'^int/keystore/list/$', 'keystore_list'),
    (r'^int/keystore/view/(?P<id>\d+)/$', 'keystore_view'),
)

urlpatterns += patterns('api.rapi.views.int.push',
    (r'^int/push/add/$', 'push_add'),
    (r'^int/push/history/$', 'push_history'),
    (r'^int/push/details/$', 'push_details'),
    (r'^int/site/push/(?P<pad>[\w\.\-\*]+)/history/$', 'push_history'),
)

urlpatterns += patterns('api.rapi.views.int.product',
    (r'^int/product/add/$', 'product_add_or_edit'),
    (r'^int/product/edit/(?P<cop_product_id>[^/]+)/$', 'product_add_or_edit'),
    (r'^int/product/view/(?P<cop_product_id>[^/]+)/$', 'product_view'),
    (r'^int/product/list/$', 'product_list'),
)

urlpatterns += patterns('api.rapi.views.contract',
    (r'^cdn/contract/view/(?P<cop_product_id>[^/]+)/$', 'contract_view'),
    (r'^cdn/contract/list/$', 'contract_list'),
    (r'^cdn/contract/(?P<cop_product_id>[^/]+)/shields/$', 'contract_shields'),
)

urlpatterns += patterns('api.rapi.views.push',
    (r'^cdn/push/history/$', 'push_history'),
    (r'^cdn/push/(?P<pad>[\w\.\-\*]+)/history/$', 'push_history'),
    (r'^cdn/site/push/(?P<pad>[\w\.\-\*]+)/history/$', 'push_history'),
)

urlpatterns += patterns('api.rapi.views.content',
    (r'^cdn/content/purge/list/(?P<pad>[\w\.\-\*]+)/$', 'content_purge_list'),
    (r'^cdn/content/purge/status/(?P<id>\d+)/$', 'content_purge_status'),
    (r'^cdn/content/purge/(?P<type>[A-Za-z]+)/(?P<pad>[\w\.\-\*]+)/$', 'content_purge'),
    (r'^cdn/content/expire/(?P<type>[A-Za-z]+)/(?P<pad>[\w\.\-\*]+)/$', 'content_purge'),
)


urlpatterns += patterns('api.rapi.views.site',
    (r'^cdn/site/add/$', 'site_edit'),
    (r'^cdn/site/edit/(?P<pad>[\w\.\-\*]+)/$', 'site_edit'),
    (r'^cdn/site/add/v2/$', 'site_edit_v2'),
    (r'^cdn/site/edit/v2/(?P<pad>[\w\.\-\*]+)/$', 'site_edit_v2'),
    (r'^cdn/site/requestimplement/(?P<pad>[\w\.\-\*]+)/$', 'site_request_implement'),
    (r'^cdn/site/cancelrequest/(?P<pad>[\w\.\-\*]+)/$', 'site_cancel_request_implement'),
    (r'^cdn/site/delete/(?P<pad>[\w\.\-\*]+)/$', 'site_delete'),
    (r'^cdn/site/selfimplementable/(?P<pad>[\w\.\-\*]+)/$', 'site_is_self_implementable'),
    (r'^cdn/site/view/(?P<pad>[\w\.\-\*]+)/$', 'site_view'),
    (r'^cdn/site/version/history/(?P<pad>[\w\.\-\*]+)/$', 'site_version_history'),
    (r'^cdn/site/version/compare/(?P<pad>[\w\.\-\*]+)/$', 'site_version_compare'),
    (r'^cdn/site/version/restore/(?P<pad>[\w\.\-\*]+)/$', 'site_version_restore'),
    (r'^cdn/site/stagingtest/(?P<pad>[\w\.\-\*]+)/$', 'site_trace_internal'),
    (r'^cdn/site/push/(?P<pad>[\w\.\-\*]+)/staging/$', 'site_push_to_staging'),
    (r'^cdn/site/push/(?P<pad>[\w\.\-\*]+)/production/$', 'site_push_to_production'),
    (r'^cdn/site/push/(?P<pad>[\w\.\-\*]+)/status/$', 'site_push_status'),
    (r'^cdn/site/list/$', 'site_list'),
    (r'^cdn/site/preheat/$', 'preheat_api'),
    (r'^cdn/site/preheatinfo/$', 'preheatinfo_api'),
    (r'^cdn/site/originip/$', 'originip_api'),
)

urlpatterns += patterns('api.rapi.views.sam',
    (r'^cdn/site/(?P<pad>[\w\.\-\*]+)/sam_add/$', 'sam_add'),
    (r'^cdn/site/(?P<pad>[\w\.\-\*]+)/sam_view/$', 'sam_view'),
    (r'^cdn/site/(?P<pad>[\w\.\-\*]+)/sam_edit/$', 'sam_edit'),
    (r'^cdn/site/(?P<pad>[\w\.\-\*]+)/sam_delete/$', 'sam_delete'),
)

urlpatterns += patterns('api.rapi.views.user',
    #(r'^cdn/user/add/$', 'user_add_or_edit', {'name': None}),
    #(r'^cdn/user/edit/(?P<name>[^/]+)/$', 'user_add_or_edit'),
    (r'^cdn/user/view/(?P<name>[^/]+)/$', 'user_view'),
    (r'^cdn/user/list/$', 'user_list'),
)

urlpatterns += patterns('api.rapi.views.log',
    (r'^cdn/log/view/(?P<aggregate_type>\d+)/(?P<pad>[\w\.-]+)/$', 'log_view'),
)

urlpatterns += patterns('api.rapi.views.invoice',
    (r'^cdn/invoice/list/$', 'invoice_list'),
    (r'^cdn/invoice/view/(?P<invoice_id>[A-Za-z0-9]+)/$', 'invoice_view'),
)

urlpatterns += patterns('api.rapi.views.ticket',
    (r'^cdn/ticket/add/(?P<issue_type>\d+)/$', 'ticket_add'),
)
