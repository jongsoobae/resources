from datetime import datetime
from django.db.models import query, manager
from django.http import HttpResponse, QueryDict
from django.utils import simplejson
from urllib import unquote

class queryAndDateEncoder(simplejson.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return '@' + obj.isoformat() + '@'
        if isinstance(obj, query.ValuesQuerySet):
            return list(obj)
        if isinstance(obj, manager.Manager) or \
                isinstance(obj, query.QuerySet):
            return list(obj.values())
        return super(queryAndDateEncoder, self).default(obj)

class RestResponse(HttpResponse):
    def __init__(self, object, error = {}, label = "data", status = 200, custom_mode=False):
        """outputs a json object based on the object submitted.
        This takes the object and puts it in a dictionary with the key of 
        label property and if error is not empty will add that to the dictionary also
        which is then converted to json

        if error is not passed, label is passed None and object is a dictionary will json the dictionary as provided

        special handling is added for django.db.models.query, django.db.models.queryValuesQuerySet
        and datetime.datetime"""
        try:
            if label == None and error in [None,{}] and isinstance(object,dict):
                resp = object
            else:
                resp = {label: object}
        except:
            error['internal'] = "Internal error compiling results"
            resp = {}
        if len(error) > 0 and not resp.has_key('errors'):
            resp['errors'] = error
        if custom_mode == False:
            resp['status_code'] = status
        HttpResponse.__init__(self,  
            simplejson.dumps(resp, cls=queryAndDateEncoder, ensure_ascii=False, indent=4), 
            mimetype='text/plain; charset=utf-8', status=status)

def get_rest_username_password(request):
    """Returns tuple of username/password/login_as_id/customer_id and removes them from the path in the request object"""
    return _get_colon_separated_pair(request)

def get_rest_login_id_customer_id(request):
    """Assumes username/password already removed from path"""
    return _get_colon_separated_pair(request, depth=3)

def _get_colon_separated_pair(request, depth=None):
    pair_split = request.path.find(":") #splits username and password...requires domain to never have a : in it
    if pair_split <= 0:
        return (None, None)

    after = request.path.find("/",pair_split+1)
    pre_b = request.path[:pair_split]
    if depth != None and pre_b.count("/") != depth:
        return (None, None)

    before = pre_b.rfind("/")
    a = unquote(pre_b[before+1:])
    b = unquote(request.path[pair_split+1:after])

    request.path = pre_b[:before] + request.path[after:]
    request.META['PATH_INFO'] = request.path
    request.path_info = request.path
    return (a, b)


def getOptionalParams(pRequest):
    """Takes a request object and returns all the optional parameters supplied.
    For a rest request we consider any query string or posted parameters to be optional
    """
    opt_params = None
    if pRequest.POST:
        opt_params = pRequest.POST.copy()
    if pRequest.GET:
        if opt_params == None:
            opt_params = pRequest.GET.copy()
        else:
            opt_params.update(pRequest.GET)
    if opt_params == None:
        opt_params = QueryDict({}).copy()
    return opt_params

def popAndFilter(params, model_query, param, key, expectslist=False, exclude=False):
    """What this does is check dict for param and if it exists applies a filter on model query of filter = param

    !!!!!!!This has a side affect of remove the value from the dictionary!!!!!!!!

    @param params = QueryDict copy that is mutable
    @param model_query = ModelQuery object that filter is applied to
    @param param = Paramater to look for in params
    @param key = The filter/exclude key to pass
    @param expectslist = If True will pass list into filter/exclude instead of the first value
    @param exclude = If True will use exclude instead of filter

    @return updated model_query or original if no change
    """
    if params.has_key(param):
        try:
            kwargs = {key: params.pop(param) if expectslist else params.pop(param)[0]}
            if exclude:
                return model_query.exclude(**kwargs)
            else:
                return model_query.filter(**kwargs)
        except Exception, e:
            params.setlist(param,kwargs[key])
    return model_query
