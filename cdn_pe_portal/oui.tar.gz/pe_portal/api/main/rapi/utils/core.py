from ci.common.utils.api import get_object_or_api_exception, values_replace_choice, \
	APIException, get_object_or_api_exception, create_api_modelform
from ci.common.models.common import DatedModel
from api.rapi.utils import RestResponse, popAndFilter, getOptionalParams

def add_or_edit(pRequest, modelform, object, description="request", pk="id", edit_blacklist=[], blacklist=[]):
	"""This handles the standard add/edit functionality.
	Standard functionality assumes edit permission for all fields.
	
	if object = None then this is and add otherwise an else.
	
	Parameters:
		model = Model that is being modified
		modelform = Form for model above
		object = None for new otherwise object to edit
		description = Name of object for printing.
		pk = Primary key if not id
		edit_blacklist = List of fields that can be set during add but not during edit

	This function expects the data to be verified to be allowed before entering this function"""

	model = modelform.Meta.model
	opts = getOptionalParams(pRequest)
	opts_set = set(opts)
	if hasattr(modelform.Meta,"fields"):
		fields = modelform.Meta.fields
	else:
		available_fields = list(f.name for f in model._meta.fields)
	if hasattr(modelform.Meta,"exclude"):
		for item in modelform.Meta.exclude:
			if item in available_fields:
				available_fields.remove(item)
	if object == None:
		"This is an add so there is a minimum set of fields that must be set!"
		required_fields = set((f.name if f.blank == False and f.editable == True else None) for f in model._meta.fields)
		required_fields.remove(None)
		missing_opts = required_fields.difference(opts_set)
		if len(missing_opts) > 0:
			raise APIException("Following missing parameters are required: " + ", ".join(missing_opts))
	else:
		for item in edit_blacklist:
			if item in available_fields:
				available_fields.remove(item)
	for item in blacklist:
		if item in available_fields:
			available_fields.remove(item)
	invalid_opts = opts_set.difference(available_fields)
	if len(invalid_opts) > 0:
		raise APIException("Invalid parameters in request: " + ", ".join(invalid_opts))
	form = create_api_modelform(modelform, opts_set)
	form = form(data=opts,instance=object)

	errors = {}
	if form.is_valid():
		saved_obj = form.save()
		if object == None: #added instead of edited
			return (saved_obj, RestResponse({'details': description.capitalize() + " has been created", 'id': getattr(saved_obj,pk)}))
		else:
			return (saved_obj, RestResponse({'details': description.capitalize() + " has been modified"}))
	if form.errors:
		for item, value in form.errors.items():
			if item == "_all__":
				item = "general"
			errors[item] = value.as_text()
	return (None, RestResponse({}, error = errors, status = 400))
