from datetime import datetime, timedelta
import urllib
from django.contrib.auth.decorators import user_passes_test
from ci.common.utils.pusher import request_cache_flush, flush_limit_error_codes, flush_limit_status, clean_flush_paths, FLUSH_ALL, FLUSH_PATHS
from ci.common.utils import get_allowed_sites
from ci.common.utils.api import get_object_or_api_exception, APIException, values_replace_choice, get_site_or_api_exception
from ci.common.utils.flush import  flush_percent_done
from ci.common.models.site import Site
from ci.common.models.pusher import PusherToNodeUpdateFlush
from ci.common.forms.flush import FlushReceiptForm
from api.rapi.utils import RestResponse, popAndFilter, getOptionalParams
from ci.common.models.pusher import FLUSH_TYPES
from ci.common.utils.flush_api import list_flush_by_pad, create_site_otg 

def content_purge(pRequest, type, pad):
	if pRequest.session.get('operr_flag') == None:
		return content_purge_nor(pRequest, type, pad)
	else:
		return content_purge_otg(pRequest, type, pad)

def content_purge_otg(pRequest, type, pad):
	"""REST interface for cache flushing.
	if input could not be parsed: 400
	if auth key incorrect or REST not enabled: 403
	if site not recognized: 404
	"""
	type = type.lower()
	#accepted types uri just for backwards compatibility (original choice, but realized it is incorrect for wildcard domains so changed to item
	flush_types = {'all': FLUSH_ALL, 'wildcard':FLUSH_PATHS, 'uri': FLUSH_PATHS, 'item': FLUSH_PATHS}
	wildcard_true = ['wildcard'] #if type in this list then wildcard flag will be true
	path_required = ['wildcard', 'uri', 'item'] #if type in this list a path param is required, otherwise not allowed
	ims_allowed = ['all','wildcard'] #if type in this list then IMS is allowed

	#allowe sites
	site = create_site_otg(pad)

	opt_params = getOptionalParams(pRequest)
	username = pRequest.session.get('operr_user')
	if opt_params.has_key('staff'):
		opt_params.pop('staff')

	if opt_params.has_key('username'):
		username = '%s (via: %s)' %(opt_params.get('username'), username)
		opt_params.pop('username')

	if not flush_types.has_key(type):
		raise APIException("Invalid flush type supplied", status=400)

	if opt_params.has_key('ims') and opt_params.pop('ims') == [u"1"]:
		if not type in ims_allowed:
			raise APIException("ims flag can not be used in conjuction with this expiration type", status=400)
		ims = True
	else:
		ims = False

	if type in path_required:
		if not opt_params.has_key('path'):
			raise APIException("At least 1 path required for this flush type", status=400)
		paths_unencoded = opt_params.pop('path')
		#need to urlencode the paths...
		paths = [x.replace(" ","%20") for x in paths_unencoded]
	else:
		paths = []
	if len(opt_params) > 0:
		raise APIException("Invalid parameters in request: " + opt_params.urlencode(), status=400)
	desc = '%s rest flush (%d items)' %(type, len(paths))
	path_errors = clean_flush_paths(site, paths, ims=ims, wildcard=type in wildcard_true)
	if path_errors:
		return RestResponse({}, label = None, error=path_errors, status=400)
	if paths:
		limit = flush_limit_status(site, len(paths), 3 if type in wildcard_true else 2)
	else:
		limit = flush_limit_status(site, 0, 1 if opt_params.has_key('ims') else 4)
	if limit > 0:
		raise APIException(flush_limit_error_codes.get(limit), status=509)

	try:
		push_id = request_cache_flush(desc, username, site, flush_types[type], paths=paths, wildcard=type in wildcard_true, use_ims=ims)
	except:
		raise APIException("Invalid request, contact support@pantherexpress.net for further information", status=400)
	resp = {'id': push_id, 'details':desc}
	if type in path_required:
		resp['paths'] = paths
	return RestResponse(resp, label = None)



@user_passes_test(lambda u: u.get_profile().can_flush_item or u.get_profile().can_flush_all or u.get_profile().can_flush_wildcard)
def content_purge_nor(pRequest, type, pad):
	"""REST interface for cache flushing.
	if input could not be parsed: 400
	if auth key incorrect or REST not enabled: 403
	if site not recognized: 404
	"""
	type = type.lower()
	#accepted types uri just for backwards compatibility (original choice, but realized it is incorrect for wildcard domains so changed to item
	flush_types = {'all': FLUSH_ALL, 'wildcard':FLUSH_PATHS, 'uri': FLUSH_PATHS, 'item': FLUSH_PATHS}
	wildcard_true = ['wildcard'] #if type in this list then wildcard flag will be true
	path_required = ['wildcard', 'uri', 'item'] #if type in this list a path param is required, otherwise not allowed
	ims_allowed = ['all','wildcard'] #if type in this list then IMS is allowed

	#allowe sites
	sites = get_allowed_sites(pRequest)
	username = pRequest.user.username

	opt_params = getOptionalParams(pRequest)
	if (not pRequest.user.userprofile.can_flush_all and flush_types.get(type)==FLUSH_ALL) or (not pRequest.user.userprofile.can_flush_wildcard and type in  wildcard_true) or (not pRequest.user.userprofile.can_flush_item and flush_types.get(type)==FLUSH_PATHS and type not in wildcard_true):
		raise APIException("Your user account does not have permission to use this expiration type", status=403)
	if opt_params.has_key('staff') and pRequest.user.is_staff and opt_params.pop('staff') == [u"1"]:
		sites = Site.objects.all()
		if opt_params.has_key('username'):
			username = '%s (via: %s)' %(opt_params.get('username'), username)
			opt_params.pop('username') #need to remove to track what was used.

	site = get_object_or_api_exception(sites, pad=pad, message="Invalid site supplied")

	if not flush_types.has_key(type):
		raise APIException("Invalid flush type supplied", status=400)

	if opt_params.has_key('ims') and opt_params.pop('ims') == [u"1"]:
		if not type in ims_allowed:
			raise APIException("ims flag can not be used in conjuction with this expiration type", status=400)
		ims = True
	else:
		ims = False

	if type in path_required:
		if not opt_params.has_key('path'):
			raise APIException("At least 1 path required for this flush type", status=400)
		paths_unencoded = opt_params.pop('path')
		#need to urlencode the paths...
		paths = [x.replace(" ","%20") for x in paths_unencoded]
	else:
		paths = []
	if len(opt_params) > 0:
		raise APIException("Invalid parameters in request: " + opt_params.urlencode(), status=400)
	desc = '%s rest flush (%d items)' %(type, len(paths))
	path_errors = clean_flush_paths(site, paths, ims=ims, wildcard=type in wildcard_true)
	if path_errors:
		return RestResponse({}, label = None, error=path_errors, status=400)
	if paths:
		limit = flush_limit_status(site, len(paths), 3 if type in wildcard_true else 2)
	else:
		limit = flush_limit_status(site, 0, 1 if opt_params.has_key('ims') else 4)
	if limit > 0:
		raise APIException(flush_limit_error_codes.get(limit), status=509)

	try:
		push_id = request_cache_flush(desc, username, site, flush_types[type], paths=paths, wildcard=type in wildcard_true, use_ims=ims)
	except:
		raise APIException("Invalid request, contact support@pantherexpress.net for further information", status=400)
	resp = {'id': push_id, 'details':desc}
	if type in path_required:
		resp['paths'] = paths
	return RestResponse(resp, label = None)


def content_purge_status(pRequest, id):
    if pRequest.session.get('operr_flag') == None:
        return content_purge_status_nor(pRequest, id)
    else:
        return content_purge_status_otg(pRequest, id)


def content_purge_status_otg(pRequest, id):
	opt_params = getOptionalParams(pRequest)
	if opt_params.has_key('staff'):
		opt_params.pop('staff')
	if len(opt_params) > 0:
		raise APIException("Invalid parameters in request: " + opt_params.urlencode(), status=400)

	receipt_form = FlushReceiptForm({'id': id}, initial_sites=[], operr_flag=pRequest.session.get('operr_flag'))
	errors = {}
	if receipt_form.is_valid():
		try:
			org_receipt = receipt_form.cleaned_data['receipt']
			percent_done = float(org_receipt['percent'])
		except Exception, e:
			percent_done = None
			org_receipt = None
		if org_receipt['request_cnt'] == 1:
			tmp_receipt = {}
			tmp_receipt['items'] = int(org_receipt['items'])
			tmp_receipt['create_user'] = org_receipt['req_create_user'] 
			tmp_receipt['submitted_time'] = org_receipt['req_submitted_time']
			tmp_receipt['create_time'] = org_receipt['repo_create_time'] 
			tmp_receipt['pad'] = org_receipt['site']
			tmp_receipt['type'] = FLUSH_TYPES.get(int(org_receipt['type']),'bad/unknown type') 
			tmp_receipt['id'] = int(org_receipt['request_id'])
			receipt = [tmp_receipt]

			resp = {'percent_complete': percent_done, 'receipt': receipt}
			if percent_done < 100 and receipt[0]['submitted_time'] < datetime.now() - timedelta(minutes=5):
				resp['warning'] = "This flush request has not been fully processed by our system within our expected timeframe.\n\nThe delay in processing flushes is likely due to a node, or small number of nodes, that was temporarily unable to receive flush requests our flush repository. Please allow additional time for this small node subset to process all previous flush requests.\n\nIf your flush request is of an urgent nature, please submit a trouble ticket so we identify the node(s) that are in the process of catching up on flushes and take corrective measures to ensure that the the most up to date content is being served by CDNetworks."
			return RestResponse(resp)
		errors['general'] = "Unknown error occurred.  Please contact support"
	for item, value in receipt_form.errors.items():
		if item == "__all__":
			item = "general"
		errors[item] = value.as_text()
	return RestResponse({},error = errors, status=400)


@user_passes_test(lambda u: u.get_profile().can_flush_item or u.get_profile().can_flush_all or u.get_profile().can_flush_wildcard)
def content_purge_status_nor(pRequest, id):
	opt_params = getOptionalParams(pRequest)
	if opt_params.has_key('staff') and pRequest.user.is_staff and opt_params.pop('staff') == [u"1"]:
		sites = Site.objects.all()
	else:
		sites = get_allowed_sites(pRequest)
	if len(opt_params) > 0:
		raise APIException("Invalid parameters in request: " + opt_params.urlencode(), status=400)

	receipt_form = FlushReceiptForm({'id': id}, initial_sites=sites)
	errors = {}
	if receipt_form.is_valid():
		try:
			org_receipt = receipt_form.cleaned_data['receipt']
			percent_done = float(org_receipt['percent'])
		except Exception, e:
			percent_done = None
			org_receipt = None
		if org_receipt['request_cnt'] == 1:
			tmp_receipt = {}
			tmp_receipt['items'] = int(org_receipt['items'])
			tmp_receipt['create_user'] = org_receipt['req_create_user'] 
			tmp_receipt['submitted_time'] = org_receipt['req_submitted_time']
			tmp_receipt['create_time'] = org_receipt['repo_create_time'] 
			tmp_receipt['pad'] = org_receipt['site']
			tmp_receipt['type'] = FLUSH_TYPES.get(int(org_receipt['type']),'bad/unknown type') 
			tmp_receipt['id'] = int(org_receipt['request_id'])
			receipt = [tmp_receipt]

			resp = {'percent_complete': percent_done, 'receipt': receipt}
			if percent_done < 100 and receipt[0]['submitted_time'] < datetime.now() - timedelta(minutes=5):
				resp['warning'] = "This flush request has not been fully processed by our system within our expected timeframe.\n\nThe delay in processing flushes is likely due to a node, or small number of nodes, that was temporarily unable to receive flush requests our flush repository. Please allow additional time for this small node subset to process all previous flush requests.\n\nIf your flush request is of an urgent nature, please submit a trouble ticket so we identify the node(s) that are in the process of catching up on flushes and take corrective measures to ensure that the the most up to date content is being served by CDNetworks."
			return RestResponse(resp)
		errors['general'] = "Unknown error occurred.  Please contact support"
	for item, value in receipt_form.errors.items():
		if item == "__all__":
			item = "general"
		errors[item] = value.as_text()
	return RestResponse({},error = errors, status=400)



def content_purge_list(pRequest, pad):
	if pRequest.session.get('operr_flag') == None:
		return content_purge_list_nor(pRequest, pad)
	else:
		return content_purge_list_otg(pRequest, pad)

def content_purge_list_otg(pRequest, pad):
	opt_params = getOptionalParams(pRequest)
	if opt_params.has_key('staff'):
		opt_params.pop('staff') == [u"1"]
	site = create_site_otg(pad)
	if len(opt_params) > 0:
		raise APIException("Invalid parameters in request: " + opt_params.urlencode(), status=400)
	errors = {}
	receipt = list_flush_by_pad(site, requester=None, max_result=None)
	result = []
	for item in receipt:
		result.append({"items":int(item.pop('items')),
						"id":int(item['push_request_id']),
						"create_user":item.pop('create_user'),
						"create_time":item['create_time'],
						"pad":item.pop('site'),
						"type":FLUSH_TYPES.get(int(item['type']),'bad/unknown type'),
						"submitted_time":item.pop('submitted')})

	return RestResponse(result)

def content_purge_list_nor(pRequest, pad):
	opt_params = getOptionalParams(pRequest)
	if opt_params.has_key('staff') and pRequest.user.is_staff and opt_params.pop('staff') == [u"1"]:
		#staff access anything....
		site = get_object_or_api_exception(Site.objects.all(), pad=pad, message="Invalid site supplied")
	else:
		#otherwise only your allowed pads
		site = get_site_or_api_exception(pRequest, pad)
	if len(opt_params) > 0:
		raise APIException("Invalid parameters in request: " + opt_params.urlencode(), status=400)
	errors = {}
	receipt = list_flush_by_pad(site, requester=None, max_result=None)
	result = []
	for item in receipt:
		result.append({"items":int(item.pop('items')),
						"id":int(item['push_request_id']),
						"create_user":item.pop('create_user'),
						"create_time":item['create_time'],
						"pad":item.pop('site'),
						"type":FLUSH_TYPES.get(int(item['type']),'bad/unknown type'),
						"submitted_time":item.pop('submitted')})

	return RestResponse(result)
