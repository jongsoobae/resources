from django.contrib.auth.decorators import user_passes_test
from django.conf import settings
from ci.common.models.customer import Product, Customer, CustomerProductEdge
from ci.common.utils.api import APIErrorResponse, APIException
from ci.common.utils.util_api import get_cs_contract_info
from ci.common.utils import get_customer
from api.rapi.utils import getOptionalParams, RestResponse
import json

def padded_cop_product_id(cop_product_id):
    errors = {}
    try:
        temps = cop_product_id.split('-')
        return "%s-%s" % (temps[0].zfill(10), temps[1].zfill(6))
    except:
        return APIErrorResponse("Invalid contract_no input")

def contract_view(pRequest, cop_product_id):
    errors = {}
    try:
        if cop_product_id is None:
            return APIErrorResponse('contract_no inupt missing')

        cop_product_id = padded_cop_product_id(cop_product_id)
        customer = get_customer(pRequest)
        contracts = customer.get_allowed_contracts(pRequest).values_list('cop_product_id',flat=True)
        if cop_product_id not in contracts:
            return APIErrorResponse("not allowed to access.")

        cs_contracts = get_cs_contract_info()
        contract = {}
        try:
            product = Product.objects.get(cop_product_id=cop_product_id)
        except Product.DoesNotExist:
            return APIErrorResponse("contract does not exist")

        cs_contract = cs_contracts.get(cop_product_id)
        contract_info = product.get_contract_info(cs_contract)
        return RestResponse(contract_info)
    except Exception,e:
        return RestResponse({},status=400,error=errors)

def contract_list(pRequest, cop_product_id=None):
    customer = get_customer(pRequest)
    contracts = customer.get_allowed_contracts(pRequest).values_list(
        'cop_product_id',flat=True)
    cs_contracts = get_cs_contract_info()
    contract_list = []

    for cop_product_id in contracts:
        product = Product.objects.get(cop_product_id= cop_product_id)
        cs_contract = cs_contracts.get(cop_product_id)
        contract_info = product.get_contract_info(cs_contract)
        contract_list.append(contract_info)

    return RestResponse(contract_list)

def contract_shields(pRequest, cop_product_id):
    errors = {}
    if cop_product_id is None:
        return APIErrorResponse('contract_no inupt missing')
    cop_product_id = padded_cop_product_id(cop_product_id)
    try:
        customer = get_customer(pRequest)
        contracts = customer.get_allowed_contracts(pRequest).values_list('cop_product_id',flat=True)
        if cop_product_id not in contracts:
            return APIErrorResponse("not allowed to access.")

        cs_contracts = get_cs_contract_info()
        shield_locations = {}

        try:
            product = Product.objects.get(cop_product_id= cop_product_id)
            cs_contract = cs_contracts.get(cop_product_id)
            result = product.get_available_shield_locations(cs_contract)
            shield_locations.update({'result':result})
        except:
            raise APIException("No product found for input %s" % cop_product_id)

        return RestResponse(shield_locations)
    except Exception,e:
        return APIErrorResponse(str(e))

