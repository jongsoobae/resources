from datetime import datetime, timedelta
from django.http import HttpResponseNotFound
from api.rapi.utils import RestResponse, popAndFilter, getOptionalParams
from ci.common.models.alert import OnCallSchedule, OnCallContact
from ci.common.models.pusher import NodeUpdateFlush
from ci.common.models.cdn import Pop, Service
from ci.common.models.cache import Band
from ci.common.utils.api.site import site_add_or_edit

def oncall_list(pRequest):
	schedule = OnCallSchedule.objects.filter(start_time__lte = datetime.now(), end_time__gte = datetime.now())

	info = False
	error = {}
	opt_params = getOptionalParams(pRequest)
	if opt_params.has_key('info') and opt_params.pop('info') == [u"1"]:
		info = True
	if len(opt_params) > 0:
		error['unknown_parameter(s)'] = "The following parameters were not handled: " + opt_params.urlencode()

	if schedule.count() <> 1:
		return HttpResponseNotFound("Current on call schedule not found")

	if info:
		schedule = schedule.values()
		for s in schedule:
			s['contacts'] = []
			for c in OnCallContact.objects.filter(schedule=s['id']):
				user = c.contact
				user_profile = user.userprofile
				s['contacts'].append({
					'seq': c.contact_order,
					'id': user.id,
					'username': user.username,
					'full_name': user.get_full_name(),
					'phone': user_profile.phone_number,
					'phone_numeric': "".join((l if l.isdigit() else "") for l in user_profile.phone_number),
					'email': user.email,
					'mobile_email': user_profile.mobile_email
				})
	else:
		schedule = schedule.values('id')
	return RestResponse(schedule, label = "obj", error = error)

def getFlushRange(pRequest, time_in_seconds):
	flushes = NodeUpdateFlush.objects.filter(create_time__gt = datetime.now() - timedelta(minutes=time_in_seconds)).order_by('create_time')
	count = flushes.count()
	flush = {
		'flushes': count,
		'min_id': flushes[0].id,
		'max_id': flushes[count-1].id,
	}
	return RestResponse(flush)

def pop_list(pRequest):
	pop = Pop.objects
	error = {}

	opt_params = getOptionalParams(pRequest)
	pop = popAndFilter(opt_params, pop, 'pop','id__in', expectslist=True)
	pop = popAndFilter(opt_params, pop, 'service_dns_prefix','service__dns_prefix__in', expectslist=True)
	pop = popAndFilter(opt_params, pop, 'service', 'service__id__in', expectslist=True)
	pop = popAndFilter(opt_params, pop, 'offline', 'offline')
	pop = popAndFilter(opt_params, pop, 'region', 'region__id__in', expectslist=True)
	pop = popAndFilter(opt_params, pop, 'region_name', 'region__name__in', expectslist=True)
	if opt_params.has_key('min_modify_date'):
		try:
			pop = pop.filter(modify_time__gt = \
				datetime.strptime(opt_params.pop('min_modify_date')[0][:19],
				'%Y-%m-%d %H:%M:%S'))
		except:
			error['min_modify_date'] = "Invalid, date must be ISO format without timezone"
	if opt_params.has_key('info') and opt_params.pop('info') == [u"1"]:
		pop = pop.values()
	else:
		pop = pop.values('id','name')
	return RestResponse(pop, error = error)
	
	
def service_list(pRequest):
	error = {}
	service = Service.objects
	opt_params = getOptionalParams(pRequest)
	service = popAndFilter(opt_params, service, 'service_dns_prefix','dns_prefix__in', expectslist=True)
        service = popAndFilter(opt_params, service, 'service', 'id__in', expectslist=True)
	service = popAndFilter(opt_params, service, 'offline', 'offline')
	if opt_params.has_key('min_modify_date'):
		try:
			service = service.filter(modify_time__gt = \
				datetime.strptime(opt_params.pop('min_modify_date')[0][:19],
				'%Y-%m-%d %H:%M:%S'))
		except:
			error['min_modify_date'] = "Invalid, date must be ISO format without timezone"
	if opt_params.has_key('info') and opt_params.pop('info') == [u"1"]:
		service = service.values()
		for s in service:
			s['bands'] = []
			for b in Band.objects.filter(service__id = s['id']):
				s['bands'].append(b.id)
	else:
		service = service.values('id','name', 'dns_prefix')
	return RestResponse(service, error = error)

	