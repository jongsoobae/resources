from django import forms
from django.contrib.auth.decorators import user_passes_test
from ci.common.models.alert import Alert
from ci.common.utils.alert import send_alert
from ci.common.utils.api import APIException
from api.rapi.utils import RestResponse, getOptionalParams
from datetime import datetime, timedelta

ALERT_LIMIT = 10
@user_passes_test(lambda u:u.has_perm('oui.add_alert'))
def alert_add(pRequest):
	opts = getOptionalParams(pRequest)  
	opts_set = set(opts)
	required_params = set(('code', 'subject', 'body')) 
	missing = required_params.difference(opts_set)
	if missing:
		raise APIException("The following params are required to create an alert: %s" % ", ".join(missing))
	if opts.has_key('urgent') and opts.pop('urgent')==[u'0']:
		urgent = False
	else:
		urgent = True              
	code=opts.get('code')
	subject=opts.get('subject')
	body=opts.get('body')
	#check if over rate limit for urgent....
	if Alert.objects.filter(user=pRequest.user, create_time__gt = datetime.now() - timedelta(hours=1), urgent = True).count() >= ALERT_LIMIT:
		return RestResponse({}, error = "This account is over its limit for urgent tickets via API. ", status = 406)
	resp = send_alert(code=code, subject=subject, body=body, urgent=urgent)      
	#    	error = {}
	# if len(opts) > 0:
	# 	error['unknown_parameter(s)'] = "The following parameters were not handled: " + opts.urlencode()
	data = {'details': "Alert created."}
	return RestResponse(data)
