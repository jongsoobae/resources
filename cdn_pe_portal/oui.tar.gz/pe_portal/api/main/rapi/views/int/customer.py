from datetime import datetime
from django.conf import settings
from django.http import HttpResponseNotFound
from django.contrib.auth.decorators import user_passes_test
from api.rapi.utils import RestResponse, popAndFilter, getOptionalParams
from ci.common.utils.api import get_object_or_api_exception, values_replace_choice, \
	APIException, create_api_modelform
from ci.common.models.cdn import Customer
from ci.common.forms.customer import CustomerForm


def customer_add_or_edit(pRequest, name):
	"""REST interface for modifying an existing customer or creating a new customer

	If name == None then this is an add, otherwise it is an edit"""
	opts = getOptionalParams(pRequest)
	opts_set = set(opts)
	customer = get_object_or_api_exception(Customer, name__iexact=name, message='Invalid customer name: ' + name) if name != None else None
	available_fields = tuple(f.name for f in Customer._meta.fields)
	if customer == None:
		"This is an add so there is a minimum set of fields that must be set!"
		required_fields = set((f.name if f.blank == False and f.editable == True and f.get_default() in (None,'') else None) for f in Customer._meta.fields)
		required_fields.remove(None)
		missing_opts = required_fields.difference(opts_set)
		if len(missing_opts) > 0:
			raise APIException("Following parameters are required to add a customer: " + ", ".join(missing_opts))
	else:
		if not opts.has_key('sales_rep'):
			opts['sales_rep'] = customer.sales_rep.username
		if not opts.has_key('sales_eng'):
			opts['sales_eng'] = customer.sales_eng.username
	invalid_opts = opts_set.difference(available_fields)
	if len(invalid_opts) > 0:
		raise APIException("Invalid parameters in request: " + ", ".join(invalid_opts))
	form = create_api_modelform(CustomerForm, opts_set)
	if opts.has_key('cdnetworks_customer'):
		opts['add_to_ocsp'] = 'No'
	form = form(data=opts,auto_id='customerform_%s', instance=customer)
	errors = {}
	if form.is_valid():
		obj = form.save(username=pRequest.user.username)
		if customer == None: #added instead of edited
			return RestResponse({'details': "Customer has been created", 'id': obj.id}, error = errors)
		return RestResponse({'details': "Customer changes have been applied"}, error = errors)
	for item, value in form.errors.items():
		if item == "__all__":
			item = "general"
		errors[item] = value.as_text()
	return RestResponse({},error = errors, status=400)

def customer_add(pRequest, name):
	if not pRequest.user.has_perm('oui.add_customer'):
		raise APIException("User does not have permission to add customers")
	else:
		return customer_add_or_edit(pRequest, name)
	
def customer_list(pRequest):
	error = {}
	customers = Customer.objects
	opt_params = getOptionalParams(pRequest)
	customers = popAndFilter(opt_params, customers, 'active', 'status')
	customers = popAndFilter(opt_params, customers, 'region','address__country__invoice_region__in', expectslist=True)
	if opt_params.has_key('min_modify_date'):
		try:
			customers = customers.filter(modify_time__gt = \
				datetime.strptime(opt_params.pop('min_modify_date')[0][:19],
				'%Y-%m-%d %H:%M:%S'))
		except:
			error['min_modify_date'] = "Invalid, date must be ISO format without timezone"
			opt_params.pop('min_modify_date')
	if opt_params.has_key('info') and opt_params.pop('info') == [u"1"]:
		customers = customers.values()
	else:
		customers = customers.values('id','name')
	if len(opt_params) > 0:
		error['unknown_parameter(s)'] = "The following parameters were not handled: " + opt_params.urlencode()
	customers = values_replace_choice(customers, Customer)
	return RestResponse(customers, error = error)

def customer_view(pRequest, name):
	error = {}
	opt_params = getOptionalParams(pRequest)
	customer = get_object_or_api_exception(Customer,name__iexact=name, as_query=True).values()
	customer = values_replace_choice(customer, Customer)
	if len(opt_params) > 0:
		error['unknown_parameter(s)'] = "The following parameters were not handled: " + opt_params.urlencode()
	return RestResponse(customer[0], error = error)

def customer_name_update(qRequest):
	errors = {}
	opt_params = getOptionalParams(qRequest)
	opts_set = set(opt_params)
	required_fields = set(('name', 'new_name'))
	missing_opts = required_fields.difference(opts_set)
	if len(missing_opts) > 0:
		raise APIException("Following parameters are required to update a customer: " + ", ".join(missing_opts))
	name = opt_params.pop('name')
	new_name = opt_params.pop('new_name')
	if new_name[0] == '' or name[0] == new_name[0]:
		raise APIException("Valid new name is required to update a customer")
	if len(opt_params) > 0:
		raise APIException("Following parameters were not handled : " + ", ".join(opt_params))
	customer = get_object_or_api_exception(Customer, name__iexact=name[0], message='Invalid customer name: ' + name[0])
	new_customer = Customer.objects.filter(name__iexact=new_name[0])
	if len(new_customer):
		raise APIException("New customer name is duplicated")
	customer.name = new_name[0]
	customer.save()
	return RestResponse({'details': "Customer changes have been applied"}, error = errors)

def customer_name_view(qRequest):
	errors = {}
	opt_params = getOptionalParams(qRequest)
	opts_set = set(opt_params)
	required_fields = set(('name',))
	missing_opts = required_fields.difference(opts_set)
	if len(missing_opts) > 0:
		raise APIException("Following parameters are required to view a customer: " + ", ".join(missing_opts))
	name = opt_params.pop('name')
	customer = get_object_or_api_exception(Customer,name__iexact=name[0], as_query=True).values()
	if len(opt_params) > 0:
		errors['unknown_parameter(s)'] = "The following parameters were not handled: " + opt_params.urlencode()
	return RestResponse(customer[0], error = errors)
