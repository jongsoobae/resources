from django.db.models import FieldDoesNotExist
from django.views.generic.list import BaseListView
from api.rapi.utils import RestResponse
from ci.common.models.customer import Product, Customer
from ci.common.models.cdn import Service
from ci.common.models.site import Site
from ci.common.utils.api import APIException


class JSONView(BaseListView):

    def __init__(self, **kwargs):
        super(JSONView, self).__init__(**kwargs)
        self.filter_fields = {}

    def render_to_response(self, context, **response_kwargs):
        return RestResponse(self.get_data(context), **response_kwargs)

    def get_data(self, context):
        if 'paginator' in context:
            del context['paginator']
        if 'page_obj' in context:
            context['page_obj'] = str(context['page_obj'])

        context['filtered_fields'] = self.filter_fields
        context['total_count'] = len(context['object_list'])
        if self.request.GET.get('avail'):
            context['avail_fields'] = self.model._meta.get_all_field_names()
        return context

    def get_context_object_name(self, object_list):
        #  if this exists, api return object_list and model_list, both are same.
        return None

    def get(self, request, *args, **kwargs):
        try:
            return super(JSONView, self).get(request, *args, **kwargs)
        except Exception, e:
            raise APIException(e)

    def get_paginate_by(self, queryset):
        try:
            paginate_by = int(self.request.GET.get('page_size', self.paginate_by))
        except:
            paginate_by = self.paginate_by
        return paginate_by

    def get_queryset(self):
        queryset = super(JSONView, self).get_queryset()
        return queryset.filter(**self.get_valid_filter_field(queryset))

    def get_valid_filter_field(self, queryset):
        filter_fields = {}
        for q, v in self.request.GET.items():
            try:
                self.model._meta.get_field_by_name(q)
            except FieldDoesNotExist:
                continue
            try:
                queryset.filter(**{q: v})
            except ValueError:
                raise APIException('%s field value is error' % q)

            filter_fields[q] = v
        self.filter_fields = filter_fields

        return filter_fields


class SiteView(JSONView):
    model = Site


class ProductView(JSONView):
    model = Product


class ServiceView(JSONView):
    model = Service


class CustomerView(JSONView):
    model = Customer
