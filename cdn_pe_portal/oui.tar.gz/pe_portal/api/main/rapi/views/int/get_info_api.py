import datetime
from datetime import timedelta
from django.utils.datastructures import SortedDict
from api.rapi.utils import RestResponse, popAndFilter, getOptionalParams
from ci.common.utils.api import get_site_or_api_exception, APIException
from ci.common.models import Customer, Site, Product
from ci.common.utils.traffic import round_time_to_epoch, Serieses, processQuery
from ci.constants import HTTP_RESPONSE_CODES
from ci.constants import MySQL_CHARTRON_DB

def convert_unicode_to_str(unicode_str):
    result = unicode_str
    try:
        if isinstance(unicode_str, unicode):
            result = unicode_str.encode('utf8')
            #result = str(unicode_str.replace(u'\xa0', u' '))
    except:
        #there is more unicode not converted
        result = unicode_str.encode('ascii','replace')
    return result

#(stat_time_start = '2012-05-01', stat_time_end = '2012-05-05', by_pop = 0, customer_id=48, pop_id=97, key_value=200, cdn_service_id=3, site_id=144)
def get_response_stat(pRequest):
    opts = getOptionalParams(pRequest)

    #option check pop_id
    #option check pop flag 1 or 0
    if not opts.has_key('by_pop'):
        return  RestResponse({'details':"by_pop is required"})

    if not opts.has_key('stat_time_start'):
        return  RestResponse({'details':"stat_time_start is required"})

    if not opts.has_key('stat_time_end'):
        return  RestResponse({'details':"stat_time_end is required"})


    if not str(opts.get('by_pop')) in ['1', '0']:
        return  RestResponse({'details':"by_pop is not available"})

    if str(opts.get('by_pop')) in ['0'] and opts.has_key('pop_id'):
        return  RestResponse({'details':"pop_id is not required when by_pop is set"})

    if (not opts.has_key('customer_id') and not opts.has_key('cdn_service_id') and not opts.has_key('site_id')):
         return  RestResponse({'details':"least one of customer_id, cdn_service_id, site_id is required."})


    intersec = []
    customer_sites = []
    service_sites = []
    option_site = []
    result_set = set()
    key_value = None
    pop_id = None

    if opts.has_key('pop_id'):
        try:
            pop_id = str(int(opts.get('pop_id')))
        except: 
            return  RestResponse({'details':"pop_id is not required when by_pop is set"})


    #option check customer
    if opts.has_key('customer_id'):
        customer_sites_objs = Site.objects.filter(customer = int(opts.get('customer_id')))
        for obj in customer_sites_objs:
            customer_sites.append(obj.id)
        result_set = set(customer_sites)
        
    #option check cdn_service_id
    if opts.has_key('cdn_service_id'):
        service_sites_objs = Site.objects.filter(service = int(opts.get('cdn_service_id')))
        for obj in service_sites_objs:
            service_sites.append(obj.id)
        if len(result_set) == 0:
            result_set = set(service_sites)
        else:
            result_set = result_set.intersection( set(service_sites) )

    #option check site_id
    if opts.has_key('site_id'):
        option_site_objs = Site.objects.filter(id = int(opts.get('site_id')))
        for obj in option_site_objs:
            option_site.append(obj.id)
        
        if len(result_set) == 0:
            result_set = set(option_site)
        else:
            result_set = result_set.intersection( set(option_site) )

    customer_site_ids = list(result_set)

    if (opts.has_key('customer_id') or opts.has_key('cdn_service_id') or opts.has_key('site_id')) and customer_site_ids == []:
        return  RestResponse({'details':"no intersection"})    
    
    #option check key value in (200, ......)
    if opts.has_key('key_value'):
        if int(opts.get('key_value')) not in HTTP_RESPONSE_CODES:
            return  RestResponse({'details':"retrun code is not available"})
        else:
            key_value = str(opts.get('key_value'))        
    
    sum_columns        = [
        '((sum(t0.e%s)))' % (i) for i in range(288)
    ]

    str_columns = ' ,'.join(sum_columns)

    try:
        start_date = datetime.datetime.strptime(str(opts.get('stat_time_start')), '%Y-%m-%d')
    except:
        return  RestResponse({'details':"stat_time_start is not available"})

    try:
        end_date = datetime.datetime.strptime(str(opts.get('stat_time_end')), '%Y-%m-%d')
    except:
        return  RestResponse({'details':"stat_time_start is not available"})

    if end_date < start_date:
        return  RestResponse({'details':"stat_time_start must be greater than stat_time_end"})

    if end_date != start_date and start_date + timedelta(days=2) < end_date and str(opts.get('by_pop')) in ['1']:
        return  RestResponse({'details':"max period is 3 when by_pop is set"})

    if end_date != start_date and start_date + timedelta(days=6) < end_date and str(opts.get('by_pop')) in ['0']:
        return  RestResponse({'details':"max period is 7 when by_pop is not set"})

    stat_time = []
    while True:
        stat_time.append("stat_time = date('" + start_date.strftime('%Y-%m-%d') + "')")
        start_date = start_date + datetime.timedelta(days=1)
        
        if start_date > end_date:
            break;
    
    str_dates = ' or '.join(stat_time)

    ids = [
        '%s' % str(i) for i in customer_site_ids 
    ]

    str_ids = ' ,'.join(ids)

    if str(opts.get('by_pop')) in ['0']:
        sql = ' select stat_time, customer_site_id, key_value, '
        sql += str_columns
        sql += ' from `site_response_code_requests` t0 '
        sql += ' where (' +  str_dates + ') '
        if str_ids != '':
            sql += ' and t0.CUSTOMER_SITE_ID in (' + str_ids + ') '
        if key_value != None:
            sql += ' and key_value = ' + key_value
        sql += ' group by stat_time, key_value '            

        column = ['stat_time', 'customer_site_id', 'key_value']

    if str(opts.get('by_pop')) in ['1']:
        sql = 'select stat_time, customer_site_id, pop_id, key_value,'
        sql += str_columns
        sql += ' from `site_response_code_requests_pop` t0 '
        sql += ' where (' +  str_dates + ') '
        if str_ids != '':
            sql += ' and t0.CUSTOMER_SITE_ID in (' + str_ids + ') '
        if key_value != None:
            sql += ' and key_value = ' + key_value
        if pop_id != None:
            sql += ' and pop_id = ' + pop_id
        sql += ' group by stat_time, pop_id, key_value '

        column = ['stat_time', 'customer_site_id', 'pop_id', 'key_value']

    ret = processQuery(sql, mysql_params=MySQL_CHARTRON_DB, returnRows=True, isFailOver2Default=True)

    sum_bucket = [
        'e%s' % (i) for i in range(288)
    ]

    pop_column = column + sum_bucket

    ret_arr = []
    for row in ret:
        row_one = []
        for col in row:
            try:
                row_one.append(int(col))
            except:
                row_one.append(str(col))

        tmp_dict = SortedDict(zip(pop_column, row_one))
        ret_arr.append(tmp_dict)

    return  RestResponse(ret_arr)


#type={customer,domain,service},
#name
def get_service_info(pRequest):
    opts = getOptionalParams(pRequest)

    if not opts.has_key('type') or not opts.get('type') in ['customer', 'domain', 'service', 'all']:
        return  RestResponse({'details':"type is required"})

    if not opts.has_key('name') and opts.get('type') <> 'all':
        return  RestResponse({'details':"name is required"})

    param_type = opts.get('type')
    param_name = opts.get('name')

    column = ['domain', 'site_id', 'status', 'service', 'service_dns', 'service_id', 'customer', 'customer_id', \
                        'shielded', 'shielded_id', 'product_key', 'product_name', 'origin', 'static_origin_ip', 'custom_origin_port', 'custom_host_header']

    sql = "select distinct a.SERVE_DOMAIN, a.CUSTOMER_SITE_ID, a.status, b.NAME, b.DNS_PREFIX, b.cdn_service_id, c.name, c.customer_id, "
    sql += " CASE when d.NAME is null then '' else d.NAME end shielded, "
    sql += " CASE when d.id is null then '' else d.id end shielded_id, e.cop_product_id, e.name, "
    sql += " a.domain, a.origin_ip, a.origin_port, a.origin_host_header  "
    sql += " from customer_site a "
    sql += " inner join cdn_service b on a.cdn_service_id = b.CDN_SERVICE_ID "
    sql += " inner join customer c on a.CUSTOMER_ID = c.CUSTOMER_ID "
    sql += " left outer join shielded_service d on a.shielded_service_id = d.id "
    sql += " inner join customer_product e on a.product_id = e.product_id "

    # customer
    if param_type == 'customer': 
        #site_objs = Site.objects.filter(customer__name = param_name)
        sql += " where c.NAME = '" + param_name  + "' "

    # domain 
    if param_type == 'domain':
        #site_objs = Site.objects.filter(pad = param_name)
        sql += " where a.SERVE_DOMAIN = '" + param_name  + "' "

    # service
    if param_type == 'service':
        #site_objs = Site.objects.filter(service__dns_prefix = param_name)
        sql += " where b.DNS_PREFIX = '" + param_name  + "' "

    #if len(site_objs) == 0:
    #    return  RestResponse({'details':"no data"})

    ret = processQuery(sql, mysql_params=MySQL_CHARTRON_DB, returnRows=True, isFailOver2Default=True)

    if len(ret) == 0:
        return  RestResponse({'details':"no data"})

    ret_arr = []
    for row in ret:
        row_one = []
        for col in row:
            row_one.append(convert_unicode_to_str(col))

        tmp_dict = SortedDict(zip(column, row_one))
        ret_arr.append(tmp_dict)

    return  RestResponse(ret_arr)



def get_service_vip(pRequest):
    opts = getOptionalParams(pRequest)

    if not type_range_check_for_table(opts=opts, param_name='dns_prefix', type='str', max_len=8, required=True):
        return RestResponse({'details':"dns_prefix is required"})

    if not type_range_check_for_table(opts=opts, param_name='pop_offline', type='match', required=False, range_values=['1','0']):
        return RestResponse({'details':"pop_offline is required"})

    if not type_range_check_for_table(opts=opts, param_name='offline', type='match', required=False, range_values=['1','0']):
        return RestResponse({'details':"offline is required"})

    if not type_range_check_for_table(opts=opts, param_name='pop_id', type='smallint', required=False):
        return RestResponse({'details':"pop_id is required"})
    
    column = ['node_id', 'hostname', 'ngp_hostname', 'ipv4_address', 'offline', 'broken', 'pop_id', \
                'vips', 'pop_name', 'short_name', 'pop_offline', 'region', 'failed']

    sql = " select distinct Z.node_id, Z.hostname, Z.ngp_hostname, Z.ipv4_address, Z.offline, Z.broken, Z.pop_id, V.ipv4_address, P.NAME, P.short_name, P.OFFLINE, M.NAME, "
    sql += " CASE WHEN Z.OFFLINE = 1 THEN "
    sql += "     0 " # -- not fail
    sql += " ELSE "
    sql += "     CASE WHEN U.failed = 0 THEN "
    sql += "         CASE WHEN TIMEDIFF(NOW(),update_time) > '00:10:00' THEN "
    sql += "             -1 " # -- unkonwn fail
    sql += "         ELSE "
    sql += "             0 " # -- not fail 
    sql += "         END "
    sql += "     ELSE "
    sql += "             ifnull(U.failed,-2) "
    sql += "     END "
    sql += " END failed_oui_case "
    sql += " from "
    sql += " ( "
    sql += "      select node_ip_id from "
    sql += "      ( "
    sql += "      select S.band_id from "
    sql += "           cdndomain_band S inner join cdn_service N on S.cdn_service_id = N.CDN_SERVICE_ID "

    if opts.has_key('dns_prefix'):
        sql += "           where N.dns_prefix = '%s' "%opts.get('dns_prefix')

    sql += "      ) C "
    sql += "      inner join band_node D on C.band_id = D.band_id "
    sql += " ) R "
    sql += " inner join node_ip V on R.node_ip_id = V.id "
    sql += " inner join node Z on V.node_id = Z.node_id "
    sql += " inner join pop P on Z.pop_id = P.pop_id "
    sql += " inner join region M on P.region_id = M.region_id "
    sql += " left outer join nodestat U on U.node_id = Z.NODE_ID "
    sql += " where P.POP_ID <> 22 "

    if opts.has_key('pop_offline'):
        sql += " and P.offline = %s"%opts.get('pop_offline')    

    if opts.has_key('offline'):
        sql += " and Z.offline = %s"%opts.get('offline')    

    if opts.has_key('pop_id'):
        sql += " and P.POP_ID = %s"%opts.get('pop_id')   

    sql += " order by M.region_id, Z.pop_id, Z.hostname "

    ret = processQuery(sql, mysql_params=MySQL_CHARTRON_DB, returnRows=True, isFailOver2Default=True)

    if len(ret) == 0:
        return  RestResponse({'details':"no data"})

    ret_arr = []
    for row in ret:
        row_one = []
        for col in row:
            row_one.append(convert_unicode_to_str(col))

        tmp_dict = SortedDict(zip(column, row_one))

        tmp_name = tmp_dict['hostname']
        try:
            tmp_name = tmp_name[:tmp_name.rfind('.',0,tmp_name.rfind('.'))]
            tmp_dict['hostname'] = tmp_name
        except:
            pass

        ret_arr.append(tmp_dict)

    return  RestResponse(ret_arr)

#2-1
def get_edge_info(pRequest):
    opts = getOptionalParams(pRequest)

    if not type_range_check_for_table(opts=opts, param_name='dns_prefix', type='str', max_len=8, required=True):
        return RestResponse({'details':"dns_prefix is required"})

    if opts.has_key('info') and not opts.get('info') in ['1', '0']:
        return  RestResponse({'details':"info type is required"})

    info = opts.get('info') if opts.get('info') != None else 0

    column_band = ['band_id', 'band_name', 'pop_id', 'pop_name']
    if info == '1':
        column_shield = ['edge_id', 'edge_name', 'band']
    else:
        column_shield = ['edge_id', 'edge_name']

    sql = " select distinct A.CDN_SERVICE_ID, A.NAME, C.id, C.name, P.POP_ID, P.name from "
    sql += " cdn_service A "
    sql += " inner join cdndomain_band B on A.CDN_SERVICE_ID = B.cdn_service_id "
    sql += " inner join band C on B.band_id = C.id "
    sql += " inner join band_node D on C.id = D.band_id " 
    sql += " inner join node E on D.node_id = E.NODE_ID "
    sql += " inner join pop P on E.POP_ID = P.POP_ID "
    sql += " where A.DNS_PREFIX = '%s' "%opts.get('dns_prefix')
    sql += " order by cdn_service_id, id "

    ret = processQuery(sql, mysql_params=MySQL_CHARTRON_DB, returnRows=True, isFailOver2Default=True)

    if len(ret) == 0:
        return  RestResponse({'details':"no data"})

    shield_dict = {}
    for row in ret:
        one_shield = []
        one_band = []
        if not shield_dict.has_key('%s'%str(row[0])):
            one_shield.append(str(row[0]))
            one_shield.append(convert_unicode_to_str(row[1]))
            if info == '1':
                one_shield.append([])
            tmp_dict = SortedDict(zip(column_shield, one_shield))
            shield_dict['%s'%str(row[0])] = tmp_dict
        if info == '1':
            one_band.append(convert_unicode_to_str(row[2]))
            one_band.append(convert_unicode_to_str(row[3]))
            one_band.append(convert_unicode_to_str(row[4]))
            one_band.append(convert_unicode_to_str(row[5]))

            tmp_dict = SortedDict(zip(column_band, one_band))

            obj = shield_dict['%s'%str(row[0])]
            obj['band'].append(tmp_dict)

    ret_arr = []
    for key, value in shield_dict.iteritems():
        ret_arr.append(value)

    return  RestResponse(ret_arr)

#2-2
def get_shield_info(pRequest):
    opts = getOptionalParams(pRequest)

    if not type_range_check_for_table(opts=opts, param_name='dns_prefix', type='str', max_len=8, required=False):
        return RestResponse({'details':"dns_prefix is required"})

    if not type_range_check_for_table(opts=opts, param_name='service_id', type='int', required=False):
        return  RestResponse({'details':"service_id is required in int"})

    if not type_range_check_for_table(opts=opts, param_name='shield_id', type='int', required=False):
        return  RestResponse({'details':"shield_id is required in int"})

    if opts.has_key('info') and not opts.get('info') in ['1', '0']:
        return  RestResponse({'details':"info type is required"})

    info = opts.get('info') if opts.get('info') != None else 0 

    column_band = ['band_id', 'band_name', 'cache_level', 'group_num', 'order_num']
    if info == '1':
        column_shield = ['shielded_id', 'shielded_name', 'band']
    else:
        column_shield = ['shielded_id', 'shielded_name']

    sql = " select distinct A.id, A.name, C.id, C.name, B.cache_level, B.group_num, B.order_num from "
    sql += " shielded_service A "
    sql += " inner join shielded_service_band B on A.id = B.shielded_service_id "
    sql += " inner join band C on B.band_id = C.id "
    sql += " inner join cdn_service D on A.cdn_service_id = D.CDN_SERVICE_ID "
    sql += " where 1 = 1 "

    if opts.has_key('shield_id'):
        sql += " and A.id = '%s'"%opts.get('shield_id')

    if opts.has_key('service_id'):
        sql += " and A.cdn_service_id = '%s'"%opts.get('service_id')    

    if opts.has_key('dns_prefix'):
        sql += " and D.DNS_PREFIX = '%s'"%opts.get('dns_prefix')    
    
    ret = processQuery(sql, mysql_params=MySQL_CHARTRON_DB, returnRows=True, isFailOver2Default=True)
    
    if len(ret) == 0:
        return  RestResponse({'details':"no data"})

    shield_dict = {}
    for row in ret:
        one_shield = []
        one_band = []
        if not shield_dict.has_key('%s'%str(row[0])):
            one_shield.append(str(row[0]))
            one_shield.append(convert_unicode_to_str(row[1]))
            if info == '1':
                one_shield.append([])
            tmp_dict = SortedDict(zip(column_shield, one_shield))
            shield_dict['%s'%str(row[0])] = tmp_dict
        if info == '1':
            one_band.append(convert_unicode_to_str(row[2]))
            one_band.append(convert_unicode_to_str(row[3]))
            one_band.append(convert_unicode_to_str(row[4]))
            one_band.append(convert_unicode_to_str(row[5]))
            one_band.append(convert_unicode_to_str(row[6]))
            tmp_dict = SortedDict(zip(column_band, one_band))        

            obj = shield_dict['%s'%str(row[0])]
            obj['band'].append(tmp_dict)

    ret_arr = []
    for key, value in shield_dict.iteritems():
        ret_arr.append(value)

    return  RestResponse(ret_arr)

#2-3
def get_band_vip(pRequest):
    opts = getOptionalParams(pRequest)

    if not type_range_check_for_table(opts=opts, param_name='band_id', type='int', required=True):
        return RestResponse({'details':"band_id is required"})

    column = ['host_id', 'host_name', 'ipv4_address', 'vips', 'broken', 'offline', 'failing']

    sql = " select distinct D.NODE_ID, D.HOSTNAME, D.IPV4_ADDRESS, C.ipv4_address vips, D.broken, D.OFFLINE, "

    sql += " CASE WHEN D.OFFLINE = 1 THEN "
    sql += "    0 " # -- not fail
    sql += " ELSE "
    sql += "    CASE WHEN U.failed = 0 THEN "
    sql += "        CASE WHEN TIMEDIFF(NOW(),update_time) > '00:10:00' THEN "
    sql += "            -1 " # -- unkonwn fail 
    sql += "        ELSE "
    sql += "            0 " # -- not fail
    sql += "        END "
    sql += "    ELSE "
    sql += "            ifnull(U.failed,-2) " 
    sql += "    END "
    sql += " END failed_oui_case, C.seq_num, C.description "


    sql += " from band A "
    sql += " inner join band_node B on A.id = B.band_id "
    sql += " inner join node_ip C on B.node_ip_id = C.id "
    sql += " inner join node D on C.node_id = D.NODE_ID "
    sql += " left outer join nodestat U on U.node_id = D.NODE_ID "
    sql += " where A.id = %s "%opts.get('band_id')


    ret = processQuery(sql, mysql_params=MySQL_CHARTRON_DB, returnRows=True, isFailOver2Default=True)

    if len(ret) == 0:
        return  RestResponse({'details':"no data"})

    host_dict = {}
    for row in ret:
        one_host = []
        if not host_dict.has_key('%s'%str(row[0])):
            one_host.append(str(row[0]))
            one_host.append(convert_unicode_to_str(row[1]))
            one_host.append(convert_unicode_to_str(row[2]))
            one_host.append([])
            one_host.append(convert_unicode_to_str(row[4]))
            one_host.append(convert_unicode_to_str(row[5]))
            one_host.append(convert_unicode_to_str(row[6]))
            tmp_dict = SortedDict(zip(column, one_host))
            host_dict['%s'%str(row[0])] = tmp_dict

        obj = host_dict['%s'%str(row[0])]
        obj['vips'].append((convert_unicode_to_str(row[3]), convert_unicode_to_str(row[7]), convert_unicode_to_str(row[8])))

    ret_arr = []
    for key, value in host_dict.iteritems():
        ret_arr.append(value)

    return  RestResponse(ret_arr)


def isDigitCheck(value):
    ret = True
    try:
        val = int(value)
    except:
        ret = False
    return ret


def type_range_check_for_table(opts, param_name, type, max_len=0, required=False, range_values=[]):
    ret = True
    if not opts.has_key(param_name):
        if required == True:
            ret = False
    else:
        if type == 'int':
            if not isDigitCheck(opts.get(param_name)) or int(opts.get(param_name)) > 2147483647 or int(opts.get(param_name)) < -2147483648:
                ret = False
        elif type == 'smallint':
            if not isDigitCheck(opts.get(param_name)) or int(opts.get(param_name)) > 32767 or int(opts.get(param_name)) < -32768:
                ret = False
        elif type == 'str':
            if len(opts.get(param_name)) > max_len:
                ret = False
        elif type == 'match':
            if not opts.get(param_name) in range_values:
                ret = False
        elif type == 'ipaddress':
            from ci.common.utils.ipaddr import IPAddress
            try:
                IPAddress(opts.get(param_name))
            except:
                ret = False

    return ret

#2-4
def get_pop_vip(pRequest):
    opts = getOptionalParams(pRequest)

    if not type_range_check_for_table(opts=opts, param_name='pop_id', type='smallint', required=True):
        return RestResponse({'details':"pop_id is required"})

    column = ['host_id', 'host_name', 'ipv4_address', 'vips', 'broken', 'offline', 'failing']
    
    sql = " select distinct D.NODE_ID, D.HOSTNAME, D.IPV4_ADDRESS, C.ipv4_address vips, D.broken, D.OFFLINE, "

    sql += " CASE WHEN D.OFFLINE = 1 THEN "
    sql += "    0 " # -- not fail
    sql += " ELSE "
    sql += "    CASE WHEN U.failed = 0 THEN "
    sql += "        CASE WHEN TIMEDIFF(NOW(),update_time) > '00:10:00' THEN "
    sql += "            -1 " # -- unkonwn fail
    sql += "        ELSE "
    sql += "            0 " # -- not fail
    sql += "        END "
    sql += "    ELSE "
    sql += "            ifnull(U.failed,-2) "
    sql += "    END "
    sql += " END failed_oui_case, C.seq_num, C.description "

    sql += " from node_ip C "
    sql += " inner join node D on C.node_id = D.NODE_ID "
    sql += " left outer join nodestat U on U.node_id = D.NODE_ID "
    sql += " where D.POP_ID = %s "%opts.get('pop_id')

    ret = processQuery(sql, mysql_params=MySQL_CHARTRON_DB, returnRows=True, isFailOver2Default=True)
    
    if len(ret) == 0:
        return  RestResponse({'details':"no data"})
        
    host_dict = {}
    for row in ret:
        one_host = []
        if not host_dict.has_key('%s'%str(row[0])):
            one_host.append(str(row[0]))
            one_host.append(convert_unicode_to_str(row[1]))
            one_host.append(convert_unicode_to_str(row[2]))
            one_host.append([])
            one_host.append(convert_unicode_to_str(row[4]))
            one_host.append(convert_unicode_to_str(row[5]))
            one_host.append(convert_unicode_to_str(row[6]))
            tmp_dict = SortedDict(zip(column, one_host))
            host_dict['%s'%str(row[0])] = tmp_dict

        obj = host_dict['%s'%str(row[0])]
        obj['vips'].append((convert_unicode_to_str(row[3]), convert_unicode_to_str(row[7]), convert_unicode_to_str(row[8])))

    ret_arr = []
    for key, value in host_dict.iteritems():
        ret_arr.append(value)

    return  RestResponse(ret_arr)


def get_vip_customer(pRequest):
    opts = getOptionalParams(pRequest)

    opts_set = set(opts)
    required_params = set(('ip_address',))
    missing = required_params.difference(opts_set)
    if missing:
        raise APIException("The following params are required: %s" % ", ".join(missing))
    if not type_range_check_for_table(opts=opts, param_name='ip_address', type='ipaddress', required=True):
        return RestResponse({'details':"valid ip address is required"})

    column = ['domain', 'site_id', 'customer', 'customer_id']

    sql = " select distinct E.SERVE_DOMAIN, E.CUSTOMER_SITE_ID, F.NAME, F.customer_id from  node_ip A "
    sql += " inner join band_node B on A.id = B.node_ip_id "
    sql += " inner join cdndomain_band C on B.band_id = C.band_id "
    sql += " inner join customer_site E on C.CDN_SERVICE_ID = E.cdn_service_id "
    sql += " inner join customer F on E.CUSTOMER_ID = F.CUSTOMER_ID "
    sql += " where ipv4_address = '%s' "%opts.get('ip_address')
    sql += " union "
    sql += " select distinct E.SERVE_DOMAIN, E.CUSTOMER_SITE_ID, F.NAME, F.customer_id from  node_ip A "
    sql += " inner join band_node B on A.id = B.node_ip_id "
    sql += " inner join shielded_service_band C on B.band_id = C.band_id "
    sql += " inner join customer_site E on C.shielded_service_id = E.shielded_service_id "
    sql += " inner join customer F on E.CUSTOMER_ID = F.CUSTOMER_ID "
    sql += " where ipv4_address = '%s'; "%opts.get('ip_address')

    ret = processQuery(sql, mysql_params=MySQL_CHARTRON_DB, returnRows=True, isFailOver2Default=True)

    if len(ret) == 0:
        return  RestResponse({'details':"no data"})

    ret_arr = []
    for row in ret:
        row_one = []
        for col in row:
            row_one.append(convert_unicode_to_str(col))

        tmp_dict = SortedDict(zip(column, row_one))
        ret_arr.append(tmp_dict)

    return  RestResponse(ret_arr)



def get_pop_info(qRequest):
    opts = getOptionalParams(qRequest)

    opts_set = set(opts)
    required_params = set(('pop_id',))
    missing = required_params.difference(opts_set)
    if missing:
        raise APIException("The following params are required: %s" % ", ".join(missing))
    if not type_range_check_for_table(opts=opts, param_name='pop_id', type='int', required=True):
        return RestResponse({'details':"valid pop id is required"})

    column = ['POP_ID',
              'MAX_MBPS',
              'LOAD_ADJUSTMENT',
              'lb_max_lal',
              'lb_min_lal',
              'lb_up_lal',
              'lb_down_lal',
              'lb_up_exp',
              'lb_down_exp',
              'lb_cushion',
              'lb_update_interval_sec',
              'ms_per_mbps',
              'ms_per_rps',
              'ms_per_ops',
              'ms_per_disk_iops',
              'ms_per_disk_await',
              'ms_per_load_avg_1',
              'error_margin',
              'error_decay',
              'loop_period_sec',
              'proportional_gain',
              'integral_time_div',
              'derivative_time_mul'
              ]
    sql = """
        select
        `pop`.`POP_ID`,
        `pop_load_limit`.`MAX_MBPS`,
        `pop_load_limit`.`LOAD_ADJUSTMENT`,
        `pop_load_limit`.`lb_max_lal`,
        `pop_load_limit`.`lb_min_lal`,
        `pop_load_limit`.`lb_up_lal`,
        `pop_load_limit`.`lb_down_lal`,
        `pop_load_limit`.`lb_up_exp`,
        `pop_load_limit`.`lb_down_exp`,
        `pop_load_limit`.`lb_cushion`,
        `pop_load_limit`.`lb_update_interval_sec`,
        `pop_load_limit`.`ms_per_mbps`,
        `pop_load_limit`.`ms_per_rps`,
        `pop_load_limit`.`ms_per_ops`,
        `pop_load_limit`.`ms_per_disk_iops`,
        `pop_load_limit`.`ms_per_disk_await`,
        `pop_load_limit`.`ms_per_load_avg_1`,
        `pop_load_limit`.`error_margin`,
        `pop_load_limit`.`error_decay`,
        `pop_load_limit`.`loop_period_sec`,
        `pop_load_limit`.`proportional_gain`,
        `pop_load_limit`.`integral_time_div`,
        `pop_load_limit`.`derivative_time_mul`
        from `pop` inner join `pop_load_limit` on `pop`.`pop_id`= `pop_load_limit`.`pop_id`
        where `pop`.`POP_ID` = %s ;
    """%opts.get('pop_id')

    ret = processQuery(sql, mysql_params=MySQL_CHARTRON_DB, returnRows=True, isFailOver2Default=True)

    if len(ret) == 0:
        return  RestResponse({'details':"no data"})

    ret_arr = []
    for row in ret:
        row_one = []
        for col in row:
            row_one.append(convert_unicode_to_str(col))

        tmp_dict = SortedDict(zip(column, row_one))
        ret_arr.append(tmp_dict)

    sql = """
        select
        `pop`.`pop_id`,
        `pop`.`short_name`,
        `pop_network_distance`.`distance`,
        `pop_network_distance`.`cost`
        from `pop_network_distance` inner join `pop` on `pop_network_distance`.`pop2_id` = `pop`.`pop_id`
        where `pop1_id` = %s ;
    """%opts.get('pop_id')

    ret = processQuery(sql, mysql_params=MySQL_CHARTRON_DB, returnRows=True, isFailOver2Default=True)

    arr_dist = []
    for row in ret:
        arr_dist.append({'pop_id':row[0],'short_name':row[1],'distance':row[2]})
    ret_arr[0]['distances'] = arr_dist
    return RestResponse(ret_arr)


def get_pops_in_service(pRequest):
    column = ['pop_id', 'xname', 'short_name', 'offline', 'description']

    sql = """
        select `pop_id`, `xname`, `short_name`, `offline`, `description`
        from `pop`
        where `pop`.`pop_id` in
        (select distinct `node`.`pop_id`
        from `cdndomain_band`
        inner join `band_node` on `cdndomain_band`.`band_id` = `band_node`.`band_id`
        inner join `node` on `node`.`node_id` = `band_node`.`node_id`); """

    ret = processQuery(sql, mysql_params=MySQL_CHARTRON_DB, returnRows=True, isFailOver2Default=True)

    if len(ret) == 0:
        return  RestResponse({'details':"no data"})

    ret_arr = []
    for row in ret:
        row_one = []
        for col in row:
            row_one.append(convert_unicode_to_str(col))

        tmp_dict = SortedDict(zip(column, row_one))
        ret_arr.append(tmp_dict)

    return  RestResponse(ret_arr)
