from django.contrib.auth.decorators import user_passes_test
from ci.common.models.cdn import Node
from ci.common.utils.api import APIException
from ci.common.forms.node import ChangeHashPointsForm
from api.rapi.utils import getOptionalParams, RestResponse

@user_passes_test(lambda u:u.has_perm('oui.edit_node'))
def hashpoint_modify(pRequest):
	ncpf = get_hashpoint_form(pRequest)
	if isinstance(ncpf,RestResponse):
		return ncpf
	elif isinstance(ncpf,ChangeHashPointsForm):
		changes = ncpf.change_hashpoints()
		resp = []
		for node, diffs in changes.iteritems():
			adds = []
			for add in diffs[0]:
				adds.append({'hashpoint': add.hashpoint, 'join_time': add.join_time})
			dels = []
			for rem in diffs[1]:
				dels.append({'hashpoint': rem.hashpoint})
			resp.append({'node': node.hostname, 'added': adds, 'deleted': dels})
		return RestResponse(resp, error = {})
	return RestResponse({},error = {'general': "Unknown error"}, status=400)


@user_passes_test(lambda u:u.has_perm('oui.edit_node'))
def hashpoint_preview(pRequest):
	ncpf = get_hashpoint_form(pRequest)
	if isinstance(ncpf,RestResponse):
		return ncpf
	elif isinstance(ncpf,ChangeHashPointsForm):
		changes = ncpf.get_affected_counts()
		resp = []
		for node, change in changes.iteritems():
			resp.append({'node': node.hostname, 'change': change})
		return RestResponse(resp, error = {})
	return RestResponse({},error = {'general': "Unknown error"}, status=400)

def get_hashpoint_form(pRequest):
	opts = getOptionalParams(pRequest)
	opts_set = set(opts)
	available_fields = ChangeHashPointsForm.base_fields.keys()
	#target and type get translated by api...
	available_fields.remove('nodes')
	available_fields.append('node')
	invalid_opts = opts_set.difference(available_fields)
	if len(invalid_opts) > 0:
		raise APIException("Invalid parameters in request: " + ", ".join(invalid_opts))
	nodes = opts.getlist('node')
	opts.pop('node')
	errors = {}
	for node in nodes:
		try:
			n = Node.objects.get(hostname=node)
			opts.update({'nodes':n.id})
		except:
			errors['node'] = "Invalid target: " + node
			break
	ncpf = ChangeHashPointsForm(opts)
	if len(errors) == 0 and ncpf.is_valid():
		return ncpf
	elif len(errors) == 0:
		replace_errors = {'nodes':'node'}
		for item, value in ncpf.errors.items():
			if item == "__all__":
				item = "general"
			errors[replace_errors.get(item,item)] = value.as_text()
	return RestResponse({},error = errors, status=400)
