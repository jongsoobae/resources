from datetime import datetime
from django.http import HttpResponseNotFound
from api.rapi.utils import RestResponse, popAndFilter, getOptionalParams
from ci.common.utils.api import get_object_or_api_exception, values_replace_choice
from ci.common.models.customer import SSLKeystore
from ci.common.models.cdn import Service

def keystore_list(pRequest):
	error = {}
	keystore = SSLKeystore.objects.filter(upload_successful=True)
	opt_params = getOptionalParams(pRequest)
	if opt_params.has_key('info') and opt_params.pop('info') == [u"1"]:
		keystore = keystore.values()
		for k in keystore:
			k['services'] = []
			for s in Service.objects.filter(ssl_cert = k['keystore_id']):
				k['services'].append(s.id)
	else:
		keystore = keystore.values('keystore_id','domain')
	keystore = values_replace_choice(keystore, SSLKeystore)
	return RestResponse(keystore, error = error)

def keystore_view(pRequest, id):
	error = {}
	opt_params = getOptionalParams(pRequest)
	keystore =get_object_or_api_exception(SSLKeystore,keystore_id=id, as_query=True).values()
	keystore = values_replace_choice(keystore, SSLKeystore)
	keystore[0]['services'] = []
	for s in Service.objects.filter(ssl_cert = keystore[0]['keystore_id']):
		keystore[0]['services'].append(s.id)
	if len(opt_params) > 0:
		error['unknown_parameter(s)'] = "The following parameters were not handled: " + opt_params.urlencode()
	return RestResponse(keystore[0], error = error)
	
