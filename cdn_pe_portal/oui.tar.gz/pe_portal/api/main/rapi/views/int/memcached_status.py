from django import http
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse, HttpResponseServerError
from django.utils import simplejson
from django.core.cache import get_cache
from api.rapi.utils import RestResponse, getOptionalParams

@csrf_exempt
def memcached_status(request):
    try:
        import memcache
    except ImportError:
        raise http.Http404

    cache_stats = []
    error = {}
    for cache_backend_nm, cache_backend_attrs in settings.CACHES.iteritems():
        try:
            cache_backend = get_cache(cache_backend_nm)
            this_backend_stats = cache_backend._cache.get_stats()
            # returns list of (name, stats) tuples
            for server_name, server_stats in this_backend_stats:
                load_rate = float(server_stats['bytes'])/float(server_stats['limit_maxbytes']) * 100
                server_stats.update({'load':str(load_rate)})
                cache_stats.append(("%s: %s" % (
                    cache_backend_nm, server_name), server_stats))
        except AttributeError: # this backend probably doesn't support that
            continue
    if len(cache_stats) > 0:
        pass
    else:
        error = {'general': 'no cache stats available'}
    return RestResponse(cache_stats, error=error)

