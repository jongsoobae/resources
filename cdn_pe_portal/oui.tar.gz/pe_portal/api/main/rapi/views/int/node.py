from datetime import datetime
from ci.common.models.cdn import Node, NodeIP, NodeLoadLimit
from ci.common.models.legacy_shield import CacheFragment
from ci.common.models.cache import NodeHashpoint
from ci.common.utils.api import get_object_or_api_exception, values_replace_choice, \
	APIException, get_object_or_api_exception, create_api_modelform
from ci.common.forms.node import NodeForm
from api.rapi.utils import RestResponse, popAndFilter, getOptionalParams
from api.rapi.utils.core import add_or_edit

def node_add_or_edit(pRequest, name=None):
	"""REST interface for modifying an existing node or adding a new node
	If node_id == None then this is an add, otherwise it is an edit

	NOTE: This is not fully baked and is only partially done.  As such this is only to be used for add for now"""

	node = get_object_or_api_exception(Node, hostname=name, message='Invalid node hostname: ' + name) if name != None else None
	#blacklist anything that can modify node serving for now...
	saved_node, ret = add_or_edit(pRequest, NodeForm, node, description="node", blacklist=['offline','broken'], edit_blacklist=['pop','ipv4_address'])
	if node == None and saved_node:
		#this is add so need to create ip record 0 and default load limits...
		#should make this user settable but for now lets just set defaults.
		NodeIP(node=saved_node, seq_num=0, ipv4_address = saved_node.ipv4_address).save()
		NodeLoadLimit(node=saved_node, max_ops=2000, max_ips=2000, max_disk_iops=400, max_disk_avg_wait=160,
			max_load_avg_1 = 18, load_adjustment=0, max_mbps=800).save()
	return ret

def node_list(pRequest):
	node = None
	info = False
	error = {}
	opt_params = getOptionalParams(pRequest)
	if opt_params.has_key('info') and opt_params.pop('info') == [u"1"]:
		node = Node.objects.values()
		info = True
	else:
		node = Node.objects.values('id','hostname')
	node = popAndFilter(opt_params, node,'node','id__in', expectslist=True)
	node = popAndFilter(opt_params, node, 'pop','pop__id__in', expectslist=True)
	node = popAndFilter(opt_params, node, 'pop_name','pop__name__in', expectslist=True)
	node = popAndFilter(opt_params, node, 'pop_short_name','pop__short_name__in', expectslist=True)
	node = popAndFilter(opt_params, node, 'service_dns_prefix', 'band__service__dns_prefix__in', expectslist=True)
	node = popAndFilter(opt_params, node, 'service', 'band__service__id__in', expectslist=True)
	node = popAndFilter(opt_params, node, 'band', 'band__id__in',expectslist=True)
	node = popAndFilter(opt_params, node, 'band_name', 'band__name__in',expectslist=True)
	node = popAndFilter(opt_params, node, 'offline', 'offline')
	node = popAndFilter(opt_params, node, 'region','pop__region__id__in',expectslist=True)
	node = popAndFilter(opt_params, node, 'region_name','pop__region__name__in',expectslist=True)
	if opt_params.has_key('min_modify_date'):
		try:
			node = node.filter(modify_time__gt = \
			datetime.strptime(opt_params.pop('min_modify_date')[0][:19], \
			'%Y-%m-%d %H:%M:%S'))
		except:
			error['min_modify_date'] = "Invalid, date must be ISO format without timezone"
	if opt_params.has_key('http'):
		if opt_params.pop('http') == [u"1"]:
			node = node.filter(node_type__id__in =  [1,3])
	if opt_params.has_key('dns'):
		if opt_params.pop('dns') == [u"1"]:
			node = node.filter(node_type__id__in = [2,3])

	if len(opt_params) > 0:
		error['unknown_parameter(s)'] = "The following parameters were not handled: " + opt_params.urlencode()
			
	if info:
		bucket_nodes = set(list(CacheFragment.objects.values_list('node_id',flat=True)) + list(NodeHashpoint.objects.values_list('node_id',flat=True)))
		for n in node:
			n['dns'] = n['node_type_id'] > 1
			n['http'] = n['node_type_id'] <> 2
			try:
				n['name'] = n['hostname'][:n['hostname'].rindex('.',0,n['hostname'].rindex('.'))]
			except:
				n['name'] = n['hostname']
			if bucket_nodes.issuperset([n['id']]):
				n['buckets'] = True
			else:
				n['buckets'] = False
			n['vips'] = NodeIP.objects.filter(node=n['id']).values_list('ipv4_address',flat=True)
	return RestResponse(node, error = error)
