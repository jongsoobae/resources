import json
from django.views.decorators.csrf import csrf_exempt
from ci.common.utils.api.nodeip import NodeIpPairRegister, ValidationException, is_match_v4_v6, JsonResponse, \
    JSON_SCHEMA


@csrf_exempt
def register_ipv6(request):
    try:
        # parse and validate input
        if not request.POST:
            raise ValidationException('HTTP Method only allowd POST.', status=405)

        params = validate_parameters(get_json_data(request).copy())
        check_valid_pair(params['pair'])

        # do register
        results = NodeIpPairRegister(params['hostname'], params['pair']).do_register()

        return JsonResponse(results, status=200)
    except ValidationException, e:
        return JsonResponse('', status=e.status_code, error=e.message)
    except Exception, ee:
        return JsonResponse('', status=500, error=ee.message)


@csrf_exempt
def delete_ipv6(request):
    try:
        # parse and validate input
        if not request.POST:
            raise ValidationException('HTTP Method only allowd POST.', status=405)

        params = validate_parameters(get_json_data(request).copy())
        check_valid_pair(params['pair'])

        # do delete
        results = NodeIpPairRegister(params['hostname'], params['pair']).do_delete()

        return JsonResponse(results, status=200)
    except ValidationException, e:
        return JsonResponse('', status=e.status_code, error=e.message)
    except Exception, ee:
        return JsonResponse('', status=500, error=ee.message)


@csrf_exempt
def list_ipv6(request):
    try:
        # parse and validate input
        params = get_json_data(request)

        if type(params) != dict or 'hostname' not in params:
            raise ValidationException('hostname is required.')

        results = [
            (
                node_ip.ipv4_address,
                node_ip.get_v6_node_ip_by_seq().ipv4_address if node_ip.get_v6_node_ip_by_seq() else ''
            )
            for node_ip in NodeIpPairRegister(params['hostname'], '').node_ip_list
        ]

        return JsonResponse(results, status=200)
    except ValidationException, e:
        return JsonResponse('', status=e.status_code, error=e.message)
    except Exception, ee:
        return JsonResponse('', status=500, error=ee.message)


def get_json_data(request):
    try:
        return json.loads(request.raw_post_data)
    except Exception:
        raise ValidationException('Need valid json type.')


def validate_parameters(json_data):
    from jsonschema import validate
    from jsonschema import ValidationError
    try:
        validate(json_data, JSON_SCHEMA)
    except ValidationError, e:
        raise ValidationException(_get_json_schema_error_message(e))

    return json_data


def _get_json_schema_error_message(e):
    try:
        if e.validator != 'pattern':
            return e.message

        pattern_what = ''
        if e.schema_path[3] == 0:
            pattern_what = 'ipv4'
        elif e.schema_path[3] == 1:
            pattern_what = 'ipv6'

        if 'does not match' in e.message and pattern_what:
            return '%sis not valid %s pattern.' % (e.message[0:e.message.index('does not match')], pattern_what)

    except (IndexError, Exception, ):
        return e.message


def check_valid_pair(pair):
    v4, v6 = pair
    if not is_match_v4_v6(v4, v6):
        raise ValidationException('IP Pair %s , %s is not matched.' % (v4, v6))
