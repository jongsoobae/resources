from api.rapi.utils import RestResponse, popAndFilter, getOptionalParams
from django.contrib.auth.models import User as AuthUser
from ci.common.utils.throttling import UserRateThrottle, AnonRateThrottle, AnonymousUsernameThrottle
from ci.common.utils.util_common import log_info

def lift_login_block(request, username):
    errors = {}
    try:
        result = AnonymousUsernameThrottle.invalidate_cache(username, 'anon_username')
        if result:
            log_info("lifted login blocking for user:%s" % username)
    except Exception,e:
        errors.update({'error': str(e)})
        return RestResponse({},error = errors, status=500)

    return RestResponse({},error = errors, status=200)