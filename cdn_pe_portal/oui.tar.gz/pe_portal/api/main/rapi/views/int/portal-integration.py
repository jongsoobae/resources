from random import randrange 
import time
from ci.common.models import AuthUser, LongUser
from ci.common.models.site import SiteDraft
from ci.common.models.customer import Customer
from ci.common.forms.user import UserForm, get_privilege_form
from ci.common.utils.api import get_object_or_api_exception, APIException, create_api_modelform
from api.rapi.utils import RestResponse, getOptionalParams

def user_deactivate(pRequest, user_id):
    """REST interface to allow OCSP/COP to easily deactivate panther users"""
    user = get_object_or_api_exception(AuthUser, id=user_id, message='Invalid user id: ' + user_id)
    if not user.is_active:
        raise APIException("User is already inactive")
    user.is_active=False
    user.username=str(time.time()) + "-" + user.username
    user.save()
    return RestResponse({'details': "User has been deactivated."}, error = {})

def user_add_or_edit(pRequest, user_id, cop=False):
    """REST interface to have OCSP/COP create and update panther users
    If user_id == None then this is and add, otherwise it is an edit"""
    opts = getOptionalParams(pRequest)
    opts_set = set(opts)
    user = get_object_or_api_exception(LongUser, id=user_id, message='Invalid user id: ' + user_id) if user_id != None else None
    available_fields = set(('email','edit_pad_perm','restrict_pads','allowed_pads', 'is_active'))
    required_fields = set(('email', 'customer_id'))
    priv_fields = set(('allowed_pads','customer_id','edit_pad_perm'))
    if cop:
        available_fields = available_fields.union(set(('first_name', 'last_name')))
        required_fields = required_fields.union(set(('first_name', 'last_name')))
    customer_id = -1
    if user == None:
        #This is an add so there is a minimum set of fields that must be set!
        missing_opts = required_fields.difference(opts_set)
        if len(missing_opts) > 0:
            raise APIException("Following parameters are required to add an ocsp user: " + ", ".join(missing_opts))
        customer_id = opts.pop('customer_id')[0]
        cust = get_object_or_api_exception(Customer, id=customer_id, message="Invalid customer id: " + customer_id)
        available_fields = available_fields.union(required_fields)
    else:
        cust = user.get_profile().customer
    invalid_opts = opts_set.difference(available_fields)
    if len(invalid_opts) > 0:
        raise APIException("Invalid parameters in request: " + ", ".join(invalid_opts))
    vals=dict(opts)
    pvals={}
    for key, val in vals.items():
        if isinstance(val,list) and len(val) == 1:
            vals[key] = val[0]
    #move vals to pvals...
    for move_field in priv_fields:
        if vals.get(move_field):
            pvals[move_field] = vals.pop(move_field)

    def randchar():
        return chr(randrange(65,122,1))
    if user == None: #initial form settings...
        vals['password'] = randchar() + randchar() + randchar() + randchar() + randchar() + randchar() + randchar()
        vals['password_check'] = vals['password']
        vals['username'] = vals['email']
        if cop:
            vals['first_name'] = vals['first_name']
            vals['last_name'] = vals['last_name']
        else:
            vals['first_name'] = vals['email'].split("@")[0][0:30]
            vals['last_name'] = "OCSP CREATED"
        pvals['password_reset'] = 0
        pvals['support_perm'] = 0
    else:
        vals['username'] = user.username
    pvals['add_to_ocsp'] = 'No'
    
    uform = create_api_modelform(UserForm, vals)
    uform = uform(data=vals, instance=user)

    if pvals.has_key('allowed_pads') and len(pvals['allowed_pads']) > 0:
        #needs to be string cause that how form class works...
        pvals['draft_whitelist'] = map(str,SiteDraft.objects.filter(site__id__in = pvals['allowed_pads'].split(",")).values_list('id', flat=True))
        
    pform = create_api_modelform(get_privilege_form(pRequest, oui=True, user=user, customer_id=customer_id if user == None else None),pvals)
    pform = pform(data=pvals, instance=user.get_profile() if user else None)

    errors = {}
    if uform.is_valid() and pform.is_valid():
        #to save....
        saved_user = uform.save(commit=False)
        saved_user.save()
        uform.save_m2m()
        profile = pform.save(commit=False)
        base_user = AuthUser.objects.get(pk=saved_user.id)
        if not user:
            profile.user = base_user
        profile.save()
        pform.save_m2m()
        if user == None: #added instead of edited
            return RestResponse({'details': "User has been created", 'id': saved_user.id}, error = errors)
        return RestResponse({'details': "User changes have been applied"}, error = errors)

    for form in [uform, pform]:
        if not form.is_valid():
            for item, value in form.errors.items():
                if item == "__all__":
                    item = "general"
            errors[item] = value.as_text()
    return RestResponse({},error = errors, status=400)
