from django import forms
from django.core.cache import cache
from api.rapi.utils.core import add_or_edit
from api.rapi.utils import RestResponse, getOptionalParams
from ci.common.utils.util_api import get_cs_contract_info
from ci.common.models.customer import Product
from ci.common.utils.api import get_object_or_api_exception, values_replace_choice, \
        APIException, create_api_modelform

def product_add_or_edit(pRequest, cop_product_id=None):
    """REST interface for modifying an existing product or adding a new product
    If cop_product_id == None then this is an add, otherwise it is an edit"""

    class ProductForm(forms.ModelForm):
        class Meta:
            model = Product
    product = get_object_or_api_exception(Product, cop_product_id=cop_product_id, message='Invalid product id: ' + cop_product_id) if cop_product_id != None else None
    return add_or_edit(pRequest, ProductForm, product, description="product", pk="product_id", edit_blacklist="customer")[1]


def product_list(pRequest):
    error = {}
    opt_params = getOptionalParams(pRequest)
    products = Product.objects.select_related('customer__name','customer__using_private_certs').filter(active=True)

    cs_contracts = get_cs_contract_info()

    cache_key = 'product_list_papi'
    product_lists = cache.get(cache_key)
    if product_lists is None:
        product_lists = []
        for product in products:
            try:
                cs_contract = cs_contracts.get(product.cop_product_id)
                if cs_contract is not None:
                    display_name = product.get_customer_ui_name(cs_contract)
                    product_dicts = {}
                    product_dicts.update({'product_id': product.pk})
                    product_dicts.update({'customer_id': product.customer_id})
                    product_dicts.update({'customer': product.customer.name})
                    product_dicts.update({'customer_using_private_certs': product.customer.using_private_certs})
                    product_dicts.update({'display_name': display_name})
                    product_dicts.update({'allow_add_flag': product.allow_add_pad_flag})
                    product_dicts.update({'material_no': product.product_cd})
                    edge = product.get_default_edge_service_for_production(cs_contract)
                    product_dicts.update({'mapped_service_edge': "%s - %s" % (edge.dns_prefix,edge.name) if edge else ''})
                    product_dicts.update({'contract_info': product.get_contract_info_name()})
                    if product.is_dwa_contract():
                        product_dicts.update({'shield_locations': product.get_available_shield_locations(cs_contract)})
                    product_lists.append(product_dicts)
            except Exception, e:
                pass
        cache.set(cache_key, product_lists, 60*10)

    return RestResponse(product_lists)

def product_view(pRequest,cop_product_id=None):
    """
    Default: do not apply cache since this is debug call
    :param pRequest:
    :param cop_product_id:
    :return:
    """
    from api.rapi.views.contract import padded_cop_product_id
    error = {}
    opt_params = getOptionalParams(pRequest)
    apply_cache = opt_params.get('apply_cache', False)
    if apply_cache in ['True','1']:
        apply_cache = True
    else:
        apply_cache = False

    try:
        padded_cop_product_id = padded_cop_product_id(cop_product_id)
        products =get_object_or_api_exception(Product,cop_product_id=padded_cop_product_id, as_query=True)

        product_dicts = values_replace_choice(products.values(), Product)
        i=0
        product = {}
        cs_contracts = get_cs_contract_info(products[i].get_contract_no(), apply_cache)
        try:
            cs_contract = cs_contracts.get(padded_cop_product_id)
        except:
            cs_contract = None
        product.update({'fetched_info_from_prism':cs_contract})
        product.update({'product_info':product_dicts})
        product.update({'product_id': products[i].pk})
        product.update({'customer_id': products[i].customer_id})
        product.update({'customer_using_private_certs': products[i].customer.using_private_certs})
        product.update({'material_no': products[i].product_cd})
        product.update({'contract_info': products[i].get_contract_info_name(cs_contract)})
        product.update({'display_name': products[i].get_customer_ui_name(cs_contract)})
        edge = products[i].get_default_edge_service_for_production(cs_contract)
        product.update({'mapped_service_edge': "%s - %s" % (edge.dns_prefix,edge.name) if edge else ''})
        product.update({'contract_region': products[i].get_contract_region(cs_contract)})
        if products[i].is_dwa_contract():
            product.update({'available_shield_locations': products[i].get_available_shield_locations(cs_contract)})
        product.update({'self_implementable': products[i].is_self_implementable(cs_contract)})
    except Exception,e:
        error.update({'general': str(e)})


    #if len(opt_params) > 0:
    #    error['unknown_parameter(s)'] = "The following parameters were not handled: " + opt_params.urlencode()
    return RestResponse(product, error = error)