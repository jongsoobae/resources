import json
from django.contrib.auth.decorators import user_passes_test
from ci.common.models.cdn import Node
from ci.common.utils.api import APIException
from ci.common.forms.push import PushRequestForm
from api.rapi.utils import getOptionalParams, RestResponse
from ci.common.utils.api import get_draft_or_api_exception
from ci.common.utils.api.site import get_push_history
from ci.common.models.pusher import ConfigPushRequestHistory

@user_passes_test(lambda u:u.has_perm('oui.add_pushrequestjson'))
def push_add(pRequest, pad=None):
    opts = getOptionalParams(pRequest)
    opts_set = set(opts)
    available_fields = PushRequestForm.base_fields.keys()
    #target and type get translated by api...
    available_fields.remove('targets')
    available_fields.remove('types')
    available_fields.append('target')
    available_fields.append('type')
    invalid_opts = opts_set.difference(available_fields)
    targets = opts.getlist('target')
    opts.pop('target')
    errors = {}
    if len(targets) == 1 and targets[0] == 'all':
        opts.update({'target_type':'default'})
    elif len(targets) == 0:
        errors['target'] = "Must supply at least 1 target or 'all'"
    else:
        opts.update({'target_type':'pick'})
        for target in targets:
            try:
                n = Node.objects.get(hostname=target)
                opts.update({'targets':n.id})
            except:
                errors['target'] = "Invalid target: " + target
                break
    #simple rename...
    for type in opts.pop('type'):
        opts.update({'types':type})
    if len(errors) == 0:
        p=PushRequestForm(opts, user=pRequest.user)
    else:
        p=None
    if len(invalid_opts) > 0:
        raise APIException("Invalid parameters in request: " + ", ".join(invalid_opts))
    if len(errors) == 0 and p and p.is_valid():
        if p.do_push():
            return RestResponse({'details': "Push request has been submitted"}, error = errors)
        else:
            errors['general'] =  "Unknown error occurred in submitting push"
    else:
        replace_errors = {'targets':'target','types':'type'}
        if p and p.errors:
            for item, value in p.errors.items():
                if item == "__all__":
                    item = "general"
                errors[replace_errors.get(item,item)] = value.as_text()
    return RestResponse({},error = errors, status=400)


def push_history(pRequest,pad=None):
    """
    for debugging purpose, get all push history
    :param pRequest:
    :param pad:
    :return:
    """
    opts = getOptionalParams(pRequest)
    #opts = remove_params_for_aurora(opts)
    if pad is not None:
        draft = get_draft_or_api_exception(pRequest,pad)
    else:
        draft = None

    resp,errors = get_push_history(None,None,draft)
    return RestResponse({'details': resp}, error=errors)

def push_details(pRequest):
    resp = []
    errors = {}
    opts = getOptionalParams(pRequest)
    action_id = opts.get('action_id', None)
    if not action_id:
        return RestResponse(resp, error= 'action_id input missing.', status=400)
    push_requests = ConfigPushRequestHistory.objects.filter(action=action_id)
    if push_requests.exists():
        for push_request in push_requests:
            try:
                site_draft = push_request.site_draft
            except:
                site_draft = None
            resp.append({'action_id':action_id,
                         'draft_pk': str(push_request.get_site_cui_id()),
                         'draft_details': site_draft.get_deploy_status_dict(is_for_customer=False) if site_draft else '',
                         'config_phase': push_request.get_config_phase(),
                         'request_id': push_request.pk,
                         'request_user': push_request.request_user,
                         'request_desc': push_request.desc,
                         'create_time': push_request.create_time,
                         'result_from_config_api':push_request.get_valid_push_result_item()})
    else:
        from ci.common.utils.pusher import ConfigApi
        config_api = ConfigApi()
        result = config_api._config_api_push_progress([action_id])
        push_history_items = json.loads(result)
        parent_joint_action_id = push_history_items.get(action_id).get('parent_joint_action_id',None)
        draft_details = None
        push_request = None

        if parent_joint_action_id:
            push_requests = ConfigPushRequestHistory.objects.filter(action=parent_joint_action_id)
            if push_requests.exists():
                try:
                    push_request = push_requests[0]
                    site_draft = push_requests[0].site_draft
                except:
                    site_draft = None
                draft_details = site_draft.get_deploy_status_dict(is_for_customer=False) if site_draft else {},

        resp.append({'action_id':action_id,
                     'draft_pk': str(push_request.get_site_cui_id()) if push_request else '',
                     'draft_details': draft_details,
                     'config_phase': push_request.get_config_phase() if push_request else '',
                     'request_id':push_request.pk if push_request else '',
                     'request_user': push_request.request_user if push_request else '',
                     'request_desc': push_request.desc if push_request else '',
                     'create_time': push_request.create_time if push_request else '',
                     'result_from_config_api':push_history_items,
                     'note': 'action_id %s is not in OUI request queue. promoted from %s' % (action_id,parent_joint_action_id)})
        #errors.update({'general': 'action_id %s is in OUI request queue.' % action_id})
    if errors:
        return RestResponse(resp, error = errors, status=400)
    else:
        return RestResponse(resp, error=errors)