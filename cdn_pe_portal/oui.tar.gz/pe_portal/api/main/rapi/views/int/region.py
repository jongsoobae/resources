from ci.common.models.geo import Region
from api.rapi.utils import RestResponse, popAndFilter, getOptionalParams

def region_list(pRequest):
	region = Region.objects
	error = {}
	
	opt_params = getOptionalParams(pRequest)
	region = popAndFilter(opt_params, region,'region', 'id__in', expectslist=True)
	
	if opt_params.has_key('info') and opt_params.pop('info') == [u"1"]:
		region = region.values()
	else:
		region = region.values('id','name')
	return RestResponse(region, error = error)
