from datetime import datetime
from django.http import HttpResponseNotFound
from api.rapi.utils import RestResponse, popAndFilter, getOptionalParams
from ci.common.utils.api import get_object_or_api_exception, values_replace_choice
from ci.common.models.cdn import Service, Pop
from ci.common.models.cache import Band

def service_list(pRequest):
	error = {}
	service = Service.objects
	opt_params = getOptionalParams(pRequest)
	service = popAndFilter(opt_params, service, 'offline', 'offline')
	if opt_params.has_key('min_modify_date'):
		try:
			service = service.filter(modify_time__gt = \
				datetime.strptime(opt_params.pop('min_modify_date')[0][:19],
				'%Y-%m-%d %H:%M:%S'))
		except:
			error['min_modify_date'] = "Invalid, date must be ISO format without timezone"
	if opt_params.has_key('info') and opt_params.pop('info') == [u"1"]:
		service = service.values()
		for s in service:
			s['bands'] = []
			for b in Band.objects.filter(service__id=s['id']):
				s['bands'].append(b.id)
	else:
		service = service.values('id','name', 'dns_prefix')
	service = values_replace_choice(service, Service)
	return RestResponse(service, error = error)

def service_view(pRequest, id):
	error = {}
	opt_params = getOptionalParams(pRequest)
	service =get_object_or_api_exception(Service,id=id, as_query=True).values()
	service = values_replace_choice(service, Service)
	service[0]['bands'] = []
	for b in Band.objects.filter(service__id=id):
		service[0]['bands'].append(b.id)
	if len(opt_params) > 0:
		error['unknown_parameter(s)'] = "The following parameters were not handled: " + opt_params.urlencode()
	return RestResponse(service[0], error = error)
	
