from datetime import datetime
from django.db.models import Q
from django.core.exceptions import ObjectDoesNotExist
from django.utils.datastructures import SortedDict
from django.utils.encoding import force_unicode, smart_unicode, smart_str
from django.utils import simplejson
from django.contrib.auth.models import User as AuthUser
from ci.common.utils.api.site import site_add_or_edit
from api.rapi.utils import RestResponse, popAndFilter, getOptionalParams
from ci.common.utils.api import get_site_or_api_exception, get_draft_or_api_exception, get_stage_site_or_api_exception,\
    values_replace_choice,APIException
from ci.common.models import Customer, Site, Product, SiteDraft, SiteStage, PADChangeTime, SiteDDosConvertRule
from ci.common.models.site_event import SiteEventHistory, NEW, WORKING, ABORTED, DDOS_EVENT_QUEUE_STATUS
from ci.common.utils.site import getFieldsFromFieldset
from ci.common.utils.site import log_pad_change
from ci.common.utils.misc import get_elapsed_total_seconds
from ci.common.forms.site import SiteForm
from ci.common.forms.server_actions import get_rule_objects, get_rule_objects_from_json
from ci.common.forms.server_actions import SERVER_ACTION_ACTIONS, NON_LEAF_IDS
from ci.common.utils.misc import dict_diff
from ci.constants import EMAIL_ALERTS
from ci.django_mailer.models import MAIL_EVENT, DDOS_ATTACK_ALERTED
from ci.django_mailer.models import Message

def log_ddos_event(pRequest,  site, target_name, description='', report_time=None):
    """
    there is an 60 seconds of wait time to prevent identical requests.
    60 seconds is estimated time of task until agent job is done
    :param pRequest:
    :param site:
    :param target_name:
    :param description:
    :param report_time:
    :return:
    """
    resp= {'result':'Success'}
    message_list = []
    error = {}
    try:
        if report_time:
            try:
                report_time = datetime.fromtimestamp(float(report_time))
            except:
                report_time = datetime.now()
                message_list.append(u"Failed to parse report time. Current server time is used instead.")

        site_events = SiteEventHistory.objects.filter(site_id=site.pk,
                                                      event_id=DDOS_ATTACK_ALERTED,
                                                      event_queue_status__in=[NEW,WORKING,ABORTED])
        event_pk = -1
        if site_events.exists():
            total_elapsed_seconds = get_elapsed_total_seconds(datetime.now(), site_events[0].create_time)
            if total_elapsed_seconds < 60:
                message_list.append(u"Event has already been notified to DDos alert manager and under processing.")
                event_pk = site_events[0].pk
            else:
                event_pk = create_site_event(pRequest, site, target_name, report_time, description)
                message_list.append(u"Additional event has been successfully notified to site DDos alert manager.")
        else:
            event_pk = create_site_event(pRequest, site, target_name, report_time, description)
            message_list.append(u"Event has been successfully notified to site DDos alert manager.")
        resp.update({'pad':site.pad, 'event_log_id': event_pk, 'details':' '.join(message_list)})
    except Exception, e:
        resp.update({'result':'Failure'})
        error.update({'DB Error':str(e)})
    return resp, error

def create_site_event(pRequest, site, target_name, report_time, description):
    site_event = SiteEventHistory(site_id=site.pk,
                                  event_object_name=target_name,
                                  event_id = DDOS_ATTACK_ALERTED,
                                  report_time=report_time if report_time else datetime.now(),
                                  description=description,
                                  create_user=pRequest.user.username)
    site_event.save()
    return site_event.pk

def ddos_attack_event(pRequest):
    opts = getOptionalParams(pRequest)
    errors = {}
    resp = {}
    site_id = opts.get('site_id', None)
    target_name = opts.get('target_name', None)
    description = opts.get('description', None)
    report_time = opts.get('report_time', None)
    site = None

    if not site_id or not target_name:
        errors.update({'General':u'site_id and target_name field is mandatory.'})
    else:
        try:
            site = Site.objects.get(pk=int(site_id))
        except:
            site = None
            errors.update({'site_id': 'invalid site_id input'})

        if site:
            if not site.is_valid_target_with_pad_name(target_name):
                errors.update({'target_name':u'invalid target_name. target name is not matched with site pad name'})

    if not errors:
        resp, errors = log_ddos_event(pRequest, site, target_name, description, report_time)

    if resp and errors:
        return RestResponse(resp, error=errors, status=400)
    elif resp:
        return RestResponse(resp, error=errors)
    else:
        return RestResponse({}, error=errors, status=400)

def get_ddos_queue_status(queue_status):
    if queue_status:
        for ddos_queue in DDOS_EVENT_QUEUE_STATUS:
            if ddos_queue[1].lower() == queue_status.lower():
                return ddos_queue[0]
    return None


def fetch_site_ddos_queues(pRequest):
    """
    #TODO: add page_size parameter
    :param pRequest:
    :return:
    """
    opts = getOptionalParams(pRequest)
    errors = {}
    resp = {}
    try:
        agent_ipv4 = opts.get('agent_ipv4', '')

        queue_status = get_ddos_queue_status(opts.get('queue_status', None))
        as_queue = opts.get('as_queue',None)
        as_queue = True if as_queue and as_queue.lower() == 'true' else False
        if queue_status is not None:
            queue_status_list = [queue_status]
        else:
            queue_status_list = [NEW,ABORTED,WORKING]

        histories = SiteEventHistory.objects.filter(event_queue_status__in=queue_status_list).values('id','site_id',
                                                                                            'event_object_name',
                                                                                            'event_queue_status',
                                                                                            'report_time')
        if as_queue:
            new_histories = SiteEventHistory.objects.filter(event_queue_status=NEW)
            new_histories.update(event_queue_status=WORKING, agent_ipv4=agent_ipv4)

        resp.update({'result': histories})
    except Exception,e:
        errors.update({'General': str(e)})
    if resp and errors:
        return RestResponse(resp, error=errors, status=400)
    elif resp:
        return RestResponse(resp, error=errors)
    else:
        return RestResponse({}, error=errors, status=400)

def get_automated_site_ddos_rules(pRequest):
    errors = {}
    resp = {}
    result_list = []
    try:
        rules = SiteDDosConvertRule.objects.select_related().filter(Q(automated_service_prefix_change_enabled=1) |
                                                   Q(automated_set_cookie_samrule_change_enabled=1))
        for rule in rules:
            result_list.append(rule.get_automation_info_as_dict())

        resp.update({'result': result_list})
    except Exception,e:
        errors.update({'General':str(e)})
    if resp and errors:
        return RestResponse(resp, error=errors, status=400)
    elif resp:
        return RestResponse(resp, error=errors)
    else:
        return RestResponse({}, error=errors, status=400)

def update_site_ddos_queue_status(pRequest):
    opts = getOptionalParams(pRequest)
    errors = {}
    resp = {}
    try:
        queues = opts.get('queue_ids', None)
        agent_ipv4 = opts.get('agent_ipv4', '')
        queue_status = opts.get('queue_status', None)
        target_status = get_ddos_queue_status(queue_status)
        if queues and target_status is not None:
            queue_list = [int(x) for x in queues.split(',') if x.isdigit()]
            histories = SiteEventHistory.objects.filter(id__in=queue_list)
            if histories.exists():
                histories.update(event_queue_status=target_status,
                                 agent_ipv4=agent_ipv4,
                                 modify_user=pRequest.user.username,
                                 modify_time=datetime.now())
                queue_ids = histories.values_list('pk', flat=True)
                resp = {'result':'Success',
                        'queue_status': queue_status,
                        'queue_ids': queue_ids,
                        'details': u"Event queue status has been successfully updated."}
            else:
                errors.update({'queue_ids': u'invalid queue list or queue list does not exist'})
        else:
            if not target_status:
                errors.update({'queue_status':u'queue_status input is missing.'})
            if not queues:
                errors.update({'queue_ids':u'queue_ids input missing'})
    except Exception,e:
        errors.update({'General': str(e)})
    if resp and errors:
        return RestResponse(resp, error=errors, status=400)
    elif resp:
        return RestResponse(resp, error=errors)
    else:
        return RestResponse({}, error=errors, status=400)

def ddos_convert_to_attack(pRequest):
    """
    convert to attack prefix and 302 SAM rule
    :param pRequest:
    :return:
    """
    opts = getOptionalParams(pRequest)
    errors = {}
    resp = {}
    try:
        simulate_failure = int(opts.get('simulate_failure',0))
    except:
        simulate_failure = 0
    site_id = opts.get('site_id', None)
    agent_ipv4 = opts.get('agent_ipv4', '')
    queues = opts.get('queues', '').split(',')
    queue_list = [int(x) for x in queues if x.isdigit()]

    if not site_id:
        errors.update({'site_id':u'site_id field is mandatory.'})
    if not queue_list:
        errors.update({'queues': u'queues field is mandatory'})
    try:
        site = Site.objects.get(pk=int(site_id))
        site_rule = site.get_ddos_convert_rule()
        if site_rule is None:
            errors.update({'site_id': u'Site exists but has no DDos convert rule.'})
    except:
        site = None
        site_rule = None
        errors.update({'site_id': u'invalid site_id input'})
    if site:
        histories = SiteEventHistory.objects.filter(id__in=queue_list, site_id=site_id)
        if not histories.exists():
            errors.update({'queues':u'invalid queues input or queues for site_id %s does not exist.' % site_id})

    try:
        if simulate_failure:
            raise Exception('[TEST] Intended failure exception for TEST')
        if not errors:
            message_list = []
            result = ''
            if site_rule.is_service_prefix_convert_automated() and not site_rule.is_service_prefix_ddos_attack_converted():
                site.convert_service_to_ddos_attack(pRequest, site_rule)
                message_list.append(u"Site's service has been automatically converted to attack mode.")
                result = 'Success'
            if site_rule.is_sam_rule_attack_convert_automated() and not site_rule.is_sam_rule_attack_converted():
                site.apply_sam_rule_to_ddos_attack(pRequest, site_rule)
                message_list.append(u"302 SAM rule has been automatically added to site as attack mode.")
                result = 'Success'
            if result == 'Success':
                histories.update(event_queue_status=2,
                                 agent_ipv4=agent_ipv4,
                                 modify_user=pRequest.user.username,
                                 modify_time=datetime.now())
            else:
                result = 'No Action'
                histories.exclude(event_queue_status=2).update(event_queue_status=3,
                                 agent_ipv4=agent_ipv4,
                                 modify_user=pRequest.user.username,
                                 modify_time=datetime.now())
                message_list.append(u'No action taken. Job may have been processed already by operator or not automated rule.')
                message_list.append(u'service prefix automated:%s' % site_rule.is_service_prefix_convert_automated())
                message_list.append(u'302 SAM automated:%s' % site_rule.is_service_prefix_ddos_attack_converted())
            resp.update({'result': result, 'details': ' '.join(message_list)})
    except Exception,e:
        #tag job as 'aborted'
        histories.update(event_queue_status=-1,
                         agent_ipv4=agent_ipv4,
                         modify_user=pRequest.user.username,
                         modify_time=datetime.now())
        errors.update({'General': str(e)})

    if resp and errors:
        return RestResponse(resp, error=errors, status=400)
    elif resp:
        return RestResponse(resp, error=errors)
    else:
        return RestResponse({}, error=errors, status=400)

def ddos_restore_to_normal(pRequest):
    """
    convert to normal prefix and 302 SAM rule if automated is true
    :param pRequest:
    :return:
    """
    opts = getOptionalParams(pRequest)
    errors = {}
    resp = {}
    site_id = opts.get('site_id', None)
    pad_name = opts.get('pad_name', None)

    if not site_id or not pad_name:
        errors.update({'site_id':u'site_id and pad_name field is mandatory.'})
    try:
        site = Site.objects.get(pk=int(site_id))
        if site.pad != pad_name:
            errors.update({'pad_name': u'Site exists but not matched with pad_name input.'})
        site_rule = site.get_ddos_convert_rule()
        if site_rule is None:
            errors.update({'site_id': u'Site exists but has no DDos convert rule.'})
    except:
        site = None
        site_rule = None
        errors.update({'site_id': u'invalid site_id input'})

    try:
        if not errors:
            message_list = []
            result = ''
            if site_rule.is_service_prefix_convert_automated() and site_rule.is_service_prefix_ddos_attack_converted():
                site.convert_ddos_service_back_to_normal(pRequest,site_rule)
                message_list.append(u"Site's service has been automatically restored to normal mode.")
                result = 'Success'
            if site_rule.is_sam_rule_attack_convert_automated() and site_rule.is_sam_rule_attack_converted():
                site.apply_sam_rule_to_ddos_normal(pRequest, site_rule)
                message_list.append(u"302 SAM rule has been automatically removed from site as normal mode.")
                result = 'Success'
            if result != 'Success':
                result = 'No Action'
                message_list.append(u'No action taken. Job may have been processed already by operator or not automated rule.')
                message_list.append(u'service prefix automated:%s' % site_rule.is_service_prefix_convert_automated())
                message_list.append(u'302 SAM automated:%s' % site_rule.is_service_prefix_ddos_attack_converted())
            resp.update({'result': result, 'details': ' '.join(message_list)})
    except Exception,e:
        errors.update({'General': str(e)})

    if resp and errors:
        return RestResponse(resp, error=errors, status=400)
    elif resp:
        return RestResponse(resp, error=errors)
    else:
        return RestResponse({}, error=errors, status=400)

def site_add(pRequest):
    opts = getOptionalParams(pRequest)
    resp, errors = site_add_or_edit(pRequest, opts, pad=None, site=True)
    if resp and errors:
        return RestResponse({'details': resp}, error =errors, status=400)
    elif resp:
        return RestResponse({'details': resp},error = errors)
    else:
        return RestResponse({}, error = errors, status=400)
        
def site_edit(pRequest, site):
    opts = getOptionalParams(pRequest)
    resp, errors = site_add_or_edit(pRequest, opts, pad=site, site=True)
    if resp and errors:
        return RestResponse({'details': resp}, error =errors, status=400)
    elif resp:
        return RestResponse({'details': resp},error = errors)
    else:
        return RestResponse({}, error = errors, status=400)

def draft_view(pRequest, pad):
    error = {}
    opt_params = getOptionalParams(pRequest)
    type_status = opt_params.get('type','')
    if type_status == 'production':
        sites = get_site_or_api_exception(pRequest, pad, as_query=True)
        pad = sites.values(*tuple(set(getFieldsFromFieldset(SiteDraft.fieldsets)).difference(SiteDraft.api_view_blacklist)))
        model = Site
    elif type_status == 'stage':
        stages = get_stage_site_or_api_exception(pRequest, pad, as_query=True)
        pad = stages.values(*tuple(set(getFieldsFromFieldset(SiteDraft.fieldsets)).difference(SiteDraft.api_view_blacklist)))
        model = SiteStage
    else:
        drafts = get_draft_or_api_exception(pRequest, pad, as_query=True)
        pad = drafts.values(*(SiteDraft.cui_editable_fields + getFieldsFromFieldset(SiteDraft.cui_stat_fields)))
        model = SiteDraft
    pad = values_replace_choice(pad, model)
    #if len(opt_params) > 0:
    #    error['unknown_parameter(s)'] = "The following parameters were not handled: " + opt_params.urlencode()
    return RestResponse(pad[0],error=error)

def trace_internal(pRequest, pad):
    error_dict = {}
    opt_params = getOptionalParams(pRequest)
    drafts = get_draft_or_api_exception(pRequest, pad, as_query=True)

    url = opt_params.get('url',opt_params.get('uri',''))
    ipv4 = opt_params.get('ipv4', None)
    additional_headers = opt_params.get('additional_headers','')
    filename = opt_params.get('filename','')
    file_contents = opt_params.get('body_contents',opt_params.get('file_contents',None))
    ipaddr = ipv4
    if drafts[0].has_testable_staging_node():
        error, result, raw_result, hostname, ipaddr = drafts[0].fetch_trace_internal_result(url,additional_headers,
                                                                                filename,file_contents,
                                                                                ipv4=ipv4)
    else:
        error = u"PAD configuration may have not been pushed to test nodes. " \
                u"Staging test is enabled only when PAD status is 'On Staging'. PAD status:%s" % (drafts[0].get_pad_status())

    result_dict = {'hostname':hostname, 'ipv4':ipaddr, 'url':url, 'result':result, 'raw_result': raw_result}
    if error and len(error.strip()) > 0:
        error_dict.update({'general':error})
    return RestResponse(result_dict,error=error_dict)

def mail_template_view(pRequest, pad):
    error_dict = {}
    error = ''
    opt_params = getOptionalParams(pRequest)
    drafts = get_draft_or_api_exception(pRequest, pad, as_query=True)
    send_mail = opt_params.get('send_mail',False)
    worker_email = opt_params.get('user_email')
    event_id = int(opt_params.get('event_id'))
    event_name = MAIL_EVENT[event_id]
    try:
        implementer = AuthUser.objects.get(username=opt_params.get('implementer'))
    except:
        implementer = pRequest.user

    customer_recipients = drafts[0].get_pad_change_event_mail_customer_subscribers()
    customer_recipients.append(worker_email)
    operator_recipients = drafts[0].get_pad_change_event_operator_subscribers(event_id,implementer)

    #[Debug_Test] ==> backend django mailer will not send email to additional recipients
    subject = "[Debug_Test] %s" % drafts[0].get_pad_change_event_mail_subject_by_event_id(event_id)
    recipients = customer_recipients + operator_recipients
    body = drafts[0].get_pad_change_event_mail_body_contents(subject, comments='',
                                                             operator_receiver=operator_recipients,
                                                             customer_receiver=customer_recipients,
                                                             implementer=implementer,
                                                             display_cust_flags=True,
                                                             debug=True)
    result_dict = {'implementer': str(implementer),
                   'event': event_name,
                   'PAD': str(drafts[0]),
                   'PAD deploy status': drafts[0].get_pad_status(),
                   'product': str(drafts[0].product),
                   'product_info': drafts[0].product.fetch_cs_contract(),
                   'product_info2': drafts[0].product.get_contract_info(),
                   'related_products': drafts[0].get_related_contracts(),
                   'customer_region': "%s: %s" % (drafts[0].customer.corp_code, drafts[0].customer.get_short_corp_code()),
                   'customer_recipients': customer_recipients,
                   'operator_recipients': operator_recipients,
                   'subject': subject,
                   'body_messages': body}

    if send_mail:
        from ci.common.utils.site import send_mail_wrapping
        recipients = EMAIL_ALERTS
        send_mail_wrapping(subject, body, implementer, recipients, worker_email, drafts[0], event_id)

    if error and len(error.strip()) > 0:
        error_dict.update({'general':error})
    return RestResponse(result_dict,error=error_dict)

def site_mail_logs(pRequest, pad):
    error = {}
    opt_params = getOptionalParams(pRequest)
    drafts = get_draft_or_api_exception(pRequest, pad, as_query=True)
    worker_email = opt_params.get('user_email',None)
    verbose = opt_params.get('verbose',True)
    if verbose in ['False','0']:
        verbose = False
    try:
        event_id = int(opt_params.get('event_id')) # 1,2,5 triggered by customer user
    except:
        event_id = 0
    try:
        latest_message_id = int(opt_params.get('latest_message_id'))
    except:
        latest_message_id = 0

    result_list = []
    if drafts.exists():
        message_logs = Message.objects.filter(draft_id=drafts[0].pk, pk__gt=latest_message_id).order_by('-pk')
        if event_id > 0:
            message_logs = message_logs.filter(event_id=event_id)
        if worker_email:
            message_logs = message_logs.filter(actor=worker_email)
        for message in message_logs:
            result_dict = {'message_id':message.pk,
                           'actor': message.actor,
                           'to_address': message.to_address,
                           'from_address': message.from_address,
                           'subject':message.subject,
                           'date_created':message.date_created,
                           'parent_id': message.parent_id,
                           'event_name': message.get_event_name(),
                           'message_status': message.get_status(),
                           'date_sent': message.get_date_sent()}
            if verbose:
                result_dict.update({'encoded_message':message.encoded_message.split('\n')})
            result_list.append(result_dict)

    if error:
        return RestResponse(result_list,error=error, status=400)
    else:
        return RestResponse(result_list,error=error)

def stage_diff_view(pRequest,pad):
    errors = {}
    draft = get_draft_or_api_exception(pRequest, pad, as_query=True)
    if not draft.exists():
        return RestResponse({}, error = {'error':"draft not exist"}, status=400)

    result_dict = {'draft_pad':smart_unicode(draft[0]), 'draft_product':draft[0].product.get_customer_ui_name()}
    stage = SiteStage.objects.filter(sitedraft=draft)

    fields_exclude = SiteDraft.cui_diff_excludes
    fields_exclude += getFieldsFromFieldset(SiteDraft.cui_stat_fields)

    pads = draft.values(*(list(f.name for f in SiteDraft._meta.fields if f.name not in fields_exclude) ))
    if stage.exists():
        stage_pads = stage.values(*(list(f.name for f in SiteStage._meta.fields if f.name not in fields_exclude) ))
        result_dict.update({'stage_pad':smart_unicode(stage[0]),'stage_product':stage[0].product.get_customer_ui_name()})
    else:
        stage_pads = [{}]

    pads = values_replace_choice(pads, SiteDraft)
    stage_pads = values_replace_choice(stage_pads, SiteStage)
    diff_dict = dict_diff(pads[0], stage_pads[0])

    result_dict.update({'diff':diff_dict})
    return RestResponse(result_dict, error=errors, status=200)

def production_diff_view(pRequest, pad):
    errors = {}
    draft = get_draft_or_api_exception(pRequest, pad, as_query=True)

    if not draft.exists():
        return RestResponse({}, error = {'error':"draft not exist"}, status=400)
    production = Site.objects.filter(sitedraft=draft)

    result_dict = {'draft_pad':smart_unicode(draft[0]), 'draft_product':draft[0].product.get_customer_ui_name()}
    fields_exclude = SiteDraft.cui_diff_excludes
    fields_exclude += getFieldsFromFieldset(SiteDraft.cui_stat_fields)
    pads = draft.values(*(list(f.name  for f in SiteDraft._meta.fields if f.name not in fields_exclude) ))
    if production.exists():
        production_pads = production.values(*(list(f.name for f in Site._meta.fields if f.name not in fields_exclude)))
        result_dict.update({'production_pad':smart_unicode(production[0]),
                            'production_product':production[0].product.get_customer_ui_name()})
    else:
        production_pads = [{}]

    pads = values_replace_choice(pads, SiteDraft)
    production_pads = values_replace_choice(production_pads, Site)
    diff_dict = dict_diff(pads[0], production_pads[0])
    result_dict.update({'diff':diff_dict})
    return RestResponse(result_dict, error=errors, status=200)


def product_edit(pRequest, site):
    opts = getOptionalParams(pRequest)
    site = get_site_or_api_exception(pRequest, site)
    if not opts.has_key('cop_product_id'):
        raise APIException("You must pass a COP product ID")
    try:
        product = Product.objects.get(cop_product_id=opts.get('cop_product_id'))
    except ObjectDoesNotExist:
        raise APIException("Invalid COP product ID. If this is a new product, you must add it using the add product API first")
    if product.customer != site.customer:
        raise APIException("Invalid COP product for this customer")
    site.product = product
    site.save()
    return RestResponse({'details':"Site product has been changed"})

def product_move(pRequest, site):
    opts = getOptionalParams(pRequest)
    site = get_site_or_api_exception(pRequest, site)

    if not opts.has_key('cop_product_id') or not opts.has_key('customer_id'):
        raise APIException("cop_product_id, customer_id are required.")

    try:
        customer = Customer.objects.get(pk=opts.get('customer_id'))
    except:
        raise APIException("Invalid customer id.")

    try:
        product = Product.objects.get(cop_product_id=opts.get('cop_product_id'), customer=customer)
    except:
        raise APIException("Invalid cop_product_id in '%s'"%opts.get('customer_id'))

    site.customer = customer
    site.product = product
    site.save()

    return  RestResponse({'details':"Site product has been changed"})

def get_dictionary(self):
    ret = []
    if self.get_form().data['id'] not in NON_LEAF_IDS:
        if self.get_form().errors != {}:
            ret.append(self.get_form().errors)
    else:
        for child in self.children():
            ret = ret + get_dictionary(child)
    return ret

def update_server_action_rule(pRequest):
    err_msg = []
    err_org = []
    warning_msg = []
    found_cnt = 0

    site_id =  pRequest.POST.get('site_id', None)
    rule_name = pRequest.POST.get('rule_name', None)
    new_rule = pRequest.POST.get('server_action_rule', None)

    if site_id == None or site_id == '':
        err_msg.append('site_id is required')
    if rule_name == None or rule_name == '':
        err_msg.append('rule_name is required')
    if new_rule == None or new_rule == '':
        err_msg.append('new_rule is required')

    try:
        n_site_id = int(site_id)
        if n_site_id <= 0:
            err_msg.append('valid site_id is required')
    except:
        err_msg.append('invalid literal for int() with base 10')

    if err_msg != []:
        return RestResponse({'details':"parameter required", 'error-msg':err_msg})

    try:
        site_obj = Site.objects.get(id = site_id)
        site_obj_changed = Site.objects.get(id = site_id)
        new_rule_json = simplejson.loads(new_rule)

        site_obj_json = site_obj.json_server_actions()
        rules = get_rule_objects(site_obj) if site_obj.server_action_rules != '' and site_obj.server_action_rules != None else None
        if rules:
            new_rule_obj = get_rule_objects_from_json(site_obj, new_rule_json)
            idx = 0
            for rule in rules:
                if rule.name == rule_name:
                    err_org = get_dictionary(rule.condition()) if rule.condition() else []
                    action_val_flag = True
                    condition_val_flag = True
                    if len(err_org) == 0:
                        forms = new_rule_obj[0].actions()
                        for form_class in forms:
                            form_class = new_rule_obj[0].actions()[0]
                            form = SERVER_ACTION_ACTIONS[form_class.id](data=form_class.data)
                            if not form.is_valid():
                                action_val_flag = False
                                err_msg.append(form.errors)

                        if new_rule_obj[0].condition():
                            new_rule_condition = new_rule_obj[0].condition()
                            ret = get_dictionary(new_rule_condition)
                            if len(ret) > 0:
                                condition_val_flag = False
                                err_msg = err_msg + ret
                        else:
                            warning_msg.append("none condition")

                        if action_val_flag == True and condition_val_flag == True:
                            site_obj_json[idx] = new_rule_obj[0].get_dictionary()
                            found_cnt = found_cnt + 1
                idx = idx + 1

        if err_msg == [] and err_org == [] and found_cnt > 0:
            site_obj_changed.server_action_rules = simplejson.dumps(site_obj_json)
            site_form_data = SiteForm(instance=site_obj_changed, site=site_obj_changed)

            form_model = SiteForm
            site_form_changed = form_model(data=site_form_data.initial, instance=site_obj_changed, site=site_obj_changed, edit_type='normal_api')

            if site_form_changed.is_valid():
                change_row  = PADChangeTime(site=site_obj_changed, user=pRequest.user, comment='api changed')
                change_row.save()
                log_pad_change(change_row, site_obj, site_form_changed.cleaned_data)
                site_obj_changed.save()

        if found_cnt == 0:
            warning_msg.append("no rule updated")

    except Exception, e:
        err_msg.append("Error Msg : %s"%(str(e)))

    if err_msg != [] or err_org != []:
        return RestResponse({'details':"error occured", 'error-msg':err_msg, 'warning-msg':warning_msg, 'error-org':err_org})
    else:
        return RestResponse({'details':"server action rule updated", 'warning-msg':warning_msg})


def search_server_action_rule(pRequest):
    match_cnt = 0
    arr_match_cnt = []
    non_match_cnt = 0
    arr_non_match_cnt = []
    error_cnt = 0
    arr_error_cnt = []
    total_cnt = 0
    err_msg = []

    column = ['totla-cnt', 'match-cnt', 'match-site', 'non-match-cnt', 'non-match-site', 'error-cnt', 'error-site']

    rule_name = pRequest.POST.get('rule_name', None)
    server_action_rule = pRequest.POST.get('server_action_rule', None)
    type = pRequest.POST.get('type_flag', None)
    status = pRequest.POST.get('status', '1')

    if rule_name == None or rule_name == '':
        err_msg.append('rule_name is required')
    if server_action_rule == None or server_action_rule == '':
        err_msg.append('server_action_rule is required')
    if type == None or type == '':
        err_msg.append('type_flag is required')
    if status not in ('1', '0'):
        err_msg.append('invalid status')
    try:
        type_flag = int(type)
    except:
        err_msg.append("invalid literal for int() with base 10")

    if err_msg != []:
        return RestResponse({'details':"valid parameter required", 'error-msg':err_msg})

    try:
        if status == '1':
            site_all = Site.objects.filter(type_flag = type_flag, status = True).all()
        else:
            site_all = Site.objects.filter(type_flag = type_flag).all()
        server_action_rule_json = simplejson.loads(server_action_rule)

        for site_obj in site_all:
            try:
                ret = []
                server_action_rule_obj = get_rule_objects_from_json(site_obj, server_action_rule_json)
                if server_action_rule_obj[0].condition():
                    new_rule_condition = server_action_rule_obj[0].condition()
                    ret = get_dictionary(new_rule_condition)
                    if len(ret) > 0 and total_cnt == 0:
                        err_msg = err_msg + ret
    
                if len(ret) == 0:
                    site_obj_json = site_obj.json_server_actions()
                    rules = get_rule_objects(site_obj) if site_obj.server_action_rules != '' and site_obj.server_action_rules != None else None
                    if rules:
                        for rule in rules:
                            if rule.name == rule_name:
                                ret = get_dictionary(rule.condition()) if rule.condition() else []
                                if len(ret) > 0:
                                    raise Exception("original validation error")                                
                                rule_hash_old = simplejson.dumps(rule.get_dictionary())
                                rule_hash_new = simplejson.dumps(server_action_rule_obj[0].get_dictionary())
                                if rule_hash_old == rule_hash_new:
                                    match_cnt = match_cnt + 1
                                    arr_match_cnt.append(str(site_obj.id))
                                else:
                                    non_match_cnt = non_match_cnt + 1
                                    arr_non_match_cnt.append(str(site_obj.id))

            except Exception, e:
                error_cnt = error_cnt + 1
                arr_error_cnt.append(str(site_obj.id))

            total_cnt = total_cnt + 1

        ret_arr = []
        row_one = []
        row_one.append(str(total_cnt))
        row_one.append(str(match_cnt))
        row_one.append(arr_match_cnt)
        row_one.append(str(non_match_cnt))
        row_one.append(arr_non_match_cnt)
        row_one.append(str(error_cnt))
        row_one.append(arr_error_cnt)

        tmp_dict = SortedDict(zip(column, row_one))
        ret_arr.append(tmp_dict)

    except Exception, e:
        err_msg.append("Error Msg : %s"%(str(e)))

    if err_msg != []:
        return RestResponse({'details':"error occured", 'error-msg':err_msg})
    else:
        return RestResponse(ret_arr)

