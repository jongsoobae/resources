from django.contrib.auth.decorators import user_passes_test
from api.rapi.utils import RestResponse, popAndFilter, getOptionalParams
from ci.common.utils.invoice import raw_invoice_detail_pdf
from ci.common.models.invoice import Invoice
from ci.common.utils.api import get_object_or_api_exception

@user_passes_test(lambda u: u.get_profile().invoice_perm and u.get_profile().customer.can_see_invoices)
def invoice_list(pRequest):

	profile = pRequest.user.get_profile()
	opts = getOptionalParams(pRequest)
	error = {}
	
	invoices = profile.customer.invoice_set.filter(published=True)
	invoices = popAndFilter(opts, invoices, 'year', 'month__year')

	if opts.has_key('info') and opts.pop('info') == [u"1"]:
		invoices = invoices.values('official_id','month')
	else:
		invoices = invoices.values('official_id')

	if len(opts) > 0:
		error['unknown_parameter(s)'] = "The following parameters were not handled: " + opts.urlencode()

	return RestResponse(invoices, error = error)

@user_passes_test(lambda u: u.get_profile().invoice_perm and u.get_profile().customer.can_see_invoices)
def invoice_view(pRequest, invoice_id):
	profile = pRequest.user.get_profile()
	invoice = get_object_or_api_exception(Invoice, published=True, customer=profile.customer, official_id=invoice_id, message="Invalid invoice id supplied.")

	return raw_invoice_detail_pdf(pRequest, invoice.id)
