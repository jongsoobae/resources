from ci.common.models.aggregate import Aggregate
from ci.common.models.site import Site
from api.rapi.utils import RestResponse, getOptionalParams
from ci.common.utils import get_allowed_sites
from ci.common.utils.api import APIException, get_object_or_api_exception, get_site_or_api_exception
from ci.common.utils.aggregate import aggregateReportGeneration, AggregateReportForm, report_types

def log_view(pRequest, aggregate_type, pad):
	"""Rest interface for custom reports.
	If input could not be parsed: 400
	If site is not recognized: 400
	If aggregate type is not recognized: 400
	If any other error: 400
	"""
	profile = pRequest.user.get_profile()
	site = get_site_or_api_exception(pRequest, pad)
	agg = get_object_or_api_exception(Aggregate,id=aggregate_type, message="Invalid aggregate type")

	opts = getOptionalParams(pRequest)
        opts['aggregate'] = aggregate_type
	opts['site'] = site.id
	format = opts.pop('format',None)
	if format == None:
		format = "csv" #default value
	if isinstance(format, list) and len(format) == 1:
		format = format[0]
	opts['report_type'] = report_types.get(format,(None,None))[0]
	opts['show_header'] = False  if opts.has_key('header') and opts.pop('header') == [u"0"] else True
	if not opts.has_key('start'):
		opts['start'] = AggregateReportForm.base_fields['start'].initial
	if not opts.has_key('end'):
		opts['end'] = AggregateReportForm.base_fields['end'].initial
	if site.aggregate_set.filter(id=aggregate_type).count() != 1:
		raise APIException("Site not configured for desired report type",status=400)

	form = AggregateReportForm(opts, initial_sites = Site.objects.filter(id=site.id))
	if form.is_valid():
		ret = aggregateReportGeneration(profile.customer, form)
		if ret != None:
			return ret
		form.addDataError("No data available for PAD and time range specified")	
	errors = {}
	replace_dict = {'__all__': "general", 'report_type': "format", 'site': "pad", 'aggregate': "report", 'show_header': "header"}
	for item, value in form.errors.items():
		if replace_dict.has_key(item):
			item = replace_dict.get(item)
		errors[item] = value.as_text() if hasattr(value,"as_text") else str(value)
	return RestResponse({}, error=errors,status=400)
