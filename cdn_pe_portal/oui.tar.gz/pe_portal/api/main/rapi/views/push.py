from django.contrib.auth.decorators import user_passes_test
from ci.common.utils.api import get_draft_or_api_exception
from api.rapi.utils import getOptionalParams, RestResponse
from ci.common.utils.api.site import get_push_history
from ci.common.utils import get_customer

def push_history(pRequest,pad=None):
    opts = getOptionalParams(pRequest)
    username = opts.get('aurora_user_id')
    #opts = remove_params_for_aurora(opts)
    if pad is not None:
        draft = get_draft_or_api_exception(pRequest,pad)
    else:
        draft = None

    resp,errors = get_push_history(get_customer(pRequest), username, draft, is_for_customer=True)

    if errors:
        return RestResponse(resp,error=errors, status=400)
    else:
        return RestResponse(resp,error=errors)


