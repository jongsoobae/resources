from django.contrib.auth.decorators import user_passes_test
from django.views.decorators.csrf import csrf_exempt
from api.rapi.utils import getOptionalParams, RestResponse
from ci.common.utils.api.sam import sam_addrule, sam_viewrule, sam_editrule, sam_deleterule


def remove_params_for_aurora(opt_params):
    if opt_params.has_key('md5_dig'):
        opt_params.pop('md5_dig')
    if opt_params.has_key('pad_list'):
        opt_params.pop('pad_list')
    if opt_params.has_key('ckey'):
        opt_params.pop('ckey')
    if opt_params.has_key('aurora_user_id'):
        opt_params.pop('aurora_user_id')
    if opt_params.has_key('aurora_user_key'):
        opt_params.pop('aurora_user_key')
    if opt_params.has_key('editable'):
        opt_params.pop('editable')
    if opt_params.has_key('admin_flag'):
        opt_params.pop('admin_flag')
    return opt_params


@user_passes_test(lambda u: u.get_profile().edit_pad_perm)
@csrf_exempt
def sam_add(pRequest, pad=None, production=False):
    opts = getOptionalParams(pRequest)
    opts = remove_params_for_aurora(opts)

    resp, errors = sam_addrule(pRequest, opts, pad)

    if resp and errors:
        return RestResponse({'details': resp}, error=errors, status=400)
    elif resp:
        return RestResponse({'details': resp}, error=errors)
    else:
        return RestResponse({}, error=errors, status=400)


@csrf_exempt
def sam_view(pRequest, pad=None):
    opts = getOptionalParams(pRequest)
    opts = remove_params_for_aurora(opts)

    resp, errors = sam_viewrule(pRequest, opts, pad)

    if resp and errors:
        return RestResponse({'details': resp}, error=errors, status=400)
    elif resp:
        return RestResponse({'details': resp}, error=errors)
    else:
        return RestResponse({}, error=errors, status=400)


@user_passes_test(lambda u: u.get_profile().edit_pad_perm)
@csrf_exempt
def sam_edit(pRequest, pad=None):
    opts = getOptionalParams(pRequest)
    opts = remove_params_for_aurora(opts)

    if pRequest.session.get('aurora_editable', True):
        resp, errors = sam_editrule(pRequest, opts, pad)
    else:
        resp, errors = '', 'Your user account does not have sufficient permissions to access this API - Contact Support'

    if resp and errors:
        return RestResponse({'details': resp}, error=errors, status=400)
    elif resp:
        return RestResponse({'details': resp}, error=errors)
    else:
        return RestResponse({}, error=errors, status=400)


@user_passes_test(lambda u: u.get_profile().edit_pad_perm)
@csrf_exempt
def sam_delete(pRequest, pad=None):
    opts = getOptionalParams(pRequest)
    opts = remove_params_for_aurora(opts)

    resp, errors = sam_deleterule(pRequest, opts, pad)

    if resp and errors:
        return RestResponse({'details': resp}, error=errors, status=400)
    elif resp:
        return RestResponse({'details': resp}, error=errors)
    else:
        return RestResponse({}, error=errors, status=400)