import json
import pexpect
from django.conf import settings
from django.contrib.auth.decorators import user_passes_test
from ci.common.models.site import SiteDraft, Site, REQUEST_IMPLEMENT_READY, DEPLOY_STATUS_WAITING_REQ
from api.rapi.utils import getOptionalParams, RestResponse, popAndFilter
from ci.common.utils.api import get_site_or_api_exception, get_draft_or_api_exception, values_replace_choice
from ci.common.utils import get_allowed_sites, get_allowed_drafts
from ci.common.utils.site import getFieldsFromFieldset, draft_groups_for_query
from ci.common.utils.api.site import site_add_or_edit,site_add_or_edit_v2, push_to_staging, push_to_production, get_pad_status,\
    validate_contract_shield_or_api_exception, is_self_implementable_pad
from ci.common.utils.traffic import round_time_to_epoch, Serieses, processQuery
from ci.common.models.site_history import CustomerSiteChangeHistory
from ci.common.utils.misc import dict_diff, padded_cop_product_id
from ci.constants import SUPPORT_SERVER, SUPPORT_AUTHENTICATION_KEY
from ci.common.utils.supporttools import supporttoolsGenericSubmission, mergeDictionaries, \
    supporttoolsPreheatListRetrieve, supporttoolsParseURL, supporttoolsInfo, handleHttpGetConnection, concatQueryStrings
from ci.constants import MySQL_CHARTRON_DB
from ci.django_mailer.models import QueuedMessage, Message, Log


def remove_params_for_aurora(opt_params):
    if opt_params.has_key('md5_dig'):
        opt_params.pop('md5_dig')
    if opt_params.has_key('pad_list'):
        opt_params.pop('pad_list')
    if opt_params.has_key('ckey'):
        opt_params.pop('ckey')
    if opt_params.has_key('aurora_user_id'):
        opt_params.pop('aurora_user_id')
    if opt_params.has_key('aurora_user_key'):
        opt_params.pop('aurora_user_key')
    if opt_params.has_key('editable'):
        opt_params.pop('editable')
    if opt_params.has_key('admin_flag'):
        opt_params.pop('admin_flag')
    if opt_params.has_key('item_list'):
        opt_params.pop('item_list')
    if opt_params.has_key('output'):
        opt_params.pop('output')
    return opt_params

def remove_params_for_request_implementation(opt_params, draft=None):
    """
    if draft is not self implementable, 'shield_location',
    'product' field should be removed for compatibility with previous api version.
    :param opt_params:
    :return:
    """
    if opt_params.has_key('self_implementable'):
        opt_params.pop('self_implementable')
    if opt_params.has_key('deploy_status'):
        opt_params.pop('deploy_status')
    if draft:
        if not draft.is_new(): #product can not be changed if draft once had been deployed to production
            if opt_params.has_key('product'):
                contract_no = opt_params.get('product')
                if draft.product.cop_product_id != padded_cop_product_id(contract_no):
                    from ci.common.utils.api import APIException
                    raise APIException("You can not change product once PAD deployed to production.", status=400)
                else:
                    opt_params.pop('product')

            if not draft.is_dwa():
                if opt_params.has_key('shield_location'):
                    opt_params.pop('shield_location')

            if not draft.is_ssl_contract():
                if opt_params.has_key('upstream_ssl'):
                    opt_params.pop('upstream_ssl')
                if opt_params.has_key('enable_ssl'):
                    opt_params.pop('enable_ssl')
    return opt_params

@user_passes_test(lambda u: u.get_profile().edit_pad_perm)
def site_push_to_staging(pRequest, pad=None):
    opts = getOptionalParams(pRequest)
    if pRequest.session.get('aurora_editable', True):
        resp, errors = push_to_staging(pRequest, opts, pad)
    else:
        resp, errors = '', 'Your user account does not have sufficient permissions to access this API - Contact Support'

    if resp and errors:
        return RestResponse({'details': resp}, error =errors, status=400)
    elif resp:
        return RestResponse({'details': resp},error = errors)
    else:
        return RestResponse({}, error = errors, status=400)

@user_passes_test(lambda u: u.get_profile().edit_pad_perm)
def site_push_to_production(pRequest, pad=None):
    opts = getOptionalParams(pRequest)
    if pRequest.session.get('aurora_editable', True):
        resp, errors = push_to_production(pRequest, opts, pad)
    else:
        resp, errors = '', 'Your user account does not have sufficient permissions to access this API - Contact Support'

    if resp and errors:
        return RestResponse({'details': resp}, error =errors, status=400)
    elif resp:
        return RestResponse({'details': resp},error = errors)
    else:
        return RestResponse({}, error = errors, status=400)

@user_passes_test(lambda u: u.get_profile().edit_pad_perm)
def site_push_status(pRequest, pad=None):
    #opts = getOptionalParams(pRequest)
    #opts = remove_params_for_aurora(opts)
    opts = {}
    resp, errors = get_pad_status(pRequest, opts, pad)

    if errors:
        return RestResponse(resp,error=errors, status=400)
    else:
        return RestResponse(resp,error=errors)

@user_passes_test(lambda u: u.get_profile().edit_pad_perm)
def site_is_self_implementable(pRequest, pad=None, production=False):
    #opts = getOptionalParams(pRequest)
    #opts = remove_params_for_aurora(opts)
    opts = {}
    resp, errors = is_self_implementable_pad(pRequest, opts, pad)
    return RestResponse({'details': resp},error = errors)


@user_passes_test(lambda u: u.get_profile().edit_pad_perm)
def site_edit(pRequest, pad=None, production=False):
    """REST interface for modifying an existing pad or create a new PAD
    if pad == None then this is an add, otherwise it is an edit
    if production==True then this is adding a production domain not a draft
    """
    opts = getOptionalParams(pRequest)
    opts = remove_params_for_aurora(opts)

    if pRequest.session.get('aurora_editable', True):
        resp, errors = site_add_or_edit(pRequest, opts, pad)
    else:
        resp, errors = '', 'Your user account does not have sufficient permissions to access this API - Contact Support'

    if resp and errors:
        return RestResponse({'details': resp}, error =errors, status=400)
    elif resp:
        return RestResponse({'details': resp},error = errors)
    else:
        return RestResponse({}, error = errors, status=400)

@user_passes_test(lambda u: u.get_profile().edit_pad_perm)
def site_edit_v2(pRequest, pad=None, production=False):
    """REST interface for modifying an existing pad or create a new PAD
    if pad == None then this is an add, otherwise it is an edit
    if production==True then this is adding a production domain not a draft
    """
    errors = {}
    resp = ''
    opts = getOptionalParams(pRequest)
    opts = remove_params_for_aurora(opts)
    if pad:
        draft = get_draft_or_api_exception(pRequest, pad)
        opts = remove_params_for_request_implementation(opts, draft)
        if not draft.is_modifiable():
            resp = ""
            errors = {'general': "Unable to modify. PAD is currently in %s" % draft.get_pad_status()}
        if draft.is_waiting_implementation():
            resp = ""
            errors = {'general': "Unable to modify. PAD is currently in %s" % draft.get_pad_status()}

    if not errors:
        if pRequest.session.get('aurora_editable', True):
            resp, errors = site_add_or_edit_v2(pRequest, opts, pad)
        else:
            resp, errors = '', 'Your user account does not have sufficient permissions to access this API - Contact Support'

    if resp and errors:
        return RestResponse({'details': resp}, error =errors, status=400)
    elif resp:
        return RestResponse({'details': resp},error = errors)
    else:
        return RestResponse({}, error = errors, status=400)


@user_passes_test(lambda u: u.get_profile().edit_pad_perm)
def site_request_implement(pRequest, pad=None):
    errors = {}
    resp = ''
    opts = getOptionalParams(pRequest)
    opts = remove_params_for_aurora(opts)
    if pad:
        draft = get_draft_or_api_exception(pRequest, pad)
        opts = remove_params_for_request_implementation(opts, draft)
        comment = opts.get('comment',None)
        pad_status = draft.get_pad_status()
        if pad_status in REQUEST_IMPLEMENT_READY:
            if draft.is_self_implementable():
                resp = ''
                errors = {'general': "Unable to request implementation. PAD is self implementable. Please refer to API manual for the details."}

            if not errors:
                aurora_user_id = pRequest.session.get('aurora_user_id','')
                user_email = pRequest.user.email
                if pRequest.session.get('aurora_editable', True):
                    resp, warning, error = draft.request_implement_pad(aurora_user_id,user_email,comment)
                    if len(error) > 0:
                        errors.update({'general': error})
                    #send_draft_implementation_mail(pRequest)
                    if len(warning) > 0:
                        errors.update(({'warning': warning}))
                else:
                    resp, errors = '', 'Your user account does not have sufficient permissions to access this API - Contact Support'
        elif pad_status == DEPLOY_STATUS_WAITING_REQ:
            resp = "Already implementation request for PAD is accepted. status: %s" % pad_status
        else:
            resp = ''
            if draft.local_changes():
                errors = {'general': "Unable to request implementation. Deploy status: %s" % pad_status}
            else:
                errors = {'general': "Unable to request implementation. No changes. Deploy status: %s" % pad_status}
    if resp and errors:
        return RestResponse({'details': resp}, error =errors, status=400)
    elif resp:
        return RestResponse({'details': resp},error = errors)
    else:
        return RestResponse({}, error = errors, status=400)

@user_passes_test(lambda u: u.get_profile().edit_pad_perm)
def site_cancel_request_implement(pRequest, pad=None):
    errors = {}
    resp = ''
    opts = getOptionalParams(pRequest)
    opts = remove_params_for_aurora(opts)
    if pad:
        draft = get_draft_or_api_exception(pRequest, pad)
        opts = remove_params_for_request_implementation(opts, draft)
        comment = opts.get('comment',None)
        if draft.get_pad_status() not in ['Waiting Request Implementation']:
            resp = 'Unable to cancel request implementation.'
            errors = {'pad_status': "PAD is currently in %s" % draft.get_pad_status()}
        else:
            aurora_user_id = pRequest.session.get('aurora_user_id','')
            user_email = pRequest.user.email
            if pRequest.session.get('aurora_editable', True):
                resp, warning, error = draft.cancel_request_implement(aurora_user_id,user_email,comment)
                if len(error) > 0:
                    errors.update({'general': error})
                if len(warning) > 0:
                    errors.update(({'warning': warning}))
            else:
                resp, errors = '', 'Your user account does not have sufficient permissions to access this API - Contact Support'

    if resp and errors:
        return RestResponse({'details': resp}, error =errors, status=400)
    elif resp:
        return RestResponse({'details': resp},error = errors)
    else:
        return RestResponse({}, error = errors, status=400)

@user_passes_test(lambda u: u.get_profile().edit_pad_perm)
def site_version_restore(pRequest, pad):
    errors = {}
    result_dict = {}
    opt_params = getOptionalParams(pRequest)
    drafts = get_draft_or_api_exception(pRequest, pad, as_query=True)
    error = ''
    message = ''
    if opt_params.has_key('version'):
        version = opt_params.get('version', None)
        opt_params.pop('version')
    else:
        version = None
    try:
        if version is not None:
            version = int(version)
    except ValueError:
        errors['version'] = "Invalid version input."
    else:
        if drafts.exists():
            try:
                if drafts[0].product and not drafts[0].product.active:
                    error = "Product is expired. If you want to proceed, please contact support center."
                else:
                    username = pRequest.session["aurora_user_id"]
                    latest_version, previous_version = CustomerSiteChangeHistory.get_latest_versions(drafts[0])
                    if version is None:
                        version = previous_version

                    if version is None:
                        error = "There is no version to restore."
                    else:
                        if int(version) == int(latest_version):
                            error = "Can not be restored. Version is latest version."
                        else:
                            error, message = drafts[0].restore_from_snapshot(version, username)
            except CustomerSiteChangeHistory.DoesNotExist:
                error = "Access with invalid PAD configuration version"
            except TypeError:
                error = "Version %s PAD configuration has problem. Please contract CDNetworks technical support team" % (version)
            except Exception, e:
                # TODO : add logging
                error = "System internal error"
            if len(error) > 0:
                errors.update({'general': error})
        else:
            errors['pad'] = "Invalid PAD name input."

    if errors:
        return RestResponse(result_dict,error=errors, status=400)
    else:
        result_dict.update({'details':message})
        return RestResponse(result_dict,error=errors)

@user_passes_test(lambda u: u.get_profile().edit_pad_perm)
def site_delete(pRequest, pad=None):
    opts = getOptionalParams(pRequest)
    opts = remove_params_for_aurora(opts)

    if pad:
        draft = get_draft_or_api_exception(pRequest, pad)
    else:
        resp = ''
        errors = 'PAD input missing'
        draft = None

    if pRequest.session.get('aurora_editable', True):
        if draft:
            site = draft.get_site()
            if site and site.status:
                resp = ''
                errors = 'PAD is not deletable. It should be disabled first or not be published to production.'
            else:
                if draft.product and not draft.product.active:
                    resp = ""
                    errors = "Product is expired. If you want to proceed, please contact support center."
                else:
                    if draft.is_deletable():
                        resp = "'%s' has been deleted." % draft.pad
                        draft.delete()
                        errors = ''
                    else:
                        resp = ""
                        errors = "Unable to delete. PAD is currently in %s" % draft.get_pad_status()
    else:
        resp, errors = '', 'Your user account does not have sufficient permissions to access this API - Contact Support'

    if resp and errors:
        return RestResponse({'details': resp}, error =errors, status=400)
    elif resp:
        return RestResponse({'details': resp},error = errors)
    else:
        return RestResponse({}, error = errors, status=400)

def site_list(pRequest):
    #TODO: support search filter
    #TODO: pagination ==> let's add v2 version
    error = {}
    info = False
    opt_params = getOptionalParams(pRequest)
    opt_params = remove_params_for_aurora(opt_params)
    info = is_param_request(opt_params, 'info')
    verbose = is_param_request(opt_params, 'verbose')
    if opt_params.has_key('fields'):
        fields = opt_params.get('fields', None)
        opt_params.pop('fields')
        if fields:
            fields = fields.split(",")
    else:
        fields = []

    if is_param_request(opt_params, 'prod'):
        pads = get_site_pads(pRequest, opt_params, info=info, verbose=verbose, fields=fields)
    else:
        pads = get_draft_pads(pRequest, opt_params, info=info, verbose=verbose, fields=fields)

    if len(opt_params) > 0:
        error['unknown_parameter(s)'] = "The following parameters were not handled: " + opt_params.urlencode()

    if error:
        return RestResponse(pads,error=error, status=400)
    else:
        return RestResponse(pads,error=error)

def get_draft_pads(pRequest, opt_params, info=False, verbose=False, fields=[]):
    """
    add deploy status
    :param pRequest:
    :param opt_params:
    :param info:
    :param verbose:
    :param fields:
    :return:
    """
    pads = get_allowed_drafts(pRequest)
    model = SiteDraft

    sql = "select `customer_product`.`cop_product_id` from `customer_product` where `customer_product`.`product_id`= `customer_site_cui`.`product_id`"
    if info:
        tuples = getFieldsFromFieldset(SiteDraft.cui_stat_fields) + SiteDraft.papi_editable_fields + ('id','pad','product',)
        if fields:
            for field in fields:
                if field not in tuples:
                    raise Exception("Unknown field name %s" % field)
                tuples = tuple(fields)
        pads = pads.extra(select={'product':sql}).values(*tuples)
        pads = popAndFilter(opt_params, pads, 'origin', 'origin__in', expectslist=True)
        pads = values_replace_choice(pads, model)
    else:
        if verbose:
            pad_list = []
            #pads = pads.extra(select={'product':sql}).values('id','pad','origin','product')
            if opt_params.has_key('origin'):
                origin_params = opt_params.pop('origin')
            else:
                origin_params = None
            draft_groups_values, count_dict = draft_groups_for_query(pads.values_list('id', flat=True), verbose=verbose, origin=origin_params)
            for draft_groups in draft_groups_values:
                for draft_values in draft_groups[1]:
                    pad_list.append({'deploy_status':draft_groups[0],
                                     'id':draft_values[0],
                                     'pad':draft_values[1],
                                     'origin':draft_values[2],
                                     'description':draft_values[4],
                                     'product':draft_values[5]})
            pads = pad_list
        else:
            pads = pads.values('id','pad','origin')
            pads = popAndFilter(opt_params, pads, 'origin', 'origin__in', expectslist=True)
            pads = values_replace_choice(pads, model)
    return pads

def get_site_pads(pRequest, opt_params, info=False, verbose=False, fields=[], origin_params=None):
    pads = get_allowed_sites(pRequest, include_inactive=True)
    sql = "select `customer_product`.`cop_product_id` from `customer_product` where `customer_product`.`product_id`= `customer_site`.`product_id`"
    model = Site
    if info:
        tuples = tuple(set(getFieldsFromFieldset(SiteDraft.fieldsets)).difference(SiteDraft.api_view_blacklist)) + ('product',)
        if fields:
            for field in fields:
                if field not in tuples:
                    raise Exception("Unknown field name %s" % field)
                tuples = tuple(fields)
        pads = pads.extra(select={'product':sql}).values(*tuples)
    else:
        if verbose:
            pads = pads.extra(select={'product':sql}).values('id','pad','origin','product')
        else:
            pads = pads.values('id','pad','origin')
    pads = popAndFilter(opt_params, pads, 'origin', 'origin__in', expectslist=True)
    pads = values_replace_choice(pads, model)
    return pads


def is_param_request(opt_params, param):
    """
    check parameter value exists and check boolean propertry. pop parameter
    :param opt_params:
    :param param:
    :return:
    """
    if opt_params.has_key(param):
        is_prod= opt_params.pop(param)
        if is_prod == [u"1"] or is_prod ==[u'True']:
            return True
    return False

def site_view(pRequest, pad):
    error = {}
    opt_params = getOptionalParams(pRequest)
    opt_params = remove_params_for_aurora(opt_params)

    if is_param_request(opt_params, 'prod'):
        site_tuples = tuple(set(getFieldsFromFieldset(SiteDraft.fieldsets)).difference(SiteDraft.api_view_blacklist))
        pad = get_site_or_api_exception(pRequest, pad, as_query=True).values(*site_tuples)
        model = Site
        pad = values_replace_choice(pad, model)
    else:
        draft_tuples = (SiteDraft.cui_editable_fields + getFieldsFromFieldset(SiteDraft.cui_stat_fields))
        drafts = get_draft_or_api_exception(pRequest, pad, as_query=True)
        pad = drafts.values(*draft_tuples)
        model = SiteDraft
        pad = values_replace_choice(pad, model)
        pad[0].update(drafts[0].get_additional_values_for_customer(info=True))

    if len(opt_params) > 0:
        error['unknown_parameter(s)'] = "The following parameters were not handled: " + opt_params.urlencode()
    return RestResponse(pad[0],error=error)

def site_trace_internal(pRequest, pad):
    """
    oui/api server need to be able to access to testable staging edge nodes where PAD configuration is deployed.
    if 'body_contents' exists, request method to edge server will be 'POST', otherwise 'GET'
    The term 'trace internal' is internal and not used for customer, use 'Staging test' instead.
    :param pRequest:
    :param pad:
    :return:PAD name
    """
    error_dict = {}
    opt_params = getOptionalParams(pRequest)
    opt_params = remove_params_for_aurora(opt_params)
    drafts = get_draft_or_api_exception(pRequest, pad, as_query=True)

    url = opt_params.get('url',opt_params.get('uri',''))
    ipv4 = opt_params.get('ipv4', None)
    additional_headers = opt_params.get('additional_headers','')
    filename = opt_params.get('filename','')
    file_contents = opt_params.get('body_contents',opt_params.get('file_contents',None))
    ipaddr = ipv4
    pad_status = drafts[0].get_pad_status()
    if drafts[0].is_self_implementable():
        if pad_status == 'On Staging':
            if drafts[0].has_testable_staging_node():
                error, result, raw_result, hostname, ipaddr = drafts[0].fetch_trace_internal_result(url,
                                                                                        additional_headers,
                                                                                        filename, file_contents, ipv4)
            else:
                error = "Please wait until PAD configuration is pushed to test nodes. " \
                        "It may take minutes until PAD configuration to be deployed to test nodes after PAD status just turned into 'On Staging'."
        else:
            error = "Not supported. PAD deploy status should be 'On Staging'. PAD status:%s" % (pad_status)
    else:
        error = "Not supported. PAD is not self implementable. PAD status:%s" % (pad_status)

    if error and len(error.strip()) > 0:
        error_dict.update({'general':error})
        result_dict = {'url':url, 'ipv4':ipaddr, 'result':''}
    else:
        result_dict = {'url':url, 'ipv4':ipaddr, 'result':result}

    if settings.DEBUG and opt_params.get('debug'):
        result_dict.update({'raw_result': raw_result})

    if error_dict:
        return RestResponse(result_dict,error=error_dict, status=400)
    else:
        return RestResponse(result_dict,error=error_dict)

def site_version_compare(pRequest, pad):
    errors = {}
    opt_params = getOptionalParams(pRequest)
    drafts = get_draft_or_api_exception(pRequest, pad, as_query=True)
    if opt_params.has_key('version'):
        version = opt_params.get('version', None)
        opt_params.pop('version')
    else:
        version = None

    result_dict = {}
    try:
        if version is not None:
            version = int(version)
    except ValueError:
        errors['version'] = "Invalid version input."
    else:
        if drafts.exists():
            change_histories = CustomerSiteChangeHistory.objects.filter(sitedraft=drafts[0]).order_by('-pk')
            if change_histories.exists():
                try:
                    current_version = change_histories[0].version
                    if version:
                        version_histories = change_histories.filter(version=version)
                        if version_histories.exists():
                            current_dict = change_histories[0].get_snapshot_data()
                            target_dict = version_histories[0].get_snapshot_data()
                            diff_dict_with_current = dict_diff(target_dict,current_dict)
                            result_dict =version_histories[0].get_values_for_customer(latest_version=current_version,
                                                                                      diff_dict_with_latest=diff_dict_with_current,
                                                                                      snapshot=target_dict,
                                                                                      display_snapshot=True)
                        else:
                            target_dict = {}
                        if not target_dict:
                            errors.update({'general': "Snapshot data for target version '%s' does not exist. Nothing to compare." % version})
                    else:
                        #if version input missing, return diff with previous change history
                        if change_histories.count() > 1:
                            result_dict = change_histories[1].get_values_for_customer(latest_version=current_version)
                        else:
                            result_dict = change_histories[0].get_values_for_customer(latest_version=current_version)
                except Exception,e:
                    errors.update({'general':"System internal error"})
            else:
                errors.update({'general':"There is no PAD change version history."})

    if errors:
        return RestResponse(result_dict,error=errors, status=400)
    else:
        return RestResponse(result_dict,error=errors)


def site_version_history(pRequest, pad):
    error = {}
    drafts = get_draft_or_api_exception(pRequest, pad, as_query=True)
    result_list = []

    if drafts.exists():
        next_dict = {}
        try:
            change_histories = CustomerSiteChangeHistory.objects.filter(sitedraft=drafts[0]).order_by('-pk')[:31]
            idx = 1
            for change_history in change_histories:
                current_dict = change_history.get_snapshot_data()
                if next_dict:
                    diff_dict = dict_diff(current_dict,next_dict)
                    result_list.append(previous_change_history.get_values_for_customer(diff_dict=diff_dict))

                if change_histories.count() == idx:
                    result_list.append(change_history.get_values_for_customer())

                previous_change_history = change_history
                next_dict = current_dict
                idx += 1
        except Exception,e:
            error = "System internal error"

    if error:
        return RestResponse(result_list,error=error, status=400)
    else:
        return RestResponse(result_list,error=error)

def preheat_api(pRequest):
    error = {}
    passObjects = {}
    additionalObjects = {}
    opt_params = getOptionalParams(pRequest)
    prefixName = "preheat"
    visible_to_user = False
    authorized = False

    action = pRequest.POST.get('action')

    if action not in ("filter", "Preheat File(s)"):
        return  RestResponse({'details':"action is required"})

    if action == 'filter':
        if (not opt_params.has_key('filter_by_url') and not opt_params.has_key('filter_by_customer')) or (pRequest.POST.get('filter_by_url','') == '' and pRequest.POST.get('filter_by_customer','') == ''):
            return  RestResponse({'details':"one of filter_by_url or filter_by_customer is required"})

    if action == 'Preheat File(s)':
        if (not opt_params.has_key('urls') and not opt_params.has_key('compareHeaders')) or (pRequest.POST.get('compareHeaders','') == '' and pRequest.POST.get('urls','') == ''):
            return  RestResponse({'details':"urls and compareHeaders are required"})    

    if pRequest.POST.get('filter_by_url', '') != '' or pRequest.POST.get('urls', '') != '':    
        try:
            if action == "Preheat File(s)":
                url = pRequest.POST.get('urls')
            if action == "filter":
                url = pRequest.POST.get('filter_by_url')
            urlComponents = supporttoolsParseURL(url)
            site = Site.objects.get(pad=urlComponents['domain'])
        except:
            site = None
    
        if site:
            if (pRequest.user.get_profile().customer == site.customer and not pRequest.user.is_staff) or pRequest.user.is_staff:
                authorized = True
            else:
                error['general'] = "request url not allowed"        
        else:
            error['general'] = "request url not matched"


    if pRequest.POST.get('filter_by_customer','') != '' and not error.has_key('general'):
        if pRequest.user.get_profile().customer.name != pRequest.POST.get('filter_by_customer') and not pRequest.user.is_staff:
            error['general'] = "request customer not matched"
            authorized = False            
        else:
            authorized = True


    if authorized and pRequest.POST and action == "Preheat File(s)":
        uri = "/rest/request/preheat/?auth_key=" + SUPPORT_AUTHENTICATION_KEY
        additionalObjects =  supporttoolsGenericSubmission(pRequest, Site.objects, prefixName, visible_to_user, uri)

    if authorized and pRequest.POST and action == "filter":
        passObjects = supporttoolsPreheatListRetrieve(pRequest.POST)
        if passObjects.has_key('filter_form'):
            del passObjects['filter_form']

    passObjects = mergeDictionaries(passObjects, additionalObjects)
    return RestResponse(passObjects, error = error)


def preheatinfo_api(pRequest):
    error = {}
    passObjects = {}    
    opt_params = getOptionalParams(pRequest)
    prefixName = "preheat"
    visible_to_user = False
    queryString = ""

    object_id = pRequest.POST.get('id')

    if not opt_params.has_key('id') or not opt_params.has_key('url'):
        return  RestResponse({'details':"id and url are required"})        

    try:
        submittedUrl_req = pRequest.POST.get('url')
        urlComponents = supporttoolsParseURL(submittedUrl_req)
        site = Site.objects.get(pad=urlComponents['domain'])

        if pRequest.user.get_profile().customer != site.customer and not pRequest.user.is_staff:
            site = None
    except:
        site = None

    if site:
        authQueryString = "auth_key=" + SUPPORT_AUTHENTICATION_KEY
        uri = "/rest/get/preheat/" + object_id + "/" + concatQueryStrings(queryString,authQueryString)
        respObj = handleHttpGetConnection(SUPPORT_SERVER, uri)
        if not isinstance(respObj,dict) or respObj.has_key('error'):
            error['general'] = "api request error"

        if len(error) == 0:
            submittedUrl_res = ''
            if respObj.has_key('preheatStatus') and respObj['preheatStatus'].has_key('submittedUrl'):
                submittedUrl_res = respObj['preheatStatus']['submittedUrl']
            if submittedUrl_req != submittedUrl_res:            
                error['general'] = "request url not matched"
            else:
                passObjects = respObj
    else:
        error['general'] = "this url is not allowed"

    passObjects = mergeDictionaries(passObjects, {})
    return RestResponse(passObjects, error = error)


def originip_api(pRequest):
    opt_params = getOptionalParams(pRequest)
    if not opt_params.has_key('cdn_id'):
        return RestResponse({'status':1, 'error':'cdn_id is required'}, label=None, custom_mode=True)
    else:
        if opt_params.get('cdn_id') != '672367200':
            return RestResponse({'status':1, 'error':'Valid cdn_id is required'}, label=None, custom_mode=True)

    if opt_params.get('domain', '') == '':
        return RestResponse({'status':1, 'error':'domain is required'}, label=None, custom_mode=True)

    if opt_params.get('cdn_ip', '') == '':
        return RestResponse({'status':1, 'error':'cdn_ip is required'}, label=None, custom_mode=True)
    else:
        from ci.common.utils.ipaddr import IPAddress
        ip_addr = opt_params.get('cdn_ip', '')
        try:
            ip_addr = '.'.join([str(int(i)) for i in ip_addr.split('.')])
            IPAddress(ip_addr)
        except:
            return RestResponse({'status':1, 'error':'Valid cdn_ip is required'}, label=None, custom_mode=True)

    pa_domain = opt_params.get('domain')
    cdn_ip = ip_addr 

    if pa_domain[0] == '*':
        domains = [pa_domain]
    else:
        a_domain = ''
        sp_domain = pa_domain.split('.')
        for i in range(len(sp_domain)):
            if i == 0:
                a_domain += '*'
            else:
                a_domain += '.' + sp_domain[i]
        domains = [pa_domain, a_domain]    

    domain_found = False
    ip_found = False
    ip_list = ''
    error = []
    try:
        status = 0
        for domain in domains:
            if domain_found == False:
                sql = """
                    select customer_site_id, serve_domain, cdn_service_id, origin_ip from customer_site
                    where serve_domain = '%s'
                """%domain
    
                ret = processQuery(sql, mysql_params=MySQL_CHARTRON_DB, returnRows=True, isFailOver2Default=True)
        
                if len(ret) == 1:
                    domain_found = True
                    cdn_service_id = ret[0][2]
                    origin_ip = ret[0][3]

                    sql = """
                        SELECT distinct `node`.`pop_id`, `cdn_service`.`cdn_service_id`, `node_ip`.ipv4_address
                        FROM `cdn_service` INNER JOIN `cdndomain_band` ON (`cdn_service`.`cdn_service_id` = `cdndomain_band`.`cdn_service_id`) 
                        INNER JOIN `band` ON (`cdndomain_band`.`band_id` = `band`.`id`) 
                        INNER JOIN `band_node` ON (`band`.`id` = `band_node`.`band_id`)
                        INNER JOIN `node_ip` ON (`band_node`.`node_ip_id` = `node_ip`.`id`)
                        INNER JOIN `node` ON (`node_ip`.`node_id` = `node`.`node_id`)
                        INNER JOIN `pop` ON (`node`.`pop_id` = `pop`.`pop_id`) 
                        INNER JOIN `region` ON (`pop`.`region_id` = `region`.`region_id`) 
                        WHERE (`cdn_service`.`status` = True ) 
                        AND `pop`.importance > -1 and `pop`.pop_type_id = 1
                        AND `cdn_service`.CDN_SERVICE_ID = %d
                        AND `pop`.REGION_ID in (11,12,13)
                    """%cdn_service_id

                    ret = processQuery(sql, mysql_params=MySQL_CHARTRON_DB, returnRows=True, isFailOver2Default=True)
    
                    for ip in ret:
                        if ip_found == False and cdn_ip == ip[2]:
                            ip_found = True
                            break

                    if ip_found:
                        if origin_ip and len(origin_ip) > 0:
                            ip_list = origin_ip
                        else:
                            lookup_command = 'host -t a %s'%domain
                            ips = pexpect.run(lookup_command, timeout=3)
                            if ips.find('has no A record') == -1:                            
                                ips_arr = ips.split('\n')
                                for ip_each in ips_arr:
                                    if ip_each.find('has address') > 0:
                                        each_item = ip_each.split(' ')
                                        ip_list = each_item[len(each_item)-1].strip()
                                        break
                            else:
                                ip_list = ips.strip()

    except:
        status = 1
        error.append('fail searching')

    api_result = {}
    api_result['status'] = status
    if len(error) > 0:
        api_result['error'] = error
    else:
        api_result['infos'] = {'source_ipaddr': ip_list}
    return RestResponse(api_result, label=None, custom_mode=True)
