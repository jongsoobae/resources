from django import forms
from django.contrib.auth.decorators import user_passes_test
from ci.common.forms.support import create_support_ticket
from ci.common.models.alert import Alert
from api.rapi.utils import RestResponse, getOptionalParams
from datetime import datetime, timedelta

URGENT_TICKET_LIMIT = 5
TOTAL_TICKET_LIMIT = 10

@user_passes_test(lambda u: u.get_profile().support_perm)
def ticket_add(pRequest, issue_type):
	opts = getOptionalParams(pRequest)
	opts['issue'] = issue_type
	#check if over rate limit for urgent....
	if opts.get('urgent',None) == '1' and Alert.objects.filter(user=pRequest.user, create_time__gt = datetime.now() - timedelta(days=1), urgent = True).count() >= URGENT_TICKET_LIMIT:
		return RestResponse({}, error = "This account is over its limit for urgent tickets via API. Please submit ticket as non-urgent or via the website.", status = 406)
	if Alert.objects.filter(user=pRequest.user, create_time__gt = datetime.now() - timedelta(days=1)).count() >= TOTAL_TICKET_LIMIT:
		return RestResponse({}, error = "This account is over its limit for tickets via API. Please submit ticket via the website.", status = 406)
	resp = create_support_ticket(pRequest, post=opts)
	if not isinstance(resp,forms.Form):
		RestResponse(resp)
	errors = {}
	if hasattr(resp,'errors') and len(resp.errors) > 0:
		for item, value in resp.errors.items():
			if item == "__all__":
				item = "general"
			errors[item] = value.as_text()
		return RestResponse({},error = errors, status=400)

	data = {'details': "Support ticket has been submitted.  A response will be sent to the email for this account shortly."}
	return RestResponse(data)
