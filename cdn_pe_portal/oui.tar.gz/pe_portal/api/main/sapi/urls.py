from django.conf.urls.defaults import *

urlpatterns = patterns('api.sapi.views.content',
	(r'^cdn/content/expire/$', 'expire'),
)

urlpatterns += patterns('api.sapi.views.site',
	(r'^cdn/site/add/$', 'add'),
)

#legacy soap urls...eventually these will be phased out
from ui.soap import views
from ui.soap.views.BandwidthUse_server import BandwidthUseService
from ui.soap.views.CacheFlushValue_server import CacheFlushValueService
from ui.soap.views.CacheFlushAll_server import CacheFlushAllService
from ui.soap.views.PadServices_server import PadServices
from ui.soap.views.CacheServices_server import CacheServices
urlpatterns += patterns('ui.soap.views',
	url('bandwidthuse', 'common.soap_response', {'service': BandwidthUseService()}, 'bandwidthuse'),
	url('cacheflushvalue', 'common.soap_response', {'service': CacheFlushValueService()}, 'cacheflushvalue'),
	url('cacheflushall', 'common.soap_response', {'service': CacheFlushAllService()}, 'cacheflushall'),
	url('cacheflush', 'common.soap_response', {'service': CacheServices()}, 'cache_webservice'),
	url('pad', 'common.soap_response', {'service': PadServices()}, 'pad_webservice'),
)
