from django.http import HttpResponse
from ZSI import SoapWriter, ParsedSoap

class SoapResponse(HttpResponse):
	def __init__(self, content):
		sw = SoapWriter()
		sw.serialize(content)
		sw.close
		HttpResponse.__init__(self, content=str(sw),mimetype='text/xml')

def get_soap_username_password(request):
	"""Returns tuple of username/password and sets request.parsedsoap"""

	#get usernam and password from request...
	try:
		request.parsedsoap = ParsedSoap(request.raw_post_data)
		command_name = request.parsedsoap.body_root.nodeName
                # trim the namespace portion
                if ':' in command_name:
                        command_name = command_name[command_name.index(':')+1:]
		request.path += command_name + "/"
		request.META['PATH_INFO'] += command_name + "/"
		request.path_info += command_name + "/"
		return (request.parsedsoap.body_root.getElementsByTagName('username')[0].firstChild.nodeValue, 
			request.parsedsoap.body_root.getElementsByTagName('password')[0].firstChild.nodeValue)
	except Exception, e:
		return None, None

