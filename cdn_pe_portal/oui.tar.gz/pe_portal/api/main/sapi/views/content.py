from ui.soap.views import new_cache_flush
from api.sapi.utils.Content_server import Content

def expire(request):
	soap_request, soap_response = Content.soap_expire(request.parsedsoap)
	id= new_cache_flush(soap_request, soap_response, type_attribute="type")
	if id != None:
		soap_response.expireId = long(id)
	else:
		soap_response.expireId = long(-1)
