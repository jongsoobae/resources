from ui.soap.views import create_pad, duplicate_pad
from api.sapi.utils.Site_server import Site

def add(request):
	soap_request, soap_response = Site.soap_add(request.parsedsoap)
	if soap_request.sourcePad == None or soap_request.sourcePad.strip() == "":
		id = create_pad(soap_request, soap_response)
	else:
		id = duplicate_pad(soap_request, soap_response)
	soap_response.siteId = id
