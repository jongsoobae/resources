# Django settings for api project.

from ci.constants import API_DATABASE_USER, DATABASE_HOST, DATABASE_PORT, API_DATABASE_PASSWORD, TEMPLATE_DIRS, \
    CACHE_BACKEND, REDIS_SENTINEL_LOCATIONS, CACHE_LOCATIONS, \
	MEDIA_ROOT, MEDIA_URL, BASE_DIR, SEND_EMAIL, MySQL_AGGREGATE_DB, MySQL_CHARTRON_DB, DEBUG, READONLY_DB
import os

TEMPLATE_DEBUG = False
PROJECT_NAME = "PANTHER API"

DATABASES = {
	'default': {
		'NAME': 'centraldb',
		'ENGINE':'django.db.backends.mysql',
		'HOST': DATABASE_HOST,
		'PORT': DATABASE_PORT,
		'USER': API_DATABASE_USER,
		'PASSWORD': API_DATABASE_PASSWORD
			},
	'chartrondb': READONLY_DB
}

DATABASE_ROUTERS = ['ci.common.CDBRouter']

# Otherwise MyISAM is default
DATABASE_OPTIONS = {'charset': 'utf8', "init_command": "SET storage_engine=INNODB"}

# Local time zone for this installation. All choices can be found here:
# http://www.postgresql.org/docs/8.1/static/datetime-keywords.html#DATETIME-TIMEZONE-SET-TABLE
# If running in a Windows environment this must be set to the same as your
# system time zone.
TIME_ZONE = 'GMT'

# Language code for this installation. All choices can be found here:
# http://www.w3.org/TR/REC-html40/struct/dirlang.html#langcodes
# http://blogs.law.harvard.edu/tech/stories/storyReader$15
LANGUAGE_CODE = 'en-us'

SITE_ID = 1

# If you set this to False, Django will make some optimizations so as not
# to load the internationalization machinery.
USE_I18N = False

# Absolute path to the directory that holds media.
# Example: "/home/media/media.lawrence.com/"
# MEDIA_ROOT = ''

# URL that handles the media served from MEDIA_ROOT.
# Example: "http://media.lawrence.com"
# MEDIA_URL = ''

# URL prefix for admin media -- CSS, JavaScript and images. Make sure to use a
# trailing slash.
# Examples: "http://foo.com/media/", "/media/".
#ADMIN_MEDIA_PREFIX = '/media/'

# Make this unique, and don't share it with anybody.
SECRET_KEY = 'h8kile#8#5+_oh-vxr3u6+v(jf$kf%%kp9i^fcf16&-b+9q+2@'

# List of callables that know how to import templates from various sources.
TEMPLATE_LOADERS = (
	'django.template.loaders.filesystem.load_template_source',
	'django.template.loaders.app_directories.load_template_source',
	#'django.template.loaders.eggs.load_template_source',
)

MIDDLEWARE_CLASSES = (
	'django.middleware.common.CommonMiddleware',
	'api.middleware.APILoginMiddleware',
	'api.middleware.APIResponseMiddleware',
	'django.middleware.transaction.TransactionMiddleware',
)

#CACHE_MIDDLEWARE_SECONDS = 20
#CACHE_MIDDLEWARE_KEY_PREFIX = ''

ROOT_URLCONF = 'api.urls'

TEMPLATE_DIRS = TEMPLATE_DIRS


INSTALLED_APPS = (
    'django.contrib.auth',
    'django.contrib.admin',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.sites',
    'ui.cui', #this is just here until we deprecate the legacy rest apis
    'api.sapi',
    'api.rapi',
    'ci.common',
    'ci.django_mailer',
)

AUTHENTICATION_BACKENDS = (
    'api.backend.PantherAPIModelBackend',
	'django.contrib.auth.backends.ModelBackend',
)

INTERNAL_IPS = (
	'192.168.2.1',
	'127.0.0.1',
	'192.168.17.114',
	'::1' # localhost, in ipv6
)


TEMPLATE_CONTEXT_PROCESSORS = (
	"django.core.context_processors.auth",
	"django.core.context_processors.debug",
	"django.core.context_processors.i18n",
	"django.core.context_processors.media",
	"django.core.context_processors.request",
	"ci.common.context_processors.environment",
	"ci.common.context_processors.tzoffset",
)

TEMPLATE_DIRS = (
   	os.path.join(BASE_DIR, 'templates'),
)

SOAP_ROOT = '/soap/'
REST_ROOT = '/rest/'

STAFF_REST_LOGIN_REQUIRED = (
	r'^rest/int/',
)
STAFF_SOAP_LOGIN_REQUIRED = ()

#This can be removed once we revoke legacy api calls
LEGACY_PATHS = (
	r'^account/do-cache-flush/',
	r'^account/rest-custom-reports/',
	r'^soap/bandwidthuse',
	r'^soap/cacheflushvalue',
	r'^soap/cacheflushall',
	r'^soap/cacheflush',
	r'^soap/pad',
)
AUTH_PROFILE_MODULE = 'common.userprofile'

FIXTURE_DIRS = (
	os.path.join(BASE_DIR, 'fixtures'),
)

EMAIL_BACKEND = 'ci.django_mailer.smtp_queue.EmailBackend'
EMAIL_HOST = 'send.mx.cdnetworks.com'
EMAIL_PORT = 25
MAILER_LOCK_WAIT_TIMEOUT = 30

# Everyone in this list gets emailed when there's a 500 and DEBUG=False.
MANAGERS = ADMINS = (('Webmaster','eng-ui@cdnetworks.com'),)
EMAIL_SUBJECT_PREFIX = '[Django] '
SERVER_EMAIL = 'ui@pantherexpress.net'

REDIS_DEFAULT_TIMEOUT = 60
REDIS_CACHE_BACKEND = "ci.common.contrib.django_redis.cache.RedisCache"
REDIS_SENTINEL_OPTIONS = {
    "CLIENT_CLASS": "ci.common.utils.sentinel.SentinelClient",
    "PASSWORD":"cdnetworks"
}

CACHES = {
    'default': {
        'BACKEND': CACHE_BACKEND,
        'LOCATION': CACHE_LOCATIONS,
    },
    'redis': {
        'BACKEND': REDIS_CACHE_BACKEND,
        'LOCATION': REDIS_SENTINEL_LOCATIONS,
        'OPTIONS': REDIS_SENTINEL_OPTIONS,
    }
}
DEFAULT_THROTTLE_RATES = {}