import os, sys
import unittest
import requests

sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'api.settings'

from ci.common.utils.api.nodeip import ValidationException
from api.rapi.views.int.nodeip import validate_parameters

ID = 'jungho.park'
PW = 'cdnadmin'
#PRE_URL = 'https://pantherapi-qa.cdnetworks.com/rest/int/%s:%s/' % (ID, PW)
PRE_URL = 'http://10.40.196.147:8089/rest/int/%s:%s' % (ID, PW)

ADD_API_URL = '%s/nodeip_v6/register/' % PRE_URL
DELETE_API_URL = '%s/nodeip_v6/delete/' % PRE_URL
LIST_API_URL = '%s/nodeip_v6/list/' % PRE_URL


class TestNodeIPApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pass

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_add_valid(self):
        host = "h0-s201.p99-icn.cdngp.net"
        pair_list = [
            ["192.168.0.14", "2401:C500:003F:8200:0192:0168:0000:0014"]
        ]
        for pair in pair_list:
            res = self.send_post(host=host, pair=pair)
            print res.json()
            self.assertEqual(200, res.status_code)

            res = self.send_delete(host=host, pair=pair)
            print res.json()
            self.assertEqual(200, res.status_code)

    def test_add_client_error(self):
        host = "h0-s201.p99-icn.cdngp.net"
        pair_list = [
            ["192.168.0.14", ""],
            ["", "2401:C500:003F:8200:0192:0168:0000:0014"],
            ["", ""],
            ["192.168.0.14111", "2401:C500:003F:8200:0192:0168:0000:0014"],
            ["192.168.0.14", "2401:C500:003F:8200:0192:0168:0000:001411"],
            ["192.168.0.1412", "2401:C500:003F:8200:0192:0168:0000:001411"],
            ["192.168.0.14", "2401:C500:003F:8200:0192:0168:0000:0013"],
            ["192.168.255.255", "2401:C500:003F:8200:0192:0168:0255:0255"],  # not exist
        ]

        for pair in pair_list:
            res = self.send_post(host=host, pair=pair)
            print res.json()
            self.assertEqual(400, res.status_code)

    def test_add_server_error(self):
        pass

    def test_delete_client_error(self):
        host = "h0-s201.p99-icn.cdngp.net"
        pair_list = [
            ["192.168.0.14", "2401:C500:003F:8200:0192:0168:0000:0014"],
            ["192.168.255.255", "2401:C500:003F:8200:0192:0168:0255:0255"],
        ]

        for pair in pair_list:
            res = self.send_delete(host=host, pair=pair)
            print res.json()
            self.assertEqual(400, res.status_code)

    def test_delete_server_error(self):
        pass

    def test_list(self):
        host = "h0-s201.p99-icn.cdngp.net"
        res = self.send_list(host=host)
        if 'data' in res.json() and type(res.json()['data']) == list:
            self.assertTrue(True)
        else:
            self.fail('LIST API is wrong.')

    def test_ipv4_check_fail(self):
        ip_list = [
            "",
            "1",
            "1.1",
            "1.1.1",
            "1.1.1.1.1",
            "1,1,1,1",
            "-1.1.1.1",
            "1.-1.1.1",
            "1.1.-1.1",
            "1.1.1.-1",
            "256.1.1.1",
            "a.1.1.1",
            "A.1.1.1",
            "!.1.1.1"
        ]

        for ip in ip_list:
            try:
                self.ipv4_check(ip)
                self.fail('ipv4 valid check fail.')
            except ValidationException:
                self.assertTrue(True)

    def test_ipv4_check_success(self):
        ip_list = [
            "1.1.1.1",
            "255.255.255.255"
        ]

        for ip in ip_list:
            try:
                self.ipv4_check(ip)
                self.assertTrue(True)
            except ValidationException:
                self.fail('ipv4 valid check fail.')

    def test_ipv6_check_fail(self):
        ip_list = [
            "2001:0DB8:0:0:0:0:1428:-1",
            "2001:0DB8:0:0:0:0:1428:1G",
        ]

        for v6 in ip_list:
            try:
                self.ipv6_check(v6)
                self.fail('Error!! %s ipv6 is valid.' % v6)
            except ValidationException:
                self.assertTrue(True)

    def test_ipv6_check_success(self):

        ip_list = [
            "2001:0DB8:0000:0000:0000:0000:1428:57AB",
            "2001:0DB8:0:0:0:0:1428:57AB",
            "2001:0DB8::1428:57AB",
            "2001:0DB8:0000:0000:0000::1428:57AB",
            "2001:0DB8:0::0:1428:57AB",
            "2001:0DB8:0:0:0:0:1428:57AB",
        ]

        for v6 in ip_list:
            try:
                self.ipv6_check(v6)
                self.assertTrue(True)
            except ValidationException:
                self.fail('Error!!. %s ipv6 is invalid.' % v6)

    @classmethod
    def ipv4_check(cls, v4):
        d = {
            'hostname': 'h0-s201.p99-icn.cdngp.net',
            'pair': [v4, "2401:C500:003F:8200:0192:0168:0000:0014"]
        }
        validate_parameters(d)

    @classmethod
    def ipv6_check(cls, v6):
        d = {
            'hostname': 'h0-s201.p99-icn.cdngp.net',
            'pair': ["192.168.0.14", v6]
        }
        validate_parameters(d)

    @classmethod
    def send_post(cls, host, pair):
        send_object = {
            "hostname": host,
            "pair": pair
        }

        return requests.post(ADD_API_URL, json=send_object)

    @classmethod
    def send_delete(cls, host, pair):
        send_object = {
            "hostname": host,
            "pair": pair
        }

        return requests.post(DELETE_API_URL, json=send_object)

    @classmethod
    def send_list(cls, host):
        send_object = {
            "hostname": host
        }

        return requests.post(LIST_API_URL, json=send_object)

if __name__ == '__main__':
    unittest.main()
