from django.conf.urls.defaults import *
from django.contrib import admin
from ci.constants import DEBUG, BASE_DIR
import os

#as we do not know response type can not just give a generic html error file
handler404 = "ci.common.utils.api.page_not_found"
handler500 = "ci.common.utils.api.server_error"

urlpatterns = patterns('',
	(r'^soap/', include('api.sapi.urls')),
	(r'^rest/', include('api.rapi.urls')),
)

#These are legacy rest calls in the account level.  Can be removed once we stop supporting older apis
urlpatterns += patterns('ui.cui.views.flush',
	(r'^account/do-cache-flush/(?P<input_string>.*)$', 'rest_cache_flush'),
)

urlpatterns += patterns('ui.cui.views.aggregate',
	(r'^account/rest-custom-reports/(?P<input_string>.*)$', 'restAggregateReport'),
)
