from ci.constants import ENVIRONMENT
from django.core.exceptions import ObjectDoesNotExist
from ci.common.models.status import SystemStatus
from ci.common.utils import get_customer

def environment(request):
	return {'environment': ENVIRONMENT}

def tzoffset(request):
	"""
	Add a floating-point number to the template context, the offset, in hours,
	of the logged-in user's timezone from GMT.  E.g., in India {{ tzoffset}}
	would be rendered as "5.5"
	"""
	return {'tzoffset': request.session.get('tzo', None) }

def customer(request):
	return {'customer': get_customer(request)}

def status(request):
	#This will return non or the last current urgent message if one.
	try:
		return {'urgent': SystemStatus.objects.filter(active=True,urgent=True,oui_only=False).latest('create_time')}
	except:
		return {'urgent': None}

