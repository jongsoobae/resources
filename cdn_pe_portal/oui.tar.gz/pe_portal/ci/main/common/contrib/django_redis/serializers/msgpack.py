# -*- coding: utf-8 -*-

from __future__ import absolute_import, unicode_literals
from .base import BaseSerializer


class MSGPackSerializer(BaseSerializer):
    def dumps(self, value):
        raise Exception('Not implemented')

    def loads(self, value):
        raise Exception('Not implemented')
