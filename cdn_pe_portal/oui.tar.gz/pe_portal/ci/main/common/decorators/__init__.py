#-*- coding: utf-8 -*-
import datetime
import json
import inspect
from functools import wraps
from django.http import Http404, HttpResponseRedirect, HttpResponseBadRequest,HttpResponseForbidden
from django.conf import settings
from ci.common import exceptions
from ci.common.utils.util_common import log_error as _log_error

def log_exception(msg='', default_return_value='__ignore__', send_mail=False):
    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception,e:
                try:
                    function_args, vargs, keywords, defaults = inspect.getargspec(func)
                    parameter_context = dict(zip(function_args, args))
                    parameter_context.update({'function': func.func_name})
                    _log_error(message=msg, e=e, context=parameter_context, sendemail=send_mail)
                    if default_return_value != '__ignore__':
                        return default_return_value
                except:
                    pass
        return wrapper
    return decorator

def throttled(request, wait):
    """
    If request is throttled, determine what kind of exception to raise.
    """
    e = exceptions.ThrottledException(wait)
    _log_error(e.detail,e, request)
    raise e

def throttle_classes(throttle_classes, scope=None):
    def decorator(func):
        func.throttle_classes = throttle_classes
        def wrapper_func(request, *args, **kwargs):
            retval = func(request, *args, **kwargs)
            if not func.throttle_classes:
                return retval

            for throttle in func.throttle_classes:
                throttle_ins = throttle()
                if throttle_ins.allow_request(request, scope):
                    continue
                try:
                    throttled(request, throttle_ins.wait())
                except:
                    errmsg = """403 Error: Your account is temporarily blocked for login.
                    Please wait until the lock is released.
                    """
                    return HttpResponseForbidden(errmsg)
            return retval
        return wrapper_func
    return decorator

