from __future__ import unicode_literals
from utils import http_status as status
import math


class RestAPIException(Exception):
    """
    Base class for REST API exceptions.
    Subclasses should provide `.status_code` and `.default_detail` properties.
    """
    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    default_detail = ''

    def __init__(self, detail=None):
        self.detail = detail or self.default_detail

class ThrottledException(RestAPIException):
    status_code = status.HTTP_429_TOO_MANY_REQUESTS
    default_detail = 'Request was throttled.'
    extra_detail = "Expected available in %d second%s."

    def __init__(self, wait=None, detail=None):
        if wait is None:
            self.detail = detail or self.default_detail
            self.wait = None
        else:
            format = (detail or self.default_detail) + self.extra_detail
            self.detail = format % (wait, wait != 1 and 's' or '')
            self.wait = math.ceil(wait)