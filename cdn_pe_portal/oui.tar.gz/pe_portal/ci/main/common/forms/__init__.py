from django.utils.encoding import StrAndUnicode, force_unicode
from django.forms.widgets import RadioInput
from django.utils.safestring import mark_safe



class FlatRadioFieldRenderer(StrAndUnicode):
    """
    An object used by RadioSelect to enable customization of radio widgets.
    """

    def __init__(self, name, value, attrs, choices):
        self.name, self.value, self.attrs = name, value, attrs
        self.choices = choices

    def __iter__(self):
        for i, choice in enumerate(self.choices):
            yield RadioInput(self.name, self.value, self.attrs.copy(), choice, i)

    def __getitem__(self, idx):
        choice = self.choices[idx] # Let the IndexError propogate
        return RadioInput(self.name, self.value, self.attrs.copy(), choice, idx)

    def __unicode__(self):
        return self.render()

    def render(self):
        """Outputs a flat non-list for this set of radio fields."""
        return mark_safe(u'<p>\n%s\n</p>' % u'\n'.join([u'</br> %s <br/>'
                % force_unicode(w) for w in self]))
