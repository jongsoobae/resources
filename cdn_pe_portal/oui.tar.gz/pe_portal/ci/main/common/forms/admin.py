import re
from datetime import datetime
from django import forms
from django.contrib import admin
from django.contrib.admin import widgets
from django.forms.models import BaseInlineFormSet
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.utils import simplejson
from django.db.models import Q
from ci.common.models.sni import SNIGroup
from ci.common.models.dns import ARecord, Dns_Ns_Record, DnsZone
from ci.common.models.billing import BillRate
from ci.common.models.pusher import PUSH_NAMES, PUSH_VISIBLE
from ci.common.models.cdn import Pop, Service, Node, NodeIP, PopLoadLimit, SSL_PROTOCOLS, DEFAULT_SSL_SERVER_CIPHER
from ci.common.models.cache import Band, ShieldedServiceBand, ShieldedService, EdgeAppVersion
from ci.common.models.customer import SSLKeystore
from ci.common.models.site import SAMProfile, SAMDefaultRule
from ci.common.utils import get_needed_perms
from ci.common.utils.sni_group import validate_sni_service_for_service_admin
from ci.common.utils.site import ValidatorCertAndDomain
from ci.common.utils.supporttools import handleHttpGetConnection2
from ci.common.utils.util_common import get_request
from ci.constants import PRISMAPI_SERVER, PRISMAPI_USER, PRISMAPI_PASS
from ci.common.utils.cdn import CheckOOS
from ci.common.models.customer import FastmonCustomerPrefix
from ci.common.utils.api import APIException
from ci.common.utils.sam_wizard import rule_validation
from ci.common.utils.json_load_ordered import json_load_ordered

from ci.common.models.cdn import HTTP2_ALLOW_SSL_PROTOCOL
from ci.common.models.cdn import HTTP2_ALLOW_SSL_CIPHER
from ci.common.models.cdn import HTTP2_ALLOW_ALTERNATIVE_SSL_CIPHERs


def make_inactive(modeladmin, request, queryset):
    """convenience action for setting objects to inactive. Use only for ModelAdmins related to models that use column 'Status'"""
    queryset.update(status=False)
make_inactive.short_description = "Set selected objects to inactive"

from django.conf import settings

class BandAdminFilteredSelectMultiple(widgets.FilteredSelectMultiple):
    def __init__(self, verbose_name, is_stacked, attrs=None, choices=()):
        self.verbose_name = verbose_name
        self.is_stacked = is_stacked
        super(BandAdminFilteredSelectMultiple, self).__init__(verbose_name, is_stacked, attrs=attrs, choices=choices)

    def render(self, name, value, attrs=None, choices=()):
        if value is None: value = []
        attrs['class'] = 'selectfilter'
        if self.is_stacked: attrs['class'] += 'stacked'
        str_values = set([smart_unicode(v) for v in value])
        final_attrs = self.build_attrs(attrs, name=name)
        output = [u'<select multiple="multiple" %s>' % util.flatatt(final_attrs)]

        all_choices = Band.objects.all().select_related('band_aggr').values('id', 'name', 'band_aggr__ips')
        for i, option in enumerate(all_choices):
            option_value, option_label, ips = option
            option_value = smart_unicode(option['id'])
            selected_html = (option_value in str_values) and ' selected="selected"' or ''
            output.append(u'<option value="%s"%s>%s (%s)</option>'%(option['id'], selected_html, option['name'], option['band_aggr__ips']))
        output.append(u'</select>')
        output.append(u'<script type="text/javascript">addEvent(window, "load", function(e) {')
        output.append(u'SelectFilter.init("id_%s", "%s", %s, "%s"); });</script>\n' % \
            (name, self.verbose_name.replace('"', '\\"'), int(self.is_stacked), settings.ADMIN_MEDIA_PREFIX))
        return mark_safe(u''.join(output))

class NodeIPsAdminFilteredSelectMultiple(widgets.FilteredSelectMultiple):
    def __init__(self, verbose_name, is_stacked, attrs=None, choices=()):
        self.verbose_name = verbose_name
        self.is_stacked = is_stacked
        super(NodeIPsAdminFilteredSelectMultiple, self).__init__(verbose_name, is_stacked, attrs=attrs, choices=choices)

    def render(self, name, value, attrs=None, choices=()):
        if value is None: value = []
        attrs['class'] = 'selectfilter'
        if self.is_stacked: attrs['class'] += 'stacked'
        str_values = set([smart_unicode(v) for v in value])
        final_attrs = self.build_attrs(attrs, name=name)
        output = [u'<select multiple="multiple" %s>' % util.flatatt(final_attrs)]
        all_choices = self.choices.queryset.select_related('node').values('id', 'node__hostname', 'seq_num', 'description')
        for i, option in enumerate(all_choices):
            option_value = smart_unicode(option['id'])
            selected_html = (option_value in str_values) and ' selected="selected"' or ''
            output.append(u'<option value="%s"%s>%s (%d: %s)</option>'%(option['id'], selected_html, option['node__hostname'], option['seq_num'], option['description']))
        output.append(u'</select>')
        output.append(u'<script type="text/javascript">addEvent(window, "load", function(e) {')
        output.append(u'SelectFilter.init("id_%s", "%s", %s, "%s"); });</script>\n' % \
            (name, self.verbose_name.replace('"', '\\"'), int(self.is_stacked), settings.ADMIN_MEDIA_PREFIX))
        return mark_safe(u''.join(output))


class AdminRedirect(admin.ModelAdmin):
    """Because django is lame and uses a simple permission denied exception for the admin site, I had to override each part that uses that exception and manually use my custom page as opposed to a simple middleware exception which would eliminate my ability to know what the model/object being accessed was and get the proper list of needed perms. --silvia"""
    def permission_denied_resp(self, request):
        perms=get_needed_perms(request, obj=self)
        return render_to_response("admin_perm_required.html", {'perms': perms})

    def changelist_view(self, request, extra_context=None):
        if not self.has_change_permission(request, None):
            return self.permission_denied_resp(request)
        else:
            return super(AdminRedirect, self).changelist_view(request, extra_context=extra_context)

    redirect_string = None
    def response_change(self, request, obj):
        if request.POST.has_key("_save"):
            if obj.__class__.__name__.lower() == 'band':
                return HttpResponseRedirect('%s/%s' % (request.META.get('SCRIPT_NAME',""), 'band/'+ str(obj.pk)))
            elif obj.__class__.__name__.lower() == 'service':
                return HttpResponseRedirect('%s/%s' % (request.META.get('SCRIPT_NAME',""), 'service/'+ str(obj.pk)))
            elif obj.__class__.__name__.lower() == 'shieldedservice':
                return HttpResponseRedirect('%s/%s' % (request.META.get('SCRIPT_NAME',""), 'service/'+ str(obj.service_id)))
            elif obj.__class__.__name__.lower() == 'node':
                return HttpResponseRedirect('%s/%s' % (request.META.get('SCRIPT_NAME',""), 'node/'+ str(obj.pk)))
            else:
                return HttpResponseRedirect('%s/%s' % (request.META.get('SCRIPT_NAME',""), self.redirect_string if self.redirect_string else 'admin/oui/'+ obj.__class__.__name__.lower()))
        return super(AdminRedirect,self).response_change(request, obj)

class DnsModelFormset(BaseInlineFormSet):
    def clean(self):
        super(DnsModelFormset, self).clean()
        if any(self.errors):
            return
        for row in self.cleaned_data:
            name = row.get('name')
            if name and not name.endswith(self.instance.domain_name):
                raise forms.ValidationError("The name %s should end with the overall DNS zone name %s" % (name, self.instance.domain_name))
        return self.cleaned_data

class PushTestForm(forms.ModelForm):
    push_type = forms.ChoiceField(choices=[(PUSH_NAMES.get(t, t), PUSH_NAMES.get(t, t)) for t in PUSH_VISIBLE])

class BillRateAdminForm(forms.ModelForm):
    class Meta:
        model = BillRate
    def clean(self):
        if self.instance and self.instance.archived:
            raise forms.ValidationError("Archived rates cannot be changed")
        return self.cleaned_data

class ARecordFormset(DnsModelFormset):
    class Meta:
        model = ARecord
    def clean(self):
        super(ARecordFormset, self).clean()
        if any(self.errors):
            return
        ptr_dict, ids, error_string = {}, [], ''
        for row in self.cleaned_data:
            if len(row)>0:
                if row.get('id') and hasattr(row.get('id'),'id'):
                    ids.append(row.get('id').id)
                else:
                    ids.append(-1)
            if row.get('ptr_record'):
                if ptr_dict.has_key(row.get('address')):
                    ptr_dict[row.get('address')].append(row.get('name'))
                else:
                    ptr_dict[row.get('address')] = [row.get('name')]
        for obj in ARecord.objects.filter(status=True, ptr_record=True).exclude(id__in=ids).all():
            ptr_dict[obj.address] = [obj.name]
        for ip, hostnames in ptr_dict.iteritems():
            distinct_hosntames = set(hostnames)
            if distinct_hosntames.__len__()>1:
                error_string = 'The following ARecord(s) were found marked PTR for IP %s:<br/> ' % ip
                for each in distinct_hosntames.__iter__():
                    error_string = error_string + "-" + each + '<br/>'
        if error_string >'':
            raise forms.ValidationError(error_string + "Only one ARecord can be used as a PTR record for a given IP.")

        return self.cleaned_data

class NsRecordFormset(DnsModelFormset):
    class Meta:
        model = Dns_Ns_Record
    def clean(self):
        super(NsRecordFormset, self).clean()
        if any(self.errors):
            return
        if self.cleaned_data==[{}]:
            raise forms.ValidationError('You cannot save a dns zone without having at least one ns record linked to that zone')
        else:
            # this nameserver code check is loose but it matches the behaviour of our current DNS code
            ns_names = [(row.get('name'), row.get('status'))for row in self.cleaned_data]
            flag=True
            for name, status in ns_names:
                if status==True and name.startswith('ns1'):
                    flag=False
            if flag:
                raise forms.ValidationError('At least one of the active ns records must start with "ns1" for valid DNS behaviour')
        return self.cleaned_data


from django.utils.safestring import mark_safe
from django.forms import util
from django.utils.encoding import smart_unicode
import datetime
from ci.common.models.customer import Customer


class BandAdminSelectField(forms.Select):
    def render(self, name, value, attrs=None, choices=()):
        if value is None: value = []
        str_value = smart_unicode(value)

        final_attrs = self.build_attrs(attrs, name=name)
        output = [u'<select %s>' % util.flatatt(final_attrs)]
        all_choices = Band.objects.filter(is_v6=False).select_related('band_aggr').values('id', 'name', 'band_aggr__ips')

        output.append(u'<option value=""%s>----------</option>'%(' selected="selected"' if str_value == '' else ''))
        for i, option in enumerate(all_choices):
            option_value, option_label, ips = option
            option_value = smart_unicode(option['id'])
            selected_html = (option_value == str_value) and ' selected="selected"' or ''
            output.append(u'<option value="%s"%s>%s (%s)</option>'%(option['id'], selected_html, option['name'], option['band_aggr__ips']))
        output.append(u'</select>')
        return mark_safe(u''.join(output))

class SSLKeystoreAdminSelectField(forms.Select):
    def render(self, name, value, attrs=None, choices=()):
        if value is None: value = []
        str_value = smart_unicode(value)

        final_attrs = self.build_attrs(attrs, name=name)
        output = [u'<select %s>' % util.flatatt(final_attrs)]
        all_choices = SSLKeystore.objects.all().select_related('customer').order_by('customer','domain', '-create_time').values('keystore_id', 'expiration_date', 'customer__name', 'domain', 'description')

        output.append(u'<option value=""%s>----------</option>'%(' selected="selected"' if str_value == '' else ''))
        before_val = {'id':0,'domain':''}
        for i, option in enumerate(all_choices):
            option_value = smart_unicode(option['keystore_id'])
            current_val = {'id':option['customer__name'], 'domain':option['domain']}
            is_lastest = '(---- Lastest ----)' if before_val <> current_val else ''
            selected_html = (option_value == str_value) and ' selected="selected"' or ''
            output.append(u'<option value="%s"%s>%s%s: %s (%s)%s</option>'%(option['keystore_id'], selected_html, 'EXPIRED - ' if option['expiration_date']<datetime.datetime.now() else '',option['customer__name'], option['domain'] if option['domain'] else option['description'], option['expiration_date'].strftime("%m/%d/%Y"), is_lastest))
            before_val = current_val
        output.append(u'</select>')
        return mark_safe(u''.join(output))


class CustomerAdminSelectField(forms.Select):
    def render(self, name, value, attrs=None, choices=()):
        if value is None: value = []
        str_value = smart_unicode(value)

        final_attrs = self.build_attrs(attrs, name=name)
        output = [u'<select %s>' % util.flatatt(final_attrs)]
        all_choices = Customer.objects.all().values('id', 'name')
        output.append(u'<option value=""%s>----------</option>'%(' selected="selected"' if str_value == '' else ''))
        for i, option in enumerate(all_choices):
            option_value = smart_unicode(option['id'])
            selected_html = (option_value == str_value) and ' selected="selected"' or ''
            output.append(u'<option value="%s"%s>%s</option>'%(option['id'], selected_html, option['name']))
        output.append(u'</select>')
        return mark_safe(u''.join(output))


class ServiceAdminForm(forms.ModelForm):
    result_count = forms.IntegerField(initial=2, min_value=1, max_value=30, required=True, label="Number of A records")
    force_input_cipher = forms.BooleanField(required=False)
    bands = forms.ModelMultipleChoiceField(queryset=Band.objects.all().select_related('band_aggr'), required=False, widget=BandAdminFilteredSelectMultiple('Bands', False))
    ssl_cert = forms.ModelChoiceField(queryset=SSLKeystore.objects.all(), required=False, widget=SSLKeystoreAdminSelectField())
    sni_group = forms.ModelChoiceField(queryset=SNIGroup.objects.all(), required=False)
    customer = forms.ModelChoiceField(queryset=Customer.objects.all(), required=False, widget=CustomerAdminSelectField())

    def __init__(self,  *args, **kwargs):
        super(ServiceAdminForm, self).__init__(*args, **kwargs)
        #self.fields['ssl_cert'].queryset = SSLKeystore.objects.all().select_related('customer').order_by('customer','domain', '-create_time')
        self.fields['status'].widget.attrs['onclick'] = 'return false'
        if get_request().user.is_superuser:
            del self.fields['status'].widget.attrs['onclick']

        if self.instance.sni_group:
            msg = 'Can`t edit this field, while sni_group exists.'
            self.fields['ssl_server_protocols'].widget.attrs['readonly'] = 'readonly'
            self.fields['ssl_server_protocols'].widget.attrs['title'] = msg

            self.fields['ssl_server_ciphers'].widget.attrs['readonly'] = 'readonly'
            self.fields['ssl_server_ciphers'].widget.attrs['title'] = msg

            self.fields['ssl_client_protocols'].widget.attrs['readonly'] = 'readonly'
            self.fields['ssl_client_protocols'].widget.attrs['title'] = msg

            self.fields['ssl_client_ciphers'].widget.attrs['readonly'] = 'readonly'
            self.fields['ssl_client_ciphers'].widget.attrs['title'] = msg

    class Meta:
        model = Service

    def clean_ssl_server_ciphers(self):
        super(ServiceAdminForm, self).clean()
        cleaned_ssl_cert = self.cleaned_data.get('ssl_cert')
        cleaned_ssl_server_ciphers = self.cleaned_data.get('ssl_server_ciphers')

        if self.cleaned_data['is_http2']:
            cleaned_ssl_server_ciphers = self.get_valid_server_cipher_for_http2(cleaned_ssl_server_ciphers)
        if cleaned_ssl_cert:
            services = Service.objects.filter(ssl_cert=cleaned_ssl_cert).exclude(pk=self.instance.pk)
            try:
                for service in services:
                    if cleaned_ssl_server_ciphers:
                        if service.ssl_server_ciphers != cleaned_ssl_server_ciphers:
                            raise Exception(str(service.pk))
                    else:
                        if service.ssl_server_ciphers not in ['', None, DEFAULT_SSL_SERVER_CIPHER]:
                            raise Exception(str(service.pk))
            except Exception, e:
                raise forms.ValidationError(
                    "There are service that have different cipher with same cert_key. : %s" % e.message)

        return cleaned_ssl_server_ciphers

    def clean_ssl_client_ciphers(self):
        super(ServiceAdminForm, self).clean()
        cleaned_ssl_cert = self.cleaned_data.get('ssl_cert')
        cleaned_ssl_client_ciphers = self.cleaned_data.get('ssl_client_ciphers')
        if cleaned_ssl_cert:
            services = Service.objects.filter(ssl_cert=cleaned_ssl_cert).exclude(pk=self.instance.pk)
            try:
                for service in services:
                    if cleaned_ssl_client_ciphers:
                        if service.ssl_client_ciphers != cleaned_ssl_client_ciphers:
                            raise Exception(str(service.pk))
                    else:
                        if service.ssl_client_ciphers in ['', None, 'SSL_RSA_WITH_RC4_128_MD5,SSL_RSA_WITH_RC4_128_SHA,TLS_RSA_WITH_AES_128_CBC_SHA,TLS_RSA_WITH_AES_256_CBC_SHA']:
                            pass
                        else:
                            raise Exception(str(service.pk))
            except Exception, e:
                raise forms.ValidationError("There are service that have different cipher with same cert_key. : %s" % e.message)

        return self.cleaned_data['ssl_client_ciphers']

    def clean_ssl_server_protocols(self):
        super(ServiceAdminForm, self).clean()

        cleaned_ssl_server_protocols = self.cleaned_data.get('ssl_server_protocols')
        if self.cleaned_data['is_http2']:
            cleaned_ssl_server_protocols = self.get_valid_server_protocol_for_http2(cleaned_ssl_server_protocols)
        checked_ssl_server_protocols = []

        dupl_list = []
        if cleaned_ssl_server_protocols <> '':
            for protocol in cleaned_ssl_server_protocols.split(','):
                aprotocol = protocol.strip()
                if aprotocol not in SSL_PROTOCOLS:
                    raise forms.ValidationError("SSL Server Protocols: %s is not available"%aprotocol)
                else:
                    if aprotocol not in checked_ssl_server_protocols:
                        checked_ssl_server_protocols.append(aprotocol)
                    else:
                        dupl_list.append(aprotocol)

            if len(dupl_list) > 0:
                raise forms.ValidationError("Cannot Save or Save just one : %s"%", ".join(dupl_list))

        self.cleaned_data['ssl_server_protocols'] = ",".join(checked_ssl_server_protocols)
        return self.cleaned_data['ssl_server_protocols']

    def clean_ssl_client_protocols(self):
        super(ServiceAdminForm, self).clean()

        cleaned_ssl_client_protocols = self.cleaned_data.get('ssl_client_protocols')
        checked_ssl_client_protocols = []
        dupl_list = []
        if cleaned_ssl_client_protocols <> '':
            for protocol in cleaned_ssl_client_protocols.split(','):
                aprotocol = protocol.strip()
                if aprotocol not in SSL_PROTOCOLS:
                    raise forms.ValidationError("SSL Client Protocols: %s is not available"%aprotocol)
                else:
                    if aprotocol not in checked_ssl_client_protocols:
                        checked_ssl_client_protocols.append(aprotocol)
                    else:
                        dupl_list.append(aprotocol)

            if len(dupl_list) > 0:
                raise forms.ValidationError("Cannot Save or Save just one : %s"%", ".join(dupl_list))

        self.cleaned_data['ssl_client_protocols'] = ",".join(checked_ssl_client_protocols)
        return self.cleaned_data['ssl_client_protocols']

    @classmethod
    def get_valid_server_protocol_for_http2(cls, server_protocol):
        if not server_protocol:
            return server_protocol

        if HTTP2_ALLOW_SSL_PROTOCOL not in server_protocol:
            raise forms.ValidationError(
                "Deployments of HTTP/2 that use TLSv1.2 MUST support TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 at the default priority (or higher)")

        return ','.join(
            [HTTP2_ALLOW_SSL_PROTOCOL] +
            [x.strip() for x in server_protocol.split(',') if x.strip() != HTTP2_ALLOW_SSL_PROTOCOL]
        )

    @classmethod
    def get_valid_server_cipher_for_http2(cls, server_cipher):
        if not server_cipher:
            return server_cipher

        b_has_allow_ssl_cipher = False
        b_has_allow_alter_ssl_cipher = False
        other_cipher_list = []
        alter_list = []
        for sc in map(lambda x: x.strip(), server_cipher.split(',')):
            if sc == HTTP2_ALLOW_SSL_CIPHER:
                b_has_allow_ssl_cipher = True
            elif sc in HTTP2_ALLOW_ALTERNATIVE_SSL_CIPHERs:
                b_has_allow_alter_ssl_cipher = True
                alter_list.append(sc)
            else:
                other_cipher_list.append(sc)

        if not b_has_allow_ssl_cipher and not b_has_allow_alter_ssl_cipher:
            raise forms.ValidationError(
                "To use HTTP / 2, you must use TLS 1.2 and TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256(or higher).")

        ret_list = []
        if b_has_allow_ssl_cipher:
            ret_list.append(HTTP2_ALLOW_SSL_CIPHER)
        if b_has_allow_alter_ssl_cipher:
            ret_list += alter_list
        ret_list += other_cipher_list

        return ','.join(ret_list)

    def clean_bands(self):
        super(ServiceAdminForm, self).clean()
        bands = self.cleaned_data.get('bands')

        if not bands:
            return bands

        v6_bands = bands.filter(is_v6=True)
        v4_bands = bands.filter(is_v6=False)
        v4_band_id_list = [str(v4_band.pk) for v4_band in v4_bands]
        if v6_bands.exists():
            for v6_band in v6_bands:
                if not str(v6_band.my_v4_band_id) in v4_band_id_list:
                    raise forms.ValidationError(mark_safe('V6 band can`t exist on its own. It needs pair v4 band.'))

        if not self.data.has_key('ignore_check_shield_bands') and self.instance.pk != None:
            removed_bands = []
            related_bands = []

            objs_band = self.instance.band_set.all()
            for obj in objs_band:
                if not obj in self.cleaned_data.get('bands'):
                    removed_bands.append(obj)

            objs_shield = ShieldedService.objects.filter(service=self.instance)

            for obj in objs_shield:
                shield_bands = obj.bands.all()
                temp_arr = []
                for rem_obj in removed_bands:
                    if rem_obj in shield_bands:
                        temp_arr.append(rem_obj.name)
                if len(temp_arr) > 0:
                    related_bands.append('%s of %s<br>'%(', '.join(temp_arr), obj.name))

            if len(related_bands) > 0:
                raise forms.ValidationError(mark_safe('Please check Bands related Shielded service<br>') + mark_safe(''.join(related_bands)))

        return bands
    def validate_sni_group(self):
        return validate_sni_service_for_service_admin(
            service=self.instance, sni_group=self.cleaned_data.get('sni_group'),
            cleaned_data=self.cleaned_data
        )

    def clean(self):
        super(ServiceAdminForm, self).clean()
        force_input_cipher = self.cleaned_data['force_input_cipher']
        if force_input_cipher and self.errors:
            if self.errors.get('ssl_client_ciphers'):
                del self.errors['ssl_client_ciphers']
                self.cleaned_data['ssl_client_ciphers'] = self.data.get('ssl_client_ciphers')
            if self.errors.get('ssl_server_ciphers'):
                del self.errors['ssl_server_ciphers']
                self.cleaned_data['ssl_server_ciphers'] = self.data.get('ssl_server_ciphers')

        if any(self.errors):
            return self.cleaned_data

        sni_group_errors = self.validate_sni_group()
        if sni_group_errors:
            sni_errors = [v for k, v in sni_group_errors.items()]
            self._errors['sni_group'] = self.error_class(sni_errors)
        if self.cleaned_data.get('is_http2'):
            if self.cleaned_data.get('stage_service') or self.cleaned_data.get('stage_ssl') or self.cleaned_data.get('stage_region'):
                raise forms.ValidationError("Cannot set both http2 & stage service.")
            if not self.cleaned_data.get('ssl_cert'):
                raise forms.ValidationError("Cannot set http2 without ssl_cert.")

        self.cleaned_data['dns_prefix'] = self.cleaned_data['dns_prefix'].strip()
        if not self.cleaned_data.get('pops') and not self.cleaned_data.get('bands') and self.cleaned_data.get('status'):
            raise forms.ValidationError(" Cannot set this service to active without any PoPs or bands")
        for band in self.cleaned_data.get('bands'):
            if self.cleaned_data.get('ssl_cert') and not band.check_keystore(keystore_id=self.cleaned_data.get('ssl_cert').keystore_id, exclude_services=[self.instance.id] if self.instance and self.instance.id else []):
                raise forms.ValidationError("The band, %s, has at least 1 IP already assigned to another keystore" %(band.name))
        if self.cleaned_data.get('ssl_cert') and self.cleaned_data.get('customer') and self.cleaned_data.get('ssl_cert').customer != self.cleaned_data.get('customer'):
            raise forms.ValidationError("The customer associated with the service must match the customer associated with the selected keystore")
        if self.instance and self.instance.ssl_cert and not self.cleaned_data.get('ssl_cert'):
            for pad in self.instance.site_set.all():
                if pad.enable_ssl:
                    raise forms.ValidationError("Pad: %s uses this service and has SSL enabled. An SSL certificate has to be assigned. " % pad)
                    break

        try:
            ValidatorCertAndDomain.validate_for_service(
                service=self.instance,
                ssl_cert=self.cleaned_data.get('ssl_cert'),
                sni_group=self.cleaned_data.get('sni_group'),
                allow_nonmatching_domains=self.cleaned_data.get('allow_nonmatching_domains')
            )
        except Exception, e:
            raise forms.ValidationError(e)

        if self.instance and self.instance.pk and (self.instance.ssl_cert or self.cleaned_data.get('ssl_cert')) and not self.cleaned_data.get('allow_nonmatching_domains'):
            cert_domain = self.cleaned_data.get('ssl_cert').domain if self.cleaned_data.get('ssl_cert') else None
            alt_domains = [d.domain for d in self.cleaned_data.get('ssl_cert').keystoredomains_set.all()] if self.cleaned_data.get('ssl_cert') else []                

            isValid = False
            for site in self.instance.site_set.filter(status=True):
                isValid = False
                if not site.enable_ssl:
                    continue
                if cert_domain and cert_domain[0] == '*':
                    if cert_domain.partition('.')[2] == site.pad.partition('.')[2]:
                        isValid = True
                else:
                    if cert_domain == site.pad:
                        isValid = True

                if isValid == False:
                    for domain_check in alt_domains:
                        if domain_check != '' and domain_check[0] == '*':
                            if domain_check.partition('.')[2] == site.pad.partition('.')[2] and site.enable_ssl:
                                isValid = True
                        else:
                            if domain_check == site.pad and site.enable_ssl:
                                isValid = True
                if isValid == False:
                    raise forms.ValidationError("%s uses the original certificate on this edge service and is not compatible with this new certificate" % site.pad)

        return self.cleaned_data

class EdgeAppVersionForm(forms.ModelForm):
    class Meta:
        model = EdgeAppVersion

class BandAdminForm(forms.ModelForm):
    node_ips = forms.ModelMultipleChoiceField(queryset=NodeIP.objects.filter(node__pop__importance__gte=0, is_v6=False).select_related('node'), widget=NodeIPsAdminFilteredSelectMultiple('Nodes IP', False))
    services = forms.ModelMultipleChoiceField(queryset=Service.objects.all(), widget=widgets.FilteredSelectMultiple('Services', False), required=False)
    class Meta:
        model = Band
    def clean(self):
        super(BandAdminForm, self).clean()
        if not any(self.errors):
            if self.instance.get_v6_sync_status() == 2:
                raise forms.ValidationError('Need to sync v6 band.')
            certs = None
            if len(self.cleaned_data.get('services')) > 0:
                certs = set(self.cleaned_data.get('services').filter(ssl_cert__isnull=False).values_list('ssl_cert',flat=True))
            if certs != None:
                try:
                    svc_id_list = [s.id for s in self.instance.service_set.all()]
                except:
                    svc_id_list = [s.id for s in self.cleaned_data.get('services')]
                if len(certs) > 1:
                    raise forms.ValidationError("The band is assigned to services with different keystores")
                if len(certs) == 1:
                    b = Band()
                    cert = certs.pop()
                    for ip in self.cleaned_data.get('node_ips',[]):
                        if not b.check_keystore(additional_ips=[ip.ipv4_address], keystore_id=cert, exclude_services=svc_id_list):
                            raise forms.ValidationError("IP %s can not be added as it would be assigned to multiple keystores" %(ip.ipv4_address))
        if self.cleaned_data.get('services') and len(self.cleaned_data.get('services')) > 0 and self.cleaned_data.get('node_ips') and len(self.cleaned_data.get('node_ips')) > 0:
            service_stageinfo_set = set()
            for service in self.cleaned_data.get('services'):
                service_stageinfo_set.add(1 if service.stage_service else 0)
            if len(service_stageinfo_set) >= 2:
                raise forms.ValidationError("There are two types of service (stage, non-stage). There must be only one type.")

            node_stageinfo_set = set()
            for nodeip in self.cleaned_data.get('node_ips'):
                node_stageinfo_set.add(1 if nodeip.node.stage_node else 0)
            if len(node_stageinfo_set) >= 2:
                raise forms.ValidationError("There are two types of node (stage, non-stage). There must be only one type.")

            if service_stageinfo_set.pop() != node_stageinfo_set.pop():
                raise forms.ValidationError("Service and node must be of the same type(stage, non-stage).")

        return self.cleaned_data


class NodeAdminForm(forms.ModelForm):
    # bands = forms.ModelMultipleChoiceField(queryset=Band.objects.all(), widget=widgets.FilteredSelectMultiple('Bands', False), required=False)
    class Meta:
        model = Node
    def clean(self):
        super(NodeAdminForm, self).clean()
        if self.cleaned_data.get('hostname') and not re.search(r"^[a-z0-9-_\.]+$",self.cleaned_data.get('hostname')):
            raise forms.ValidationError("Node hostname can only contain lower case characters, number, '-', '_' and '.' characters. Please check your input again")
        if self.instance and self.instance.broken != self.cleaned_data.get('broken') and self.cleaned_data.get('description') == self.instance.description:
            raise forms.ValidationError("You must enter your changes in the description before changing a node's broken status")
        if self.cleaned_data.get('ngp_hostname') and not re.match('^h[0-9]+-s[0-9]+.(p|v)[0-9]+-[a-z0-9]{3}.cdngp.net$', self.cleaned_data.get('ngp_hostname')):
            raise forms.ValidationError("NGP hostname does not match required format")
    
        return self.cleaned_data
    
class NodeIPInlineFormset(BaseInlineFormSet):
    class Meta:
        model = NodeIP
    def clean(self):
        super(NodeIPInlineFormset, self).clean()
        if any(self.errors):
            return 
        if self.cleaned_data==[{}]:
            raise forms.ValidationError('You cannot save a node without at least one IP with sequence 0 created')
        else:
            primary_ip_row= None
            for row in self.cleaned_data:
                if row.get('seq_num')==0 and not row.get('DELETE'):
                    primary_ip_row = row
            if not primary_ip_row:
                raise forms.ValidationError("No primary IP is found or it has been marked deleted. There has to be a primary IP for any node with sequence number 0. ")
        if self.instance.ipv4_address != primary_ip_row.get('ipv4_address'):
            raise forms.ValidationError("The IPv4 address above does not match the primary IP row value. Please make sure those 2 values match. ")
        return self.cleaned_data

    def get_queryset(self):
        return self.queryset.filter(is_v6=False)


class ShieldedServiceBandAdminFormset(BaseInlineFormSet):
    class Meta:
        model = ShieldedServiceBand

    def clean(self):
        super(ShieldedServiceBandAdminFormset, self).clean()
        
        for form in self.forms:
            try:
                if len(form._errors) > 0:
                    raise forms.ValidationError('Please correct the errors below')
            except AttributeError:
                pass 

        
class ShieldedServiceBandAdminForm(forms.ModelForm):
    cache_level = forms.IntegerField(label="Cache level",min_value=1)
    skip_check = forms.BooleanField(label="Skip check", required=False)
    band = forms.ModelChoiceField(queryset=Band.objects.filter(is_v6=False), required=False, widget=BandAdminSelectField())
    class Meta:
        model = ShieldedServiceBand

    def clean(self):
        super(ShieldedServiceBandAdminForm, self).clean()
        if self.cleaned_data['shielded_service'].service_id != None:
            if not self.cleaned_data['band'] in self.cleaned_data['shielded_service'].service.band_set.all() and self.cleaned_data['skip_check'] == False:
                raise forms.ValidationError("Selected Band is not in this Edge Service")

            if self.cleaned_data['DELETE'] == True:
                if self.cleaned_data['shielded_service'].service != self.instance.shielded_service.service and self.cleaned_data['skip_check'] == False:
                    raise forms.ValidationError("Selected Band can't be deleted in this Edge Service")

        return self.cleaned_data

class SAMProfileAdminForm(forms.ModelForm):
    class Meta:
        model = SAMProfile
    def clean(self):
        super(SAMProfileAdminForm, self).clean()
        if any(self.errors):
            return 
        if self.cleaned_data:
            try:
                rules = simplejson.loads(self.cleaned_data.get('rule_set'))
            except:
                raise forms.ValidationError("The server action rules you entered are invalid. Please check your syntax")
        return self.cleaned_data

class SAMDefaultRuleAdminForm(forms.ModelForm):
    class Meta:
        model = SAMDefaultRule

    def clean(self):
        super(SAMDefaultRuleAdminForm, self).clean()
        if self.cleaned_data:
            try:
                rules = json_load_ordered(self.cleaned_data['server_action_rule'])
                if isinstance(rules, list):
                    for rule in rules:
                        rule_validation(rule)
                else:
                    rule_validation(rules)
                self.cleaned_data['server_action_rule'] = simplejson.dumps(rules, indent=4)
            except APIException, e:
                raise forms.ValidationError("Validation failed. Invalid Format Error: %s" % e.message)
            except:
                raise forms.ValidationError("The server action rules you entered are invalid. Please check your syntax")
        return self.cleaned_data

class DnsZoneAdminForm(forms.ModelForm):
    class Meta:
        model = DnsZone
    def clean(self):
        super(DnsZoneAdminForm, self).clean()
        uri = '/dns/zone/is_exist?user=' + PRISMAPI_USER  + '&pass=' + PRISMAPI_PASS  + '&zone=' + self.cleaned_data['domain_name'].strip()
        resp = handleHttpGetConnection2(PRISMAPI_SERVER, uri)
        if not isinstance(resp,dict):
            raise forms.ValidationError("prism api connect error")
        if resp['result'] != 'false':
            raise forms.ValidationError("duplicated from prism")
        return self.cleaned_data

class PopLoadLimitForm(forms.ModelForm):
    loop_period_sec = forms.DecimalField(decimal_places=3, required=True, initial=13.0)
    integral_time_div = forms.DecimalField(decimal_places=4, required=True, initial=2.0)
    class Meta:
        model = PopLoadLimit

    def has_changed(self):
        return True

    def clean_loop_period_sec(self):
        super(PopLoadLimitForm, self).clean()
        loop_period_sec = self.cleaned_data['loop_period_sec']
        if loop_period_sec <= 0:
            raise forms.ValidationError("This value must be greater than 0")
        return loop_period_sec

    def clean_integral_time_div(self):
        super(PopLoadLimitForm, self).clean()
        integral_time_div = self.cleaned_data['integral_time_div']
        if integral_time_div <= 0:
            raise forms.ValidationError("This value must be greater than 0")
        return integral_time_div

class PopAdminForm(forms.ModelForm):
    xname = forms.CharField(required=False)
    class Meta:
        model = Pop
    def clean(self):
        super(PopAdminForm, self).clean()
        if self.cleaned_data['offline'] == True:
            single_service = CheckOOS(pop=self.instance)
            if len(single_service) >0:
                raise forms.ValidationError("These services have a only band in this pop : %s"%', '.join(single_service))
        return self.cleaned_data

from ci.common.models.site import Site
class FastmonCustomerPrefixAdminForm(forms.ModelForm):
    class Meta:
        model = FastmonCustomerPrefix
    def clean(self):
        super(FastmonCustomerPrefixAdminForm, self).clean()
        if not any(self.errors):
            service_obj = self.cleaned_data['service']
            customer_obj = self.cleaned_data['customer']
            site_service_list = Site.objects.filter(customer = customer_obj).values_list('service',flat=True)
            if service_obj.pk not in site_service_list:
                raise forms.ValidationError("This service is not serviced for this customer")
        return self.cleaned_data
