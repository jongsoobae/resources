from datetime import datetime
from django import forms
from django.contrib.auth.models import User as AuthUser
from ci.common.models import UserProfile
from ci.common.models.alert import Alert
from ci.common.utils.mail import send_email
from ci.constants import ALERT_ADDR
	
def get_esc_form(request):
	oncall_users = AuthUser.objects.filter(oncallcontact__schedule__start_time__lte=datetime.now(), oncallcontact__schedule__end_time__gt=datetime.now()).order_by('oncallcontact__contact_order')
	class EscalateAlertForm(forms.Form):
		escalate_to_roster = forms.MultipleChoiceField(label="Choose legacy PE staff from the On-Call roster to escalate to",widget=forms.CheckboxSelectMultiple, choices=[(u.id, '%s, %s'%(u.last_name, u.first_name)) for u in oncall_users], required=False)
		escalate = forms.MultipleChoiceField(label="Escalate to a non-on-call tech... ", widget=forms.CheckboxSelectMultiple, choices=[(u.id, '%s, %s'%(u.last_name, u.first_name)) for u in AuthUser.objects.filter(is_staff=True, groups__id__in=(2,4), is_active=1).exclude(id__in=oncall_users.values_list('id', flat=True)).order_by('last_name').distinct()], required=False)
		done_so_far = forms.CharField(label="Work done so far", widget=forms.Textarea, required=False) 
		alert_id = forms.IntegerField(widget=forms.HiddenInput)
		def __init__(self, *args, **kwargs):
			super(EscalateAlertForm, self).__init__(*args, **kwargs)
			try:
				self.fields['escalate_to_roster'].initial = self.fields['escalate_to_roster'].choices[0]
			except:
				pass
		def clean(self):
			if not self.cleaned_data['escalate_to_roster'] and not self.cleaned_data['escalate']:
				raise forms.ValidationError("You must choose at least one person to escalate to. ")
			return self.cleaned_data
	if request.POST and request.POST.get('action') == 'escalate':
		esc_form = EscalateAlertForm(data=request.POST)
		if esc_form.is_valid():
			alert = Alert.objects.get(pk=esc_form.cleaned_data['alert_id'])
			escalate_ids = esc_form.cleaned_data['escalate'] + esc_form.cleaned_data['escalate_to_roster']
			for i in range(len(escalate_ids)):
				escalate_ids[i] = int(escalate_ids[i])
			esc_emails = list(AuthUser.objects.filter(id__in=escalate_ids).values_list('email', flat=True))+ list(UserProfile.objects.filter(user__in=escalate_ids).values_list('mobile_email', flat=True))
			body = """The following alert was escalated to you by %s.\n\n %s \n\n %s \n\n Troubleshooting done so far: \n %s \n\nPlease call USNOC center at 408.228.3455 once you receive this message.""" % (request.user.get_full_name(),alert.email_subject, alert.email_body, esc_form.cleaned_data['done_so_far'] if esc_form.cleaned_data['done_so_far'] else 'Not Provided')
			send_email(ALERT_ADDR, esc_emails, "[escalation] %s" % alert.email_subject, body)
			request.user.message_set.create(message="Your escalation request has been sent to the staff member(s) specified.")
			
	else:
		esc_form=EscalateAlertForm()
	return esc_form
