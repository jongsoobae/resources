from django import forms
from ci.common.utils.cdn import get_all_pops, get_all_services

class FilterBandsForm(forms.Form):
	pop = forms.ChoiceField(label="PoP", choices=[('','-------')], required=False)
	service = forms.ChoiceField(choices=[('','-------')], required=False)
	def __init__(self, *args, **kwargs):
		super(FilterBandsForm, self).__init__(*args, **kwargs)
		self.fields['pop'].choices += [(p.id, p.shortname()) for p in get_all_pops().order_by('short_name')]
		self.fields['service'].choices += [(s.id, "%s: %s" % (s.dns_prefix.upper(), s.name if len(s.name)<15 else s.name[:15]+'...')) for s in get_all_services()]
	def clean(self):
		if not self.cleaned_data.get('pop') and not self.cleaned_data.get('service'):
			raise forms.ValidationError(" Please choose a pop or a service to filter with. ")
		if self.cleaned_data.get('pop') and self.cleaned_data.get('service'):
			raise forms.ValidationError(" You can only filter on either a service or a PoP. Not both")
		return self.cleaned_data
