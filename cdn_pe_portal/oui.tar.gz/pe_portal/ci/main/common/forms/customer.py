import datetime
from django import forms
from django.contrib.auth.models import User as AuthUser
from django.forms import model_to_dict, fields_for_model
from ci.common.forms import FlatRadioFieldRenderer
from ci.common.models.customer import Customer, CustomerProductEdge, Product
from ci.common.models.geo import Address
from ci.common.models.billing import BillRate, Currency
from ci.common.models.sam_admin import SamRuleCondition, SamRuleAction, CustomerControlSam
from ci.common.utils.mail import send_email
from ci.constants import BILLING, SALES_EMEA, SALES_US, NO_REPLY
class AddressForm(forms.ModelForm):
    class Meta:
        model = Address

class CustomerForm(forms.ModelForm):
    add_to_ocsp = forms.ChoiceField(label="Add to OCSP?",help_text="Only mark this as 'No' if this customer already exists in OCSP", choices=(('y',"Yes"), ('n',"No")),widget=forms.RadioSelect(renderer=FlatRadioFieldRenderer),required=False)
    sales_eng = forms.ModelChoiceField(queryset=AuthUser.objects.filter(is_active=True, is_staff=True, groups__name__in=("Solutions Engineers", "Sales", "Service Delivery")).order_by('username').distinct(), label="Solutions engineer")
    sales_rep = forms.ModelChoiceField(queryset=AuthUser.objects.filter(is_active=True, is_staff=True, groups__name__in=("Solutions Engineers", "Sales", "Service Delivery")).order_by('username').distinct(), label="Sales rep")
    default_log_format = forms.CharField(label="Default Log Format", help_text="A default log format for all PADs this customer adds", widget=forms.Textarea(attrs={'rows': 4}), required=False)
    priority_note = forms.CharField(label="Priority Note", help_text="Put here any customer related note you want displayed as high priority on the customer page/related PAD pages", widget=forms.Textarea(attrs={'rows': 4}), required=False)
    
    class Meta:
        model = Customer
        
    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        if kwargs.has_key('fields'):
            self.Meta.fields = kwargs.pop('fields')
        instance = kwargs.get('instance',None)
        super(CustomerForm, self).__init__(
            *args,
            **kwargs
        )

        if 'status' in self.fields and not (user and user.is_superuser):
            self.fields.pop('status')

        if self.instance.customer_portal_flag == 'A':
            self.fields['name'].widget.attrs['readonly'] = 'readonly'
            self.fields['customer_portal_flag'].widget.attrs['readonly'] = 'readonly'

        if self.instance.pk:
            if self.fields.has_key('add_to_ocsp'):
                self.fields.pop('add_to_ocsp')
        else:
            self.fields['add_to_ocsp'].initial = 'y'
        if self.instance.pk and self.instance.cdnetworks_customer:
            if self.fields.has_key('corp_code'):
                self.fields.pop('corp_code')
            if self.fields.has_key('cdnetworks_customer'):
                self.fields.pop('cdnetworks_customer')
        if self.fields.has_key('default_rate'):
            if not self.instance.pk:
                self.fields['default_rate'].queryset = BillRate.objects.filter(archived=False)
            else:
                self.fields['default_rate'].queryset = BillRate.objects.filter(archived=False) | BillRate.objects.filter(pk=self.instance.default_rate.pk)
            
    def save(self, *args, **kwargs):
        username = kwargs.pop("username","Unknown")
        if self.instance is not None and self.fields.has_key('default_rate') and self.cleaned_data['default_rate'] != self.instance.default_rate:
            email_recp =  [ BILLING ]
            if self.instance.sales_rep:
                if self.instance.sales_rep.is_active:
                    email_recp.append(self.instance.sales_rep.email)
            else:
                email_recp.append(SALES_US)
                email_recp.append(SALES_EMEA)
            send_email(NO_REPLY, email_recp, "[alert] %s default rate has been changed" % self.instance.name,
                "%s's default rate has been changed from '%s' to '%s' by user %s" % (self.instance.name, self.instance.default_rate.description, self.cleaned_data["default_rate"], username))
        # if customer is newly marked as CDNW, mark all existing PADs as cdnw (both CUI and OUI rows)
        if self.instance and not self.instance.cdnetworks_customer and self.cleaned_data.get('cdnetworks_customer')==True:
            self.instance.site_set.update(cdnw=True)
            self.instance.sitedraft_set.update(cdnw=True)
        customer = super(CustomerForm, self).save(*args, **kwargs)
        return customer
        
    def clean(self):
        errors = []
        self.validate_unique()
        if self.errors:
            return self.cleaned_data
        is_cdnw=self.instance.pk and self.instance.cdnetworks_customer
        if Customer.objects.filter(name=self.cleaned_data.get('name')).exclude(pk=self.instance.pk if self.instance.pk else -1):
            errors.append("A customer with this name already exists")
        if self.instance.pk and self.instance.invoice_set.count() and not self.cleaned_data.get('address'):
            errors.append("You must add an address for customers with existing invoices")
        if self.cleaned_data.get('cdnetworks_customer')==True and not is_cdnw and self.instance.site_set.filter(request_log_msg_format__gt=''):
            raise forms.ValidationError("This customer uses custom per hit logging on one of their existing domains. They cannot be turned on for OCSP syncing without removing that feature first")
        if not self.instance.pk and not self.cleaned_data.get('add_to_ocsp'):
            errors.append("For new customers you must explicitly choose whether you want the customer's data sync-ed to the OSCP portal")
        if self.instance.customer_portal_flag == 'A' \
                and (self.instance.name != self.cleaned_data['name'] or self.instance.customer_portal_flag != self.cleaned_data['customer_portal_flag']):
            errors.append("Can't be changed customer name and flag if customer is for Aurora's control group")
        if errors:
            raise forms.ValidationError(errors)
        return self.cleaned_data


class CustomerProductEdgeForm(forms.ModelForm):
    allow_add_pad_flag = forms.BooleanField()
    count_per_contract = forms.IntegerField(initial=100)

    class Meta:
        model = CustomerProductEdge
        exclude = ('product', )

    def __init__(self, instance=None, product=None, *args, **kwargs):
        if instance:
            self.product = instance.product
        else:
            self.product = product
        _fields = ('allow_add_pad_flag', 'count_per_contract',)
        _initial = model_to_dict(self.product, _fields) if self.product is not None else {}
        super(CustomerProductEdgeForm, self).__init__(initial=_initial, instance=instance, *args, **kwargs)
        self.fields.update(fields_for_model(Product, _fields))
        self.fields['cdn_service'].queryset = self.fields['cdn_service'].queryset.filter(stage_service=0)

    def save(self, *args, **kwargs):
        #TODO:disable self provisioning when call is from ocsp. OUI should not permit allow add flag disabled for ocsp contract
        try:
            product = self.instance.product
        except Product.DoesNotExist:
            product = self.product
        if product:
            product.allow_add_pad_flag = self.cleaned_data.get('allow_add_pad_flag')
            product.count_per_contract = self.cleaned_data.get('count_per_contract')
            product.save()
            self.instance.product = product

        if self.cleaned_data.get('cdn_service'):
            return super(CustomerProductEdgeForm, self).save(*args, **kwargs)
        else:
            if self.instance and self.instance.pk:
                self.instance.delete()
            return CustomerProductEdge.objects.none()


class CustomerControlSamForm(forms.Form):
    sam_conditions = forms.MultipleChoiceField(required=False)
    sam_actions = forms.MultipleChoiceField(required=False)

    def __init__(self, customer_id, *args, **kwargs):
        super(CustomerControlSamForm, self).__init__(*args, **kwargs)
        self.customer_id = customer_id
        self.fields['sam_conditions'].choices = [(condition.pk, condition.rule_item_str_id) for condition in SamRuleCondition.objects.filter(expose_for_customer=1)]
        self.fields['sam_actions'].choices = [(action.pk, action.rule_item_str_id) for action in SamRuleAction.objects.filter(expose_for_customer=1)]

        controlled_sam = CustomerControlSam.objects.filter(customer=customer_id).select_related('sam_rule_item')
        controlled_condition = controlled_sam.filter(sam_rule_item__rule_type=1)
        controlled_action = controlled_sam.filter(sam_rule_item__rule_type=2)

        wrong_controlled_condition = controlled_condition.exclude(sam_rule_item__expose_for_customer=1)
        wrong_controlled_action = controlled_action.exclude(sam_rule_item__expose_for_customer=1)

        if wrong_controlled_condition.exists():
            for wc in wrong_controlled_condition:
                self.fields['sam_conditions'].choices = self.fields['sam_conditions'].choices + [(wc.sam_rule_item.pk, '%s - wrong' % wc.sam_rule_item.rule_item_str_id)]

        if wrong_controlled_action.exists():
            for wa in wrong_controlled_action:
                self.fields['sam_actions'].choices = self.fields['sam_actions'].choices + [(wa.sam_rule_item.pk, '%s - wrong' % wa.sam_rule_item.rule_item_str_id)]

        self.fields['sam_conditions'].initial = controlled_condition.values_list('sam_rule_item_id', flat=True)
        self.fields['sam_actions'].initial = controlled_action.values_list('sam_rule_item_id', flat=True)

    def clean_sam_conditions(self):
        sam_conditions = self.cleaned_data.get('sam_conditions', [])
        if type(sam_conditions) is not list:
            raise forms.ValidationError('Data type error.')
        for condition in sam_conditions:
            try:
                int(condition)
            except:
                raise forms.ValidationError('Date type error.')

        wrong_conditions = SamRuleCondition.objects.filter(pk__in=sam_conditions, expose_for_customer=0)
        if wrong_conditions.exists():
            raise forms.ValidationError('Need to remove this conditions. %s' % [str(v) for v in wrong_conditions.values_list('rule_item_str_id', flat=True)])
        return sam_conditions

    def clean_sam_actions(self):
        sam_actions = self.cleaned_data.get('sam_actions', [])
        if type(sam_actions) is not list:
            raise forms.ValidationError('Data type error.')
        for action in sam_actions:
            try:
                int(action)
            except:
                raise forms.ValidationError('Date type error.')

        wrong_actions = SamRuleAction.objects.filter(pk__in=sam_actions, expose_for_customer=0)
        if wrong_actions.exists():
            raise forms.ValidationError('Need to remove this actions. %s' % [str(v) for v in wrong_actions.values_list('rule_item_str_id', flat=True)])
        return sam_actions

    def clean(self):
        return self.cleaned_data

    def save(self):
        controlled_sam = CustomerControlSam.objects.filter(customer=self.customer_id)
        db_id_set = set([unicode(obj.sam_rule_item_id) for obj in controlled_sam])

        update_id_set = set(self.cleaned_data.get('sam_conditions', []) + self.cleaned_data.get('sam_actions', []))

        remove_set = db_id_set - update_id_set
        add_set = update_id_set - db_id_set
        for remove_rule_item_id in remove_set:
            controlled_sam.filter(sam_rule_item=remove_rule_item_id).delete()

        for add_rule_item_id in add_set:
            CustomerControlSam.objects.get_or_create(customer_id=self.customer_id, sam_rule_item_id=add_rule_item_id)
