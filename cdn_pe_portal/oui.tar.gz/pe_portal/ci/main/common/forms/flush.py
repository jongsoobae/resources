from django import forms
from ci.common.models.pusher import PusherToNodeUpdateFlush
from ci.common.utils.flush_api import flush_detail_by_req_id

class FlushLookupForm(forms.Form):
	site = forms.ChoiceField(label="PAD", choices=[(0, 'form not properly initialized')])
	complete_history = forms.ChoiceField(label="Max # of Flushes:", initial=50, choices=[(10,10),(50,50),(100,100),(1000,1000)])
	user = forms.CharField(label="Requester:", required=False)
	def __init__(self, *args, **kwargs):
		try:
			initial_sites = kwargs.pop('initial_sites')
		except KeyError:
			raise KeyError('FlushLookup constructor must have an initial_sites argument')
		super(FlushLookupForm, self).__init__(*args, **kwargs)
		self.fields['site'].choices = [(s.id, '%s [origin: %s]' % (s.pad, s.origin)) for s in initial_sites]

class FlushReceiptForm(forms.Form):
	id = forms.IntegerField(label="Flush Receipt ID")
	def __init__(self, *args, **kwargs):
		self.operr_flag = False
		try:
			self.operr_flag = kwargs.pop('operr_flag')
		except:
			pass
		try:
			self.authorized_sites = kwargs.pop('initial_sites')
		except KeyError:
			raise KeyError('FlushReceipt constructor must have an initial_sites argument')
		super(FlushReceiptForm, self).__init__(*args, **kwargs)
	def clean(self):
		try:
			request_id = self.cleaned_data.get('id', -1)
			receipt = flush_detail_by_req_id(request_id)
			if len(receipt) > 0:
				if (not self.operr_flag and self.authorized_sites.filter(pk=receipt.get('site_id', -1))) or \
						self.operr_flag:
					self.cleaned_data['receipt'] = receipt
			else:
				raise forms.ValidationError('Flush details not found. Either the ID you entered corresponds to a flush that has not been queued for processing, or you entered an invalid flush ID. Flushes are queued within minutes of submission, and flush records are removed after a few days.')
		except:
			#flush not found
			raise forms.ValidationError('Invalid flush ID. Flushes take a minute to appear and expire after a few days.')
		return self.cleaned_data
