from random import random, randrange, choice
from datetime import datetime, timedelta
from django import forms
from django.contrib.auth.models import User as AuthUser
from ci.common.models.cdn import Node
from ci.common.models.legacy_shield import CacheFragment
from ci.common.models.cache import NodeHashpoint
from ci.common.models.geo import Address
from ci.common.utils.mail import send_email

#NOTE: THIS FILE IS A STUB COPIED FROM CUSTOMER AND IS NOT COMPLETE DO NOT USE
class AddressForm(forms.ModelForm):
	class Meta:
		model = Address

class NodeForm(forms.ModelForm):
	#pop_short_name = forms.CharField(max_length=10)
	class Meta:
		model = Node
		exclude = ['create_user', 'modify_user', 'modify_time', 'create_time', 'id']
	def __init__(self, *args, **kwargs):
		if kwargs.has_key('fields'):
			self.Meta.fields = kwargs.pop('fields')
		instance = kwargs.get('instance',None)
		super(NodeForm, self).__init__(*args,**kwargs)

class ChangeNodeStatusForm(forms.Form):
	nodes = forms.MultipleChoiceField(required=True)
	change = forms.TypedChoiceField(label="Change the status of the selected nodes", empty_value=None, choices=[(None, '-------------'),(1, 'offline'), (2, 'offline/broken'), (3, 'online')], coerce=int)
	description = forms.CharField(required=True, min_length=4, max_length=100)
	def __init__(self, *args, **kwargs):
		self.pop = kwargs.pop('pop', None)
		self.band = kwargs.pop('band', None)
		self.user = kwargs.pop('user', None)
		self.nodes = self.pop.node_set.all() if self.pop else self.band.node_set.all()
		super(ChangeNodeStatusForm,self).__init__(*args, **kwargs)
		self.fields['nodes'].choices = [(u"%s" % str(node.id), '%s' % str(node.name())) for node in self.nodes]
	def clean(self):
		
		if not self.user.is_authenticated() or (not self.user.has_perm('oui.change_node') and not self.user.is_superuser):
			raise forms.ValidationError("You are not authorized to make node status changes. Please contact an engineer with your request.")
		if self.cleaned_data.has_key('nodes'):
			for node in self.cleaned_data['nodes']:
				if not CacheFragment.objects.filter(node=int(node)) and not NodeHashpoint.objects.filter(node=int(node)) and self.cleaned_data.get('change')==3:
					raise forms.ValidationError('Node %s (id(%s)) does not have any buckets or hashpoints and cannot be turned on for traffic' % (Node.objects.get(id=int(node)).name(), node))
		else:
			raise forms.ValidationError("No nodes selected. No action taken")
		return self.cleaned_data

class ChangeHashPointsForm(forms.Form):
	nodes = forms.ModelMultipleChoiceField(queryset=Node.objects.filter(pop__importance__gte = 0), required=True)
	target_points = forms.IntegerField(required=True, min_value = 1, initial=20)
	first_delay = forms.DateTimeField(initial=datetime.now())
	offset_minutes = forms.IntegerField(required=True, initial=240)
	def __init__(self, *args, **kwargs):
		band = kwargs.pop('band',None)
		super(ChangeHashPointsForm, self).__init__(*args,**kwargs)
		if band:
			self.fields['nodes'].queryset = Node.objects.filter(band = band)
	def get_affected_counts(self):
		"""This returns a dictionary of nodes and the net change in hashpoints that will occurr"""
		if self.errors:
			raise forms.ValidationError("Only accessible for valid forms")
		changes = {}
		target = self.cleaned_data.get('target_points')
		for node in self.cleaned_data.get('nodes'):
			changes[node] = target - len(node.hashpoints())
		return changes
	def change_hashpoints(self):
		"""This adds/removes hashpoints on nodes and then returns the changes made"""
		if self.errors:
			raise forms.ValidationError("Only accessible for valid forms")
		changes = {}
		next_time = self.cleaned_data.get('first_delay')
		offset_minutes = self.cleaned_data.get('offset_minutes')
		nodes = list(self.cleaned_data.get('nodes'))
		target = self.cleaned_data.get('target_points')
		#get total change count...
		new_points = 0
		for node in nodes:
			points = len(node.hashpoints())
			if points < target:
				new_points += target - points
		rand_points = [random() for x in range(new_points)]
		rand_points.sort(reverse=True)
		while len(nodes) > 0:
			node = choice(nodes)
			points = len(node.hashpoints())
			if not changes.has_key(node):
				changes[node] = ([],[])
			if points > target:
				#remove hashpoint
				nhs = NodeHashpoint.objects.filter(node = node, join_time__gt = datetime.now())
				if nhs.count() == 0:
					nhs = NodeHashpoint.objects.filter(node = node, join_time__lt = datetime.now())
				rand_point = randrange(0,len(nhs))
				changes[node][1].append(nhs[rand_point])
				nhs[rand_point].delete()
			elif points < target:
				#add hashpoint
				nh = NodeHashpoint(node = node, hashpoint = rand_points.pop(0) if len(rand_points) > 0 else random(), join_time = next_time)
				next_time += timedelta(minutes=offset_minutes)
				nh.save()
				changes[node][0].append(nh)
			else:
				#node is good
				nodes.remove(node)
		return changes
		

def node_changes(form_obj):
	change_list = []
	if form_obj.cleaned_data['change']==1:
		change_text = 'Offline'
	elif form_obj.cleaned_data['change']==2:
		change_text = "Offline/Broken"
	elif form_obj.cleaned_data['change']==3:
		change_text = "Online"
	for node_obj in form_obj.nodes:
		if str(node_obj.id) in form_obj.cleaned_data['nodes']:
			changed = False
			if form_obj.cleaned_data['change']==1 and node_obj.broken == 1:
				old_stat = "Offline/Broken"
				node_obj.broken=False
				node_obj.offline=True
				changed = True
			if form_obj.cleaned_data['change']==3 and node_obj.offline==1:
				old_stat = "Offline/Broken" if node_obj.broken else "Offline"
				node_obj.offline=False
				node_obj.broken=False
				changed = True
			if form_obj.cleaned_data['change'] == 1 and not node_obj.offline==1:
				old_stat = "Online"
				node_obj.offline = True
				node_obj.broken = False
				changed = True
			if form_obj.cleaned_data['change']==2 and not node_obj.broken==1:
				old_stat = "Online" if not node_obj.offline else "offline"
				node_obj.broken = True
				node_obj.offline = True
				changed = True
				node_obj.description += form_obj.cleaned_data['description']
			if changed:
				change_list.append((node_obj.name(), old_stat))
				node_obj.save()
	return change_list, change_text
	
