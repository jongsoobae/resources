import time
from datetime import datetime
from django import forms
from ci.constants import NO_REPLY, NOC
from ci.common.models.pusher import PUSH_NAMES, PUSH_VISIBLE, PUSH_SITESNG
from ci.common.models.cdn import Node
from ci.common.models.status import SystemStatus
from ci.common.utils.pusher import request_push, NGP_BEPusher, get_non_ngp_nodes
from ci.common.utils.cdn import get_all_nodes
from ci.common.utils.mail import send_email

class PushRequestForm(forms.Form):
    types = forms.MultipleChoiceField(label='Config Type(s)', choices=[(t, PUSH_NAMES.get(t, t)) for t in PUSH_VISIBLE])
    targets = forms.MultipleChoiceField(required=False, label='Target(s)',choices=[(0,'Click pick to fetch node names')])
    target_type = forms.ChoiceField(required=True, label='Target Type',choices=[('default','Default'), ('pick','Pick')])
    description = forms.CharField(min_length=4, max_length=200, label='Description', widget=forms.TextInput(attrs={'size':'100'}))
    skip_testing = forms.BooleanField(required=False, label="Skip Config Test", help_text="If enabled, pushed config(s) will be propagated to target production nodes without testing")
    stage_push = forms.BooleanField(required=False, label="Stage Push", help_text="If enabled, pushed config(s) will go to the staging queue, not to the production queue")
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super(PushRequestForm, self).__init__(*args, **kwargs)
        latest_status = SystemStatus.objects.filter(active=True, oui_only=True).latest('create_time')
        if not self.user.has_perm('oui.add_push'):
            self.fields['types'].choices = [(t, PUSH_NAMES.get(t, t)) for t in [PUSH_SITESNG]]
        if not self.user.is_superuser:
            self.fields.pop('skip_testing')
        if not self.user.has_perm('add_pushrequestjsontest') or not latest_status.turn_on_stage_queue:
            self.fields.pop('stage_push')
        # inject valid choices for nodes/sites if needed to prevent clean() from nuking them
        if len(args) > 0 and isinstance(args[0],dict) and args[0].get('target_type',None) == 'pick':
            self.__dict__['fields']['targets'].choices = [(n.id, n.name()) for n in get_all_nodes()]

    def clean(self):
        if self.cleaned_data["target_type"] == "pick":
            if len(self.cleaned_data["targets"]) == 0:
                raise forms.ValidationError({"targets": "\"Pick mode\" needs to choose one or more targets."})

        return self.cleaned_data

    def do_push(self):
        skip_testing = False
        stage_push = False

        if self.cleaned_data.get('skip_testing'):
            skip_testing = True
            send_email(NO_REPLY,NOC, 
                subject=u"[alert] un-tested push submitted by %s" %(self.user.username if self.user else 'Unknown'),  
                body=u"Push details...\n- User: %s\n- Date/Time: %s\n- Config(s): %s \n- Target(s): %s\n- Description: %s" 
                    %(self.user.username if self.user else 'Unknown', datetime.now().strftime('%Y-%m-%d %H:%M:%S'), ', '.join(map(PUSH_NAMES.get,self.cleaned_data['types'])), 
                    ', '.join(Node.objects.filter(id__in = self.cleaned_data['targets']).values_list('hostname',flat=True)) if self.cleaned_data['targets'] else "all", 
                    self.cleaned_data['description']))
        if self.cleaned_data.get('stage_push'):
            stage_push = True

        if self.cleaned_data['target_type'] == 'default':
            ngp_nodes = Node.objects.filter(ngp_flag=True)
            if ngp_nodes.exists():
                bepusher = NGP_BEPusher()
                be_request_push = bepusher.push(phase=self.cleaned_data['types'],
                                                request_user=self.user.username,
                                                description=self.cleaned_data['description'],
                                                skip_testing=skip_testing)

        """
        Pusher does not handle NGP node(s) ('npg_flag' is True) for efficiency of pusher process.
        So self.cleaned_data['targets'] has to define every Non NGP nodes.
        """

        non_ngp_node = get_non_ngp_nodes(self.cleaned_data['types'])
        if len(self.cleaned_data['targets']) > 0:
            non_ngp_node = non_ngp_node.filter(id__in=self.cleaned_data['targets'])

        non_ngp_node = non_ngp_node.values_list("id", flat=True)
        self.cleaned_data['targets'] = [i for i in non_ngp_node]

        if len(self.cleaned_data['targets']) > 0:
            request_push(
                self.cleaned_data['types'],
                self.cleaned_data['description'],
                '%s' %(self.user if self.user else 'Unknown'),
                self.cleaned_data['targets'],
                {'skip_testing': skip_testing}, 
                stage=stage_push)
        return True
