from hashlib import md5
from django import forms
from django.forms.util import flatatt
from django.utils.safestring import mark_safe
from django.utils import simplejson
from ci.common.models.site import Site
from ci.common.utils.country_codes import country_codes
from ci.common.utils.fields import RegexFormField, RawCharField, regex_valid, RegexCustFormField
from ci.constants import HTTP_RESPONSE_CODES


NON_LEAF_IDS = ('AND', 'OR')

class Node(object):
	"""Tree implementation to represent complex conditions for a Rule.
	 In case of one simple condition, we have only one node instance as the rules condition attribute"""
	def __init__(self, id=None, prism=False):
		self.__id = id
		self.__data = None
		self.__not = False
		self.__children = [] 
		self.__index = None
		self.__depth = 0
		self.__prism = prism
	def get_depth(self):
		return self.__depth
	def add_child(self, obj):
		assert isinstance(obj, Node)
		self.__children.append(obj)
	def set_id(self, id):
		self.__id = id
	def get_id(self):
		return self.__id
	def set_index(self, num):
		self.__index = num
	def get_index(self):
		return self.__index
	def has_children(self):
		if self.__children:
			return True
		else:
			return False
	def get_hash(self):
		try:
			return self.get_form().fields.get('object_hash').widget.attrs.get('value')
		except KeyError:
			return None
	def set_inverse(self, val):
		self.__not = True if val=='true' else False
	def is_inversed(self):
		return True if self.__not else False
	def get_form(self):
		return self.__data
	def children(self):
		return self.__children
	def find_child(self, index, hash):
		if self.get_hash() == hash and self.get_index() == index:
			return self
		else:
			if self.has_children():
				for child in self.children():
					found = child.find_child(hash=hash, index=index)
					if found:
						return found
 	def remove_branch(self, hash, index):
		for i in range(len(self.children())):
			if self.__children[i].get_hash()==hash and self.__children[i].get_index()==index:
				self.__children.pop(i)
				return None
			else:
				self.__children[i].remove_branch(hash=hash, index=index)
	def replace_child(self, hash, index, new_child):
		if self.get_hash()==hash and self.get_index()==index:
			self.set_form(new_child.get_form())
		else:
			if self.has_children():
				for i in range(len(self.children())):
					if self.__children[i].get_hash()==hash and self.__children[i].get_index()==index:
						self.__children.pop(i)
						self.__children.insert(i, new_child)
					else:
						self.__children[i].replace_child(hash=hash, index=index, new_child=new_child)
	def set_form(self, obj):
		self.__data = obj
		self.__id = obj.data.get('id')
	def get_dictionary(self):
		if self.__id not in NON_LEAF_IDS:
			ret = self.get_form().get_dictionary()
		else:
			ret = {'id':self.__id, 'c':[]}
			if self.__not:
				ret['not'] = 'true'
			for child in self.__children:
				ret['c'].append(child.get_dictionary())
		return ret
	def in_html(self, site,rule_id, template="", depth=0, oui=False, prism=False):
		"""Custom recursive function to build the html of the condition tree. Because Django sucks!"""
		if depth > self.__depth:
			self.__depth = depth
		delete_html = '| <a class="delete" id="condition" href="%s/site/server-actions/delete/?site_id=%d&rule_id=%d&site_hash=%s&hash=%s&cond_id=%d&item_type=condition">delete</a> ' % ('/oui' if prism else '',site.id, rule_id, site.samsandbox.server_actions_hash(), self.get_hash(), self.get_index())
		if self.get_id() in NON_LEAF_IDS:
			template += """<tr><td width="25px" colspan="%d">&nbsp;</td><td colspan="1">%s%s</td><td style="text-align:right">%s</td></tr>""" % \
			(depth+1, self.get_id(), " NOT" if self.is_inversed() else "","""<a href="%s/site/server-actions/edit-andor/?site_id=%d&rule_id=%d&site_hash=%s&cond_id=%d&hash=%s">edit</a>  %s| 
<a href="%s/site/%d/server-actions/choose/%d/condition/%d/%s/%s">add</a> |
<a href="%s/site/server-actions/edit-andor/?site_id=%d&rule_id=%d&site_hash=%s&cond_id=%d&new=%s&hash=%s">%s</a>"""%('/oui' if prism else '',site.id, rule_id, site.samsandbox.server_actions_hash(), self.get_index(), self.get_hash(),delete_html if not self.has_children() else '', '/oui' if prism else '',site.id, rule_id, self.get_index(),self.get_hash(), site.samsandbox.server_actions_hash(), '/oui' if prism else '',site.id, rule_id, site.samsandbox.server_actions_hash(), self.get_index(), 'AND' if self.get_id()=='OR' else 'OR', self.get_hash(), 'AND' if self.get_id()=='OR' else 'OR') if oui else '')
			for child in self.children():
				template += child.in_html(site, rule_id, depth=depth+1, oui=oui, prism=prism)
		else:
			template += self.get_form().html(rule_id, self.__index, site, depth=depth+1, oui=oui, prism=prism)
		return template
			
class Rule(object):
	def __init__(self, name, prism):
		self.name = name
		self.__actions = []
		self.__continue = None
		self.__condition = None
		self.__rule_id = None
		self.__site = None
		self.__oui = False
		self.__prism = prism
	def set_site(self, s):
		assert isinstance(s, Site)
		self.__site = s
	def set_view_attr(self, oui):
		self.__oui = oui
	def add_action(self, action_form):
		assert isinstance(action_form, Action)
		self.__actions.append(action_form)
	def add_condition(self, node, parent_hash=None, parent_index=None):
		assert isinstance(node, Node)
		if parent_index==-1:
			old_tree = self.condition()
			node.add_child(old_tree)
			self.__condition = node
			return None
		if self.__condition:
			parent = self.__condition.find_child(hash=parent_hash, index=parent_index)
			parent.add_child(node)
		else:
			self.__condition = node
	def set_proc(self, proc):
		self.__continue = proc
	def set_id(self, id):
		self.__rule_id = id
	def get_id(self):
		return self.__rule_id
	def get_proc(self):
		return self.__continue
	def get_dictionary(self):
		ret = {'do':[], 'name': self.name, 'proc':'1' if self.__continue in ('true', '1') else '0'}
		if self.__condition:
			ret['if'] = self.__condition.get_dictionary()
		for action in self.__actions:
			ret['do'].append(action.get_dictionary()) 
		return ret				
	def actions(self):
		return self.__actions
	def set_condition_tree(self, n):
		assert isinstance(n, Node)
		self.__condition = n
	def condition(self):
		return self.__condition
	def get_max_action_id(self):
		ret = -1
		if len(self.actions())>0:
			for action in self.actions():
				if action.get_action_id()>ret:
					ret = action.get_action_id()
		return ret
	def condition_html(self,  template=''):
		""" Making a custom function to render the condition tree because Django explicitly prohibits recursive use of templates"""
		return self.condition().in_html(self.__site, self.__rule_id, template, oui=self.__oui, prism=self.__prism)
	def __unicode__(self):
		return self.name
		
class ValuelessCheckboxInput(forms.CheckboxInput):
    def render(self, name, value, attrs=None):
        final_attrs = self.build_attrs(attrs, type='checkbox', name=name)
        #try:
        result = self.check_test(value)
        #except: # Silently catch exceptions
        #    result = False
        if result:
            final_attrs['checked'] = 'checked'
        return mark_safe(u'<input%s />' % flatatt(final_attrs))

class TextBooleanField(forms.BooleanField):
    widget = ValuelessCheckboxInput(check_test = lambda x: False if x in ['False', '0', 'false', False] else True)
    def clean(self, value):
        # """Returns a Python boolean object."""
        # Explicitly check for the string 'False', which is what a hidden field
        # will submit for False. Also check for '0', since this is what
        # RadioSelect will provide. Because bool("True") == bool('1') == True,
        # we don't need to handle that explicitly.
        if value in ('False', '0','false') :
            value = False
        else:
            value = bool(value)
        super(TextBooleanField, self).clean(value)
        if not value and self.required:
            raise forms.ValidationError(self.error_messages['required'])
        return 'true' if value else 'false'
				
class BaseObject(forms.Form):
	rules_hash = forms.CharField(widget=forms.HiddenInput, required=False)
	object_hash = forms.CharField(widget=forms.HiddenInput, required=False)
	custom = TextBooleanField(initial=False, required=False)
	def __init__(self, *args, **kwargs):
		super(BaseObject, self).__init__(*args, **kwargs)
		custom_field = self.fields.pop('custom')
		if self.get_id()!='CUS':
			self.fields['custom'] = custom_field
	def set_object_hash(self, obj):
		self.fields['object_hash'].widget.attrs = {'value':md5(obj).hexdigest()}
	def set_rules_hash(self, site_obj):
		self.fields['rules_hash'].widget.attrs = {'value':md5((site_obj.samsandbox.server_action_rules).encode('utf-8') if site_obj.samsandbox.server_action_rules else '').hexdigest()}
	def get_id(self):
		return self.id
	def get_name(self):
		return self.name
	def get_dictionary(self):
		if any(self.errors):
			raise forms.ValidationError("Can't use this unless all underlying form is clean")
		ret = {}
		for item, value in self.cleaned_data.items():
			if value != '' and not (item=='custom' and value=='false'):
				ret[item] = value
		ret['id'] = self.get_id()
		if ret['id'] == 'VMD':
			if ret.has_key('var_name'):
				ret['name'] = ret.pop('var_name')
			if ret.has_key('from_val'):
				ret['from'] = ret.pop('from_val')
		ret.pop('action_id', None)
		ret.pop('rules_hash', None)
		ret.pop('object_hash', None)
		return ret

class Condition(BaseObject):
	inverse = forms.ChoiceField(label="Match on",choices=[( 'false', 'Matches'),('true', 'Does not match')],initial=False, required=False, help_text="Inverse the result of the condition, true becomes false, and vice versa")
	m = RegexCustFormField(label="Match String", required=False, help_text="The string to match")
	x = TextBooleanField(initial=False, label="Regular Expression", required=False, help_text="Use regular expression during matching")
	nullOk = TextBooleanField(label="Accept Null",initial=False, required=False, help_text="Consider a 'null' input as matching (for example, if a header is not present in request)")
	split = forms.CharField(label="Split String", required=False, help_text='Will split the Match String using this character, then each token will be a possible match. For example if m="joe,tom" and split="," then condition will match "joe" or "tom"')
	caseSens = TextBooleanField(label="Case Sensitive", required=False, initial=False, help_text="Is matching case sensitive")
	extract = forms.CharField(label="Extract Variables", required=False, help_text="Extract the matched groups from regexp into Custom Variables")
	def __init__(self, *args, **kwargs):
		if len(args)>0 and args[0].has_key('not'):
			args[0]['inverse'] = args[0].pop('not', None)
		
		super(Condition, self).__init__(*args, **kwargs)
		if self.fields.has_key('custom'):
			self.fields['custom'].label = "Make this condition editable only in JSON"

	def get_dictionary(self):
		d = super(Condition, self).get_dictionary()
		if d.has_key('inverse'):
			d['not'] = d['inverse']
			d.pop('inverse', None)
		return d
	def html(self, rule_id, condition_index, site, depth=0, oui=False, prism=False):
		"""Function that displays the values of the condition in non-edit form. Used instead of a template so we can call it recursively on condition trees"""
		ret =  """<tr><td width="25px" colspan="%d">&nbsp;</td><td colspan="3" width="10px" style="border-left:solid 1px;">%s</td></tr>""" % (depth, self.name)
		for key, field in self.fields.items():
			if key not in ('rules_hash', 'object_hash', 'custom'):
				if field.label == 'Countries':
					row = """<tr><td colspan="%d">&nbsp;</td><td %s>&nbsp;</td>		  
					<td%s>%s%s</td>
					<td>%s</td>
				</tr>	""" % (depth,'style="border-left:solid 1px;"' if depth>0 else '', ' title="%s" class="tool-tip"'%field.help_text if field.help_text else '', field.label ,'*' if field.help_text else '', self.display_country_values())
				elif field.label == "Return Code":
					row = """<tr><td colspan="%d">&nbsp;</td><td %s>&nbsp;</td>		  
					<td%s>%s%s</td>
					<td>%s</td>
				</tr>	""" % (depth, 'style="border-left:solid 1px;"' if depth>0 else '',' title="%s" class="tool-tip"'%field.help_text if field.help_text else '',field.label,'*' if field.help_text else '', self.display_codes())
				else:
					if hasattr(field, 'choices'):
						choice_lookup = dict(field.choices)
						if self.data.has_key(key):
							if field.label == 'Mode':
								value = choice_lookup.get(int(self.data[key]))
							else:
								value = choice_lookup.get(self.data[key])
						else:
							value = field.initial
					else:
						if self.data.has_key(key):
							value = self.data[key]
						else:
							value = field.initial
					row = """<tr><td colspan="%d">&nbsp;</td><td %s>&nbsp;</td>
					<td%s>%s%s</td>
					<td>%s</td>
				</tr>	""" % (depth, 'style="border-left:solid 1px;"' if depth>0 else '',' title="%s" class="tool-tip"'%field.help_text if field.help_text else '',field.label if field.label else key,'*' if field.help_text else '', str(value))
			else:
				row = ''
			
			ret += row
			
		return ret

class HeaderCondition(Condition):
	def __init__(self, *args, **kwargs):
		super(HeaderCondition, self).__init__(*args, **kwargs)
		# rename labels
		self.fields['m'].label="Header value to match"
		# pop unused fields in the Header context
		# Finally, reorder fields for more logical workflow
		self.fields.keyOrder = ['h','m', 'inverse', 'nullOk', 'x','extract', 'custom','rules_hash', 'object_hash']
	h = forms.CharField(label="Header Name", help_text="Name of the header to match")
	def clean(self):
		return self.cleaned_data
	def get_dictionary(self):
		assert self.is_valid()
		d = super(HeaderCondition, self).get_dictionary()
		return d
		
class RequestHeaderCondition(HeaderCondition):
	id="RQH"
	name = "Request Header"
	def __unicode__(self):
		return self.get_name()

class ResponseHeaderCondition(HeaderCondition):
	id =  "RPH"
	name = "Response Header"
	def __unicode__(self):
		return self.get_name()
		
class StringCondition(Condition):
	id="STR"
	name = "String"
	string = forms.CharField(label="Input String", required=False, help_text="Input string to match against")
	def __unicode__(self):
		return self.get_name()
	
class IntegerCondition(Condition):
	id="INT"
	name ="Integer"
	value = forms.CharField(label="Input Value", required=False, help_text="The value to be checked.")
	min = forms.IntegerField(label="Minimum", required=False, initial=0, help_text="Minimum value of the range, inclusive")
	max = forms.IntegerField(label="Maximum", required=False, initial=0, help_text="Maximum value of the range, inclusive")
	def __init__(self, *args, **kwargs):
		super(IntegerCondition, self).__init__(*args, **kwargs)
		self.fields.pop('m', None)
		self.fields.pop('nullOk', None)
		self.fields.pop('x', None)
		
	def __unicode__(self):
		return self.get_name()

class RequestCookieCondition(Condition):
	id="RQC"
	name = "Request Cookie"
	c = forms.CharField(label="Cookie", required=False, help_text="Name of the cookie to match")
	

class HostInformationCondition(Condition):
	id="HOI"
	name = "Host Information"
	mode = forms.ChoiceField(label="Mode", initial=0, choices=[(0,"Full host name"), (1,"Short host name"), (2,"Default ip address of host"), (3,"Local ip address of host (VIP)")])

class ExtensionCondition(Condition):
	id="EXT"
	name = "Extension"
	
class FilePropertyCondition(Condition):
	id="PTY"
	name = "File Property"
	mode = forms.ChoiceField(label="Mode", initial=0, choices=[(0,"The size of file"), (1,"The reference count (the number of concurrent user using the file)"), (2,"The ram usage count (the number of times that the object served from ram cache)"),(3,"The time since file fetched from origin")])
	max = forms.IntegerField(label="Maximum", initial=0, help_text="Minimum value of the range, inclusive")
	min = forms.IntegerField(label="Minimum", initial=0, help_text="Maximum value of the range, inclusive")
	def __init__(self, *args, **kwargs):
		super(FilePropertyCondition, self).__init__(*args, **kwargs)
		self.fields.pop('m', None)
		self.fields.pop('nullOk', None)
		self.fields.pop('x', None)


import re
IP_RE   = re.compile(r"^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$")
IP_CIDR_RE = re.compile(r"^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])(\/(\d|[1-2]\d|3[0-2]))$")
regex_ip = re.compile(IP_RE)
regex_ip_cidr = re.compile(IP_CIDR_RE)

def ip_check(ip):
	is_ip = True
	is_cidr = True

	if not regex_ip.match(ip):
		is_ip = False
	if not regex_ip_cidr.match(ip):
		is_cidr = False

	if is_ip == False and is_cidr == False:
		return False
	else:
		return True


class UserIPCondition(Condition):
	id = "UIP"
	name = "User IP"
	def __init__(self, *args, **kwargs):
		super(UserIPCondition, self).__init__(*args, **kwargs)
		self.fields['m'].label="IP value to match"
		self.fields['m'].widget=forms.Textarea(attrs={'style':'height:330px;width: 500px'})
		self.fields.keyOrder = ['m', 'inverse', 'split', 'nullOk', 'x', 'extract','custom','rules_hash', 'object_hash']
	def clean(self):
		if not self.cleaned_data.get('m'):
			raise forms.ValidationError("You must enter a match string for this condition")
		if self.cleaned_data.get('x') == 'false':
			ip = self.cleaned_data.get('m')
			split = self.cleaned_data['split']
			if split == '':
				if not ip_check(ip):
					raise forms.ValidationError("Not IP address pattern ["+ip+"]")
			else:
				ips_arr = ip.split(split)
				for ip in ips_arr:
					if not ip_check(ip):
						raise forms.ValidationError("Not IP address pattern ["+ip+"]")

		return self.cleaned_data

class URLMatchCondition(Condition):
	id = "URL"
	name = "URL Match"
	mode = forms.ChoiceField(label="Mode", choices=[("0", "As it is being processed"), ("1", "As requested"), ("2", "After all translations are applied")], initial="0", help_text="Defines which step to look at URL")
	def __init__(self, *args, **kwargs):
		if args and not args[0].has_key('mode'):
			args[0]['mode'] = "0"
		super(URLMatchCondition, self).__init__(*args, **kwargs)
		self.fields.keyOrder = ['m','inverse', 'caseSens', 'nullOk', 'x', 'mode', 'extract','custom','rules_hash', 'object_hash']
	def get_dictionary(self):
		d = super(URLMatchCondition, self).get_dictionary()
		if not d.has_key('mode'):
			d['mode'] = 0
		return d
		
class ProtocolCondition(Condition):
	id = "PRO"
	name = "Protocol"
	m = forms.ChoiceField(label="Protocol", choices=[("", "---"),('http://', 'HTTP'), ("https://", "HTTPS")])
	def __init__(self, *args, **kwargs):
		super(ProtocolCondition, self).__init__(*args, **kwargs)
		self.fields.pop('x', None)
		self.fields.pop('nullOk', None)
		self.fields.keyOrder = ['m', 'inverse','extract', 'custom', 'rules_hash', 'object_hash']
	def clean(self):
		return self.cleaned_data		

class MethodCondition(Condition):
	id = "MET"
	name = "Method"	
	m = forms.ChoiceField(label="Method", choices=[('', '------'),('GET', 'Get'), ('POST', 'Post'), ('HEAD', 'Head')])
	def __init__(self, *args, **kwargs):
		super(MethodCondition, self).__init__(*args, **kwargs)
		self.fields.pop('x', None)
		self.fields.pop('nullOk', None)
		self.fields.keyOrder = ['m', 'inverse', 'extract','custom', 'rules_hash', 'object_hash']
	def clean(self):
		if not self.cleaned_data.get('m'):
			raise forms.ValidationError("You choose a method type to match")
		return self.cleaned_data

class ResponseCodeCondition(Condition):
	name = "Response Code"
	id = 'RPC'
	group = forms.ChoiceField(label="Code Group", required=False, help_text="Group of codes to match",choices=[("", "------"),("RC2xx", "Code in the 200 range"), ("RC3xx", "Code in the 300 range"),
	("RC4xx", "Response in the 400 range"), ("RC5xx", "Response in the 500 range"),("SUCCESS", "Match both the 200 and 300 range"), ("ERROR","Match 400  and 500 range")])
	rc = forms.MultipleChoiceField(label="Return Code", choices=[(key, "%s: %s"%(str(key), str(item))) for key, item in iter(sorted(HTTP_RESPONSE_CODES.iteritems()))],required=False, help_text="Choose one or more code(s) to match")
	error = TextBooleanField(label="Error Only", required=False, initial=False, help_text="Only match 503 code files that are the result of a transfer errors")
	def __init__(self,*args, **kwargs):
		try:
			if args[0].has_key('rc'):
				rc = args[0].get('rc').split(',')
				args[0]['rc'] = rc
		except:
			pass
		super(ResponseCodeCondition, self).__init__(*args, **kwargs)
		self.fields.pop('m', None)
		self.fields.pop('x', None)
		self.fields.pop('nullOk', None)		
		self.fields.keyOrder = ['group', 'rc', 'error', 'inverse', 'extract','custom', 'rules_hash', 'object_hash']
	def display_codes(self):
		if self.data.get('rc'):
			ret = ''
			for code in self.data.get('rc'):
				ret+="%s, " % code
			return ret[:-2]
		else:
			return "Not Applicable"
	def clean(self):
		if not self.cleaned_data.get('rc') and not self.cleaned_data.get('group'):
			raise forms.ValidationError("You must either choose a response code group or specific response codes to match")
		if self.cleaned_data.get('group') and self.cleaned_data.get('rc'):
			raise forms.ValidationError("You cannot choose specific response codes if you already chose a code group to match")
		return self.cleaned_data
	def get_dictionary(self):
		rc = ''
		d = super(ResponseCodeCondition, self).get_dictionary()
		if d.get('rc'):
			for c in d.get('rc'):
				rc += "%s," % c
			d['rc'] = rc[:-1]
		else:
			d.pop('rc', None)
		if not d.get('group'):
			d.pop('group', None)
		return d
		
class GeoLocationCondition(Condition):
	name = "Geo Location"
	id = 'GEO'
	countries = forms.MultipleChoiceField(label="Countries", choices=[(key, item) for key,item in iter(sorted(country_codes.iteritems()))], help_text="Choose one or more countries to match")
	def __init__(self,*args, **kwargs):
		try: #if passed a country list, change it to fit the multiple choice field syntax
			if args[0].has_key('countries'):
				countries = args[0].get('countries').split(',')
				args[0]['countries'] = countries
		except Exception, e: #nothing was passed, move on
			pass
		super(GeoLocationCondition, self).__init__(*args, **kwargs)
		self.fields.pop('m', None)
		self.fields.pop('x', None)
		self.fields.pop('nullOk', None)
		self.fields.keyOrder = ['countries', 'inverse', 'extract', 'custom', 'rules_hash', 'object_hash']
	def display_country_values(self):
		ret = ''
		for code in self.data.get('countries'):
			ret += "%s, " % (country_codes.get(code))
		return ret[:-2]
	def get_dictionary(self):
		codes= ''
		d = super(GeoLocationCondition, self).get_dictionary()
		for c in d.get('countries'):
			codes+= "%s," % c
		d['countries'] = codes[:-1]
		return d
		
class CustomCondition(Condition):
	name = "Custom"
	id = 'CUS'
	value = RawCharField(label="Custom condition", help_text="Valid JSON syntax required", widget=forms.Textarea(attrs={'rows': 4, 'cols':40}), required=False)
	def clean(self):
		if not self.cleaned_data.get('value'):
			raise forms.ValidationError('You must enter a condition in valid JSON syntax')
		if not regex_valid(self.cleaned_data.get('value')):
			raise forms.ValidationError("Can not have * followed by an *")
		try:
			cond_dict =  simplejson.loads(self.cleaned_data.get('value'))
		except:
			raise forms.ValidationError('Invalid JSON Syntax. Make sure all keys and values are wrapped in double quotes ("")')
		if not isinstance(cond_dict, dict):
			raise forms.ValidationError("The topmost object in this field has to be a dictionary. Please refer to Server Action documentation for more information.")
		if cond_dict.get("id") in SERVER_ACTION_CONDITIONS.keys() and not cond_dict.get("custom"):
			raise forms.ValidationError("The condition ID you entered exists as its own type but you did not add a custom flag. ")
		return self.cleaned_data
	def __init__(self, *args, **kwargs):
		if len(args)>0 and args[0].has_key('value') and isinstance(args[0]['value'], dict):
			#need to convert dict to string by json dumps
			args[0]['value'] = simplejson.dumps(args[0].get('value'))
		super(CustomCondition, self).__init__(*args, **kwargs)
		self.fields.pop('m', None)
		self.fields.pop('x', None)
		self.fields.pop('inverse', None)
		self.fields.pop('nullOk', None)
		self.fields.pop('split', None)
		self.fields.pop('caseSens', None)
		self.fields.pop('extract', None)
	def get_dictionary(self):
		assert not any(self.errors)
		cond_dict = self.cleaned_data['value']
		return simplejson.loads(cond_dict)

class Action(BaseObject):
	action_id = None
	on = forms.ChoiceField(label="Execution Time", choices=[("URQ", "On user request"), ("ORP", "On origin response"), ("SRP", "On cache response")], help_text="Time when to apply the action",required=False)
	def __init__(self, *args, **kwargs):
		super(Action, self).__init__(*args, **kwargs)
		if self.fields.has_key('custom'):
			self.fields['custom'].label = "Make this action editable only in JSON"
	def set_id(self, id):
		assert isinstance(id, int)
		self.action_id = id
	def get_action_id(self):
		return self.action_id
			
class HeaderOverrideAction(Action):
	on =  forms.ChoiceField(label="Execution Time",choices=[("ORP", "On origin response"), ("SRP", "On cache response")], initial='ORP', help_text="time when to apply the action", required=False)
	mode = forms.ChoiceField(label="Mode",choices=[("0", "Default header if not present"), ("1", "Override header")], initial="0", help_text="Mode of the filter to apply", required=False)
	h = forms.CharField(label="Header name", help_text="Header name (case-insensitive)", required=False)
	value = forms.CharField(label="Header value", help_text="Value of header (leave this field empty to remove the header)", required=False)
	def __init__(self, *args, **kwargs):
		if args and not args[0].has_key('on'):
			args[0]['on']='ORP'
		if args and isinstance(args[0].get('mode'), int):
			args[0]['mode'] = str(args[0].get('mode'))
		super(HeaderOverrideAction, self).__init__(*args, **kwargs)
		self.fields.keyOrder = ['h', 'value', 'mode', 'on', 'custom','rules_hash', 'object_hash']
	def get_dictionary(self):
		d = super(HeaderOverrideAction, self).get_dictionary()
		if not d.has_key('on'):
			d['on'] = 'ORP'
		return d
	def __unicode__(self):
		return self.get_name()

class RequestHeaderOverrideAction(HeaderOverrideAction):
	id="RHO"
	name="Request Header Override"
	def __init__(self, *args, **kwargs):
		super(RequestHeaderOverrideAction, self).__init__(*args, **kwargs)
		if self.fields.get('on'):
			self.fields['on'].choices = [("URQ", "Apply headers on user request to server, before processing"), ("SRQ", "Apply headers on server request to origin, after processing (e.g. drop IMS, VIA)")]
			self.fields['on'].initial = "URQ"

class ResponseHeaderOverrideAction(HeaderOverrideAction):
	id="OHO"
	name = "Response Header Override"
	
class DropQueryStringAction(Action):
	params = forms.CharField(label="Parameters", required=False, help_text="Comma-separated list of parameters to drop (case-insensitive). If null, drop full query string")
	id = "IQS"
	name =  "Drop Query String"
	def get_id(self):
		return self.id
	def __unicode__(self):
		return self.get_name()

class RequestFilterAction(Action):
	name = "Request Filter"
	id = "RFR"
	#NEED TO REMOVE "Redirect to a new URL" until 1.5.20 is released.
	#type = forms.ChoiceField(label="Filter to apply", required=False, choices=[('0', 'Continue processing request'), ('1', 'Return a 403'), ('2', "Redirect to a new URL")], initial='0')
	type = forms.ChoiceField(label="Mode", required=False, choices=[('0', 'Continue processing request'), ('1', 'Return a 403'), ('2', 'Return a 302')], help_text="Mode of the filter to apply", initial='0')
	redirect = forms.CharField(label="Redirect URL", help_text= "Specifies the url to redirect to (CRO object, see service note)",  required=False)
	def __init__(self, *args, **kwargs):
		super(RequestFilterAction, self).__init__(*args, **kwargs)
		self.fields.pop('on', None)
	def clean(self):
		if self.cleaned_data.get('type')=='2' and not self.cleaned_data.get('redirect'):
			raise forms.ValidationError("You must enter a redirect URL for that filter type")
		return self.cleaned_data

class URLRewriteAction(Action):
	name = "URL Rewrite"
	id = "URW"
	match = RegexCustFormField(label="From Value", help_text="Pattern to match", required=False)
	to = forms.CharField(label="To Value", help_text="Substitution string")
	full = TextBooleanField(label="Full URL rewrite", help_text="If true, rewrite using the entire url including the domain name. If false, use URI (relative path) only", required=False, initial=False)
	def __init__(self, *args, **kwargs):
		if kwargs.has_key('from'):
			kwargs['match'] =kwargs.pop('from', None)
		if args and args[0].has_key('from'):
			args[0]['match'] = args[0].pop('from', None)
		super(URLRewriteAction, self).__init__(*args, **kwargs)
		self.fields.pop('on', None)
	def get_dictionary(self):
		if any(self.errors):
			assert False, self.errors
		d = super(URLRewriteAction, self).get_dictionary()
		d['from'] = d.get('match')
		if d.get('from') == "":
			d.pop('from')
		d.pop('match', None)
		return d
	def clean(self):
		return self.cleaned_data
		
class BypassCacheAction(Action):
	mode = forms.ChoiceField(label = "Override mode", choices=[("0", "Edge servers go directly to origin "), ("1", "Edge servers go directly to shield")], initial="1", help_text="The mode of bypass", required=True)
	name = "Bypass Cache"
	id = "BYP"
	def __init__(self, *args, **kwargs):
		if args and isinstance(args[0].get('mode'), int):
			args[0]['mode'] = str(args[0].get('mode'))
		super(BypassCacheAction, self).__init__(*args, **kwargs)
		self.fields.pop('on', None)
	def get_dictionary(self):
		d = super(BypassCacheAction, self).get_dictionary()
		d.pop('on', None)
		return d
		
class ResponseOverrideAction(Action):
	name = "Response Override"
	id = "ORO"
	rc = forms.IntegerField(initial=0, label="New return code", required=False)
	redirect = forms.CharField(label="Redirect URL", help_text="URL redirect (CRO) to apply in case rc is 302", required=False)
	empty = TextBooleanField(label="Empty body", initial=False, required=False, help_text="Make response have no content")
	def clean(self):
		return self.cleaned_data
		
class OriginLogicControlAction(Action):
	name = "Origin Logic Control"
	id = "OLC"
	server = forms.CharField(label="Server Hostname", help_text="Origin server to use for validation. A specific port can be chosen", required=False)
	bypassOnFailure = TextBooleanField(label="Bypass on Connection Error", help_text="whether or not to accept request if the validation server cannot be reached", required=False, initial=False)
	defaultRedirect = forms.CharField(label="Default URL Redirect",help_text="Default url redirect (CRO) to apply in case server returns 302 with no location",  required=False)
	def __init__(self, *args, **kwargs):
		super(OriginLogicControlAction, self).__init__(*args, **kwargs)
		self.fields.pop('on', None)
	def clean(self):
		if not self.cleaned_data.get('server'):
			raise forms.ValidationError("You must enter a validation server")
		return self.cleaned_data

class URIAddStringAction(Action):
	id="UAS"
	name = "URI Add String"
	mode = forms.ChoiceField(label="Mode", initial=0, choices=[(0,"Prepend: add string at beginning of URI"), (1,"Append: add string at end of URI")])
	string = forms.CharField(label="String", required=False, help_text="The string to be appended/prepended")
	def __init__(self, *args, **kwargs):
		super(URIAddStringAction, self).__init__(*args, **kwargs)
		self.fields.pop('on', None)

class VariableModifyAction(Action):
	name="Variable Modify"
	id="VMD"
	var_name = forms.CharField(label="Variable name", required=False, help_text="Name of the variable")
	mode = forms.ChoiceField(label="Mode", initial=0, choices=[('0','Set: set to the "to" value'), ('1','Rewrite: apply a rewrite using the "from" and "to"'), ('2','Delete'), ('3','Uppercase: make value all upper-case'), ('4','Lowercase: make value all lower-case'), ('5','Trim: remove leading and trailing spaces'), ('6','Replace: replace any occurrence of "from" string with the "to" string')], help_text="Mode of action")
	from_val = forms.CharField(label="From Value", required=False, help_text="Beginning Value")
	to = forms.CharField(label="To Value", required=False, help_text="End value")
	def __init__(self, *args, **kwargs):
		if args and args[0].has_key('from'):
			args[0]['from_val'] = args[0].pop('from', None)
		if kwargs.has_key('name'):
			kwargs['var_name'] = kwargs.pop('name', None)
		if args and args[0].has_key('name'):
			args[0]['var_name'] = args[0].pop('name', None)
		super(VariableModifyAction, self).__init__(*args, **kwargs)
	
class MasterRedirectAction(Action):
	name = "Master Redirect"
	id= "MRD"
	def __init__(self, *args, **kwargs):
		super(MasterRedirectAction, self).__init__(*args, **kwargs)
		self.fields.pop('on', None)
		
class SetProxyingAction(Action):
	name="Set Proxying"
	id="PXY"
	proxy= TextBooleanField(label="File Proxying", initial=True, required=False, help_text="Flag specifying the proxy mode. If False, affinity object is stored in disk cache")
	def __init__(self, *args, **kwargs):
		super(SetProxyingAction, self).__init__(*args, **kwargs)
		#self.fields.pop('on', None)
	
class NoAction(Action):
	name = "No Action"
	id = "NOA"
	def __init__(self, *args, **kwargs):
		super(NoAction, self).__init__(*args, **kwargs)
		self.fields.pop('on', None)
		self.fields.pop('custom', None)
		
class CustomAction(Action):
	name = "Custom"
	id = "CUS"
	do = RawCharField(label="Custom action", help_text="JSON syntax required", widget=forms.Textarea(attrs={'rows': 4}), required=False)
	def __init__(self, *args, **kwargs):
		try:
			if args[0].has_key('do') and isinstance(args[0].get('do'),dict):
				#need to convert dict to string by json dumps
				try:
					args[0]['do'] = simplejson.dumps(args[0].get('do'))
				except:
					pass #tried...oh well...
		except:
			pass
		super(CustomAction, self).__init__(*args, **kwargs)
		self.fields.pop('on', None)	
	def clean(self):
		if not self.cleaned_data.get('do'):
			raise forms.ValidationError("You must enter an action in valid JSON syntax")
		try:
			do_dict = simplejson.loads(self.cleaned_data.get('do'))
		except:
			raise forms.ValidationError("Invalid JSON syntax")
		if not isinstance(do_dict, dict):
			raise forms.ValidationError("The topmost object in this field has to be a dictionary. Please refer to Server Action documentation for more information.")
		if do_dict.get('id') in SERVER_ACTION_ACTIONS.keys() and not do_dict.get("custom"):
			raise forms.ValidationError("The action ID you defined exists as its own type but you did not add a custom flag.")
		self.cleaned_data['do']= do_dict
		return self.cleaned_data
	def get_dictionary(self):
		assert not any(self.errors)
		do_dict={}
		# if self.get_id() in SERVER_ACTION_ACTIONS.keys():
		# 	do_dict['action_id'] = self.get_action_id()
		for item in self.cleaned_data.get('do').keys():
			do_dict[item] = self.cleaned_data.get('do')[item]
		return  do_dict
		
# Use these dicts to return instances of the right action/condition form instance
SERVER_ACTION_CONDITIONS = {
	'UIP': UserIPCondition,
	'URL': URLMatchCondition,
	'PRO': ProtocolCondition,
	'MET': MethodCondition,
	'RQH': RequestHeaderCondition,
	'RPH': ResponseHeaderCondition,
	'RPC': ResponseCodeCondition,
	'EXT': ExtensionCondition,
	'INT': IntegerCondition,
	'STR': StringCondition,
	'PTY': FilePropertyCondition,
	'HOI': HostInformationCondition,
	'RQC': RequestCookieCondition,
	'GEO': GeoLocationCondition,
	'CUS': CustomCondition
}

SERVER_ACTION_ACTIONS = {
	'RFR': RequestFilterAction,
	'URW': URLRewriteAction,
	'BYP': BypassCacheAction,
	'IQS': DropQueryStringAction,
	'OHO': ResponseHeaderOverrideAction,
	'RHO': RequestHeaderOverrideAction,
	'ORO': ResponseOverrideAction,
	'OLC': OriginLogicControlAction,
	'CUS': CustomAction,
	'UAS': URIAddStringAction,
	'VMD': VariableModifyAction,
	'MRD': MasterRedirectAction,
	'PXY': SetProxyingAction,
	'NOA': NoAction
}

class ChooseAction(forms.Form):
	new_id = forms.ChoiceField(label="Choose an action type to add",choices=[(key, item.name) for key, item in iter(sorted(SERVER_ACTION_ACTIONS.iteritems()))])

class ChooseCondition(forms.Form):
	new_id = forms.ChoiceField(label="Choose a condition type to add",choices=[(key, item.name) for key, item in iter(sorted(SERVER_ACTION_CONDITIONS.iteritems()))])
	def __init__(self, *args, **kwargs):
		rule = kwargs.pop('rule', None)
		super(ChooseCondition,self).__init__(*args, **kwargs)
class EditCondition(forms.Form):
	id = forms.ChoiceField(label="Choose whether you'd like to apply any or all the conditions", choices=[('','---'),('OR', 'OR'), ('AND', 'AND')])
	inverse = forms.BooleanField(label="Match this conditon group on failure", required=False, initial=False)
	rules_hash = forms.CharField(widget=forms.HiddenInput, required=False)
	object_hash = forms.CharField(widget=forms.HiddenInput, required=False)
	def set_rules_hash(self, site_obj):
		self.fields['rules_hash'].widget.attrs = {'value':md5(site_obj.samsandbox.server_action_rules if site_obj.samsandbox.server_action_rules else '').hexdigest() }
	def set_object_hash(self, obj):
		self.fields['object_hash'].widget.attrs = {'value':md5(obj).hexdigest()}
	
class EditRule(forms.Form):
	name = forms.CharField(label="Rule name", max_length=30)
	proc = TextBooleanField(label="Continue processing rules after this?", required=False)
	rules_hash = forms.CharField(widget=forms.HiddenInput, required=False)
	object_hash = forms.CharField(widget=forms.HiddenInput, required=False)
	def set_rules_hash(self, site_obj):
		self.fields['rules_hash'].widget.attrs = {'value':md5(site_obj.samsandbox.server_action_rules if site_obj.samsandbox.server_action_rules else '').hexdigest()}
	def set_object_hash(self, obj):
		self.fields['object_hash'].widget.attrs = {'value':md5(obj).hexdigest()}

def make_cond_tree(d, site, index=0):
	"""
		Recursive function that reads the condition dictionary of a rule and returns it as a condition form tree
		@param d: the current dictionary being traversed
		@param index: the node's count in breadth first traversal
		@param site: this is only used to add a full ruleset hash to the node's form
	"""
	new_node = Node(id=d.get('id'))
	new_node.set_index(index)
	if d.get('id') in NON_LEAF_IDS:
		form = EditCondition({'id':new_node.get_id(), 'inverse':True if d.get('not')=='true' else False})
		form.set_rules_hash(site)
		form.set_object_hash(form.__str__())
		new_node.set_inverse(d.get('not'))
		new_node.set_form(form)
		index += 1
		for item in d.get('c'):
			child_node, index = make_cond_tree(d=item, site=site, index=index)
			new_node.add_child(child_node)
		return (new_node, index)
	elif d.has_key('if'):
		d = d['if']
		return make_cond_tree(d, site, index=index)
	else:
		if d.has_key('custom') and ((isinstance(d.get('custom'), unicode) and d.get('custom').lower()=='true') or d.get('custom')==True):
			form = SERVER_ACTION_CONDITIONS['CUS']({'value':d, 'hash': md5(d.__str__()).hexdigest()})
			new_node.set_id('CUS')
		else:
			try:
				form = SERVER_ACTION_CONDITIONS[d['id']](d)
			except KeyError:
				form = SERVER_ACTION_CONDITIONS['CUS']({'value':d, 'hash': md5(d.__str__()).hexdigest()})
				new_node.set_id('CUS')
		form.set_rules_hash(site)
		form.set_object_hash(form.__str__())
		new_node.set_form(form)
		return (new_node, index+1)
		
		
def get_rule_objects(site, oui=False, prism=False):
	site_rules = site.json_server_actions()
	rules, rule_ids, missing_ids, cond_depths = [], [], [], []
	next_rule_id = 0
	for rule in site_rules:
		r = Rule(rule.get('name'), prism=prism)
		r.set_view_attr(oui)
		if rule.has_key('rule_id'):
			rule.pop('rule_id', None)
		r.set_id(next_rule_id)
		next_rule_id = next_rule_id+1
		r.set_proc(rule['proc'] if rule.has_key('proc') else '1')
		r.set_site(site)
		action_forms, action_ids, missing_action_ids = [],[],[]
		if rule.has_key('do'):
			max_action_id = 0
			for action in rule['do']:
				if action.has_key('custom') and action.get('custom').lower()=='true':
					a = SERVER_ACTION_ACTIONS['CUS']({'do':action, 'hash': md5(site.server_action_rules).hexdigest()})
				else:
					try:
						a = SERVER_ACTION_ACTIONS[action['id']](action)
					except KeyError:#Custom action is found
						a = SERVER_ACTION_ACTIONS['CUS']({'do':action, 'hash': md5(site.server_action_rules).hexdigest()})
				a.set_id(max_action_id)
				max_action_id = max_action_id+1
				a.set_rules_hash(site)
				r.add_action(a)
				action_forms.append(a)
		#if rule.has_key('if'):
		#	cond_tree = make_cond_tree(rule['if'], site)
		#	r.set_condition_tree(cond_tree[0])
		rules.append(r)
	return rules


def get_rule_objects_from_json(site, jsonobj, oui=False, prism=False):
        site_rules = jsonobj
        rules, rule_ids, missing_ids, cond_depths = [], [], [], []
        next_rule_id = 0
        for rule in site_rules:
                r = Rule(rule.get('name'), prism=prism)
                r.set_view_attr(oui)
                if rule.has_key('rule_id'):
                        rule.pop('rule_id', None)
                r.set_id(next_rule_id)
                next_rule_id = next_rule_id+1
                r.set_proc(rule['proc'] if rule.has_key('proc') else '1')
                r.set_site(site)
                action_forms, action_ids, missing_action_ids = [],[],[]
                if rule.has_key('do'):
                        max_action_id = 0
                        for action in rule['do']:
                                if action.has_key('custom') and action.get('custom').lower()=='true':
                                        a = SERVER_ACTION_ACTIONS['CUS']({'do':action, 'hash': md5(simplejson.dumps(jsonobj)).hexdigest()})
                                else:
                                        try:
                                                a = SERVER_ACTION_ACTIONS[action['id']](action)
                                        except KeyError:#Custom action is found
                                                a = SERVER_ACTION_ACTIONS['CUS']({'do':action, 'hash': md5(simplejson.dumps(jsonobj)).hexdigest()})
                                a.set_id(max_action_id)
                                max_action_id = max_action_id+1
				a.set_rules_hash(site)
                                r.add_action(a)
                                action_forms.append(a)
                if rule.has_key('if'):
                        cond_tree = make_cond_tree(rule['if'], site)
                        r.set_condition_tree(cond_tree[0])
                rules.append(r)
        return rules

