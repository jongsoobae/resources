import copy
import re
from django.core import cache
from django.forms import widgets
from django.forms.util import flatatt
from django.utils.encoding import force_unicode
from django.utils.html import conditional_escape
from django.utils.safestring import mark_safe
from django import forms
from django.shortcuts import get_object_or_404
from django.template.loader import get_template
from django.template import Context
from django.db.models import Q
from django.utils import simplejson
from ci.common.models.site import Site, SiteDraft, SiteStage, SiteDDosConvertRule
from ci.common.models import Service, ShieldedService, Product, DWA_MATERIALS
from ci.common.models import DnsZone
from ci.common.utils import get_customer
from ci.common.utils.api import APIException
from ci.common.utils.api.beian import get_beian_no
from ci.common.utils.sam_wizard import rule_validation
from ci.common.utils.site import getFieldsFromFieldset, ValidatorCertAndDomain, get_valid_origin_domain
from ci.common.utils.misc import padded_cop_product_id
from ci.common.utils.json_load_ordered import json_load_ordered

MA_PRODUCT = (1203, 1204)

def valid_address(address, address_type=None, with_path=False):
    if address_type=='origin':
        regex = r'^[\w\.\-/ \*?]+$' if with_path else r'^[\w\.\-\*?]+$'
    elif address_type=='pad':
        regex = r'^\*?[\w\.\-]+$'if with_path else r'^\*?[\w\.\-]+$'
    wildcard_count = address.count('*')
    string_match=re.match(regex, address)
    if len(re.findall('\.', address))<1 :
        return False
    if wildcard_count>1 or not string_match:
        return False
    else:
        return True


class SiteServerActionFields(widgets.Textarea):
    def __init__(self, *args, **kwargs):
        super(SiteServerActionFields, self).__init__(*args, **kwargs)

    def render(self, name, value, attrs=None):
        final_attrs = self.build_attrs(attrs)
        if not value:
            value = ''

        if final_attrs.get('readonly'):
            output = [
                '<div ',
                'readonly_id="' , final_attrs['id']+'_div" ',
                'class="'+ final_attrs.get('class', '') +'"',
                'style="width: 100%;"> ',
                '<pre>'+ value+ '</pre>',
                '</div>',
                '<input type="hidden" id="', final_attrs['id'], '" name="', name, '" value="',conditional_escape(force_unicode(value)) , '" >'
            ]
        else:
            output = [
                '<div ',
                'id="' , final_attrs['id']+'_div" ',
                'class="'+ final_attrs.get('class', '') +'"',
                'style="width: 100%; height: 500px;"> ',
                value,
                '</div>',
                '<input type="hidden" id="', final_attrs['id'], '" name="', name, '">'
            ]

        return mark_safe(u''.join(output))


class OriginField(forms.CharField):
    def __init__(self, *args, **kwargs):
        if 'help_text' not in kwargs:
            kwargs['help_text'] = Site._meta.get_field('origin').help_text
        super(OriginField, self).__init__(*args, **kwargs)
    def clean(self, value):
        """Validates that the input is a valid address, sans 'http://', optionally with a path after the domain.
    """
        super(OriginField, self).clean(value)
        if not valid_address(value, address_type='origin',with_path=True):
            raise forms.ValidationError('This is not a valid origin name. Make sure you do not include "http://" and there are no spaces. Only one wildcard character is allowed.')
        return get_valid_origin_domain(value)


class PADField(forms.CharField):
    def __init__(self, *args, **kwargs):
        if 'help_text' not in kwargs:
            kwargs['help_text'] = Site._meta.get_field('pad').help_text
        if 'label' not in kwargs:
            kwargs['label'] = 'PAD'
        super(PADField, self).__init__(*args, **kwargs)
        self.draft = None # will be set by EditPadForm if it has a SiteDraft instance
    def clean(self, value):
        """Validates that this PAD has a valid format and does not already exist in the system for some other site.
        """
        super(PADField, self).clean(value)
        if not valid_address(value, address_type='pad'):
            raise forms.ValidationError('This is not a valid pad name. Make sure you do not include "http://" and there are no spaces. The wildcard character can only be the first one. ')
        if self.draft:
            draft_sites = SiteDraft.objects.filter(pad=value)
            if draft_sites.exclude(pk=self.draft.id).exists():
                raise forms.ValidationError('This PAD is already in use.')
            if Site.objects.filter(pad=value).exists() and (not self.draft.site or self.draft.site.pad != value):
                raise forms.ValidationError('This PAD is already in use.')
        else:
            if Site.objects.filter(pad=value).exists() or SiteDraft.objects.filter(pad=value).exists():
                raise forms.ValidationError('This PAD is already in use.')
        return value.lower()


class DnsPrefix(forms.Field):
    def clean(self, value):
        value = super(DnsPrefix, self).clean(value)
        #if anyone changes this to allow subdomains they must block x<valid IP address>.<any string>
        if value and value.find('.') >= 0:
            raise forms.ValidationError("CNAME prefix can not contain a '.' (subdomains)")
        if value and value.find(' ') >= 0:
            raise forms.ValidationError("CNAME prefix can not contain any spaces")
        if value and (value.startswith("p") or value.startswith("s")) and value[1:].isdigit():
            raise forms.ValidationError("CNAME can not be in form of %s<numeric>" %(value[0]))
        return value


def is_prefix_in_use(cname, site=None, draft=None):
    if not cname:
        return False
    cnamed_sites = Site.objects.filter(cname_prefix=cname)
    if site and site.id:
        cnamed_sites = cnamed_sites.exclude(id = site.id)
    cnamed_drafts = SiteDraft.objects.filter(cname_prefix=cname)
    if draft and draft.id:
        cnamed_drafts = cnamed_sites.exclude(id = draft.id)
    if cnamed_sites.count() > 0 or cnamed_drafts.count() > 0:
        return True
    return False


class TabbedModelForm(forms.ModelForm):
    """Functions as follows:
        1. expects a Meta.fieldset
        2. expects fieldset to be the same objects as fields or a subset
        3. if
        3. if Meta.whitelist then will only display objects in this list/tuple...
    """

    def __init__(self, *args, **kwargs):
        self.proxy = kwargs.pop('proxy',False)
        super(TabbedModelForm, self).__init__(*args, **kwargs)
    def __unicode__(self):
        return unicode(self.as_tabs())
    def __str__(self):
        return str(self.as_tabs())
    def info(self):
        return self.Meta.model.__name__
    def as_tabs(self):
        entire_site = []
        group_errors = []
        blackset = set(self.Meta.blacklist) if hasattr(self.Meta,"blacklist") else None
        try:
            for group in self.Meta.fieldset:
                this_group_errors = 0
                entire_group = []
                sub_groups = group[1]

                if isinstance(sub_groups,dict):
                    #no subgroup so create subgroup with name of None...
                    sub_groups = [(None, sub_groups)]
                for sub_group in sub_groups:
                    fields = sub_group[1]['fields']
                    if not isinstance(fields,tuple):
                        fields = [fields] #to ensure it is iterable as 1 loop
                    final_fields = []
                    for field in fields:
                        if blackset and blackset.issuperset([field]):
                            continue #skip blacklisted elements
                        try:
                            form_field = self.__getitem__(field)
                            field_display = True
                            if form_field and form_field.errors:
                                this_group_errors+=1

                            final_fields.append((form_field.label, form_field.__unicode__(), form_field.help_text, True, None, form_field.errors if form_field and form_field.errors else None))
                        except:
                            model_field = self.Meta.model._meta.get_field(field)
                            final_fields.append((model_field.verbose_name, "", model_field.help_text, False, None, None))
                    if len(final_fields) > 0:
                        entire_group.append( (sub_group[0],sub_group[1].get('guides'),final_fields) )
                if len(entire_group) > 0:
                    entire_site.append( (group[0],entire_group) )
                    if this_group_errors > 0:
                        group_errors.append((group[0],this_group_errors))
        except Exception, e:
            return str("Internal Error - Contact Support")
        context = {
            'display_group': tuple(entire_site),
            'table_name': self.Meta.table_name if hasattr(self.Meta,'table_name') else self.Meta.model.__name__,
            'section': self.meta.section if hasattr(self.Meta,'section') else "",
            'default_value': '<i>Leave comment in request if required<i>',
            'group_with_flags': group_errors,
            'is_proxy': self.proxy,
        }
        return get_template('fragment/tabbed-display.html').render(Context(context))


def get_EditPadForm(editable_fields=SiteDraft.cui_editable_fields, customer=None, material_no_list=None,
                    shield_location=None, is_api=False, dup_request=False, **kwargs):
    """
    #TODO: refactoring needs. need to add 'is_api_request' flag
    :param editable_fields:
    :param customer:
    :param material_no_list: only came from UI.
    :param kwargs:
    :return:
    """

    class EditPadForm(TabbedModelForm):
        class Meta:
            model = SiteDraft
            fieldset = SiteDraft.fieldsets
            blacklist = SiteDraft.cui_view_blacklist + SiteDraft.cui_edit_blacklist
            fields = editable_fields
            table_name = "edit_pad"

        def clean_product(self):
            product = self.cleaned_data['product']
            if not product:
                product = self.instance.product if self.instance and self.instance.product else product
            if product:
                if not product.active:
                    raise forms.ValidationError("Product is expired. If you want to proceed, please contact support center.")
                if product.allow_add_pad_flag and product.sitedraft_set.count() >= product.count_per_contract:
                    raise forms.ValidationError('Can`t create PAD. Maximum count for %s is %s ' % (str(product), str(product.count_per_contract)))
            return product

        def clean(self):
            if len(self.errors) > 0:
                raise forms.ValidationError('')
            origin = self.cleaned_data.get('origin') if self.cleaned_data.has_key('origin') else None

            if self.instance and origin is None:
                origin = self.instance.origin
            pad = self.cleaned_data.get('pad') if self.cleaned_data.has_key('pad') else None
            if self.instance and pad is None:
                pad = self.instance.pad

            push_status = self.cleaned_data.get('push_status')
            if push_status in [1, 3]:
                raise forms.ValidationError('This pad[%s] is in pushing. please wait until pushing is done.' % pad)

            if pad.find('*') == -1:
                pass
            else:
                if self.cleaned_data.get('pad_aliases')>'':
                    raise forms.ValidationError(" Wildcard PADs do not support PAD aliases")

            alias_errors = pad_alias_check(pad, site=self.instance.site if self.instance.site else None, draft=self.instance if self.instance else None)
            if alias_errors:
                raise forms.ValidationError("Requested pad:\n" +alias_errors + ' <br/> A domain with this name already exists please open a ticket with support to convert this domain to a pad alias.')
            aliases = self.cleaned_data.get('pad_aliases')
            if aliases:
                aliases = aliases.lower()
                for one in aliases.splitlines():
                    alias_line_check=re.match(r'^([\w\-]+\.)+\w+$', one)
                    if not alias_line_check:
                        raise forms.ValidationError('Your pad aliases entry is invalid. Please make sure each pad alias has correct domain syntax and is on a separate line')
                    if one == pad:
                        raise forms.ValidationError('Your pad and aliases must be unique')
                alias_errors = pad_alias_check(aliases, site=self.instance.site if self.instance.site else None, draft=self.instance if self.instance else None)
                if alias_errors:
                    raise forms.ValidationError("Requested pad alias(es):\n" +alias_errors + ' <br/> A domain with this name already exists please open a ticket with support to convert this domain to a pad alias.')
                self.cleaned_data['pad_aliases'] = aliases

            if is_prefix_in_use(self.cleaned_data.get('cname_prefix'), draft=self.fields['pad'].draft if hasattr(self.fields.get('pad'),"draft") else None):
                raise forms.ValidationError("The custom cname prefix you requested is already in use.")
            if self.cleaned_data.has_key('origin'):
                self.cleaned_data['origin'] = get_valid_origin_domain(self.cleaned_data['origin'])
            if self.cleaned_data.has_key('pad'):
                self.cleaned_data['pad'] = self.cleaned_data['pad'].lower()

            for field, value in self.cleaned_data.items():
                if field in SiteDraft.cui_size_64k_limit_list:
                    if len(value) > 65535:
                        raise forms.ValidationError("%s input size limit is 65kb. If you want to proceed with this input, please contact support center" % field)
                if isinstance(value,unicode) or isinstance(value,str):
                    change=False
                    if value.find("\r\n") >= 0:
                        change = True
                        value = value.replace("\r\n","\n")
                    if value.find("\t") >= 0:
                        change = True
                        value = value.replace("\t"," ")
                    for char in range(0,32):
                        if char == 10:
                            continue
                        if value.find(chr(char)) >= 0:
                            change = True
                            value = value.replace(chr(char),"")
                    if change:
                        self.cleaned_data[field] = value

            if self.cleaned_data.has_key('origin_port'):
                if int(self.cleaned_data['origin_port']) < 0:
                    raise forms.ValidationError("Ensure Custom Origin Port, This value is greater than or equal to 0.")
                if int(self.cleaned_data['origin_port']) > 65536:
                    raise forms.ValidationError("Ensure Custom Origin Port, This value is less than or equal to 65536.")

            errors_withzone = pad_validation_withzone(pad, site=self.instance.site if self.instance.site else None, draft=self.instance if self.instance else None)
            if errors_withzone:
                raise forms.ValidationError("Requested pad:\n" +errors_withzone + ' \n validation with zone name failed.')

            return self.cleaned_data

        def _filter_product_for_api(self, product, material_list):
            if not product:
                return
            if not material_list:
                material_list = [product.product_cd]
            product_set = self.fields['product'].queryset.filter(product_cd__in=material_list)
            if self.instance and self.instance.pk:
                if self.instance.site:
                    self.fields['product'].queryset =product_set.filter(pk=self.instance.product.pk)
                    self.fields['product'].initial = self.instance.product
                else:
                    self.fields['product'].queryset =product_set
                    self.fields['product'].initial = product
            else:
                self.fields['product'].queryset =product_set
                self.fields['product'].initial = product


        def _filter_product_for_ui(self, material_list):
            if self.instance and self.instance.pk:
                if self.instance.site:
                    self.fields['product'].queryset = self.fields['product'].queryset.filter(pk=self.instance.product.pk)
                    self.fields['product'].widget.attrs['readonly'] = True
                    self.fields['product'].widget.attrs['disabled'] = True
                    return

            self.fields['product'].queryset = self.fields['product'].queryset.filter(product_cd__in=material_list)


        def _filter_product(self, _customer, product, material_list, is_api=False):
            self.fields['product'].queryset = self.fields['product'].queryset.filter(customer=_customer)
            if is_api:  # this means api call
                self._filter_product_for_api(product, material_list)
            else:
                self._filter_product_for_ui(material_list)

        def __init__(self, *args, **kwargs):
            customer = kwargs.pop('customer', None)
            product = kwargs.pop('product', None)  # passed from api call only
            is_api = kwargs.pop('is_api', None)
            dup_request = kwargs.pop('dup_request', None)
            material_list = kwargs.pop('material_no_list', None)
            super(EditPadForm, self).__init__(*args, **kwargs)
            draft = kwargs.get('instance')

            has_product = True
            if 'product' in self.fields:
                if customer:
                    if not customer.check_customer_has_self_product(material_list):
                        self.fields.pop('product')
                        has_product = False
                else:
                    self.fields.pop('product')
                    has_product = False

                if has_product:
                    self._filter_product(_customer=customer, product=product, material_list=material_list, is_api=is_api)

            if is_api:
                if not has_product:
                    if 'enable_ssl' in self.fields:
                        self.fields.pop('enable_ssl')
                    if 'upstream_ssl' in self.fields:
                        self.fields.pop('upstream_ssl')
                else:
                    if 'product' in self.fields:
                        initial_product = self.fields['product'].initial
                        if initial_product and initial_product.is_ssl_contract() and initial_product.is_self_implementable():
                            if draft is None and 'enable_ssl' not in self.fields: #oui-1954
                                self.fields['enable_ssl'] = forms.BooleanField(required=True, initial=True)
                        else:
                            if 'enable_ssl' in self.fields:
                                self.fields.pop('enable_ssl')
                            if 'upstream_ssl' in self.fields:
                                self.fields.pop('upstream_ssl')

            if 'pad' in self.fields:
                self.fields['pad'] = PADField()
            if 'origin' in self.fields:
                self.fields['origin'] = OriginField()
            if 'cname_prefix' in self.fields:
                self.fields['cname_prefix'] = DnsPrefix(required=False)
            if draft and 'pad' in self.fields:
                self.fields['pad'].draft = draft

    dup_request = kwargs.get('dup_request')
    dwa_fieldsets = copy.deepcopy(SiteDraft.fieldsets)
    basic_fields = [f for f in dwa_fieldsets[0][1]['fields']]
    if 'shield_location' not in basic_fields:
        if customer and customer.check_customer_has_self_product(material_no_list):
            basic_fields.insert(basic_fields.index('origin')+1, 'shield_location')
        dwa_fieldsets[0][1]['fields'] = tuple(basic_fields)

    class EditDWAPadForm(EditPadForm):
        shield_location = forms.ChoiceField()
        class Meta:
            model = SiteDraft
            fieldset = dwa_fieldsets
            blacklist = SiteDraft.cui_view_blacklist + SiteDraft.cui_edit_blacklist
            fields = editable_fields
            table_name = "edit_pad"

        def __init__(self, *args, **kwargs):
            product = kwargs.get('product')
            customer = kwargs.get('customer')
            dup_request = kwargs.pop('dup_request', None)

            data = kwargs.get('data', {})
            product_id = data.get('product', None)
            _shield_location = data.get('shield_location', kwargs.pop('shield_location', None))

            super(EditDWAPadForm, self).__init__(*args, **kwargs)

            try:
                if self.instance.pk: #edit mode
                    customer = self.instance.customer
                    product = self.instance.product or self.get_product(padded_cop_product_id(product_id))
                else: #add
                    product = self.get_product(padded_cop_product_id(product_id))
                if product and customer is None:
                    customer = product.customer

                self.fields['shield_location'].required = False
                if product and product.is_self_implementable():
                    if product.is_ssl_contract() :
                        if not self.instance.pk and 'enable_ssl' not in self.fields: #oui-1954
                            self.fields['enable_ssl'] = forms.BooleanField(required=True, initial=True)

                    if not dup_request:
                        self.fields['shield_location'].required = True

                if self.instance.pk:
                    if self.instance.is_self_implementable() and not dup_request:
                        self.fields['shield_location'].required = True
            except:
                pass

            dwa_products = Product.objects.filter(customer=customer, product_cd__in=DWA_MATERIALS)
            if product:
                dwa_products = dwa_products.filter(pk=product.pk)
            locations = []
            try:
                for product in dwa_products:
                    locations += [(l["location_id"], l["location_name"])
                                 for l in product.get_available_shield_locations()]
            except:
                locations = []
            self.fields['shield_location'].choices = tuple([('', '---------------',)] + (locations))
            if self.instance.pk: #edit
                self.fields['shield_location'].required = False
                if _shield_location:
                    self.fields['shield_location'].initial = int(_shield_location)
                else:
                    self.fields['shield_location'].initial = self.instance.shielded_service_id
            else: #add
                if _shield_location: #for api call
                    self.fields['shield_location'].initial = int(_shield_location)

        @classmethod
        def get_product(cls, pid):
            try:
                if str(pid).find('-') > -1:
                    return Product.objects.get(cop_product_id=padded_cop_product_id(pid))
                else:
                    return Product.objects.get(pk=pid)
            except (Product.DoesNotExist, Exception,):
                return None

        def clean(self):
            self.cleaned_data = super(EditDWAPadForm, self).clean()
            try:
                self.cleaned_data['shielded_service'] = self.cleaned_data['shield_location']
            except:
                pass
            return self.cleaned_data

        def save(self, *args, **kwargs):
            pad = super(EditDWAPadForm, self).save(*args, **kwargs)
            try:
                if self.cleaned_data['shield_location']:
                    pad.shielded_service_id = self.cleaned_data['shield_location']
            except Exception,e:
                pass
            return pad

    if is_dwa_product_request(material_no_list):
        return EditDWAPadForm(customer=customer, material_no_list=material_no_list,
                              shield_location=shield_location, is_api=is_api,dup_request=dup_request, **kwargs)
    else:
        return EditPadForm(customer=customer, material_no_list=material_no_list, is_api=is_api,dup_request=dup_request, **kwargs)

def is_dwa_product_request(material_no_list):
    is_dwa = False
    try:
        for material_no in material_no_list:
            if int(material_no) in DWA_MATERIALS:
                is_dwa = True
                break
    except:
        pass
    return is_dwa


class DuplicateForm(forms.Form):
    """You must pass a site_set argument to instantiate this formClass.
    That site set is in the format (pad_id, pad_name) to be used
    as a valid list of pad choices the user can use for duplication.
    """
    pad = PADField()
    copy_settings_from = forms.ChoiceField()
    product = forms.ModelChoiceField(queryset=Product.objects.all())
    def __init__(self, *args, **kwargs):
        self.site = kwargs.pop('site', False)
        self.site_set = kwargs.pop('site_set')

        customer = kwargs.pop('customer', None)
        is_api_call = kwargs.pop('is_api_call', None)
        dup_request = kwargs.pop('dup_request', None)
        material_no_list = kwargs.pop('material_no_list',None)
        super(DuplicateForm, self).__init__(*args, **kwargs)
        self.fields['copy_settings_from'].choices = self.site_set

        try:
            if is_api_call: #parameter came from api call
                data = kwargs.get('data', None)
                customer = data.pop('customer',None)
                contract_product = data.get('product',None)
                if contract_product is None:
                    self.fields.pop('product')
                else:
                    #need customer value in order to validate product ACL
                    self.fields['product'].queryset = self.fields['product'].queryset.filter(customer=customer)
                    self.fields['product'].queryset = self.fields['product'].queryset.filter(pk=contract_product)
                    self.fields['product'].initial = contract_product
            else:
                if not customer:
                    self.fields.pop('product')
                else:
                    if not customer.check_customer_has_self_product(material_no_list):
                        self.fields.pop('product')
                    else:
                        self.fields['product'].queryset = self.fields['product'].queryset.filter(customer=customer)
                        if material_no_list:
                            self.fields['product'].queryset = self.fields['product'].queryset.filter(product_cd__in=
                                                                                                     material_no_list)
            if dup_request:
                if self.fields.has_key('shield_location'):
                    self.fields.pop('shield_location')
        except:
            try:
                if self.fields.has_key('product'):
                    self.fields.pop('product')
            except:
                pass

    def save(self):
        if self.site:
            source = get_object_or_404(Site, pk=self.cleaned_data['copy_settings_from'])
        else:
            source = get_object_or_404(SiteDraft, pk=self.cleaned_data['copy_settings_from'])
        new_row = source.clone()
        if hasattr(new_row, 'pad_aliases'):
            new_row.pad_aliases = ''
        if hasattr(new_row, 'on_hold'):
            new_row.on_hold = False
        new_row.pad = self.cleaned_data['pad']
        new_row.push_status = 0
        if self.cleaned_data.has_key('product'):
            new_row.product = self.cleaned_data['product']

        new_row.save()
        return new_row

    def clean(self):
        if len(self.errors) > 0:
            raise forms.ValidationError('')
        pad = self.cleaned_data.get('pad')
        errors_withzone = pad_validation_withzone(pad, site=None, draft=None)
        if errors_withzone:
            raise forms.ValidationError("Requested pad:\n" +errors_withzone + ' \n validation with zone name failed.')
        return self.cleaned_data

class MassDuplicateForm(DuplicateForm):
    """This class is just a way to duplicate many forms at once"""
    pad = forms.CharField('PADs', help_text="Each line should contain a PAD.", widget=forms.Textarea())
    def clean(self):
        pads = self.cleaned_data.get('pad').split("\n")
        self.cleaned_data['pad'] = []
        pf = PADField()
        errors = []
        for pad in pads:
            if pad.strip() == "":
                continue
            try:
                clean_pad = pf.clean(pad.strip())
                if clean_pad in self.cleaned_data.get('pad'):
                    raise forms.ValidationError(['PAD in duplicate list multiple times.'])
                self.cleaned_data.get('pad').append(clean_pad)
            except forms.ValidationError, ve:
                for message in ve.messages:
                    errors.append('%s: %s' %(pad,message))
        if errors:
            raise forms.ValidationError(errors)
        return self.cleaned_data
    def save(self):
        pads = self.cleaned_data.get('pad')
        new_rows = []
        for pad in pads:
            self.cleaned_data['pad'] = pad
            new_rows.append(super(MassDuplicateForm,self).save())
        return new_rows

def pad_alias_check(form_aliases, site=None, draft=None):
    """a helper function to make sure any pad_alias entered in the edit form is not already in use by a PAD or draft"""
    raw_form_aliases = form_aliases.splitlines()
    clean_form_aliases = [a.strip() for a in raw_form_aliases]
    dup_alias=reduce(lambda x,y: x|y, [Q(pad_aliases__icontains=piece) for piece in clean_form_aliases] + [Q(pad=piece) for piece in clean_form_aliases])
    pad_dups = Site.objects.filter(dup_alias)
    draft_dups = SiteDraft.objects.filter(dup_alias) if draft else []
    dupstring, duplist = '',[]

    for this_id, queryset in ((site.id if site else None, pad_dups), (draft.id if draft else None, draft_dups)):
        for row in queryset:
            if this_id == row.id:
                continue# this means the result is the current site or the current draft
            if row.pad in clean_form_aliases:
                if row.pad not in duplist:
                    duplist.append(row.pad)
            if row.pad_aliases:
                alias=row.pad_aliases
            else:
                continue
            for one in alias.splitlines():
                if one in clean_form_aliases:
                    if one not in duplist:
                        duplist.append(one)
    dupstring=', '.join(duplist)
    return dupstring if dupstring else None

def get_dynamic_only_zones():
    cache_key = 'dynamic_only_zones'
    try:
        dynamic_only_zones = cache.get(cache_key)
    except:
        dynamic_only_zones = None
    if dynamic_only_zones is None:
        dynamic_only_zones = DnsZone.objects.filter(dynamic_cache__in = [1,2], status=True).values_list('domain_name',flat=True)
        #cache.set(cache_key, dynamic_only_zones, 30 * 60)
        try:
            cache.set(cache_key, dynamic_only_zones, 30 * 60)
        except:
            pass

    return dynamic_only_zones

def pad_validation_withzone(pad, site=None, draft=None, dynamic_only_zones = None):
    '''
     is cacheable?
    :param pad:
    :param site:
    :param draft:
    :return:
    '''
    duplist = []
    dynamic_only_zones = get_dynamic_only_zones()

    mpad_list = []
    fpad_list = []
    for zone in dynamic_only_zones:
        dot_zone = '.' + zone
        if pad.endswith(dot_zone):
            fpad_list.append(pad.split(dot_zone)[0])
        else:
            mpad_list.append(pad + dot_zone)

    if pad.endswith(dot_zone):
        #check Site with removed zone name
        fsites = Site.objects.filter(pad__in= fpad_list)
        if site:
            fsites = fsites.exclude(id=site.id)
        fdraft_sites = SiteDraft.objects.filter(pad__in = fpad_list)
        if draft:
            fdraft_sites = fdraft_sites.exclude(id=draft.id)
        if fsites.exists():
            duplist.append(fsites[0].pad)
        if fdraft_sites.exists():
            duplist.append(fdraft_sites[0].pad)

        #check service prefix
        services = Service.objects.filter(dns_prefix__in=fpad_list)
        if services.exists():
            duplist.append(services[0].dns_prefix)
    else:
        msites = Site.objects.filter(pad__in= mpad_list)
        if site:
            msites = msites.exclude(id=site.id)
        mdraft_sites = SiteDraft.objects.filter(pad__in = mpad_list)
        if draft:
            mdraft_sites = mdraft_sites.exclude(id=draft.id)
        if msites.exists():
            duplist.append(msites[0].pad)
        if mdraft_sites.exists():
            duplist.append(mdraft_sites[0].pad)

    return ', '.join(duplist) if duplist != [] else None

class DdosConvertRuleForm(forms.ModelForm):
    automated_service_prefix_change = forms.BooleanField(label="Automatic service prefix change on DDos attack", required=False)
    automated_set_cookie_samrule_change = forms.BooleanField(label="Automatic set-cookie sam rule change on DDos attack", required=False)
    edge_prefix_on_ddos = forms.ModelChoiceField(label='Edge prefix on ddos attack', queryset=Service.objects.distinct(), required=False)
    shielded_prefix_on_ddos = forms.ModelChoiceField(label='Shielded prefix on ddos attack', queryset=ShieldedService.objects.none(), required=False)
    server_action_rule_on_ddos = forms.CharField('Server action rule on ddos attack', help_text="json format text", widget=forms.Textarea(), required=False)
    description = forms.CharField(label="Description", widget=forms.TextInput(attrs={'size':50}), required=False)

    def __init__(self, *args, **kwargs):
        self.site = kwargs.pop('site', None)
        self.ddos_site_rule = kwargs.pop('ddos_site_rule', None)
        super(DdosConvertRuleForm, self).__init__(*args, **kwargs)
        self.fields.pop('event_status')
        if self.ddos_site_rule:
            self.fields['edge_prefix_on_ddos'].initial = self.ddos_site_rule.edge_prefix_on_ddos_attack
            self.fields['shielded_prefix_on_ddos'].queryset = ShieldedService.objects.filter(service=self.ddos_site_rule.edge_prefix_on_ddos_attack)
            self.fields['shielded_prefix_on_ddos'].initial = self.ddos_site_rule.shielded_prefix_on_ddos_attack
            self.fields['automated_service_prefix_change'].initial = self.ddos_site_rule.automated_service_prefix_change_enabled
            self.fields['automated_set_cookie_samrule_change'].initial = self.ddos_site_rule.automated_set_cookie_samrule_change_enabled
            self.fields['server_action_rule_on_ddos'].initial = self.ddos_site_rule.server_action_rule_on_ddos_attack
            self.fields['description'].initial = self.ddos_site_rule.description
        else:
            try:
                edge_prefix = kwargs.get('data').get('edge_prefix_on_ddos')
                self.fields['shielded_prefix_on_ddos'].queryset = ShieldedService.objects.filter(service__pk=int(edge_prefix))
            except:
                pass

    def clean(self):
        if self.cleaned_data:
            automated_service_prefix_change = self.cleaned_data.get('automated_service_prefix_change')
            edge_prefix = self.cleaned_data.get('edge_prefix_on_ddos')
            shielded_prefix = self.cleaned_data.get('shielded_prefix_on_ddos')
            if automated_service_prefix_change:
                if edge_prefix is None or shielded_prefix is None:
                    raise forms.ValidationError("Validation failed. If 'automatic service prefix change' is checked, edge prefix and shielded prefix is mandatory fields.")

            if edge_prefix and shielded_prefix is None:
                raise forms.ValidationError("Validation failed. 'Shielded prefix on ddos attack' field is empty.")

            if edge_prefix and self.site:
                if not edge_prefix.is_site_matches_with_ssl_key_store(self.site):
                    raise forms.ValidationError("Validation failed. 'SSL key store of edge prefix on ddos attack' is not matched with site pad name.")

            if self.site:
                try:
                    site_ddos_rule = SiteDDosConvertRule.objects.get(site=self.site)
                except SiteDDosConvertRule.DoesNotExist:
                    site_ddos_rule = None
                if site_ddos_rule and site_ddos_rule.is_service_prefix_ddos_attack_converted():
                    pass
                else:
                    if edge_prefix == self.site.service:
                        raise forms.ValidationError("Validation failed. Edge prefix is same with current service prefix.")

            try:
                server_action_rule = self.cleaned_data.get('server_action_rule_on_ddos')
                if server_action_rule:
                    rules = json_load_ordered(server_action_rule)
                    if isinstance(rules, list):
                        for rule in rules:
                            rule_validation(rule)
                    else:
                        rule_validation(rules)
                    self.cleaned_data['server_action_rule_on_ddos'] = simplejson.dumps(rules, indent=4)
            except APIException, e:
                raise forms.ValidationError("Validation failed. Invalid Format Error: %s" % e.message)
            except:
                raise forms.ValidationError("Validation failed. The server action rules you entered are invalid. Please check your syntax")
        return self.cleaned_data

    class Meta:
        model=SiteDDosConvertRule

class SiteForm(forms.ModelForm):
    high_rps_approval = forms.BooleanField(label="Approval has been granted from the Service Delivery team", required=False)
    skip_sync = forms.BooleanField(label="Link to existing COP domain (Jaguar PAD migration)", required=False)
    change_comment = forms.CharField(label="Reason for change", required=False)
    server_action_rules = forms.CharField(label="Server action rules", required=False, help_text="List of server action rules", widget=SiteServerActionFields())
    force_save_china_lic = forms.BooleanField(label="force_save_china_lic", required=False)
    force_save_sam = forms.BooleanField(label="force_save_sam", required=False)

    def __init__(self, *args, **kwargs):
        self.site = kwargs.pop('site', None)
        self.draft = kwargs.pop('draft', None)
        self.edit_type = kwargs.pop('edit_type', None)
        self.group_auth = kwargs.pop('group_auth', False)
        self.sam_json_edit = kwargs.pop('sam_json_edit', False)
        super(SiteForm, self).__init__(*args, **kwargs)
        if self.group_auth == False:
            if self.fields.has_key('nonwildcard_hour'):
                self.fields.pop('nonwildcard_hour')
            if self.fields.has_key('items_per_request'):
                self.fields.pop('items_per_request')
            if self.fields.has_key('all_per_hour'):
                self.fields.pop('all_per_hour')
            if self.fields.has_key('wildcards_per_hour'):
                self.fields.pop('wildcards_per_hour')
            if self.fields.has_key('wildcards_per_request'):
                self.fields.pop('wildcards_per_request')

        if not self.sam_json_edit:
            if self.draft:
                self.fields['server_action_rules'].widget.attrs['readonly'] = True
            else:
                if self.fields.has_key('server_action_rules'):
                    self.fields.pop('server_action_rules')

        if self.fields.has_key('origin'):
            self.fields['origin'] = OriginField()
        #get customer and draft
        try:
            draft = self.draft if self.draft else self.site.sitedraft
        except:
            draft = None
        if self.site:
            customer = self.site.customer
        elif self.draft:
            customer = self.draft.customer
        else:
            customer = None
        if not draft or not draft.need_high_rps_approval() or self.edit_type != "new draft":
            self.fields.pop('high_rps_approval')
        if not self.edit_type == 'new site':
            self.fields.pop('skip_sync')
        if self.fields.has_key('cname_prefix'):
            self.fields['cname_prefix'] = DnsPrefix(required=False)
        if not self.instance.pk and customer and customer.default_log_format:
            self.fields['request_log_msg_format'].widget.attrs['value'] = customer.default_log_format
        if customer and self.fields.has_key('service'):
            self.fields['service'] = forms.ModelChoiceField(queryset=Service.objects.filter(Q(customer = customer)|Q(customer__isnull = True)).exclude(status=False))

        if self.fields.has_key('product') and self.site and self.site.pk and self.site.product:
            #can only set product on add, never on edit...
            self.fields.pop('product')
            if self.fields.has_key('platform_cd'):
                self.fields.pop('platform_cd')
        elif customer and self.fields.has_key('product'):
            queryset=Product.objects.filter(customer = customer,active=True).order_by('-default','name')
            isMA = False
            for obj in queryset:
                if obj.product_cd in MA_PRODUCT:
                    isMA = True
            if isMA == False and self.fields.has_key('platform_cd'):
                self.fields.pop('platform_cd')

            initial = queryset.filter(default=True)[0].product_id if queryset.filter(default=True).count()>0 else None
            if not initial and queryset.count() == 1:
                initial = queryset[0].product_id
            self.fields['product'] = forms.ModelChoiceField(queryset=queryset, initial=initial)
            if queryset.count() == 0 and self.site and self.site.pk:
                #allow pads without products and no products available to continue to be edited (hack)
                self.fields.pop('product')

    def clean_track_codes(self):
        codes=self.cleaned_data['track_codes']
        if not re.match(r'^(\d+(,\d+)*)*$', codes):
            raise forms.ValidationError('Only numbers and commas are allowed in this field.')
        return codes

    def clean_content_variation_rules(self):
        cv_str = self.cleaned_data['content_variation_rules']

        cv_str = cv_str.replace('\r\n', '\n')
        cv_str_lines = cv_str.split('\n')
        for line in cv_str_lines:
            if not self.check_content_variation_valid(line):
                raise forms.ValidationError('May mass rule is in one line. Please check this rules.')

        return cv_str

    @classmethod
    def check_content_variation_valid(cls, cv_str_line):
        if not cv_str_line:
            return True
        try:
            first_blank_index = cv_str_line.index(' ')
            cv_keys = cv_str_line[first_blank_index + 1:].strip()
            cv_keys_split = cv_keys.split(';')
            for cv_key in cv_keys_split:
                cv_key = cv_key.strip()
                if cv_key.find(' ') > -1:
                    return False
            return True
        except (Exception, ):
            return False

    def check_sam_has_rho(self):
        sam_list = simplejson.loads(self.cleaned_data.get('server_action_rules') or '[]')
        for sam in sam_list:
            try:
                for action in sam['do']:
                    if str(action['id']).lower() == 'rho':
                        return True
            except Exception, e:
                continue
        return False

    def check_origin_has_invalid_ip(self):
        ip_regex = '^(\d)+\.(\d)+\.(\d)+\.(\d)+$'
        if re.match(ip_regex, self.cleaned_data.get('origin')) and not self.cleaned_data.get('cache_id') and not self.check_sam_has_rho():
            return True
        return False

    def clean(self):
        if self.cleaned_data.get('dns_entry_existing_time_limit') \
                and self.cleaned_data.get('dns_entry_existing_time_limit') < 0:
            raise forms.ValidationError("Ensure Dns entry existing time limit, This value is greater than or equal to 0.")
        if self.cleaned_data.get('origin_ip') and self.cleaned_data.get('use_origin_multiple_dns_record'):
            raise forms.ValidationError(
                "Both 'Static Origin IP' and 'Use multiple DNS records for Round-Robin origin selection' are cannot be used together.")
        if self.cleaned_data.get('use_origin_multiple_dns_record') and self.cleaned_data.get('backup_origin'):
            raise forms.ValidationError(
                "Both 'Failover Origin' and 'Use multiple DNS records for Round-Robin origin selection' are cannot be used together.")
        if self.cleaned_data.get('use_origin_sticky') \
                and self.cleaned_data.get('upstream_hash_source') != 1:
            raise forms.ValidationError("If 'use Origin sticky session', 'Upstream Hash Source' must be user_ip.")
        if not self.cleaned_data.get('pad') and not self.edit_type=='normal_api':
            raise forms.ValidationError("The field PAD cannot be left blank")
        if self.cleaned_data.get('pad') and self.cleaned_data.get('pad').find(' ') != -1:
            raise forms.ValidationError("PAD field cannot contain spaces")
        site_instance = self.site if self.site and self.site.id else None
        error_string = pad_alias_check(self.cleaned_data['pad'], site=site_instance)
        if error_string:
            raise forms.ValidationError("Requested pad:\n" +error_string + ' \n already in use.')
        if self.cleaned_data.get('origin'):
            _origin = self.cleaned_data.get('origin')
            if _origin.find(' ') != -1:
                raise forms.ValidationError("Origin field cannot contain spaces")
            if self.check_origin_has_invalid_ip():
                from django.forms.util import ErrorList
                self._errors['origin'] = ErrorList()
                self._errors['origin'].append('Input "pad ID" or Use RHO SAM rule for "HOST" on SRQ')

        if self.cleaned_data.get('pad') and not valid_address(self.cleaned_data.get('pad'), address_type='pad'):
            raise forms.ValidationError('This is not a valid pad name. Make sure you do not include "http://" and there are no spaces. The wildcard character can only be the first one. ')
        if (not self.site or not self.site.service or not self.Meta.fields or set(['service']).issubset(self.Meta.fields)) and not self.cleaned_data.get('service'):
            raise forms.ValidationError('Service field is required.')
        try:
            if site_instance: #site save. followings must not run when draft is saving.
                site_ddos_rule = SiteDDosConvertRule.objects.get(site=site_instance)
                if self.cleaned_data.get('service'):
                    if not self.cleaned_data.get('service').is_site_matches_with_ssl_key_store(site_instance):
                        raise forms.ValidationError("Validation failed. 'SSL key store of edge prefix on ddos attack' is not matched with site pad name. "
                                                    "You need to go 'Site view page' to correct the ddos rule.")

                if not site_ddos_rule.is_service_prefix_ddos_attack_converted() \
                        and site_ddos_rule.edge_prefix_on_ddos_attack == self.cleaned_data.get('service'):
                    raise forms.ValidationError("This site has DDos convert rule. Service can not be same with the service prefix of ddos convert rule.")
        except SiteDDosConvertRule.DoesNotExist:
            pass

        if self.fields.has_key('high_rps_approval') and self.draft and self.draft.need_high_rps_approval() and not self.cleaned_data.get('high_rps_approval'):
            raise forms.ValidationError("You must get Service delivery team approval before implementing this PAD")
        if (not self.site or not self.site.shielded_service or not self.Meta.fields or set(['shielded_service']).issubset(self.Meta.fields)) \
                and not self.cleaned_data.get('shielded_service'):
            shielded_services = self.cleaned_data.get('service').shieldedservice_set
            if shielded_services.distinct().count()>1:
                if shielded_services.filter(band_relations__isnull=True).exists():
                    raise forms.ValidationError("This customer uses shielding for other PADs. Please choose an appropriate shield or the 'no shield option'")
                raise forms.ValidationError("The edge service you selected only supports shielding configurations. Please choose a shield or create a 'no shield' option first")
            else:
                raise forms.ValidationError("The edge service you selected has no shielding or non-shielded options. Please create valid backend shielded services before you can use that edge service")
        if self.cleaned_data.get('force_ssl') and not self.cleaned_data.get('enable_ssl'):
            raise forms.ValidationError("You cannot force SSL unless the PAD is set to serve SSL")

        ssl_service = self.cleaned_data.get('service').ssl_cert if self.cleaned_data.get('service') else False
        if self.cleaned_data.get('service') and  self.cleaned_data.get('service').ssl_cert:
            ssl_alt_domains = [d.domain for d in self.cleaned_data.get('service').ssl_cert.keystoredomains_set.all()]
        else:
            ssl_alt_domains = []
        if (self.cleaned_data.get('force_ssl') or self.cleaned_data.get('enable_ssl')) and not ssl_service:
            raise forms.ValidationError("Cannot turn on '%s' unless the PAD is using a service with a keystore" % 'enable_ssl' if self.cleaned_data.get('enable_ssl') else 'force_ssl')
        if not ValidatorCertAndDomain.validate_for_pad(
                pad=self.cleaned_data.get('pad'),
                enable_ssl=self.cleaned_data.get('enable_ssl'),
                service=self.cleaned_data.get('service'),
                service_n_ssl_cert=self.cleaned_data.get('service').ssl_cert if self.cleaned_data.get('service') else None,
                service_n_sni_group=self.cleaned_data.get('service').sni_group if self.cleaned_data.get('service') else None,
        ):
            raise forms.ValidationError("Your PAD name does not match the domain of the SSL certificate you are trying to assign this to")
        """
        if ssl_service and self.cleaned_data.get('enable_ssl') and not self.cleaned_data.get('service').allow_nonmatching_domains:
            isValid = False
            if ssl_service.domain != '' and ssl_service.domain[0]=='*':
                if ssl_service.domain.partition('.')[2] == self.cleaned_data.get('pad').partition('.')[2]:
                    isValid = True
            else:
                if ssl_service.domain == self.cleaned_data.get('pad'):
                    isValid = True

            if isValid == False:
                for domain_check in ssl_alt_domains:
                    if domain_check != '' and domain_check[0] == '*':
                        if domain_check.partition('.')[2] == self.cleaned_data.get('pad').partition('.')[2]:
                            isValid = True
                    else:
                        if domain_check == self.cleaned_data.get('pad'):
                            isValid = True

            if isValid == False:
                raise forms.ValidationError("Your PAD name does not match the domain of the SSL certificate you are trying to assign this to")
        """

        if self.cleaned_data.get('pad') and self.cleaned_data.get('pad').find('*') == -1:
            pass
        else:
            if self.cleaned_data.get('pad_aliases') >'':
                raise forms.ValidationError(" Wildcard PADs do not support aliases")
        if self.cleaned_data.get('pad_aliases').find('*') >= 0:
            raise forms.ValidationError(" Wildcard aliases do not support")
        if self.draft:
            if SiteDraft.objects.filter(pad=self.cleaned_data['pad']).exclude(pk=self.draft.id).exists():
                raise forms.ValidationError('This PAD name is already in use.')
        else:
            if Site.objects.filter(pad=self.cleaned_data.get('pad')).exclude(pk=self.site.id).exists():
                raise forms.ValidationError('This PAD name is already in use.')
        if self.cleaned_data.get('pad'):
            self.cleaned_data['pad'] = self.cleaned_data.get('pad').lower()
        if self.cleaned_data.get('origin'):
            self.cleaned_data['origin'] = get_valid_origin_domain(self.cleaned_data.get('origin'))
        rules = None
        if self.cleaned_data.get('server_action_rules'):
            try:
                rules = simplejson.loads(self.cleaned_data.get('server_action_rules'))
                if not self.cleaned_data.get('force_save_sam'):
                    for rule in rules:
                        rule_validation(rule)
            except APIException, e:
                raise forms.ValidationError(
                    ['server_action_rules : ' + e.get_error_message_for_sam_error(),
                     'If you want to force save, check force_save_sam option.']
                )
            except:
                raise forms.ValidationError("The server action rules you entered are invalid. Please check your syntax")

        if rules != None and not isinstance(rules, list):
            raise forms.ValidationError("Rule set must be in the form of a list. Please adjust your input or use our SAM editor.")
        # if self.cleaned_data.get['cache_id'] > '' and cache_id_check(self.cleaned_data['cache_id'], self.cleaned_data['origin']):
        #     raise forms.ValidationError(cache_id_check(self.cleaned_data['cache_id'], self.cleaned_data['origin']))
        aliases = self.cleaned_data.get('pad_aliases')
        if aliases:
            aliases = aliases.lower()
            for one in aliases.splitlines():
                alias_line_check=re.match(r'^([\w\-]+\.)+\w+$', one)
                if not alias_line_check:
                    raise forms.ValidationError('Your pad aliases entry is invalid. Please make sure each pad alias is on a separate line')
                if one == self.cleaned_data.get('pad'):
                    raise forms.ValidationError('Your pad and aliases must be unique')
            if self.site and not self.draft:
                try:
                    draft_instance = SiteDraft.objects.get(site=self.site.id)
                except:
                    draft_instance=None
            error_string=pad_alias_check(aliases, site=self.site if self.site and self.site.id else None)
            if error_string:
                raise forms.ValidationError("Requested pad alias(es):\n" +error_string + ' \n already in use.')
            else:
                self.cleaned_data['pad_aliases'] = '\n'.join(aliases.splitlines())
        site = None
        draft = None
        if self.site:
            site = self.site
            customer = site.customer
            try:
                draft = site.sitedraft
            except:
                pass

        if self.draft:
            draft = self.draft
            customer = draft.customer
            if site == None:
                site = draft.site

        if site:
            tmpProduct = Product.objects.filter(customer = customer, active = True)
            if tmpProduct.count() > 0 and self.edit_type == 'new site' and  not self.fields.has_key('product'):
                raise forms.ValidationError("product field is requried.")

            if self.fields.has_key('status') and self.cleaned_data.get('status') == True:
                if self.site.product and self.site.product.active == False:
                    raise forms.ValidationError("this product is inactive.")

        if self.fields.has_key('product') and self.cleaned_data.get('product') != None and self.cleaned_data.get('product').product_cd in MA_PRODUCT and self.cleaned_data.get('platform_cd') == None:
            raise forms.ValidationError("platform cd field is requried, if product is not Acceleration for HTTP VOD, LIVE Streaming.")

        if self.fields.has_key('product') and self.cleaned_data.get('product') != None and self.cleaned_data.get('product').product_cd not in MA_PRODUCT and self.cleaned_data.get('platform_cd') != None:
            raise forms.ValidationError("platform cd field is not requried, if product is not Acceleration for HTTP VOD, LIVE Streaming.")

        if self.cleaned_data.get('service').is_use_china_pop():
            self.cleaned_data['china_lic'] = get_beian_no(self.cleaned_data['pad'])
            if not self.cleaned_data['china_lic'] and not self.cleaned_data['force_save_china_lic']:
                raise forms.ValidationError("The edge service chosen requires a chinese license, but beian API don`t return license no. \nIf you want to force save, check force_save_china_lic. ")
        else:
            self.cleaned_data['china_lic'] = ''

        if self.cleaned_data.get('default_rate')==customer.default_rate:
            raise forms.ValidationError("The default rate you chose is already used at the customer level. You only need to set a rate on a domain if it is not the same as the customer overall rate. ")
        if is_prefix_in_use(self.cleaned_data.get('cname_prefix'), site, draft):
            raise forms.ValidationError("The custom cname prefix you requested is already in use.")
        if self.cleaned_data.get('shielded_services')==0:
            raise forms.ValidationError( "You must choose a shielding option")
        dynamic_only_zones = DnsZone.objects.filter(dynamic_cache=2).values_list('domain_name',flat=True)
        for zone in dynamic_only_zones:
            if self.cleaned_data.get('pad') and self.cleaned_data.get('pad').endswith(zone):
                raise forms.ValidationError("You cannot use a pad name that ends in '%s' as that is the name of a dynamic only zone" % zone)

        if self.cleaned_data.has_key('origin_port'):
            if int(self.cleaned_data.get('origin_port')) < 0:
                raise forms.ValidationError("Ensure Custom Origin Port, This value is greater than or equal to 0.")
            if int(self.cleaned_data.get('origin_port')) > 65536:
                raise forms.ValidationError("Ensure Custom Origin Port, This value is less than or equal to 65536.")

        if not self.cleaned_data.get('use_origin_multiple_dns_record') and self.cleaned_data.get('use_origin_sticky'):
            raise forms.ValidationError("use_origin_sticky is not a valid, you can set use_origin_sticky only when use_origin_multiple_dns_record set.")

        errors_withzone = pad_validation_withzone(self.cleaned_data['pad'], site=self.site if self.site and self.site.id else None)
        if errors_withzone:
            raise forms.ValidationError("Requested pad:\n" +errors_withzone + ' \n validation with zone name failed.')

        if 'server_action_rules' in self.cleaned_data and self.cleaned_data['server_action_rules']:
            json_obj = json_load_ordered(self.cleaned_data['server_action_rules'])
            self.cleaned_data['server_action_rules'] = simplejson.dumps(json_obj, indent=4)

        if 'pad_aliases' in self.cleaned_data:
            pad_aliases = self.cleaned_data.get('pad_aliases', '')
            self.cleaned_data['pad_aliases'] = pad_aliases.replace('\r\n', '\n')

        return self.cleaned_data

    def save(self, customer_id, commit=True):
        site = super(SiteForm, self).save(commit=False)
        site.customer_id = customer_id
        if commit:
            site.save(skip_sync = self.cleaned_data.get('skip_sync'))
        return site

    class Meta:
        model=Site
        fields=getFieldsFromFieldset(Site.fieldsets, blacklist=('id','create_time', 'modify_time', 'customer'))

def get_message_from_api_exception(message):
    ret_msg = ''
    if not message:
        return ''
    if isinstance(message, basestring):
        return message
    else:
        try:
            return int(message)
        except:
            pass
        if isinstance(message, dict):
            for key, value in message.items():
                ret_msg = ret_msg + str(key) + ' -> ' + get_message_from_api_exception(value)
        elif isinstance(message, list):
            ret_msg += '['
            ret_msg += ','.join(message)
            ret_msg += ']'
    return ret_msg
