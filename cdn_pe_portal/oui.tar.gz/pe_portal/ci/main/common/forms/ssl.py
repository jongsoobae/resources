import os, string, random, stat
import hashlib
from django.utils.safestring import mark_safe
import pexpect
import M2Crypto as m2c
import pyDes
from time import sleep, strptime
from datetime import datetime
import shutil
import uuid
from ci.common.forms.admin import SSLKeystoreAdminSelectField
from django import forms
from django.core.exceptions import ObjectDoesNotExist
from django.db.models import Count
from ci.common.utils.sni_group import get_algorithm
from ci.common.utils.ssh_client import ssh_client
from ci.common.utils.mail import send_email
from ci.common.models.cdn import Service
from ci.common.models.customer import SSLKeystore, KeystoreDomains, Customer
from ci.constants import NO_REPLY, NOC_ADDR, KEYSTORE_HOST, KEYSTORE_USER, KEYSTORE_KEY_PRIV, KEYSTORE_PORT, KEYSTORE_PATH_PREFIX, TRUSTED_CERTS_PATH
from ci.common.utils.site import ValidatorCertAndDomain

def get_cert_list_oui(customer=None):

	from django.db import connection
	cursor = connection.cursor()

	active_dict, inactive_dict = {},{}
	active_certs, inactive_certs = [],[]
	cert_info = {}

	sql = """
		select `ssl_keystore`.`keystore_id`, `ssl_keystore`.`domain`,
		`customer`.name,
		COUNT(DISTINCT `keystore_domains`.`id`) AS `keystoredomains__count`,
		`ssl_keystore`.`description`
		from `ssl_keystore`
		inner join `customer` on `ssl_keystore`.customer_id = `customer`.customer_id
		LEFT OUTER JOIN `keystore_domains` ON (`ssl_keystore`.`keystore_id` = `keystore_domains`.`keystore_id`)
		where `ssl_keystore`.`upload_successful` = 1
		group by `ssl_keystore`.`keystore_id`, `ssl_keystore`.`domain`,
		`customer`.name;
	"""
	cursor.execute(sql)
	ret_all = cursor.fetchall()

	for ret in ret_all:
		if not cert_info.has_key(ret[0]):
			cert_info[ret[0]] = {'customer_name':ret[2],
								 'keystoredomains__count':ret[3],
								 'description':ret[4]}

	sql = """
		select `ssl_keystore`.`keystore_id`, `ssl_keystore`.`domain`, `ssl_keystore`.`expiration_date`,
		COUNT(`cdn_service`.`cdn_service_id`) AS `frontends__count`, if(`ssl_keystore`.`sni_group_id` > 0, 1 , 0)
		from `ssl_keystore`
		LEFT OUTER JOIN `cdn_service` ON (`ssl_keystore`.`keystore_id` = `cdn_service`.`keystore_id`)
		where `ssl_keystore`.`upload_successful` = 1
		group by `ssl_keystore`.`keystore_id`, `ssl_keystore`.`domain`, `ssl_keystore`.`expiration_date`;
	"""

	cursor.execute(sql)
	ret_all = cursor.fetchall()

	for ret in ret_all:
		domain = ret[1] if ret[1] != unicode('')  else cert_info[ret[0]].get('description')
		if ret[3] + ret[4] > 0:
			if ret[2]<datetime.now():
				type = 'expired'
			elif (ret[2]-datetime.now()).days < 90:
				type = 'soon'
			else:
				type = ''
			if not active_dict.has_key(ret[0]):
				active_dict[ret[0]] = {'keystore_id':ret[0]}
				active_certs.append(({'keystore_id':ret[0],
										'frontends__count':ret[3],
										'domain':domain,
										'customer_name':cert_info[ret[0]].get('customer_name'),
										'keystoredomains__count':cert_info[ret[0]].get('keystoredomains__count'),
									    'sni_group': ret[4]
										}, type))
		else:
			if ret[2] < datetime.now():
				type = 'expired'
			elif (ret[2]-datetime.now()).days < 90:
				type = 'soon'
			else:
				type = ''
			if not inactive_dict.has_key(ret[0]):
				inactive_dict[ret[0]] = {'keystore_id':ret[0]}
				inactive_certs.append(({'keystore_id':ret[0],
										'frontends__count':ret[3],
										'domain':domain,
										'customer_name':cert_info[ret[0]].get('customer_name'),
										'keystoredomains__count':cert_info[ret[0]].get('keystoredomains__count')
										}, type))

	inactive_certs.sort(lambda a,b: cmp(a[0]['keystore_id'], b[0]['keystore_id']))
	active_certs.sort(lambda a,b: cmp(a[0]['keystore_id'], b[0]['keystore_id']))
	return active_certs, inactive_certs


def get_cert_list(customer=None):
	if customer:
		cert_set = SSLKeystore.objects.filter(customer=customer, upload_successful=True)
	else:
		cert_set = SSLKeystore.objects.filter(upload_successful=True)

	cert_set = cert_set.select_related('customer')\
		.annotate(Count('frontends', disinct=True)).annotate(Count('keystoredomains', distinct=True))
	active_certs, inactive_certs = [],[]

	for cert in cert_set:
		if cert.frontends__count > 0:
			if cert.expiration_date<datetime.now():
				active_certs.append((cert, 'expired'))
			elif (cert.expiration_date-datetime.now()).days < 90:
				active_certs.append((cert, 'soon'))
			else:
				active_certs.append((cert, ''))
		else:
			if cert.expiration_date<datetime.now():
				inactive_certs.append((cert, 'expired'))
			elif (cert.expiration_date-datetime.now()).days < 90:
				inactive_certs.append((cert, 'soon'))
			else:
				inactive_certs.append((cert, ''))
	return active_certs, inactive_certs


def remove_cert(victim):
	domain = victim.domain
	#never allow a keystore that is assigned to a service be deleted
	if Service.objects.filter(ssl_cert=victim):
		message="SSL keystore for %s cannot be removed as it is currently in use by an edge service" % domain
	client = ssh_client()
	client.ssh_settings(host=KEYSTORE_HOST, user=KEYSTORE_USER, port=KEYSTORE_PORT, key_priv=KEYSTORE_KEY_PRIV)
	rm_in, rm_out, rm_err = client.ssh_command('rm %s02-ready/ks%d.p12; rm %s02-ready/ks%d.auth;' % (KEYSTORE_PATH_PREFIX, victim.keystore_id,KEYSTORE_PATH_PREFIX, victim.keystore_id), shell=True)
	err = rm_err.read()
	if err>'':
		victim.upload_successful = False
		victim.save()
		send_email(NO_REPLY, [NOC_ADDR], "Keystore removal failed", "The following error was encountered:\n%s"% err)
		message = "An error has occured. Your keystore entry will be removed manually."
	else:
		victim.delete()
		message="SSL keystore for %s has been removed from our system" % domain		
	return message
			
def cleanup_files(f_id=None):
	"""This will cleanup any files relating to ssl uploads from the local /tmp/ directory. Also any upload files left behind by Django."""
	tmp_file_list = os.listdir('/tmp/')
	for f in tmp_file_list:
		if f.endswith('.upload'):
			try:
				os.remove('/tmp/%s' % f)
			except:
				pass
		if f_id and (f.endswith('.auth') or f.startswith('crt') or f.endswith('.pem') or f.endswith('.p12') or f.startswith('ca')or f[1:].isdigit()) and not f.find(str(f_id))==-1:
			try:
				os.remove('/tmp/%s' % f)
			except:
				pass

class SSLUploadForm(forms.Form):
	customer = forms.TypedChoiceField(label='Customer to own this certificate', choices=[(None, '-----')], coerce=int)
	crt_file = forms.FileField(label="Certificate file")
	self_signed = forms.BooleanField(label="This is a self-signed certificate", required=False, help_text="Check this box to bypass certificate validation")
	ca_file = forms.FileField(label="Chain file",required=False)
	key_file = forms.FileField(label="Private Key file", required=False)
	psswd = forms.CharField(label="Key file password", widget=forms.PasswordInput, required=False)
	psswd_v = forms.CharField(label="Verify the key password", widget=forms.PasswordInput, required=False)
	notify = forms.EmailField(label="Notification email", help_text="This email will be used for all communication regarding this SSL service. ")
	ssl_cert = forms.ModelChoiceField(queryset=SSLKeystore.objects.all(), required=False, widget=SSLKeystoreAdminSelectField())
	description = forms.CharField(label="Description", required=False)
	confirm = forms.BooleanField(label='I have read the <a href= "/static/pdf/CDNetworks_SSL+Delivery+-+Service+Note.pdf" target="_blank"> SSL asset management policy and terms</a>')
	def __init__(self, *args, **kwargs):
		self.old_cert = kwargs.pop('old_cert', None)
		self.db_row = kwargs.pop('row', None)
		self.env = kwargs.pop('env', None)
		self.is_proxy = kwargs.pop('is_proxy', None)
		super(SSLUploadForm, self).__init__(*args, **kwargs)
		self.fields['customer'].choices += [(s.id, s.name) for s in Customer.objects.filter(status=True, using_private_certs=True)]
		if self.env=='portal':
			self.fields.pop('customer', None)
		else:
			self.fields.pop('confirm', None)
		if self.is_proxy:
			self.fields['confirm'].label = 'I have read the <a href= "/static/pdf/ocsp/CDNetworks_SSL+Delivery+-+Service+Note.pdf"> SSL asset management policy and terms</a>'

		if self.old_cert:
			self.fields['notify'].initial = self.old_cert.notification_email
			self.fields['crt_file'].label = "Certificate file for %s" % self.old_cert.domain
			if not self.env=='portal':
				self.fields['customer'].initial = self.old_cert.customer.id
		if 'ssl_cert' in self.fields:
			self.fields.pop('ssl_cert')

	def clean(self):
		if self.errors:
			cleanup_files()
			return self.cleaned_data
		flag_pfx_file = False
		if self.cleaned_data['crt_file'].name.endswith('.pfx'):
			flag_pfx_file = True

		crt_file_buff = self.cleaned_data['crt_file'].read()
		new_algorithm = get_algorithm(_crt_file=crt_file_buff)
		errors = []
		if self.old_cert and not self.old_cert.frontends:#we do not show the link to replace next to unused stores but just in case
			errors.append("You cannot replace a cert unless it is already in use by an active PAD")
		if self.old_cert and self.old_cert.sni_group:
			if new_algorithm and self.old_cert.algorithm != new_algorithm:
				errors.append(
					"You cannot replace a cert because SNI_Group %s used algorithm [%s], instead of [%s]." % (
						self.old_cert.sni_group, self.old_cert.algorithm, new_algorithm
					)
				)
		if self.cleaned_data.get('psswd') and not self.cleaned_data.get('psswd_v'):
			errors.append('You must verify the key file encryption password')
		elif self.cleaned_data.get('psswd') != self.cleaned_data.get('psswd_v'):
			errors.append("The passwords you entered do not match")
		if not self.cleaned_data.get('confirm') and self.env == 'portal':
			errors.append("You must confirm that you have read our SSL asset management policy and terms")
		if self.files.get('crt_file').size > 2097152:
			cleanup_files()
			errors.append("A cert file should not be larger than 2MB")
		if not flag_pfx_file:
			if not self.files.get('key_file'):
				raise forms.ValidationError({'key_file':['Private Key file is requried.']})
			if self.files.get('key_file').size > 2097152:
				cleanup_files()
				errors.append("A key file should not be larger than 2MB")
			if self.files.get('ca_file') and self.files.get('ca_file').size > 2097152:
				errors.append("A chain file should not be larger than 2MB")	
		if self.cleaned_data.get('customer'):
			try:
				customer = Customer.objects.get(pk=self.cleaned_data.get('customer'))
				self.cleaned_data['customer'] = customer
			except ObjectDoesNotExist: #this should never really happen but let's be prudent
				errors.append("This customer does not exxist. Please contact support")
		if not errors:
			k_pass = self.cleaned_data.get('psswd')
			if flag_pfx_file:
				crt_buff, key_buff, ca_buff, file_errors = get_file_info_from_pfx(pfx_file=crt_file_buff, k_pass=k_pass)
				k_pass = ''
			else:
				file_errors = ''
				crt_buff = crt_file_buff
				key_buff = self.cleaned_data['key_file'].read()
				ca_buff = self.cleaned_data.get('ca_file').read() if self.cleaned_data.get('ca_file') else None

			if not file_errors:
				file_errors = handle_asset_files(description = self.cleaned_data['description'], db_row = self.db_row, crt_file = crt_buff, key_file=key_buff, ca_file=ca_buff, k_pass=self.cleaned_data.get('psswd') if self.cleaned_data.get('psswd') else '', old_cert=self.old_cert if self.old_cert else None, self_signed=True if self.cleaned_data.get('self_signed') else False)
			if file_errors:
				cleanup_files(self.db_row.keystore_id)
				errors.append(mark_safe("""Validation failed, ensure all files were uploaded and a correct password was provided if protected.<br />Exact error message: (<a href=# style="color:red;" onclick='$("file_error").style.display=""; return false;'>Click here to view details</a>):<br/> <p id="file_error" style='display:none;'> %s</p> """%file_errors))
		if errors:
			raise forms.ValidationError(errors)
		self.cleaned_data['crt_file'] = crt_buff
		self.cleaned_data['key_file'] = key_buff
		self.cleaned_data['ca_file'] = ca_buff if ca_buff else None
		return self.cleaned_data

def get_file_info_from_pfx(pfx_file, k_pass):
	job_dir = '%d'%uuid.uuid4().int
	cert_file = None
	ca_file = None
	key_file = None
	error_msg = None

	try:
		os.makedirs('/tmp/%s/'%job_dir)
		ca_dest = open('/tmp/%s/pfx'%job_dir, 'wb+')
		ca_dest.write(pfx_file)
		ca_dest.close()

		#cert file
		str_command = 'openssl pkcs12 -in /tmp/%s/pfx -clcerts -nokeys -out /tmp/%s/pfx.crt -passin pass:%s'%(job_dir, job_dir, k_pass)
		dec = pexpect.run(str_command, timeout=3)
		if dec.find('MAC verified OK') == -1:
			raise Exception("%s"%dec)

		f = open('/tmp/%s/pfx.crt'%job_dir, 'r')
		cert_file = f.read()
		f.close()

		#chain file
		str_command = 'openssl pkcs12 -in /tmp/%s/pfx -cacerts -nokeys -out /tmp/%s/pfxCA.crt -passin pass:%s'%(job_dir, job_dir, k_pass)
		dec = pexpect.run(str_command, timeout=3)
		if dec.find('MAC verified OK') == -1:
			raise Exception("%s"%dec)
		f = open('/tmp/%s/pfxCA.crt'%job_dir, 'r')
		ca_file = f.read()
		f.close()

		#ke file
		str_command = 'openssl pkcs12 -in /tmp/%s/pfx -nocerts -out /tmp/%s/pfx.key -passin pass:%s'%(job_dir, job_dir, k_pass)
		child = pexpect.spawn(str_command)
		child.expect('Enter PEM pass phrase:')
		dec1 = child.sendline(k_pass)
		child.expect('Verifying - Enter PEM pass phrase:')
		dec1 = child.sendline(k_pass)
		child.expect (pexpect.EOF)

		str_command = 'openssl rsa -in /tmp/%s/pfx.key -out /tmp/%s/pfx.nopass.key'%(job_dir, job_dir)
		child = pexpect.spawn(str_command)
		child.expect('Enter pass phrase for /tmp/%s/pfx.key:'%job_dir)
		dec1 = child.sendline(k_pass)
		child.expect (pexpect.EOF)

		f = open('/tmp/%s/pfx.nopass.key'%job_dir, 'r')
		key_file = f.read()
		f.close()
	except Exception, e:
		error_msg = '%s'%e
	finally:
		if os.path.exists("/tmp/%s/"%job_dir):
			shutil.rmtree('/tmp/%s/'%job_dir)

	return cert_file, key_file, ca_file, error_msg


def replace_cert(cert, user):
	"""Given a cert object and a user, create a new one, replacing the customer and the date info and return the new one"""
	new_crt = SSLKeystore()
	new_crt.create_user = user
	new_crt.customer = cert.customer
	new_crt.description = cert.description
	new_crt.upload_successful = False
	return new_crt

def get_not_after_from_certstring(cert_str):
	temps = cert_str.split('\n')
	date_str = ''
	for temp in temps:
		if temp.strip().lower().startswith('not after'):
			subtemps = temp.strip().split(': ')
			date_str = subtemps[1]
			break
	return date_str

def populate_cert_data(cert_file,new_crt, email,self_signed=False, old_cert=None ):
	crt_obj = m2c.X509.load_cert_string(cert_file)
	domain = crt_obj.get_subject().__getattr__('CN')
	if not domain:
		domain = ''
	vendor = crt_obj.get_issuer().__getattr__('CN')
	crt_start = datetime(*strptime(crt_obj.get_not_before().__str__(), "%b %d %H:%M:%S %Y %Z")[0:6])
	date_str  = get_not_after_from_certstring(crt_obj.as_text())
	crt_expiration = datetime(*strptime(date_str.strip(), "%b %d %H:%M:%S %Y %Z")[0:6])
	if self_signed:
		new_crt.self_signed_cert=True
	if old_cert:
		services = old_cert.frontends.select_related(depth=1)
		new_crt.start_date = crt_start
		new_crt.domain= domain
		new_crt.expiration_date = crt_expiration
		new_crt.notification_email = email
		new_crt.cert_vendor = vendor
		new_crt.upload_successful = True
		new_crt.algorithm = get_algorithm(_crt_obj=crt_obj)
		if old_cert.sni_group:
			new_crt.sni_group = old_cert.sni_group
			old_cert.sni_group = None
			old_cert.save()

		new_crt.save()
		svc_id_list = [s.id for s in services]
		for service in services:
			service.ssl_cert = new_crt
			service.save(exclude_services=svc_id_list)
	else:
		new_crt.start_date = crt_start
		new_crt.cert_vendor = vendor
		new_crt.expiration_date = crt_expiration
		new_crt.domain = domain
		new_crt.upload_successful = True
		new_crt.notification_email=email
		new_crt.algorithm = get_algorithm(_crt_obj=crt_obj)
		new_crt.save()
	if old_cert:
		message="Your certificate for domain %s has been replaced. " % domain
	else:
		message="Your keystore for domain %s has been uploaded. " % domain
	return message
	
def handle_asset_files(db_row, crt_file, key_file, ca_file=None, k_pass='', old_cert=None, self_signed=False, description=''):
	message_key = "eaaf5Cf00F9AC3FFe16bE63C8ee0fc735f6CeA4648FBDb4C"
	if ca_file:
		try:
			ca = m2c.X509.load_cert_string(ca_file) 
		except m2c.X509.X509Error:
			cleanup_files(db_row.keystore_id)
			return "An invalid file was used as a chain file"
	else:
		ca=None
	try:
		crt_obj = m2c.X509.load_cert_string(crt_file)
	except m2c.X509.X509Error:
		cleanup_files(db_row.keystore_id)
		return "An invalid file was used as a certificate file"
	domain = crt_obj.get_subject().__getattr__('CN')
	if not domain:
		domain = ''
	domain_checklist = []
	if crt_obj.get_ext_count()>0:
		for i in range(crt_obj.get_ext_count()):
			if crt_obj.get_ext_at(i).get_name()=="subjectAltName":
				alternate_domains = crt_obj.get_ext_at(i).get_value()
				alternate_domains_list, domain_checklist = alternate_domains.split(','), []
				new_dom_row = KeystoreDomains()
				new_dom_row.keystore = db_row
				new_dom_row.domain = domain
				new_dom_row.save()
				for dom in alternate_domains_list:
					if dom.strip().startswith('DNS:'):
						new_dom_row = KeystoreDomains()
						new_dom_row.keystore = db_row 
						new_dom_row.domain = dom.strip().split("DNS:")[1].strip()
						new_dom_row.save()
						domain_checklist.append(new_dom_row.domain)
	#if not domain:
	#	return "This certificate does not have a common name, usually used for the domain name."

	if not domain and not description:
		return "This certificate does not have a common name. in this case, description is required."
	if old_cert:
		if old_cert.domain != domain:
			return 'The domain of this certificate does not match the domain of the certificate you are trying to replace'
		elif old_cert.start_date > datetime.now():
			return "You cannot replace an active certificate with another that is not active yet. "
		try:
			ValidatorCertAndDomain.validate_for_cert(old_cert=old_cert, domain_checklist=domain_checklist, new_cert=db_row)
		except Exception, e:
			return e.message

		"""
		if old_cert.keystoredomains_set.count()>0:
			for frontend in old_cert.frontends.all():
				if not frontend.allow_nonmatching_domains:
					for site in frontend.site_set.all():
						isValid = False
						if not site.enable_ssl:
							continue

						if domain and domain[0] == '*':
							if domain.partition('.')[2] == site.pad.partition('.')[2]:
								isValid = True	
						else:
							if domain == site.pad:
								isValid = True

						if isValid == False:
							for domain_check in domain_checklist:
								if domain_check[0] == '*':
									if domain_check.partition('.')[2] == site.pad.partition('.')[2] and site.enable_ssl:
										isValid = True
								else:
									if domain_check == site.pad and site.enable_ssl:
										isValid = True
						if isValid == False:
							return "%s uses the original certificate on edge service %s and is not compatible with this new certificate" % (site.pad, frontend.dns_prefix)
		"""

	# if there is already a database entry with this domain name, just return an error before writing anything to disk
	#elif SSLKeystore.objects.filter(domain=domain, upload_successful=True):
	#	return 'A keystore with this domain name already exists. Use the <a style="color:red;text-decoration:underline;" href="/ssl-assets"> replace form </a> if you are trying to replace an existing record'
	ks_pass = ''.join( random.Random().sample(string.letters+string.digits, 25) )
	num = db_row.keystore_id
	crt_dest = open('/tmp/crt%d' % num, 'wb+')
	os.chmod('/tmp/crt%d' % num,  stat.S_IMODE(0600))
	crt_dest.write(crt_file)
	crt_dest.close()
	if ca_file:
		ca_dest = open('/tmp/ca%d' % num, 'wb+')
		os.chmod('/tmp/ca%d' % num,  stat.S_IMODE(0600))
		ca_dest.write(ca_file)
		ca_dest.close()
	if not self_signed:
		verify_command = "openssl verify -CApath %s  %s /tmp/crt%d" % (TRUSTED_CERTS_PATH, "-CAfile /tmp/ca%d" % num if ca_file else '', num)
		ver = pexpect.run(verify_command, timeout=10)
		if ver.find('/tmp/crt%d: OK' % num) == -1:
			cleanup_files(db_row.keystore_id)
			return ver if ver else 'verify failed.'
	k_dest = open('/tmp/k%d' % num, 'wb+')
	os.chmod('/tmp/k%d' % num,  stat.S_IMODE(0600))
	k_dest.write(key_file)
	k_dest.close()
	if k_pass != '':# if the key was supplied with a password. It is used to strip the key then the new PEM file is used in lieu of the original password encrypted key
		decrypt_command = "openssl rsa -in /tmp/k%d -out /tmp/k%d.pem -passin pass:%s" % (num, num, k_pass)
		dec = pexpect.run(decrypt_command, timeout=10)
		if dec.find('bad decrypt') != -1:
			cleanup_files(db_row.keystore_id)
			return "%s"% dec if dec else 'decrypt failed.'
	export_command = "openssl pkcs12 -export -in /tmp/crt%d -inkey /tmp/k%d%s -out /tmp/ks%d.p12 -name '%s' -passout pass:%s %s  -rand /dev/urandom" % (num, num, '.pem' if k_pass !='' else '',num, domain.replace('.', '_').replace('*', 'star'), ks_pass, "-certfile %s -caname %s" % ('/tmp/ca%d' % num, 'ks%d.chain' % num) if ca_file else '' )
	export = pexpect.run(export_command, timeout=10)
	if export.find('Error')!= -1 or os.stat('/tmp/ks%d.p12'%num)[6]<1:
		cleanup_files(db_row.keystore_id)
		return "%s" % export if export else 'export failed.'

	#if os.stat('/tmp/ks%d.p12'%num)[6]>9722:
	#	c_size = os.stat('/tmp/ks%d.p12'%num)[6]
	#	cleanup_files(db_row.keystore_id)
	#	return 'ks%d.p12 must be less then or esqual to 9722, this file size is %d'%(num,c_size)

	p12_m5 = hashlib.md5()
	p12_m5.update(open('/tmp/ks%d.p12'%num).read())
	p12_hash = p12_m5.hexdigest()
	os.chmod('/tmp/ks%d.p12' % num,  stat.S_IMODE(0600))
	des_3 = pyDes.triple_des(message_key.decode('hex'), mode = pyDes.ECB, padmode=pyDes.PAD_PKCS5)
	kp = open('/tmp/ks%d.auth' % num , 'wb+')
	os.chmod('/tmp/ks%d.auth' % num,  stat.S_IMODE(0600))
	kp.write(des_3.encrypt(ks_pass))
	kp.close()
	auth_m5 = hashlib.md5()
	auth_m5.update(open('/tmp/ks%d.auth'%num).read())
	auth_hash = auth_m5.hexdigest()

	client = ssh_client()
	client.ssh_settings(host=KEYSTORE_HOST, user=KEYSTORE_USER, port=KEYSTORE_PORT, key_priv=KEYSTORE_KEY_PRIV)
	# Check that there are no files on ks.pcdc.com with the same names. This should never happen since we are using the unique db row id but just in case
	remote_list = client.ssh_command('ls %s02-ready/' % KEYSTORE_PATH_PREFIX, shell=True)[1].read().splitlines()
	if 'ks%d.p12' % num in remote_list or 'ks%d.auth' % num in remote_list:
		cleanup_files(db_row.keystore_id)
		return "The files created already exist in the remote server"
	#send the files then move them to the ready folder. The sleep is to keep python from getting ahead of itself
	p12_scp_in, p12_scp_out, p12_scp_err = client.scp_to_server(local_path='/tmp/ks%d.p12'%num, dest_path='%s01-incoming/' % KEYSTORE_PATH_PREFIX, shell=True)
	while not p12_scp_out:
		sleep(1)
	p12_error_text = p12_scp_err.read()
	if p12_error_text>'':
		cleanup_files(db_row.keystore_id)
		return "The following error occured while transferring your keystore file: %s" % p12_error_text
	if not p12_hash == client.ssh_command("md5sum %s01-incoming/ks%d.p12" % (KEYSTORE_PATH_PREFIX,num), shell=True)[1].read().split(' ')[0].strip():
		cleanup_files(db_row.keystore_id)
		i,o,e = client.ssh_command("md5sum %s01-incoming/ks%d.p12" % (KEYSTORE_PATH_PREFIX,num), shell=True)
		return "Keystore file was corrupted during transfer"
	client.ssh_command('chmod 440 %s01-incoming/ks%d.p12' % (KEYSTORE_PATH_PREFIX,num))
	db_row.ks_file_hash = p12_hash
	db_row.save()
	auth_scp_in, auth_scp_out, auth_scp_err = client.scp_to_server(local_path='/tmp/ks%d.auth'%num, dest_path='%s01-incoming/' % KEYSTORE_PATH_PREFIX, shell=True)
	while not auth_scp_out:
		sleep(1)
	auth_error_text = auth_scp_err.read()
	if auth_error_text>'':
		cleanup_files(db_row.keystore_id)
		return "An error occured while tranferring the authentication file."
	if not auth_hash == client.ssh_command("md5sum %s01-incoming/ks%d.auth" % (KEYSTORE_PATH_PREFIX,num), shell=True)[1].read().split(' ')[0].strip():
		cleanup_files(db_row.keystore_id)
		return "Authentication file was corrupted during transfer"
	db_row.auth_file_hash = auth_hash
	db_row.save()
	client.ssh_command('chmod 440 %s01-incoming/ks%d.auth' % (KEYSTORE_PATH_PREFIX,num))
	mv_in, mv_out, mv_err = client.ssh_command(cmd_str='mv %s01-incoming/ks%d.p12 %s02-ready/; mv %s01-incoming/ks%d.auth %s02-ready/' % (KEYSTORE_PATH_PREFIX, num, KEYSTORE_PATH_PREFIX, KEYSTORE_PATH_PREFIX, num, KEYSTORE_PATH_PREFIX), shell=True)
	mv_err_text = mv_err.read()
	if mv_err_text>'':
		cleanup_files(db_row.keystore_id)
		return "The following error occured while moving your files: %s" % mv_err_text

	cleanup_files(db_row.keystore_id)
	return None

