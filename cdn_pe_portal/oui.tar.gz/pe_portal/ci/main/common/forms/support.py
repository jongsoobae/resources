from django import forms
from ci.constants import SUPPORT_ADDR,NOC
from ci.common.utils import get_customer
from ci.common.utils.mail import send_email
from ci.common.utils.alert import send_alert

issueTypes = {u'11': u'Origin Issue',
 u'12': u'Portal (User Account, Contact Info, etc.)',
 u'15': u'PAD Action (Add, Edit, Disable, Shield, etc.)',
 u'16': u'SSL Certificate Setup',
 u'17': u'(Generic) Support Request',
 u'18': u'Content Delivery (Speed, Error, Compression, etc.)',
 u'20': u'Service Availability',
 u'21': u'Cache Flush (Object or PAD)',
 u'22': u'Web Services (APIs)',
 u'28': u'Reporting & Logging',
 u'29': u'DNS (PoP/Node Selection)'}

class SupportForm(forms.Form):
	issue = forms.ChoiceField(
		label = 'Issue Type',
		# looks ugly, but basically we want:
		# <OPTION VALUE="17: Flush Request">Flush Request</OPTION>
		choices = sorted([(key, issueTypes[key]) for key in issueTypes.keys()], key=lambda e:e[1])
	)
	subject = forms.CharField(max_length=200)
	message = forms.CharField(widget=forms.Textarea(attrs={'rows':16}))
	test_file = forms.CharField(label='Test URL', max_length=2000, required=False)


def create_support_ticket(request, post=None):
	if post:
		support_form = SupportForm(data=post, auto_id='supportform_%s')
		
		if support_form.is_valid():
			# message parts
			subject = support_form.cleaned_data['subject']
			message = support_form.cleaned_data['message']
			test_file = support_form.cleaned_data['test_file']
			issuetypeid = support_form.cleaned_data['issue']
			issuestring = dict(support_form.fields['issue'].choices)[issuetypeid]
			test_page = None
			tab = '    '	
			# send email
			full_subject = '[Cache/%s] %s' % (get_customer(request), subject)
			full_message = u'Customer: %s \n\nIssue Type: %s \n\nOriginal message: \n%sSubject: %s\n%sMessage: %s\n\nUser Agent: %s \n\nIP: %s\nTest URL: %s'\
			 			% ( 
							get_customer(request),
							issuestring, 
							tab,
							subject,
							tab,
							message,
							request.META['HTTP_USER_AGENT'],
							request.META['REMOTE_ADDR'],
							test_file or 'Not Provided')
			# if issuekey and test_file and False: #this comments out new code until its ready to be turned on
			# 	resp = supporttoolsTestFileSubmission(test_file, issuekey, request)
			
			#create alert in OUI 
			send_email(request.user.email, [SUPPORT_ADDR], full_subject, full_message, reply_to=request.user.email)
			
	else:
		support_form = SupportForm(auto_id='supportform_%s')
	return support_form
	
