from django import forms
from django.contrib.auth.models import User
from ci.common.models import LongUser
from django.shortcuts import get_object_or_404
from ci.common.models import UserProfile
from ci.common.models.customer import Customer
from ci.common.forms import FlatRadioFieldRenderer
from ci.common.utils import render_response, get_customer
from ci.common.utils.fields import check_password_complexity
from ci.common.utils import shared_constants
from ci.common.models.common import ChangeActionHistory
from ci.common.utils.util_common import get_current_obj_from_db

from django.utils.translation import ugettext_lazy as _

class ModelMultipleChoiceFieldPAD(forms.ModelMultipleChoiceField):
    def label_from_instance(self, obj):
        return obj.pad

class UserForm(forms.ModelForm):
    username = forms.CharField(label=_("Username"), max_length=100)
    password = forms.CharField(label='New password', widget=forms.PasswordInput)
    password_check = forms.CharField(label='Repeat password', widget=forms.PasswordInput)
    class Meta:
        model = LongUser
        fields = ['username','is_active','first_name','last_name','email']

    def __init__(self, *args, **kwargs):
        self.user = kwargs.get('instance', None)
        self.customer_id = kwargs.pop('customer_id', None)

        if self.user and self.user.pk:
            long_user = LongUser.objects.get(pk=self.user.pk)
        else:
            long_user = LongUser.objects.none()

        if self.customer_id and self.customer_id==4:
            self._meta.model = User
        super(UserForm, self).__init__(*args, **kwargs)
        if self.fields.has_key('username'):
            self.fields['username'].help_text = ''
        for field in ('first_name','last_name','email'):
            if self.fields.has_key(field):
                self.fields[field].required = True

        if self.user:
            if self.fields.has_key('password'):
                self.fields['password'].required = False
                self.fields['password_check'].required = False

        if long_user and long_user.is_migrated_to_AD():
            self.fields['username'].widget.attrs['readonly'] = True
            self.fields['username'].required = False
            self.fields['email'].widget.attrs['readonly'] = True
            self.fields['email'].required = False
            self.fields['first_name'].widget.attrs['readonly'] = True
            self.fields['first_name'].required = False
            self.fields['last_name'].widget.attrs['readonly'] = True
            self.fields['last_name'].required = False

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if (not self.user or self.user.username != username) and User.objects.filter(username=username).count():
            raise forms.ValidationError('This username is already in use.')
        return username

    def clean(self):
        if not self.cleaned_data.get('password'):
            return self.cleaned_data
        if self.cleaned_data.get('password') != self.cleaned_data.get('password_check'):
            raise forms.ValidationError('The two password entries do not match.')
        ret = check_password_complexity(self.cleaned_data.get('password'))
        if self.cleaned_data.get('password') != '' and ret < 3:
            raise forms.ValidationError('The password is not satisfied for complexity.')
        return self.cleaned_data

    def save(self, commit=True):
        user = super(UserForm, self).save(commit=False)
        try:
            long_user = LongUser.objects.get(pk=user.pk)
            if self.cleaned_data['password']:
                long_user.set_password(self.cleaned_data['password'])
                user.password = long_user.password

            if commit:
                long_user.save()
        except Exception,e:
            pass
        return user


def get_privilege_form(request, oui=False, user=None, customer_id=None):
    """if oui is True, user or customer_id must be set"""
    profile = request.user.get_profile()
    # limit the list of pads in the whitelist selector to those of the correct customer
    if user: # editing an existing user in cui or oui
        if oui:
            long_user = LongUser.objects.get(pk=user.pk)
            long_user.check_user_profile(customer_id = 4)
        drafts = user.get_profile().customer.sitedraft_set.all()
    elif oui: # creating a new user in oui
        drafts = Customer.objects.get(pk=customer_id).sitedraft_set.all()
    else: # creating a new user in cui
        drafts = profile.customer.sitedraft_set.all()
    # customer = get_object_or_404(Customer, pk=customer_id) if customer_id elif user.userprofile.customer if user
    if customer_id:
        customer = get_object_or_404(Customer, pk=customer_id)
    elif user:
        customer = get_customer(request)
    elif not oui and not (user and customer_id):
        customer = get_customer(request)


    class PantherPrivForm(forms.ModelForm):
        login_user = request.user
        class Meta:
            model = UserProfile
            fields = ['phone_number', 'mobile_email', 'password_reset', 'webservice_perm','ui_perm', 'can_manage_ssl', 'sam_json_editable']

        def __init__(self, *args, **kwargs):
            super(PantherPrivForm, self).__init__(*args, **kwargs)

            if not self.login_user.is_superuser or self.login_user.userprofile.customer_id != 4:
                del self.fields['sam_json_editable']

        def save(self, commit=True):
            userprofile = super(PantherPrivForm, self).save(commit=False)
            # setting some default Panther-only values before committing
            userprofile.customer_id = 4
            userprofile.can_flush_item = True
            userprofile.can_flush_wildcard = True
            userprofile.can_flush_all = True
            if commit:
                userprofile.save()
            return userprofile

    class PrivForm(forms.ModelForm):
        add_to_ocsp = forms.ChoiceField(label="Add to OCSP?", choices=(('y',"Yes"), ('n',"No")),widget=forms.RadioSelect(renderer=FlatRadioFieldRenderer))
        draft_whitelist = ModelMultipleChoiceFieldPAD(queryset=drafts, required=False)
        class Meta:
            model = UserProfile
            fields = UserProfile.oui_edit_fields() if oui else profile.cui_edit_fields()
        def __init__(self, *args, **kwargs):
            super(PrivForm, self).__init__(*args, **kwargs)
            if self.instance.pk or (customer and not customer.cdnetworks_customer):
                self.fields.pop('add_to_ocsp', None)
            if not customer.using_private_certs==1:
                self.fields.pop('can_manage_ssl', None)
        def clean(self):
            errors = []
            restrict_pads = self.cleaned_data.get('restrict_pads')
            draft_whitelist =  self.cleaned_data.get('draft_whitelist')
            data_whitelist = self.data.getlist('draft_whitelist') if hasattr(self.data, 'getlist') else self.data.get('draft_whitelist')
            if data_whitelist and (not draft_whitelist or len(data_whitelist) != len(draft_whitelist)):
                errors.append("Not all PADs selected are available to be added to whitelist.")
            if restrict_pads and not draft_whitelist:
                errors.append('When "restrict PADs" is enabled, you must select some PADs for the whitelist.')
            if errors:
                raise forms.ValidationError(errors)
            return self.cleaned_data
        def save(self, commit=True):
            userprofile = super(PrivForm, self).save(commit=False)
            userprofile.customer_id = user.userprofile().customer_id if user else customer_id
            if commit:
                userprofile.save()
            return userprofile

    if user:
        return PantherPrivForm if  user.is_staff else PrivForm
    else:
        return PantherPrivForm if (customer_id=='4') else PrivForm
