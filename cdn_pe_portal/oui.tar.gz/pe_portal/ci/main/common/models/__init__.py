from datetime import datetime
from django.contrib.auth.models import User as AuthUser, Group, Permission, get_hexdigest
from django.utils.translation import ugettext_lazy as _
from django.db import models
from django.db.models import Q
from django.utils.safestring import mark_safe
from django.contrib.admin.util import quote
from django.contrib.contenttypes.models import ContentType
from django.core.validators import MaxLengthValidator
from django.utils.translation import ugettext as _
from django.db.models.signals import class_prepared

from ci.common.contrib.crypt.hashers import make_password as make_sha2_password, check_password as check_sha2_password
from ci.common.models.customer import Customer
from ci.common.models.site import Site, SiteDraft

# the order of these imports is somewhat brittle, due to dependencies between models.
from ci.common.models.contact import *
from ci.common.models.geo import *
from ci.common.models.billing import *
from ci.common.models.site import *
from ci.common.models.traffic import *
from ci.common.models.invoice import *
from ci.common.models.customer import *
from ci.common.models.cdn import *
from ci.common.models.alert import *
from ci.common.models.pusher import *
from ci.common.models.chart import *
from ci.common.models.adjustment import *
from ci.common.models.chart import *
from ci.common.models.dns import *
from ci.common.models.stats import *
from ci.common.models.aggregate import *
from ci.common.models.cache import *
from ci.common.models.legacy_shield import *
from ci.common.models.status import *

from ci.common.utils import shared_constants
from ci.common.utils.crowds import CrowdServer
from ci.common.models.common import DatedModel
from ci.common.utils.util_common import get_request, log_error, log_info
from ci.common.decorators import log_exception

MAX_USERNAME_LENGTH = 100
UNUSABLE_PASSWORD = '!' # This will never be a valid hash

try:
    def longer_username_signal(sender, *args, **kwargs):
        if (sender.__name__ == "User" and sender.__module__ == "django.contrib.auth.models"):
            patch_user_model(sender)
    class_prepared.connect(longer_username_signal)

    def patch_user_model(model):
        field = model._meta.get_field("username")

        field.max_length = MAX_USERNAME_LENGTH
        field.help_text = _("Required, %s characters or fewer. Only letters, "
                            "numbers, and @, ., +, -, or _ "
                            "characters." % MAX_USERNAME_LENGTH)

        # patch model field validator because validator doesn't change if we change
        # max_length
        for v in field.validators:
            if isinstance(v, MaxLengthValidator):
                v.limit_value = MAX_USERNAME_LENGTH

    # https://github.com/GoodCloud/django-longer-username/issues/1
    # django 1.3.X loads User model before class_prepared signal is connected
    # so we patch model after it's prepared

    # check if User model is patched
    if AuthUser._meta.get_field("username").max_length != MAX_USERNAME_LENGTH:
        patch_user_model(AuthUser)
except Exception,e:
    pass

class AuthGroup(models.Model):
    name = models.CharField(max_length=80)

    class Meta:
        db_table = 'auth_group'

class AuthUserGroup(models.Model):
    user_id = models.IntegerField()
    group_id = models.IntegerField()

    class Meta:
        db_table = 'auth_user_groups'


class LongUser(models.Model):
    username = models.CharField(_('username'), max_length=100, unique=True, help_text=_("Required. 100 characters or fewer. Letters, numbers and @/./+/-/_ characters"))
    first_name = models.CharField(_('first name'), max_length=30, blank=True)
    last_name = models.CharField(_('last name'), max_length=30, blank=True)
    email = models.EmailField(_('e-mail address'), blank=True)
    password = models.CharField(_('password'), max_length=128, editable=False, help_text=_("Use '[algo]$[salt]$[hexdigest]' or use the <a href=\"password/\">change password form</a>."))
    is_staff = models.BooleanField(_('staff status'), default=False, help_text=_("Designates whether the user can log into this admin site."))
    is_active = models.BooleanField(_('active'), default=True, help_text=_("Designates whether this user should be treated as active. Unselect this instead of deleting accounts."))
    is_superuser = models.BooleanField(_('superuser status'), default=False, help_text=_("Designates that this user has all permissions without explicitly assigning them."))
    last_login = models.DateTimeField(_('last login'), default=datetime.now)
    date_joined = models.DateTimeField(_('date joined'), default=datetime.now)
    groups = models.ManyToManyField(Group, verbose_name=_('groups'), blank=True, help_text=_("In addition to the permissions manually assigned, this user will also get all permissions granted to each group he/she is in."))
    user_permissions = models.ManyToManyField(Permission, verbose_name=_('user permissions'), blank=True)

    class Meta:
        db_table = 'fake_auth_user'
        ordering = ['-date_joined']

    def __unicode__(self):
        return u"%s %s" % (self.pk, self.username)

    @staticmethod
    def get_base_auth_user(legacy_user):
        try:
            if isinstance(legacy_user, AuthUser):
                return legacy_user
            else:
                return AuthUser.objects.get(pk=legacy_user.pk)
        except:
            return None

    def is_panther_operator(self):
        try:
            return self.userprofile().is_panther_operator()
        except UserProfile.DoesNotExist:
            if self.password == UNUSABLE_PASSWORD:
                return True
            else:
                return False

    def get_safe_username(self):
        return self.username.split('@')[0] if '@' in self.username else self.username

    def is_identical_ad_user_exists(self):
        try:
            if not self.is_panther_operator():
                return False
            cs = CrowdServer()
            return cs.user_exists(self.get_safe_username())
        except:
            return False

    def is_username_identical(self, username):
        if not self.is_panther_operator():
            return False
        if username == self.get_safe_username():
            return True
        return False

    def find_legacy_user_with_identical_username(self):
        """
        find user who has username@xxx.xxx within panther customer at AD
        """
        userprofiles = UserProfile.objects.filter(customer__id=4).values('user')
        users = LongUser.objects.filter(Q(username__istartswith="%s@" % self.username,
                                          id__in=userprofiles) ).order_by('-last_login')[:1]
        if users.exists():
            return users[0]
        else:
            return None

    @log_exception(default_return_value=False)
    def copy_privileges_from_legacy_user(self, legacy_user, new_user):
        """
        this is one time migration function from DB to AD
        Does not need to run once a user is migrated to AD
        need to get auth_user instance since following error occur with long_user m2m relation operation:
        Table 'centraldb.fake_auth_user_groups' doesn't exist
        """
        if legacy_user:
            legacy_username = legacy_user.username.split('@')[0] if '@' in legacy_user.username else legacy_user.username
            if not self.is_migrated_to_AD() and self.is_username_identical(legacy_username):
                base_legacy_user = LongUser.get_base_auth_user(legacy_user)
                self._copy_auth_user_properties(base_legacy_user, new_user)
                self._copy_auth_user_groups(base_legacy_user, new_user)
                self._copy_auth_user_permissions(base_legacy_user, new_user)
                self._copy_user_profile(base_legacy_user, new_user)
                self._copy_draft_white_list(base_legacy_user, new_user)
                log_info("successfully copied user:%s ACL form legacy old user account:%s" %
                         (self.username,legacy_user.username))
                return True

        return False

    def _copy_auth_user_properties(self, base_legacy_user, new_user):
        new_user.is_staff = base_legacy_user.is_staff
        new_user.is_superuser = base_legacy_user.is_superuser
        new_user.save()

    @log_exception()
    def _copy_auth_user_groups(self, base_legacy_user, new_user):
        auth_groups = base_legacy_user.groups.all()
        new_user.groups.add(*auth_groups)

    def _copy_auth_user_permissions(self, base_legacy_user, new_user):
        user_permissions = base_legacy_user.user_permissions.all()
        new_user.user_permissions.add(*user_permissions)

    def _copy_user_profile(self, base_legacy_user, new_user):
        legacy_user = LongUser.objects.get(pk=base_legacy_user.pk)
        legacy_userprofile = legacy_user.userprofile()
        try:
            new_userprofile = new_user.get_profile()
        except UserProfile.DoesNotExist:
            legacy_userprofile.pk = None
            legacy_userprofile.user = new_user
            legacy_userprofile.save()


    def _copy_draft_white_list(self, base_legacy_user, new_user):
        legacy_user = LongUser.objects.get(pk=base_legacy_user.pk)
        draft_list = legacy_user.userprofile().draft_whitelist.all()
        self.userprofile().draft_whitelist.add(*draft_list)

    def is_anonymous(self):
        return False

    def is_authenticated(self):
        return True

    @log_exception(default_return_value=False)
    def check_default_auth_group(self):
        """
        return True if auth group created
        """
        user_auth_groups = AuthUserGroup.objects.filter(user_id=self.pk)
        if not user_auth_groups.exists():
            default_auth_group = AuthGroup.objects.get(name='No Auth')
            auth_user_group = AuthUserGroup(user_id=self.pk, group_id=default_auth_group.pk)
            auth_user_group.save()
            return True
        return False

    @log_exception(default_return_value=False)
    def check_user_profile(self, customer_id):
        """
        return True if profile is created
        """
        try:
            up = UserProfile.objects.get(user=self.pk)
        except UserProfile.DoesNotExist:
            profile = UserProfile(user_id=self.pk,
                                    customer_id=customer_id,
                                    ui_perm=1,
                                    password_reset=0,
                                    webservice_perm=0,
                                    admin_perm=0,
                                    support_perm=0,
                                    invoice_perm=0,
                                    #flush_perm=0,
                                    edit_pad_perm=0,
                                    daily_email=0,
                                    daily_top_email=0,
                                    get_notifications=0,
                                    restrict_pads=0,
                                    can_flush_item=0,
                                    can_flush_wildcard=0,
                                    can_flush_all=0,
                                    can_manage_ssl=0,
                                    sam_json_editable=0)
            profile.save()
            return True
        return False


    def get_profile(self):
        if self.pk:
            base_user = LongUser.get_base_auth_user(self)
            return base_user.get_profile()
        else:
            try:
                d_user =AuthUser.objects.get(username=self.username)
                return d_user.get_profile()
            except AuthUser.DoesNotExist:
                return None

    def userprofile(self):
        return self.get_profile()

    def customer(self):
        return self.get_profile().customer

    def set_unusable_password(self):
        # Sets a value that will never be a valid hash
        self.password = UNUSABLE_PASSWORD

    def set_password(self, raw_password):
        if raw_password is None:
            self.set_unusable_password()
        else:
            self.password = make_sha2_password(raw_password)

    def check_password(self, raw_password):
        if self.password.startswith('pbkdf2_sha'):
            return check_sha2_password(raw_password, self.password)
        else:
            user = AuthUser.objects.get(pk=self.pk)
            return user.check_password(raw_password)

    def is_legacy_db_user_before_AD_migration(self):
        return not self.is_migrated_to_AD()

    def is_migrated_to_AD(self):
        try:
            user_profile = UserProfile.objects.get(user__pk=self.pk)
        except:
            user_profile = None

        if user_profile:
            return user_profile.is_migrated_to_AD()
        return False

class AuthMessage(models.Model):
    user = models.ForeignKey(LongUser, db_column='user_id', on_delete=models.DO_NOTHING)
    message = models.TextField()

    class Meta:
        db_table = 'auth_message'
        app_label = 'History'

class AdminLog(models.Model):
    action_time = models.DateTimeField(_('action time'), auto_now=True)
    user = models.ForeignKey(LongUser, on_delete=models.DO_NOTHING)
    content_type = models.ForeignKey(ContentType, blank=True, null=True)
    object_id = models.TextField(_('object id'), blank=True, null=True)
    object_repr = models.CharField(_('object repr'), max_length=200)
    action_flag = models.PositiveSmallIntegerField(_('action flag'), choices=shared_constants.ADMIN_CHANGE_ACTION_TYPE)
    change_message = models.TextField(_('change message'), blank=True)

    class Meta:
        db_table = 'django_admin_log'
        app_label = "History"
        ordering = ('-action_time',)

    def __repr__(self):
        return smart_unicode(self.action_time)

    def is_addition(self):
        return self.action_flag == shared_constants.INSERT_ACTION

    def is_change(self):
        return self.action_flag == shared_constants.UPDATE_ACTION

    def is_deletion(self):
        return self.action_flag == shared_constants.DELETE_ACTION

    def get_edited_object(self):
        "Returns the edited object represented by this log entry"
        return self.content_type.get_object_for_this_type(pk=self.object_id)

    def get_admin_url(self):
        """
        Returns the admin URL to edit the object represented by this log entry.
        This is relative to the Django admin index page.
        """
        if self.content_type and self.object_id:
            return mark_safe(u"%s/%s/%s/" % (self.content_type.app_label, self.content_type.model, quote(self.object_id)))
        return None

class UserProfile(models.Model):
    user = models.OneToOneField(AuthUser)
    customer = models.ForeignKey(Customer)
    phone_number = models.CharField('phone number (optional)', max_length=50, blank=True)
    mobile_email = models.EmailField('mobile device email (optional)',help_text='This is used for staff only to send on call related alerts.', blank=True, default='')
    webservice_perm = models.BooleanField('can use web services', default=False)
    ui_perm = models.BooleanField('can view web UI', help_text = "This applies to logging into either the customer portal or the internal pantheroui", default=True)
    support_perm = models.BooleanField('can make support requests', default=True) # send support requests
    admin_perm = models.BooleanField('can add/change other users', default=False) # get admin access to all users in your customer
    invoice_perm = models.BooleanField('can view invoices', default=False)
    # flush_perm = models.BooleanField('can flush cache', default=True)
    can_flush_item = models.BooleanField('can flush items', default=True, help_text="User can request single item flushes")
    can_flush_wildcard = models.BooleanField('can flush wildcards', default=True, help_text="User can request flushes involving wildcard characters")
    can_flush_all = models.BooleanField('can flush a full PAD', default=True, help_text="User can request to flush an entire PAD")
    can_manage_ssl = models.BooleanField('can manage SSL certs', default=False, help_text="User can add, remove or replace SSL certificates")
    edit_pad_perm = models.BooleanField('can edit PADs', default=True)
    daily_email = models.BooleanField('receive daily traffic email', default=False)
    daily_top_email = models.BooleanField('receive daily top request email', default=False)
    get_notifications = models.BooleanField('receive important email notifications', default=True)
    password_reset = models.BooleanField('force a password change on the next login', default=True) # force password change on next login
    restrict_pads = models.BooleanField('restricted PAD access', default=False, help_text="If this is enabled, the user will only be able to see the pads selected in their PAD whitelist.")
    draft_whitelist = models.ManyToManyField(SiteDraft, verbose_name='PAD whitelist', blank=True, db_table='auth_user_profile_pad_whitelist')
    sam_json_editable = models.BooleanField('can edit SAM rule with JSon', default=False)

    @staticmethod
    def oui_edit_fields():
        return [field.name for field in UserProfile._meta.fields if field.name not in ('id','user','customer', 'sam_json_editable')] + ['draft_whitelist']

    def cui_edit_fields(self):
        fields = UserProfile.oui_edit_fields()
        for field in ('mobile_email',):
            fields.remove(field)
        if not self.customer.can_see_invoices:
            fields.remove('invoice_perm')
        if not self.customer.site_set.filter(track_urls=True).count():
            fields.remove('daily_top_email')
        return fields

    def is_password_reset_required(self):
        if self.is_migrated_to_AD():
            return False
        return self.password_reset

    def perms(self):
        perms = ['ui_perm','support_perm','edit_pad_perm','restrict_pads','webservice_perm','can_flush_all',
                 'can_flush_wildcard', 'can_flush_item','admin_perm', 'can_manage_ssl', 'sam_json_editable']
        if self.customer.can_see_invoices:
            perms.insert(-1, 'invoice_perm')
        return perms

    class Meta:
        db_table = 'auth_user_profile'
        permissions = (
            ('can_add_staff', 'Can add staff users'),
            ('can_edit_staff', 'Can edit staff users'),)

    def __unicode__(self):
        if self.user:
            return 'for %s' % self.user.username
        else:
            return 'orphaned'

    def has_top_url_sites(self):
        sites = Site.objects.filter(sitedraft__userprofile=self) if self.restrict_pads else self.customer.site_set
        return sites.filter(track_urls=True, status=True).count() > 0

    def is_migrated_to_AD(self):
        if self.user and self.customer:
            if self.is_panther_operator() and self.user.password == UNUSABLE_PASSWORD:
                return True
        return False

    def is_panther_operator(self):
        return self.customer.pk == shared_constants.PANTHER_CUSTOMER

class CNameStatusIncorrectManager(models.Manager):
    def get_query_set(self):
        return super(CNameStatusIncorrectManager, self).get_query_set().exclude(status__in = CNameStatus.correct_choices)

class CNameStatus(DatedModel):
    objects = models.Manager() #explictly define default manager
    incorrect_objects = CNameStatusIncorrectManager() #all incorrect cname
    correct_choices = [1,2,4,9]
    status_choices = {1:"Matches Prefix",2:"Matches Custom CNAME",3:"Matches Shared Custom CNAME",4:"Matches Legacy Service",5:"Incorrect CNAME", 6:"Resolves Directly to a CDNetworks Node",7:"Not Directed to CDNetworks",8:"No CNAME",9:"Matches PAD",99:"Unknown"}
    id = models.AutoField(primary_key=True, db_column='cname_status_id')
    site = models.ForeignKey(Site, null=False)
    status = models.PositiveSmallIntegerField(default=99, choices=status_choices.items())
    domain_checked = models.CharField(unique=True, max_length=255)
    cname = models.CharField(max_length=255)
    last_correct_time = models.DateTimeField(blank=True,null=True)
    class Meta:
        db_table = 'cname_status'
        ordering = ['site','domain_checked']
    def save(self, *args, **kwargs):
        if self.status in self.correct_choices:
            self.last_correct_time = datetime.now()
        super(CNameStatus, self).save(*args, **kwargs)
    def status_description(self):
        return self.status_choices.get(self.status,"Unknown Status")


class UseLogByUser(models.Model):
    id = models.AutoField(primary_key=True)
    user_id = models.IntegerField()
    url_function = models.CharField(max_length=150)
    desc = models.CharField(max_length=100)
    create_time = models.DateTimeField(default=datetime.now)

    class Meta:
        db_table = 'use_log_by_user'

class UseLogForCloudSecurity(models.Model):
    id = models.AutoField(primary_key=True, db_column='log_id')
    pad_id = models.IntegerField()
    state_flag = models.PositiveSmallIntegerField()
    cdn_service_id = models.IntegerField()
    create_time = models.DateTimeField(default=datetime.now)

    class Meta:
        db_table = 'use_log_for_cloud_security'

