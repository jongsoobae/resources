from django.db import models
from ci.common.models.invoice import Invoice
from ci.common.models.customer import Customer
from datetime import datetime

class Adjustment(models.Model):
	description = models.TextField()
	is_percentage = models.BooleanField("If True, amount is a percentage of the Invoice pretax total, otherwise amount is a fixed addition to the Invoice")
	amount = models.DecimalField(max_digits=10, decimal_places=2)
	class Meta:
		abstract = True


class CustomerAdjustment(Adjustment):
	"""
	A charge applied to all a Customer's Invoices
	"""
	customer = models.ForeignKey(Customer, related_name='customer_adjustment_set')
	class Meta:
		db_table = 'customer_adjustment'
		app_label = 'oui'
		ordering = ['id']
	def __unicode__(self):
		return 'CustomerAdjustment(%s, is_percentage=%s, amount=%s)' % (
			repr(self.customer),
			repr(self.is_percentage),
			repr(self.description)
		)


class InvoiceAdjustment(Adjustment):
	"""
	A charge applied to a particular Invoice
	"""
	invoice = models.ForeignKey(Invoice, related_name='invoice_adjustment_set')
	class Meta:
		db_table = 'invoice_adjustment'
		app_label = 'oui'
		ordering = ['id']
	def __unicode__(self):
		return 'InvoiceAdjustment(%s, is_percentage=%s, amount=%s)' % (
			repr(self.invoice),
			repr(self.is_percentage),
			repr(self.description)
		)
	def save(self, *args, **kwargs):
		if self.invoice and self.invoice.published:
			raise Exception('an adjustment for a published invoice cannot be changed')
		super(InvoiceAdjustment, self).save(*args, **kwargs)
	def delete(self):
		if self.invoice and self.invoice.published:
			raise Exception('an adjustment for a published invoice cannot be deleted')
		super(InvoiceAdjustment, self).delete()
