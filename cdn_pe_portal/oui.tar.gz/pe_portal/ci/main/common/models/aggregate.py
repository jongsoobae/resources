from django.db import models
from ci.common.models.site import Site

class Aggregate(models.Model):
	id = models.AutoField(primary_key=True, db_column='aggregate_id')
	title = models.CharField("Short description", help_text="Only used as name of aggregate", max_length=50)
	sites = models.ManyToManyField(Site, limit_choices_to={'request_log_msg_format__gt': ' '})
	split_url = models.CharField(max_length=25, help_text="This can either be a text delimeter (like an asterisk) or a regex (in case you want to drop pat of the URL for matching)", blank=True)
	split_response_code = models.CharField('split by response code', max_length=25, blank=True)
	split_referrer = models.CharField('split by referrer', max_length=25, blank=True)
	split_user_agent = models.CharField("split by end user's browser",max_length=25, blank=True)
	filter_url = models.CharField("filter by url", help_text="this is supposed to be a regex",max_length=25, blank=True)
	filter_response_code = models.CharField("filter by response code",help_text="this is supposed to be a regex",max_length=25, blank=True)
	filter_referrer = models.CharField("filter by referrer", help_text="this is supposed to be a regex", max_length=25, blank=True)
	filter_user_agent = models.CharField("filter by user agent", help_text="this is supposed to be a regex",max_length=25, blank=True)
	def __unicode__(self):
		return self.title + " (" + str(self.id) + ")"
	class Meta:
		db_table = 'aggregate'
		app_label = 'oui'
	class Admin:
		pass

class AggregateValue(models.Model):
	id = models.AutoField(primary_key=True, db_column='aggregate_value_id')
	aggregate = models.ForeignKey(Aggregate)
	title = models.CharField("Short description", help_text="Will be used in report headers in the csv file", max_length=50)
	field_number = models.PositiveSmallIntegerField(help_text="This needs to be a number from 1 to n where n is the number of aggregate values for the parent aggregate this is attached to",null=False)
	value_type = models.PositiveSmallIntegerField(choices={1: 'Byte', 2: 'Count'}.items())
	filter_url = models.CharField('Filter by url', help_text="this filter will apply only to this count",max_length=25, blank=True)
	filter_response_code = models.CharField('filter by response code', help_text="this filter will apply only to this count",max_length=25, blank=True)
	filter_referrer = models.CharField('filter by referrer', help_text="this filter will apply only to this count",max_length=25, blank=True)
	filter_user_agent = models.CharField('filter by user agent', help_text="this filter will apply only to this count", max_length=25, blank=True)
	divisor_factor= models.PositiveIntegerField(default=1, blank=True)
	def __unicode__(self):
		return self.title
	
	class Meta:
		db_table = 'aggregate_value'
		app_label = 'oui'
		ordering = ('field_number',)
		unique_together = (('field_number','aggregate'))
	class Admin:
		pass

class AggregateDerived(models.Model):
	id = models.AutoField(primary_key=True, db_column='aggregate_derived_id')
	aggregate = models.ForeignKey(Aggregate)
	aggregatevalue = models.ManyToManyField(AggregateValue)
 	title = models.CharField("short description",help_text="Will be used in report headers in the csv file", max_length=50)
	derived_number = models.PositiveSmallIntegerField(help_text="This needs to be a number from 1 to n where n is the number of aggregate values for the parent aggregate this is attached to", null=False)
	derived_type = models.PositiveSmallIntegerField(choices={1: 'Sum'}.items())
	divisor_factor= models.PositiveIntegerField(help_text="this will divide the total to convert datatype.",default=1)
	def __unicode__(self):
		return self.title
	
	class Meta:
		db_table = 'aggregate_derived'
		verbose_name_plural = 'aggregate derivatives'
		app_label = 'oui'
		ordering = ('derived_number',)
		unique_together = (('derived_number','aggregate'))
	class Admin:
		pass
