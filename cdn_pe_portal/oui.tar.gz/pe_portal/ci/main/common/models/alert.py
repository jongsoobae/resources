from django.db import models
from django.contrib.auth.models import User as AuthUser
from datetime import date, datetime
from ci.common.models.common import DatedModel

ALERT_SUPPORT = 'App :: CUI'
ALERT_OUI3 = 'App :: OUI'
ALERT_NAGIOS = 'Monitor :: Nagios'
ALERT_DB = 'Montior :: MySQL'

# these are shown by default in the history
ALERT_DEFAULT = (
	ALERT_SUPPORT,
	ALERT_OUI3,
	ALERT_DB,
	ALERT_NAGIOS,
)

def alert_types():
	"""get the list of push types that exist in the db"""
	return  Alert.objects.distinct().values_list('alert_code', flat=True).order_by('alert_code')

class Alert(models.Model):
	alert_code = models.CharField(max_length=20)
	urgent = models.BooleanField(default=False)
	email_subject = models.CharField(max_length=255)
	email_body = models.TextField()
	handled_by = models.CharField(max_length=75, null=True)
	send_count = models.IntegerField(default=0)
	create_time = models.DateTimeField()
	last_send_time = models.DateTimeField(default=date(2007,1,1))
	jira_info = models.CharField(max_length=20, null=True, editable=False)
	user = models.ForeignKey(AuthUser, db_column='create_user_id', null=True, blank=True)
	class Meta:
		db_table = 'alert_history'
		ordering = ['-create_time']
		app_label = 'oui'
	def __unicode__(self):
		return '%s: %s' % (self.alert_code, self.email_subject)

class OnCallSchedule(DatedModel):
	id = models.AutoField(primary_key=True, db_column='schedule_id')
	start_time = models.DateTimeField()
	end_time = models.DateTimeField()
	class Meta:
		db_table = 'on_call_schedule'
		ordering = ('start_time',)
		app_label = 'oui'
	def __unicode__(self):
		return '%s: %s to %s' % (self.id, self.start_time, self.end_time)
	def is_current(self):
		return self.start_time < datetime.now() < self.end_time
	def primary(self):
		return self.oncallcontact_set.get(contact_order=0).contact
	def secondary(self):
		return self.oncallcontact_set.get(contact_order=1).contact
	def tertiary(self):
		return self.oncallcontact_set.get(contact_order=2).contact
	def quaternary(self):
		return self.oncallcontact_set.get(contact_order=3).contact
	def set_contacts(self, contacts):
		current_contacts = self.oncallcontact_set
		if current_contacts:
			current_contacts.all().delete()
		for order, contact in enumerate(contacts):
			OnCallContact.objects.create(schedule=self, contact=contact, contact_order=order)
	def contacts(self):
		return [c.contact for c in self.oncallcontact_set.all()]
	def save(self, *args, **kwargs):
		super(OnCallSchedule, self).save(*args, **kwargs)
		assert self.id, 'no id? %s' % self.id
		# make sure no two schedules have overlapping times, and "push" times if necessary.
		# four types of overlap:
		# 1. complete:
		# S---new---E
		#  S--old--E
		# and
		# S--new--E
		# S--old--E
		complete_overlaps = OnCallSchedule.objects.filter(start_time__gte=self.start_time, end_time__lte=self.end_time).exclude(pk=self.id)
		if complete_overlaps:
			complete_overlaps.delete()
		# 2. middle:
		#  S--new--E
		# S---old---E
		try:
			middle_overlap = OnCallSchedule.objects.get(start_time__lt=self.start_time, end_time__gt=self.end_time)
			new_sched = OnCallSchedule.objects.create(start_time=self.end_time, end_time=middle_overlap.end_time)
			new_sched.set_contacts(middle_overlap.contacts())
			new_sched.save()
			middle_overlap.end_time = self.start_time
			middle_overlap.save()
		except OnCallSchedule.DoesNotExist:
			pass
		# 3. start:
		# S--new--E
		#   S--old--E
		# and
		# S--new--E
		# S---old---E
		try:
			start_overlap = OnCallSchedule.objects.exclude(pk=self.id).get(start_time__lt=self.end_time, end_time__gt=self.end_time)
			start_overlap.start_time = self.end_time
			start_overlap.save()
		except OnCallSchedule.DoesNotExist:
			pass
		# 4. end:
		#   S--new--E
		# S--old--E
		# and
		#   S--new--E
		# S---old---E
		try:
			end_overlap = OnCallSchedule.objects.exclude(pk=self.id).get(start_time__lt=self.start_time, end_time__gt=self.start_time)
			end_overlap.end_time = self.start_time
			end_overlap.save()
		except OnCallSchedule.DoesNotExist:
			pass
			
	def delete(self):
		OnCallContact.objects.filter(schedule=self).delete()
		super(OnCallSchedule, self).delete()	

class OnCallContact(DatedModel):
	schedule = models.ForeignKey(OnCallSchedule, db_column='SCHEDULE_ID')
	contact = models.ForeignKey(AuthUser, db_column='CONTACT_ID')
	contact_order = models.IntegerField(unique=True)
	class Meta:
		db_table = 'on_call_schedule_contact'
		ordering = ('schedule','contact_order')
		app_label = 'oui'
	def __unicode__(self):
		return '%d: %s' % (self.contact_order, self.contact)

