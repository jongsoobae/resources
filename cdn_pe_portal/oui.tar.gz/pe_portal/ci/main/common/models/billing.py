from decimal import Decimal
from django.db import models
import time

class Currency(models.Model):
	id = models.AutoField(primary_key=True, db_column='currency_id')
	description = models.CharField(unique=True, max_length=10)
	html_symbol = models.CharField(unique=True, max_length=10)
	dollar_equiv = models.FloatField()
	update_time = models.DateTimeField(editable=False)
	class Meta:
		db_table = 'currency'
		app_label = 'oui'
		verbose_name_plural = 'currencies'
	def __unicode__(self):
		return self.description

class BillRate(models.Model):
	id = models.AutoField(primary_key=True, db_column='rate_id')
	currency = models.ForeignKey(Currency)
	description = models.CharField(max_length=40)
	is_gb = models.BooleanField('bill by GB', default=False, db_column='is_gb_xferred')
	minimum = models.DecimalField(max_digits=13, decimal_places=3, default=Decimal('0.000'))
	archived = models.BooleanField(default=False, help_text="Archived rates cannot be selected for new customers and new invoices. Once a rate becomes archived, it cannot be changed or deleted.")
	class Meta:
		db_table = 'bill_rate'
		ordering = ['description']
		app_label = 'oui'
	def __unicode__(self):
		return '%s' % self.description
	def num_levels(self):
		return self.billratelevel_set.count()
	num_levels.short_description = 'levels'
	def invoice_use_count(self):
		return self.invoice_set.count()
	invoice_use_count.short_description = 'invoice use count'
	def customer_use_count(self):
		return self.customer_set.count()
	customer_use_count.short_description = 'customer use count'
	def level(self, gb, mbps):
		"applicable BillRateLevel for the given traffic volume"
		level_threshold = max(float(self.minimum), float((mbps, gb)[self.is_gb]))
		try:
			return self.level_set.filter(start_level__lte=level_threshold).order_by('-start_level')[0]
		except:
			raise Exception("couldn't find a level for rate %d at %.2f %s" % (self.id, level_threshold, ('mbps','gb')[self.is_gb]))
	def price(self, gb, mbps):
		"always returns dollar values"
		level = self.level(gb, mbps)
		return level.price * Decimal(str(self.currency.dollar_equiv))
	def save(self, *args, **kwargs):
		if self.id:
			assert not BillRate.objects.get(pk=self.id).archived, 'Archived rates cannot be changed'
		super(BillRate, self).save(*args, **kwargs)
	def delete(self):
		assert not BillRate.objects.get(pk=self.id).archived, 'Archived rates cannot be deleted'
		super(BillRate, self).delete()
	def levels_list(self):
		return [(l.start_level, l.price) for l in self.level_set.order_by('start_level')]
	def equals(self, other_rate):
		return self.currency == other_rate.currency and \
			self.minimum == other_rate.minimum and \
			self.is_gb == other_rate.is_gb and \
			self.levels_list() == other_rate.levels_list()
	def make_archived_copy(self):
		description_suffix = ' (preserved %s)' % time.strftime('%Y-%m-%d')
		description = self.description[:self._meta.get_field('description').max_length - len(description_suffix)] + description_suffix
		archived_copy = BillRate.objects.create(currency=self.currency, is_gb=self.is_gb, minimum=self.minimum, archived=True, description=description)
		for start_level, price in self.levels_list():
			BillRateLevel.objects.create(start_level=start_level, price=price, rate=archived_copy)
		return archived_copy
		

class BillRateLevel(models.Model):
	rate = models.ForeignKey(BillRate, related_name='level_set', db_column='rate_id')
	start_level = models.FloatField()
	price = models.DecimalField(max_digits=8, decimal_places=3, db_column='rate')
	class Meta:
		db_table = 'bill_rate_level'
		ordering = ['start_level']
		app_label = 'oui'
	def save(self, *args, **kwargs):
		if self.id:
			original = BillRateLevel.objects.get(pk=self.id)
			if original.start_level != self.start_level or original.price != self.price:
				assert not self.rate.archived, 'Archived rates cannot be changed'
		super(BillRateLevel, self).save(*args, **kwargs)
	def delete(self):
		assert not self.rate.archived, 'Archived rates cannot be deleted'
		super(BillRateLevel, self).delete()

