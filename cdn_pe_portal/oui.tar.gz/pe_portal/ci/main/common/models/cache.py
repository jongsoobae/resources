from django.db import models, connection
from django.core.exceptions import ValidationError
from ci.common.models import DatedModel
from ci.common.models.cdn import Node, NodeIP, Service, node_name_cmp
from ci.common.models.legacy_shield import *
from ci.common.utils.fields import SimpleIntermediateM2MField
from ci.common.utils.functional import assocLookup, concat, intercalate
from datetime import *
from django.db.models.signals import m2m_changed, post_delete
from django.dispatch import receiver


class AbstractJoinTimeModel(models.Model):
    join_time = models.DateTimeField(blank=True)
    def save(self, *args, **kwargs):
        if not self.join_time:
            self.join_time = datetime.now()
        return super(AbstractJoinTimeModel, self).save(*args, **kwargs)
    class Meta:
        abstract = True

# ip addresses in a band
class BandNode(AbstractJoinTimeModel):
    band = models.ForeignKey('Band')
    node = models.ForeignKey(Node)
    node_ip = models.ForeignKey(NodeIP, verbose_name="Node IP")
    class Meta:
        app_label = 'oui'
        db_table = 'band_node'
        unique_together = ('band','node_ip')
    def save(self, *args, **kwargs):
        self.node = self.node_ip.node
        ret = super(BandNode, self).save(*args, **kwargs)
        self.band.band_aggr.ips = self.band.node_ips.count()
        self.band.band_aggr.save()
        return ret

    def __unicode__(self):
        return "%s (IP: %s)" % (self.band.name, self.node_ip.ipv4_address)


@receiver(post_delete, sender=BandNode)
def bandnode_changed(sender, instance, **kwargs):
    instance.band.band_aggr.ips = instance.band.node_ips.count()
    instance.band.band_aggr.save()


class EdgeAppVersion(models.Model):
    edge_app = models.CharField(max_length=20)
    avail_version = models.CharField(max_length=20)
    obj_state = models.BooleanField()
    create_time = models.DateTimeField()
    modify_time = models.DateTimeField()

    class Meta:
        app_label = 'oui'
        db_table = 'edge_app_version'
        unique_together = ('edge_app', 'avail_version')


V6_BAND_STATUS = (
    (0, 'Only V4'),
    (1, 'SYNCED'),
    (2, 'NOT_SYNCED'),
    (3, 'V6'),
)


def get_reverse_band_status_dict():
    ret_dict = {}
    for st in V6_BAND_STATUS:
        ret_dict[st[1]] = st[0]
    return ret_dict


REVERSE_V6_BAND_STATUS_DICT = get_reverse_band_status_dict()


class Band(DatedModel):
    name = models.CharField(max_length=50, unique=True)
    nodes = SimpleIntermediateM2MField(Node, through=BandNode)
    node_ips = SimpleIntermediateM2MField(NodeIP, through=BandNode, related_name="band_ip", table_to_field={'nodeip': 'node_ip'})
    services = SimpleIntermediateM2MField(Service, blank=True, through='CdnDomainBand')
    is_v6 = models.PositiveSmallIntegerField(
        choices=[(1, 'v6'), (0, 'v4')], default=0, null=False, blank=False, editable=False)
    my_v4_band_id = models.PositiveIntegerField(editable=False)

    class Meta:
        app_label = 'oui'
        db_table = 'band'
        ordering = ['name']

    def save(self, *args, **kwargs):
        if not self.check_keystore(new_ssl = False):
            raise Exception("Saving band(%s) would violate keystore to IP uniqueness constraint" % self.name)
        super(Band, self).save(*args, **kwargs)

        try:
            band_aggr = BandAggr.objects.get(band=self)
        except:
            band_aggr = BandAggr(band=self, ips=0)
        band_aggr.save()

        band_pk = self.pk
        from ci.common.models.prism_sync import SyncJob
        sync_job = SyncJob(name='band', type='save', key=str(band_pk), flag=0, cnt=0)
        sync_job.save()

    def check_deletable(self):
        used_services = self.services.all()
        if used_services.exists():
            raise Exception('Band %s can`t delete, because used at %s.' % (self, [str(x) for x in used_services]))

    def delete(self):
        self.check_deletable()
        band_pk = self.pk
        super(Band, self).delete()

        from ci.common.models.prism_sync import SyncJob
        sync_job = SyncJob(name='band', type='delete', key=str(band_pk), flag=0, cnt=0)
        sync_job.save()

    def members(self):
        return self.nodes.select_related()
    def failing_nodes(self):
        return [n for n in self.node_set.all() if n.failing()]
    def ok_nodes(self):
        return [n for n in self.node_set.filter(offline=False) if not n.failing()]
    def offline_nodes(self):
        return self.nodes.filter(offline=True)
    def offline_only_nodes(self):
        return self.node_ips.filter(node__offline=True, node__broken=False)
    def broken_nodes(self):
        return self.node_ips.filter(node__broken=True)
    def online_nodes(self):
        return self.node_ips.filter(node__offline=False)
    def failing(self):
        return len(self.failing_nodes()) >= len(self.ok_nodes())
    def offline(self):
        return True if self.online_nodes().count() == 0 or self.online_nodes().filter(node__pop__offline=False).count() == 0 else False
    def sorted_node_set(self):
        nodes = list(self.node_set.select_related('nodestat'))
        nodes.sort(cmp=node_name_cmp)
        ret = []
        for node in nodes:
            for ip in node.nodeip_set.all():
                if ip in self.node_ips.all():
                    ret.append(ip)
        return ret
    def __unicode__(self):
        return '%s (%d)' % (self.name, self.band_aggr.ips)
    def check_keystore(self, keystore_id=None, additional_ips=[], exclude_services=[], new_ssl=True):
        if not new_ssl and Service.objects.filter(band = self, ssl_cert__isnull=False).count() == 0:
            #no keystore on this band so do not need to worry about other bands.
            return True
        ip_list = list(self.node_ips.values_list('ipv4_address',flat=True)) if self.id else []
        ip_list += additional_ips
        keystores = set(Service.objects.filter(band__node_ips__ipv4_address__in = ip_list, ssl_cert__isnull=False).exclude(id__in = exclude_services).values_list('ssl_cert_id',flat=True))
        if keystores != None and (
            len(keystores) > 1 or
            (keystore_id != None and len(keystores) == 1 and not keystores.issuperset([keystore_id]))):
            return False
        return True
    def pops(self):
        return list(set([ip.node.pop for ip in self.node_ips.all()]))

    def get_v6_band(self):
        if not self.pk:
            return None

        if self.is_v6:
            return self

        try:
            v6_band = Band.objects.get(is_v6=True, my_v4_band_id=self.pk)
        except Band.DoesNotExist:
            v6_band = Band(
                is_v6=True, my_v4_band_id=self.pk, name='%s (v6)' % self.name
            )
        return v6_band

    def get_pair_band(self):
        if not self.pk:
            return None
        try:
            if self.is_v6:
                return Band.objects.get(pk=self.my_v4_band_id)
            return Band.objects.get(my_v4_band_id=self.pk)
        except Band.DoesNotExist:
            return None

    def get_v6_sync_status(self):
        if not self.pk:
            return -1
        if self.is_v6:
            return REVERSE_V6_BAND_STATUS_DICT['V6']

        v6_band = self.get_v6_band()
        if not v6_band.pk:
            return REVERSE_V6_BAND_STATUS_DICT['Only V4']

        v4_nodes = self.node_ips.values('seq_num', 'node_id')
        v6_nodes = v6_band.node_ips.values('seq_num', 'node_id')
        if len(v4_nodes) != len(v6_nodes):
            return REVERSE_V6_BAND_STATUS_DICT['NOT_SYNCED']

        v6_node_dict = {}
        for v6 in v6_nodes:
            v6_node_dict['%s-%s' % (v6['node_id'], v6['seq_num'])] = True

        for v4_node in v4_nodes:
            if '%s-%s' % (v4_node['node_id'], int(v4_node['seq_num'])+ 100) not in v6_node_dict:
                return REVERSE_V6_BAND_STATUS_DICT['NOT_SYNCED']

        return REVERSE_V6_BAND_STATUS_DICT['SYNCED']

    @property
    def is_v4(self):
        return not self.is_v6


class BandAggr (models.Model):
    band = models.OneToOneField(Band, primary_key=True, db_column='band_id', related_name='band_aggr')
    ips = models.IntegerField()
    class Meta:
        app_label = 'oui'
        db_table = 'band_aggr'


class BandMon (models.Model):
    band = models.ForeignKey(Band, primary_key=True, db_column='band_id')
    create_time = models.DateTimeField(auto_now_add=True, editable=False)
    class Meta:
        app_label = 'oui'
        db_table = 'band_mon'

class NodeHashpoint(AbstractJoinTimeModel):
    node = models.ForeignKey(Node)
    hashpoint = models.FloatField()
    class Meta:
        app_label = 'oui'
        db_table = 'node_hashpoint'
    def __unicode__(self):
        return str(self.hashpoint)
    def name(self):
        return self.node.name()


class ShieldedService(models.Model):
    name = models.CharField(max_length=50)
    service = models.ForeignKey(Service, db_column='cdn_service_id', verbose_name="Edge Service")
    bands = models.ManyToManyField(Band, through='ShieldedServiceBand', related_name='shields')
    public_to_customer = models.BooleanField(default=0, help_text="This option is for public to customer for self implementation")

    class Meta:
        app_label = 'oui'
        db_table = 'shielded_service'
        unique_together = ('service','name')

    def __unicode__(self):
        return self.name

    @staticmethod
    def location_name(location_name):
        try:
            location = location_name.split('-')
            return "%s, %s" % (location[2], location[3])
        except:
            return ''

    def get_location_name(self):
        shields = ShieldedService.objects.filter(pk=self.pk)
        shields = shields.select_related('bands__node__pop__cdnw_pop_id__name').values('bands__node__pop__cdnw_pop_id__name')
        return self.location_name(shields[0]['bands__node__pop__cdnw_pop_id__name'])

    def get_related_shield_nodes(self):
        related_bands = ShieldedServiceBand.objects.filter(shielded_service = self).values_list('band',flat=True)
        band_nodes = BandNode.objects.filter(band__in=related_bands).values_list('node',flat=True)
        nodes = Node.objects.filter(pk__in=band_nodes).distinct()
        return nodes

    def get_related_ngp_hostname_list(self):
        from ci.common.utils.misc import short_hostname
        host_list = []
        nodes = self.get_related_shield_nodes()
        for ngp_hostname in nodes.values_list('ngp_hostname',flat=True):
            host_list.append(short_hostname(ngp_hostname))
        return host_list


class ShieldUrlTest(models.Model):
    shielded_service = models.ForeignKey(ShieldedService, db_column='shielded_service_id')
    url = models.URLField(max_length=512, verify_exists=True)
    result_md5 = models.CharField(max_length=128, blank=True, null=True)
    class Meta:
        app_label = 'oui'
        db_table = 'urltest_shield'
    def __unicode__(self):
        return "%s : %s" % (self.shielded_service.service.dns_prefix, self.url)

class CdnDomainBand(AbstractJoinTimeModel):
    """this maps which bands should be used for the frontend of each service"""
    service = models.ForeignKey(Service, db_column='cdn_service_id')
    band = models.ForeignKey(Band)
    class Meta:
        app_label = 'oui'
        db_table = 'cdndomain_band'
        verbose_name = "Edge to Band"
        unique_together = ('service','band')
    def __unicode__(self):
        return self.service.name + ': ' + self.band.__unicode__()

class FrontEndUrlTest(models.Model):
    service = models.ForeignKey(Service, db_column='cdn_service_id')
    url = models.URLField(max_length=512, verify_exists=False)
    result_md5 = models.CharField(max_length=128, blank=True, null=True)
    class Meta:
        app_label = 'oui'
        db_table = 'urltest_frontend'
    def __unicode__(self):
        return "%s : %s" % (self.service.dns_prefix, self.url)

class ShieldedServiceBand(AbstractJoinTimeModel):
    """this maps which bands should be used for shielding"""
    shielded_service = models.ForeignKey(ShieldedService, related_name="band_relations")
    cache_level = models.PositiveIntegerField(help_text='This is the main ordering. 1 = 1st first-level shield, 2 = second level shield, and so on. No 0 level (which means front-end)')
    band = models.ForeignKey(Band, related_name="shield_relations")
    region = models.PositiveIntegerField(db_column='group_num', help_text='Traffic is routed to one region in a level based on distance.')
    order = models.PositiveIntegerField(db_column='order_num', help_text='All bands in the same region cache the same content, but only the lowest-order band in a region is live; the others are only for backup.')

    class Meta:
        app_label = 'oui'
        db_table = 'shielded_service_band'
        verbose_name = "Layered cache"
        unique_together = ('shielded_service','cache_level','band')
    def __unicode__(self):
        return '%s %d.%d.%d' % (self.shielded_service.name, self.cache_level, self.region, self.order)