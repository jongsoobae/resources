from datetime import datetime, timedelta
from django.db import models
from django.db.models import Q
from django.core.exceptions import ObjectDoesNotExist, ValidationError
from ci.common.models.sni import SNIGroup
from ci.common.utils.misc import short_hostname
from ci.common.models.customer import Customer, SSLKeystore, CORP_CODES
from ci.common.models.common import DatedModel
from ci.common.models.dns import DnsZone, Dns_Ns_Record
from ci.common.models.geo import Address, Region, Country, delete_if_unused
from ci.common.utils.ip import ipIntToString
from ci.common.utils.fields import SimpleIntermediateM2MField
import re
from ci.common.models.prism_sync import CdnwPop


SERVICE_PRODUCT_TYPE_CHOICES = (
    (1, 'Http'),
    (2, 'Https'),
    (3, 'C-Security'),
)


SERVICE_COVERAGE_CHOICES = (
    ('KR', 'KR Local'),
    ('JP', 'JP Local'),
    ('CN', 'CN Local'),
    ('N1', 'Global Business'),
    ('N2', 'Global Standard'),
    ('N3', 'Global Premium'),
)


SERVICE_TYPE_CHOICES = (
    (1, 'Edge service'),
    (2, 'GSLB delegation'),
)


YN_CHOICES = (
    (0, 'N'),
    (1, 'Y'),
)


def get_contract_region():
    return CORP_CODES.items()

SSL_PROTOCOLS = ['SSLv3', 'TLSv1', 'TLSv1.1', 'TLSv1.2', 'SSLv2Hello']
HTTP2_ALLOW_SSL_PROTOCOL = 'TLSv1.2'
HTTP2_ALLOW_SSL_CIPHER = 'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256'
HTTP2_ALLOW_ALTERNATIVE_SSL_CIPHERs = ('TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384',)
DEFAULT_SSL_SERVER_CIPHER = 'SSL_RSA_WITH_RC4_128_MD5,SSL_RSA_WITH_RC4_128_SHA,TLS_RSA_WITH_AES_128_CBC_SHA,TLS_RSA_WITH_AES_256_CBC_SHA'


# this is the sentinel value that monitor_nodes sets the LAL to for a node or pop
# when an actual value cannot be obtained.
BAD_LAL = 99999

class PopType(DatedModel):
    id = models.AutoField(primary_key=True, db_column='pop_type_id')
    name = models.CharField(unique=True, max_length=50)
    description = models.CharField(max_length=255)
    class Meta:
        db_table = 'pop_type'
        app_label = 'oui'
    def __unicode__(self):
        return self.name

class NodeType(models.Model):
    "1 = http, 2 = dns, 3 = http/dns"
    id = models.AutoField(primary_key=True, db_column='node_type_id')
    name = models.CharField(max_length=50)
    description = models.CharField(max_length=255)
    class Meta:
        db_table = 'node_type'
        app_label = 'oui'
    def __unicode__(self):
        return self.name

ngp_hostname = re.compile(r'h[0-9]+-s[0-9]+.p[0-9]+-[a-zA-Z]+$')

def node_name_cmp(n1, n2):
    n1_type = False
    n2_type = False

    if ngp_hostname.match(n1.name()):
        n1_type = True
        if ngp_hostname.match(n2.name()):
            n2_type = True

    if n1_type and n2_type:
        return node_name_cmp_ngp(n1, n2)
    elif not n1_type and not n2_type:
        return node_name_cmp_reg(n1, n2)
    else:
        if n1_type:
            return -1
        else:
            return 1

def node_name_cmp_ngp(n1, n2):
    """a comparison function for node names.
    orders e.g. foo-bar-n9 before foo-bar-n14, as well as shields and dns nodes
    ahead of http nodes.
    """
    try:
        n1 = {'h':int(n1.name().split('.')[0].split('-')[0][1:]),
                's':int(n1.name().split('.')[0].split('-')[1][1:]),
                'k':n1.name().split('.')[1].split('-')[0][:1],
                'p':int(n1.name().split('.')[1].split('-')[0][1:]),
                'r':n1.name().split('.')[1].split('-')[1]}

        n2 = {'h':int(n2.name().split('.')[0].split('-')[0][1:]),
                's':int(n2.name().split('.')[0].split('-')[1][1:]),
                'k':n2.name().split('.')[1].split('-')[0][:1],
                'p':int(n2.name().split('.')[1].split('-')[0][1:]),
                'r':n2.name().split('.')[1].split('-')[1]}

        if cmp(n1['k'], n2['k']) != 0:
           return cmp(n1['k'], n2['k'])
        elif cmp(n1['p'], n2['p']) != 0:
           return cmp(n1['p'], n2['p'])
        elif cmp(n1['s'], n2['s']) != 0:
           return cmp(n1['s'], n2['s'])
        elif cmp(n1['h'], n2['h']) != 0:
           return cmp(n1['h'], n2['h'])
        else:
           return -1
    except:
        return cmp(n1, n2)

def node_name_cmp_reg(n1, n2):
    """a comparison function for node names.
    orders e.g. foo-bar-n9 before foo-bar-n14, as well as shields and dns nodes
    ahead of http nodes.
    """
    try:
        n1_t = n1.name().split('-')
        n2_t = n2.name().split('-')
        n1_type = n1_t[len(n1_t)-1][:1]
        n2_type = n2_t[len(n2_t)-1][:1]

        if n1_type == 'n' and n2_type != 'n':
            type_cmp = 1
        elif n2_type == 'n' and n1_type != 'n':
            type_cmp = -1
        else:
            type_cmp = -1*cmp(n1_type, n2_type)
        if type_cmp == 0:
            n1_num = int(n1_t[len(n1_t)-1][1:])
            n2_num = int(n2_t[len(n2_t)-1][1:])
            return cmp(n1_num, n2_num)
        else:
            return type_cmp
    except:
        return cmp(n1, n2)

class Pop(DatedModel):
    id = models.AutoField(primary_key=True, db_column='pop_id')
    name = models.CharField(max_length=50)
    short_name = models.CharField(max_length=20, blank=True)
    xname = models.CharField(max_length=50, null=True)
    description = models.CharField(max_length=255)
    region = models.ForeignKey(Region)
    offline = models.BooleanField(default=True)
    importance = models.IntegerField(default="0", help_text="Valid values for this field:\n (0) a 'regular' pop. \n (1) a very important PoP like a shield for a major customer. \n (-1) a retired PoP, this value will make the PoP invisible in the OUI")
    country = models.ForeignKey(Country)
    pop_type = models.ForeignKey(PopType)
    # load_balancer_pop = models.BooleanField(default=False)
    url_wiki = models.CharField('URL: Wiki', blank=True, null=True, max_length=255)
    url_asset = models.CharField('URL: Asset-Tracking',blank=True, null=True, max_length=255)
    failure_threshold = 0.5        # percentage of failing nodes which makes the pop count as failing
    cdnw_pop_id = models.ForeignKey(CdnwPop, null=True, db_column='cdnw_pop_id')
    capacity = models.FloatField(default=1.0)
    class Meta:
        ordering = ['region','short_name']
        db_table = 'pop'
        app_label = 'oui'
    def __unicode__(self):
        return self.name
    def shortname(self):
        return self.short_name
    def shortshortname(self):
        return ''.join([word[:2] for word in self.name.split('.')[1:3]])
    def services(self):
        return Service.objects.filter(band__node_ips__node__pop=self, status=True).distinct().all()
    # def `short_name(self):
    #     return ''.join([word[:2] for word in self.name.split('.')[1:3]])
    def nodestats(self):
        # circular imports
        from ci.common.models.stats import NodeStat
        return NodeStat.objects.filter(node__in=self.node_set.all())
    def active(self):
        return not self.offline
    def node_count(self):
        return self.node_set.count()
    node_count.short_description = 'Number of nodes'
    def online_nodes(self):
        return self.node_set.filter(offline=False)
    def broken_nodes(self):
        return self.node_set.filter(offline=True, broken=True)
    def offline_nodes(self):
        return self.node_set.filter(offline=True, node_type__in=[1,3] )
    def offline_only_nodes(self):
        return self.offline_nodes().exclude(broken=True)
    def failing_nodes(self):
        return [n for n in self.node_set.all() if n.failing()]
    def bands(self):
        # circular import bonanza
        from ci.common.models.cache import Band
        return Band.objects.filter(node_ips__node__pop=self).distinct()
    def ok_nodes(self):
        return [n for n in self.node_set.filter(offline=False) if not n.failing()]
    def mbps(self):
        return sum([n.mbps() for n in self.node_set.filter(offline=True)])
    def rps(self):
        return sum([n.rps() for n in self.node_set.filter(offline=True)])
    def ops(self):
        return sum([n.ops() for n in self.node_set.filter(offline=True)])
    def lal(self):
        try:
            ret = float(self.popstat.lal)
            if ret != BAD_LAL:
                return ret
            else:
                return '?'
        except:
            return '?'
    def sorted_node_set(self):
        nodes = list(self.node_set.select_related('nodestat'))
        nodes.sort(cmp=node_name_cmp)
        return nodes
    def failing(self):
        return len(self.failing_nodes()) >= len(self.ok_nodes())
    def ok(self):
        return not self.failing() and not self.offline
    def save(self, *args, **kwargs):
        if self.xname == '':
            self.xname = None
        if self.id:
            super(Pop, self).save()
        else:
            super(Pop, self).save(*args, **kwargs)
        #This is exessive and will cause an ugly srver error. But we need to make sure a PoP is never added beyond that ID
        if self.id>200:
            raise Exception("Cannot make a pop with id larger than 200" )

        pop_pk = self.pk
        from ci.common.models.prism_sync import SyncJob
        sync_job = SyncJob(name='pop', type='save', key=str(pop_pk), flag=0, cnt=0)
        sync_job.save()

    def delete(self):
        pop_pk = self.pk
        super(Pop, self).delete()

        from ci.common.models.prism_sync import SyncJob
        sync_job = SyncJob(name='pop', type='delete', key=str(pop_pk), flag=0, cnt=0)
        sync_job.save()

    def get_distances(self):
        return PopNetworkDistance.objects.filter(pop1=self).order_by('-distance')
    def closest_pop(self):
        distances = self.get_distances()
        min_dist = 9999999
        closest= None
        for row in distances:
            if row.distance< min_dist and not (row.pop2==self and row.pop1==self):
                closest = row
                min_dist = row.distance
        return (closest.pop1, closest.distance) if closest.pop1 != self else (closest.pop2, closest.distance)
    def farthest_pop(self):
        distances = self.get_distances()
        max_dist = 0
        farthest= None
        for row in distances:
            if row.distance> max_dist:
                farthest = row
                max_dist = row.distance
        return (farthest.pop1, farthest.distance) if farthest.pop1 != self else (farthest.pop2, farthest.distance)


class PopLoadLimit(DatedModel):
    pop = models.OneToOneField(Pop, db_column='pop_id', related_name='load_limits')
    max_mbps = models.IntegerField(default=100)
    load_adjustment = models.IntegerField(default=1)
    lb_max_lal = models.IntegerField('max LAL', default=50)
    lb_min_lal = models.IntegerField('min LAL', default=0)
    ms_per_mbps = models.DecimalField(max_digits=7, decimal_places=4, default=0.04)
    ms_per_rps = models.DecimalField(max_digits=7, decimal_places=4, default=0.025)
    ms_per_ops = models.DecimalField(max_digits=7, decimal_places=4, default=0.04)
    ms_per_disk_iops = models.DecimalField(max_digits=7, decimal_places=4, default=0.08)
    ms_per_disk_await = models.DecimalField(max_digits=7, decimal_places=4, default=0.1)
    ms_per_load_avg_1 = models.DecimalField(max_digits=7, decimal_places=4, default=0.625)
    error_margin = models.DecimalField(max_digits=6, decimal_places=2, default=0.5)
    error_decay = models.DecimalField(max_digits=7, decimal_places=4, default=0.5)
    loop_period_sec = models.DecimalField(max_digits=9, decimal_places=3, default=13.0)
    proportional_gain = models.DecimalField(max_digits=8, decimal_places=4, default=0.1)
    integral_time_div = models.DecimalField(max_digits=7, decimal_places=4, default=2.0)
    derivative_time_mul = models.DecimalField(max_digits=7, decimal_places=4, default=3.0)
    class Meta:
        db_table = 'pop_load_limit'
        app_label = 'oui'
    def __unicode__(self):
        return 'limits for %s' % self.pop.shortname()


class Service(DatedModel):
    id = models.AutoField(primary_key=True, db_column='cdn_service_id')
    name = models.CharField(unique=True, max_length=50)
    description = models.CharField(blank=True, max_length=255)
    dns_prefix = models.CharField('DNS Prefix',unique=True, max_length=8)
    dns_ttl = models.IntegerField('DNS TTL', default=20)
    dns_zone = models.ForeignKey(DnsZone, db_column='dns_zone_record_id', limit_choices_to={'dynamic_cache__in':(0,1)})
    status = models.BooleanField('Active', default=True, help_text="Only superuser can handle this \"active\" checkbox.")
    weight = models.FloatField(default=1)
    midLal = models.SmallIntegerField(default=50)
    ssl_cert = models.ForeignKey(SSLKeystore, verbose_name="SSL Keystore",  null=True, blank=True, db_column="keystore_id", related_name="frontends", limit_choices_to={ 'upload_successful':True})
    sni_group = models.ForeignKey(SNIGroup, db_column='sni_group_id', null=True, blank=True)
    china_svc = models.BooleanField('China only service', help_text="This service includes servers that require Chinese authorizaton. That authorization is set at the customer level", default=False)
    allow_nonmatching_domains = models.BooleanField("Allow non matching SSL domains", default=False)
    is_http2 = models.BooleanField("Allow http2.0", default=False)
    pop_down_threshold = models.IntegerField('PoP Down Threshold',default=2)
    bands = SimpleIntermediateM2MField('Band', through='CdnDomainBand', table_to_field={'cdn_service':'service'})
    result_count = models.IntegerField('Number of A records', default=2)
    customer = models.ForeignKey(Customer, null=True, blank=True)
    plain_port = models.IntegerField("Plain service port ", default=0, help_text='Choose a non-default port for non-secure delivery. Default 0 means standard port. ')
    secure_port = models.IntegerField("Secure service port ", default=0, help_text='Choose a non-default port for secure delivery. Default 0 means standard port. ')
    use_edns_client_subnet = models.BooleanField('Use edns client subnet', default=True)
    use_global_region_rule = models.BooleanField('Use global region rule', default=False)
    ssl_server_protocols = models.CharField("SSL Server Protocols ", default="", null=True, blank=True, max_length=50,
                                            help_text="""Comma separated list of SSL Server Prototols ("SSLv3,TLSv1,TLSv1.1,TLSv1.2"). If NULL, CS will use "TLSv1,TLSv1.1,TLSv1.2" """)
    ssl_client_protocols = models.CharField("SSL Client Protocols ", default="", null=True, blank=True, max_length=50,
                                            help_text="""Comma separated list of SSL Client Prototols ("SSLv3,TLSv1,TLSv1.1,TLSv1.2"). If NULL, CS will use "TLSv1,TLSv1.1,TLSv1.2" """)
    ssl_server_ciphers = models.CharField("SSL Server Ciphers ", null=True, blank=True, max_length=1000,
                                          help_text="""Comma separated list of Ciphers that CS should use when acting as server.
                                              If NULL CS will use "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,TLS_RSA_WITH_AES_256_GCM_SHA384,TLS_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384,TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA,TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256,TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA,TLS_RSA_WITH_AES_256_CBC_SHA256,TLS_RSA_WITH_AES_128_CBC_SHA256,TLS_RSA_WITH_AES_128_CBC_SHA,SSL_RSA_WITH_3DES_EDE_CBC_SHA,TLS_RSA_WITH_AES_256_CBC_SHA """"")
    ssl_client_ciphers = models.CharField("SSL Client Ciphers ", null=True, blank=True, max_length=1000,
                                          help_text="""Comma separated list of Ciphers that CS should use when acting as client.
                                              TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384,TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA,TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256,TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA,TLS_RSA_WITH_AES_256_CBC_SHA256,TLS_RSA_WITH_AES_128_CBC_SHA256,SSL_RSA_WITH_3DES_EDE_CBC_SHA,SSL_RSA_WITH_RC4_128_MD5,SSL_RSA_WITH_RC4_128_SHA,TLS_RSA_WITH_AES_128_CBC_SHA,TLS_RSA_WITH_AES_256_CBC_SHA """"")

    stage_service = models.BooleanField("Stage Edge Service", default=False,
                                help_text="If you checked this item, this edge service use for \"Staging\"")
    stage_ssl = models.BooleanField("Stage for SSL", default=False,
                                help_text="Staging Edge service for SSL")
    stage_region = models.PositiveSmallIntegerField("Stage Region", null=True, blank=True, choices=get_contract_region(),
                                help_text="Staging Regions")

    product_type = models.PositiveSmallIntegerField("Product Type", null=True, blank=True, choices=SERVICE_PRODUCT_TYPE_CHOICES)
    service_coverage = models.CharField("Service coverage", max_length=5, null=True, blank=True, choices=SERVICE_COVERAGE_CHOICES)
    with_china = models.PositiveSmallIntegerField("With China", null=True, blank=True, choices=YN_CHOICES)
    service_type = models.PositiveSmallIntegerField("Service Type", null=True, blank=True, choices=SERVICE_TYPE_CHOICES)

    class Meta:
        db_table = 'cdn_service'
        verbose_name = "Edge Service"
        ordering = ['dns_prefix']
        app_label = 'oui'

    def save(self, *args, **kwargs):
        if self.ssl_cert and self.pk:
            excluded=[self.id]+kwargs.pop('exclude_services', [])
            for band in self.bands.all():
                if not band.check_keystore(keystore_id=self.ssl_cert.keystore_id, exclude_services=excluded if self.id else kwargs.pop('exclude_services', [])):
                    raise Exception("Saving service (%s) would violate keystore to IP uniqueness constraint.\n services excluded: %s\n %s" % (self.name, str(excluded), band.name) )
        super(Service, self).save(*args, **kwargs)

        service_pk = self.pk
        from ci.common.models.prism_sync import SyncJob
        sync_job = SyncJob(name='service', type='save', key=str(service_pk), flag=0, cnt=0)
        sync_job.save()

    def delete(self):
        service_pk = self.pk
        super(Service, self).delete()

        from ci.common.models.prism_sync import SyncJob
        sync_job = SyncJob(name='service', type='delete', key=str(service_pk), flag=0, cnt=0)
        sync_job.save()

    def get_related_ddos_rules(self):
        from ci.common.models import SiteDDosConvertRule
        site_ddos_rules = SiteDDosConvertRule.objects.filter(site__status=True, edge_prefix_on_ddos_attack=self.pk)
        return site_ddos_rules

    def clean(self):
        if self.pk:
            if self.stage_service:
                production_nodes = self.bands.exclude(Q(bandnode__node__stage_node=True)).values('bandnode__node__hostname')
                if production_nodes.exists():
                    production_hostnames = [node['bandnode__node__hostname']\
                        for node in production_nodes]
                    production_hostnames = ", ".join(list(set(production_hostnames)))

                    raise ValidationError("Stage edge service has to have only stage nodes. Please check the assigned nodes (%s)"%(production_hostnames))

        from ci.common.utils.site import ValidatorCertAndDomain
        try:
            ValidatorCertAndDomain.validate_for_service(
                service=self,
                ssl_cert=self.ssl_cert,
                sni_group=self.sni_group,
                allow_nonmatching_domains=self.allow_nonmatching_domains)
        except Exception, e:
            raise ValidationError(e)
        if self.pk and self.ssl_cert and not self.allow_nonmatching_domains:
            self.validate_ssl_cert_with_ddos_rules()

    def validate_ssl_cert_with_ddos_rules(self):
        ddos_rules = self.get_related_ddos_rules()
        for ddos_rule in ddos_rules:
            if not self.is_site_matches_with_ssl_key_store(ddos_rule.site):
                raise ValidationError("DDos rule set of Site '%s' uses the original certificate on this edge service and is not compatible with this new certificate" % ddos_rule.site.pad)

    def is_site_matches_with_ssl_key_store(self, site):
        if not site.enable_ssl:
            return True
        if self.pk and self.ssl_cert and not self.allow_nonmatching_domains:
            cert_domain = self.ssl_cert.domain if self.ssl_cert else None
            alt_domains = [d.domain for d in self.ssl_cert.keystoredomains_set.all()] if self.ssl_cert else []
            if cert_domain and cert_domain[0] == '*':
                if cert_domain.partition('.')[2] == site.pad.partition('.')[2]:
                    return True
            else:
                if cert_domain == site.pad:
                    return True

            for domain_check in alt_domains:
                if domain_check != '' and domain_check[0] == '*':
                    if domain_check.partition('.')[2] == site.pad.partition('.')[2] and site.enable_ssl:
                        return True
                else:
                    if domain_check == site.pad and site.enable_ssl:
                        return True
            return False
        else:
            return True

    def get_stage_region_display(self):
        pass

    def has_keystore(self):
        return True if self.ssl_cert else False
    has_keystore.boolean = True

    def related_shield_count(self):
        return self.shieldedservice_set.filter(band_relations__isnull=False).count()

    def __unicode__(self):
        return '%s: %s' % (self.dns_prefix, self.name)

    def domainName(self):
        return self.dns_prefix + '.' + self.dns_zone.domain_name

    def pop_set(self):
        return Pop.objects.filter(node__band__service = self).exclude(importance=-1).distinct()

    def pop_count(self):
        return self.pop_set().count()

    def active_pop_count(self):
        return self.pop_set().filter(offline=0).count()

    def band_count(self):
        return self.bands.exclude(node__pop__importance=-1).distinct().count()

    def active_band_count(self):
        return self.bands.filter(node__pop__offline=False).exclude(node__pop__importance=-1).distinct().count()
    pop_count.short_description = 'Number of pops'

    def pops_by_region(self):
        regions = {}
        pops = self.pop_set().select_related()
        for pop in pops:
            if pop.region.name not in regions:
                regions[pop.region.name] = []
            regions[pop.region.name].append(pop)
        ritems = regions.items()
        ritems.sort(key=lambda r: len(r[1]),reverse=True)
        return ritems

    def customers(self):
        return Customer.objects.filter(site__service=self, site__status=True, status=True).select_related().distinct()

    def get_related_default_shield_service(self):
        #from ci.common.models.cache import ShieldedService
        no_shields = self.shieldedservice_set.filter(band_relations__isnull=True)
        if no_shields.exists():
            return no_shields[0]
        else:
            raise Exception("no shield are not set yet for edge service")

    def get_related_nodes(self):
        from ci.common.models.cache import Band, BandNode,CdnDomainBand
        related_bands = CdnDomainBand.objects.filter(service = self).values_list('band',flat=True)
        band_nodes = BandNode.objects.filter(band__in=related_bands).values_list('node',flat=True)
        nodes = Node.objects.filter(pk__in=band_nodes).distinct()
        return nodes

    def get_ip_host_list(self, ok_list=None, is_for_customer=False):
        result_list = []
        for nodes in self.bands.all():
            for ip in nodes.node_ips.all():
                hostname = ip.get_short_hostname()
                item = {
                    'ip': ip.ipv4_address,
                    'location': ip.get_location(),
                    'deploy_status': ip.get_push_status(ok_list)
                }
                if not is_for_customer:
                    item.update({'hostname': hostname})
                result_list.append(item)
        return result_list

    def get_related_ngp_hostname_list(self):
        host_list = []
        nodes = self.get_related_nodes()
        for ngp_hostname in nodes.values_list('ngp_hostname',flat=True):
            host_list.append(short_hostname(ngp_hostname))
        return host_list

    def routingFactors(self):
        try:
            return self.serviceroutingfactors
        except ObjectDoesNotExist:
            return defaultServiceRoutingFactors(self)

    def get_json(self):
        ret_json = self.get_base_json()
        ret_json['sni_group_id'] = self.sni_group_id
        ret_json['keystore_id'] = self.ssl_cert_id
        ret_json['_name'] = str(self) + [' (h1)', ' (h2)'][self.is_http2]
        return ret_json

    def is_use_china_pop(self):
        for pop in self.pop_set():
            if str(pop.country_id) in ['13']:
                return True
        return False


class RoutingFactors(models.Model):
    latency_factor = models.FloatField()
    load_factor = models.FloatField()
    cost_factor = models.FloatField()
    class Meta:
        abstract = True
    def toString(self):
        triple = (self.latency_factor, self.load_factor, self.cost_factor)
        return '1' if triple == (1.0,1.0,1.0) else '(%.2f,%.2f,%.2f)' % triple

class ServicePopRoutingFactors(RoutingFactors):
    id = models.AutoField(primary_key=True, db_column='service_pop_routing_id')
    pop = models.ForeignKey(Pop)
    service = models.ForeignKey(Service)

    class Meta:
        db_table = 'service_pop_routing_factors'
        app_label = 'oui'

def defaultServicePopRoutingFactors(service, pop):
    return ServicePopRoutingFactors(service=service, pop=pop, latency_factor=1.0, load_factor=1.0, cost_factor=1.0)

def getServicePopRoutingFactors(service, pop):
        try:
            return ServicePopRoutingFactors.objects.get(service=service, pop=pop), 'pop'
        except ObjectDoesNotExist:
            try:
                return ServiceRoutingFactors.objects.get(service=service), 'service'
            except ObjectDoesNotExist:
                return defaultServicePopRoutingFactors(service,pop), 'default'

class ServiceRoutingFactors(RoutingFactors):
    service = models.OneToOneField(Service, primary_key=True, db_column='service_id')
    class Meta:
        db_table = 'service_routing_factors'
        app_label = 'oui'

def defaultServiceRoutingFactors(service):
    return ServiceRoutingFactors(service=service, latency_factor=1.0, load_factor=1.0, cost_factor=1.0)

class Node(DatedModel):
    id = models.AutoField(primary_key=True, db_column='node_id')
    hostname = models.CharField(max_length=100, unique=True)
    ngp_hostname = models.CharField(max_length=100, unique=True, blank=True, null=True)
    ipv4_address = models.IPAddressField(unique=True, verbose_name="IPv4 address")
    description = models.CharField(max_length=255, blank=True)
    pop = models.ForeignKey(Pop)
    node_type = models.ForeignKey(NodeType) #1-cs node, 2-dns node, 3-cs/dns
    dns_application = models.IntegerField(choices=((1,'PEDNS'),(2,'GSLB'),(3,'PEGSLB')), blank=True, null=True, help_text="")
    offline = models.BooleanField(default=True)
    broken = models.BooleanField(default=False, help_text='If this is checked, the node will not receive pushes, and "Offline" will also be checked.')
    bands = models.ManyToManyField('Band', through='BandNode')
    ngp_flag = models.BooleanField(default=True)
    stage_node = models.BooleanField("Stage Edge Service", default=False,
                                help_text="If you checked this item, this edge service use for \"Staging\"")

    class Meta:
        db_table = 'node'
        ordering = ['hostname']
        app_label = 'oui'

    def clean(self):
        if self.pk:
            if self.stage_node:
                production_services = self.bands.exclude(Q(services__stage_service=True)).values('services__name')
                if production_services.exists():
                    production_services = [service['services__name']\
                            for service in production_services]
                    production_services = ", ".join(list(set(production_services)))
                    raise ValidationError("Stage Node CAN NOT assign to non-stage service(%s)"%(production_services))
            else:

                stage_services = self.bands.filter(services__stage_service=True).values('services__name')
                if stage_services.exists():
                    stage_services = [service['services__name']\
                            for service in stage_services]
                    stage_services = ", ".join(list(set(stage_services)))
                    raise ValidationError("Node CAN NOT assign to stage service(%s)"%(stage_services))

    def save(self, *args, **kwargs):
        if self.broken:
            self.offline = True
        if self.hostname.rfind('.') <= -1 or self.hostname.rfind('.',0,self.hostname.rfind('.')) <= 0:
            assert False, "Node hostname needs to be fully qualified having atleast 3 levels"
        similiar_nodes = Node.objects.filter(hostname__istartswith = self.name()).exclude(id=self.id)
        for node in similiar_nodes:
            if node.name() == self.name():
                assert False,  "Node hostname removing top 2 domain levels must be unique - conflicting node: " + node.name()
        super(Node, self).save(*args, **kwargs)

        node_pk = self.pk
        from ci.common.models.prism_sync import SyncJob
        sync_job = SyncJob(name='node', type='save', key=str(node_pk), flag=0, cnt=0)
        sync_job.save()

    def delete(self):
        node_pk = self.pk
        super(Node, self).delete()

        from ci.common.models.prism_sync import SyncJob
        sync_job = SyncJob(name='node', type='delete', key=str(node_pk), flag=0, cnt=0)
        sync_job.save()

    def active(self):
        return not self.offline
    def status(self):
        return ('online','offline')[self.offline]
    def name(self):
        try:
            return self.hostname[:self.hostname.rfind('.',0,self.hostname.rfind('.'))]
        except:
            return self.hostname
    def sortable_name(self):
        "zero-pad node numbers so that n2 comes before n19, etc."
        name = self.name()
        try:
            return '%s%04d' % (name[:9], int(name[9:]))
        except:
            return name

    def get_ngp_hostname(self):
        return short_hostname(self.ngp_hostname)

    def failing(self):
        try:
            return not self.offline and (self.nodestat.failed or datetime.now() - self.nodestat.update_time > timedelta(minutes=10))
        except ObjectDoesNotExist:
            return True
    def lal(self):
        try:
            ret = self.nodestat.lal
            if ret != BAD_LAL:
                return ret
            else:
                return '?'
        except:
            return '?'
    def mbps(self):
        try:
            return float(self.nodestat.mbps)
        except:
            return 0
    def rps(self):
        try:
            return float(self.nodestat.rps)
        except:
            return 0
    def ops(self):
        try:
            return float(self.nodestat.ops)
        except:
            return 0
    def serves_dns(self):
        return self.node_type.id > 1
    def hashpoints(self):
        return map (lambda nh: nh.hashpoint, self.nodehashpoint_set.select_related())
    def __unicode__(self):
        return "%s (%d IP%s)" % (self.name(), self.nodeip_set.count(), 's' if self.nodeip_set.count()>1 else '')
    def get_dns(self):
        dns_app = ""
        if self.dns_application == 3:
            dns_app = "PEGSLB"
        if self.dns_application == 2:
            dns_app = "GSLB"
        if self.dns_application == 1:
            dns_app = "PEDNS"
        return dns_app


class NodeIP(models.Model):
    node = models.ForeignKey(Node)
    seq_num = models.IntegerField('IP sequence')
    ipv4_address = models.IPAddressField(unique=True, verbose_name="IPv4 address")
    description = models.CharField('IP Description', null=False, blank=True, max_length=100)
    is_v6 = models.PositiveSmallIntegerField(
        choices=[(1, 'v6'), (0, 'v4')], default=0, null=False, blank=False, editable=False)

    class Meta:
        db_table = 'node_ip'
        verbose_name = "Node IP"
        app_label = 'oui'
        ordering = ['node', 'seq_num']
        unique_together = ('node', 'seq_num')

    def hostname(self):
        return self.node.hostname

    def get_short_hostname(self):
        if self.node:
            if self.node.ngp_hostname:
                return short_hostname(self.node.ngp_hostname)
            elif self.node.hostname:
                return short_hostname(self.node.hostname)
            else:
                return ''
        else:
            return ''

    def name(self):
        return self.node.name()

    def pop(self):
        return self.node.pop

    def offline(self):
        return self.node.offline

    def failing(self):
        return self.node.failing()

    def broken(self):
        return self.node.broken

    def nodestat(self):
        return self.node.nodestat

    def lal(self):
        return self.node.lal()

    def get_v6_node_ip_by_seq(self):
        try:
            return NodeIP.objects.get(node=self.node, seq_num=int(self.seq_num)+100)
        except NodeIP.DoesNotExist:
            return None

    def get_region(self):
        try:
            region_name = self.node.pop.region.name
        except (Exception, ):
            return ''
        return region_name

    def get_location(self):
        try:
            location_name = self.node.pop.cdnw_pop_id.name
        except (Exception,):
            return ''
        try:
            location = location_name.split('-')
            location_name = "%s, %s" % (location[2], location[3])
        except (Exception,):
            location_name = self.node.pop.cdnw_pop_id.name
        return location_name

    def get_push_status(self, ok_list=None):
        if self.node.broken or self.node.offline:
            return 'maintenance'
        return 'deployed' if self.get_short_hostname() in (ok_list or []) else 'waiting'

    @property
    def is_v4(self):
        return not self.is_v6

    def __unicode__(self):
        return "%s (%d: %s)" % (self.node.name(), self.seq_num, self.description)

    def save(self, *args, **kwargs):
        super(NodeIP, self).save(*args, **kwargs)
        nodeip_pk = self.pk
        from ci.common.models.prism_sync import SyncJob
        sync_job = SyncJob(name='nodeip', type='save', key=str(nodeip_pk), flag=0, cnt=0)
        sync_job.save()

    def delete(self):
        nodeip_pk = self.pk
        if self.is_v4:
            v6_nodeip = self.get_v6_node_ip_by_seq()
            if v6_nodeip:
                v6_nodeip.delete()

        super(NodeIP, self).delete()

        from ci.common.models.prism_sync import SyncJob
        sync_job = SyncJob(name='nodeip', type='delete', key=str(nodeip_pk), flag=0, cnt=0)
        sync_job.save()


class NodeLoadLimit(DatedModel):
    node = models.OneToOneField(Node, db_column='node_id', related_name='load_limits')
    max_ops = models.IntegerField()
    max_ips = models.IntegerField()
    max_disk_iops = models.IntegerField()
    max_disk_avg_wait = models.IntegerField()
    max_load_avg_1 = models.IntegerField()
    load_adjustment = models.IntegerField()
    max_mbps = models.IntegerField()
    class Meta:
        db_table = 'node_load_limit'
        app_label = 'oui'
    def __unicode__(self):
        return 'limits for %s (%d)' % (self.node.name(), self.node.id)

class Cohort(models.Model):
    id = models.AutoField(primary_key=True, db_column='cohort_id')
    name = models.CharField(unique=True, max_length=127)
    description = models.CharField(blank=True, max_length=255)
    class Meta:
        db_table = 'user_cohort'
        ordering = ['name']
        app_label = 'oui'
    def agents(self):
        return CohortAgent.objects.filter(cohort=self)
    def agentsText(self):
        return '\n'.join(map(str,self.agents()))
    def routingFactors(self):
        try:
            return self.cohortroutingfactors
        except ObjectDoesNotExist:
            return defaultCohortRoutingFactors(self)

class CohortAgent(models.Model):
    ip_address_num = models.IntegerField(primary_key=True, db_column='ip_address')
    cohort = models.ForeignKey(Cohort, db_column='cohort_id')
    description = models.CharField(blank=True, max_length=255)
    class Meta:
        db_table = 'cohort_ip_address'
        ordering = ['cohort', 'description']
        app_label = 'oui'
    def ip_address_string(self):
        return ipIntToString(self.ip_address_num)
    def __unicode__(self):
        return ""

class CohortRoutingFactors(models.Model):
    cohort = models.OneToOneField(Cohort, primary_key=True, db_column='cohort_id')
    latency_factor = models.FloatField()
    load_factor = models.FloatField()
    cost_factor = models.FloatField()
    class Meta:
        db_table = 'cohort_routing_factors'
        app_label = 'oui'

class MetricsLookup (models.Model):
    metric_value_name = models.CharField(max_length=50)
    metric_value = models.FloatField()
    class Meta:
        db_table = 'metrics_lookup'
        app_label = 'oui'

class ServiceCost(models.Model):
    service_name = models.CharField(max_length=10)
    service_total_rps = models.FloatField()
    apac_rps = models.FloatField()
    emea_rps = models.FloatField()
    east_rps = models.FloatField()
    mid_rps = models.FloatField()
    west_rps = models.FloatField()
    service_total_mbps = models.FloatField()
    apac_mbps = models.FloatField()
    emea_mbps = models.FloatField()
    east_mbps = models.FloatField()
    mid_mbps = models.FloatField()
    west_mbps = models.FloatField()
    class Meta:
        db_table = 'service_cost_breakdown'
        app_label = 'oui'

class PopNetworkDistance(models.Model):
    pop1 = models.ForeignKey(Pop, related_name="pop1_distance")
    pop2 = models.ForeignKey(Pop, related_name="pop2_distance")
    distance = models.IntegerField(default=0)
    cost = models.PositiveSmallIntegerField(default=0)
    class Meta:
        db_table = 'pop_network_distance'
        app_label = 'oui'
        unique_together = ('pop1', 'pop2')
def defaultCohortRoutingFactors(cohort):
    return CohortRoutingFactors(cohort=cohort, latency_factor=1.0, load_factor=1.0, cost_factor=1.0)
