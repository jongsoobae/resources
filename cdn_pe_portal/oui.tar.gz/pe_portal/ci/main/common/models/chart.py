from ci.common.utils.traffic import get_dns_grouped_rows_extra, get_grouped_rows_extra
from ci.common.models.stats import DnsServiceLoad
from ci.common.models import traffic, dns
from ci.common.models.customer import Customer
from ci.common.models.cdn import  Service, Node, Pop
from ci.common.models.geo import Region, Country
from ci.common.models.site import Site
from ci.constants import BASE_DIR
from django.db import models
from django.contrib.auth.models import User as AuthUser
from django.utils.encoding import smart_unicode


from datetime import date, datetime, timedelta
from pickle import dumps, loads
import time
import os
import types

def ago(td):
	"""
	@param td:	A timedelta instance
	@return:	A string like '1 year, 47 days, 10:05 ago', rounded down to nearest 5 minutes
	"""
	return (', '.join(
		'%d %s%s' % (
			value, unit, 's' if value != 1 else ''
		) for unit, value in (
			('year', td.days / 365), 	# ignore leap years
			('day', td.days % 365) 		# ignore leap years
		) if value
	) + (
		' %02d:%02d ' % (
			td.seconds / (60 * 60), # hour
			(((td.seconds % (60 * 60)) / 60) / 5) * 5 # 5 minutes
			# Ignore seconds, milliseconds, and microseconds
		) if td.seconds else ' '
	) + 'ago').strip().replace('  ', ' ') # Trim any extra spaces


def sites_for_user(user):
	"""
	@param user:  The logged-in AuthUser instance
	@return:      A QuerySet of Site instances
	"""
	profile = user.get_profile()
	
	return (
		# Get sites whose drafts are in the user profile's pad_whitelist
		Site.objects.filter(sitedraft__userprofile=profile)
		if profile.restrict_pads
		# Else all the customer's sites, including disabled ones, but excluding those not in the CUI
		else profile.customer.site_set.extra(where=['customer_site_id in (select customer_site_id from customer_site_cui where customer_site_id is not null)'])
	).order_by('pad')


class ChartType:
	def __init__(self, name, label, traffic_tables, factor, total_label=None, total_factor=0,
			extra_filter=None, percentage=False, order_descending=True, split_by=None,
			value_field=None, show_in_cui=True, maximum=False, func='', num_format=".2f"
		):
		"""
		Represents a kind of traffic data (mbps, hits/sec, etc.) that can be graphed
		@param name: 			A string suitable as an HTML element id
		@param label:			A human-readable label for this chart type
		@param traffic_tables:	A tuple of traffic model classes or operators like '+', '-', '(', ')'
		@param factor:			Multiply all data by this number
		@param total_label: 	What to call the total column, like GB transferred or hits
		@param total_factor:	Multiply data in the total column by this AS WELL AS by factor
		@param extra_filter:	Goes in the SQL WHERE clause to filter the traffic data
		@param percentage:		If True, treat sums and averages appropriately for a percentage,
								otherwise treat them as absolute measures
		@param order_descending:If True, order Serieses by descending, otherwise ascending
		@param split_by:		If not None, use this split-by option name instead of the user's choice
		@param show_in_cui:		If True, this chart is shown in the CUI.
		@param maximum:			If not False, is the maximum value of the chart series.
		@param func:            A mysql function name to add around the value, allows for round, floor, ceil extra...
		@param num_format:	Format to display numbers in key
		"""
		self.name 				= name
		self.label 				= label
		self.traffic_tables		= traffic_tables
		self.factor				= factor
		self.total_label		= total_label
		self.total_factor		= total_factor
		self.extra_filter   	= extra_filter
		self.percentage			= percentage
		self.order_descending	= order_descending
		self.split_by			= split_by
		self.value_field        = value_field
		self.show_in_cui		= show_in_cui
		self.maximum			= maximum
		self.func			= func
		self.num_format			= num_format

# option name, and the group-by column
class SplitByOption:
	def __init__(self, name, label, model_class, columns, label_plural=None, display_field="name"):
		self.name                = name
		self.label               = label
		self.label_plural= label_plural or label + 's'
		self.model_class = model_class
		self.columns     = columns
		self.display_field       = display_field
		

#if adding a category need to create class object and modify: category_options and all_chart_types
class CategoryOptions:
	def __init__(self, chart_types, split_by_options, filter_types, series_function):
		"""
		All items needed for each category of charts.
		@param chart_types - set of ChartType objects
		@param split_by_options - set of SplitByOption objects
		@param filter_types - strings of filter type options
		@param series_function - function to generate series from database
		"""
		self.chart_types = chart_types
		self.split_dict = dict((s.name, s) for s in split_by_options)
		self.split_by_options = split_by_options
		self.filter_types = filter_types
		self.series_function = series_function
	def get_chart_types_dict(self):
		return dict((c.name, c) for c in self.chart_types)

category_options = [
	#Http CategoryOptions
	CategoryOptions(
		chart_types = [
			ChartType('mbps', 'Mbps', (traffic.TrafficBytesPop,), 8./(5.*60*1000000), 'GB transferred', 5*60*1000000/(8.*1000**3)),
			ChartType('hits_per_sec', 'Hits/Sec', (traffic.TrafficRequestsPop,), 1/(5.*60), 'total hits', 5*60, num_format=".0f"),
			ChartType('mbps_from_origin', 'Origin Mbps', (traffic.TrafficMissBytesPop,), 8./(5.*60*1000000), 'GB transferred', 5*60*1000000/(8.*1000**3)),
			ChartType('pct_data_from_cache', 'Cache Miss % (by Mbps)', (traffic.TrafficMissBytesPop, '/', traffic.TrafficBytesPop), 100, percentage=True, show_in_cui=False, maximum=100),
			ChartType('hits_per_sec_from_origin', 'Origin Hits/Sec', (traffic.TrafficMissRequestsPop,), 1/(5.*60), 'total hits', 5*60, num_format=".0f"),
			ChartType('pct_hits_per_sec_from_cache', 'Cache Miss % (by Hits)', (traffic.TrafficMissRequestsPop, '/', traffic.TrafficRequestsPop), 100, percentage=True, show_in_cui=False, maximum=100),
			ChartType('avg_object_size', 'Average Object Size (kb)', (traffic.TrafficBytesPop, '/', traffic.TrafficRequestsPop), 0.001, show_in_cui=False, percentage=True),
			ChartType('avg_object_size_from_origin', 'Average objects size fetched from origin (kb)',(traffic.TrafficMissBytesPop,'/',traffic.TrafficMissRequestsPop), 0.001, show_in_cui=False, percentage=True),
			ChartType('hits_per_sec_by_response_code', 'Hits/Sec by Response Code', (traffic.SiteResponseCodeRequestsPop,), 1/(5.*60), 'total hits', 5*60, split_by='response_code', num_format=".0f"),
			ChartType('responses_per_sec_20x', '20x Hits/Sec', (traffic.SiteResponseCodeRequestsPop,), 1/(5.*60), 'total hits', 5*60, "key_value like '2%'", num_format=".0f"),
			ChartType('responses_per_sec_30x', '30x Hits/Sec', (traffic.SiteResponseCodeRequestsPop,), 1/(5.*60), 'total hits', 5*60, "key_value like '3%'", num_format=".0f"),
			ChartType('responses_per_sec_40x', '40x Hits/Sec', (traffic.SiteResponseCodeRequestsPop,), 1/(5.*60), 'total hits', 5*60, "key_value like '4%'", num_format=".0f"),
			ChartType('responses_per_sec_50x', '50x Hits/Sec', (traffic.SiteResponseCodeRequestsPop,), 1/(5.*60), 'total hits', 5*60, "key_value like '5%'", num_format=".0f"),
			ChartType('responses_per_sec_504', 'Error to Origin (50x) Hits/Sec', (traffic.SiteResponseCodeRequestsPop,), 1/(5.*60), 'total hits', 5*60, "key_value = '504'", num_format=".0f", show_in_cui=False),
			ChartType('responses_per_sec_505', 'Internal CDN Error (50x) Hits/Sec', (traffic.SiteResponseCodeRequestsPop,), 1/(5.*60), 'total hits', 5*60, "key_value = '505'", num_format=".0f",  show_in_cui=False),
			ChartType('responses_per_sec_external_50x', 'External Error (50x) Hits/Sec', (traffic.SiteResponseCodeRequestsPop,), 1/(5.*60), 'total hits', 5*60, "key_value like '5%' and key_value != '504' and key_value != '505' ", num_format=".0f",  show_in_cui=False),			
			ChartType('hits_per_sec_by_method', 'Hits/Sec by Method', (traffic.SiteMethodRequestsPop,), 1/(5.*60), 'total hits', 5*60, split_by='method', num_format=".0f"),
		], 
		split_by_options = [ #split_by_options
			SplitByOption('customer_country', 'customer country', Country, ['customer_country.name'], label_plural='customer countries'),
			SplitByOption('customer', 'customer', Customer, ['customer.name']),
			SplitByOption('site_service', 'site service', Service, ['site_service.dns_prefix', 'site_service.name']),
			SplitByOption('customer_site', 'site', Site, ['customer_site.serve_domain']),
			SplitByOption('region', 'region', Region, ['region.name']),
			SplitByOption('country', 'country', Country, ['country.name'], label_plural='countries'),
			# You can't actually split by pop_service, since we don't record which service
			# a POP is using when it responds to a request.  But we still need this SplitByOption
			# TODO jesse:  Do we really need it??
			SplitByOption('pop_service', 'POP service', Service, ['pop_service.dns_prefix','pop_service.name']),
			SplitByOption('pop', 'POP', Pop, ['pop.short_name']),
			SplitByOption('response_code', 'HTTP response code', None, ['key_value']),
			SplitByOption('method', 'HTTP method (GET or HEAD)', None, ['key_value']),
		],
		filter_types = ('customer', 'site_service', 'customer_site', 'region', 'country', 'customer_country', 'pop_service', 'pop', 'country'),
		series_function = get_grouped_rows_extra
	),
	#DNS CategoryOptions
	CategoryOptions(
		chart_types = [
			ChartType('dns_req_per_sec', 'dns requests/sec', (DnsServiceLoad,), 1/(5.*60), 'total requests', 5*60, value_field="sum(requests)", num_format=".0f"),
			ChartType('guess_req_per_sec', 'guess mode requests/sec', (DnsServiceLoad,), 1/(5.*60), 'total requests', 5*60, value_field="sum(guesses)", num_format=".0f"),
			ChartType('guess_percentage', 'guess mode percentage', (DnsServiceLoad,), 1, '% guess mode', 1, value_field = "sum(guesses)/sum(requests)*100", percentage=True)
		],
		split_by_options = [
			SplitByOption('dns_region', 'region', Region, ['dns_region.name']),
			SplitByOption('dns_service', 'dns service', Service, ['dns_service.dns_prefix','dns_service.name']),
			SplitByOption('node_service', 'node service', Service, ['node_service.dns_prefix','node_service.name']),
			SplitByOption('dns_node', 'node', Node, ['dns_node.hostname'], display_field="name()"),
		],
		filter_types = ('dns_region','dns_node','dns_service','node_service'),
		series_function = get_dns_grouped_rows_extra
	)
]

all_chart_types = dict((c.name, c) for c in category_options[0].chart_types + category_options[1].chart_types)

# Whether a parameter (which sites, which customers, etc.) should be used as a filter
has_all 			= lambda param: 'all' in param
should_filter_by	= lambda param: param and not has_all(param)

class Chart(models.Model):
	"""
	Persist Chartron charts in the database
	"""
	id = models.AutoField(primary_key=True, db_column='id')
	# The Chart's creator, unless this is a chart for everyone's viewing:
	user = models.ForeignKey(AuthUser, null=True)
	title = models.CharField(max_length=1000)
	category = models.PositiveSmallIntegerField(null=False)
	is_cui = models.BooleanField('If True, this Chart was saved from the Customer UI', default=False)
	form_data = models.TextField(
		'A pickled dictionary of HTTP POST keys and values that created this chart'
	)
	create_time = models.DateTimeField(default=datetime.now)
	dates_relative = models.BooleanField('''
		If True, use a date range relative to the current
		time.  If False, use the same absolute time range
		when the chart is loaded.''',
		default=True
	)
	access_time = models.DateTimeField(default=datetime.now)
	is_saved = models.BooleanField(default=False)
	traffic_data = models.TextField(
		'A pickled array of Series objects, cached traffic data'
	)
	traffic_data_time = models.DateTimeField(
		'When traffic_data was last updated',
		default=None, null=True
	)
	chart_type = models.CharField(max_length=100, choices=all_chart_types.items())
	class Meta:
		db_table = 'oui_chart'
		app_label = 'oui'
	def __init__(self, *args, **kwargs):
		super(Chart, self).__init__(*args, **kwargs)
		
		# Update access_time and unless this instance is new, write new access_time back to DB
		self.access_time = datetime.now()
		if self.id:
			self.save()
		
		# Map: operation name -> duration in seconds
		self.operations = {}
		self._timing_operation = None
		
		self.colors 	= (
			'darkblue','darkred','darkgreen','darkorange','yellow','steelblue',
			'seagreen','slateblue','darkviolet','red','green','blue','cyan',
			'black','magenta'
		)
		
		self.other_color = 'gray' # For the grouped 'other' data at the end of the legend
		self.total_color = 'black' # For the 'total' data
		self.initialized = False
		self.order_by_function = "max"	
	def initialize(self, tzoffset, form_data=None, nice_title_duration=None, order_by=None):
		"""
		After retrieving or creating a Chart from the DB, call this with a
		tzoffset to complete initialization.
		
		@param tzoffset:			The number of hours offset from UTC, maybe a float
		@param form_data:			If not None, set form_data to this dictionary
		@param nice_title_duration:	If not None, use this to express chart's time range
		@param order_by_function:	Name of series function to use to order...
		"""
		self._start_timer('initialize')
		if order_by:
			self.order_by_function = order_by
		if not form_data:
			form_data 				= self.getFormData(tzoffset)
		elif not self.form_data:
			self.setFormData(form_data, tzoffset)
		
		self.tzoffset 				= float(tzoffset)
		
		self.nice_title_duration	= nice_title_duration
		
		if form_data:
			self.legend_count 	= form_data['legend_count']
			self.include_other	= form_data['include_other'] if form_data.has_key('include_other') else True
			self.show_stacked	= form_data['show_stacked'] if form_data.has_key('show_stacked') else True
			self.chart_total	= form_data['chart_total'] if form_data.has_key('chart_total') else True
			self.use_gmt		= form_data['use_gmt'] if form_data.has_key('use_gmt') else False
			
			# Find the split-by option with the correct name
			split_by_name = form_data['split_by']
			self.split_by = category_options[self.category].split_dict[split_by_name]
		
		if self.chart_type:
			self.chart_type_info	= all_chart_types[self.chart_type]
			# Unless this type of chart requires a certain split-by option,
			# find the split-by the user chose
			split_by_name	= self.chart_type_info.split_by or form_data['split_by']
			if not form_data.has_key('category'):
				#this is for legacy saved charts before category was added
				form_data['category'] = 0
			self.split_by	= category_options[form_data['category']].split_dict[split_by_name]
			self.title = self.make_title()
		
		self._stop_timer()
		self.initialized = True
	
	def get_times(self, tzoffset):
		"""
		@param tzoffset:	The offset in hours from UTC
		@return:			start, end, start_utc, end_utc
		"""
		from ci.common.utils.traffic import round_time_to_epoch
		# getFormData() updates start and end if self.dates_relative
		form_data	= self.getFormData(tzoffset)
		start  		= round_time_to_epoch(form_data['start'],5)
		end    		= round_time_to_epoch(form_data['end'],5)
		start_utc  	= start - timedelta(hours=tzoffset)
		end_utc    	= end   - timedelta(hours=tzoffset)
		return start, end, start_utc, end_utc
	
	def __unicode__(self):
		return 'Chart(id=%s, title=%s)' % (
			repr(self.id), repr(self.title)
		)
	
	def setFormData(self, form_data, tzoffset):
		self._start_timer('setFormData')
		form_data['saved_tzoffset'] = tzoffset
		self.form_data = dumps(form_data)
		self._stop_timer()
	
	def getFormData(self, tzoffset):
		from ci.common.utils.traffic import round_time_to_epoch
		self._start_timer('getFormData')
		try:
			if not self.form_data:
				return {}
			else:
				unpacked_data = loads(str(self.form_data))
				now = datetime.now()
				if self.dates_relative:
					for i in 'start', 'end':
						#must round now and self.create_time 
						#otherwise could move the range by 5 minutes depending how far into the epoch each is
						unpacked_data[i] = round_time_to_epoch(unpacked_data[i] + (round_time_to_epoch(now,5) - round_time_to_epoch(self.create_time,5)),5)
						if unpacked_data.has_key('saved_tzoffset') and unpacked_data['saved_tzoffset'] <> tzoffset:
							unpacked_data[i] += timedelta(hours=tzoffset - unpacked_data['saved_tzoffset'])
				return unpacked_data
		finally:
			self._stop_timer()
	
	def setTrafficData(self, traffic_data):
		self._start_timer('setTrafficData')
		self.traffic_data 		= dumps(traffic_data)
		self.traffic_data_time 	= datetime.now()
		self._stop_timer()
	
	def getTrafficData(self):
		self._start_timer('getTrafficData')
		try:
			return loads(str(self.traffic_data))
		finally:
			self._stop_timer()
	
	
	def _sequence_to_filter(self, table_name, ids):
		"""
		Write a SQL fragment filtering a table
		@param table_name:	The name of a table in the DB
		@param ids:			A sequence of integers, ids
		"""
		table2column = {
			'site_service'	: 'cdn_service_id',
			'pop_service'	: 'cdn_service_id',
			'dns_node'	: 'node_id',
			'dns_region'	: 'region_id',
			'dns_service'	: 'cdn_service_id',
			'node_service'	: 'cdn_service_id',
			'customer_country': 'country_id',
		}
		
		return '%s.%s in (%s)' % (
			table_name,
			table2column.get(table_name, table_name + '_id'),
			','.join(map(str, ids)) if ids else 'null'
		)
	
	def make_title(self, show_dates=True):
		"""
		Create a title string for this chart
		@param show_dates:	bool, if False omit start and end times from the title
		@return: 			A string, this chart's title
		"""

		from ci.common.utils.formutil import form_list_to_id_set

		form_data = self.getFormData(self.tzoffset)
		start, end, start_utc, end_utc = self.get_times(self.tzoffset)
		self._start_timer('make_title')
		try:
			
			def filter_description(filters, split_dict):
				for filter in filters:
					split_by_option = split_dict[filter]
					if filter in form_data:
						ids = form_list_to_id_set(form_data[filter])
						include_other = form_data['include_other'] if form_data.has_key('include_other') else True
						if should_filter_by(ids):
							if len(ids) <= 3:
								return ', '.join(
									eval("split_by_option.model_class.objects.get(id=i)." + split_by_option.display_field)
									for i in ids
								)
							else:
								return '%d %s' % (len(ids), split_by_option.label_plural)
						elif not include_other and form_data['split_by'] == split_by_option.label:
							return 'top %d %s' %(form_data['legend_count'], split_by_option.label_plural)
						# elif has_all(ids):
						# 	return 'all %s' % split_by_option.label_plural
				
				# Last-ditch default
				return 'all %s' % split_dict[filters[0]].label_plural
		
			if self.category == 0:			
				first_filter_description = filter_description(['customer_country','customer', 'site_service', 'customer_site'], category_options[self.category].split_dict)
				second_filter_description  = filter_description(['region', 'country', 'pop_service', 'pop'], category_options[self.category].split_dict)
			elif self.category == 1:
				first_filter_description = filter_description(['node_service', 'dns_region', 'dns_node'], category_options[self.category].split_dict)
				second_filter_description = filter_description(['dns_service'], category_options[self.category].split_dict)
			else:
				first_filter_description = "Unknown"
				second_filter_description = "Unknown"
				
			if self.dates_relative:
				now = datetime.now()
				time_range_description = '%s to %s' % (
					ago(now - start_utc), ago(now - end_utc)
				)
			else:
				time_range_description = '%s to %s' % (
					start.strftime('%Y-%m-%d %H:%M'), end.strftime('%Y-%m-%d %H:%M')
				)
			
			if show_dates:
				time_desc	= (
					', 1 ' + self.nice_title_duration
					if self.nice_title_duration
					else ', %s (UTC%+d)' % (time_range_description, self.tzoffset)
				)
			else:
				time_desc 	= ''
			
			return '%s for %s in %s by %s%s' % (
				self.chart_type_info.label,
				first_filter_description,
				second_filter_description,
				self.split_by.label,
				time_desc
			)
		finally:
			self._stop_timer()
	
	def get_serieses(self, disable_save=False):
		"""
		Side-effect!:  Caches the serieses and saves this Chart to the DB, persisting
		any other changes since this Chart was instantiated from the DB!
		@param disable_save:	This turns off the side effect of saving the chart.  If is_saved is True this param is ignored. This generally needs to be on as the graph and the key are generated seperately and it would be bad to do that processing twice.  However, dashboard generates both of these at once and will never access the same chart instance so the save is not desireable.
		@return:	(serieses, grand_total), where serieses is an ordered list of
					Series instances, representing traffic statistics, and
					grand_total is one series representing the sum of all the serieses
		"""
		assert self.initialized

		from ci.common.utils.traffic import make_time_slice, Series, add_series
		from ci.common.utils.formutil import form_list_to_id_set

		start, end, start_utc, end_utc = self.get_times(self.tzoffset)
		# Does the model instance have cached traffic data?
		if self.traffic_data_time and datetime.now() - self.traffic_data_time < timedelta(minutes=5):
			self._start_timer('retrieve cached traffic data')
			serieses = self.getTrafficData()
		else:
			form_data = self.getFormData(self.tzoffset)
			self._start_timer('create data filters')
			extra_filters = [self.chart_type_info.extra_filter] if self.chart_type_info.extra_filter else []
			legend_count = form_data['legend_count']

			for filter in category_options[self.category].filter_types:
				ids = form_list_to_id_set(form_data.get(filter))
				
				# For CUI charts, only chart user's sites
				if filter == 'customer_site' and self.is_cui:
					allowed_sites = (s.id for s in sites_for_user(self.user)) # generator
					if should_filter_by(ids):
						ids.intersection_update(allowed_sites)
						if not ids:
							# Weird: if we got here, it means ids was a subset of
							# sites, but none were allowed for the user
							ids = set(allowed_sites)
					else:
						ids = set(allowed_sites)
					
					extra_filters.append(self._sequence_to_filter(filter, ids))
				
				elif should_filter_by(ids):
					extra_filters.append(self._sequence_to_filter(filter, ids))
			
			self._start_timer('query')
			rows = category_options[self.category].series_function(
				traffic_tables=self.chart_type_info.traffic_tables,
				start_time=start_utc,
				end_time=end_utc,
				extra_groups=self.split_by.columns if legend_count != 0 or not self.chart_type_info.percentage else [],
				extra_filters=extra_filters,
				factor=self.chart_type_info.factor,
				value_field=self.chart_type_info.value_field,
				maximum=self.chart_type_info.maximum,
				func=self.chart_type_info.func,
			)
			self._start_timer('split data and sort by max')
			
			# Sum up each set of data that has the same split_by_key (e.g., same
			# customer name)
			split_by_key2rows= {}
			for row in rows:
				if legend_count == 0 and self.chart_type_info.percentage:
					split_by_key = 'Total'
				else:
					split_by_key = ': '.join(smart_unicode(getattr(row, column_name), 'ascii', errors='replace') for column_name in self.split_by.columns)
				split_by_key2rows.setdefault(split_by_key, []).append(row)
			serieses 	= []
			for split_by_key, rows in split_by_key2rows.items():
				serieses.append(
					Series(
						split_by_key   	= split_by_key,
						data			= make_time_slice(rows, start_utc, end_utc),
						total_factor	= self.chart_type_info.total_factor
					)
				)

			if legend_count == 0 and self.chart_type_info.percentage:
				legend_count = 1
			
			# Order
			order_fn = lambda a, b: cmp(getattr(a,self.order_by_function)(), getattr(b,self.order_by_function)())
			serieses.sort(order_fn, reverse=self.chart_type_info.order_descending)
					
			self._start_timer('limit legend lines')
			
			# If there are too many split-by keys, group all but the largest few
			include_other = form_data['include_other'] if form_data.has_key('include_other') else True
			serieses, tail = serieses[:legend_count], serieses[legend_count:]
			if include_other and (tail or serieses) and not self.chart_type_info.percentage:
				other_series 		= Series(
					split_by_key	= 'Other',
					data			= reduce(
						add_series,
						[s.data for s in tail],
						[0] * len(serieses[0].data if serieses else tail[0].data)
					),
					total_factor	= self.chart_type_info.total_factor
				)
				if other_series.max() > 0:
					#this removes other series that have no data adding total incorrectly...
					serieses.append(other_series)
			
			# Now that they're sorted and grouped, assign colors (assigning colors
			# after sorting by max helps keep colors more consistent from chart to chart)
			for i, series in enumerate(serieses):
				series.color = self.colors[i % len(self.colors)]
			
			if serieses and serieses[-1].split_by_key == 'Other':
				serieses[-1].color = self.other_color
			elif serieses and serieses[-1].split_by_key == 'Total':
				if len(serieses) > 1 and serieses[-2].split_by_key == 'Other':
					serieses[-2].color = self.other_color
				serieses[-1].color = self.total_color
			# Cache the data in the DB for later
			self.setTrafficData(serieses)

			if not disable_save or self.is_saved:
				self.save()
		
		self._stop_timer()
		if not serieses:
			grand_total = None
		else:
			grand_total = [0]*len(serieses[0].data)
			for series in serieses:
				grand_total =  add_series(grand_total, series.data)
			grand_total = Series(serieses[0].split_by_key, grand_total, serieses[0].total_factor)
		return serieses, grand_total
	
	def image(self, width, height, serieses = None, grand_total = None, show_axis=True, full_image=False, show_x = True, show_y = True, legend=False):
		"""
		Returns the binary contents of a chart image as StringIO
		
		If both serieses and grand_total are set the call to self.get_serieses() will be avoided.  This should be used if the same process needs to call these already saving computation
		@param width:	Width in pixels
		@param height:	Height in pixels
		@param serieses: [Optional] The first return from self.get_serieses()
		@param grand_total: [Optional] The second return value from self.get_serieses()
		"""
		assert self.initialized
		
		from ci.common.utils.chart import create_chart, create_message_chart

		start, end, start_utc, end_utc = self.get_times(self.tzoffset)
			
		if not serieses or not grand_total:
			serieses, grand_total = self.get_serieses()
	
		if not serieses:
			return create_message_chart('No data is available for the selected settings', width, height)
	
		chart = create_chart(serieses, start, end, width, height, minute_interval=5,
			stacked=not self.chart_type_info.percentage and self.show_stacked, percentage=self.chart_type_info.percentage or not self.chart_total, order=lambda x: x, 
			ylabel = self.chart_type_info.label + ("" if self.chart_type_info.percentage  or not self.show_stacked else " (stacked)"), 
			xlabel='date', show_axis=show_axis, full_image=full_image, show_x=show_x, show_y=show_y, legend=legend)
		return chart
	
	def mark_saved(self, dates_relative):
		"""
		Mark this Chart saved (no longer temporary).  You should call save() after
		this to actually write it back to the DB.  is_saved will now be True.
		@param dates_relative:  bool, new value for Chart.dates_relative
		"""
		assert self.initialized
		
		self.is_saved = True # Praise Jesus!
		self.dates_relative = dates_relative
		# If dates_relative changed, it'll change the format of the title
		self.title = self.make_title()
	
	def _start_timer(self, operation):
		"""
		Start timing the performance of an operation; complete timing a previous
		operation if necessary.
		"""
		# TODO jesse:  save ops across requests and print them somewhere useful
		if self._timing_operation:
			self._stop_timer()
		self._timing_operation = operation
		self._timing_start     = time.time()
		#print '_start_timer(%s): %s' % (repr(operation), time.ctime())
	
	def _stop_timer(self):
		"""
		Complete timing the performance of an operation
		"""
		#print '_stop_timer(%s): %s' % (repr(self._timing_operation), time.ctime())
		if self._timing_start:
			self.operations[self._timing_operation] = time.time() - self._timing_start
			self._timing_operation = self._timing_start = None
	

