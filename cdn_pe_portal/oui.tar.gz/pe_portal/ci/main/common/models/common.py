import json
from StringIO import StringIO
from django.db import models
from django.shortcuts import get_object_or_404
from django.core import serializers
from django.core.serializers.json import Serializer as JSONSerializer
from django.utils import simplejson
from django.utils.encoding import smart_str, is_protected_type, smart_unicode
from ci.common.utils.misc import dict_diff
from ci.common.utils import shared_constants
from ci.common.decorators import log_exception
from ci.common.utils.util_common import get_request as _get_request, get_username_from_context, \
    get_userinfo_as_tuple_from_context, get_userinfo_from_context, get_current_obj_from_db

get_request = _get_request

ACTION_TYPE = shared_constants.CHANGE_ACTION_TYPE

class PantherSerializer(JSONSerializer):

    def serialize(self, queryset, **options):
        """
        Serialize a queryset.
        """
        self.options = options

        self.stream = options.pop("stream", StringIO())
        self.selected_fields = options.pop("fields", None)
        self.use_natural_keys = options.pop("use_natural_keys", False)

        self.start_serialization()
        for obj in queryset:
            self.start_object(obj)

            for field in obj._meta.local_fields:
                if field.serialize:
                    if field.rel is None:
                        if self.selected_fields is None or field.attname in self.selected_fields:
                            self.handle_field(obj, field)
                    else:
                        if self.selected_fields is None or field.attname[:-3] in self.selected_fields:
                            self.handle_fk_field(obj, field)
            for field in obj._meta.many_to_many:
                if field.serialize:
                    if self.selected_fields is None or field.attname in self.selected_fields:
                        self.handle_m2m_field(obj, field)
            self.end_object(obj)
        self.end_serialization()
        return self.getvalue()

    def handle_field(self, obj, field):
        """
        since current obj values are come from input form, type is often differ from db value.
        To avoid different object instance type, we need to type cast additionally.
        :param obj:
        :param field:
        :return:
        """
        try:
            field_value = field._get_val_from_obj(obj)
            if field_value:
                if isinstance(field, models.IntegerField) or isinstance(field, models.AutoField):
                    if not isinstance(field_value, int):
                        field_value = int(field_value)
                elif isinstance(field, models.FloatField):
                    if not isinstance(field_value, float):
                        field_value = float(field_value)
                elif isinstance(field, models.BooleanField):
                    if not isinstance(field_value, bool):
                        field_value = bool(field_value)
                elif isinstance(field, models.DateField):
                    pass
                else:
                    pass
            # Protected types (i.e., primitives like None, numbers, dates,
            # and Decimals) are passed through as is. All other values are
            # converted to string first.
            if is_protected_type(field_value):
                self._current[field.name] = field_value
            else:
                self._current[field.name] = field.value_to_string(obj)
        except Exception,e:
            raise e

    def handle_fk_field(self, obj, field):
        #in case field has Foreignkey reference, we need to type cast keyvalue as int
        try:
            try:
                related = getattr(obj, field.name, None)
            except:
                related = None
            if related is not None:
                if self.use_natural_keys and hasattr(related, 'natural_key'):
                    related = related.natural_key()
                else:
                    if field.rel.field_name == related._meta.pk.name:
                        # Related to remote object via primary key
                        related = related._get_pk_val()
                        try:
                            related = int(related)
                        except:
                            pass
                    else:
                        # Related to remote object via other field
                        related = smart_unicode(getattr(related, field.rel.field_name), strings_only=True)
            self._current[field.name] = related
        except Exception,e:
            raise e

    def handle_m2m_field(self, obj, field):
        if isinstance(field.rel.through, str):
            try:
                if self.use_natural_keys and hasattr(field.rel.to, 'natural_key'):
                    m2m_value = lambda value: value.natural_key()
                else:
                    m2m_value = lambda value: smart_unicode(value._get_pk_val(), strings_only=True)

                self._current[field.name] = [m2m_value(related) for related in getattr(obj, field.name).iterator()]
            except Exception,e:
                pass
        elif field.rel.through._meta.auto_created:
            try:
                if self.use_natural_keys and hasattr(field.rel.to, 'natural_key'):
                    m2m_value = lambda value: value.natural_key()
                else:
                    m2m_value = lambda value: smart_unicode(value._get_pk_val(), strings_only=True)

                self._current[field.name] = [m2m_value(related) for related in getattr(obj, field.name).iterator()]
            except Exception,e:
                pass


def log_change_history(obj, previous_obj=None, user=None, request=None):
    pass

def serialize_obj_to_json(obj):
    serializer = PantherSerializer()
    data = serializer.serialize([obj])
    return data

def deserialize_first_obj_from_json(json_data):
    """
    serialize returns iterator.
    since we put queryset objects to serialize, we need to pop just 1 item from iterator
    :param json_data:
    :return:
    """
    objs = serializers.deserialize('json', json_data)
    for obj in objs:
        return obj

def get_changed_obj_fields(obj, current_obj=None, previous_obj=None, log_diff_ignored_fields=[]):
    if obj and hasattr(obj, "PantherMeta"):
        skip_fields = getattr(obj.PantherMeta, "log_diff_skip_fields", [])
        log_diff_ignored_fields += skip_fields
    return dict_diff(previous_obj, current_obj, log_diff_ignored_fields)


def get_changed_as_json(obj, current_json, previous_json='{}', action_type=None, log_diff_ignored_fields=[]):
    action_type = shared_constants.UPDATE_ACTION if action_type is None else action_type
    action_type = shared_constants.INSERT_ACTION if not previous_json else action_type
    action_dict = dict((x,y) for x,y in shared_constants.CHANGE_ACTION_TYPE)
    changed_fields = action_dict.get(action_type)
    if action_type == shared_constants.UPDATE_ACTION:  # if update, save previous self
        current_serialized = json.loads(current_json)
        previous_serialized = json.loads(previous_json)
        current_json_obj = current_serialized[0].get('fields') if current_serialized and 'fields' in current_serialized[0] else {}
        previous_json_obj = previous_serialized[0].get('fields') if previous_serialized and 'fields' in previous_serialized[0] else {}
        changed_obj_fields = get_changed_obj_fields(obj, current_json_obj, previous_json_obj, log_diff_ignored_fields)
        changed_fields = json.dumps(changed_obj_fields)
    return changed_fields

def get_parent_obj_model_as_tuple(obj):
    parent_model = obj._meta.db_table
    parent_pk = obj.pk if obj.pk else 0
    if hasattr(obj, 'PantherMeta'):
        parent_obj_name = getattr(obj.PantherMeta, 'parent', None)
        if parent_obj_name:
            parent_instance = getattr(obj, parent_obj_name, None)
            if parent_instance:
                parent_model = parent_instance._meta.db_table
                parent_pk = parent_instance.pk
    return parent_model,parent_pk

class DatedModel(models.Model):
    create_user = models.CharField(max_length=30, editable=False)
    modify_user = models.CharField(max_length=30, editable=False)
    modify_time = models.DateTimeField(auto_now=True, editable=False)
    create_time = models.DateTimeField(auto_now_add=True, editable=False)

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        if kwargs.has_key('user') and isinstance(kwargs['user'],(str,unicode)):
            self.modify_user = kwargs.pop('user')[0:30]
            if not self.pk:
                self.create_user = self.modify_user
        #following codes are commented, since 'modify_user' column size are not always bigger than 30 byte
        #for instance cdn_service model who inherits this Datedmodel, has 10 byte size 'modify_user' column
        #we need to lenthen 'modify_user' column to prevent another unexpected error.
        #else:
        #    username = get_username_from_context()
        #    self.modify_user = username[0:30]
        #    if not self.pk:
        #        self.create_user = self.modify_user
        super(DatedModel,self).save(*args,**kwargs)

    def get_base_json(self):
        ret_json = {}
        for field in self._meta.fields:
            value = getattr(self, field.name)
            if isinstance(value, bool):
                ret_json[field.name] = value
            else:
                ret_json[field.name] = unicode(value) if value else ''
        return ret_json

class HistoryModel(models.Model):
    log_diff_ignored_fields = ['date_modified', 'date_updated', 'latest_history_id', 'modify_time','create_time',
                          'update_time', 'latest_updater', 'time_updated','time_created']

    class Meta:
        abstract = True

    def is_allowed_to_log(self):
        is_track_enabled = (hasattr(self, "PantherMeta") and getattr(self.PantherMeta, "track", True))
        is_allowed_to_log = is_track_enabled or not hasattr(self, "PantherMeta")
        return is_allowed_to_log

    def check_action_type(self):
        if self.pk:
            action_type = shared_constants.UPDATE_ACTION
        else:
            action_type = shared_constants.INSERT_ACTION
        return action_type

    def get_previous_obj(self):
        if self.pk:
            try:
                return get_object_or_404(self.__class__, pk=self.pk)
            except:
                return None
        else:
            return None

    def save(self, *args, **kwargs):
        action_type = self.check_action_type()
        previous_self = self.get_previous_obj()

        super(HistoryModel,self).save(*args,**kwargs)
        if self.is_allowed_to_log():
            ChangeActionHistory.log_change_action(obj=self, previous_obj=previous_self,
                                                  action_type=action_type,
                                                  log_diff_ignored_fields=HistoryModel.log_diff_ignored_fields)

    def delete(self, *args, **kwargs):
        ChangeActionHistory.log_change_action(obj=self, action_type=shared_constants.DELETE_ACTION)
        super(HistoryModel, self).delete(*args, **kwargs)

class DatedHistoryModel(HistoryModel):
    create_user = models.CharField(max_length=30, editable=False)
    modify_user = models.CharField(max_length=30, editable=False)
    modify_time = models.DateTimeField(auto_now=True, editable=False)
    create_time = models.DateTimeField(auto_now_add=True, editable=False)

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        if kwargs.has_key('user') and isinstance(kwargs['user'],(str,unicode)):
            self.modify_user = kwargs.pop('user')[0:30]
            if not self.pk:
                self.create_user = self.modify_user
        else:
            self.modify_user = get_username_from_context()
            if not self.pk:
                self.create_user = self.modify_user
        super(DatedHistoryModel,self).save(*args,**kwargs)

    def delete(self, *args, **kwargs):
        super(DatedHistoryModel, self).delete(*args, **kwargs)


class ChangeActionHistory(models.Model):
    action_id = models.AutoField(primary_key=True, editable=False)
    action_model = models.CharField(max_length=50, editable=False)
    parent_model = models.CharField(max_length=50, editable=False)
    user_name = models.CharField(max_length=30, editable=False)
    app_name = models.CharField(max_length=100, editable=False)
    action_pk = models.IntegerField(editable=False)
    parent_pk = models.IntegerField(editable=False)
    action_obj = models.TextField(editable=False)
    user_ip = models.IPAddressField(blank=True, editable=False)
    action_time = models.DateTimeField(auto_now_add=True, editable=False)
    action_type = models.IntegerField(choices=ACTION_TYPE, editable=False)


    def __unicode__(self):
        return "%s %s" % (self.action_model, str(self.action_pk))

    class Meta:
        db_table = 'change_action_history'
        app_label = 'History'
        ordering = ['-action_id']


    @classmethod
    @log_exception(default_return_value=None)
    def log_change_action(cls, obj, previous_obj=None, previous_obj_json=None,
                          action_type=None, request=None, log_diff_ignored_fields=[]):
        """
        log change action
        :param obj:
        :param previous_obj: previous object before change.
        :param previous_obj_json: if model fields has m2m field, those values are need to evaluated earlier rather than compare time.
        :param action_type:
        :param request:
        :param log_diff_ignored_fields: ignored to compare
        :return:
        """
        result = None
        if request is None:
            request = get_request()
        if previous_obj is None and previous_obj_json is None:
            previous_obj = get_current_obj_from_db(obj)
        if not action_type:
            action_type = shared_constants.INSERT_ACTION if not previous_obj else action_type
            action_type = shared_constants.UPDATE_ACTION if previous_obj and action_type is None else action_type

        current_json = serialize_obj_to_json(obj)
        previous_json = previous_obj_json if previous_obj_json else serialize_obj_to_json(previous_obj) if previous_obj else '{}'
        change_comment = get_changed_as_json(obj, current_json, previous_json, action_type, log_diff_ignored_fields)
        action_obj = {'snapshot': current_json, 'change_diff': change_comment}

        user_info = get_userinfo_from_context(request)
        parent_model, parent_pk = get_parent_obj_model_as_tuple(obj)

        if change_comment and change_comment != '{}':

            action_history = ChangeActionHistory(user_name=user_info.get('username'),
                                        app_name=user_info.get('app_name'),
                                        action_obj=action_obj,
                                        action_model=obj._meta.db_table,
                                        parent_model=parent_model,
                                        parent_pk=parent_pk,
                                        action_pk=obj.pk if obj.pk else 0,
                                        user_ip=user_info.get('user_ip'),
                                        action_type=action_type)
            action_history.save()
            result = action_history.pk

        UserActionHistory.log_action(action_type, request, user_info, action_id=result)
        return result

    def get_action_obj_as_dict(self):
        action_obj = {}
        try:
            action_obj = simplejson.loads(self.action_obj)
        except:
            try:
                import ast
                action_obj = ast.literal_eval(self.action_obj)
            except Exception, e:
                pass
        if isinstance(action_obj, list):
            return action_obj[0]
        return action_obj

    def get_action_obj_snapshot(self):
        action_obj = self.get_action_obj_as_dict()
        return action_obj.get('snapshot','')

    def get_action_obj_changed_comment(self):
        diff = ''
        action_obj = self.get_action_obj_as_dict()
        diff = action_obj.get('change_diff','')
        if not diff:
            diff = self.change_diff
        return diff

class UserActionHistory(models.Model):
    id = models.AutoField(primary_key=True)
    user_id = models.IntegerField()
    username = models.CharField(max_length=100)
    app_name = models.CharField(max_length=100)
    request_id = models.CharField(max_length=32)
    request_path = models.CharField(max_length=100)
    action_type = models.SmallIntegerField(choices=shared_constants.USER_ACTION_TYPE)
    related_action_id = models.BigIntegerField()
    action_dict = models.CharField(max_length=512)
    user_context = models.CharField(max_length=1024)
    user_ip = models.CharField(max_length=15)
    action_time = models.DateTimeField(auto_now_add=True)

    def __unicode__(self):
        return "%s - %s" % (self.username, str(self.action_type))

    class Meta:
        db_table = 'user_action_history'
        app_label = 'History'

    @classmethod
    def log_action(cls, action_type, request=None, user_info=None, action_id=None):
        try:
            request = get_request() if request is None else request
            user_info = get_userinfo_from_context(request) if user_info is None else user_info
            user_action = UserActionHistory(user_id=user_info.get('user_id'),
                                        username=user_info.get('username'),
                                        app_name=user_info.get('app_name'),
                                        request_path=user_info.get('request_path'),
                                        request_id=getattr(request,'id',None),
                                        action_type=action_type,
                                        related_action_id = action_id,
                                        action_dict={},
                                        user_ip=user_info.get('user_ip'))

            user_action.save()
        except Exception:
            pass

class ActionEventLog(models.Model):
    id = models.AutoField(primary_key=True, db_column='id')
    username = models.CharField(max_length=100)
    request_path = models.CharField(max_length=200)
    request_id = models.CharField(max_length=32)
    app_name = models.CharField(max_length=100)
    request_message = models.CharField(max_length=2048)
    message_detail = models.CharField(max_length=2048)
    result_message = models.CharField(max_length=2048)
    post_message = models.CharField(max_length=2048)
    stack_error_message = models.CharField(max_length=2048)
    event_description = models.TextField(max_length=2048, blank=True)
    log_level = models.IntegerField(choices=shared_constants.LOG_LEVEL)
    user_ip = models.IPAddressField()
    date_created = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'action_event_log'
        app_label = 'History'

    def __unicode__(self):
        return "%s %s by %s" % (str(self.id), self.request_path, self.username)

    @classmethod
    def create_action_event(cls, message='', error_message='', request=None, context=None, log_level=1):
        user_info = get_userinfo_from_context(request)
        error_message = error_message[:2047] if len(error_message) > 2047 else error_message

        action_event = ActionEventLog()
        action_event.username = user_info.get('username')
        action_event.app_name = user_info.get('app_name')
        action_event.message_detail = message
        action_event.user_ip = user_info.get('user_ip')
        action_event.post_message = user_info.get('post_message')
        action_event.request_path = user_info.get('request_path')
        action_event.request_message = user_info.get('request_message')
        action_event.log_level = 3 if error_message else log_level
        action_event.stack_error_message = error_message[:2047] if len(error_message) > 2047 else error_message
        try:
            parameter_context = context.copy()
            if 'password' in parameter_context:
                parameter_context.update({'password':'******'})
            action_event.event_description = parameter_context
        except:
            pass
        action_event.save()
        return action_event.pk