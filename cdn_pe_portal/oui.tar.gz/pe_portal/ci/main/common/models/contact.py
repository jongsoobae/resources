from django.db import models

class Contact(models.Model):
	id = models.AutoField(primary_key=True, db_column='contact_id')
	first_name = models.CharField(max_length=50)
	last_name = models.CharField(max_length=50)
	phone_number = models.CharField(max_length=50, blank=True)
	email_address = models.CharField(max_length=75, blank=True)
	class Meta:
		db_table = 'contact'
		ordering = ['last_name','first_name']
		app_label = 'oui'
	def __unicode__(self):
		return '%s %s' % (self.first_name, self.last_name)
