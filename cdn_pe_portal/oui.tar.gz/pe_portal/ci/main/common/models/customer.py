from django.contrib.auth.models import User as AuthUser
from django.db import models, connection
from django.core.exceptions import ObjectDoesNotExist
from django.conf import settings
from ci.common.models.sni import SNIGroup
from ci.common.models.common import DatedModel
from ci.common.models.billing import BillRate
from ci.common.models.geo import Address, delete_if_unused
from ci.common.utils import timeutil
from ci.common.utils.mathutil import bytes_to_mbps
import datetime
import time
from ci.constants import DWA_MATERIALS, CA_MATERIAL, CA_SSL_MATERIAL,DWA_MATERIAL, DWA_SSL_MATERIAL,\
    DWA_CLOUD_SECURITY_MATERIAL,CA_CLOUD_SECURITY_MATERIAL,MA_MATERIALS,MH_MATERIALS,MM_MATERIALS, EAS_MATERIALS


class CustomerType(models.Model):
    """1 = standard, 2 = test"""
    id = models.AutoField(primary_key=True, db_column='customer_type_id')
    name = models.CharField(unique=True, max_length=150)
    description = models.CharField(max_length=765)
    status = models.IntegerField()
    class Meta:
        db_table = 'customer_type'
        app_label = 'oui'
    def __unicode__(self):
        return self.name

CORP_CODES = {
    1:"United States",
    2:"Korea",
    3:"China",
    4:"Japan",
    5:"EMEA",
    6:"Singapore",
    7:"UK"
}

# map between Contract sales_org and OUI corp_codes
REGION_MAPS={
    1000:2, #KR
    2000:4, #JP
    3000:3, #CN
    4000:1, #US
    5000:5, #EMEA
    6000:6, #SG
    7000:7, #UK
}

REGION_MAPS_TXT={
    1000:'KR',
    2000:'JP',
    3000:'CN',
    4000:'US',
    5000:'EMEA',
    6000:'SG',
    7000:'UK',
}

class Customer(DatedModel):
    id = models.AutoField(primary_key=True, db_column='customer_id')
    customer_type = models.ForeignKey(CustomerType, db_column='CUSTOMER_TYPE_ID')
    name = models.CharField(unique=True, max_length=150)
    local_name = models.CharField(null=True, blank=True, max_length=150)
    english_name = models.CharField(null=True, blank=True, max_length=150)
    description = models.CharField(blank=True, max_length=765)
    vat_id = models.CharField(blank=True, max_length=60)
    status = models.BooleanField('Active', default=True)
    cdnetworks_customer = models.BooleanField("OCSP logging/data sync", help_text="Turn on this flag if the customer will access their data through OCSP. This will synchronize their data and send per hit logs to the OCSP portal for all their PADs",default=True)
    using_private_certs = models.BooleanField("Using private certificates", default=False)
    sales_rep = models.ForeignKey(AuthUser, db_column='sales_rep', related_name='rep_customers', limit_choices_to={'is_staff':True, 'is_active':True})
    sales_eng = models.ForeignKey(AuthUser, db_column='sales_eng', related_name='eng_customers', limit_choices_to={'is_staff':True, 'is_active':True})
    original_sales_rep = models.ForeignKey(AuthUser, db_column='original_sales_rep',related_name='original_rep_customers', limit_choices_to={'is_staff':True}, editable=False)
    original_sales_eng = models.ForeignKey(AuthUser, db_column='original_sales_eng', related_name='original_eng_customers', limit_choices_to={'is_staff':True}, editable=False)
    nonwildcard_hour = models.PositiveIntegerField('Non-Wildcard Flush Requests/Hour', default=60, help_text="The limit is per site", db_column="flushes_per_hour")
    items_per_request = models.PositiveIntegerField('Items/Request', default=1000, help_text="The limit is per site")
    all_per_hour = models.PositiveIntegerField('All Flush Requests Per Hour', default=1, help_text="The limit is per site")
    wildcards_per_hour = models.PositiveIntegerField('Wildcard Requests/Hour', default=10, help_text="The limit is per site")
    wildcards_per_request = models.PositiveIntegerField('Wildcards/Request', default=10, help_text="The limit is per site")
    default_rate = models.ForeignKey(BillRate, db_column='default_rate', default=1247) # 1247 is the 'trial/evaluation' rate
    prebill = models.BooleanField(default=False)
    address = models.ForeignKey(Address, null=True, blank=True)
    can_see_invoices = models.BooleanField(default=False)
    china_lic = models.CharField('China license number', blank=True, null=True, max_length=150)
    priority_note = models.CharField(blank=True, null=True, max_length=255)
    default_log_format = models.CharField(blank=True, null=True, max_length=1000)
    # if any choices are added and/or removed from here:
    # The get_short_corp_code function below will need to be changed accordingly
    corp_code = models.IntegerField(default=1, choices= ((key,value) for key, value in CORP_CODES.items()), db_column="cdnetworks_svc_area")

    customer_portal_flag = models.CharField(null=True, default='O', max_length=1, help_text="ocsp:O, aurora:A") # aurora:A, ocsp:O

    class Meta:
        ordering = ['name']
        db_table = 'customer'
        app_label = 'oui'

    class Admin:
        list_display = ('name','status','sales_rep')
        search_fields = ['name']
        list_filter = ('customer_type',)

    def __unicode__(self):
        return self.name

    def get_display_name(self):
        return self.local_name if self.local_name else self.name

    def get_default_event_operator_subscriber_emails(self):
        from ci.django_mailer.models import Subscriber, DEFAULT
        recipients = Subscriber.objects.filter(corp_code=self.corp_code, event_id=DEFAULT).values_list('email', flat=True)
        return list(recipients)

    def get_email_recipients(self, draft=None, site_id=None):
        recipients = []
        #recipients += [contact.get('email') for contact in self.get_sales_contact_list()]
        if self.customer_portal_flag == 'O':
            recipients += [self.sales_rep.email]
            customer_recipients = [u.user for u in self.userprofile_set.filter(get_notifications=True, user__is_active=True)]
            for user in customer_recipients:
                if draft and user.userprofile.restrict_pads and draft not in user.userprofile.draft_whitelist.all():
                    customer_recipients.remove(user)
            recipients += [u.email for u in customer_recipients]
        else:
            from ci.common.utils.site import get_pad_change_event_subscribers_from_aurora
            siteid = draft.get_site().pk if draft and draft.get_site() else site_id
            recipients += get_pad_change_event_subscribers_from_aurora(self.pk, siteid)
        return recipients

    def get_sales_contact_list(self):
        result_list = []
        from ci.common.utils.util_api import get_cs_contact_list
        contact_list = get_cs_contact_list()
        for contact in contact_list:
            if int(contact.get('ckey')) == self.pk and contact.get('contact_role') == 'Z1':
                result_list.append(contact)
        return result_list

    def high_priority(self):
        if self.priority_note:
            return self.priority_note
        elif self.site_set.filter(product__product_cd__in = [1115,1118]).count():
            return "Dynamic Acceleration"
        else:
            return ""

    def delete(self):
        address = self.address
        super(Customer, self).delete()
        delete_if_unused(address)

    def save(self, force_insert=False, force_update=False):
        if not self.address and self.invoice_set.count(): #we have a form cleanuo line for this but better be extra sure
            raise Exception("Cannot save a customer with invoices without an address")
        if not hasattr(self, 'original_sales_rep') or self.original_sales_rep == None:
            self.original_sales_rep = self.sales_rep
        if not hasattr(self, 'original_sales_eng') or self.original_sales_eng == None:
            self.original_sales_eng = self.sales_eng
        try:
            customer_obj = Customer.objects.get(pk=self.id)
            if customer_obj.cdnetworks_customer <> self.cdnetworks_customer:#only do a cascading PAD check if the CDNW flag was actually changed
                cdnw_flag_change =True
            else:
                cdnw_flag_change = False
        except:
            cdnw_flag_change =True
        if self.cdnetworks_customer and cdnw_flag_change: # do not touch pads using logging.
            for pad in self.site_set.exclude(request_log_msg_format__isnull=False):
                if not pad.cdnw:
                    pad.cdnw = True
                    pad.save()
        else:
            for pad in self.site_set.exclude(request_log_msg_format__isnull=False):
                if pad.cdnw:
                    pad.cdnw=False
                    pad.save()

        if self.id:
            prev_address = Customer.objects.get(pk=self.id).address
            super(Customer, self).save(force_insert, force_update)
            if prev_address != self.address:
                delete_if_unused(prev_address)
        else:
            super(Customer, self).save(force_insert, force_update)

    def rate_info(self, gb, mbps):
        """given values for GB transferred and mbps, return the applicable rate in the form
        (rate, is_gb, min), where rate is in dollars, is_gb is a boolean indicating
        whether the rate is based on the GB or mbps value, and min is the minimum value
        for the rate."""
        rate = self.default_rate
        return float(rate.price(gb, mbps)), rate.is_gb, float(rate.minimum)

    def traffic_now(self, epoch_offset=-2, gb=False):
        datestamp, epoch = timeutil.date_and_epoch(time.time()+epoch_offset*300)
        cursor = connection.cursor()
        cursor.execute("""select sum(e%d)
                            from traffic_bytes
                           where customer_site_id in
                         (select customer_site_id
                            from customer_site
                           where customer_id = %d)
                             and stat_time = '%s'""" % \
            (epoch, self.id, time.strftime('%Y-%m-%d %H:%M:%S', datestamp.timetuple())))
        val = cursor.fetchone()[0]
        val = float(val) if val else 0
        return val if gb else bytes_to_mbps(val)

    def mbps_yesterday(self, epoch_offset=-2):
        return self.traffic_now(epoch_offset-300)

    def mbps_last_week(self, epoch_offset=-2):
        return self.traffic_now(epoch_offset-2100)

    def gb_yesterday(self, epoch_offset=-2):
        return self.traffic_now(epoch_offset-300, gb=True)

    def mbps_stats(self, epoch_offset=-2):
        n = self.traffic_now(epoch_offset)
        y = self.mbps_yesterday(epoch_offset)
        w = self.mbps_last_week(epoch_offset)
        try:
            return {
                'now': n,
                'yesterday': y,
                'yesterday_pct_diff': (n-y)/float(y)*100,
                'last_week': w,
                'last_week_pct_diff': (n-w)/float(w)*100
            }
        except ZeroDivisionError:
            return {'now':n, 'yesterday':y, 'last_week':w}

    def traffic_stats(self):
        ret = {
            'mbps_yday': 0,
            'gb_yday': 0,
            'avg_gb': 0,
            'week_mbps': 0,
            'gb_delta': 0,
        }

        try:
            agg = TrafficAggregate.objects.get(pk=self.id)
        except ObjectDoesNotExist:
            return ret
        ret = {
            'mbps_yday': agg.day_mbps,
            'gb_yday': agg.day_gb,
            'avg_gb': agg.week_avg_gb,
            'week_mbps': agg.week_mbps,
            'gb_delta': agg.gb_delta,
        }
        return ret

    def get_contracts(self):
        products = Product.objects.filter(customer=self)
        return products

    def get_allowed_contracts(self, pRequest):
        if pRequest.session['aurora_restrict_items']:
            products = self.get_contracts().filter(cop_product_id__in=pRequest.session['aurora_restrict_items'])
        else:
            products = self.get_contracts()
        return products

    def get_active_contracts(self, material_no_list=[]):
        products = Product.objects.filter(customer=self,active=1)
        if material_no_list and len(material_no_list)> 0:
            products = products.filter(product_cd__in=material_no_list)
        return products

    def check_customer_has_self_product(self, material_no_list=[]):
        products = self.get_active_contracts(material_no_list)
        for product in products:
            if product.is_self_implementable():
                return True
        return False

    def has_request_implementation_product(self, material_no_list=[]):
        products = self.get_active_contracts(material_no_list)
        for product in products:
            if not product.is_self_implementable():
                return True
        return False

    def users(self):
        return AuthUser.objects.filter(userprofile__customer=self).order_by('username')

    def pending_drafts(self):
        return self.sitedraft_set.filter(approval_pending=True)

    def get_short_corp_code(self):
        short_codes = {
            1: "US",
            2: "KR",
            3: "CN",
            4: "JP",
            5: "EM",
            6: "SG",
            7: "UK"
        }
        return short_codes[self.corp_code]


    #def get_fqdn_count_per(self, flag_active=None, site_ids=[4, 8, 5, 6, 7, 3], per_type="product"):
    #site_ids = [] means all pad in customer
    def get_fqdn_count_per(self, flag_active=None, site_ids=[], per_type="product"):
        try:
            cursor = connection.cursor()
            if len(site_ids) > 0:
                str_site_ids = ','.join([str(site_id) for site_id in site_ids])
            else:
                site_ids = self.site_set.all().values_list('pk', flat=True)
                str_site_ids = ','.join([str(site_id) for site_id in site_ids])

            if flag_active in [1, 0]:
                str_active = " and status = %s "%flag_active
            else:
                str_active = ""

            if per_type == "product":
                str_group_by = "K.product_id"
            else:
                str_group_by = "K.customer_site_id"

            sql = """
                select %s,
                    sum(K.padcnt) padcnt, sum(K.aliascnt) aliascnt
                from
                (
                    select U.product_id, U.customer_site_id, 1 padcnt,
                        case when U.len_org = 0 then 0
                        else
                            case when U.len_org = U.len_ext then 1
                            else U.len_org - U.len_ext + 1
                            end
                        end aliascnt
                    from
                    (select product_id, customer_site_id,
                            LENGTH(pad_aliases) len_org ,
                            LENGTH(REPLACE(pad_aliases, '\n', '')) len_ext from customer_site
                                        where customer_site_id in (%s)
                                        %s
                                        ) U
                ) K
                group by %s;
                        """ %(str_group_by, str_site_ids, str_active, str_group_by)

            cursor.execute(sql)
            ret = cursor.fetchall()
            ret_dict = dict([ (k, {'padcnt':v, 'aliascnt':w}) for k, v, w in ret ])
        except Exception,e:
            ret_dict = {}
        finally:
            cursor.close()
            del cursor
        return ret_dict

class TrafficAggregate(models.Model):
    customer = models.OneToOneField(Customer, primary_key=True)
    day_gb = models.FloatField(default=0.00)
    day_mbps = models.FloatField(default=0.00)
    week_mbps = models.FloatField(default=0.00)
    week_avg_gb = models.FloatField(default=0.00)
    create_time = models.DateTimeField(editable=False, auto_now_add=True)
    modify_time = models.DateTimeField(editable=False, auto_now=True)
    class Meta:
        app_label="oui"
        db_table = "traffic_aggregates"
    def gb_delta(self):
        try:
            return ((self.day_gb-self.week_avg_gb)/self.week_avg_gb)*100
        except ZeroDivisionError:
            return 100.00 if self.day_gb > 0 else 0.00


class SSLKeystore(models.Model):
    keystore_id = models.AutoField(primary_key=True, db_column='keystore_id')
    customer = models.ForeignKey(Customer)
    domain = models.CharField(max_length=255, blank=True, null=True)
    cert_vendor = models.CharField(max_length=50, blank=True, null=True)
    start_date = models.DateTimeField(blank=True, null=True)
    expiration_date = models.DateTimeField(blank=True, null=True)
    notification_email = models.CharField(max_length=255, blank=True, null=True)
    upload_successful = models.BooleanField(default=False)
    self_signed_cert = models.BooleanField(default=False)
    ks_file_hash = models.CharField(max_length=32, null=True, blank=True, editable=False)
    auth_file_hash = models.CharField(max_length=32, null=True, blank=True, editable=False)
    create_time = models.DateTimeField(editable=False, auto_now_add=True)
    create_user = models.ForeignKey(AuthUser, db_column="create_user", editable=False)
    description = models.CharField(max_length=255, blank=True, null=True, unique=True)
    sni_group = models.ForeignKey(SNIGroup, db_column='sni_group_id', null=True, blank=True)
    algorithm = models.CharField(max_length=64, blank=True, null=True, default='')

    class Meta:
        app_label = "oui"
        db_table = "ssl_keystore"
        ordering = ['customer', 'domain', '-expiration_date']
        get_latest_by = "create_time"

    def __unicode__(self):
        pk = SSLKeystore.objects.filter(customer = self.customer, domain = self.domain).order_by('-create_time')[0].pk
        flag = False
        if pk == self.pk:
            flag = True
        return "%s%s: %s (%s)%s" % ("EXPIRED - " if self.expiration_date<datetime.datetime.now() else "",self.customer.name, self.domain, self.expiration_date.strftime("%m/%d/%Y"),"(---- Latest ----)" if flag else "")

    def is_expired(self):
        return self.expiration_date < datetime.datetime.now()

    def get_json(self):
        ret_json = {}
        for field in self._meta.fields:
            ret_json[field.name] = unicode(getattr(self, field.name))
        ret_json['sni_group_id'] = self.sni_group_id
        ret_json['_name'] = "%s (%s)" % (unicode(self), self.algorithm)

        return ret_json


class KeystoreDomains(models.Model):
    keystore = models.ForeignKey(SSLKeystore)
    domain = models.CharField(max_length=255, blank=True, null=True)
    class Meta:
        app_label='oui'
        db_table = 'keystore_domains'


class Product(DatedModel):
    product_id = models.AutoField(primary_key=True, db_column='product_id')
    customer = models.ForeignKey(Customer)
    name = models.CharField(max_length=100, blank=False, null=False)
    cop_product_id = models.CharField(max_length=17, unique=True)
    product_cd = models.IntegerField(blank=True, null=True, default=1028, help_text="Default value is 1028")
    active = models.BooleanField(default=True)
    default = models.BooleanField(default=False)
    allow_add_pad_flag = models.BooleanField(
        help_text="Allow Self Implementation", default=0)
    count_per_contract = models.PositiveIntegerField(blank=True, default=100, help_text="Limit of total number PAD")

    class Meta:
        app_label = "oui"
        db_table = "customer_product"
        get_latest_by = "product_id"

    def __unicode__(self):
        project_name = settings.SETTINGS_MODULE

        for p_name in ['cui', 'rapi', 'api']:
            if p_name in project_name:
                return self.get_customer_ui_name()
        return self.name

    def pretty_full_contract_no(self):
        temps = self.cop_product_id.split('-')
        return "%s-%s" % (int(temps[0]), int(temps[1]))

    def get_customer_ui_name(self, contract=None):
        try:
            status_txt = "expired" if not self.active else ''
            if contract is None:
                contract = self.fetch_cs_contract()
                if contract is None:
                    return "%s: %s (Request Implementation) %s" % (self.cop_product_id, self.get_material_type_txt(), status_txt)

            service_type_txt = contract.get('service_type_txt','') # China

            if self.is_self_implementable(contract):
                push_type= "Self Implementation"
            else:
                push_type = 'Request Implementation'

            return "%s: %s - %s (%s) %s" % (self.pretty_full_contract_no(),
                                            self.get_material_type_txt(),
                                            service_type_txt,
                                            push_type, status_txt)
        except Exception,e:
            return self.name

    def get_contract_no(self):
        return int(self.cop_product_id.split('-')[0])

    def get_item_no(self):
        return int(self.cop_product_id.split('-')[1])

    def get_material_type_txt(self,material_no=None):
        if material_no is None:
            material_no = self.product_cd
        if int(material_no) in CA_MATERIAL:
            return "CA"
        elif int(material_no) == DWA_MATERIAL:
            return "DWA"
        elif int(material_no) == CA_SSL_MATERIAL:
            return "CA SSL"
        elif int(material_no) == DWA_SSL_MATERIAL:
            return "DWA SSL"
        elif int(material_no) == DWA_CLOUD_SECURITY_MATERIAL:
            return "SAC"
        elif int(material_no) == CA_CLOUD_SECURITY_MATERIAL:
            return "SCA"
        elif int(material_no) in MA_MATERIALS:
            return "MA"
        elif int(material_no) in MH_MATERIALS:
            return "MH"
        elif int(material_no) in MM_MATERIALS:
            return "MM"
        elif int(material_no) in EAS_MATERIALS:
            return "EAS"
        else:
            return material_no

    def save(self, *args, **kwargs):
        #if i'm default make everyone else for my customer not default
        if self.default:
            other_defaults = Product.objects.filter(customer = self.customer).exclude(product_id = self.product_id)
            if other_defaults.count() > 0:
                for other_default in other_defaults:
                    other_default.default = False
                    other_default.save()
            #set all PADs without a product to this product
            from ci.common.models.site import Site #here to avoid circular imports...
            Site.objects.filter(customer=4,product__isnull=True).update(product=self)
        if self.create_time is None:
            self.create_time = datetime.datetime.now()
        super(Product, self).save(*args, **kwargs)
        if self.default:
            #set all PADs without a product to this product
            #import here to avoid circular imports...
            from ci.common.models.site import Site, SiteDraft
            Site.objects.filter(customer=4,product__isnull=True).update(product=self)
            SiteDraft.objects.filter(customer=4,product__isnull=True).update(product=self)

    def get_default_edge_service_for_production(self, contract=None):
        if contract is None:
            contract = self.fetch_cs_contract()
            if contract is None:
                return None

        material_no = int(contract.get('material_no',-1))
        service_type = contract.get('service_type','')
        sales_org = contract.get('sales_org','')
        customer_edges = CustomerProductEdge.objects.filter(product=self).filter(product__allow_add_pad_flag=1).\
            filter(cdn_service__stage_service=0, cdn_service__status=1)
        return self._get_default_edge_service(customer_edges,service_type,material_no, sales_org)

    def _get_default_edge_service(self, customer_edges, service_type=None, material_no=None, sales_org=None):
        from ci.common.models.cdn import Service
        if customer_edges.exists():
            return customer_edges[0].cdn_service
        else:
            try:
                if material_no in CA_MATERIAL:
                    if service_type.strip().upper() == 'R4': #global premium': #n3
                        return Service.objects.get(dns_prefix='n3', status=1)
                    elif service_type.strip().upper() == 'R3': #global standard': #n2
                        return Service.objects.get(dns_prefix='n2', status=1)
                    elif service_type.strip().upper() == 'R1': #global business': # n1
                        return Service.objects.get(dns_prefix='n1', status=1)
                    elif service_type.strip().upper() == '1': #local':
                        if sales_org == '1000': #KR : k1
                            return Service.objects.get(dns_prefix='k1', status=1)
                        elif sales_org == '2000': #JP: j4
                            return Service.objects.get(dns_prefix='j4', status=1)
                    else:
                        return None
                elif material_no == DWA_MATERIAL:
                    if service_type.strip().upper() == 'R4': #global premium': #n3
                        return Service.objects.get(dns_prefix='n3', status=1)
                    elif service_type.strip().upper() == 'R3': #global standard': #n2
                        return Service.objects.get(dns_prefix='n2', status=1)
                    elif service_type.strip().upper() == 'R1': #global business': # n1
                        return Service.objects.get(dns_prefix='n1', status=1)
                    else:
                        return None
                else:
                    return None
            except:
                return None

    def is_self_implementable(self, contract=None):
        """
        Refer following wike #3.2 ~#3.3
        https://wiki.cdnetworks.com/confluence/display/PRODUCTMARKETING/PRD+of+PAD+self-provisioning
        :param contract:
        :return:
        """
        try:
            if not self.active:
                return False

            if not self.is_self_implemetation_on():
                return False

            if contract is None:
                contract = self.fetch_cs_contract()
                if contract is None:
                    return False
                    #can not confirm contract validity, but customer user does not need see error

            material_no = int(contract.get('material_no',-1))
            service_type = contract.get('service_type','') # China
            unit = contract.get('unit','')

            if service_type.strip().upper() in ['R5','R7','R8']: # 'R5:china', 'R7:Global Standard + china','R8:Global premium + china'
                return False

            if not self.get_default_edge_service_for_production(contract):
                return False

            if material_no in CA_MATERIAL:
                return True
            elif material_no == CA_SSL_MATERIAL:
                if self.customer.using_private_certs:
                    return True
                else:
                    return False
            elif material_no == DWA_MATERIAL:
                return True
            elif material_no == DWA_SSL_MATERIAL:
                if self.customer.using_private_certs:
                    return True
                else:
                    return False
            else:
                return False
        except Exception,e:
            return False

    def is_ssl_contract(self):
        if self.product_cd in [CA_SSL_MATERIAL, DWA_SSL_MATERIAL]:
            return True
        else:
            return False

    def get_contract_region(self, contract=None):
        if contract is None:
            contract = self.fetch_cs_contract()
            if contract is None:
                return -1

        sales_org = int(contract.get('sales_org',-1))
        return REGION_MAPS.get(sales_org)

    def get_contract_region_txt(self, contract=None):
        if contract is None:
            contract = self.fetch_cs_contract()
            if contract is None:
                return 'undefined'

        sales_org = int(contract.get('sales_org',-1))
        return REGION_MAPS_TXT.get(sales_org)

    def get_service_type_txt(self, contract=None):
        if contract is None:
            contract = self.fetch_cs_contract()
            if contract is None:
                return ''
        return contract.get('service_type_txt','')

    def is_dwa_contract(self):
        return self.product_cd in DWA_MATERIALS

    def fetch_cs_contract(self):
        """
        return contract dictionary
        :return: {"material_no": "1028","service_type_txt": "Local","sales_org": "1000", "unit": "GB"}
        """
        from ci.common.utils.util_api import get_cs_contract_info
        try:
            cs_contracts = get_cs_contract_info()
            return cs_contracts.get(self.cop_product_id)
        except Exception,e:
            pass
        return None

    def is_self_implemetation_on(self):
        return self.allow_add_pad_flag

    def get_contract_info_name(self, contract=None):
        if contract is None:
            contract = self.fetch_cs_contract()
            if contract is None:
                return 'undefined'

        sales_org = int(contract.get('sales_org',-1))
        service_type = contract.get('service_type','')
        service_type_txt = contract.get('service_type_txt','') # China
        unit = contract.get('unit','')
        return "%s - %s(%s) - %s" % (REGION_MAPS_TXT.get(sales_org),service_type, service_type_txt,unit)

    def get_contract_info(self, cs_contract=None):
        contract_name = self.get_customer_ui_name(cs_contract)
        status = 'active' if self.active else 'expired'
        contract_info = {'contract_no': self.pretty_full_contract_no(),
                              'contract_name': contract_name,
                              'self_implementable': 1 if self.is_self_implementable(cs_contract) else 0,
                              'is_dwa': 1 if self.is_dwa_contract() else 0,
                              'service_category': self.get_material_type_txt(),
                              'is_ssl': 1 if self.is_ssl_contract() else 0,
                              'status':status}

        contract_info.update({'available_shield_locations':self.get_available_shield_locations(cs_contract)})
        return contract_info

    def get_related_contracts(self):
        from ci.common.utils.util_api import get_cs_contract_info
        try:
            result_list = []
            cs_contracts = get_cs_contract_info()
            mycontract =  cs_contracts.get(self.cop_product_id)
            item_id = mycontract.get('item_id')

            for key in cs_contracts.keys():
                cs_contract = cs_contracts.get(key)
                if item_id and item_id == cs_contract.get('parent_item_id'):
                    result_list.append({key:cs_contract})
        except Exception,e:
            pass
        return result_list


    def validate_shield_locations(self, shield_service_id):
        """
        validate product acl with shield service
        :param shield_service: shield_service pk to validate if the product has proper acl with the shield service
        :return:
        """
        matched = False
        shield_locations = self.get_available_shield_locations()
        for shield_location in shield_locations:
            location_id = shield_location.get('location_id')
            if location_id == int(shield_service_id):
                matched = True
                break
        return matched

    def get_available_shield_locations(self, contract=None):
        """
        get available shield locations for self provisioning api
        :param contract: dictionary info from prism api. provide it as a cache to avoid chatty call to prism api
        :return:
        """
        from ci.common.models.cache import ShieldedServiceBand
        shield_location = []
        if contract is None:
            contract = self.fetch_cs_contract()
            if contract is None:
                return shield_location  # return empty shield location

        if self.is_self_implementable(contract) and self.product_cd in DWA_MATERIALS:
            # exclude bands which has lower cache level
            cdn_service = self.get_default_edge_service_for_production(contract=contract)
            shielded_service_bands = ShieldedServiceBand.objects.values(
                'shielded_service', 'band__node__pop__cdnw_pop_id__name').filter(
                shielded_service__public_to_customer=1, shielded_service__service=cdn_service).order_by(
                'shielded_service', 'cache_level', 'order').distinct()

            temp_locations = []
            for service_band in shielded_service_bands:
                location_id = service_band.get('shielded_service')
                location_name = service_band.get('band__node__pop__cdnw_pop_id__name')
                location = location_name.split('-')

                if location_id not in temp_locations:
                    temp_locations.append(location_id)
                    shield_location.append({'location_id':location_id,
                                        'location_name':"%s, %s" % (location[2],location[3])})
        return shield_location


class CustomerProductEdge(models.Model):
    from ci.common.models.cdn import Service
    customer_product_edge = models.AutoField(primary_key=True, db_column='customer_product_edge')
    product = models.ForeignKey(Product)
    cdn_service = models.ForeignKey(Service, blank=True, null=True, verbose_name='Preset Edge Service')

    class Meta:
        app_label = 'oui'
        db_table = 'customer_product_edge'


from ci.common.models.cdn import Service


class FastmonCustomerPrefix(models.Model):
    id = models.AutoField(primary_key=True, db_column='id')
    customer = models.ForeignKey(Customer, db_column='customer_id')
    service = models.ForeignKey(Service, db_column='cdn_service_id')
    status = models.BooleanField(default=False)

    class Meta:
        app_label = "oui"
        db_table = "fastmon_customer_prefix"
        unique_together = ('customer', 'service')

