from django.db import models
from ci.common.models.common import DatedModel
import time

class DnsZone(DatedModel):
	id = models.AutoField(primary_key=True, db_column='dns_zone_record_id')
	domain_name = models.CharField(unique=True, max_length=255)
	ttl = models.IntegerField('TTL', default=86400)
	serial_number = models.IntegerField(help_text='This is set automatically. Any changes you make here will be ignored.', default=0)
	refresh = models.IntegerField(default=1200)
	retry = models.IntegerField(default=120)
	expire = models.IntegerField(default=86400)
	minimum = models.IntegerField(default=120)
	status = models.BooleanField('Active', default=True)
	dynamic_cache = models.IntegerField(choices=[(0,'Non Dynamic'), (1,'Dual use'), (2,'Dynamic use only')], default=0)
	class Meta:
		db_table = 'dns_zone_record'
		app_label = 'oui'
		ordering=['domain_name']
		verbose_name = 'DNS zone'
	def __unicode__(self):
		return self.domain_name
	def save(self, *args, **kwargs):
		"automatically update serial number"
		if not self.serial_number:
			self.serial_number = int('%s00' % time.strftime('%Y%m%d'))
		else:
			serial_str = str(self.serial_number)
			old_date, counter = serial_str[:-2], int(serial_str[-2:])
			today = time.strftime('%Y%m%d')
			if today == old_date:
				self.serial_number = int('%s%02d' % (today, counter + 1))
				if counter + 1 >= 100:
					raise Exception,'This zone has been updated too many times in one day -- cannot set serial number.'
			else:
				self.serial_number = int('%s00' % today)
		super(DnsZone, self).save(*args, **kwargs)

class DnsModel(DatedModel):
	zone = models.ForeignKey(DnsZone, db_column='dns_zone_record_id')
	name = models.CharField(max_length=255)
	ttl = models.IntegerField('TTL')
	status = models.BooleanField()
	class Meta:
		abstract = True
	def save(self, *args, **kwargs):
		self.name = self.name.strip()
		super(DnsModel, self).save(*args, **kwargs)
	
class ARecord(DnsModel):
	id = models.AutoField(primary_key=True, db_column='dns_a_record_id')
	address = models.IPAddressField(max_length=20)
	ptr_record = models.BooleanField('PTR Record', default=True)
	class Meta:
		db_table = 'dns_a_record'
		app_label = 'oui'
		ordering = ['name']
		verbose_name = 'A record'

class CnameRecord(DnsModel):
	id = models.AutoField(primary_key=True, db_column='dns_cname_record_id')
	cname = models.CharField(max_length=255)
	class Meta:
		db_table = 'dns_cname_record'
		app_label = 'oui'
		unique_together = ('name',)
		ordering = ['name']
		verbose_name = 'CNAME record'

class MxRecord(DnsModel):
	id = models.AutoField(primary_key=True, db_column='dns_mx_record_id')
	preference = models.IntegerField()
	class Meta:
		db_table = 'dns_mx_record'
		app_label = 'oui'
		ordering = ['preference']
		verbose_name = 'MX record'

class Dns_Ns_Record(DnsModel):
	"""this has a funny name so that the many-to-many relationship between 
	nodes and nameservers works (django guesses column names in the relation table
	based on model name)"""
	id = models.AutoField(primary_key=True, db_column='dns_ns_record_id')
	address = models.IPAddressField(max_length=20)
	class Meta:
		db_table = 'dns_ns_record'
		app_label = 'oui'
		ordering = ['name']
		verbose_name = 'NS record'
	def __unicode__(self):
		return self.name

class TxtRecord(DnsModel):
	id = models.AutoField(primary_key=True, db_column='dns_txt_record_id')
	value = models.CharField(max_length=255)
	class Meta:
		db_table = 'dns_txt_record'
		app_label = 'oui'
		ordering = ['name']
		verbose_name = 'TXT record'


CAA_FLAGs = ((i, i) for i in xrange(256))
CAA_TAGs = (
	('issue', 'Authorization Entry by Domain'),
	('issuewild', 'Authorization Entry by Wildcard Domain'),
	('iodef', 'Report incident by IODEF report '),
)


class Dns_Caa_Record(DnsModel):
	id = models.AutoField(primary_key=True, db_column='dns_caa_record_id')
	flag = models.PositiveSmallIntegerField(choices=CAA_FLAGs)
	tag = models.CharField(max_length=10, choices=CAA_TAGs)
	value = models.CharField(max_length=255, db_column='caa_value')
	class Meta:
		db_table = 'dns_caa_record'
		app_label = 'oui'
		ordering = ['name']
		verbose_name = 'CAA record'
