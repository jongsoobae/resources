from django.db import models
from ci.common.models.site import SiteDraft

class DraftPadCreator (models.Model):
	draft_pad_creator_id = models.AutoField(primary_key=True)
	site_cui_id = models.IntegerField()
	creator_id = models.CharField(max_length=255)

	class Meta:
		db_table = 'draft_pad_creator'
