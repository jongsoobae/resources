from django.db import models
from ci.common.models.common import DatedModel


def delete_if_unused(address):
	if (address and
	not address.customer_set.all()):
		address.delete()

class Country(models.Model):
	id = models.AutoField(primary_key=True, db_column='country_id')
	name = models.CharField(max_length=50)
	invoice_region = models.CharField(max_length=3) # FIXME this should be a foreign key
	class Meta:
		db_table = 'country'
		verbose_name_plural = 'countries'
		app_label = 'oui'
	def __unicode__(self):
		return self.name

class Region(models.Model):
	id = models.AutoField(primary_key=True, db_column='region_id')
	name = models.CharField(max_length=50)
	description = models.CharField(max_length=255)
	diameter = models.IntegerField(help_text='max latency (ms) from end to end')
	countries = models.ManyToManyField(Country, db_table='region_country')
	class Meta:
		ordering = ['name']
		db_table = 'region'
		app_label = 'oui'
	def __unicode__(self):
		return self.name
	def valid_pops(self):
		return self.pop_set.filter(importance__gt=-1, pop_type=1)
	def online_pops(self):
		return self.pop_set.filter(offline=False)
	def offline_pops(self):
		return self.pop_set.filter(offline=True)
	def mbps(self):
		return sum([p.mbps() for p in self.pop_set.all()])
	def rps(self):
		return sum([p.rps() for p in self.pop_set.all()])
	def ops(self):
		return sum([p.ops() for p in self.pop_set.all()])
	def node_count(self):
		from ci.common.models.cdn import Node
		pop_set = self.pop_set.filter(importance__gt=-1)
		node_set = Node.objects.filter(pop__in = pop_set)	
		return node_set.count()

	def offline_node_count(self):
		from ci.common.models.cdn import Node
		pop_set = self.pop_set.filter(importance__gt=-1)
		node_set = Node.objects.filter(pop__in = pop_set, offline=True, node_type__in=[1,3])
		return node_set.count()

class RegionState(models.Model):
	id = models.IntegerField(primary_key=True, db_column='region_state_id')
	country = models.ForeignKey(Country)
	name = models.CharField(unique=True, max_length=100)
	class Meta:
		db_table = 'region_state'
		app_label = 'oui'
	def is_none(self):
		return self.id == 0
	def __unicode__(self):
		if self.is_none():
			return 'None'
		else:
			return self.name

class Address(DatedModel):
	id = models.AutoField(primary_key=True, db_column='address_id')
	street_1 = models.CharField(max_length=50)
	street_2 = models.CharField(blank=True, max_length=50)
	street_3 = models.CharField(blank=True, max_length=50)
	city = models.CharField(max_length=50)
	zip_postal = models.CharField('ZIP/postal code', max_length=60)
	region_state = models.ForeignKey(RegionState)
	country = models.ForeignKey(Country)
	class Meta:
		db_table = 'address'
		verbose_name_plural = 'addresses'
		app_label = 'oui'
	def __unicode__(self):
		return '%s, %s, %s' % (self.street_1, self.city, self.country)
	def full_display(self):
		s = '%s\n' % self.street_1
		if self.street_2:
			s += '%s\n' % self.street_2
		if self.street_3:
			s += '%s\n' % self.street_3
		s += self.city
		if not self.region_state.is_none():
			s += ', %s' % self.region_state.name
		if self.zip_postal:
			s += ', %s' % self.zip_postal
		s += '\n%s' % self.country.name
		return s

