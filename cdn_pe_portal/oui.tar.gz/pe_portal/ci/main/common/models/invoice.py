from decimal import Decimal
from datetime import date, datetime, time
from django.db import models, connection
import calendar
from ci.common.utils.timeutil import date2dt, previous_month, next_month
from ci.common.models.billing import BillRate
from ci.common.models.customer import Customer
from ci.common.models.site import Site
from ci.common.utils.mathutil import convert_currency
from django.conf import settings


class TrafficHistory(models.Model):
	customer = models.ForeignKey(Customer)
	site = models.ForeignKey(Site, db_column='customer_site_id', null=True)
	month = models.DateTimeField()
	min_mbps = models.FloatField()
	max_mbps = models.FloatField()
	mbps_95p = models.FloatField()
	gbytes = models.FloatField()
	class Meta:
		db_table = 'traffic_history'
		verbose_name_plural = 'traffic histories'
		app_label = 'oui'
	def __unicode__(self):
		return '%s, %s, %s' % (self.customer, self.site, self.month)


class RateCharge(object):
	"""
	The charge for one BillRate for one Invoice
	"""
	def __init__(self, rate, site_volumes, mbps_95p=0):
		"""
		@param rate:			A BillRate instance
		@param site_volumes:	A list of tuples, [(Site instance, traffic volume for Site), ...]
								volume is in gbytes or mbps_95p, depending on rate.is_gb
		@param mbps_95p:		95th-percentile mbps billed for all Sites at this rate
		                        (if not rate.is_gb)
		"""
		self.rate			= rate
		self.site_volumes	= site_volumes
		self.mbps_95p		= mbps_95p
	
	def gbytes(self):
		"""
		@return:	Total GB billed at this rate
		"""
		return sum(i[1] for i in self.site_volumes) if self.rate.is_gb else 0
	
	def traffic_volume(self):
		"""
		Return the GB for this month billed at this rate, if this is a GB rate,
		else 0.  Same for 95th-percentile mbps:  either the volume billed at
		this rate this month if this is a 95th-percentile mbps rate, else 0.
		@return:	(gbytes, mbps_95p)
		"""
		return (
			self.gbytes() if self.rate.is_gb else 0,
			self.mbps_95p if not self.rate.is_gb else 0
		)
	
	def price(self):
		"""
		@return:	A Decimal, the price per unit (per GB or per 95th-p mbps) in
					the rate's currency (euros, dollars, or whatever)
		"""
		return self.rate.price(
			*self.traffic_volume()
		) / Decimal(str(self.rate.currency.dollar_equiv))
	
	def level(self):
		"""
		@return:	Applicable BillRateLevel
		"""
		return self.rate.level(*self.traffic_volume())
	
	def charge(self):
		"""
		@return:	A Decimal, total charge for all Sites billed at this BillRate
					this month, in the rate's currency (euros, dollars, or
					whatever)
		"""
		return self.price() * max(
			self.rate.minimum,
			Decimal(str(self.gbytes() if self.rate.is_gb else self.mbps_95p))
		)
	
	def __unicode__(self):
		return 'RateCharge(%s, %s)' % (repr(self.rate), repr(self.site_volumes))


class LazyProperty(object):
	"""
	Mark a property as not-yet-calculated.
	
	Adapted from http://aspn.activestate.com/ASPN/Cookbook/Python/Recipe/363602
	recipe "Lazy property evaluation", by Scott David Daniels
	
	>>> class LazyPropertyExample():
	...     def _calc_lazy_properties(self, attrname):
	...             print '_calc_lazy_properties()'
	...             self._prop = 'prop_value'
	...     
	...     prop = LazyProperty('_prop')
	... 
	>>> l = LazyPropertyExample()
	>>> l.prop
	_calc_lazy_properties()
	'prop_value'
	>>> l.prop
	'prop_value'
	>>> LazyProperty.reset_lazy_properties(l)
	>>> l.prop
	_calc_lazy_properties()
	'prop_value'
	"""
	CALCULATING = 'CALCULATING'
	def __init__(self, attrname):
		self.attrname   = attrname
	
	def __get__(self, obj, _=None):
		status = getattr(obj, '_calculated_lazy_properties', False)
		assert status != LazyProperty.CALCULATING,\
			"%s tried to access lazy property '%s' inside _calc_lazy_properties()" % (
			obj, self.attrname
		)
		
		if not status:
			obj._calculated_lazy_properties = LazyProperty.CALCULATING
			try:
				obj._calc_lazy_properties(self.attrname)
			finally:
				obj._calculated_lazy_properties = True
		
		assert self.attrname in obj.__dict__, "%s._calc_lazy_properties() did not calculate property %s" % (
			repr(obj), repr(self.attrname)
		)
		return getattr(obj, self.attrname)
	
	@staticmethod
	def reset_lazy_properties(obj):
		try:
			delattr(obj, '_calculated_lazy_properties')
		except AttributeError:
			# reset_lazy_properties() was called before _calc_lazy_properties()
			pass
	


class Invoice(models.Model):
	id = models.CharField(primary_key=True, max_length=30, db_column='invoice_id')
	customer = models.ForeignKey(Customer, db_column='customer_id')
	month = models.DateTimeField()
	rate = models.ForeignKey(BillRate, db_column='rate_id')
	prebill = models.BooleanField()
	published = models.BooleanField(default=False)
	published_date = models.DateTimeField(null=True)
	official_id = models.CharField(blank=True, max_length=8)
	def shortmonth(self):
		return self.month.strftime('%b %y')
	shortmonth.short_description = 'month'
	class Meta:
		db_table = 'invoice'
		ordering = ['-month','customer']
		app_label = 'oui'
	def __unicode__(self):
		return '%s (%s)' % (self.id, ('unpublished',self.official_id)[self.official_id!=''])
	def title(self):
		days_in_month = calendar.monthrange(self.month.year, self.month.month)[1]
		return 'Invoice for %s (%s 1-%s)' % (
			self.month.strftime('%B %Y'), self.month.strftime('%B'), days_in_month
		)
	
	def make_id(self):
		return '%06d%02d%02d' % (self.customer.id, self.month.year-2000, self.month.month)
	
	def save(self, *args, **kwargs):
		if not self.id:
			self.id = self.make_id()
		super(Invoice, self).save(*args, **kwargs)
	
	def adjustment_total(self):
		"""The total effect (positive, negative, zero) of all adjustments to this invoice,
		assumed to be in self.rate.currency.  Make sure _new_charge is already calculated"""
		return sum([
			self._new_charge * Decimal('.01') * sum(
				[a.amount for a in self.invoice_adjustment_set.filter(is_percentage=True)]
			),
			sum(
				[a.amount for a in self.invoice_adjustment_set.filter(is_percentage=False)]
			)
		])
	
	def adjustments_string(self):
		"""A human-readable string describing all adjustments to this invoice"""
		return ', '.join(
			'%s%s%s (%s)' % (
				self.rate.currency.html_symbol if not ia.is_percentage else '',
				ia.amount,
				'%' if ia.is_percentage else '',
				ia.description
			)
			for ia in self.invoice_adjustment_set.order_by('id')
		)
	
	def _get_mbps_95p(self, site, month):
		"""
		@param site:		A Site instance
		@param month:		A datetime
		@return:			The 95th-percentile mbps, or 0
		"""
		try:
			return TrafficHistory.objects.get(customer=self.customer, month=month, site=site).mbps_95p
		except TrafficHistory.DoesNotExist:
			return 0
	
	def _rate_charges(self, month, prebill):
		"""
		For each BillRate that applies to this Invoice, map the BillRate to the
		Sites it applies to and calculate the total charge for all Sites at this
		BillRate
		@param month:   The month for which to charge
		@param prebill: If True, only consider charges for invoices with prebilling enabled
		@return:		A list of RateCharge instances, ordered by rate description (alpha)
		"""
		from ci.common.utils.traffic import get_grouped_stats
		rv = {}
		
		def rate_key(rate, keys={}):
			"""
			Make sure BillRates can be used as hash keys, by always returning
			the same instance for a given BillRate id
			"""
			return keys.setdefault(rate.id, rate)
		
		if month == self.month:
			invoice = self
		else:
			invoices = Invoice.objects.filter(customer=self.customer, month=month)
			if prebill: invoices = invoices.filter(prebill=True)
			if not invoices.count():
				# No previous Invoice for this customer, empty return value
				return []
			assert invoices.count() == 1
			invoice = invoices[0]
		
		assert invoice
		
		# For rates that use the 95th-percentile mbps, we have to get the
		# 95th percentile mbps for all sites with this rate.
		# map: rate-> [site, ...]
		mbps_rates2sites = {}
		
		# Calculate prices for Sites priced by the GB.  Store 95th-percentile mbps
		# rates and sites for later
		for site in self._sites:
			try:
				rate = rate_key(site.site_rate_set.get(month=month).rate)
			except SiteRateMonth.DoesNotExist:
				rate = rate_key(invoice.rate)
			
			# Save the site->rate mapping for clients' use
			if month == self.month: self._site_id2rate[site.id] = rate
			
			if rate.is_gb:
				try:
					gbytes = TrafficHistory.objects.get(customer=self.customer, month=month, site=site).gbytes
				except TrafficHistory.DoesNotExist:
					gbytes = 0
				
				# Price in customer's currency
				rate_charge = rv.setdefault(rate, RateCharge(rate, []))
				rate_charge.site_volumes.append((site, gbytes))
			else:
				# The rate is for 95th-percentile mbps
				mbps_rates2sites.setdefault(rate, [])
				mbps_rates2sites[rate].append(site)
		
		# Now sum up prices for the 95th-percentile mbps rates.  Optimized case:
		# one rate applies to all
		if len(mbps_rates2sites) == 1 and not rv:
			rate, sites = mbps_rates2sites.items()[0]
			try:
				mbps_95p = TrafficHistory.objects.get(
					customer=self.customer, month=month, site__isnull=True
				).mbps_95p
			except TrafficHistory.DoesNotExist:
				# No stats for the customer
				mbps_95p = 0
			
			return [RateCharge(rate, [(site, self._get_mbps_95p(site, month)) for site in sites], mbps_95p)]
		else:
			for rate, sites in mbps_rates2sites.items():
				assert not rate.is_gb
				# Collect traffic volumes for these sites, just to display them --
				# the charge is calculated from the mbps_95p for the sites in aggregate
				site_volumes = [
					(site, self._get_mbps_95p(site, month))
					for site in sites
				]
				# Optimized case: this mbps rate applies to only one site
				if len(sites) == 1:
					mbps_95p = site_volumes[0][1]
				else:
					# Note:  this could be expensive if there are lots of sites,
					# you might consider caching this calculation in the DB.  But
					# then you have to clear the cache when changing rates!
					mbps_95p = get_grouped_stats(
						sites,
						date2dt(month),
						date2dt(next_month(month))
					)[2]
				
				assert rate not in rv
				rv[rate] = RateCharge(rate, site_volumes, mbps_95p)
		
		return sorted(
			rv.values(),
			lambda rate_charge_0, rate_charge_1: cmp(
				rate_charge_0.rate.description,
				rate_charge_1.rate.description
			)
		)
	
	def _raw_charge(self, rate_charges):
		"""
		Pretax pre-adjustment charge for a month
		@param rate_charges:	The return value of _rate_charges()
		@return: 				The total charge, a Decimal, in self.rate.currency
		"""
		return Decimal(str(
			sum(
				convert_currency(
					rc.rate.currency.dollar_equiv, self.rate.currency.dollar_equiv, float(rc.charge())
				) for rc in rate_charges
			)
		))
	
	def __init__(self, *args, **kwargs):
		"""To minimize the complexity of the views, pre-calculate all charges, taxes,
		   and everything in between"""
		models.Model.__init__(self, *args, **kwargs)
		self._lazy_properties_calculated = False
		
		# map: Site id -> BillRate that applies for this Invoice
		self._site_id2rate = {}
	
	sites = LazyProperty('_sites')
	old_rate_charges = LazyProperty('_old_rate_charges')
	new_rate_charges = LazyProperty('_new_rate_charges')
	active_rate = LazyProperty('_active_rate')
	active_price = LazyProperty('_active_price')
	new_charge = LazyProperty('_new_charge')
	pretax = LazyProperty('_pretax')
	old_charge = LazyProperty('_old_charge')
	is_french = LazyProperty('_is_french')
	is_intl = LazyProperty('_is_intl')
	tax_percent = LazyProperty('_tax_percent')
	tax_amount = LazyProperty('_tax_amount')
	grand_total = LazyProperty('_grand_total')
	rates = LazyProperty('_rates')
	site_id2rate = LazyProperty('_site_id2rate')
	active_levels = LazyProperty('_active_levels')
	def _calc_lazy_properties(self, attrname):
		"""
		To prevent unnecessary calculation, don't figure out all the billing for
		this invoice unless asked
		"""
		self._lazy_properties_calculated = True
		current_sites = [site for site in self.customer.site_set.order_by('pad')]
		
		# this includes sites that were later switched to a different customer
		self._sites = current_sites + \
			[h.site for h in TrafficHistory.objects.filter(month=self.month, customer=self.customer)
				if h.site and h.site.id not in [s.id for s in current_sites]]
				
		self._old_rate_charges 	= self._rate_charges(previous_month(self.month), prebill=True)
		self._new_rate_charges 	= self._rate_charges(self.month, prebill=False)
		
		# [(rate, active_level), ...] for active levels this month
		self._active_levels = [
			(rate_charge.rate, rate_charge.level())
			for rate_charge in self._new_rate_charges
		]
		
		if len(self._new_rate_charges) == 1:
			active_rate_charge 	= self._new_rate_charges[0]
			self._active_rate 	= active_rate_charge.rate
			self._active_price 	= active_rate_charge.price()
		else:
			self._active_rate	= self._active_price = None
		
		self._new_charge = self._raw_charge(self._new_rate_charges)
		self._pretax = self._new_charge + self.adjustment_total()
		
		# if you're wondering why there is a reference to February 2008 below:
		# there was a loophole where if you turned off prebilling for a customer, the next invoice would not 
		# subtract the prebill fee that had been charged in the last month, causing us to overcharge.
		# this had to be fixed, but without affecting old invoices, hence the date check.
		# see OUI-193.
		self._old_charge = None
		if self.prebill or self.month > datetime(2008, 2, 1):
			# customer is pre-billed for the subsequent month's fees based on the traffic from the prior month
			self._old_charge = self._raw_charge(self._old_rate_charges)
			self._pretax -= self._old_charge
		if self.prebill:
			self._pretax += self._new_charge
		
		self._is_french   = str(self.customer.address.country).lower() == 'france'
		self._is_intl     = str(self.customer.address.country).lower() not in ('united states', 'canada')
		self._tax_percent = Decimal("19.6") if self._is_french else 0
		self._tax_amount  = self._pretax * (self._tax_percent / Decimal(100))
		self._grand_total = self._pretax + self._tax_amount
		self._rates		  = [rc.rate for rc in self._new_rate_charges]
	
	def rate_for_site(self, site_id):
		"""
		@param site_id:	A Site id
		@return:		The BillRate instance that applied to the Site for this
						Invoice id, or None
		"""
		return self.site_id2rate.get(int(site_id))
	
	def set_rate_for_site_and_save(self, site, rate):
		"""
		Set the BillRate that applies to a Site for this month.  You should also
		set the Site's default_rate so it will apply to future months, but that's
		left up to you.  This method's updates are saved to the DB immediately.
		@param site:	A Site
		@param rate:	A BillRate
		"""
		assert not self.published
		try:
			# If a special rate has already been applied
			site_rate = site.site_rate_set.get(month=self.month)
			site_rate.rate=rate
			site_rate.save()
		except SiteRateMonth.DoesNotExist:
			site.site_rate_set.create(month=self.month, rate=rate)
		
		LazyProperty.reset_lazy_properties(self)
	
	def set_active_rate_and_save(self, rate):
		"""
		Sets all Sites' rates in this Invoice to rate.  You should also
		set the Site's default_rate so it will apply to future months, but that's
		left up to you.  This method's updates are saved to the DB immediately.
		@param rate:	A BillRate
		"""
		assert not self.published
		self.rate = rate
		self.save()
		
		SiteRateMonth.objects.filter(site__customer=self.customer, month=self.month).delete()
		for site in self.customer.site_set.exclude(default_rate=self.rate):
			site.site_rate_set.create(rate=rate, month=self.month)
		
		LazyProperty.reset_lazy_properties(self)
	
	def publish(self):
		"""
		Set the official id by combining the region ID, and the count of
		Invoices in the region.  Update InvoiceCount model for this region.
		Preserve the invoice's rate by copying it and archiving it.
		"""
		if self.published: raise Exception("Attempt to republish invoice %s" % self)
		# We must create a unique invoice ID that is a concatentation of this
		# invoice's region and the count of invoices in the region.  To ensure
		# uniqueness, lock the invoice_id_counter table between reading it and
		# updating.
		assert 'django.middleware.transaction.TransactionMiddleware' in settings.MIDDLEWARE_CLASSES
		region = self.customer.address.country.invoice_region
		
		cursor = connection.cursor()
		cursor.execute('select count from invoice_id_counter where region = %s for update', [region]);
		results = cursor.fetchall()
		if results:
			# There's already a row in invoice_id_counter for this region
			count = results[0][0] + 1
			cursor.execute('update invoice_id_counter set count=count+1 where region = %s', [region])
		else:
			count = 1
			cursor.execute('insert into invoice_id_counter(count, region) values(1, %s)', [region])
		
		self.preserve_rates()
		self.official_id = "%s%05d" % (region, count)
		self.published_date = date.today()
		self.published = True
		LazyProperty.reset_lazy_properties(self)
	
	def preserve_rates(self):
		"""preserve the invoice's rates.
		first search for a rate that is exactly like the current one.
		criteria: same description, with " (preserved <timestamp>)", and same tiers.
		if it exists, use it; otherwise create one.
		"""
		def find_archived_copy(rate):
			assert not rate.archived
			
			for archived_rate in BillRate.objects.filter(
				currency	= rate.currency,
				minimum 	= rate.minimum,
				is_gb 		= rate.is_gb,
				archived	= True
			):
				# equals() checks for deeper equality than can be expressed
				# in a simple SQL query
				if archived_rate.equals(rate):
					return archived_rate
			
			# Not found; make one
			return rate.make_archived_copy()
		
		# Preserve this Invoice's rate (Note:  if all Sites have custom rates,
		# the Invoice's rate isn't applied, but it's still used to determine
		# the currency for the Invoice)
		if not self.rate.archived:
			self.rate = find_archived_copy(self.rate)
		
		for site_rate in SiteRateMonth.objects.filter(
			site__customer=self.customer,
			month=self.month,
			rate__archived=False
		):
			site_rate.rate = find_archived_copy(site_rate.rate)
			site_rate.save()
	


class InvoiceCount(models.Model):
	region = models.CharField(primary_key=True, max_length=9)
	count = models.IntegerField()
	class Meta:
		db_table = 'invoice_id_counter'
		app_label = 'oui'
	def __unicode__(self):
		return self.region


class SiteRateMonth(models.Model):
	"""
	Optional per-site rate for each site in each invoice (if none exists, use
	the Site's default rate; if that's null, use the Invoice's rate)
	"""
	site = models.ForeignKey(Site, related_name='site_rate_set')
	rate = models.ForeignKey(BillRate, related_name='site_rate_set')
	month = models.DateTimeField()
	class Meta:
		db_table = 'site_rate_month'
		app_label = 'oui'
	def __unicode__(self):
		return 'Rate for site %s and month %s: %s' % (
			self.site, self.month, self.rate
		)
