from django.db import models
from ci.common.models.site import Site
from ci.common.models.cdn import Node

# legacy models for conversion

class Site_Group(models.Model):
	id = models.AutoField(primary_key=True, db_column='site_group_id')
	name = models.CharField(max_length=150)
	site = models.ManyToManyField(Site)
	class Meta:
		app_label = 'oui'
		db_table = 'site_group'

class Cache_Instance(models.Model):
	id = models.AutoField(primary_key=True, db_column='cache_instance_id')
	site_group = models.ForeignKey(Site_Group)
	class Meta:
		app_label = 'oui'
		db_table = 'cache_instance'
	def fragments(self):
		return self.cachefragment_set.select_related()
	def mainPop(self):
		pops = {}
		for frag in self.fragments():
			pop = frag.node.pop
			pops[pop] = 1 + (pops[pop] if pops.has_key(pop) else 0)
		largestPop = None
		largestCount = 0
		for pop, count in pops.iteritems():
			if count > largestCount:
				largestCount = count
				largestPop = pop
		return largestPop
	def name(self):
		frags = sorted (self.fragments(), key = lambda f: f.node.id)
		return self.mainPop().shortname() + ' ' + str(len(frags))

class CacheFragment(models.Model):
	cache_instance = models.ForeignKey(Cache_Instance)
	bucket_min = models.IntegerField()
	bucket_max = models.IntegerField()
	node = models.ForeignKey(Node)
	class Meta:
		app_label = 'oui'
		db_table = 'cache_fragment'

class Cache_Group(models.Model):
	id = models.AutoField(primary_key=True, db_column='cache_group_id')
	name = models.CharField(max_length=150)
	site_group = models.ForeignKey(Site_Group)
	instance = models.ManyToManyField(Cache_Instance)
	class Meta:
		app_label = 'oui'
		db_table = 'cache_group'
	def userGroups(self):
		"return cache groups that have me as shield"
		return map (lambda r: r.cache_group, CacheGroupMaster.objects.filter(master_cache_group = self))
	def masterGroups(self):
		"return cache groups that I use as shield"
		return map (lambda r: r.master_cache_group, CacheGroupMaster.objects.filter(cache_group = self))

class CacheGroupMaster(models.Model):
	cache_group = models.ForeignKey(Cache_Group, related_name='masters')
	master_cache_group = models.ForeignKey(Cache_Group, related_name='dependents')
	n_closest = models.IntegerField()
	maxcc = models.IntegerField()
	class Meta:
		app_label = 'oui'
		db_table = 'cache_group_master'
