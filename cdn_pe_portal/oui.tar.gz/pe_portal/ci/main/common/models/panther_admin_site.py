from django.contrib.admin.sites import AdminSite

class PantherAdminSite(AdminSite):
    def has_permission(self, request):
        """
        Returns True if the given HttpRequest has permission to view
        *at least one* page in the admin site.
        """
        return request.user.is_active



panther_site = PantherAdminSite()
