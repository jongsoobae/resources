from django.db import models
from datetime import datetime, timedelta

class SyncJob(models.Model):
    job_id = models.AutoField(primary_key=True, db_column='id')
    name = models.CharField(max_length=50)
    key  = models.CharField(max_length=255)
    type  = models.CharField(max_length=50)
    flag  = models.IntegerField()
    cnt = models.IntegerField()
    content  = models.TextField()
    complete_time = models.DateTimeField()
    create_time = models.DateTimeField(default=datetime.now())

    class Meta:
        db_table = 'sync_job'

class CdnwPop(models.Model):
    id = models.IntegerField(primary_key=True, db_column='cdnw_pop_id')
    code = models.CharField(max_length=255)
    ngp_code = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    status = models.IntegerField()
    description = models.TextField()

    class Meta:
        db_table = 'cdnw_pop'

    def __unicode__(self):
        return self.name

