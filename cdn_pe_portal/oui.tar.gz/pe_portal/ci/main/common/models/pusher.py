from datetime import timedelta
from django.db import models, connection
from django.utils import simplejson
from ci.common.models.cdn import Pop, Node
from ci.common.models.site import Site, SiteDraft

PUSH_SYSINFO = 'SYSINFO'
PUSH_DNS = 'DNS'
PUSH_SITESNG = 'SITESNG'
PUSH_SYSLOAD = 'SLL'
PUSH_POPNETWORK = 'PNM'
PUSH_CACHECONF = 'CACHECONF'
PUSH_CONTDIST = 'CONTDIST'
PUSH_PING = 'PING'
PUSH_TRACE = 'TRACE'
PUSH_CRUNNER = 'CRUN'
PUSH_FLUSH = 'CMP'
PUSH_PING_LOG = 'PLOG'
PUSH_NMON_LOG = 'NLOG'
PUSH_HTTP_LOG = 'HLOG'
PUSH_DNS_LOG = 'DLOG'

PUSH_NAMES = {
    PUSH_SYSINFO: 'System Info',
    PUSH_DNS: 'DNS',
    PUSH_SITESNG: 'Http Sites',
    PUSH_SYSLOAD: 'System Load Limit',
    PUSH_POPNETWORK: 'pop network monitor',
    PUSH_CACHECONF: 'Cache Config',
    PUSH_CONTDIST: 'Content Distribution',
    PUSH_TRACE: 'traceroute',
    PUSH_PING: 'ping',
    PUSH_CRUNNER: 'command runner',
    PUSH_FLUSH: 'Cache Flush',
    PUSH_PING_LOG: 'ping log level',
    PUSH_NMON_LOG: 'nmon log level',
    PUSH_HTTP_LOG: 'http log level',
    PUSH_DNS_LOG: 'dns log level'
}

# these show up on the oui push page
PUSH_VISIBLE = [
    # PUSH_CACHECONF,
    PUSH_CONTDIST,
    PUSH_DNS,
    PUSH_SITESNG,
    # PUSH_SYSINFO,
    PUSH_SYSLOAD,
]

FLUSH_TYPES = {
    1: 'all (soft)',
    2: 'items',
    3: 'wildcard (soft)',
    4: 'all (hard)',
    5: 'wildcard (hard)',
    6: 'cancel all',
    7: 'cancel wildcard'
}

PUSH_TEST_STATUS = {
    0: 'Untested',
    1: 'Failed',
    2: 'Passed',
    3: 'Skipped',
    4: 'Ignored'
}

BE_CONFIG_GROUP = (
    ("CONTENT_DISTRIBUTION", PUSH_CONTDIST),
    ("HTTP_SITES", PUSH_SITESNG),
    ("SYSTEM_LOAD_LIMIT", PUSH_SYSLOAD),
    ("DNS", PUSH_DNS),
)

BE_CONFIG_TYPE = (
    "CFGT",
    "CFG",
)
BE_CONFIG_PHASE = (
    "TEST",
    "MNT"
)


def push_types():
    """get the list of push types that exist in the db"""
    return Push.objects.distinct().values_list('pushtype', flat=True).order_by()


def reverse_config_group_to_push_name():
    _BE_CONFIG_GROUP_TO_PUSH_TYPE = {}
    try:
        for i in BE_CONFIG_GROUP:
            _BE_CONFIG_GROUP_TO_PUSH_TYPE.update({i[0]: i[1]})
    except (Exception, ):
        pass
    return _BE_CONFIG_GROUP_TO_PUSH_TYPE


BE_CONFIG_GROUP_TO_PUSH_TYPE = reverse_config_group_to_push_name()


class Push(models.Model):
    pushtype = models.CharField(max_length=20, db_column='type')
    message = models.TextField()
    description = models.TextField()
    targets_todo = models.TextField(null=True)
    targets_done = models.TextField(null=True)
    tries = models.IntegerField(db_column="retries")
    status = models.IntegerField()
    test_status = models.IntegerField()
    last_retry_time = models.DateTimeField()
    create_time = models.DateTimeField()
    create_user = models.CharField(max_length=75)

    class Meta:
        db_table = 'push_directive'
        ordering = ('-create_time',)
        app_label = 'oui'

    def save(self):
        # 6/26/2008: this method will actually never be called in the current state of the code,
        # because push_directive rows are created only by the java pusher. but eric wrote it for
        # the future time when django makes pushes.
        created = False
        if not self.id:
            created = True
        super(Push, self).save()
        if created:
            # if push reason not recorded record it
            entries = ChangeLogEntry.objects.filter(pushID__isnull=True, pushType=self.pushtype)
            for entry in entries:
                entry.pushID = self.id
                entry.pushDescription = self.description
                entry.pushUser = self.create_user
            # if push is from same user as created and in 30mins...
            entries = ChangeLogEntry.objects.filter(pushType=self.pushtype,
                                                    time__gt=self.create_time - timedelta(minutes=30)).exclude(
                pushUser=self.user)
            for entry in entries:
                entry.pushID = self.id
                entry.pushDescription = self.description
                entry.pushUser = self.create_user

    def __unicode__(self):
        return '%s: %s @ %s' % (self.pushtype, self.description, self.create_time)

    def get_targets_notdone(self):
        if self.targets_todo is None:
            return []
        ids = list(
            set(self.targets_todo.split(',')).difference(self.targets_done.split(',') if self.targets_done else []))
        nodes = Node.objects.in_bulk(ids).values()
        nodes.sort(key=lambda n: n.name())
        return nodes

    def get_targets_todo_count(self):
        if self.targets_todo is None:
            return 0
        ids = self.targets_todo.strip().split(',')
        return len(ids)

    def get_targets_done_count(self):
        if self.targets_done is None:
            return 0
        ids = self.targets_done.strip().split(',')
        return len(ids)

    def get_targets_todo(self):
        if self.targets_todo is None:
            return []
        ids = self.targets_todo.strip().split(',')
        nodes = Node.objects.in_bulk(ids).values()
        nodes.sort(key=lambda n: n.name())
        return nodes

    def get_targets_done(self):
        if self.targets_done is None:
            return []
        ids = self.targets_done.strip().split(',')
        nodes = Node.objects.in_bulk(ids).values()
        nodes.sort(key=lambda n: n.name())
        return nodes

    def pushtype_name(self):
        return PUSH_NAMES.get(self.pushtype, self.pushtype)

    def crunner_history(self):
        cursor = connection.cursor()
        cursor.execute("""select c.id from command_runner_history c, push_directive p
            where p.type = 'CRUN' and p.message like concat('%%', c.command) order by p.create_time desc limit 1""")
        cid = cursor.fetchone()[0]
        return CrunnerHistory.objects.get(pk=cid)

    def change_set(self):
        """find the changes that were put into effect by this push."""
        entries = ChangeLogEntry.objects.filter(pushID=self.id)
        return entries


class PushTest(models.Model):
    push_type = models.CharField(max_length=20)
    node = models.ForeignKey(Node)

    class Meta:
        db_table = 'push_test_node'
        app_label = 'oui'
        verbose_name = "Push test node"

    def __unicode__(self):
        return '%s: %s' % (self.push_type, self.node)


class PurgeRequestJson(models.Model):
    content = models.TextField()

    class Meta:
        db_table = 'purge_request_json'
        app_label = 'oui'


class PurgeRequestJsonTest(models.Model):
    content = models.TextField()

    class Meta:
        db_table = 'purge_request_json_test'
        app_label = 'oui'


class ConfigRequestJson(models.Model):
    content = models.TextField()

    class Meta:
        db_table = 'config_request_json'
        app_label = 'oui'

    def save(self, *args, **kwargs):
        super(ConfigRequestJson, self).save(*args, **kwargs)

        json = simplejson.loads(self.content)
        if 'CONTDIST' in json['types']:
            push_pk = self.pk
            from ci.common.models.prism_sync import SyncJob
            sync_job = SyncJob(name='push', type='modify', key=str(push_pk), flag=0, cnt=0, content=self.content)
            sync_job.save()


class ConfigRequestJsonTest(models.Model):
    content = models.TextField()

    class Meta:
        db_table = 'config_request_json_test'
        app_label = 'oui'


class PushRequestJson(models.Model):
    content = models.TextField()

    class Meta:
        db_table = 'push_request_json'
        app_label = 'oui'


class PushRequestJsonTest(models.Model):
    content = models.TextField()

    class Meta:
        db_table = 'push_request_json_test'
        app_label = 'oui'


class NodeUpdateFlush(models.Model):
    content = models.TextField()
    description = models.TextField()
    create_time = models.DateTimeField()
    site = models.ForeignKey(Site, null=True)

    class Meta:
        get_latest_by = 'id'
        db_table = 'node_update_flush'
        app_label = 'oui'

    def __init__(self, *args, **kwargs):
        super(NodeUpdateFlush, self).__init__(*args, **kwargs)
        self.decoded_content = simplejson.loads(self.content, 'ISO-8859-15')

    def siteFromContent(self):
        return Site.objects.get(pk=self.decoded_content['site'])

    def values(self):
        return self.decoded_content['values']

    def type(self):
        return FLUSH_TYPES.get(int(self.decoded_content['type']), 'bad/unknown type')


class NodeUpdateFlushStatus(models.Model):
    node = models.OneToOneField(Node)
    update = models.IntegerField(db_column='update_id')
    update_time = models.DateTimeField()

    class Meta:
        db_table = 'node_update_flush_status'
        app_label = 'oui'


class PusherToNodeUpdateFlush(models.Model):
    push_request_id = models.IntegerField(primary_key=True)
    repository = models.ForeignKey(NodeUpdateFlush, null=True)
    site = models.ForeignKey(Site)
    type = models.IntegerField(choices=FLUSH_TYPES.items())
    items = models.IntegerField()
    submitted_time = models.DateTimeField()
    create_user = models.CharField(max_length=75)
    create_time = models.DateTimeField()

    class Meta:
        get_latest_by = 'push_request_id'
        db_table = 'pusher_flush_xref'
        app_label = 'oui'

    def type_string(self):
        return FLUSH_TYPES.get(int(self.type), 'bad/unknown type')

    def create_user_for_customer(self):
        str_user = self.create_user.split('(via:')[0].strip()
        return "%s" % str_user if str_user.rfind('aggregated.by.purge_openapi') < 0 else 'Aggregated purge request'


class CrunnerHistory(models.Model):
    command = models.TextField()
    create_time = models.DateTimeField()
    create_user = models.CharField(max_length=75)

    class Meta:
        db_table = 'command_runner_history'
        app_label = 'oui'


class ChangeLogEntry(models.Model):
    time = models.DateTimeField()  # time of change
    user = models.CharField(max_length=75)  # user who made change
    pushType = models.CharField(max_length=20)  # change command pusher type
    popId = models.ForeignKey(Pop, null=True, blank=True, db_column='popId')
    actionDescription = models.CharField(max_length=50)
    pushUser = models.CharField(max_length=75)
    pushDescription = models.TextField(default='NOT PUSHED YET')
    pushID = models.PositiveIntegerField()

    class Meta:
        db_table = 'change_log_2'
        ordering = ['-time']
        app_label = 'oui'

    def __unicode__(self):
        return '%s @ %s' % (self.pushDescription, self.time)


# def q_command_types(command_types):  # command class objects
#     filterCommandQs = map(lambda type: Q(doCode__contains = type.__name__), command_types)
#     return reduce(lambda q1,q2: q1 | q2, filterCommandQs)
#


class ConfigPushRequestHistory(models.Model):
    config_push_request_history = models.AutoField(primary_key=True, db_column="config_push_request_history_id")
    push_level = models.PositiveSmallIntegerField(null=True)
    config_group = models.CharField(help_text="BE_CONFIG Config group name", max_length=100, )
    config_type = models.CharField(help_text="BE_CONFIG Config type name", max_length=100, )
    config_phase = models.CharField(help_text="BE_CONFIG Config phase name", max_length=100, )
    phase = models.PositiveSmallIntegerField(null=True, db_column="phase_id")
    site_draft = models.ForeignKey(SiteDraft, null=True, db_column="site_cui_id")
    action = models.PositiveIntegerField(null=True, db_column="action_id")
    request_user = models.CharField(max_length=255, null=True)
    desc = models.CharField(max_length=1024, blank=True, null=True, db_column='push_desc')
    create_time = models.DateTimeField(auto_now_add=True)
    update_time = models.DateTimeField(null=True)
    history_revision = models.PositiveIntegerField()

    class Meta:
        db_table = 'config_push_request_history'
        ordering = ['-config_push_request_history']
        app_label = 'oui'

    def __unicode__(self):
        return '%s-%s (requested by %s at %s)' % (self.config_group,
                                                  self.config_type,
                                                  self.request_user,
                                                  self.create_time)

    def get_phase_display(self):
        return PUSH_NAMES[BE_CONFIG_GROUP_TO_PUSH_TYPE[self.config_group]]

    def get_config_phase(self):
        return "%s/%s/%s" % (self.config_group, self.config_type, self.config_phase)

    def get_site_cui_id(self):
        site_draft = self.get_site_draft()
        try:
            if site_draft:
                return site_draft.pk
            else:
                if self.site_draft_id:
                    return "%s (deleted)" % self.site_draft_id
                else:
                    return ''
        except:
            return ''

    def get_push_level(self):
        if self.config_type == 'CFG':
            return 'Production'
        elif self.config_type == 'CFGT':
            return 'Staging'
        else:
            return "Undefined"

    def get_site_draft(self):
        try:
            site_draft = self.site_draft
        except:
            site_draft = None
        return site_draft


    def _get_related_push_result_items(self, push_history_items={}):
        from ci.common.utils.pusher import ConfigApi, SpectrumApi
        result_dicts = {}
        try:
            spectrum_api = SpectrumApi()
            action_id_list = spectrum_api._get_related_action_ids([self.action])

            if not push_history_items:
                config_api = ConfigApi()
                result = config_api._config_api_push_progress(action_id_list)
                push_history_items = simplejson.loads(result)

            for action_id in action_id_list:
                result_dicts.update({action_id: push_history_items.get(str(action_id))})

            return result_dicts
        except Exception,e:
            return result_dicts

    def get_promoted_global_push_result_item(self, result_dicts={}):
        try:
            if not result_dicts:
                result_dicts = self._get_related_push_result_items()

            for key in result_dicts.keys():
                if result_dicts[key].get('phase') == 'GLOBAL':
                    return result_dicts[key]
            return {}
        except Exception,e:
            return {}

    def get_initial_push_result_item(self, result_dicts={}):
        try:
            if not result_dicts:
                result_dicts = self._get_related_push_result_items()
            for key in result_dicts.keys():
                if result_dicts[key].get('phase') == 'TEST':
                    return result_dicts[key]

            return {}
        except Exception,e:
            return {}

    def get_push_completion_rate(self, push_result_item):
        """
        https://wiki.cdnetworks.com/confluence/display/engbackend/Config+API+-+List+of+API
        if draft is not none, filter host with pad's edge/shield node
        :param draft:
        :param push_result_item:
                {"parent_joint_action_id": 142426,
                "status": "Completed",
                "group": "HTTP_SITES",
                "status_msg": "auto promoted from phase TEST",
                "down": [],
                "phase": "GLOBAL",
                "ok": [],
                "type": "CFGT",
                "revision": 6}
        :return:
        """
        from ci.common.utils.api.site import short_hostname
        try:
            if push_result_item is None:
                return '0.00', [], []

            if self.site_draft is not None:
                ngp_host_list = self.site_draft.get_related_ngp_hostname_list(push_result_item.get('type'))
                push_result_item.update({'pad_related_hosts': ngp_host_list})
                ok_hosts = push_result_item.get('ok')
                ok_hosts = [short_hostname(ok_host) for ok_host in ok_hosts]
                down_hosts = push_result_item.get('down')
                down_hosts = [short_hostname(down_host) for down_host in down_hosts]
                total_hosts = ok_hosts + down_hosts

                ngp_total_hosts = list(set(ngp_host_list).intersection(total_hosts))
                if len(ngp_total_hosts) == 0:
                    return '0.00', [], []
                else:
                    ngp_ok_hosts = list(set(ngp_host_list).intersection(ok_hosts))
                    completion_rate = float(len(ngp_ok_hosts))/float(len(ngp_total_hosts)) * 100.0
                    return "%.2f" % completion_rate, ngp_ok_hosts, ngp_total_hosts
            else: #whole host count
                ok_list = push_result_item.get('ok')
                down_list = push_result_item.get('down')
                total_list = ok_list + down_list
                ok_count = len(ok_list)
                down_count = len(down_list)
                if ok_count == 0 and down_count ==0:
                    return '0.00', [], []
                else:
                    return "%.2f" % float(ok_count)/float(ok_count + down_count) * 100.0, ok_list, total_list
        except Exception,e:
            return '0.0', [], []

    def get_valid_push_result_item(self, result_dicts={}):
        """
        https://wiki.cdnetworks.com/confluence/display/engbackend/Config+API+-+List+of+API
        :param result_dicts:
        :return:
        """
        import json
        try:
            error_message = ''
            push_result_item = {}
            if not result_dicts:
                result_dicts = self._get_related_push_result_items()
            for key in sorted(result_dicts.keys()):
                push_result_item = result_dicts[key]
                status = push_result_item.get('status',None)
                raw_message = push_result_item.get('status_msg',None)
                if raw_message is None:
                    # not promoted to global phase yet or waiting be_config doing its work
                    return push_result_item
                else:
                    try:
                        msg_dict = json.loads(raw_message)
                        # msg_dict = self.get_error_message_dict_from_file()
                        error_list = msg_dict.get('pad_id_list', None)
                        error_message = self.get_pad_error_message(error_list)
                    except:
                        pass
                if len(error_message) > 0 or status == 'Failed':
                    return push_result_item
            return push_result_item

        except Exception,e:
            return {}

    def get_pad_error_message(self, error_list, push_level=None):
        from ci.common.utils.api.site import get_customized_error_message
        result = ''
        error_code = ''
        error_params = []
        if push_level is None:
            push_level = self.get_push_level()
        site_draft = self.get_site_draft()
        if site_draft:
            site_id = site_draft.get_pad_id(push_level)
            for error in error_list:
                if site_id == int(error.keys()[0]):
                    error_code = error.get(str(site_id)).get('errno')
                    error_params = error.get(str(site_id)).get('extra')
                    break
            if len(error_code) > 0:
                error_message = get_customized_error_message(error_code, error_params)
                result = "%s: %s" % (error_code, error_message)
        else:
            pass
        return result

    def get_parsed_status_message(self, result_dicts={}):
        """
        return  parsed message, customized display message
        even if not in failure status, return status msg at ngp config_dist_action
        even in action status completed, but some pads might have configuration error
        https://wiki.cdnetworks.com/confluence/pages/viewpage.action?pageId=140739006
        :param push_result_item:
        :return:
        """
        import json
        error_code = 0
        parsed_msg = ''
        customized_display_msg = ''
        push_level = self.get_push_level()
        if not result_dicts:
            result_dicts = self._get_related_push_result_items()
        for key in result_dicts.keys():
            push_result_item = result_dicts[key]
            status = push_result_item.get('status',None)
            raw_message = push_result_item.get('status_msg',None)
            if raw_message is None:
                #not promoted to global phase yet or waiting be_config doing its work
                return parsed_msg, customized_display_msg
            else:
                try:
                    msg_dict = json.loads(raw_message)
                    error_list = msg_dict.get('pad_id_list', None)
                    if error_list: # << error_code in ['1']  : 'code' value at wiki page was overided by be_config. instead check if 'pad_id_list' exist.
                        if len(error_list) > 0:
                            parsed_msg = msg_dict.get('message')
                            customized_display_msg = self.get_pad_error_message(error_list, push_level)
                            if len(customized_display_msg) > 0:
                                break
                        else: #general failure
                            parsed_msg = msg_dict.get('message')
                            if status == 'Failed':
                                customized_display_msg = 'Failed to push to %s. Please contact support center.' % push_level
                                if len(customized_display_msg) > 0:
                                    break
                            else:
                                customized_display_msg = ''

                except Exception,e: # unsupported dictionary format
                    parsed_msg = raw_message
                    if status == 'Failed':
                        customized_display_msg = 'Failed to push to %s for uncertain reason. Please contact support center.' % push_level
                    else:
                        customized_display_msg = ''
        return parsed_msg, customized_display_msg

    def get_error_message_dict_from_file(self):
        """
        get test json file from fixtures
        :return:
        """
        from ci.common.utils.site import get_error_example_from_file
        return get_error_example_from_file("output_sites.json")
