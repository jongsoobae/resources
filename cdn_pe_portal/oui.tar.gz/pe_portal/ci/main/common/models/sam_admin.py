from django.db import models
from ci.common.models import DatedModel, Customer

item_type_condition = ('1', 'Condition')
item_type_action = ('2', 'Action')
item_type_choices = (item_type_condition, item_type_action)

field_type_string = ('1', 'String')  # c_regex field is used by this type.
field_type_select = ('2', 'Select')
field_type_multi_select = ('3', 'Multi Select')
field_type_string_regex = ('4', 'String(regex)')  # only add validation logic.
field_type_number = ('5', 'Number')  # it need min value, max value.
field_type_boolean = ('6', 'Boolean')
field_type_text = ('7', 'Text')
# field_type not select, need comma separated value.
field_type_choices = (
    field_type_string, field_type_select, field_type_multi_select,
    field_type_string_regex, field_type_number, field_type_boolean, field_type_text)

field_is_base_condition = ('1', 'Base Condition')
field_is_base_action = ('2', 'Base Action')
field_is_not_base = ('0', 'n')
field_is_base_choices = (field_is_base_condition, field_is_base_action, field_is_not_base)

field_is_zero = ('0', 'false')
field_is_not_zero = ('1', 'true')
field_is_zero_choices = (field_is_zero, field_is_not_zero)

req_not_required = ('0', 'No')
req_required = ('1', 'Yes')
req_choices = (req_not_required, req_required)

boolean_false = ('0', 'No')
boolean_true = ('1', 'Yes')
boolean_choices = (boolean_false, boolean_true)


"""""""""""""""""""""""""""""""""""""""""""""
    Managers
"""""""""""""""""""""""""""""""""""""""""""""


class SamConditionManager(models.Manager):
    def get_query_set(self):
        return super(SamConditionManager, self).get_query_set().filter(rule_type=item_type_condition[0])


class SamActionManager(models.Manager):
    def get_query_set(self):
        return super(SamActionManager, self).get_query_set().filter(rule_type=item_type_action[0])


class SamFieldManager(models.Manager):
    def get_query_set(self):
        return super(SamFieldManager, self).get_query_set().filter(is_base=field_is_not_base[0])


class SamBaseConditionFieldManager(models.Manager):
    def get_query_set(self):
        return super(SamBaseConditionFieldManager, self).get_query_set().filter(is_base=field_is_base_condition[0])


class SamBaseActionFieldManager(models.Manager):
    def get_query_set(self):
        return super(SamBaseActionFieldManager, self).get_query_set().filter(is_base=field_is_base_action[0])


class SamBaseFieldManager(models.Manager):
    def get_query_set(self):
        return super(SamBaseFieldManager, self).get_query_set().filter(
            is_base__in=[field_is_base_action[0], field_is_base_condition[0]])


"""""""""""""""""""""""""""""""""""""""""""""
    Abstract Models
"""""""""""""""""""""""""""""""""""""""""""""


class AbstractSamRuleItem(DatedModel):
    id = models.AutoField(primary_key=True, db_column='id')
    rule_type = models.CharField(default='1', choices=item_type_choices, max_length=1)
    rule_item_str_id = models.CharField(blank=False, null=False, unique=True, max_length=64)
    rule_item_title = models.CharField(blank=False, null=False, max_length=128)
    description = models.CharField(blank=True, null=True, unique=True, max_length=256)
    expose_for_customer = models.CharField(default='1', choices=field_is_zero_choices, max_length=1)
    ignored_fields = models.ManyToManyField('SamRuleItemBaseField', through='SamRuleIgnoreField')
    create_user = ''
    modify_user = ''

    class Meta:
        abstract = True

    def add_ignored(self, ignored_keys, current=[]):
        if not isinstance(ignored_keys, list):
            return
        item_id = self.pk
        if len(current) < 1:
            current = SamRuleIgnoreField.objects.filter(rule_item=item_id).values_list('rule_item_field_id', flat=True)

        for item_field_id in list(set(ignored_keys)-set(current)):
            SamRuleIgnoreField(rule_item_field_id=item_field_id, rule_item_id=self.pk).save()

    def remove_ignored(self, ignored_keys, current=[]):
        if not isinstance(ignored_keys, list):
            return
        item_id = self.pk
        if len(current) < 1:
            current = SamRuleIgnoreField.objects.filter(rule_item=item_id).values_list('rule_item_field_id', flat=True)

        for item_field_id in list(set(current)-set(ignored_keys)):
            SamRuleIgnoreField.objects.filter(rule_item_field=item_field_id, rule_item=self.pk).delete()

    def get_base_fields(self):
        ignored_base_fields = self.samruleignorefield_set.all().values_list('rule_item_field_id', flat=True)
        if self.rule_type == field_is_base_condition[0]:
            base_item_field = SamRuleItemBaseConditionField
        elif self.rule_type == field_is_base_action[0]:
            base_item_field = SamRuleItemBaseActionField
        else:
            base_item_field = SamRuleItemBaseField

        return base_item_field.objects.all().exclude(
            pk__in=ignored_base_fields
        )

    def to_json(self, is_detail=False):
        restricted = []
        restricted_key = []
        if isinstance(self, SamRuleCondition):
            restricted_data = self.restricted_actions.all()
            restricted = [
                {
                    'id': restrict.pk,
                    'rule_item_title': restrict.rule_item_title,
                    'rule_item_str_id': restrict.rule_item_str_id
                }
                for restrict in restricted_data
            ]
            restricted_key = [restrict.pk for restrict in restricted_data]
        elif isinstance(self, SamRuleAction):
            restricted_data = self.restricted_conditions.all()
            restricted = [
                {
                    'id': restrict.pk,
                    'rule_item_title': restrict.rule_item_title,
                    'rule_item_str_id': restrict.rule_item_str_id
                }
                for restrict in restricted_data
            ]
            restricted_key = [restrict.pk for restrict in restricted_data]

        ret_json = {
            'id': self.pk,
            'rule_type': self.rule_type,
            'rule_type_str': self.get_rule_type_display(),
            'rule_item_str_id': self.rule_item_str_id,
            'rule_item_title': self.rule_item_title,
            'expose_for_customer': self.expose_for_customer,
            'description': self.description,
            'create_user': self.create_user,
            'modify_user': self.modify_user,
            'create_time': str(self.create_time),
            'modify_time': str(self.modify_time)
        }

        if is_detail:
            rule_item = SamRuleItem.objects.get(pk=self.pk)
            ignored_data = rule_item.ignored_fields.all()
            ret_json.update(
                {
                    'ignored_item_field': [
                        ignore.to_json()
                        for ignore in ignored_data
                    ],
                    'ignored_key': [ignore.pk for ignore in ignored_data],
                    'restricted_item': restricted,
                    'restricted_key': restricted_key}
            )
        return ret_json


class AbstractSamRuleItemField(DatedModel):
    id = models.AutoField(primary_key=True, db_column='id')
    field_type = models.CharField(default='1', choices=field_type_choices, max_length=45)
    is_base = models.CharField(default='1', choices=field_is_base_choices)
    field_name = models.CharField(max_length=45)
    default = models.CharField(db_column='default_value', max_length=45)
    display_name = models.CharField(max_length=45)
    c_regex = models.CharField(max_length=45)
    min_value = models.IntegerField()
    max_value = models.IntegerField()
    description = models.CharField(max_length=256)
    data = models.CharField(max_length=2000)
    required = models.CharField(default='0', choices=req_choices, max_length=1)
    use_null = models.CharField(default='1', choices=boolean_choices, max_length=1)
    order_number = models.PositiveSmallIntegerField(default=0)

    class Meta:
        abstract = True

    def to_json(self):
        return {
            'id': self.pk,
            'field_type': self.field_type,
            'field_type_str': self.get_field_type_display(),
            'is_base': self.is_base,
            'is_base_str': self.get_is_base_display(),
            'field_name': self.field_name,
            'default': self.default,
            'display_name': self.display_name,
            'c_regex': self.c_regex,
            'min_value': self.min_value,
            'max_value': self.max_value,
            'description': self.description,
            'data': self.data,
            'required': self.required,
            'use_null': self.use_null,
            'req_str': self.get_required_display(),
            'create_user': self.create_user,
            'modify_user': self.modify_user,
            'create_time': str(self.create_time),
            'modify_time': str(self.modify_time)
        }


"""""""""""""""""""""""""""""""""""""""""""""
    SamRuleItem
"""""""""""""""""""""""""""""""""""""""""""""


class SamRuleItem(AbstractSamRuleItem):
    objects = models.Manager()
    condition_objects = SamConditionManager()
    action_objects = SamActionManager()

    class Meta:
        app_label = 'oui'
        db_table = 'sam_rule_item'

    def __init__(self, *args, **kwargs):
        super(SamRuleItem, self).__init__(*args, **kwargs)


class SamRuleCondition(AbstractSamRuleItem):
    objects = SamConditionManager()
    restricted_actions = models.ManyToManyField('SamRuleAction', through='SamRuleAdminRestrict')
    # ignored_fields = models.ManyToManyField('SamRuleItemBaseField', through='SamRuleIgnoreField')

    class Meta:
        app_label = 'oui'
        db_table = 'sam_rule_item'

    def __init__(self, *args, **kwargs):
        super(SamRuleCondition, self).__init__(*args, **kwargs)

    def add_restrict(self, restricted_keys, current=[]):
        if not isinstance(restricted_keys, list):
            return
        condition_id = self.pk
        if len(current) < 1:
            current = SamRuleAdminRestrict.objects.filter(condition=condition_id).values_list('action_id', flat=True)

        for action_id in list(set(restricted_keys)-set(current)):
            SamRuleAdminRestrict(action_id=action_id, condition=self).save()

    def remove_restrict(self, restricted_keys, current=[]):
        if not isinstance(restricted_keys, list):
            return
        condition_id = self.pk
        if len(current) < 1:
            current = SamRuleAdminRestrict.objects.filter(condition=condition_id).values_list('action_id', flat=True)

        for action_id in list(set(current)-set(restricted_keys)):
            SamRuleAdminRestrict.objects.filter(action=action_id, condition=self).delete()


class SamRuleAction(AbstractSamRuleItem):
    objects = SamActionManager()
    restricted_conditions = models.ManyToManyField('SamRuleCondition', through='SamRuleAdminRestrict')
    # ignored_fields = models.ManyToManyField('SamRuleItemBaseField', through='SamRuleIgnoreField')

    class Meta:
        app_label = 'oui'
        db_table = 'sam_rule_item'

    def __init__(self, *args, **kwargs):
        super(SamRuleAction, self).__init__(*args, **kwargs)

    def add_restrict(self, restricted_keys, current=[]):
        if not restricted_keys or not isinstance(restricted_keys, list):
            return
        action_id = self.pk
        if len(current) < 1:
            current = SamRuleAdminRestrict.objects.filter(action=action_id).values_list('condition_id', flat=True)
        for condition_id in list(set(restricted_keys)-set(current)):
            SamRuleAdminRestrict(action_id=action_id, condition_id=condition_id).save()

    def remove_restrict(self, restricted_keys, current=[]):
        if not restricted_keys or not isinstance(restricted_keys, list):
            return
        action_id = self.pk
        if len(current) < 1:
            current = SamRuleAdminRestrict.objects.filter(action=action_id).values_list('condition_id', flat=True)
        for condition_id in list(set(current)-set(restricted_keys)):
            SamRuleAdminRestrict.objects.filter(action=action_id, condition=condition_id).delete()


"""""""""""""""""""""""""""""""""""""""""""""
    SamRuleItemField
"""""""""""""""""""""""""""""""""""""""""""""


class SamRuleItemField(AbstractSamRuleItemField):
    objects = SamFieldManager()
    rule_item = models.ForeignKey(SamRuleItem, db_column='rule_item_pk')

    class Meta:
        app_label = 'oui'
        db_table = 'sam_rule_item_field'

    def __init__(self, *args, **kwargs):
        super(SamRuleItemField, self).__init__(*args, **kwargs)

    def to_json(self, is_detail=False):
        json_dict = super(SamRuleItemField, self).to_json()
        try:
            json_dict.update({'rule_item_id': self.rule_item.pk})
            if is_detail:
                json_dict.update({'rule_item': self.rule_item.to_json()})
        except SamRuleItem.DoesNotExist:
            pass
        return json_dict

    def save(self, *args, **kwargs):
        self.is_base = field_is_not_base[0]
        super(SamRuleItemField, self).save()


class SamRuleItemBaseField(AbstractSamRuleItemField):
    objects = SamBaseFieldManager()
    # ignored_rule_item = models.ManyToManyField(SamRuleItem, through='SamRuleIgnoreField')

    class Meta:
        app_label = 'oui'
        db_table = 'sam_rule_item_field'

    def __init__(self, *args, **kwargs):
        super(SamRuleItemBaseField, self).__init__(*args, **kwargs)


class SamRuleItemBaseConditionField(AbstractSamRuleItemField):
    objects = SamBaseConditionFieldManager()

    class Meta:
        app_label = 'oui'
        db_table = 'sam_rule_item_field'

    def save(self, *args, **kwargs):
        self.is_base = field_is_base_condition[0]
        super(SamRuleItemBaseConditionField, self).save()


class SamRuleItemBaseActionField(AbstractSamRuleItemField):
    objects = SamBaseActionFieldManager()

    class Meta:
        app_label = 'oui'
        db_table = 'sam_rule_item_field'

    def save(self, *args, **kwargs):
        self.is_base = field_is_base_action[0]
        super(SamRuleItemBaseActionField, self).save()


"""""""""""""""""""""""""""""""""""""""""""""
    Interim Models
"""""""""""""""""""""""""""""""""""""""""""""


class SamRuleAdminRestrict(models.Model):
    id = models.AutoField(primary_key=True, db_column='restrict_id')
    condition = models.ForeignKey(SamRuleCondition, db_column='condition_id')
    action = models.ForeignKey(SamRuleAction, db_column='action_id')

    class Meta:
        app_label = 'oui'
        db_table = 'sam_rule_admin_restrict'
        unique_together = (('condition_id', 'action_id'),)


class SamRuleIgnoreField(models.Model):
    id = models.AutoField(primary_key=True, db_column='id')
    rule_item = models.ForeignKey('SamRuleItem', db_column='rule_item_pk')
    #  condition_item = models.ForeignKey('SamRuleCondition', db_column='rule_item_pk')
    #  action_item = models.ForeignKey('SamRuleAction', db_column='rule_item_pk')
    rule_item_field = models.ForeignKey('SamRuleItemBaseField', db_column='rule_item_field_pk')

    class Meta:
        app_label = 'oui'
        db_table = 'sam_rule_item_ignore_rule_item_field'


class CustomerControlSam(models.Model):
    id = models.AutoField(primary_key=True)
    customer = models.ForeignKey(Customer, db_column='customer_id')
    sam_rule_item = models.ForeignKey(SamRuleItem, db_column='sam_rule_item_id')

    class Meta:
        app_label = 'oui'
        db_table = 'customer_control_sam'
