# -*- coding: utf-8 -*-
import base64
import json
import re
from urlparse import urlparse
from datetime import datetime, timedelta
from hashlib import md5
from _mysql_exceptions import OperationalError
from django.core.cache import cache
from django.conf import settings
from django import forms
from django.db import models, connection
from django.db.models import Q, Count
from django.utils import simplejson
from django.contrib.auth.models import User as AuthUser
from django.core.validators import RegexValidator
from ci.common.models.common import DatedModel, DatedHistoryModel, get_request
from ci.common.models.customer import Customer, Product, CustomerProductEdge
from ci.common.models.billing import BillRate
from ci.common.models.dns import DnsZone
from ci.common.utils.fields import RegexTextField
from ci.common.utils.json_load_ordered import json_load_ordered
from ci.common.utils.util_api import get_db_operation_error_message
from ci.common.utils.misc import list_contains
from ci.constants import SSL_STAGING_EDGE_CLEANUP_INTERVAL, NO_REPLY, SUPPORT_CENTER
from ci.django_mailer.models import DEFAULT,REQUEST_PAD,CANCEL_REQUEST_PAD,APPROVE_REQUEST_PAD, \
    DENY_REQUEST_PAD,PUBLISH_PAD_TO_PRODUCTION,RECOVER_PAD_TO_PRODUCTION
from ci.common.utils.json_load_ordered import json_load_ordered

BLANK_CHOICE = [("", "---------")]
DEPLOY_STATUS_NEW = "New"
DEPLOY_STATUS_CHANGED = "Changed"
DEPLOY_STATUS_DISABLED = "Disabled"
DEPLOY_STATUS_WAITING_REQ = "Waiting Request Implementation"
DEPLOY_STATUS_SELF_PUSHING_STAGE = "Pushing to Staging"
DEPLOY_STATUS_SELF_FAIL_STAGE = "Failed to Staging"
DEPLOY_STATUS_SELF_STAGE = "On Staging"
DEPLOY_STATUS_SELF_PUSHING_PROD = "Pushing to Production"
DEPLOY_STATUS_SELF_FAIL_PROD = "Failed to Production"
DEPLOY_STATUS_SELF_PROD = "On Production"

STAGING_READY = [DEPLOY_STATUS_NEW,DEPLOY_STATUS_CHANGED,DEPLOY_STATUS_SELF_FAIL_STAGE]
PRODUCTION_READY = [DEPLOY_STATUS_SELF_STAGE,DEPLOY_STATUS_SELF_FAIL_PROD]
REQUEST_IMPLEMENT_READY = [DEPLOY_STATUS_NEW,DEPLOY_STATUS_CHANGED,DEPLOY_STATUS_SELF_STAGE,
                           DEPLOY_STATUS_SELF_PUSHING_STAGE,DEPLOY_STATUS_SELF_FAIL_PROD]

SAM_NORMAL = 0
SAM_ATTACK = 1
SAM_NORMAL_WITH_CHANGE = 2


SITE_SAM_DDOS_STATUS = ((SAM_NORMAL, 'Normal'),
              (SAM_ATTACK, 'Attack'),
              (SAM_NORMAL_WITH_CHANGE, 'Normal with rule change'))

TYPE_FLAG_CHOICES = (
    (1, '1. --'),
    (2, '2. DDoS'),
    (3, '3. FEO'),
    (4, '4. FB'),
    (5, '5. FB + DDoS'),
    (6, '6. CIC'),
    (7, '7. ZE'),
    (8, '8. ZE + DDoS'),
    (9, '9. China Origin - Cloud'),
    (10, '10. China Origin - Hosting'),
    (11, '11. DDoS + China Origin'),
    (12, '12. ZE + China Origin'),
    (13, '13. ZE + DDoS + China Origin'),
)


class URLWithAuthField(models.CharField):
    """Extends URLField to support urls with basic authentication keys included in the form
    username:password@domain.com/path/to/file/. Based on r5589 (multi-db branch)"""
    def __init__(self, verbose_name=None, name=None, verify_exists=True, **kwargs):
        kwargs['max_length'] = kwargs.get('max_length', 200)
        # no oldforms validation -- so anyone editing in the admin will be able
        # to set whatever they want. fortunately we're not allowing that.
        self.verify_exists = verify_exists
        models.CharField.__init__(self, verbose_name, name, **kwargs)

    def formfield(self, **kwargs):
        defaults = {'form_class': URLWithAuthFormField, 'verify_exists': self.verify_exists}
        defaults.update(kwargs)
        return models.CharField.formfield(self, **defaults)

    def get_internal_type(self):
        return 'CharField'

class URLWithAuthFormField(forms.Field):
    def __init__(self, max_length=None, min_length=None, verify_exists=False, *args, **kwargs):
        forms.Field.__init__(self, *args, **kwargs)
        self.verify_exists = verify_exists

    def clean(self, value):
        value = super(URLWithAuthFormField, self).clean(value)
        if value == u'':
            return value
        if self.verify_exists:
            import urllib2
            headers = {
                "Accept": "text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5",
                "Accept-Language": "en-us,en;q=0.5",
                "Accept-Charset": "ISO-8859-1,utf-8;q=0.7,*;q=0.7",
                "Connection": "close",
            }
            try:
                auth_match = re.match(r'http(?P<s>s?)://(?P<user>[^:]+):(?P<passwd>[^@]+)@(?P<address>.+)', value)
                if auth_match:
                    address = 'http%s://%s' % (auth_match.group('s'), auth_match.group('address'))
                    auth_string = base64.encodestring('%s:%s' % (auth_match.group('user'), auth_match.group('passwd')))[:-1] # strip newline char
                    headers['Authorization'] = "Basic %s" % auth_string
                else:
                    address = value

                req = urllib2.Request(address, None, headers)
                u = urllib2.urlopen(req)
            except ValueError:
                raise forms.ValidationError(u'Enter a valid URL.')
            except: # urllib2.URLError, httplib.InvalidURL, etc.
                raise forms.ValidationError(u'This URL appears to be a broken link.')
        return value

class AbstractSite(DatedModel):
    """
    Any numeric type field added has to have a default value in order for the blacklist view code to work right.
    """
    customer = models.ForeignKey(Customer)
    product = models.ForeignKey(Product, null=True, blank=True)
    china_lic = models.CharField('China license number', blank=True, null=True, max_length=150)
    pad = models.CharField('PAD', unique=True, max_length=255, db_column='serve_domain', help_text='Production Accelerated Domain: the domain that CDNetworks is serving content for (e.g. cdn.customer.com)')
    origin = models.CharField(max_length=255, db_column='domain', help_text='Domain which CDNetworks cache will fetch content from on cache misses or refreshes (e.g. origin.customer.com). Changing this value will result in a full flush unless a request is made to set the pad id setting appropiately, this is due to content index being based on the origin domain.')
    backup_origin = models.CharField('Failover Origin',blank=True, null=True,  max_length=255,help_text='A failover domain or IP which cache server uses when it is unable to fetch a file from the primary origin domain. Regardless of the custom port field, if the port is not specified, 80 port will be used as default. (ex: foo.com:8080)' )
    description = models.CharField(blank=True, max_length=765, help_text='Description of site')
    status = models.BooleanField('Active', default=True, help_text='Enable or disable the site')
    service = models.ForeignKey('Service', verbose_name="Edge Service", db_column='cdn_service_id',  null=True, blank=True, help_text='CNAME the PAD to this domain.') # <br/><a href=# id="show_shields"> Choose a shielding configuration for this PAD.</a>')
    shielded_service = models.ForeignKey('ShieldedService', null=True, blank=True, help_text='')
    drop_params = models.BooleanField('Drop Query String', default=False, help_text="Drop query string before requesting object from origin and caching without query string")
    track_urls = models.BooleanField('Enable Top URLs Report', default=False, help_text='Enable tracking of the top 200 unique URLs. Responses of type "200 OK" are tracked by default; specify others in the "track codes" field')
    track_codes = models.CharField(blank=True, max_length=255, help_text="""Comma-delimited values, <b>without spaces</b>.
                                            Specify a response code to track that code, or specify a single digit (2,3,4 or 5) to track
                                            each code in that class individually. E.g.: "3,404,503".""")
    rewrite_rules = RegexTextField('Regex Rewrite Rules (URI)', blank=True, help_text="Rewrite URI before requesting object from origin and caching with rewritten URI. One rule per line. Example: <code> ^/(.*\.html) /rewritten?url=$1</code>")
    full_url_rewrite_rules = RegexTextField('Regex Rewrite Rules (Full URL)', blank=True, help_text="Rewrite Origin URL (including host) before requesting object from origin and caching with rewritten URL. This version takeOne rule per line. Example: <code> ^http://origin\.site\.com/([^/]*)/(.*.html) http://$1.origin.site.com/rewritten?url=$2</code>")
    min_age = models.IntegerField('Min-age',default=0, help_text='Objects with a max-age less than this value will have it increased to this value in seconds.')
    bps_streaming_limit = models.IntegerField('Bits/sec streaming limit',default=0,
                                              help_text='For videos this is the rate files are encoded in.<br>A default value 0 indicates feature is off')
    buffer_secs = models.IntegerField('Buffer Seconds', default=-1, help_text='Seconds of file to download before throttling based on bits/sec streaming limit')
    domain_unique_key = models.CharField('Deprecated Pad Id', blank=True, max_length=255, help_text="DEPRECATED. If you need to modify it, use Cache Id instead and seek help from an engineer.")
    referrer_list = RegexTextField(blank=True, help_text="""List of regular expressions to match referrers, Example: <code>^https?://[a-zA-Z0-9._-]*\.panthercustomer\.com/.*</code>""")
    referrer_list_type = models.IntegerField(choices=((0,'Blacklist'),(1,'Whitelist')), default=0, help_text="Apply rules as either a blacklist or whitelist")
    bypass_empty_referrer_check = models.BooleanField('Ignore rule if empty referrer header', default=True, help_text='If referrer header empty can ignore this rule')
    custom_headers = models.TextField('Custom Headers to Origin', blank=True, help_text='Set custom headers for cache to pass when connect to origin. One per line. Example: <code>X-Foo: bar</code>')
    # passthru_cookies = models.BooleanField(default=False) --deprecated via new field 'cookie exchange' as of CS1.3
    use_sub_files = models.BooleanField('Chunking', default=True, help_text="Enable chunking for large files. Origin must support byte-range requests. Any PAD that has chunking enabled or disabled will cause a cache flush for those files. This will not be an issue for new PADs being turned up since nothing is in cache yet.")
    validation_scheme = models.IntegerField(choices=((0,'None'),(1,'Origin Logic Control'),(2,'Basic Authentication')), default=0, help_text="Choose validation type")
    bypass_validation_on_failure = models.BooleanField('Authorize user if origin unreachable', default=False, help_text='For OLC, if can not reach origin, authorize user')
    default_last_modified_date = models.CharField('Default Last-Modified Date.',blank=True, max_length=30, help_text="Objects that do not have a last-modified date value will use this one. Example: <code>Thu, 1 Jan 2000 00:00:00 GMT</code>")
    progressive_dl = models.BooleanField('Enable PDSeek', default=False)
    progressive_dl_param = models.CharField('PDSeek params', blank=True, max_length=32, help_text='The query string parameter to use. Default is start.')
    failed_referrer_check_redirect_url = models.CharField('URL redirect if unauthorized referrer', blank=True, max_length=255, help_text='CDNetworks redirect object (CRO) to send user to if unauthorized.  See Origin Logic Control Service Note for info on the CRO')
    preserve_url_on_validation = models.BooleanField('Use domain from redirect', default=True)
    request_log_msg_format = models.CharField('Request-log format', blank=True, max_length=1000, help_text="If logs are required, please contact your Account Manager")
    origin_ip = models.IPAddressField('Static Origin IP', blank=True, help_text="IP used to connect to origin rather than resolving the origin domain")
    origin_port = models.IntegerField('Custom Origin Port', default=0,
                                      help_text="Port cache will use to connect to origin. Default is port 80, represented by '0'. This is not for failover origin.")
    origin_host_header = models.CharField('Custom Host Header', blank=True, max_length=255,
                                          validators=[ RegexValidator('^[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,6}$',
                                                                      'Invalid domain pattern','Invalid Entry')],
                                          help_text='Host header to use when connecting to the origin.')
    http_auth_user = models.CharField('HTTP Authentication User', blank=True, max_length=50, help_text='For Basic Auth, the user name for CDNetworks cache to use to fetch object from origin')
    http_auth_password = models.CharField('HTTP Authentication Password', blank=True, max_length=50, help_text='For Basic Auth, the password for CDNetworks cache to use to fetch object from origin')
    http_auth_type = models.IntegerField('HTTP Authentication Type', choices=((0,'Basic'),), default=0, help_text="Type of HTTP authentication")
    gzip_compression = models.BooleanField('Gzip Compression', default=True, help_text="Enable GZip compression for small text-based objects")
    honor_byte_range = models.BooleanField('Honor HTTP byte-range', default=True, help_text="Enable or disable byte-range requests.")
    honor_multi_byte_range = models.BooleanField('Honor Multi-byte-range', default=False, help_text="Enable or Disable multi-byte-range requests.  This feature is typically used by PDF clients to request several pages at once.")
    deny_direct_user_request = models.BooleanField('Deny direct request from users', default=False, help_text="Disallow users from accessing the PAD directly.  Mainly used when OLC is configured")
    strict_nocache_support = models.BooleanField('Strict no-cache support', default=False, help_text="Turn on to make sure non-cacheable files will never be shared between users.")
    cookie_exchange = models.BooleanField('Cookie Exchange', default=False, help_text="Enable cookie passing between browser and origin. Please make sure to read documentation to avoid sharing personal user data.  Requires approval to turn on.")
    rewrite_rules_post_validation = RegexTextField('Regex Rewrite Rules after validation', blank=True, help_text='When using Origin Logic Control, rewrite URL after validation. One rule per line. Example: <code> ^/(.*\.html) /rewritten?url=$1</code>')
    drop_params_post_validation = models.BooleanField('Drop query string after validation', default=False, help_text='When using Origin Logic Control, drop query string of URL after validation')
    drop_precise_params_post_validation = models.CharField('Drop specific params from query string', blank=True, max_length=255, help_text='Drop a parameter from query string before requesting object from origin. Use a comma-separated list of parameters. If using Origin Logic Control this will occur after validation.')
    case_insensitive_urls = models.BooleanField('Case-insensitive Urls', default=False, help_text="Treat URLs as case insensitive by making URL all lower cased.")
    pad_aliases = models.TextField('Pad Aliases', blank=True, help_text='Other domains to be served under the same PAD configuration. One alias per line.')
    custom_param = models.TextField('Custom Parameter', blank=True, help_text='A convenience custom parameter field, that will be passed to CS in the config.')
    reverse_proxy_redirect = models.BooleanField('Reverse Proxy redirect', default=False, help_text="Converts origin domain found in 301 or 302 to the PAD domain.  This applies to GET requests only.")
    force_not_modified_on_ims = models.IntegerField('Force 304 on IMS', default=0,
                                                    help_text="Percentage of requests for which CS should return 304 without looking up the file. <br>Default value 0 indicates feature is off")
    max_requests_per_keep_alive = models.IntegerField('Maximum requests per Keep-Alive', default=0,
                                                      help_text="Maximum number of objects served within one keep-alive connection.<br>Default value 0 indicates no limit")
    validation_default_redirect_url = models.CharField('Default redirect if authorized', blank=True, max_length=255, help_text='For OLC, CDNetworks redirect object (CRO) to send user to after OLC authorization.  If only a domain, existing path will be appended. See Origin Logic Control Service Note for info on the CRO')
    validation_nobypass_redirect_url = models.CharField('Default redirect if origin down and user unauthorized', blank=True, max_length=255, help_text='For OLC, CDNetworks redirect object (CRO) to send user to if OLC authorization can not be performed.  If only a domain, existing path will be appended. See Origin Logic Control Service Note for info on the CRO')
    upstream_timeout_sec = models.IntegerField('Origin Timeout Sec', default=0,
                                               help_text="Timeout for origin connections (connect, read and write operations).<br>Default value 0 indicates 20 Sec.")
    force_maxage_on_40x = models.IntegerField('Force Max-age on 4xx', default=0, help_text="Set max-age in seconds for 4xx responses, overriding CDNetworks' default caching behavior")
    cache_id = models.CharField('PAD ID', blank=True, max_length=255, help_text='Defines a specific key under which content is cached.  By default this is the origin domain.  Please format at "n.domain" where n is a version number and domain is your origin domain.')
    tag_hash_format = models.CharField('Custom Hash Format', blank=True, max_length=255,help_text='Custom formatted tag. This will override the preset hash format. Refer to the URL Tag Validation documentation for setting this field.')
    tag_hash_param = models.CharField('Hash Parameter Name', blank=True, max_length=255, help_text = 'Parameter in query string associated with the hash.  Default value is px-hash.')
    tag_check_enabled = models.BooleanField('Enable URL Tag Validation', default=False)
    tag_secret = models.CharField('Secret Passphrase', blank=True, max_length=255, help_text='Any alphanumeric string known only by CDNetworks and the origin')
    tag_time_allowed_sec = models.IntegerField('Time Allowed', default=0, help_text='Number of seconds after the time parameter in the URL is valid for ')
    tag_time_offset_sec = models.IntegerField('Time Offset', default=0, help_text='Optional variable to take into account any time differences between the origin and CDNetworks cache (e.g.: origin does not use GMT)')
    tag_time_param = models.CharField('Time Parameter Name', blank=True, max_length=255, help_text='Default value is px-time')
    tag_hash_format_preset = models.IntegerField('Preset Hash Format', default=0, help_text='If using a preset, choose 0-5. Refer to URL Tag Validation documentation for an explanation of these presets.')
    tag_time_in_hex = models.BooleanField('Time in Hexadecimal', default=True, help_text='Check if time is written in hexadecimal')
    pass_thru_headers_to_origin = models.TextField('Pass through headers to origin', help_text='Whitelist headers to pass from browser to origin. Note: "X-" will be added as a prefix to the header.', blank=True)
    pass_thru_headers_to_user = models.TextField('Pass through headers to user', help_text='Whitelist headers to pass from origin to browser', blank=True)
    drop_params_in_cache_url = models.BooleanField('Drop query string in cache URL',help_text='After object is requested from origin, drop query string before caching object', default=False)
    drop_precise_params_in_cache_url = models.CharField('Drop specific params in cache URL',help_text='After object is requested from origin, drop a pramater from query string before caching object. Use a comma-separated list of parameters.', max_length=50, blank=True)
    pdseek_flv_extensions = models.CharField("Extensions for FLV Seek", help_text="Comma separated list of file extensions to apply FLV seeking to Example: <code>flv</code>", max_length=255, blank=True)
    pdseek_h264_extensions = models.CharField("Extensions for H.264/MP4 Seek", help_text="Comma separated list of file extensions to apply H.264/MP4 seeking to. Example: <code>mp4,m4v</code>", max_length=255, blank=True)
    pdseek_default_type = models.IntegerField("Default Seek Type", help_text="Default seeking type if no extension rules match", choices=[(0,'flv'), (1,'h264')],default=0)
    default_max_age = models.IntegerField("Default max-age",
                                          help_text="Default max-age in seconds to apply on regular files.<br>Default value 0 indicates 604800 Sec.", default=0)
    max_age_rules = RegexTextField("Cache Controller max-age rules",help_text="Set max-age value for objects that do not have a cache-controller header from origin. One rule per line. Example: <code> ^/.*\.jpg 86400</code>", blank=True)
    content_variation_rules = RegexTextField("Content Variation Rules", help_text="Set rules on caching files with other attributes in addition to URL. One rule per line. Example: <code>^/.*\.html %cgender</code>", blank=True)
    validation_custom_headers = models.TextField("Validation Custom Headers",help_text="Optional headers that passed to origin during validation", blank=True, null=True)
    accept_setting_from_query_string = models.BooleanField("Accept setting from query string", help_text="allow to override some PAD options (like throttling) by parameters in query string", default=False)
    enable_ssl = models.BooleanField("SSL Enabled",help_text="Enable SSL content delivery on the pad", default=False)
    force_ssl = models.BooleanField('SSL only', default=False, help_text="When true, Cache Server redirect all HTTP requests from a SSL-enabled PAD to HTTPS")
    follow_redirect = models.BooleanField(default=False, help_text="When true, cache server will follow a 302 redirect returned by origin, cache the final file, and return it to user")
    use_pad_as_host_header = models.BooleanField('Pass host header to origin', default=False, help_text="When true, Cache Server uses the user-requested domain as the 'Host' header when connecting to origin, this passes on the received host header")
    large_file_redirect_size = models.IntegerField('Redirect to affinity on size', default=0,
                                                   help_text="Redirect the request to its affinity master when the requesting file is larger than this size.<br>A default value 0 indicates feature is off")
    server_action_rules = RegexTextField('Server action rules', blank=True, null=False, help_text="List of server action rules")
    wildcard_origin_from_path = models.BooleanField("Wildcard Origin from Path",help_text="Use the first subfolder of the url path as the wildcard origin",default=False)
    cdnw = models.BooleanField("Send OCSP logs?", help_text="Check this box if you want to send per hit logs for this PAD to the OCSP portal", default=True)
    cname_prefix = models.CharField("Optional custom CNAME", help_text="Use this field if you want to define a custom CName for this PAD. This is defaulted as p<pad_id>",max_length=63, null=True, blank=True)
    cname_dns_zone_record = models.ForeignKey(DnsZone,verbose_name="Dynamic DNS Zone", limit_choices_to={'dynamic_cache__in': (1,2)}, blank=False, null=False, default=9)
    tag_skip_patterns = RegexTextField("URI pattern to skip tag validation", help_text ="Use this set of regular expressions to skip tag validation for certain URIs. One rule per line. Example: <code>^/cross-domain\.xml</code> or <code> ^/.*\.flv</code>", blank=True)
    origin_failure_redirect_url = models.CharField("URL redirect upon origin download failure", help_text="CDNetworks redirect object (CRO) to send user to after failure to download cache-missed content from origin. If only a domain, existing path will be appended. See Origin Logic Control Service Note for info on CRO.", max_length=256, blank=True, null=True)
    honor_path_range = models.BooleanField("Honor Path-Range", help_text="Enable or disable byte-range requests from path (URI). Used for Silverlight player. URI format is: /path/file.ext/range/low-high[?query]", default=False)
    cookie_exchange_share_cookie = models.BooleanField(default=False, help_text="Share cookies between users")
    user_keep_alive_timeout = models.IntegerField('User keep-alive timeout (MS)', default=0, blank=True, null=True,
                                                  help_text="This field controls the timeout for the keep-alive connection to a user.<br>Default value 0 indicates 6 Sec on HTTP and 30 Sec on HTTPS.")
    stat_paths = models.TextField("Stat Path Keywords", help_text="Keywords to separate statistics per folder.  Format should be '# <path>' per line. Number must be unique and path should not contain leading /. Example: 1 static/js/", blank=True)
    upstream_ssl = models.IntegerField('Upstream SSL', choices=[(0, 'None'), (1,'Validation Only'), (2, 'Insecure'), (3, 'Secure')], default=0, help_text="NOTE: THIS IS NOT FULLY DEPLOYED, SOME VERSIONS OF CS TREAT INSECURE/SECURE AS VALIDATION ONLY.<br/> If set to other than NONE, CS will use SSL within CDN and to Origin, with security as follows:<br/>    - VALIDATION_ONLY: certificate signature validation but no domain check<br/>    - INSECURE: certificate is always accepted<br/>    - SECURE: certificate signature validation AND domain check")
    origin_keep_alive_timeout = models.IntegerField('Origin keep alive timeout (ms)', default=0,
                                                    help_text="Timeout for origin connections (connect, read and write operations).<br>Default value 0 indicates 30 Sec.")
    upstream_connect_timeout_sec = models.IntegerField('Origin Connect Timeout Sec', default=0,
                                                       help_text="Timeout for connection establishment to origin (overrides Origin Timeout Sec).<br>Default value 0 indicates 20 Sec")
    max_origin_downloads = models.IntegerField('Max Concurrent Origin Downloads', default=0,
                                               help_text="""AVAILABLE STARTING CS 1.6.1. This setting is used to prevent CS from using too many connections to origin for a single PAD.
                                                        Default value 0 indicates 2000 which should be way enough for all purposes.
                                                        Set it lower for customers that can potentially take too many connections (e.g. high rps).
                                                        If the limit is reached, CS will not start new downloads and treat them as errors.""")
    max_master_retries = models.IntegerField('Max Master Retries', default=0,
                                             help_text="AVAILABLE STARTING CS 1.6. Max number of times to retry a failed master (affinity or shield) download. A download may fail if the server was thought to be up but is actually down. The default is 0 which means no retry. Set it to 1 for improved reliability. This can reduce the stability of overloaded POP, only use if advanced user.<br>Default value 0 means to 1 retry")
    upstream_hash_source = models.IntegerField('Upstream Hash Source', default=0, help_text='AVAILABLE STARTING CS 1.6. Choose the data used to determine master nodes, default is "URL". Choose "User IP" to allow session stickiness to origin.', choices=[(0, 'URL'), (1, 'User IP'), (2,'Random')])
    origin_record_ttl = models.IntegerField('Origin Record TTL ', default=0,
                                            help_text='AVAILABLE STARTING CS 1.6. Time in seconds to keep resolved origin IP for. Use 0 for default (5min). Set to a few seconds in order to achieve DNS IP load balancing.')
    use_circular_buffer = models.BooleanField('Circular Buffer for unbounded file', default=False, help_text="AVAILABLE STARTING CS 1.6. Turns this feature on to use a circular buffer (memory efficient) for unbounded files (e.g. chunked encoding) that are not cacheable.")
    one_validation_per_connection = models.BooleanField('One validation per connection', default=False, help_text="AVAILABLE STARTING CS 1.6. If turned off (default), every user request gets validated from origin. If turned on, only the 1st request in a connection gets validated, which can speed up AA and other cases. This works for all types of validation. ADVANCED FEATURE USE CAREFULLY. ")
    pass_all_headers = models.BooleanField('Pass all headers', default=False, help_text="AVAILABLE STARTING CS 1.7.1.  If this setting is turned on, CS will pass every 'safe' headers through between user and origin, both in request and response. Default is false. ")
    platform_cd = models.IntegerField(choices=((53,'HLS'),(54,'HDS'),(55,'Smooth Streaming'),(58,'Progressive Download'), (65, 'MPEG_DASH')), blank=True, null=True, help_text="")
    #type_flag = models.IntegerField('Type Flag', default=0, help_text='Using by searching, managing server action rule')
    type_flag = models.IntegerField('Type Flag', default=1, choices=TYPE_FLAG_CHOICES)
    use_origin_multiple_dns_record = models.BooleanField('Use multiple DNS records for Round-Robin origin selection', default=False, help_text="AVAILABLE STARTING CS 8.0.22. This setting enable resolving origin host as ip list and caching in CS internal. When CS connect to origin, selecting one of ip list by round-robin algorithm")
    use_origin_sticky = models.BooleanField('Origin sticky session', default=False, help_text='AVAILABLE STARTING CS 8.0.22. This setting is used when "Use multiple DNS records for Round-Robin origin selection" is true. If once origin ip was selected by Round-robin algorithm, CS remember origin ip by key as (hostname|origin-sticky-id) during sticky session timeout (default : 30min). sticky-session-id would be default client\'s IP. But if "X-Origin-Sticky-Id" header is given at request, use origin-sticky-id as the value of the header.')
    nonwildcard_hour = models.PositiveIntegerField('Non-Wildcard Flush Requests/Hour', default=60, help_text="The limit is per site", db_column="flushes_per_hour")
    items_per_request = models.PositiveIntegerField('Items/Request', default=1000, help_text="The limit is per site")
    all_per_hour = models.PositiveIntegerField('All Flush Requests Per Hour', default=1, help_text="The limit is per site")
    wildcards_per_hour = models.PositiveIntegerField('Wildcard Requests/Hour', default=10, help_text="The limit is per site")
    wildcards_per_request = models.PositiveIntegerField('Wildcards/Request', default=10, help_text="The limit is per site")

    class Meta:
        abstract = True

    def clone(self):
        new_row = self.__class__()
        for field in self._meta.fields:
            if field.attname not in ('id','site_id','create_time'):
                setattr(new_row, field.attname, getattr(self, field.attname))
        new_row.description = 'copied from %s%s' % (self.pad, (': %s' % new_row.description if new_row.description else ''))
        return new_row

    def __init__(self, *args, **kwargs):
        super(AbstractSite, self).__init__(*args, **kwargs)
        # It's nice if most model classes have a 'name' attribute
        self.name = self.pad
        #calling self.customer or checking attribute 'customer' within init function makes 'select_related' function not working
        if hasattr(self, 'customer_id') and self.customer_id and not hasattr(self,'id') and self.id:
            #new so set product...
            def_prods = Product.objects.filter(customer = self.customer, default=True)
            if def_prods.count() == 1:
                self.product = def_prods[0]

    def cache_group(self):
        if self.cache_id:
            return self.cache_id
        elif self.domain_unique_key:
            return self.domain_unique_key
        elif self.origin_host_header:
            return self.origin_host_header
        else:
            return self.origin

    def shared_cache_pads(self):
        pad_list = []
        #using this not to weildy values list because the queryset lookup was ugly performance-wise. Wishing I was able to use Django 1.1's only
        lookup_list = Site.objects.filter(status=True).exclude(pk=self.id).values_list('id','origin', 'cache_id', 'domain_unique_key', 'origin_host_header')
        my_cache_group = self.cache_group()
        # hate circular imports

        from ci.common.utils.site import get_cache_group_val
        for pad in lookup_list:
            pad_cache_group = get_cache_group_val(pad[2], pad[3], pad[4], pad[1])
            if my_cache_group == pad_cache_group:
                pad_list.append(pad[0])
        return Site.objects.filter(pk__in=pad_list)


    def json_server_actions(self):
        if self.server_action_rules>'':
            r = json_load_ordered(self.server_action_rules)
            if not isinstance(r, list):
                raise Exception("Rules must be in the form of a list")
            else:
                return r
        else:
            return None

    def json_server_actions_for_proc_default(self):
        if self.server_action_rules>'':
            r = json_load_ordered(self.server_action_rules)
            if not isinstance(r, list):
                raise Exception("Rules must be in the form of a list")
            else:
                for rule in r:
                    if not 'proc' in rule:
                        try:
                            rule['proc'] = '1'
                        except TypeError, e:
                            return r
                return r
        else:
            return None

    def server_actions_hash(self):
        return md5((self.server_action_rules).encode('utf-8') if self.server_action_rules else '').hexdigest()
    def prod_server_actions_obj(self):
        from ci.common.forms.server_actions import get_rule_objects
        return get_rule_objects(self)


def is_changed_to_security(new, old_site):
    ret = -1
    #0 : pad's service returned to original service from security service.
    #1 : pad's service changed to security service.
    new_dns_prefix = new.service.dns_prefix
    old_dns_prefix = old_site.service.dns_prefix if old_site and old_site.service else ''
    new_match = re.match(r'SECZ[0-9][0-9][0-9]', new_dns_prefix)
    if old_site:
        old_match = re.match(r'SECZ[0-9][0-9][0-9]', old_dns_prefix)
        if old_dns_prefix != new_dns_prefix:
            if not old_match and new_match:
                ret = 1
            if old_match and not new_match:
                ret = 0
    else:
        if new_match:
            ret = 1
    return ret, new.service.pk if new.service else None

class Site(AbstractSite):
    id = models.AutoField('Site ID', primary_key=True, db_column='customer_site_id')
    auth_key = models.CharField('REST authentication key', blank=True, max_length=16)
    default_rate = models.ForeignKey(BillRate, help_text="Optional per-site default rate", blank=True, null=True, db_column='default_rate')
    wpo_origin = models.BooleanField('WPO Origin', default=False)
    wpo_type = models.PositiveSmallIntegerField('WPO Type', default=0, choices=((0, 'None'), (1, 'FEO'), (2, 'Image Converter')))
    use_edns_client_subnet = models.BooleanField('Use edns client subnet', default=True)
    use_global_region_rule = models.BooleanField('Use global region rule', default=False)
    dns_refresh_type = models.IntegerField(choices=((0,'Asychronous'),(1,'Synchronous'),(2,'Background')), default=0, blank=False, null=True,
                                           help_text="""
                                           The behavior of each resolving types when DNS TTL expires.
                                            Asynchronous - Request to origin first and then resolving to origin on other thread.
                                            Synchronous - Wait resolving and request to origin on same thread.
                                            Background - Background thread does resolving and request to origin with always fresh resolved IPs.
                                           """)
    dns_entry_existing_time_limit = models.IntegerField(default=0, blank=False, null=True,
                                                        help_text="Limit of existing time for DNS entries wthout request (in second).<br>default(0) means 7200 seconds")
    hide_customer = models.BooleanField('Hide SAM for customer', default=False)
    optimal_ratio = models.IntegerField('Optimal Ratio', default=100)

    #guides should be list of tuples where it is (name,url)
    fieldsets = (
        ('Basic', {'fields':('customer', 'id', 'pad', 'hide_customer', 'type_flag', 'nonwildcard_hour', 'items_per_request',
                             'all_per_hour', 'wildcards_per_hour', 'wildcards_per_request', 'pad_aliases', 'origin', 'backup_origin',
                             'status', 'product','platform_cd', 'wpo_type', 'use_edns_client_subnet', 'use_global_region_rule', 'china_lic',
                             'service','shielded_service', 'cname_prefix', 'cname_dns_zone_record','description',
                             'default_rate', 'pass_all_headers','create_time','modify_time'),
                   'guides':[('Implementation Guide','/static/pdf/CDNetworks_Caching_Implementation_Guide.pdf')]}),
        ('Caching',{'fields':('cache_id','strict_nocache_support','min_age','default_last_modified_date','force_not_modified_on_ims','force_maxage_on_40x','default_max_age','max_age_rules','content_variation_rules', 'upstream_hash_source'),
            'guides':[('PAD ID','/static/pdf/CDNetworks_PAD+ID+-+Service+Note.pdf'),('Cache Controller','/static/pdf/CDNetworks_Cache+Controller+-+Service+Note.pdf'),('Content Variation','/static/pdf/CDNetworks_Content+Variation+-+Service+Note.pdf')]}),
        ('Request & Response',[
            ('Rules for Requests to Origin', {'fields':('origin_ip','origin_port','origin_host_header','use_pad_as_host_header',
                                                        'custom_headers','wildcard_origin_from_path','upstream_timeout_sec',
                                                        'upstream_connect_timeout_sec','origin_keep_alive_timeout',
                                                        'origin_failure_redirect_url', 'upstream_ssl', 'max_origin_downloads',
                                                        'origin_record_ttl', 'use_origin_multiple_dns_record', 'use_origin_sticky',
                                                        'dns_refresh_type','dns_entry_existing_time_limit'),
                'guides':[('Online IQ Directions','/static/pdf/CDNetworks_Online+IQ+Directions.pdf'),('Implementation Guide','/static/pdf/CDNetworks_Caching_Implementation_Guide.pdf'),('Origin Failover','/static/pdf/CDNetworks_Origin+Failover+-+Service+Note.pdf')]}),
            ('Rules for Requests From Users', {'fields':('honor_byte_range', 'honor_multi_byte_range', 'max_requests_per_keep_alive', 'user_keep_alive_timeout','pass_thru_headers_to_origin','accept_setting_from_query_string','enable_ssl','force_ssl','honor_path_range'),
                'guides':[('Implementation Guide','/static/pdf/CDNetworks_Caching_Implementation_Guide.pdf')]}),
            ('Rules for Response to Users', {'fields':('gzip_compression','reverse_proxy_redirect', 'follow_redirect', 'pass_thru_headers_to_user','deny_direct_user_request'),
                'guides':[('Implementation Guide','/static/pdf/CDNetworks_Caching_Implementation_Guide.pdf')]}),
            ('Cookie Handling',{'fields':('cookie_exchange','cookie_exchange_share_cookie'),
                'guides':[('Cookie Handling','/static/pdf/CDNetworks_Cookie+Handling+-+Service+Note.pdf')]}),
        ]),
        ('Rewrite Rules', {'fields':('case_insensitive_urls','drop_params','rewrite_rules','drop_params_post_validation','rewrite_rules_post_validation','drop_precise_params_post_validation','drop_params_in_cache_url','drop_precise_params_in_cache_url', 'full_url_rewrite_rules'),
            'guides':[('Rewrite Rules','/static/pdf/CDNetworks_URL+Rewrite+Rules+Service+Note.pdf')]}),
        ('Validation', [
            ('Referrer Rules',{'fields':('referrer_list','referrer_list_type','bypass_empty_referrer_check','failed_referrer_check_redirect_url', 'one_validation_per_connection'),
                'guides':[('Referrer Checking','/static/pdf/CDNetworks_Referrer+Checking+-+Service+Note.pdf'),('Origin Logic Control','/static/pdf/CDNetworks_Origin+Logic+Control+-+Service+Note.pdf')]}),
            ('Validation Scheme (OLC & Basic Auth)',{'fields':('validation_scheme','bypass_validation_on_failure','validation_default_redirect_url','validation_custom_headers','validation_nobypass_redirect_url','http_auth_user','http_auth_password','http_auth_type'),
                'guides':[('Origin Logic Control','/static/pdf/CDNetworks_Origin+Logic+Control+-+Service+Note.pdf'),('Basic Authentication','/static/pdf/CDnetworks_Basic+Authentication+-+Service+Note.pdf')]}),
            ('URL Tag Validation',{'fields':('tag_check_enabled','tag_hash_format_preset','tag_hash_format','tag_hash_param','tag_secret','tag_time_param','tag_time_in_hex','tag_time_allowed_sec','tag_time_offset_sec','tag_skip_patterns'),
                'guides':[('URL Tag Validation','/static/pdf/CDNetworks_URL+Tag+Validation+-+Service+Note.pdf')]}),
        ]),
        ('Video/Large File Delivery',[
            ('Large File Handling',{'fields':('use_sub_files', 'large_file_redirect_size', 'use_circular_buffer'),
                'guides':[('Chunking','/static/pdf/CDNetworks_Chunking+-+Service+Note.pdf')]}),
            ('Throttling',{'fields':('bps_streaming_limit','buffer_secs'),
                'guides':[('Throttling','/static/pdf/CDNetworks_Throttling+Service+Note.pdf')]}),
            ('PDSeek',{'fields':('progressive_dl','progressive_dl_param','pdseek_default_type', 'pdseek_flv_extensions', 'pdseek_h264_extensions'),
                'guides':[('Progressive Download Seek','/static/pdf/CDNetworks_Progressive+Download+Seek+-+Service+Note.pdf')]})
        ]),
        ('Reporting',[
            ('Logging',{'fields':('request_log_msg_format',),
                'guides':[('Log Reporting','/static/pdf/CDNetworks_Log+Reporting+-+Service+Note.pdf')]}),
            ('Top URLs Report',{'fields':('track_urls','track_codes')}),
        ]),
    ('Misc',{'fields':('server_action_rules','auth_key','custom_param','skip_sync','stat_paths', 'max_master_retries')}),
    )
    class Meta:
        db_table = 'customer_site'
        ordering = ['customer','service','pad']
        app_label = 'oui'

    @classmethod
    def get_change_log_skip_fields(cls):
        return ['id', 'create_user', 'create_time', 'modify_user', 'modify_time', 'customer', 'product', 'preserve_url_on_validation']

    def __unicode__(self):
        return '%s: %s' % (self.customer.name, self.pad)

    def is_valid_target_with_pad_name(self, target_name):
        """
        check target name input is matched with pad
        :param target_name: domain name from real use cases
        :return:
        """
        if not target_name:
            return False
        target_name = target_name.strip().lower()
        pad_name = self.pad.lower()
        if target_name == pad_name or target_name in self.pad_aliases:
            return True
        if '*' in self.pad:
            if target_name.endswith(pad_name.replace("*","")):
                return True
        return False

    def set_shield_service(self, draft):
        """
        if product int dwa contract and shield service is already set at site table, use these one
        :return:
        """
        if self.product.is_dwa_contract():
            self.shielded_service = draft.shielded_service
        else:
            if self.shielded_service:
                return
            #set noshield
            if self.service:
                self.shielded_service = self.service.get_related_default_shield_service()
            else:
                raise Exception("Edge service is not set yet.")

    def get_ddos_convert_rule(self):
        try:
            ddos_rule = SiteDDosConvertRule.objects.get(site=self)
            return ddos_rule
        except SiteDDosConvertRule.DoesNotExist:
            return None

    def is_service_prefix_convert_automated(self, ddos_rule=None):
        """
        check if ddos convert rule automation is activated
        :return:
        """
        try:
            if ddos_rule is None:
                ddos_rule = SiteDDosConvertRule.objects.get(site=self)
            return ddos_rule.is_service_prefix_convert_automated()
        except SiteDDosConvertRule.DoesNotExist:
            return False

    def is_sam_rule_attack_convert_automated(self, ddos_rule=None):
        """
        check if ddos convert rule automation is activated
        :return:
        """
        try:
            if ddos_rule is None:
                ddos_rule = SiteDDosConvertRule.objects.get(site=self)
            return ddos_rule.is_sam_rule_attack_convert_automated()
        except SiteDDosConvertRule.DoesNotExist:
            return False

    def is_service_prefix_ddos_attack_convertible(self, ddos_rule=None):
        """
        check if ddos convert rule exists
        :return:
        """
        try:
            if ddos_rule is None:
                ddos_rule = SiteDDosConvertRule.objects.get(site=self)
            return ddos_rule.is_service_prefix_ddos_attack_convertible()
        except SiteDDosConvertRule.DoesNotExist:
            return False

    def get_ddos_convert_status(self, ddos_rule=None):
        if ddos_rule is None:
            ddos_rule = self.get_ddos_convert_rule()
        if self.is_service_prefix_ddos_attack_converted(ddos_rule):
            return "Attack"
        else:
            if ddos_rule is not None:
                return "Normal"
            else:
                return ""

    def get_ddos_sam_convert_status(self, ddos_rule=None):
        try:
            if ddos_rule is None:
                ddos_rule = SiteDDosConvertRule.objects.get(site=self)
                return ddos_rule.get_SAM_cookie_applied_status()
        except SiteDDosConvertRule.DoesNotExist:
            return ''

    def is_service_prefix_ddos_attack_converted(self, ddos_rule=None):
        """
        check if edge/shielded service is converted to attack config
        :return:
        """
        try:
            if ddos_rule is None:
                ddos_rule = SiteDDosConvertRule.objects.get(site=self)
            return ddos_rule.is_service_prefix_ddos_attack_converted()
        except SiteDDosConvertRule.DoesNotExist:
            return False

    def is_sam_rule_attack_converted(self, ddos_rule=None):
        try:
            if ddos_rule is None:
                ddos_rule = SiteDDosConvertRule.objects.get(site=self)
            return ddos_rule.is_sam_rule_attack_converted()
        except SiteDDosConvertRule.DoesNotExist:
            return False

    def get_auth_user(self):
        if self.modify_user:
            try:
                auth_user = AuthUser.objects.get(username=self.modify_user)
            except AuthUser.DoesNotExist:
                auth_user = get_request().user
        else:
            auth_user = get_request().user
        return auth_user

    def log_changes(self, previous_site_before_save, changed_dict={}, comment='', user=None):
        try:
            user = user if user else self.get_auth_user()
            change_log_manager = PADChangeTime(site=self, user=user, comment=comment)
            change_log_manager.save()
            model_fields = [(f.name, f.verbose_name if f.verbose_name else f.name) for f in Site._meta.fields]
            skip_fields = Site.get_change_log_skip_fields()
            for field_name, verbose_name in model_fields:
                if field_name not in skip_fields:
                    field_value = changed_dict.get(field_name, getattr(previous_site_before_save, field_name, ''))
                    change_log = PADChangeLog(pad_change=change_log_manager,
                                              field=verbose_name,
                                              value=field_value)
                    changed_field_value = changed_dict.get(field_name, None)
                    if changed_field_value is not None:
                        previous_field_obj = getattr(previous_site_before_save, field_name, '')
                        previous_field_value = getattr(previous_field_obj, 'pk', None)
                        previous_field_value = previous_field_value if previous_field_value else previous_field_obj
                        if changed_field_value != previous_field_value:
                            change_log.changed = True
                    change_log.save()
        except Exception,e:
            #TODO: leave error log behind
            pass

    def convert_service_to_ddos_attack(self, request=None, ddos_rule=None):
        #TODO: add validation
        """
        convert edge service and shielded service to ddos attack service set. refer to ddos convert rule for config
        :return:
        """
        if ddos_rule is None:
            ddos_rule = self.get_ddos_convert_rule()
        if ddos_rule and ddos_rule.is_service_prefix_ddos_attack_convertible() \
                and not ddos_rule.is_service_prefix_ddos_attack_converted():
            previous_site = Site.objects.get(pk=self.pk)
            ddos_rule.backup_edge_service_id = self.service.pk
            ddos_rule.backup_shield_service_id = self.shielded_service.pk
            self.service = ddos_rule.edge_prefix_on_ddos_attack
            self.shielded_service = ddos_rule.shielded_prefix_on_ddos_attack
            ddos_rule.event_status = 1
            ddos_rule.save(user=(request.user.username if request and request.user and request.user.username else ''))
            self.save(user=(request.user.username if request and request.user and request.user.username else ''))
            self.log_changes(previous_site,
                             changed_dict={'service':self.service.pk,'shielded_service':self.shielded_service.pk},
                             comment='converted to ddos attack service',
                             user=request.user if request else None)

    def convert_ddos_service_back_to_normal(self, request=None, ddos_rule=None):
        """
        convert edge shield service for ddos attack back to previous normal service. refer to ddos convert rule backup
        :return:
        """
        from ci.common.models.cache import Service, ShieldedService
        if ddos_rule is None:
            ddos_rule = self.get_ddos_convert_rule()
        if ddos_rule and ddos_rule.is_service_prefix_ddos_attack_converted() and ddos_rule.event_status == 1:
            previous_site = Site.objects.get(pk=self.pk)
            self.service = Service.objects.get(pk=int(ddos_rule.backup_edge_service_id))
            self.shielded_service = ShieldedService.objects.get(pk=int(ddos_rule.backup_shield_service_id))
            ddos_rule.backup_edge_service_id = None
            ddos_rule.backup_shield_service_id = None
            ddos_rule.event_status = 0
            ddos_rule.save(user=(request.user.username if request and request.user and request.user.username else ''))
            self.save(user=(request.user.username if request and request.user and request.user.username else ''))
            self.log_changes(previous_site,
                             changed_dict={'service':self.service.pk,'shielded_service':self.shielded_service.pk},
                             comment='converted back to normal from ddos service',
                             user=request.user if request else None)

    def get_sam_rules_as_list(self):
        result = []
        if self.server_action_rules and len(self.server_action_rules.strip()) > 0:
            try:
                result = simplejson.loads(self.server_action_rules)
                if not result:
                    result = []
            except:
                result = []
        return result

    def has_sam_rule(self):
        if self.server_action_rules is None or self.server_action_rules.strip() == '':
            return False
        else:
            return True

    def apply_sam_rule_to_ddos_attack(self, request = None, ddos_rule=None):
        """
        apply ddos default samrule if modified samrule does not exist
        modified_backup means that samrule has been backed up where modified 302 samrule was applied.
        default_backup means samrule has been backed up where default 302 samrule was applied.
        attack_samrule_snapshot means snapshot data when 302 samrule is applied which later will be used for recovery to normal
        Refer to https://wiki.cdnetworks.com/confluence/pages/viewpage.action?pageId=172196032
        :param ddos_rule:
        :return:
        """
        if ddos_rule is None:
            ddos_rule = self.get_ddos_convert_rule()
        json_previous_server_action_rule = self.server_action_rules
        action_rules = self.get_sam_rules_as_list()

        if ddos_rule and not ddos_rule.is_sam_rule_attack_converted():
            previous_site = Site.objects.get(pk=self.pk)
            samrule_to_apply = ddos_rule.server_action_rule_on_ddos_attack \
                if ddos_rule.server_action_rule_on_ddos_attack else SAMDefaultRule.objects.get(pk=1).server_action_rule
            samrules = simplejson.loads(samrule_to_apply)
            if isinstance(samrules, list):
                for samrule in samrules:
                    action_rules.append(samrule)
            else:
                action_rules.append(samrules)
            self.server_action_rules = simplejson.dumps(action_rules)
            if ddos_rule.server_action_rule_on_ddos_attack:
                backup_server_action_rule = {'modified_backup': json_previous_server_action_rule,
                                             'attack_samrule_snapshot': self.server_action_rules,
                                             'samrule_302_backup': samrules}
            else:
                backup_server_action_rule = {'default_backup': json_previous_server_action_rule,
                                             'attack_samrule_snapshot': self.server_action_rules,
                                             'samrule_302_backup': samrules}
            ddos_rule.backup_server_action_rule = backup_server_action_rule
            ddos_rule.event_status = 1
            ddos_rule.save(user=(request.user.username if request.user and request.user.username else ''))
            self.save(user=(request.user.username if request.user and request.user.username else ''))

            self.log_changes(previous_site,
                             changed_dict={'server_action_rules':self.server_action_rules},
                             comment='applied 302 SAM rule for DDos attack',
                             user=request.user if request else None)

    def apply_sam_rule_to_ddos_normal(self, request=None, ddos_rule=None):
        """
        recover site's server action rule from ddos_convert_rule's backup_server_action_rule.
        If site's samrule has changed within period when attack mode is applied,
        we should keep changes and need to remove only 302 samrule.
        refer to https://wiki.cdnetworks.com/confluence/pages/viewpage.action?pageId=172196032
        :param ddos_rule:
        :return:
        """
        if ddos_rule is None:
            ddos_rule = self.get_ddos_convert_rule()
        if ddos_rule is not None:
            current_site = Site.objects.get(pk=self.pk)
            data_dict = ddos_rule.get_backup_server_action_rule_as_dict()
            modified_backup_rule = data_dict.get('default_backup',None)
            default_backup_rule = data_dict.get('modified_backup', None)
            attack_samrule_snapshot = data_dict.get('attack_samrule_snapshot', None)
            samrule_302_backup = data_dict.get('samrule_302_backup', None)
            if modified_backup_rule is not None:
                backup_rules = '' if modified_backup_rule == 'null' else modified_backup_rule
            else:
                backup_rules = '' if default_backup_rule == 'null' else default_backup_rule

            if current_site.site_samrule_changed_during_attack_mode(attack_samrule_snapshot):
                samrule_list = self.get_sam_rules_as_list()
                if self.is_302_samrule_found(samrule_302_backup, samrule_list):
                    samrule_302_removed = self.get_samrule_with_302_rule_removed(samrule_list, samrule_302_backup)
                    self.server_action_rules = simplejson.dumps(samrule_302_removed)
                    ddos_rule.event_status = 0
                else:
                    #keep current samrule but need to alert for probable junk clean up
                    ddos_rule.event_status = 2
            else:
                self.server_action_rules = backup_rules

            ddos_rule.backup_server_action_rule = ''
            self.save(user=(request.user.username if request.user and request.user.username else ''))
            ddos_rule.save(user=(request.user.username if request.user and request.user.username else ''))

            self.log_changes(current_site,
                             changed_dict={'server_action_rules':self.server_action_rules},
                             comment='applied 302 SAM rule back to normal from DDos attack',
                             user=request.user if request else None)

    def is_302_samrule_found(self, samrule_302_backup, samrule_list):
        if isinstance(samrule_302_backup, list):
            return list_contains(samrule_list, samrule_302_backup)
        else:
            return samrule_302_backup in samrule_list

    def site_samrule_changed_during_attack_mode(self, attack_samrule_snapshot):
        return self.server_action_rules != attack_samrule_snapshot

    def get_samrule_with_302_rule_removed(self, samrule_list, samrule_302_backup):
        """
        remove 302 samrule items from site's server action rule
        samrule items can be either list or dict
        :param samrules: current samrule as list
        :param samrule_302_backup: 302 samrule backup when initial attack mode is applied
        :return:
        """
        result_samrules = []

        for samrule in samrule_list:
            if isinstance(samrule_302_backup, list):
                if samrule not in samrule_302_backup:
                    result_samrules.append(samrule)
            else:
                if samrule != samrule_302_backup:
                    result_samrules.append((samrule))
        return result_samrules



    def set_production_edge_service(self):
        """
        if edge service is already set at site table, use these one.
        once draft pushed to production, changing product at cui is not permitted.
        :return:
        """
        if self.service:
            return
        default_edge_service = self.product.get_default_edge_service_for_production()
        if default_edge_service is not None:
            self.service = default_edge_service
        else:
            raise Exception("There is no available service map for this product %s" % str(self.product))

    def copy_samrule_from_draft(self, draft):
        """
        copy draft samrule to site sam rule
        :param draft:
        :return:
        """
        self.server_action_rules = draft.server_action_rules
        #ddos_rule = self.get_ddos_convert_rule()
        #if ddos_rule is not None and ddos_rule.is_sam_rule_attack_converted():
        #    samrules = self.get_sam_rules_as_list()
        #    modified_backup, default_backup, attack_samrule = ddos_rule.get_backup_server_action_rule_as_dict()

    def push_to_production(self,draft):
        """
        1.copy draft to stage
        2.set edge service
        3.set shield service
        :param draft:
        :return:
        """
        if not draft.is_production_pushable():
            raise Exception("PAD is not allowed to be pushed to production yet. Push status is in '%s'" %
                            draft.get_push_status())
        self.draft_id = draft.pk
        self.set_from_draft(draft)
        self.copy_samrule_from_draft(draft)

        self.customer = draft.customer
        self.product = draft.product
        self.set_production_edge_service()
        self.set_shield_service(draft)
        self.save()
        return self

    def save(self, *args, **kwargs):
        assert self.service and self.pad and self.origin
        skip_sync = kwargs.pop('skip_sync', False)
        new_site = False
        if not self.id:
            self.create_time = datetime.now()
            new_site = True
        self.modify_time = datetime.now()
        is_previously_active = True
        try:
            old_site = Site.objects.get(pk=self.pk)
            is_previously_active = old_site.status
            previous_cop_dict = old_site.get_cop_related_product_info()
        except:
            previous_cop_dict = {}
            old_site = Site.objects.none()

        if not self.id:
            self.nonwildcard_hour = self.customer.nonwildcard_hour
            self.items_per_request = self.customer.items_per_request
            self.all_per_hour = self.customer.all_per_hour
            self.wildcards_per_hour = self.customer.wildcards_per_hour
            self.wildcards_per_request = self.customer.wildcards_per_request

        try:
            state_flag, security_service_id = is_changed_to_security(self, Site.objects.get(pk=self.pk) if self.pk else None)
        except:
            state_flag = -1

        super(Site, self).save(*args, **kwargs)

        try:
            if new_site:
                if skip_sync:
                    #link to cop
                    from ci.common.utils.cop import cop_domain_link
                    cop_domain_link(self)
                else:
                    self.add_domain_to_cop()
            else:
                cop_info_changed, current_cop_dict = self.has_cop_related_info_changed(previous_cop_dict)
                if cop_info_changed:
                    self.update_change_to_cop(previous_cop_dict, current_cop_dict)
        except:
            pass

        # find the site draft associated with this site
        drafts, draft = SiteDraft.objects.filter(Q(site=self) | Q(pad=self.pad)), None
        if drafts:
            try:
                draft = drafts.get()
            except AssertionError:
                # if there's more than one, delete them all
                drafts.delete()

        # if there aren't any, create one
        draft_created = False
        if not draft:
            draft = SiteDraft()
            draft_created = True

        # write all the site's settings to the draft and save them
        for field in self._meta.fields:
            if field.attname not in ('id','create_time'):
                setattr(draft, field.attname, getattr(self, field.attname))
            draft.site = self
        draft.has_customer_edits = False
        draft.push_status = 4
        draft.save()

        if draft_created:
            from ci.common.utils.site import send_implementation_email, save_site_change_history, DUMMY_SENDER_EMAIL
            if not is_previously_active:
                change_comment = u"PAD '%s' has been restored by admin operator." % (draft.pad)
            else:
                change_comment = u"PAD '%s' has been created by admin operator." % (draft.pad)

            operator_emails = self.customer.get_default_event_operator_subscriber_emails()
            #we need to show operator as actor to customer user at control portal/api
            save_site_change_history(sitedraft=draft,
                                         username=operator_emails,
                                         ops_type=1 if draft else 0,
                                         description=change_comment)

        site_pk = self.pk
        #for pe2ngp
        from ci.common.models.prism_sync import SyncJob
        sync_job = SyncJob(name='site', type='save', key=str(site_pk), flag=0, cnt=0)
        sync_job.save()

        from ci.common.models import UseLogForCloudSecurity
        if state_flag >= 0:
            uselog_obj = UseLogForCloudSecurity(pad_id=self.pk, state_flag=state_flag, cdn_service_id=security_service_id)
            uselog_obj.save()

    def is_active(self):
        return self.status

    def delete(self):
        site_pk = self.pk
        draft = self.sitedraft
        super(Site, self).delete()
        draft.delete()

        from ci.common.models.prism_sync import SyncJob
        sync_job = SyncJob(name='site', type='delete', key=str(site_pk), flag=0, cnt=0)
        sync_job.save()

    def get_paths(self):
        paths = {}
        stat_paths = self.stat_paths
        if stat_paths:
            lines=stat_paths.split("\n")
            for line in lines:
                parts = line.split(" ")
                if len(parts) == 2: #otherwise we skip line, not properly formed
                    paths[parts[0]] = parts[1].strip("\r")
        return paths

    def get_ocsp_domain_status(self):
        ocsp_status = 'active'
        if self.customer.status == True and self.status == True:
            if self.product and self.product.active == False:
                ocsp_status = 'inactive'
            else:
                ocsp_status = 'active'
        else:
            ocsp_status = 'inactive'

        return ocsp_status

    def get_site_path_string(self):
        return "$".join(["%d-%s:%s" % (str(self.id), x[0], x[1]) for x in self.get_paths().items()])

    def get_cop_related_product_info(self):
        cop_dict = {'ckey': self.customer.id,
              'domain': self.pad,
              'product_id': self.product.cop_product_id if self.product else '',
              'service_id': self.service.id,
              'status': self.get_ocsp_domain_status(),
              'platform_cd': self.platform_cd if self.platform_cd else '',
              'customer_portal_flag':self.customer.customer_portal_flag}
        if self.stat_paths:
            cop_dict['path'] = self.get_site_path_string()
        return cop_dict

    def has_cop_related_info_changed(self, previous_cop_dict):
        current_cop_dict = self.get_cop_related_product_info()
        for k,v in current_cop_dict.iteritems():
            if current_cop_dict.get(k) != previous_cop_dict.get(k):
                return True, current_cop_dict

        return False, current_cop_dict

    def update_change_to_cop(self, previous_cop_dict, current_cop_dict = None):
        if current_cop_dict is None:
            current_cop_dict = self.get_cop_related_product_info()

        old_customer_portal_flag = previous_cop_dict.get('customer_portal_flag')
        old_cop_product_id = previous_cop_dict.get('product_id')
        old_product_cd = previous_cop_dict.get('platform_cd')
        if old_customer_portal_flag == 'O' and self.customer.customer_portal_flag == 'A':
            current_cop_dict.update({'bf_product_id': str(old_cop_product_id)})
            current_cop_dict.update({'bf_platform_cd': str(old_product_cd)})
            #https://issues.cdnetworks.com/browse/OUI-1197

        from ci.common.utils.cop import copCall
        uri = "/PoDomain/%s/update/" %(self.id)
        resp = copCall(uri, current_cop_dict, acceptableResponses=[0,406])
        if resp[1] == 406:
            return self.add_domain_to_cop()
        return resp[0]

    def add_domain_to_cop(self):
        from ci.common.utils.cop import copCall
        uri = "/PoDomain/%s/add/" %(self.id)
        current_cop_dict = self.get_cop_related_product_info()
        if self.stat_paths:
            current_cop_dict['path'] = self.get_site_path_string()
        return copCall(uri, current_cop_dict, acceptableResponses=[0,301,405])[0]


    def set_from_draft(self, draft=None):
        if not draft:
            draft = self.sitedraft
        draft_diff = []
        editable = set(SiteDraft.cui_editable_fields+('pad',))
        for field in self._meta.fields:
            if hasattr(draft, field.attname):
                draft_val = getattr(draft, field.attname)
            else:
                draft_val = None
            draft_comp_val = draft_val if draft_val != "" else None
            curr_val = getattr(self, field.attname)
            if curr_val == "":
                curr_val = None
            if draft_comp_val != curr_val:
                if field.name not in ('id','create_time', 'modify_time','shielded_service'):
                    if field.__class__.__name__ == 'BooleanField':
                        draft_diff.append((field.name, field.verbose_name, "True" if curr_val==1 else "False"))
                    else:
                        draft_diff.append((field.name, field.verbose_name, curr_val))
                if field.name in editable:
                    setattr(self, field.attname, draft_val)
        return draft_diff

    def has_traffic_data(self):
        return self.trafficbytes_set.count() > 0
    def bad_cnames(self):
        from ci.common.models import CNameStatus
        return self.cnamestatus_set.exclude(status__in=CNameStatus.correct_choices).select_related()
    def legacy_cnames(self):
        from ci.common.models import CNameStatus
        return self.cnamestatus_set.filter(status=4).select_related()

    def is_modified(self):
        """
        Compare late modified time
        """
        try:
            return self.modify_time < self.sitedraft.modify_time
        except Exception, e:
            return False

    def get_diff(self):
        if not self.pk or not self.sitedraft:
            return {}

        diff_fields = self.sitedraft.local_changes()

        diff = {}
        for field in diff_fields:
            draft = getattr(self.sitedraft, field)

            diff[field] = draft

        return diff

    def toJSON(self):
        skip_fields = ("id", "service", "shielded_service", "create_time", "modify_time",\
                        "configpushrequesthistory",\
                        "site_rate_set", "trafficmissbytes", "hide_customer", "sitedraft",\
                        "trafficmissbytespop", "dns_refresh_type", "siteprofile",\
                        "pushertonodeupdateflush",\
                        "trafficrequestspop", "trafficmissrequestspop", "trafficbytes",\
                        "sitemethodrequestspop", "siteresponsecoderequestspop", "wpo_origin", "wpo_type",\
                        "site_group", "trafficbytespop", "auth_key",\
                        "nodeupdateflush", "trafficbytesforchart", "padchangetime",\
                        "traffichistory", "use_edns_client_subnet", "use_global_region_rule",\
                        "cnamestatus", "samsandbox", "sitemethodrequests", "trafficrequests",\
                        "aggregate", "trafficmissrequests", "default_rate",\
                        "siteresponsecoderequests",\
                        "dns_entry_existing_time_limit")

        site_all_fields = self._meta.get_all_field_names()

        site = draft = {}
        fields = list(set(site_all_fields) - set(skip_fields))
        for field in fields:
            site[field] = getattr(self, field)

        return json.dumps(self)


class SiteDraft(AbstractSite):
    # constant lists for form choices
    mbps_choices = (('','Please Estimate'),(20,'1-20 Mbps'), (100,'20-100 Mbps'), (500,'100-500 Mbps'), (1000,'0.5-1 Gbps'), (5000,'1-5 Gbps'), (10000,'5+ Gbps'))
    rps_choices = (('','Please Estimate'),(2500,'1 - 2,500'), (5000,'2,500 - 5,000'), (10000,'5,000 - 10,000'), (20000,'10,000+'))
    filesize_choices = (('','Please Estimate'),(1,'0-1 MB'), (10,'1-10 MB'), (50,'10-50 MB'), (100,'50-100 MB'), (500,'100-500 MB'), (1000,'0.5-1 GB'), (2000,'over 1 GB'))
    fieldsets = Site.fieldsets
    # django fields
    id = models.AutoField(primary_key=True, db_column='site_cui_id')
    site = models.OneToOneField(Site, null=True, blank=True, db_column='customer_site_id')
    approval_pending = models.BooleanField(default=False)
    on_hold = models.BooleanField(default=False)
    url_test = models.URLField('test origin URL', verify_exists=False, help_text='A URL for a test object on the origin server (e.g. http://origin.example.com/test.gif).')
    mbps_avg = models.IntegerField('bandwidth average', default=0, help_text='Average (mean) bandwidth used on the domain', choices=mbps_choices)
    mbps_peak = models.IntegerField('bandwidth max', default=0, help_text='Peak bandwidth on the domain', choices=mbps_choices)
    rps_avg = models.IntegerField('average requests per second', default=0, help_text='Average requests per second', choices=rps_choices)
    rps_peak = models.IntegerField('max requests per second', default=0, help_text='Maximum requests per second', choices=rps_choices)
    files_type = models.CharField('types of files and extensions', default='', max_length=255, help_text='List the file types served on the domain')
    files_count = models.IntegerField('number of files', default=-1, help_text='Total number of unique files served on the domain')
    files_size_avg = models.IntegerField('average file size (KB)', default=-1, help_text='Average file size in KB')
    files_size_max = models.IntegerField('maximum file size', default=0, help_text='The largest file on the domain', choices=filesize_choices)
    nam_percent = models.IntegerField('percentage of visits from N. America', default=-1)
    emea_percent = models.IntegerField('percentage of visits from Europe', default=-1)
    apac_percent = models.IntegerField('percentage of visits from Asia', default=-1)
    dynamic_content = models.BooleanField('dynamic content?', help_text='Does the domain serve dynamically generated content?', default=False)
    dynamic_content_comments = models.CharField('describe the dynamic content served', blank=True, max_length=255, help_text='How is the dynamic content generated? Is it cacheable?')
    authentication_type = models.BooleanField('authentication needed?', help_text='Does the domain require authentication?', default=False)
    authentication_type_comments = models.CharField('describe authentication', blank=True, max_length=255, help_text='Please describe how authentication is done, if at all.')
    misc_comment = models.CharField('misc comments', blank=True, max_length=255, help_text='List other notes, comments, or features to implement here.  Any notes about PAD checklist should be placed here as well.')
    checklist_comment = models.CharField('checklist comments', blank=True, max_length=255, help_text='List any exceptions or comments on the checklist here.')
    has_customer_edits = models.BooleanField(editable=False, default=False)
    push_status = models.IntegerField('push status', default=0)
    # normal class properties
    cui_size_64k_limit_list = ['pad_aliases','max_age_rules','content_variation_rules','custom_headers','rewrite_rules',
                               'rewrite_rules_post_validation','full_url_rewrite_rules', 'referrer_list','validation_custom_headers','tag_skip_patterns']
    common_view_blacklist = ['dns_refresh_type','dns_entry_existing_time_limit','shielded_service','default_rate','domain_unique_key','custom_param',
                          'customer', 'cdnw', 'large_file_redirect_size', 'cname_dns_zone_record', 'cname_prefix',
                          'upstream_connect_timeout_sec','stat_paths', 'track_urls', 'track_codes', 'skip_sync',
                          'cname_prefix', 'cname_dns_zone_record', 'max_origin_downloads', 'max_master_retries', 'pass_all_headers',
                          'china_lic', 'service', 'wpo_origin', 'wpo_type', 'use_edns_client_subnet', 'use_global_region_rule', 'hide_customer']
    cui_view_blacklist = common_view_blacklist + ['type_flag', 'nonwildcard_hour', 'items_per_request', 'wildcards_per_hour', 'wildcards_per_request',
                          'platform_cd', 'cache_id', 'cookie_exchange_share_cookie','request_log_msg_format', 'all_per_hour']
    api_view_blacklist = common_view_blacklist
    cui_view_whitelist = []
    #these are fields that aren't viewable in the Local Changes while being viewable in Production Site Settings
    cui_edit_blacklist = ['id','auth_key','create_time','modify_time', 'service', 'upstream_timeout_sec', 'user_keep_alive_timeout',
                          'origin_keep_alive_timeout', 'force_ssl', 'max_origin_downloads', 'max_master_retries',
                          'upstream_hash_source', 'origin_record_ttl', 'use_circular_buffer', 'one_validation_per_connection', 'pass_all_headers', 'hide_customer']
    #this is what they can actually change.  This must be modified or field will by default be not editable
    cui_basic_editable_fields = ('pad_aliases', 'origin', 'product', 'status', 'description','backup_origin',)
    papi_basic_editable_fields = ('pad_aliases', 'origin', 'status', 'description','backup_origin',)
    cui_caching_editable_fields = ('strict_nocache_support', 'min_age', 'default_last_modified_date',
                           'force_not_modified_on_ims', 'force_maxage_on_40x', 'default_max_age', 'max_age_rules', 'content_variation_rules',)
    cui_request_response_editable_fields = ('origin_ip', 'origin_port', 'origin_host_header', 'custom_headers',
                                            'honor_byte_range', 'honor_multi_byte_range', 'max_requests_per_keep_alive',
                                            'pass_thru_headers_to_origin', 'accept_setting_from_query_string',
                                            'gzip_compression', 'reverse_proxy_redirect', 'pass_thru_headers_to_user',
                                            'deny_direct_user_request','cookie_exchange', 'use_pad_as_host_header',
                                            'origin_failure_redirect_url','honor_path_range','follow_redirect', 'use_origin_multiple_dns_record', 'use_origin_sticky', 'enable_ssl', 'upstream_ssl',)
    cui_rewrite_rules_editable_fields = ('case_insensitive_urls', 'drop_params', 'rewrite_rules', 'full_url_rewrite_rules',
                           'drop_params_post_validation', 'rewrite_rules_post_validation', 'drop_precise_params_post_validation',
                           'drop_params_in_cache_url', 'drop_precise_params_in_cache_url',)
    cui_validation_editable_fields = ('referrer_list', 'referrer_list_type',
                           'bypass_empty_referrer_check', 'failed_referrer_check_redirect_url', 'validation_scheme',
                           'bypass_validation_on_failure', 'validation_default_redirect_url', 'validation_custom_headers',
                           'validation_nobypass_redirect_url', 'http_auth_user', 'http_auth_password', 'http_auth_type',
                           'tag_check_enabled', 'tag_hash_format_preset', 'tag_hash_format', 'tag_hash_param', 'tag_secret',
                           'tag_time_param', 'tag_time_in_hex', 'tag_time_allowed_sec', 'tag_time_offset_sec', 'tag_skip_patterns',)
    cui_VLF_delivery_editable_fields = ('bps_streaming_limit', 'buffer_secs', 'progressive_dl', 'progressive_dl_param', 'pdseek_default_type',
                           'pdseek_flv_extensions', 'pdseek_h264_extensions', 'use_sub_files',)
    cui_editable_fields = cui_basic_editable_fields + cui_caching_editable_fields + cui_request_response_editable_fields \
                          + cui_rewrite_rules_editable_fields + cui_validation_editable_fields + cui_VLF_delivery_editable_fields

    #API result requires 'product' as readable info not table id.
    papi_editable_fields = papi_basic_editable_fields + cui_caching_editable_fields + cui_request_response_editable_fields \
                          + cui_rewrite_rules_editable_fields + cui_validation_editable_fields + cui_VLF_delivery_editable_fields
    #the key requires the value to be populated in order to be considered enabled for editing/seeing value CUI-side
    cui_conditional_fields = {'referrer_list_type': 'referrer_list',
                    'bypass_empty_referrer_check': 'referrer_list',
                    'failed_referrer_check_redirect_url': 'referrer_list',
                    'bypass_validation_on_failure': 'validation_scheme',
                    'validation_default_redirect_url': 'validation_scheme',
                    'validation_nobypass_redirect_url': 'validation_scheme',
                    'http_auth_password': 'http_auth_user',
                    'http_auth_type': 'http_auth_user',
                    'progressive_dl_param': 'progressive_dl',
                    'pdseek_default_type': 'progressive_dl',
                    'pdseek_flv_extensions': 'progressive_dl',
                    'pdseek_h264_extensions': 'progressive_dl',
                    'tag_hash_format_preset': 'tag_check_enabled',
                    'tag_hash_format': 'tag_check_enabled',
                    'tag_hash_param': 'tag_check_enabled',
                    'tag_secret': 'tag_check_enabled',
                    'tag_time_allowed_sec': 'tag_check_enabled',
                    'tag_time_offset_sec': 'tag_check_enabled',
                    'tag_time_param': 'tag_check_enabled',
                    'tag_time_in_hex': 'tag_check_enabled',
                    'force_ssl': 'enable_ssl'
                }
    cui_edit_fields = ('pad','origin','description','status',)
    #same format as fieldsets
    cui_stat_fields = (
        ('Basic', {'fields':('url_test','mbps_avg','mbps_peak','rps_avg','rps_peak'),}),
        ('Files', {'fields':('files_type','files_count','files_size_avg','files_size_max'),}),
        ('Usage', {'fields':('nam_percent','emea_percent','apac_percent'),}),
        ('Comments', {'fields':('misc_comment'),}),
    )
    cui_stat_thresholds = {
        'mbps_avg': 1000,
        'mbps_peak': 1000,
        'rps_avg': 5000,
        'rps_peak': 5000,
        'files_size_avg': 10000, # KB
        'files_size_max': 1000, # MB
        'apac_percent': 15,
        'dynamic_content': False,
        'authentication_type': False,
        'misc_comment': '',
        'checklist_comment': '',
    }
    cui_diff_excludes = ('sitedraft','push_status','service','shielded_service','has_customer_edits',
                         'checklist_comment','authentication_type','authentication_type_comments',
                         'dynamic_content','dynamic_content_comments','on_hold',
                         'modify_time','create_time','id','site','hide_customer','approval_pending','dns_entry_existing_time_limit',
                         'auth_key','wpo_origin','wpo_type','default_rate','use_edns_client_subnet', 'use_global_region_rule', 'dns_refresh_type',)

    class Meta:
        db_table = 'customer_site_cui'
        ordering = ('pad',)
        app_label = 'oui'

    def save(self, *args, **kwargs):
        if not self.id:
            self.create_time = datetime.now()
        if self.get_site():
            for field in self._meta.fields:
                if field.attname not in ('id','create_time', 'server_action_rules') and \
                                field.attname not in self.cui_editable_fields and hasattr(self.site, field.attname):
                    setattr(self, field.attname, getattr(self.site, field.attname))

        self.modify_time = datetime.now()
        self.has_customer_edits = len(self.local_changes()) > 0
        if not self.id:
            self.nonwildcard_hour = self.customer.nonwildcard_hour
            self.items_per_request = self.customer.items_per_request
            self.all_per_hour = self.customer.all_per_hour
            self.wildcards_per_hour = self.customer.wildcards_per_hour
            self.wildcards_per_request = self.customer.wildcards_per_request
        super(SiteDraft, self).save(*args, **kwargs)

    def __unicode__(self):
        return '%s: %s' % (self.customer.name, self.pad)

    def get_site(self):
        try:
            return self.site
        except Site.DoesNotExist:
            return None

    def get_display_name_for_customer(self):
        return "%s" % self.pad

    def get_pretty_contract_no(self):
        contract_no = None
        if self.product:
            contract_no = self.product.pretty_full_contract_no()
        return contract_no

    def get_product_name(self):
        if self.product:
            return self.product.get_material_type_txt()
        else:
            return None

    def get_additional_values_for_customer(self, info=False):
        result = {}
        try:
            self_implementable = self.is_self_implementable()
            if self_implementable:
                if info and self.is_dwa():
                    result.update({'shield_location':self.shielded_service_id})
            result.update({'self_implementable': self_implementable})
            result.update({'deploy_status': self.get_pad_status()})
            result.update({'product': self.get_pretty_contract_no()})
        except Exception,e:
            raise e
        return result

    def is_new(self):
        return not self.get_site()

    def need_high_rps_approval(self):
        try:
            if self.is_self_implementable():
                return False
            else:
                return self.rps_avg > 5000
        except:
            return False

    def local_changes(self):
        changed = []
        if self.get_site():
            for field in self.cui_editable_fields + ('server_action_rules', ):
                if getattr(self, field) != getattr(self.get_site(), field) and (getattr(self, field) not in [None, ""] or getattr(self.get_site(), field) not in [None, ""]):
                    changed.append(field)
        return changed

    def get_pad_status(self):
        site = self.get_site()
        if self.push_status ==0:
            if self.approval_pending ==0:
                if not site:
                    return DEPLOY_STATUS_NEW
                else:
                    if site.status == 0:
                        return DEPLOY_STATUS_DISABLED
                    else:
                        if self.has_customer_edits:
                            return DEPLOY_STATUS_CHANGED
                        else:
                            return DEPLOY_STATUS_SELF_PROD
            else:
                return DEPLOY_STATUS_WAITING_REQ
        elif self.push_status == 1:
            return DEPLOY_STATUS_SELF_PUSHING_STAGE
        elif self.push_status == -2:
            return DEPLOY_STATUS_SELF_FAIL_STAGE
        elif self.push_status == 2:
            return DEPLOY_STATUS_SELF_STAGE
        elif self.push_status == 3:
            return DEPLOY_STATUS_SELF_PUSHING_PROD
        elif self.push_status == -4:
            return DEPLOY_STATUS_SELF_FAIL_PROD
        elif self.push_status == 4:
            if site and site.status == 0:
                return DEPLOY_STATUS_DISABLED
            else:
                return DEPLOY_STATUS_SELF_PROD

    def get_deploy_status_dict(self, is_for_customer=True):
        """
        return pad deploy status info
        :param is_for_customer: customer open api call
        :return:
        """
        result_item = {}
        if is_for_customer:
            result_item.update({'pad': self.pad})
        else:
            result_item.update({'pad': str(self)})
        deploy_status = self.get_pad_status()
        result_item.update({'deploy_status':deploy_status})
        completion_rate, ok_list, total_list = self.get_push_completion_rate()
        result_item.update({'push_completion_rate': completion_rate})
        if not is_for_customer or self.push_status ==2:
            result_item.update({'test_nodes': self.get_all_staging_nodes(ok_list, total_list, is_for_customer)})
        else:
            result_item.update({'test_nodes': []})
        msg, display_message = self.get_push_error_message()
        result_item.update({'error_message':display_message})
        if not is_for_customer:
            result_item.update({'raw_error': msg})
        result_item.update({'comment':self.get_deploy_comment(completion_rate)})
        return result_item

    def get_default_approve_comment(self):
        site = self.get_site()
        if site and site.cname_dns_zone_record:
            implement_cname = """We have also included the CNAME record you will need to use for your DNS configuration. The DNS changes can take up to 24 hours to propagate throughout the Internet once completed by you.\n\nThe next step is to CNAME the %s to "%s.%s".\n\nThis step allows your content to be served over the CDNetworks service.""" % \
                              (self.pad, self.pad, site.cname_dns_zone_record.domain_name)
        else:
            implement_cname = ''

        comment = """Dear %s,\n\nThis email is to let you know we have completed your PAD implementation and sent you all the information needed to support your existing PADs with CDNetworks. This implementation should be propagated throughout our network within 10-15 minutes.\n\n%s Should you have any issues with this step, please contact our support center.
\n%s""" % (self.customer.get_display_name(), implement_cname, SUPPORT_CENTER )
        return comment

    def get_deploy_comment(self, completion_rate):
        """
        push completion rate is not accurate if push history is not found
        user need to know
        :return:
        """
        comment = ''
        site = self.get_site()
        history = self._get_latest_push_history()
        try:
            completion_rate = int(float(completion_rate))
        except:
            completion_rate = 0

        if self.push_status == 4:
            if site and history is None:
                comment = "No push histories. PAD may have been created by operator."
            else:
                if completion_rate == 0:
                    comment = "PAD validation completed and started to be deployed to production nodes."
                elif completion_rate == 100:
                    comment = "PAD has been deployed all production nodes."
        elif self.push_status == 2:
            if completion_rate == 0:
                comment = "PAD validation completed and started to be deployed to test nodes. On test nodes where deploy is completed, staging test is enabled."
            elif completion_rate == 100:
                comment = "PAD has been deployed all test nodes."
            if self.is_ssl():
                comment = "This is an SSL enabled PAD, which might be expired for testing at staging nodes after '%s'. %s" % (str(self.get_estimated_stage_expire_time()), comment)
        elif self.push_status in [1,3]:
            comment = "Validating PAD configuration. The PAD is not editable until the job is done."
        elif self.push_status == -2:
            comment = "Validation failed. Please check error message info for more detail."
        elif self.push_status == -4:
            comment = "Validation failed. Please check error message info for more detail."

        return comment

    def get_estimated_stage_expire_time(self):
        try:
            site_stage = SiteStage.objects.get(sitedraft=self)
            return site_stage.modify_time + timedelta(hours=SSL_STAGING_EDGE_CLEANUP_INTERVAL)
        except:
            from ci.common.models.pusher import ConfigPushRequestHistory
            push_histories = ConfigPushRequestHistory.objects.filter(site_draft=self,
                                                                   config_group='HTTP_SITES',
                                                                   config_type='CFGT').order_by('-config_push_request_history')
            if push_histories.exists():
                return push_histories[0].create_time + timedelta(hours=SSL_STAGING_EDGE_CLEANUP_INTERVAL)
            else:
                if self.push_status == 2:
                    return self.modify_time + timedelta(hours=SSL_STAGING_EDGE_CLEANUP_INTERVAL)
                else:
                    #TODO: check if this case exists
                    return self.modify_time + timedelta(hours=SSL_STAGING_EDGE_CLEANUP_INTERVAL)


    def is_production_deploy_completed(self):
        """
        push result could be success or failure
        :return:
        """
        return self.push_status in [-4, 4]

    def is_publish_failed(self):
        return self.push_status == -4

    def get_push_status(self):
        return self.get_pad_status()

    def is_staging_pushable(self):
        if self.push_status in [0, 1, -2]:
            return True
        else:
            return False

    def is_production_pushable(self):
        if self.push_status in [2, 3, -4]:
            return True
        else:
            return False

    def too_long_push_waiting(self):
        if self.push_status not in [1, 3]:
            return False
        if self.modify_time + timedelta(minutes=10) > datetime.now():
            return False
        else:
            return True

    def is_matched_with_pad_aliases_and_wildcard(self, netloc):
        """
        pad aliases:
        validate url input is matched with PAD alias or wild card PAD name
        :param netloc: network location part. hostname part of url
        :return:
        """
        if netloc.strip() == self.pad.strip():
            return True

        if netloc.strip() in self.pad_aliases.replace("\r\n","\n").split("\n"):
            return True

        rx_string = r'(?:^|\s)(\w+\.)?' + self.pad.replace('.', '\.')[3:] + '(?:$|\s)'
        regex = re.compile(rx_string)
        if regex.match(netloc.strip()):
            return True

        return False

    def fetch_trace_internal_result(self, url, additional_headers='', filename='', file_contents='', ipv4=None):
        """
        trace internal test
        :param uri: full url
        :param additional_headers: headers
        :param filename: attached file
        :param file_contents: attached file contents
        :param ipv4: ipaddress of edge node to test
        :param protocol: http or https
        :return:
        """
        from ci.common.utils.misc import full_cdn_hostname
        from ci.common.utils.api.site import trace_internal_request
        error = ''
        result = ''
        raw_result = ''

        try:
            if not url.lower().startswith('http'):
                url = "http://%s" % url
            url_info = urlparse(url)
            if url_info.netloc == '':
                error = "Invalid URL input. URL Network location part missing."
                raise Exception(error)
            else:
                if not self.is_matched_with_pad_aliases_and_wildcard(url_info.netloc):
                    error = "Invalid URL input. Hostname of URL does not match with PAD '%s' or PAD aliases." % self.pad
                    raise Exception(error)
        except Exception,e:
            if len(error) == 0:
                error = "Invalid URL input format. %s" % str(e)
            return error, result, raw_result, '', ipv4

        hostname, ipaddr = self.get_testable_staging_node(ipv4)
        if hostname == '':
            if ipv4:
                error = "IP address '%s' is not testable node for PAD '%s'." % (ipv4, str(self))
            else:
                error = "PAD '%s' is in '%s' status but has no available test nodes. Configuration may have not been completely deployed to edges yet." % \
                    (str(self), self.get_pad_status())
        else:
            hostname = full_cdn_hostname(hostname)
            extra_headers = None
            try:
                post_data = [('url',url),('header',additional_headers)]
                error, result, raw_result = trace_internal_request(hostname, post_data, extra_headers, filename, file_contents)
            except Exception,e:
                error = "Failed to parse staging test result. Please contact Support Center"
        return error, result, raw_result, hostname, ipaddr

    def display_push_button(self):
        if self.is_self_implementable():
            return_status = 'none'
            if self.is_production_pushable():
                return_status = 'prod'
            elif self.is_staging_pushable():
                return_status = 'staging'
        else:
            if not self.get_site():
                return_status = 'req'
            else:
                if self.has_customer_edits:
                    return_status = 'req'
                else:
                    return_status = 'none'

        return return_status

    def get_mapped_service(self,config_type):
        """
        if draft push_status is in staging, return stage edge service
        :return:
        """
        try:
            if config_type is not None and config_type == 'CFGT':
                stage_draft = SiteStage.objects.get(sitedraft=self)
                return stage_draft.service
            else:
                if self.get_site():
                    return self.get_site().service
                else:
                    return None
        except SiteStage.DoesNotExist:
            return None


    def get_mapped_shield_service(self,config_type):
        """
        if draft push_status is in staging, return stage shield service
        :return:
        """
        try:
            if config_type is not None and config_type == 'CFGT':
                stage_draft = SiteStage.objects.get(sitedraft=self)
                return stage_draft.shielded_service
            else:
                if self.get_site():
                    return self.get_site().shielded_service
                else:
                    return None
        except SiteStage.DoesNotExist:
            return None

    def get_related_ngp_hostname_list(self, config_type):
        """
        should be available only when draft push status is ready(2 or 4)
        get hosts of related edge/shield.
        :return:
        """
        host_list = []

        edge_service = self.get_mapped_service(config_type)
        if edge_service:
            host_list = edge_service.get_related_ngp_hostname_list()

        shielded_service = self.get_mapped_shield_service(config_type)
        if shielded_service:
            host_list += shielded_service.get_related_ngp_hostname_list()
        return host_list

    def is_modifiable(self):
        return self.push_status not in [1,3]

    def is_waiting_implementation(self):
        return self.get_pad_status() == DEPLOY_STATUS_WAITING_REQ

    def is_deletable(self):
        pad_status = self.get_pad_status()
        if pad_status in [DEPLOY_STATUS_NEW]:
            return True
        elif pad_status in [DEPLOY_STATUS_SELF_FAIL_STAGE,DEPLOY_STATUS_SELF_STAGE,DEPLOY_STATUS_SELF_FAIL_PROD]:
            if not self.site:
                return True
        elif pad_status in [DEPLOY_STATUS_DISABLED]:
            return True
        return False

    def save_as_modified(self):
        self.push_status = 0
        self.save()

    def get_pad_change_event_mail_customer_subscribers(self):
        return self.customer.get_email_recipients(self)

    def get_pad_change_event_operator_subscribers(self, event_id, implementer=None):
        from ci.django_mailer.models import Subscriber
        result_list = []
        try:
            if self.approval_pending or implementer:
                recipients = Subscriber.objects.filter(corp_code=self.customer.corp_code, event_id=event_id).values_list('email', flat=True)
                result_list = list(recipients)

            if result_list:
                pass
            else:
                #if implementer:
                #    result_list.append(implementer.email)
                #else:
                result_list.append(NO_REPLY)
        except Exception,e:
            pass
        return result_list

    def get_adjustment_message(self):
        """
        function to find out if the related customer receives any billing adjustments (e.g.: shielding,logging, etc.)
        or is using REST service on any of their PAD's
        :return:
        """
        adj_set=self.customer.customer_adjustment_set.filter(Q(description__icontains='shield') | Q(description__icontains='storage'))
        customer_flag = ''
        if adj_set:
            customer_flag= u'This customer uses the following service(s): '
            for adj in adj_set:
                customer_flag += u'%s, ' % adj.description
        if self.customer.site_set.filter(auth_key__gt='').count():
            if customer_flag:
                customer_flag += u'REST web service, '
            else:
                customer_flag = u'This customer uses REST web services.  '
        if self.customer.site_set.filter(status=True).filter(request_log_msg_format__gt='').count():
            if customer_flag:
                customer_flag += u'full logging service. '
            else:
                customer_flag += u' This customer uses full logging on one of their PADs.  '

        if self.site and self.site.aggregate_set.count() > 0:
            customer_flag += u'\nThis PAD uses aggregate logs, Please do not add any URL manipulation rules without first contacting SUPPORT Engineers. '
        if customer_flag:
            return customer_flag[:-2] #if cust_flag else None
        else:
            return None

    def get_related_contracts(self):
        contracts = None
        #contracts = self.customer.get_active_contracts()
        if self.product:
            contracts = self.product.get_related_contracts()
        else:
            contracts = None
        return contracts

    def _get_message_for_self_implementations(self, title, comments, diff_site=None, implementer=None, display_cust_flags=True):
        from ci.common.utils.site import getFieldsFromFieldset, settings_tuple, name_and_email
        message_list = []
        if self.is_self_implementable():
            cui_edit_fields_set = set(SiteDraft.cui_edit_fields)
            message_for_customer = self.get_adjustment_message() if display_cust_flags else None
            if message_for_customer:
                message_list.append("")
                message_list.append("Note: %s " % message_for_customer)

            contracts = self.get_related_contracts()
            if contracts:
                message_list.append("")
                message_list.append("Related Product:")
                for contract_dict in contracts:
                    try:
                        cop_product_id = contract_dict.keys()[0]
                        product = Product.objects.get(cop_product_id=cop_product_id)
                        material_name = product.get_material_type_txt()
                        material_desc = contract_dict.values()[0].get('meterial_desc','')
                        service_type_txt = contract_dict.values()[0].get('service_type_txt')
                        message_list.append("%s %s %s %s" % (cop_product_id, material_name, material_desc, service_type_txt))
                    except Exception,e:
                        pass

            message_list.append("")
            message_list.append("Basic PAD settings:")
            for name in SiteDraft.cui_edit_fields:
                verbose_name, value, help_text, diff, flag = settings_tuple(self, name, diff_row = diff_site)
                message = "%(stars)s%(name)s: %(value)s%(stars)s " % {'name':verbose_name, 'value':value, 'stars':' * ' if diff else ''}
                message_list.append(message)
            if diff_site:
                changed_messages = []
                for name in getFieldsFromFieldset(SiteDraft.fieldsets, SiteDraft.cui_view_blacklist + SiteDraft.cui_edit_blacklist):
                    if cui_edit_fields_set.issuperset([name]):
                        continue
                    verbose_name, value, help_text, diff, flag = settings_tuple(self, name, diff_row = diff_site)
                    if diff:
                        message = "%(stars)s%(name)s: %(value)s%(stars)s " % {'name':verbose_name, 'value':value, 'stars':' * ' if diff else ''}
                        changed_messages.append(message)
                if changed_messages:
                    message_list.append("")
                    message_list.append("Changed PAD settings:")
                    message_list += changed_messages
            elif implementer:
                message_list.append("")
                message_list.append("The complete list of PAD settings are viewable in the portal.")
        else:
            return self._get_message_for_request_implementation(title, comments, diff_site, implementer, display_cust_flags)

        return message_list

    def _get_message_for_request_implementation(self, title, comments, diff_site=None, implementer=None,display_cust_flags=True):
        from ci.common.utils.site import getFieldsFromFieldset, settings_tuple, name_and_email
        message_list = []
        if self.is_self_implementable():
            return self._get_message_for_self_implementations(title, comments, diff_site,implementer, display_cust_flags)
        else:
            message_for_customer = self.get_adjustment_message() if display_cust_flags else None
            if len(comments) > 0:
                message_list.append("")
                message_list.append(comments)
            if self.need_high_rps_approval() and self.approval_pending and not self.site:
                message_list.append("THIS REQUEST REQUIRES APPROVAL FROM THE SERVICE DELIVERY TEAM DUE TO HIGH RPS.")
            if not self.site and self.cache_id:
                message_list.append("This draft was copied from an existing PAD that uses aPAD ID to tag content. "
                                    "Please check with the customer whether they want to also share content between those PADs or only duplicate the settings.")

            cui_edit_fields_set = set(SiteDraft.cui_edit_fields)
            cui_stat_fields = getFieldsFromFieldset(SiteDraft.cui_stat_fields)
            cui_stat_fields_set = set(cui_stat_fields)

            if message_for_customer:
                message_list.append("")
                message_list.append("Note: %s " % message_for_customer)
            contracts = self.get_related_contracts()
            if contracts:
                message_list.append("")
                message_list.append("Related Product:")
                for contract_dict in contracts:
                    try:
                        cop_product_id = contract_dict.keys()[0]
                        product = Product.objects.get(cop_product_id=cop_product_id)
                        material_name = product.get_material_type_txt()
                        material_desc = contract_dict.values()[0].get('meterial_desc','')
                        service_type_txt = contract_dict.values()[0].get('service_type_txt')
                        message_list.append("%s %s %s %s" % (cop_product_id, material_name, material_desc, service_type_txt))
                    except Exception,e:
                        pass

            message_list.append("")
            message_list.append("Basic PAD settings:")
            for name in SiteDraft.cui_edit_fields:
                verbose_name, value, help_text, diff, flag = settings_tuple(self, name, diff_row = diff_site)
                message = "%(stars)s%(name)s: %(value)s%(stars)s " % {'name':verbose_name, 'value':value, 'stars':' * ' if diff else ''}
                message_list.append(message)

            if diff_site:
                changed_messages = []
                for name in getFieldsFromFieldset(SiteDraft.fieldsets, SiteDraft.cui_view_blacklist + SiteDraft.cui_edit_blacklist):
                    if cui_stat_fields_set.issuperset([name]) or cui_edit_fields_set.issuperset([name]):
                        continue
                    verbose_name, value, help_text, diff, flag = settings_tuple(self, name, diff_row = diff_site)
                    if diff:
                        message = "%(stars)s%(name)s: %(value)s%(stars)s " % {'name':verbose_name, 'value':value, 'stars':' * ' if diff else ''}
                        changed_messages.append(message)
                if changed_messages:
                    message_list.append("")
                    message_list.append("Changed PAD settings:")
                    message_list += changed_messages
            elif implementer:
                message_list.append("")
                message_list.append("The complete list of PAD settings are viewable in the portal.")
            message_list.append("")
            message_list.append("Site Statistics:")
            for name in cui_stat_fields:
                verbose_name, value, help_text, diff, flag = settings_tuple(self, name)
                message = "%(stars)s%(name)s: %(value)s%(stars)s " % {'name':verbose_name, 'value':value, 'stars':' * ' if diff else ''}
                message_list.append(message)
                if flag and name == 'url_test':
                    for error in flag:
                        message_list.append("\t%s" % error)
            try:
                if implementer:
                    message_list.append("")
                    message_list.append("Implementer: %s" % name_and_email(implementer))
            except:
                pass

        return message_list

    def get_pad_change_event_mail_subject_by_event_id(self, event_id, subject=None):
        """
        subject will be overridden unless event_id is 0
        :param event_id:
        :param subject:
        :return:
        """
        if subject is None or len(subject) == 0:
            if event_id == REQUEST_PAD:
                subject = u"PAD implementation request"
            elif event_id == CANCEL_REQUEST_PAD:
                subject = u"PAD implementation request canceled"
            elif event_id == APPROVE_REQUEST_PAD:
                subject = u"PAD implementation request approved"
            elif event_id == DENY_REQUEST_PAD:
                subject = u"PAD implementation request denied"
            elif event_id == PUBLISH_PAD_TO_PRODUCTION:
                subject = u"PAD has been published to production"
            elif event_id == RECOVER_PAD_TO_PRODUCTION:
                subject = u"PAD has been recovered to production"
            else:
                subject = u"An undefined mail event has happened"
        try:
            subject = u"%s for %s %s" % (subject, self.customer.get_display_name(), self.pad)
        except Exception,e:
            pass
        return subject

    def get_pad_change_event_mail_body_contents(self, title, comments, operator_receiver = [], customer_receiver=[],
                                                implementer=None, display_cust_flags=True, debug=False):
        #from django.template.loader import render_to_string
        from ci.constants import ENVIRONMENT
        message_list = []
        debug_message = ''
        if debug or ENVIRONMENT in ['local','qa']:
            debug_message = u"[TEST MAIL] This email is intended to be sent to operator user:%s, customer user:%s" % \
                            (operator_receiver, customer_receiver)
            message_list.append(debug_message)
            message_list.append("")
        message_list.append(title)
        #message_list.append("PAD deploy status: %s" % (self.get_pad_status()))

        diff_site = self.get_site()
        if diff_site is None:
            diff_site = Site(customer=self.customer)

        if not diff_site.status:
            message_list.append(u"PAD has been disabled.")

        if self.is_self_implementable():
            message_list += self._get_message_for_self_implementations(title=title,
                                                                     comments=comments,
                                                                     diff_site=diff_site,
                                                                     implementer=implementer,
                                                                     display_cust_flags=display_cust_flags)

        else:
            message_list += self._get_message_for_request_implementation(title=title,
                                                                       comments=comments,
                                                                       diff_site=diff_site,
                                                                       implementer=implementer,
                                                                       display_cust_flags=display_cust_flags)

        #temp_body = render_to_string("email/customer_email_template.html", {'title':title,
        #                                                    'domain':"control.cdnetworks.com",  # has email
        #                                                    'contents':body})
        if debug:
            return message_list
        else:
            return u"\n".join(message_list)

    def request_implement_pad(self, username, email, comment=None, is_urgent=False, implement_cancel=False):
        message = ''
        warning_msg = ''
        error_msg = ''
        confirm_flush = False
        comments = []
        pad_status = self.get_pad_status()
        try:
            if not implement_cancel:
                if pad_status == DEPLOY_STATUS_WAITING_REQ:
                    message="Your PAD is already in '%s'." % DEPLOY_STATUS_WAITING_REQ
                    return message, warning_msg, error_msg

            if self.product and not self.product.active:
                error_msg = "Product is expired. If you want to proceed, please contact support center."
                return message, warning_msg, error_msg
            from ci.common.utils.site import send_implementation_email, save_site_change_history
            if not self.get_site() and (self.cache_id or self.domain_unique_key or self.origin_host_header):
                warning_msg = u"The PAD you duplicated will share the same content with this new PAD. " \
                            u"If this was not intended, " \
                            u"please let us know in the comments section of the implementation request \n"

            if self.get_site() and self.cache_group() != self.site.cache_group():
                confirm_flush = True
                warning_msg +="Implementing your new value of '%s' will result in discarding all the cached content for this PAD " \
                              "and all PADs that share content with it and refetching it from origin." % self.cache_group()

            product_name = self.get_product_name()
            if product_name:
                comments.append("This request is for a %s domain\n" %(product_name))

            if comment:
                comments.append("Request comments:")
                comments.append(comment)
                comments.append("")
            if len(warning_msg) > 0:
                comments.append("warning:")
                comments.append(warning_msg)

            self.approval_pending = not implement_cancel
            self.save_as_modified()

            subject = 'PAD implementation request%s' % (' canceled' if implement_cancel else '')
            event_id = CANCEL_REQUEST_PAD if implement_cancel else REQUEST_PAD
            worker_email = email if not username else username
            try:
                # urgency disabled per CUI-124
                send_implementation_email(subject, "\n".join(comments), self, urgent=is_urgent,
                                          worker_email=worker_email, event_id=event_id)
            except:
                subject = "Failed to send confirmation email. %s" % subject
            save_site_change_history(sitedraft=self,
                                     username=worker_email,
                                     ops_type=1,
                                     description=subject)
            if not implement_cancel:
                message="Your PAD implementation request has been successfully submitted. " \
                        "Typically PAD implementation requests are filled within 2 hours during business hours."
            else:
                message="Your cancel request for PAD implementation has been successfully submitted."
            message = "%s PAD status:%s" % (message.strip(), self.get_pad_status())
        except OperationalError, e:
            error_msg = get_db_operation_error_message(e)
        except Exception,e:
            error_msg = "Unknown Error"

        return message, warning_msg, error_msg

    def cancel_request_implement(self,username, email, comment=None, is_urgent=False):
        message = ''
        warning_msg = ''
        error_msg = ''
        if self.product and not self.product.active:
            error_msg = "Product is expired. If you want to proceed, please contact support center."
        if self.get_pad_status() == DEPLOY_STATUS_WAITING_REQ:
            message, warning_msg, error_msg = self.request_implement_pad(username,email,comment,
                                                                         is_urgent=is_urgent, implement_cancel=True)
        else:
            error_msg = "The PAD is not in '%s' status." % DEPLOY_STATUS_WAITING_REQ
        return message,warning_msg,error_msg

    def is_self_implementable(self, product=None):
        """
        return product's self_implementable property
        :param product: if product is none, it means request implementation call
        :return:
        """
        if self.pk and self.get_site():  # edit status
            return self.product.is_self_implemetation_on()
        else:  # add status
            _product = self.product or product
            if _product:
                return _product.is_self_implementable()
            else:
                return False


    def is_ssl(self, product=None):
        return self.is_ssl_contract(product) and self.enable_ssl

    def is_ssl_contract(self, product=None):
        if self.pk and self.get_site():
            return self.product.is_ssl_contract()
        else:
            if self.product:
                return self.product.is_ssl_contract()
            else:
                if product:
                    return product.is_ssl_contract()
                else:
                    return False

    def is_dwa(self, product=None):
        if self.pk and self.get_site():
            return self.product.is_dwa_contract()
        else:
            if self.product:  # may be in staging or draft local save status
                return self.product.is_dwa_contract()
            else:  # add status
                if product:
                    return product.is_dwa_contract()
                else:
                    return False

    def push_to_staging(self, username, description=""):
        """
        1.edge service, shield service mapping
        2.SiteStage save
        3.update push status
        4.add to push_request_history
        :return:
        """
        if not self.is_self_implementable():
            raise Exception('This PAD is not self implementable but needs approval of operator.')

        if not self.product or not self.customer:
            raise Exception("Customer or product not set for PAD %s" % self.pad)

        if not self.product.active:
            raise Exception("Product is expired. If you want to proceed, please contact support center.")

        if not self.is_staging_pushable():
            raise Exception("PAD is not allowed to be pushed to staging yet. Deploy status is in '%s'" %
                            self.get_push_status())

        if not self.status and not self.get_site(): #first time to be deployed. not in production.
            raise Exception("PAD status is inactive. Please set status active in order to deploy configuration.")

        try:
            sitestage = self.sitestage
        except SiteStage.DoesNotExist:
            sitestage = SiteStage()
        sitestage.push_to_staging(self)  # change SiteStage table data only...
        self.push_status = 1
        self.save()
        # save request_push_history

        try:
            from ci.common.models.site_history import CustomerSiteChangeHistory
            latest_site_history = CustomerSiteChangeHistory.objects.filter(sitedraft=self).order_by('-pk')[:1][0]
            history_revision = latest_site_history.version
        except:
            history_revision = 0
        self.push_and_save_history(phase=1, username=username, description=description, is_staging=True, history_revision=history_revision)

    def push_to_production(self, username, request=None, description=""):
        """
        1.edge service, shield service mapping
        2.Site save
        3.update push status
        4.add to push_request_history
        :return:
        """
        if not self.is_self_implementable():
            raise Exception('This PAD is not self implementable but needs approval of operator.')

        if self.product and self.customer:
            if not self.product.active:
                raise Exception("Product is expired. If you want to proceed, please contact support center.")

            if not self.is_production_pushable():
                raise Exception("PAD is not ready to be published to production yet. Deploy status should be one of %s. Deploy status:'%s'" %
                                (str(PRODUCTION_READY), self.get_push_status()))

            site = self.get_site()
            if not site:
                try:
                    site = Site.objects.get(pad=self.pad)
                except Site.DoesNotExist:
                    site = Site(customer=self.customer)

            self.site = site.push_to_production(self)  # change Site table data only...
            self.push_status = 3
            self.save()

            if request is not None:
                pad_list = request.session.get('aurora_restrict_pads')
                if self.get_site().pk not in pad_list:
                    pad_list.append(self.site.pk)
                    request.session['aurora_restrict_pads'] = pad_list

            # save request_push_history
            try:
                from ci.common.models.site_history import CustomerSiteChangeHistory
                latest_site_history = CustomerSiteChangeHistory.objects.filter(sitedraft=self).order_by('-pk')[:1][0]
                history_revision = latest_site_history.version
            except:
                history_revision = 0
            self.push_and_save_history(phase=3, username=username, description=description, is_staging=False,
                                       history_revision=history_revision)

            self.send_publish_event_mail(worker_email=username)

        else:
            raise Exception('customer or product not set for pad %s' % self.pad)

    def send_publish_event_mail(self, worker_email):
        event_id = PUBLISH_PAD_TO_PRODUCTION
        subject = "PAD has been pushed to production"
        comments = "PAD has been pushed to production"
        try:
            from ci.common.utils.site import send_implementation_email
            send_implementation_email(subject, "\n".join(comments), self, worker_email=worker_email, event_id=event_id)
        except:
            subject = "Failed to send email. %s" % subject

    def push_and_save_history(self, phase, username, description=None, is_staging=True, history_revision=0):
        """
        :param phase Push Phase 1 : Stage, 3 : Production
        """
        from ci.common.utils.pusher import request_push, NGP_BEPusher

        bepusher = NGP_BEPusher()
        if phase == 1:
            phase = "SITESNG"
        elif phase == 3:
            phase = "SITESNG"
        else:
            return False
        be_request_push = bepusher.push(phase=phase,
                                        site_draft_id=self,
                                        request_user=username,
                                        description=description,
                                        is_staging=is_staging,
                                        history_revision=history_revision)

        return be_request_push

    def _get_latest_push_history(self):
        """
        get latest action id from config_push_request_history in order to get error message from ngp config_dist_action
        :return:
        """
        from ci.common.models.pusher import ConfigPushRequestHistory
        push_histories = ConfigPushRequestHistory.objects.filter(site_draft=self).order_by('-config_push_request_history')[:1]
        if push_histories.exists():
            return push_histories[0]
        else:
            return None

    def _get_latest_production_push_histories(self, create_time=None):
        """
        get latest action id from config_push_request_history in order to get error message from ngp config_dist_action
        :return:
        """
        from ci.common.models.pusher import ConfigPushRequestHistory
        if create_time:
            push_histories = ConfigPushRequestHistory.objects.filter(site_draft=self,
                                                                 create_time__gte=create_time,
                                                                 config_type='CFG').order_by('-config_push_request_history')
        else:
            push_histories = ConfigPushRequestHistory.objects.filter(site_draft=self,
                                                                 config_type='CFG').order_by('-config_push_request_history')
        return push_histories

    def get_pad_id(self, push_level):
        """
        need to parse cs thrown error message dict
        :return:
        """
        try:
            if push_level == 'Staging':
                site_stage = SiteStage.objects.get(sitedraft=self)
                return site_stage.pk
            else:
                return self.get_site().pk
        except SiteStage.DoesNotExist:
            return None
        except:
            return None

    def get_push_completion_rate(self):
        """
        by caching response result from config api, let's protect config api from high loads of requests
        result is string not integer '0.0', '0.00' means deployment has started. '0' means no push hostory found.
        :return: result, ok_list, total_list
        """
        result = '0'
        ok_list = []
        total_list = []
        if int(self.push_status) in [2,4]:
            history = self._get_latest_push_history()
            if history:
                cache_key = "config_api_push_rate_%s_%s" % (str(self.pk), str(history.pk))
                result_dict = cache.get(cache_key)
                if result_dict is None:
                    result_dict = history.get_valid_push_result_item()
                    cache.set(cache_key, result_dict, 3) #3 seconds of ttl
            else:
                result_dict = {}
            if history is None and int(self.push_status) == 4: #PAD had been deleted and recovered by operator
                result = '100'
            else:
                if history.site_draft == self:
                    result, ok_list, total_list = history.get_push_completion_rate(result_dict)
        return result, ok_list, total_list

    def get_push_error_message(self):
        parsed_msg = ''
        display_msg = ''
        if int(self.push_status) in [-2,-4]:
            history = self._get_latest_push_history()
            if history:
                result_dict = history.get_valid_push_result_item()
            else:
                result_dict = {}

            if history and history.site_draft == self:
                parsed_msg, display_msg = history.get_parsed_status_message({history.pk:result_dict})

            if not display_msg:
                display_msg = 'Failed to push for uncertain reason. Please contact support center.'
            return parsed_msg, display_msg
        return parsed_msg, display_msg

    def get_site_stage(self):
        try:
            return self.sitestage
        except SiteStage.DoesNotExist:
            return None

    def get_all_staging_nodes(self, ok_list=None, total_list=None, is_for_customer=False):
        """
        if site stage or service does not exist, where edge service mapping can be invalidated, return empty list
        :param ok_list:
        :param total_list:
        :param is_for_customer:
        :return:
        """
        result_list = []
        if ok_list is None or total_list is None:
            completion_rate, ok_list, total_list = self.get_push_completion_rate()
        if self.push_status == 2:
            try:
                sitestage = self.get_site_stage()
                if sitestage:
                    result_list = sitestage.service.get_ip_host_list(ok_list=ok_list, is_for_customer=is_for_customer)
            except Exception,e:
                pass
        elif self.push_status == 4:
            try:
                site = self.get_site()
                if site:
                    result_list = site.service.get_ip_host_list(ok_list=ok_list, is_for_customer=is_for_customer)
            except Exception,e:
                pass
        return result_list

    def has_testable_staging_node(self):
        return self.get_pad_status() == 'On Staging' and len(self.get_testable_staging_nodes()) > 0

    def get_testable_staging_nodes(self, ok_list=None, total_list=None, is_for_customer=False):
        result_list = []
        staging_node_list = self.get_all_staging_nodes(ok_list, total_list, is_for_customer)
        for staging_node in staging_node_list:
            if staging_node.get('deploy_status') == 'deployed':
                result_list.append(staging_node)

        return result_list

    def get_testable_staging_node(self, ipv4=None):
        result= ''
        ipaddr = ipv4 if ipv4 is not None else ''
        try:
            if self.push_status == 2:
                node_item_list = self.get_all_staging_nodes()
                for node_item in node_item_list:
                    ipaddr = node_item.get('ip')
                    node_status = node_item.get('deploy_status')
                    hostname = node_item.get('hostname')
                    if node_status == 'deployed':
                        if ipv4:
                            if ipaddr == ipv4:
                                return hostname, ipaddr
                        else: #return default hostname, ipaddr
                            return hostname, ipaddr
        except:
            pass
        return result, ipaddr

    def toJSON(self):
        site = {}
        fields = list(set(self.cui_editable_fields)) + ['shielded_service', 'server_action_rules']
        for field in fields:
            try:
                value = getattr(self, field)
                if field in ['product', 'shielded_service'] and getattr(self, field):
                    value = getattr(self, field).pk
                site[field] = str(value)
            except:
                continue
        try:
            ret = json.dumps(site)
        except:
            ret = json.dumps({})
        return ret

    def restore_from_snapshot(self, snapshot_version, username, site_history=None):
        """
        restore to snapshot_version and return result error and message
        :param snapshot_version:
        :param username: aurora user name
        :return:
        """
        from ci.common.models.cache import ShieldedService
        from ci.common.utils.site import save_site_change_history
        error = ''
        message = ''
        is_updated = False

        pad_status = self.get_pad_status()
        if not self.is_modifiable():
            error = "Not supported. PAD is in pending status. %s" % pad_status
        if self.is_waiting_implementation():
            error = "Not supported. PAD is in %s" % pad_status

        if not site_history:
            from ci.common.models.site_history import CustomerSiteChangeHistory
            try:
                site_history = CustomerSiteChangeHistory.objects.get(sitedraft=self.pk, version=int(snapshot_version))
                if not site_history.is_restore_enabled():
                    error = "This version is not able to restore."
            except CustomerSiteChangeHistory.DoesNotExist:
                error = "PAD version to restore %s does not exist." % str(snapshot_version)

        if len(error) == 0:
            pad_config_snapshot = json.loads(site_history.customersitesnapshot.config_diff)
            if isinstance(pad_config_snapshot, dict):
                for attr, value in pad_config_snapshot.iteritems():
                    if hasattr(self, attr):
                        is_updated = True
                        if attr == 'product':
                            try:
                                value = Product.objects.get(pk=value)
                            except:
                                continue
                        if attr in ['shielded_service', 'shield_location']:
                            try:
                                value = ShieldedService.objects.get(pk=value)
                            except:
                                continue
                        if value == 'None':
                            value = None
                        if value == 'True':
                            value = True
                        if value == 'False':
                            value = False
                        setattr(self, attr, value)
            else:
                raise TypeError

        if is_updated:
            #status should be changed to 'New' or 'Changed', 'disabled' if status is inactive and correspondent site exists
            self.save_as_modified()
            message = u"PAD configuration has been restored to version: %s." % str(snapshot_version)
            save_site_change_history(sitedraft=self,
                                     username=username, ops_type=2,
                                     description='restored from version %s' % str(snapshot_version))

        else:
            message = u"PAD configuration has not changed (version : %s)" % str(snapshot_version)

        return error, message

class SiteStage(AbstractSite):
    #draft_id = models.IntegerField('Draft ID', db_column='customer_site_cui_id')
    id = models.AutoField('Site ID', primary_key=True, db_column='customer_site_stage_id')
    sitedraft = models.OneToOneField(SiteDraft, db_column='customer_site_cui_id')
    #site = models.OneToOneField(Site, null=True, blank=True, db_column='customer_site_id')
    auth_key = models.CharField('REST authentication key', blank=True, max_length=16)
    default_rate = models.ForeignKey(BillRate, help_text="Optional per-site default rate", blank=True, null=True, db_column='default_rate')
    wpo_origin = models.BooleanField('WPO Origin', default=False)
    wpo_type = models.PositiveSmallIntegerField('WPO Type', default=0, choices=((0, ''), (1, 'FEO'), (2, 'Image Converter')))
    use_edns_client_subnet = models.BooleanField('Use edns client subnet', default=True)
    dns_refresh_type = models.IntegerField(choices=((0,'Asychronous'),(1,'Synchronous'),(2,'Background')), default=0, blank=False, null=True,
                                           help_text="""
                                           The behavior of each resolving types when DNS TTL expires.
                                            Asynchronous - Request to origin first and then resolving to origin on other thread.
                                            Synchronous - Wait resolving and request to origin on same thread.
                                            Background - Background thread does resolving and request to origin with always fresh resolved IPs.
                                           """)
    dns_entry_existing_time_limit = models.IntegerField(default=0, blank=False, null=True,
                                                        help_text="Limit of existing time for DNS entries wthout request (in second).<br>default(0) means 7200 seconds")
    class Meta:
        db_table = 'customer_site_stage'
        ordering = ['customer','service','pad']
        app_label = 'oui'

    def __unicode__(self):
        return '%s: %s' % (self.customer.name, self.pad)

    def set_staging_edge_service(self):
        """
        Unlike production site, staging site shares edge services as pool.
        :return:
        """
        from ci.common.models.cdn import Service
        is_ssl = False
        cdn_services = Service.objects.filter(stage_service=1, status=1)
        if self.sitedraft.is_ssl():
            is_ssl = True
            contract_region = self.sitedraft.product.get_contract_region()
            cdn_services = cdn_services.filter(stage_ssl=1, stage_region=contract_region)
        else:
            cdn_services = cdn_services.filter(stage_ssl=0)
        if cdn_services.exists():
            if is_ssl:
                self.service = self._get_idle_ssl_stage_service(cdn_services)
                self._set_staging_edge_keystore_with_preset_edge_keystore()
            else:
                self.service = self._get_idle_stage_service(cdn_services)
        else:
            raise Exception("There is no available stage service map for testing with this pad %s" % str(self.sitedraft))

    def _get_idle_stage_service(self, cdn_services):
        """
        find most available edge service for staging
        :param cdn_services:
        :return:
        """
        from ci.common.models.cdn import Service
        staging_services = SiteStage.objects.filter(service__in=cdn_services).values('service').\
            annotate(servicecount=Count('service')).order_by('servicecount')

        if staging_services.exists():
            allocated_service_list = [x.get('service') for x in staging_services]
            for service in cdn_services:
                if service.pk not in allocated_service_list:  # new cdn edge service not used yet.
                    return service

            idlest_service = Service.objects.get(id=staging_services[0].get('service'))
        else:  # no services are set to sitestage yet.
            idlest_service = cdn_services[0]

        return idlest_service

    def _get_idle_ssl_stage_service(self, ssl_services):
        """
        get max capacity for ssl service
        get oldest one with ssl service mapping and invalidate it
        raise exception if modified_time is within 3 hours
        :param ssl_services:
        :return:
        """
        from datetime import datetime, timedelta

        oldest_service = -1
        max_capacity = ssl_services.count()
        if max_capacity == 0:
            raise Exception("ssl service setup is not done yet.")
        staging_sites = SiteStage.objects.filter(service__in=ssl_services)

        already_assigned_sites = staging_sites.filter(sitedraft=self.sitedraft)
        if already_assigned_sites.exists():
            for assigned_site in already_assigned_sites:
                if assigned_site.service and assigned_site.service.ssl_cert:
                    return assigned_site.service

        stage_site_count = staging_sites.count()

        if stage_site_count == 0:  # no services are set to sitestage yet. assing random service
            oldest_service = ssl_services[0]
        elif stage_site_count < max_capacity:  # find empty slot and assign it
            ssl_service_slots = staging_sites.values_list('service',flat=True)
            for ssl_service in ssl_services:
                if ssl_service.pk not in ssl_service_slots:
                    oldest_service = ssl_service
                    break
        elif stage_site_count == max_capacity:
            staging_sites = staging_sites.order_by('modify_time')[:1]
            oldest_service = staging_sites[0].service

            modify_time = staging_sites[0].modify_time
            if datetime.now() > modify_time + timedelta(hours=SSL_STAGING_EDGE_CLEANUP_INTERVAL):
                staging_sites[0].sitedraft.save_as_modified()
                staging_sites[0].delete()
            else:
                raise Exception('reached max capacity for testable ssl staging service.')
        elif stage_site_count > max_capacity:
            count_to_delete = stage_site_count - max_capacity
            staging_sites = staging_sites.order_by('modify_time')
            deleted_count = 0
            for staging_site in staging_sites:
                temp_service = staging_site.service
                if datetime.now() > staging_site.modify_time + timedelta(hours=SSL_STAGING_EDGE_CLEANUP_INTERVAL):
                    staging_site.sitedraft.save_as_modified()
                    staging_site.delete()
                    deleted_count += 1
                else:
                    break
                if (count_to_delete + 1) == deleted_count:
                    return temp_service
            if SiteStage.objects.filter(service__in=ssl_services).count() >= max_capacity:
                raise Exception('reached max capacity for testable ssl staging service.')
            else:
                oldest_service = staging_sites[:1][0].service

        return oldest_service

    def _get_ssl_cert_for_staging_service(self):
        if not self.product.customerproductedge_set.exists():
            raise Exception('SSL product must have preset edge service.')

        preset_service = self.product.customerproductedge_set.all()[0].cdn_service
        if not preset_service or not preset_service.ssl_cert:
            raise Exception('Preset edge service must have keystore file.')

        production_site = self.sitedraft.get_site()
        if not production_site:
            return self.product.customerproductedge_set.all()[0].cdn_service.ssl_cert

        return production_site.service.ssl_cert

    def _set_staging_edge_keystore_with_preset_edge_keystore(self):
        from ci.common.utils.site import validate_ssl_cert_for_draft

        self.service.ssl_cert = self._get_ssl_cert_for_staging_service()
        validate_ssl_cert_for_draft(self.sitedraft, self.service)
        self.service.save()

    def set_shield_service(self, draft):
        """
        :return:
        """
        #set noshield
        if self.service:
            self.shielded_service = self.service.get_related_default_shield_service()
        else:
            raise Exception("Edge service is not set yet.")

    def get_invalidate_time(self):
        return self.modify_time + timedelta(hours=SSL_STAGING_EDGE_CLEANUP_INTERVAL)

    def set_from_draft(self, draft=None):
        if not draft:
            draft = self.sitedraft
        draft_diff = []

        editable = set(SiteDraft.cui_editable_fields + ('pad',))
        for field in self._meta.fields:
            if hasattr(draft, field.attname):
                draft_val = getattr(draft, field.attname)
            else:
                draft_val = None
            draft_comp_val = draft_val if draft_val != "" else None
            curr_val = getattr(self, field.attname)
            if curr_val == "":
                curr_val = None
            if draft_comp_val != curr_val:
                if field.name not in ('id','create_time', 'modify_time','shielded_service'):
                    if field.__class__.__name__ == 'BooleanField':
                        draft_diff.append((field.name, field.verbose_name, "True" if curr_val==1 else "False"))
                    else:
                        draft_diff.append((field.name, field.verbose_name, curr_val))
                if field.name in editable:
                    setattr(self, field.attname, draft_val)
            else:
                if draft_comp_val is None: #if editable field, empty string need to be copied
                    if field.name in editable:
                        setattr(self, field.attname, draft_val)

        return draft_diff

    def push_to_staging(self,draft):
        """
        1.copy draft to stage
        2.set edge service
        3. if DWA(ssl), set shield service
        :param draft:
        :return:
        """
        self.sitedraft_id = draft.pk
        self.set_from_draft(draft)
        self.server_action_rules = draft.server_action_rules
        self.customer = draft.customer
        self.product = draft.product
        self.set_staging_edge_service()
        self.set_shield_service(draft)
        self.save()

    def save(self, *args, **kwargs):
        #assert self.service and self.pad and self.origin
        self.modify_time = datetime.now()
        if not self.pk:
            self.create_time = datetime.now()
            self.nonwildcard_hour = self.customer.nonwildcard_hour
            self.items_per_request = self.customer.items_per_request
            self.all_per_hour = self.customer.all_per_hour
            self.wildcards_per_hour = self.customer.wildcards_per_hour
            self.wildcards_per_request = self.customer.wildcards_per_request

        super(SiteStage, self).save(*args, **kwargs)

DDOS_EVENT_TYPE = ((1,'DDOS_ATTACK'),)
class SiteDDosConvertRule(DatedHistoryModel):
    site = models.ForeignKey(Site,editable=False)
    event_type = models.IntegerField(choices=DDOS_EVENT_TYPE, default=1, editable=False)
    event_status = models.SmallIntegerField(db_column='event_status', choices=SITE_SAM_DDOS_STATUS, default=0, null=True)
    automated_service_prefix_change_enabled = models.BooleanField(default=False)
    automated_set_cookie_samrule_change_enabled = models.BooleanField(default=False)
    backup_edge_service_id = models.IntegerField(blank=True, editable=False)
    backup_shield_service_id = models.IntegerField(blank=True, editable=False)
    backup_server_action_rule = models.TextField(blank=True, editable=False)
    edge_prefix_on_ddos_attack = models.ForeignKey('Service', db_column='ddos_edge_service_id', null=True, blank=True)
    shielded_prefix_on_ddos_attack = models.ForeignKey('ShieldedService', db_column='ddos_shield_service_id',null=True, blank=True)
    server_action_rule_on_ddos_attack = models.TextField(db_column='ddos_server_action_rule', blank=True)
    description = models.CharField(max_length=1024, blank=True)

    class Meta:
        db_table = "site_ddos_convert_rule"
        verbose_name = 'Site DDos Event Convert Rule'
        app_label = 'oui'

    class PantherMeta:
        parent = 'site'
        track_editable = True

    def __unicode__(self):
        return "DDos convert rule: %s" % self.pk

    def save(self, *args, **kwargs):
        super(SiteDDosConvertRule,self).save(*args,**kwargs)

    def get_sam_converted_status(self):
        return SITE_SAM_DDOS_STATUS[self.event_status][1]

    def is_service_prefix_convert_automated(self):
        return self.automated_service_prefix_change_enabled

    def is_service_prefix_ddos_attack_convertible(self):
        return self.edge_prefix_on_ddos_attack and self.shielded_prefix_on_ddos_attack

    def is_service_prefix_ddos_attack_converted(self):
        """
        check ifn backup edge service exists
        :return:
        """
        return self.backup_edge_service_id != '' and self.backup_edge_service_id is not None

    def is_sam_rule_attack_convert_automated(self):
        return self.automated_set_cookie_samrule_change_enabled

    def is_sam_rule_attack_converted(self):
        result = False
        default_backup_samrule = None
        modified_backup_samrule = None
        data_dict = self.get_backup_server_action_rule_as_dict()
        if data_dict:
            default_backup_samrule = data_dict.get('default_backup',None)
            modified_backup_samrule = data_dict.get('modified_backup', None)

        if modified_backup_samrule is not None: #modified samrule applied
            return True
        if default_backup_samrule is not None: #default samrule applied
            return True
        return result

    def get_activated_button_name(self):
        result = "Convert to Attack"
        if self.is_service_prefix_ddos_attack_converted():
            result = "Convert to Normal"
        return result

    def get_activated_sam_button_name(self):
        return "Convert to Normal" if self.is_sam_rule_attack_converted() else "Convert to Attack"

    def get_activated_prefix_type(self):
        """
        return 'Normal' or 'Attack' or ''
        If prefix is not set return ''
        :return:
        """
        if self.edge_prefix_on_ddos_attack is None or self.shielded_prefix_on_ddos_attack is None:
            result = ''
        else:
            result = 'Attack' if self.is_service_prefix_ddos_attack_converted() else 'Normal'
        return result

    def get_backup_server_action_rule_as_dict(self):
        """
        site's server action rule json formats are converted as list,
        while default sam rule and modified sam rule is converted as dict
        If site's samrule has changed within period when attack mode is applied,
        we should keep changes and need to remove only 302 samrule.
        refer to https://wiki.cdnetworks.com/confluence/pages/viewpage.action?pageId=172196032
        :return:
        """
        data = None
        if self.backup_server_action_rule != '':
            try:
                data = simplejson.loads(self.backup_server_action_rule)
            except:
                try:
                    import ast
                    data = ast.literal_eval(self.backup_server_action_rule)
                except Exception, e:
                    pass
        return data


    def get_SAM_cookie_applied_status(self):
        """
        check backup server action rule is same with site's correspondent sam rule
        If same, it means sam cookie applied
        :return:
        """
        if self.is_sam_rule_attack_converted():
            return 'Active'
        else:
            if self.event_status == 2:
                return 'Inactive - %s' % (self.get_sam_converted_status())
            else:
                return 'Inactive'


    def get_applied_SAM_type(self):
        """
        return 'Default' if server_action_rule_on_ddos_attack is none else 'Modified'
        :return:
        """
        if self.server_action_rule_on_ddos_attack is None or self.server_action_rule_on_ddos_attack == '':
            return 'Default'
        else:
            return 'Modified'

    def get_automation_info_as_dict(self):
        result = {}
        result.update({'site_id': self.site_id})
        result.update({'pad_name': self.site.pad})
        result.update({'automated_service_prefix_change_enabled': self.automated_service_prefix_change_enabled})
        result.update({'automated_set_cookie_samrule_change_enabled': self.automated_set_cookie_samrule_change_enabled})
        result.update({'is_prefix_ddos_attack_converted': self.is_service_prefix_ddos_attack_converted()})
        result.update({'is_sam_rule_attack_converted': self.is_sam_rule_attack_converted()})

        return result

class SAMDefaultRule(DatedModel):
    RULE_TYPE = ((1,'DDOS_SET_COOKIE'),)
    rule_name = models.CharField(max_length=100)
    server_action_rule = models.TextField()
    rule_type = models.IntegerField(choices=RULE_TYPE, default=1)
    class Meta:
        db_table = "server_action_default_rule"
        verbose_name = 'SAM Default 302 set-cookie Rule'
        app_label = 'oui'

    def __unicode__(self):
        return self.rule_name

class SAMProfile(DatedModel):
    profile_name = models.CharField(max_length=75)
    rule_set = models.TextField(max_length=255)
    class Meta:
        db_table = "server_action_profile"
        verbose_name = 'SAM Profile'
        app_label = 'oui'
    def __unicode__(self):
        return self.profile_name

class SAMSandbox(models.Model):
    site = models.OneToOneField(Site)
    server_action_rules = RegexTextField(blank=True, null=True)
    class Meta:
        db_table = "server_action_sandbox"
        verbose_name = "SAM Sandbox"
        app_label = 'oui'
    def json_server_actions(self):
        if self.server_action_rules>'':
            r = json_load_ordered(self.server_action_rules)
            if not isinstance(r, list):
                raise Exception("Rules must be in the form of a list")
            else:
                return r
        else:
            return None

    def json_server_actions_for_proc_default(self):
        if self.server_action_rules>'':
            r = json_load_ordered(self.server_action_rules)
            if not isinstance(r, list):
                raise Exception("Rules must be in the form of a list")
            else:
                for rule in r:
                    if not 'proc' in rule:
                        rule['proc'] = '1'
                return r
        else:
            return None

    def server_actions_hash(self):
        return md5((self.server_action_rules).encode('utf-8') if self.server_action_rules else '').hexdigest()
    def commit_to_production(self):
        self.site.server_action_rules = self.server_action_rules
        self.site.save()
    def revert_changes(self):
        self.server_action_rules =self.site.server_action_rules
        self.save()


class SAMSandboxCUI(models.Model):
    site = models.OneToOneField(SiteDraft)
    server_action_rules = RegexTextField(blank=True, null=True)

    class Meta:
        db_table = "server_action_sandbox_cui"
        verbose_name = "SAM Sandbox for CUI"
        app_label = 'cui'

    def json_server_actions(self):
        if self.server_action_rules>'':
            r = json_load_ordered(self.server_action_rules)
            if not isinstance(r, list):
                raise Exception("Rules must be in the form of a list")
            else:
                return r
        else:
            return None

    def json_server_actions_for_proc_default(self):
        if self.server_action_rules>'':
            r = json_load_ordered(self.server_action_rules)
            if not isinstance(r, list):
                raise Exception("Rules must be in the form of a list")
            else:
                for rule in r:
                    if not 'proc' in rule:
                        rule['proc'] = '1'
                return r
        else:
            return None


    def server_actions_hash(self):
        return md5((self.server_action_rules).encode('utf-8') if self.server_action_rules else '').hexdigest()

    def commit_to_production(self):
        self.site.server_action_rules = self.server_action_rules
        self.site.save()

    def revert_changes(self):
        self.server_action_rules =self.site.server_action_rules
        self.save()


class PADChangeTime(models.Model):
    site = models.ForeignKey(Site)
    user = models.ForeignKey(AuthUser)
    time = models.DateTimeField(auto_now_add=True)
    comment = models.CharField(max_length=255, null=True, blank=True)
    class Meta:
        db_table="pad_change"
        app_label="oui"

class PADChangeLog(models.Model):
    pad_change = models.ForeignKey(PADChangeTime)
    field = models.CharField(max_length=255)
    value = models.CharField(max_length=1000, null=True, blank=True)
    changed = models.BooleanField(default=False)
    class Meta:
        db_table="pad_change_log"
        app_label="oui"


class SiteProfile(models.Model):
    site = models.ForeignKey(Site, db_column="customer_site_id")
    note = models.TextField(blank=True)

    class Meta:
        db_table="customer_site_profile"
        app_label="oui"

class CustomerProfile(models.Model):
    customer = models.ForeignKey(Customer)
    note = models.TextField(blank=True)

    class Meta:
        db_table="customer_profile"
        app_label="oui"

