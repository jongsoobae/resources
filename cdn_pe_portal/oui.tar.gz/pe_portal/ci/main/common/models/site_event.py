# -*- coding: utf-8 -*-
from django.db import models
from ci.django_mailer.models import MAIL_EVENT
from django.utils.encoding import smart_str

NEW = 0
WORKING = 1
DONE = 2
NO_ACTION = 3
ABORTED = -1
FAILED = -2

DDOS_EVENT_QUEUE_STATUS = ((NEW, 'New'),
              (WORKING, 'Working'),
              (DONE, 'Done'),
              (NO_ACTION, 'No_Action'),
              (ABORTED, 'Aborted'),
              (FAILED, 'Failed'))

class SiteEventHistory(models.Model):
    """
    """
    parent_event_history = models.IntegerField(db_column='parent_event_history_id')
    site_id = models.IntegerField()
    guid = models.CharField(max_length=255)
    agent_ipv4 = models.CharField(max_length=15)
    event_object_name = models.CharField(max_length=255)
    event_id = models.IntegerField(choices=MAIL_EVENT,editable=False)
    event_queue_status = models.SmallIntegerField(choices=DDOS_EVENT_QUEUE_STATUS, default=0)
    report_time = models.DateTimeField(editable=False)
    description = models.CharField(max_length=1024)
    create_user = models.CharField(max_length=50, editable=False)
    modify_user = models.CharField(max_length=50, editable=False)
    modify_time = models.DateTimeField(auto_now=True, editable=False)
    create_time = models.DateTimeField(auto_now_add=True, editable=False)

    class Meta:
        db_table = "site_event_history"
        app_label = "oui"
        ordering = ["-id"]

    def to_dicts(self):
        itemdict = dict((key, smart_str(value).strip()) for key, value in self.__dict__.iteritems()
                        if not callable(value) and not key.startswith('__'))
        return itemdict