# -*- coding: utf-8 -*-
import json
from django.db import models
from ci.common.models.site import SiteDraft


class CustomerSiteChangeHistory(models.Model):
    """
    """
    OPERATION_TYPE = (
        (0, 'Add'),
        (1, 'Update'),
        (2, 'Restore'),
    )
    customer_site_history = models.AutoField(primary_key=True, db_column="customer_site_history_id")
    sitedraft = models.ForeignKey(SiteDraft, db_column="customer_site_cui_id")
    version = models.PositiveIntegerField()
    operation_type = models.PositiveIntegerField(choices=OPERATION_TYPE)
    by_operator = models.BooleanField(default=False)
    modify_user = models.CharField(max_length=30)
    create_time = models.DateTimeField(auto_now_add=True)
    description = models.TextField(max_length=255)
    
    class Meta:
        db_table = "customer_site_change_history"
        app_label = "oui"
        unique_together = (("site_draft", "version", ),)

    @staticmethod
    def get_latest_versions(draft):
        latest_version = None
        previous_version = None
        change_histories = CustomerSiteChangeHistory.objects.filter(sitedraft=draft).order_by('-pk')[:2]
        if change_histories.count() == 2:
            latest_version = change_histories[0].version
            previous_version = change_histories[1].version
        elif change_histories.count() == 1:
            latest_version = change_histories[0].version
        else:
            pass
        return latest_version, previous_version

    def is_restore_enabled(self):
        if self.sitedraft.get_site():
            snapshot = self.get_snapshot_data()
            product = snapshot.get('product')
            if product is None:
                return False
            if int(product) != self.sitedraft.product.pk:
                return False

        latest_version, previous_version = CustomerSiteChangeHistory.get_latest_versions(self.sitedraft)
        if self.version == latest_version:
            return False
        return True

    def get_version_display(self):
        return "v %s" % self.version

    def get_snapshot_data(self):
        try:
            snapshot = CustomerSiteSnapshot.objects.get(customer_site_history=self.pk)
            return json.loads(snapshot.get_config_diff_for_customer())
        except Exception,e:
            return {}

    def get_values_for_customer(self, diff_dict=None, latest_version=None, diff_dict_with_latest=None,
                                snapshot=None, display_snapshot=False):
        from ci.common.utils.misc import dict_diff
        previous_dict_diff = {}
        if snapshot is None:
            current_dict = self.get_snapshot_data()
        else:
            current_dict = snapshot.copy()
        if diff_dict is None:
            try:
                previous_history = CustomerSiteChangeHistory.objects.filter(sitedraft=self.sitedraft).filter(pk__lte=self.pk).order_by('-pk')[1]
                previous_dict = previous_history.get_snapshot_data()
            except:
                previous_dict = {}
            previous_dict_diff = dict_diff(previous_dict,current_dict)
        else:
            previous_dict_diff = diff_dict.copy()

        if not self.sitedraft.is_dwa():
            if previous_dict_diff:
                if previous_dict_diff.has_key('shield_location'):
                    previous_dict_diff.pop('shield_location')
                if previous_dict_diff.has_key('shielded_service'):
                    previous_dict_diff.pop('shielded_service')

            if diff_dict_with_latest:
                if diff_dict_with_latest.has_key('shield_location'):
                    diff_dict_with_latest.pop('shield_location')
                if diff_dict_with_latest.has_key('shielded_service'):
                    diff_dict_with_latest.pop('shielded_service')

        mydict = {'user': self.modify_user,
                  'version': self.version,
                  'restore_enabled': self.is_restore_enabled(),
                  'update_time':self.create_time,
                  'action_type': self.OPERATION_TYPE[self.operation_type][1],
                  'changed_values_with_previous': str(previous_dict_diff),
                  'comment_on_change': self.description}
        if display_snapshot:
            mydict.update({'pad_snapshot': current_dict})
        if diff_dict_with_latest is not None:
            mydict.update({'changed_values_with_current': str(diff_dict_with_latest)})
        if latest_version:
            mydict.update({'current_version': str(latest_version)})
        return mydict



class CustomerSiteSnapshot(models.Model):
    """
    """
    customer_site_snapshot = models.AutoField(primary_key=True, db_column="customer_site_snapshot_id")
    customer_site_history = models.OneToOneField(CustomerSiteChangeHistory)
    config_diff = models.TextField()
    create_time = models.DateTimeField(auto_now_add=True)
        
    class Meta:
        db_table = "customer_site_snapshot"
        app_label = "oui"

    def get_config_diff_for_customer(self):
        return self.config_diff.replace("shielded_service", "shield_location")