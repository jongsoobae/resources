from django.db import models
from ci.common.models.common import DatedModel
from django.utils import simplejson as json


class SNIGroup(DatedModel):
    objects = models.Manager()
    sni_group_id = models.AutoField(primary_key=True, db_column='sni_group_id', null=False, auto_created=True)
    sni_group_name = models.CharField(max_length=100, unique=True, null=False, blank=False, error_messages={'null': ['This field cannot be blank.']})
    description = models.CharField(max_length=255, null=True, blank=True)
    status = models.BooleanField('Active', default=True)
    ssl_server_protocols = models.CharField(default="", null=True, blank=True, max_length=50)
    ssl_client_protocols = models.CharField(default="", null=True, blank=True, max_length=50)
    ssl_server_ciphers = models.CharField(default="", null=True, blank=True, max_length=1000)
    ssl_client_ciphers = models.CharField(default="", null=True, blank=True, max_length=1000)

    class Meta:
        app_label = 'oui'
        db_table = 'sni_group'

    def __unicode__(self):
        return self.sni_group_name if self.sni_group_name else ''

    def get_certs(self):
        from ci.common.models.customer import SSLKeystore
        return SSLKeystore.objects.filter(sni_group=self)

    def get_services(self):
        from ci.common.models.cdn import Service
        return Service.objects.filter(sni_group=self)

    def update_certs(self, certs):
        from ci.common.models.customer import SSLKeystore
        SSLKeystore.objects.filter(pk=certs).update(sni_group_id=self.sni_group_id)

    def update_services(self, services):
        from ci.common.models.cdn import Service
        Service.objects.filter(pk=services).update(sni_group_id=self.sni_group_id)

    def get_history_object(self):
        ret = self.get_base_json()
        certs = self.get_certs()
        services = self.get_services()

        ret.update({
            'services': [{'id': service.pk, 'name': str(service)} for service in services],
            'certs': [{'id': cert.pk, 'name': str(cert)} for cert in certs]
        })
        return ret

    def get_histories(self):
        return SNIHistory.objects.filter(sni_group=self).order_by('-pk')

    def get_histories_json(self):
        return [hist.get_json() for hist in self.get_histories()]

    def create_history(self):
        SNIHistory.objects.create(
            sni_group=self,
            sni_group_name=self.sni_group_name,
            description=self.description,
            certs=json.dumps([{'id': cert.pk, 'name': str(cert)} for cert in self.get_certs()]),
            services=json.dumps([{'id': service.pk, 'name': str(service)} for service in self.get_services()]),
            modify_user=self.modify_user,
            ssl_server_protocols=self.ssl_server_protocols,
            ssl_client_protocols=self.ssl_client_protocols,
            ssl_server_ciphers=self.ssl_server_ciphers,
            ssl_client_ciphers=self.ssl_client_ciphers
        )

    def get_json(self, get_detail=False):
        ret = self.get_base_json()

        if get_detail:
            certs = self.get_certs()
            services = self.get_services()
            ret.update({
                'certs': [cert.get_json() for cert in certs],
                'cert_count': certs.count(),
                'services': [service.get_json() for service in services],
                'service_count': services.count(),
            })

        return ret

    def save(self, *args, **kwargs):
        super(SNIGroup, self).save(*args, **kwargs)


class SNIHistory(models.Model):
    sni_group_history_id = models.AutoField(primary_key=True, db_column='sni_group_history_id', null=False, auto_created=True)
    sni_group = models.ForeignKey(SNIGroup, db_column='sni_group_id', null=False, blank=False)
    sni_group_name = models.CharField(max_length=100, unique=True, null=False)
    description = models.CharField(max_length=255, null=True, blank=True)
    certs = models.CharField(max_length=1000, null=False, blank=False)
    services = models.CharField(max_length=1000, null=False, blank=False)
    modify_user = models.CharField(max_length=30, editable=False)
    modify_time = models.DateTimeField(auto_now=True, editable=False)
    ssl_server_protocols = models.CharField(default="", null=True, blank=True, max_length=50)
    ssl_client_protocols = models.CharField(default="", null=True, blank=True, max_length=50)
    ssl_server_ciphers = models.CharField(default="", null=True, blank=True, max_length=1000)
    ssl_client_ciphers = models.CharField(default="", null=True, blank=True, max_length=1000)

    class Meta:
        app_label = 'oui'
        db_table = 'sni_group_history'

    def get_json(self):
        ret_json = {
            'sni_group_history_id': self.pk,
            'sni_group_name': self.sni_group_name,
            'description': self.description,
            'certs': json.loads(self.certs),
            'services': json.loads(self.services),
            'modify_time': str(self.modify_time),
            'modify_user': self.modify_user,
            'ssl_server_protocols': self.ssl_server_protocols,
            'ssl_server_ciphers': self.ssl_server_ciphers,
            'ssl_client_protocols': self.ssl_client_protocols,
            'ssl_client_ciphers': self.ssl_client_ciphers
        }

        return ret_json
