from datetime import datetime
from django.db import models, connection
from ci.common.models.cdn import Node, Pop, Service, BAD_LAL
from ci.common.models.cache import Band

class DnsServiceLoad(models.Model):
	#id = models.CharField(primary_key=True, max_length=255)
	node = models.IntegerField()
	service = models.IntegerField()
	requests = models.IntegerField()
	guesses = models.IntegerField()
	stat_time = models.DateTimeField()
	class Meta:
		db_table = 'dns_traffic_service'
		app_label = 'oui'

def stale_rows(model, threshold):
	"return the number of rows older than a given threshold."
	cursor = connection.cursor()
	cursor.execute("select count(*) from %s where unix_timestamp(now()) - unix_timestamp(update_time) > %d" \
		% (model._meta.db_table, threshold))
	row = cursor.fetchone()
	return int(row[0])


class HasUpdateTime(models.Model):
	update_time = models.DateTimeField(default=datetime.now)
	class Meta:
		abstract = True
	def save(self, *args, **kwargs):
		self.update_time = datetime.now()
		super(HasUpdateTime, self).save(*args, **kwargs)


class PopStat(HasUpdateTime):
	pop = models.OneToOneField(Pop)
	lal = models.IntegerField(default=0)
	offline_count = models.IntegerField(default=0)
	passing_count = models.IntegerField(default=0)
	failing_count = models.IntegerField(default=0)
	class Meta:
		db_table = 'popstat'
		get_latest_by = 'update_time'
		app_label = 'oui'
	def __unicode__(self):
		return '%s (%d), %s' % (self.pop.name, self.pop.id, self.update_time)

class BandStat(HasUpdateTime):
	band = models.OneToOneField(Band, primary_key=True)
	lal = models.IntegerField(default=0)
	offline_count = models.IntegerField(default=0)
	passing_count = models.IntegerField(default=0)
	failing_count = models.IntegerField(default=0)
	class Meta:
		db_table = 'bandstat'
		get_latest_by = 'update_time'
		app_label = 'oui'
	def __unicode__(self):
		return '%s (%d) %s' %(self.band.name, self.band.id, self.update_time)

class NodeStat(HasUpdateTime):
	fail_choices = ((0,"Unknown"),(1,"Connection Failure (nmon)"),(2,"Connection Failure (dns)"),(3,"Connection Failure (cs menu)"),(4,"Node Failing (nmon)"),(5,"Incorrect Image"),(6,"Dead Mode (cs menu)"),)
	node = models.OneToOneField(Node)
	lal = models.IntegerField(default=BAD_LAL)
	failed = models.BooleanField()
	fail_reason = models.IntegerField(default=0, choices=fail_choices)
	rps = models.DecimalField(max_digits=8, decimal_places=1, default=0)
	mbps = models.DecimalField(max_digits=8, decimal_places=1, default=0)
	ops = models.DecimalField(max_digits=8, decimal_places=1, default=0)
	ombps = models.DecimalField(max_digits=8, decimal_places=1, default=0)
	smbps = models.DecimalField(max_digits=8, decimal_places=1, default=0)
	ambps = models.DecimalField(max_digits=8, decimal_places=1, default=0)
	diskio_ps = models.DecimalField(max_digits=8, decimal_places=1, default=0)
	disk_avg = models.DecimalField(max_digits=8, decimal_places=1, default=0)
	o503ps = models.DecimalField(max_digits=8, decimal_places=1, default=0)
	c503ps = models.DecimalField(max_digits=8, decimal_places=1, default=0)
	heap_percent = models.IntegerField(default=0)
	upstream_conn = models.IntegerField(default=0)
	downstream_conn = models.IntegerField(default=0)
	disk_age_sec = models.IntegerField(default=0)
	class Meta:
		db_table = 'nodestat'
		get_latest_by = 'update_time'
		app_label = 'oui'
	def __unicode__(self):
		return '%s (%d), %s' % (self.node.name(), self.node.id, self.update_time)
	def fail_reason_text(self):
		return self.fail_choices[self.fail_reason][1]
		
class PopFailure(HasUpdateTime):
	source_pop = models.ForeignKey(Pop, related_name='source_popfailure_set')
	target_pop = models.ForeignKey(Pop, related_name='target_popfailure_set')
	class Meta:
		db_table = 'pop_failure'
		ordering = ('update_time',)
		app_label = 'oui'
