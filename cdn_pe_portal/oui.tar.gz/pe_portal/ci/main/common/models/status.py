from django.contrib.auth.models import User as AuthUser
from ci.common.models import DatedModel
from ci.common.utils.mail import send_email
from ci.constants import NOC, OUI, NO_REPLY
from django.db import models

class SystemStatus(DatedModel):
	update = models.PositiveSmallIntegerField(default=1, editable=False)
	urgent = models.BooleanField('Urgent?', default=False)
	active = models.BooleanField(default=True, editable = False)
	description = models.CharField('Issue Description', max_length=2000, help_text="This is the issue displayed on the customer portal")
	oui_only = models.BooleanField(default=False, editable=False)
	turn_on_stage_queue = models.BooleanField("Turn on staging queue widget?",default=False, help_text="Turns on a checkbox in OUI pusher page. Can be used if smoke test pushes will be needed")
	class Meta:
		db_table = 'system_status'
		ordering = ['-create_time']
		app_label = 'oui'
	def save(self, *args, **kwargs):
		self.user = kwargs.pop('user', None)
		if not self.id:
			#this is new so get proper update number
			try:
				prev = SystemStatus.objects.filter(oui_only = self.oui_only).latest('create_time')
				if prev and prev.active and prev.urgent:
					self.update = int(prev.update) + 1
			except Exception, e:
				pass
			#current paradigm is only 1 active record at a time
			#could always do latest but since this is being done
			#on every page much quicker to limit the result set easily.
			try:
				expire = SystemStatus.objects.filter(active=True, oui_only = self.oui_only).update(active=False)
			except:
				pass
			self.create_user = self.user.get_full_name()
		super(SystemStatus,self).save(*args, **kwargs)
		msg = "New system status message\n\nUser: %s\nDomain: %s\nUrgent: %s\nCreate Time: %s\n\nStatus Message:\n%s" %(
			self.create_user,
			"pantheroui" if self.oui_only else "pantherportal, pantheroui", 
			self.urgent,
			self.create_time.strftime('%Y-%m-%d %H:%M GMT'),
			self.description,
		)
		send_email(OUI, [NOC], "[alert] %s system status change" %("OUI" if self.oui_only else "CUI"),msg)
