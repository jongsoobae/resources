from django.db import models
from ci.common.models.site import Site
from ci.common.models.cdn import Pop
from ci.common.models.customer import Customer
from datetime import timedelta

class Url(models.Model):
	hash = models.CharField(max_length=32)
	url = models.CharField(max_length=150)
	class Meta:
		db_table = 'url'


class UrlCount(models.Model):
	site_id = models.IntegerField()
	url = models.ForeignKey(Url)
	stat_time = models.DateTimeField()
	hits = models.IntegerField()
	completes = models.IntegerField()
	class Meta:
		db_table = 'url_count2'

		
class UrlCountCodes(models.Model):
	url_count = models.ForeignKey(UrlCount)
	code = models.IntegerField()
	hits = models.IntegerField()
	class Meta:
		db_table = 'url_count_response_codes2'


class DailySummaryLog(models.Model):
	report_date = models.DateTimeField(auto_now = True)
	total_objects = models.IntegerField()
	total_gb_served = models.FloatField()
	average_object = models.FloatField()
	max_mbps = models.FloatField()
	avg_mbps = models.FloatField()
	sum_billable = models.FloatField()
	mbps_95th = models.FloatField()
	hit_rate = models.FloatField()
	mbps_rate = models.FloatField()
	class Meta:
		db_table = 'daily_summary_log'
		app_label = 'oui'


class MtdSummaryLog(models.Model):
	report_date = models.DateTimeField(auto_now_add = True)
	gb_transferred = models.FloatField()
	hits = models.IntegerField()
	projected_fee = models.FloatField()
	min_fee = models.FloatField()
	class Meta:
		db_table = 'mtd_summary_log'
		app_label = 'oui'


class DnsSummaryLog(models.Model):
	stat_date = models.DateTimeField(auto_now_add = True)
	eu_total = models.IntegerField()
	eu_guess = models.IntegerField()
	eu_guess_ratio = models.FloatField()
	us_east_total = models.IntegerField()
	us_east_guess = models.IntegerField()
	us_east_guess_ratio = models.FloatField()
	us_midwest_total = models.IntegerField()
	us_midwest_guess = models.IntegerField()
	us_midwest_guess_ratio = models.FloatField()
	us_west_total = models.IntegerField()
	us_west_guess = models.IntegerField()
	us_west_guess_ratio = models.FloatField()
	apac_total = models.IntegerField()
	apac_guess = models.IntegerField()
	apac_guess_ratio = models.FloatField()
	class Meta:
		db_table = 'dns_load_summary'
		app_label = 'oui'
		
class RevenueHistory(models.Model):
	day = models.DateField(auto_now_add=True)
	customer = models.ForeignKey(Customer)
	proj_rate = models.FloatField('Rate based on projected traffic')
	curr_rate = models.FloatField('Rate based on traffic so far')
	proj_fee = models.FloatField('Projected fee')
	min_fee = models.FloatField('Minimum fee so far')
	proj_gb_xferred = models.FloatField('Projected GB transferred')
	act_gb_xferred = models.FloatField('Actual GB transferred so far')
	proj_mbps_95th = models.FloatField('Projected 95th Mbps')
	act_mbps_95th = models.FloatField('Actual 95th Mbps at this time')
	avg_mbps = models.FloatField('Actual average Mbps')
	is_gb = models.BooleanField('Is customer GB instead of MBPS')
	proj_min = models.BooleanField('Is projected revenue an applied minimum')
	curr_min = models.BooleanField('Is current revenue an applied minimum')
	class Meta:
		db_table = 'revenue_history'
		app_label = 'oui'
		unique_together = ('day', 'customer')
		verbose_name_plural = 'revenue history'

class BigIntegerField(models.IntegerField):
	empty_strings_allowed=False
	def get_internal_type(self):
		return "BigIntegerField"
	def db_type(self, connection):
		return 'bigint'

	
class FieldPerEpoch(models.Model):
	"""this is the ancestor for the group of traffic tables that are structured so that
	each row represents one day, and there are 288 columns in each row that represent
	the data values for the 288 5-minute periods of that day.
	
	In case you're wondering why the model is structured like this: 
	"""
	stat_time = models.DateTimeField()
	site = models.ForeignKey(Site, db_column='customer_site_id')
	# the 288 epoch columns are added after the end of this class definition
	class Meta:
		abstract = True
	@staticmethod
	def timedelta_to_5min_interval(td):
		"""
		@param td: A datetime.timedelta instance
		@return:   An int, the number of 5-minute intervals represented by
				   the delta, rounded down
		"""
		return td.days * ((24 * 60) / 5) + td.seconds / 300
	
	def series(self, start, stop):
		"""
		Get bytes over the 5-minute intervals on or after 'start', before 'stop'
		@param start:  A datetime, not necessarily within this day
		@param stop:   A datetime >= start, not necessarily within this day
		@return:      [ ( datetime, bytes ), ... ]
		"""
		assert stop >= start
		
		start_delta = start - self.stat_time
		stop_delta  = stop  - self.stat_time
		
		# get the 'e0' ... 'e287' attributes
		return (
			(self.stat_time + timedelta(minutes=i*5), getattr(self, 'e%d' % i))
			for i in
			range(
				max(0, FieldPerEpoch.timedelta_to_5min_interval(start_delta)),
				min(288, FieldPerEpoch.timedelta_to_5min_interval(stop_delta))
			)
		)
		
	def sum(self, start, stop):
		"""
		Calculate the sum of traffic bytes over this day for all 5-minute
		intervals on or after 'start', before 'stop'
		@param start:  A datetime, not necessarily within this day
		@param stop:   A datetime >= start, not necessarily within this day
		@return:       An int, the number of bytes over start <= time < stop
		"""
		return sum(i[1] for i in self.series(start, stop))
	
	def max(self, start, stop):
		"""
		Calculate the maximum bytes during any 5-minute interval on or after
		'start', before 'stop'
		@param start:  A datetime, not necessarily within this day
		@param stop:   A datetime >= start, not necessarily within this day
		@return:       An int, the greatest number of bytes where start <= time < stop
		"""
		return max(i[1] for i in self.series(start, stop))

# this adds the epoch columns
for i in range(0, 288):
	FieldPerEpoch.add_to_class('e%d' % i, BigIntegerField(default=0))


class TrafficBytes(FieldPerEpoch):
	"""This TrafficBytes instance represents one site over one day, divided into
	5-minute intervals.
	"""
	class Meta:
		db_table = 'traffic_bytes'
		app_label = 'oui'
		ordering = ['stat_time']
		unique_together = ('stat_time', 'site')

		
class TrafficBytesForChart(FieldPerEpoch):
        """This TrafficBytes instance represents one site over one day, divided into
        5-minute intervals.
        """
        class Meta:
                db_table = 'traffic_bytes'
                app_label = 'chartron'
                ordering = ['stat_time']
                unique_together = ('stat_time', 'site')


class TrafficRequests(FieldPerEpoch):
	class Meta:
		db_table = 'traffic_requests'
		app_label = 'oui'
		ordering = ['stat_time']
		unique_together = ('stat_time', 'site')


class TrafficMissBytes(FieldPerEpoch):
	key_value = models.CharField(max_length=10)
	class Meta:
		db_table = 'traffic_miss_bytes'
		app_label = 'oui'
		ordering = ['stat_time']
		unique_together = ('stat_time', 'site', 'key_value')


class TrafficMissRequests(FieldPerEpoch):
	key_value = models.CharField(max_length=10)
	class Meta:
		db_table = 'traffic_miss_requests'
		app_label = 'oui'
		ordering = ['stat_time']
		unique_together = ('stat_time', 'site', 'key_value')
		


class SiteMethodRequests(FieldPerEpoch):
	key_value = models.CharField(max_length=10)
	class Meta:
		db_table = 'site_method_requests'
		app_label = 'oui'
		ordering = ['stat_time']
		unique_together = ('stat_time', 'site', 'key_value')


class SiteResponseCodeRequests(FieldPerEpoch):
	key_value = models.CharField(max_length=10)
	class Meta:
		db_table = 'site_response_code_requests'
		app_label = 'oui'
		ordering = ['stat_time']
		unique_together = ('stat_time', 'site', 'key_value')


class TrafficBytesPop(FieldPerEpoch):
	pop = models.ForeignKey(Pop)
	class Meta:
		db_table = 'traffic_bytes_pop'
		app_label = 'oui'
		ordering = ['stat_time']
		unique_together = ('stat_time', 'pop', 'site')
		


class TrafficRequestsPop(FieldPerEpoch):
	pop = models.ForeignKey(Pop)
	class Meta:
		db_table = 'traffic_requests_pop'
		app_label = 'oui'
		ordering = ['stat_time']
		unique_together = ('stat_time', 'pop', 'site')
		


class TrafficMissBytesPop(FieldPerEpoch):
	pop = models.ForeignKey(Pop)
	key_value = models.CharField(max_length=10)
	class Meta:
		db_table = 'traffic_miss_bytes_pop'
		app_label = 'oui'
		ordering = ['stat_time']
		unique_together = ('stat_time', 'pop', 'site', 'key_value')
		


class TrafficMissRequestsPop(FieldPerEpoch):
	pop = models.ForeignKey(Pop)
	key_value = models.CharField(max_length=10)
	class Meta:
		db_table = 'traffic_miss_requests_pop'
		app_label = 'oui'
		ordering = ['stat_time']
		unique_together = ('stat_time', 'pop', 'site', 'key_value')


class SiteMethodRequestsPop(FieldPerEpoch):
	pop = models.ForeignKey(Pop)
	key_value = models.CharField(max_length=10)
	class Meta:
		db_table = 'site_method_requests_pop'
		app_label = 'oui'
		ordering = ['stat_time']
		unique_together = ('stat_time', 'pop', 'site', 'key_value')


class SiteResponseCodeRequestsPop(FieldPerEpoch):
	pop = models.ForeignKey(Pop)
	key_value = models.CharField(max_length=10)
	class Meta:
		db_table = 'site_response_code_requests_pop'
		app_label = 'oui'
		ordering = ['stat_time']
		unique_together = ('stat_time', 'pop', 'site', 'key_value')
