from urllib import quote
from ci.common.models import Site


def main():
    sites = Site.objects.filter(pad_aliases__icontains='\r\n').select_related('customer')
    print 'There are %s pads.' % str(len(sites))
    print '------------------------------------'

    for site in sites:
        print 'pad', site.pad
        print '-> pad_aliases:', quote(site.pad_aliases)
        yn = raw_input('continue? (y/n) :')
        if 'y' != yn.lower():
            print 'skip'
            print '------------------------------------'
            continue

        to_pad_aliases = site.pad_aliases.replace('\r\n', '\n')
        b_success = Site.objects.filter(pad=site.pad).update(pad_aliases=to_pad_aliases)
        if b_success:
            print '-> pad_aliases changed to:', quote(to_pad_aliases)
        else:
            print 'failed'
        print '------------------------------------'


if __name__ == '__main__':
    main()
