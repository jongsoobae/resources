#!/bin/bash

export DJANGO_SETTINGS_MODULE=ui.oui.settings
export PYTHONPATH=$PYTHONPATH:/opt/cdn/ui/prod


python ./change_pad_aliases_linefeed_char.py
