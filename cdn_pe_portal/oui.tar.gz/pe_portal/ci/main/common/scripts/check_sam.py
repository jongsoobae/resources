import os
import sys
from django.utils import simplejson as json


sys.path.append('/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'ui.oui.settings'


def main():
    from ci.common.models import Site
    from ci.common.utils.sam_wizard import rule_validation
    from ci.common.utils.api import APIException

    sites = Site.objects.filter(server_action_rules__isnull=False).exclude(server_action_rules='')

    json_error_list = {}
    global_error_dict = {}
    more_info_id_list = []
    for site in sites:
        rule_id = 0
        for rule in site.json_server_actions_for_proc_default():
            try:
                rule_validation(rule)
            except APIException, e:
                print '------ ' + str(site.pk) + ' -------'
                if not e.message:
                    pass
                elif 'name' in e.message:
                    pass
                else:
                    if 'True is not allowed.' in str(e.message):
                        pass
                    elif 'False is not allowed.' in str(e.message):
                        pass
                    elif '1 is not allowed.' in str(e.message):
                        pass
                    elif '0 is not allowed.' in str(e.message):
                        pass
                    elif '2 is not allowed.' in str(e.message):
                        pass
                    elif '3 is not allowed.' in str(e.message):
                        pass
                    elif '4 is not allowed.' in str(e.message):
                        pass
                    elif '5 is not allowed.' in str(e.message):
                        pass
                    elif '6 is not allowed.' in str(e.message):
                        pass
                    elif '7 is not allowed.' in str(e.message):
                        pass
                    elif '8 is not allowed.' in str(e.message):
                        pass
                    elif '9 is not allowed.' in str(e.message):
                        pass
                    elif 'proc' in e.message and 'This field is required.' in str(e.message):
                        pass
                    elif 'proc' in str(e.message) and 'This field is required.' in str(e.message):
                        pass
                    else:
                        if site.pk not in json_error_list:
                            more_info_id_list.append(site.pk)
                            json_error_list[site.pk] = {}
                        json_error_list[site.pk][rule_id] = e.message
                        print json_error_list[site.pk]

                        e_hash = hash(str(e.message))
                        if e_hash not in global_error_dict:
                            global_error_dict[e_hash] = e.message

            rule_id += 1

    sites2 = Site.objects.filter(pk__in=more_info_id_list).exclude(server_action_rules='').select_related('customer')

    for site2 in sites2:
        json_error_list[site2.pk]['pad'] = site2.pad
        json_error_list[site2.pk]['customer'] = site2.customer.name

    f = open('./error_result.txt', 'w')
    f.write(json.dumps(json_error_list))
    f.close()

    global_error_list = [value for key, value in global_error_dict.items()]

    ff = open('./error_result_types.txt', 'w')
    ff.write(json.dumps(global_error_list))
    ff.close()

if __name__ == '__main__':
    main()
