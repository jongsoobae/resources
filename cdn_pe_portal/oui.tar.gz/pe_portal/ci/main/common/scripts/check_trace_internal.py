import os
import sys
import hashlib
import cPickle
import socket
import time
import json
import urllib

sys.path.append('/opt/cdn/ui/prod')
#sys.path.insert(0,'/home/injune/git/panther')
os.environ['DJANGO_SETTINGS_MODULE'] = 'ui.oui.settings'
from ci.constants import CS_PASSWORD
from ci.common.utils.curlwrapper.browser import Browser
from ci.common.utils.curlwrapper.request import Request

DEBUG_MODE = 0

def make_cookie(cookie_ttl, test_hostname):
    """Make cookie
    :param cookie_ttl: cookie ttl
    :param test_hostname: test hostname
    :return: cookie
    """
    # example cookie_ttl = 10000
    auth_time = int(time.time()) + int(cookie_ttl)
    local_ip = socket.gethostbyname(socket.gethostname())

    auth = hashlib.sha1("%s%s%s%s" % (CS_PASSWORD, test_hostname, auth_time, local_ip)).hexdigest()
    cookies = 'authTime=%s;auth=%s' % (auth_time, auth)

    return cookies

def get_cs_auth_cookie(hostname):
    """
    deprecated
    :param hostname:
    :return:
    """
    browser = Browser()
    request = Request(url="https://%s/login" % (hostname), post={'password':CS_PASSWORD})
    resp = browser.request(request)
    cookies = []
    for header in resp.headers:
        if header[0] == 'Set-Cookie':
            cookies.append(header[1].split(';')[0])

    return "; ".join(cookies)

def main(pad_name):
    post_data = []
    #[('url', u'https://ca.staging_test.ca.foo.com/hello'), ('header', '')]
    hostname = 'h0-s160.p99-nrt.cdngp.net'
    extra_headers = ''
    filename = ''
    file_contents = None
    urlinfo = ('url','https://dwa-qa.cdnetworks.com/hello')
    header = ('header','')
    post_data.append(urlinfo)
    post_data.append(header)

    browser = Browser()
    #cookie = get_cs_auth_cookie(hostname)
    cookie = make_cookie(10000, hostname)
    #post_data = [('url','aadddde'),('header','adddd')]
    request = Request(url="https://%s/trace_internal" % (hostname),
                      post=post_data,
                      cookie=cookie,
                      multipart=True,
                      extraheaders=extra_headers,
                      filename=filename,
                      file_contents=file_contents)
    resp = browser.request(request)
    return resp


if __name__ == '__main__':
    pad_name = ''
    if len(sys.argv) > 1:
        if sys.argv[1] == '-p':
            DEBUG_MODE = 1
        else:
            pad_name =  sys.argv[1]

    main(pad_name)

