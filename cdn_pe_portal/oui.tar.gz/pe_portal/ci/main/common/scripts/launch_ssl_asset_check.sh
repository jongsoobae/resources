#!/bin/bash

export DJANGO_SETTINGS_MODULE=ci.settings
export PYTHONPATH=$PYTHONPATH:/opt/cdn/ui/prod

usage() {
	echo "arguments: -r check|verify|notify"
}

if [ "-r" == "$1" ]; then
	if [ "check" == "$2" -o "verify" == "$2" -o "notify" == "$2" ]; then
		python /opt/cdn/ui/prod/ci/common/scripts/ssl_asset_checks.py $1 $2
	else
		usage
	fi
else
	usage
fi

