# a long-running script that polls each node in the system to check its status,
# as well as one node in each pop to check inter-pop visibility.
# 
# requires python != 2.4.3, because that version has a bug that prevents it
# from handling >1024 sockets in a select() or poll().

from hashlib import md5
import os
import re
import sys
import time
import socket
import logging
import logging.handlers
import random
import traceback
import pycurl
import calendar
from datetime import datetime, timedelta, date
from ci.common.utils.pycurl_handler import CurlHandler, processRequests, authGenerator
from decimal import Decimal
from math import floor
from ci.common.utils import json
from ci.common.models.stats import NodeStat, PopStat, BandStat, PopFailure
from ci.common.models.cdn import BAD_LAL, Node, Pop, Service, NodeLoadLimit
from ci.common.models.cache import Band, ShieldedService, ShieldedServiceBand
from ci.common.models.pusher import NodeUpdateFlush
from ci.constants import NOC, ALERT_ADDR, NO_REPLY
from ci.common.utils.cdn import get_all_pops, get_all_nodes
from ci.common.utils.alert import send_alert
from django.db import transaction
import gc; gc.set_debug(gc.DEBUG_UNCOLLECTABLE | gc.DEBUG_INSTANCES | gc.DEBUG_OBJECTS)
from MySQLdb import Warning
from django.core.cache import cache
from django.db import connection
from subprocess import Popen, PIPE
from ci.common.utils.mail import send_email

log_file = '/var/log/cdn/scripts/monitor_nodes.log'

log_handler = logging.handlers.RotatingFileHandler(log_file, maxBytes=2**20, backupCount=5)
log_handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s: %(message)s'))
logging.getLogger('').setLevel(logging.INFO)
logging.getLogger('').addHandler(log_handler)

localIP="" #set by main method...
IGNORE_FIRST_X_FAILURES = 2
TRIES_PER_POP = 3
REPEAT_THRESHOLD_MINS = 15

ACCEPTED_FLUSH_LAG = 1000

NO_RRD = os.environ.get('NO_RRD', False)
REQUEST_INTERVAL = 60
NMON_WEB_PORT = 8410
DNS_WEB_PORT = 8402
#TARGETS DEFINED LATER DUE TO REQUIREMENTS
TESTIMG_URL = 'http://%s/images/testimg.jpg'
TESTIMG_HOST = 'test.pantherexpress.net'
TESTIMG_HASH = 'a0c9f0e0fbbc77a6ca9e497fbbb4fb89'

MAX_BYTES_SERVED = 112500000
MAX_HEAP_USAGE = 70
MAX2_HEAP_USAGE = 95 # for PWS/8.0.7

URL_FLUSH_EMAIL = 'http://wiki.cdnetworks.com/confluence/display/CDNUS/Responding+to+Alerts#RespondingtoAlerts-otherbehindflush'

#Compares these to start of error...
SKIP_OUTPUT_ERRORS = ('Connection time-out', 
	'Operation timed out after',
	'Failed connect to',
	"Couldn't resolve host 'None'",
)

def write_iostat_rrd(host, iops, await):
	Popen('/usr/bin/rrdtool update /var/cdn/scripts/rrd/rrds/iostat-%s.rrd N:%s:%s' % (host, iops, await), shell=True, stdout=None)

def die(email=True):
	if email:
		from ci.common.utils.mail import send_email
		send_email(NOC,[ALERT_ADDR], '[alert] monitor_nodes died','monitor_nodes has hit a fatal error.')
	import os
	os.system('pkill -f monitor_nodes')

def trunc_float(n):
	try:
		return int(float(n)*10)/float(10)
	except ValueError:
		return n

def upsertStat(klass, obj_name, obj_id, **kwargs):
	try:
		try:
			stat = klass.objects.get_or_create(**{obj_name: obj_id})[0]
		except:
			stat = klass
		for k, v in kwargs.items():
			stat.__setattr__(k, v)
		stat.save()
	except Exception, e:
		#should fix this so its an error?
		logging.info("failed saving stat! message: " + str(e))

class NodeInfo:
	"""this is a class encapsulating a set of tests and results for a node."""
	def __init__(self, node_id, ip, hostname, node_type, state_manager, acceptable_flush_id):
		self.values = {}
		self.targets = list(TARGETS)
		self.node_id = node_id
		self.hostname = hostname
		self.ip = ip
		self.node_type = node_type
		self.state_manager = state_manager
		self.acceptable_flush_id = acceptable_flush_id
                try :
                        self.max_mbps = NodeLoadLimit.objects.get(node__id=node_id).max_mbps
                except Exception, e:
			self.max_mbps = 800
                        logging.info("couldn't get node load limits for node id %s" %(node_id))
	def update(self, data):
		self.values.update(data)
	def set(self, key, value):
		self.values[key] = value
	def set_flush(self, flush_id):
		try:
			if flush_id < self.acceptable_flush_id:
				self.state_manager.lagging_flush_nodes.append(self.node_id)
		except Exception, e:
			logging.info("Failed to check node flush: " + str(e))
	def increment_done(self):
		while len(self.targets) > 0:
			url, name, class_obj = self.targets.pop()
			if (str(self.node_type) == 'Http Node') and (str(class_obj) == '__main__.DnsConfigConsumer'):
				continue
			if (str(self.node_type) == 'Dns Node') and (str(class_obj) == '__main__.CSMenuTestConsumer'):
				continue
			return [class_obj(self.node_id, self.ip, name, self.hostname, url %(self.ip), self)]
		self.store()
	def stop_now(self):
		self.store()
	def skip_now(self):
		"""a file descriptor error has occurred; record nothing."""
		pass
	def store(self):
		logging.debug('saving for node %d: %s' % (self.node_id, self.values))
		try:
			node = Node.objects.get(pk=self.node_id)
		except:
			node = self.node_id
		try:
			#failed will be True either because HttpTestConsumer failed or was skipped due to nmon NodeTestedState being false
			upsertStat(NodeStat, "node", node, 
				rps=Decimal(str(self.values.get('Ips',0))), 
				mbps=Decimal(str(self.values.get('Mbps',0))), 
				ops=Decimal(str(self.values.get('Ops',0))), 
				diskio_ps=Decimal(str(self.values.get('DiskIops',0))), 
				disk_avg=Decimal(str(self.values.get('DiskAvg',0))), 
				failed=self.values.get('failed',True), 
				fail_reason=self.values.get('fail_reason',0),
				lal=self.values.get('NodeLal',0),
				ombps=Decimal(str(self.values.get('ombps',0))),
				o503ps=Decimal(str(self.values.get('o503ps',0))),
				c503ps=Decimal(str(self.values.get('c503ps',0))),
				smbps=Decimal(str(self.values.get('smbps',0))),
				ambps=Decimal(str(self.values.get('ambps',0))),
				heap_percent=Decimal(str(self.values.get('heap_percent',0))),
				upstream_conn=self.values.get('upstream_conn',0),
				downstream_conn=self.values.get('downstream_conn',0),
				disk_age_sec=self.values.get('disk_age_sec',0),
				)
			# write the disk io/s value to the appropriate RRD
			if not NO_RRD:
				write_iostat_rrd(self.values['NodeHostname'], self.values['DiskIops'], self.values['DiskAvg'])
		except KeyError,k:
			#need to set everything to zero to get rid of long term stats
			#upsertStat(NodeStat, "node", node, failed=True, fail_reason=0, rps=0, mbps=0, ops=0, diskio_ps=0, lal=0, ombps=0, o503ps=0, c503ps=0, smbps=0, ambps=0, heap_percent=0, upstream_conn=0, downstream_conn=0, disk_age_sec=0)
			pass
		except Warning, w:
			logging.info('warning for node %d (%s): [%s]' % (self.node_id, self.ip, w))
		except Exception, e:
			logging.error(traceback.format_exc())

def get_value_per_period(name, body, multiplier=1):
	val=re.findall("%s:.*\s([0-9]+)\/([0-9]+)" %(name),body)
	try :
		return int(val[0][1])*multiplier/int(val[0][0])
	except :
		raise Exception("err, get_value_per_period of "+str(name))

def get_value(name, body):
	try :
		return int(re.findall("%s:.*\s([0-9]+)" %(name), body)[0])
	except :
		raise Exception("err, get_value of "+str(name))

def get_host(name, body):
	try :
		return (re.findall("%s:.*\s([a-z\-.0-9]+)" %(name), body)[0])
	except :
		raise Exception("err, get_host of "+str(name))

def get_version(name, body):
	try :
		return (re.findall("%s:.*\s(PWS/[.0-9]+)" %(name), body)[0])
	except :
		raise Exception("err, get_host of "+str(name))

class CSMenuTestConsumer(CurlHandler):
	def __init__(self, node_id, ip, name, hostname, url, nodeinfo):
		self.node_id = node_id
		self.ip = ip
		self.nodinfo = nodeinfo
		self.url = url
		self.hostname = hostname
		self.nodeinfo = nodeinfo
	def getOptions(self):
		return {pycurl.URL: str(self.url),
			pycurl.COOKIE: authGenerator(self.hostname,localIP),
			pycurl.HTTPHEADER: [str("Host: " +self.hostname)]}
	def getUnsetOptions(self):
		return {pycurl.URL: "", pycurl.COOKIE: "",pycurl.HTTPHEADER: [""],}
	def handleError(self, body, error_num, error):
		if not str(error).startswith(SKIP_OUTPUT_ERRORS):
			logging.info('error for node %d (%s): [%s]' % (self.node_id, self.ip, error))
			self.nodeinfo.set('failed', True)
			self.nodeinfo.set('fail_reason',3)
		#do not require this as it is not yet on all nodes
		return self.nodeinfo.increment_done()
	def get_value_per_period(self,name):
		val=re.findall(name + ":.*\s([0-9]+)\/([0-9]+)",body)
		if not val:
			return 0
		return int(val[0][1])/int(val[0][0])
	def handleResponse(self,body):
		data = {}
		try:
			traffic = get_value_per_period("BytesServed", body)
			if traffic * 8 > self.nodeinfo.max_mbps * 1000*1000:
				self.nodeinfo.state_manager.high_traffic_nodes.append(self.hostname)
			data['ombps'] = get_value_per_period("OriginBytes", body)*8/1000**2
			data['o503ps'] = get_value_per_period("Origin503", body, multiplier=60)
			data['c503ps'] = get_value_per_period("Cache503", body, multiplier=60)
			data['smbps'] = get_value_per_period("ShieldBytes", body)*8/1000**2
			data['ambps'] = get_value_per_period("AffinityBytes", body)*8/1000**2
			data['heap_percent'] = get_value("MemHeapPercent", body)
			cs_version = None
			try :
				data['cs_host'] = get_host("Host", body)
				cs_version = get_version("Version", body)
				if data['heap_percent'] > MAX_HEAP_USAGE :
					logging.info("cs_host ["+data['cs_host']+"] cs_version:"+cs_version + " / heap_percent " + str(data['heap_percent']))
			except Exception,e :
				logging.error( "get CS_VERSION ::"+str(e) )
			if ( data['heap_percent'] > MAX_HEAP_USAGE and cs_version <> "PWS/8.0.7" ) or (data['heap_percent'] > MAX2_HEAP_USAGE and cs_version == "PWS/8.0.7" ):
				self.nodeinfo.state_manager.high_heap_nodes.append(self.hostname)
			data['upstream_conn'] = get_value("UpstreamActiveConnection", body)
			data['downstream_conn'] = get_value("DownstreamKeepAliveConnection", body)
			reportedtime=int(re.findall("CurrentTime:\s([0-9]*)",body)[0])/1000
			oldestFiles = [int(x)/1000 for x in re.findall("CacheVolume[0-9]*OldestFile:\s([0-9]*)",body)]
			oldestFiles.sort()
			data['disk_age_sec'] = reportedtime-oldestFiles[-1]
			if self.nodeinfo.values.get('failed', False) != True:
				data['failed'] = False
			self.nodeinfo.set_flush(get_value("LastFlushId", body))
			self.nodeinfo.update(data)
		except Exception, e:
			self.nodeinfo.set('failed',True)
			self.nodeinfo.set('fail_reason',3)
			logging.error("("+self.hostname+") got exception in csmenu stats handleResponse " + str(e))
		return self.nodeinfo.increment_done()

class NmonConsumer(CurlHandler):
	def __init__(self, node_id, ip, name, hostname, url, nodeinfo):
		self.node_id = node_id
		self.ip = ip
		self.name = name
		self.url = url
		self.nodeinfo = nodeinfo
	def getOptions(self):
		return {pycurl.URL: str(self.url)}
	def getUnsetOptions(self):
		return {pycurl.URL: ""}
	def handleError(self, body, error_num, error):
		self.nodeinfo.set('failed',True)
		self.nodeinfo.set('fail_reason',1)
		if not str(error).startswith(SKIP_OUTPUT_ERRORS):
			logging.info('error in looking glass for node %d (%s): [%s]' % (self.node_id, self.ip, error))
		return self.nodeinfo.increment_done()
	def handleResponse(self, body):
		try:
			resp_json = json.read(body)[self.name]
			# trim float values
			data = zip(resp_json[0], [trunc_float(i) for i in resp_json[1]])
			# add key/value pairs to the nodeinfo dictionary
			self.nodeinfo.update(data)
			if not self.nodeinfo.values.get('NodeTestedState'):
				self.nodeinfo.set('failed', True)
				self.nodeinfo.set('fail_reason',4)
			elif self.nodeinfo.values.get('failed', False) != True:
				self.nodeinfo.set('failed', False)
		except:
			logging.error("Failed reading response into json for node %d (%s).  Response was:\n%s" %(self.node_id, self.ip, str(body)))	
		return self.nodeinfo.increment_done()

class PopAbstractConsumer(CurlHandler):
	#need to have path object on children
	def __init__(self, pop_id, tested_state_manager, pop_list, band_list):
		self.pop_id = pop_id
		self.pop_list = pop_list[:] #make copy as I want to modify object per consumer
		self.band_list = band_list[:] #make copy as I want to modify object per consumer
		self.tested_state = tested_state_manager
		self.nodes = []
		self.tried_nodes = []
		self.nodeLevel = 0
		self.active = True
		self.port = NMON_WEB_PORT
	def getIp(self):
		if self.nodes != None and len(self.nodes) > 0:
			index = int(floor(random.random()*len(self.nodes)))
			node = self.nodes.pop(index)
			if node in self.tried_nodes:
				#need to skip this one...
				return self.getIp()
			#if here got a good option
			self.tried_nodes.append(node)
			return node

		#need to search level and make recursive call..
		node_query = None
		if self.nodeLevel == 0: #all dns nodes...
			#dns nodes so change port...
			self.port = DNS_WEB_PORT
			node_query = Node.objects.filter(pop=self.pop_id, node_type__id__gt = 1, broken=False)
		elif self.nodeLevel == 1: #all online non-failing nodes
			self.port = NMON_WEB_PORT
			node_query = Node.objects.filter(pop=self.pop_id, node_type__id = 1, broken=False, offline=False, nodestat__failed = False, nodestat__update_time__gt = datetime.now() - timedelta(minutes=5))
		elif self.nodeLevel == 2: #all nodes...
			self.port = NMON_WEB_PORT
			node_query = Node.objects.filter(pop=self.pop_id, broken=False)

		if node_query == None:
			self.active = False
			logging.warn("Tried all nodes to get %s from pop %d, nodes tried: %s" %(self.path, self.pop_id, str(self.tried_nodes)))
			return None #couldn't find any more IPs for node
		node_list = node_query.values_list('ipv4_address',flat=True)
		self.nodes = list(node_list)
		self.nodeLevel += 1
		return self.getIp()
	def getOptions(self):
		return {pycurl.URL: str("http://%s:%s%s" %(self.getIp(),self.port, self.path))}
	def getUnsetOptions(self):
		return {pycurl.URL: ""}
	def handleError(self, body, error_num, error):
		if len(self.tried_nodes) < TRIES_PER_POP and self.active:
			#try again...
			if not str(error).startswith(SKIP_OUTPUT_ERRORS):
				logging.warn("Failed %d times to get %s from pop %d trying node %s (will try again)" %(len(self.tried_nodes), self.path, self.pop_id, self.tried_nodes[-1]))
			return [self]
		if not str(error).startswith(SKIP_OUTPUT_ERRORS):
			logging.error('error for pop %d %s and url %s: %s' % (self.pop_id, self.tried_nodes, self.path, error))
		self.tested_state.set_pop_to_pop_data(self.pop_id, BAD_LAL, {}, {})

class PopToPopConsumer(PopAbstractConsumer):
	path = '/systemloaddigest?format=json'
	def handleResponse(self, body):
		try:
			response = json.read(body).get('SystemLoadDigest')
			#we want to write to database all failures possibly?!? as so we will record the list and then do counts on it
			#since this is service/band level we may see same node many times only count worst case so need to make list of all responses seen.
			pop_counts = {} # pop_id => ([node_ids passing], [node_ids failing])
			other_pop_lals = {}
			needPopLal = True
			popLal = BAD_LAL
			for node in response[1:]:
				pop_id, pop_name, pop_lal, node_id, node_hostname, tested_state, node_lal, node_mbps = node
				# update the lal for this pop
				if pop_id == self.pop_id and needPopLal and pop_lal != BAD_LAL:
					#silly way to go round to 1 decimal, but round function seems broken in python
					popLal = int(float(pop_lal)*10)/float(10)
					needPopLal = False
				try:
					if pop_id != self.pop_id and self.pop_list.pop(pop_id):
						#math is to round to 2 decimal points
						other_pop_lals[pop_id] = int(float(pop_lal)*10)/float(10)
				except:
					pass #if not found perfectly okay...prob. better way performance wise to do this
				# record what this pop sees of other pops
				if pop_id not in pop_counts:
					pop_counts[pop_id] = ([], [])
				if tested_state == 0  and node_id in self.tested_state.online_nodes:
					#set as failing...
					pop_counts[pop_id][1].append(node_id)
				elif tested_state == 1  and node_id in self.tested_state.online_nodes:
					#set as passing...
					self.tested_state.set_up_node(node_id)
					pop_counts[pop_id][0].append(node_id)
			for pop_id in self.pop_list:
				if pop_id not in pop_counts:
                                        pop_counts[pop_id] = ([], [-1])
			#now add info to tested state manager object...
			self.tested_state.set_pop_to_pop_data(self.pop_id, popLal, pop_counts, other_pop_lals)
		except Exception, e:
			logging.warn("Error parsing %s.  Error:\n %s" %(self.path, traceback.format_exc()))
			return self.handleError(body, -1, "Error Parsing Response")

class PopTestedStateConsumer(PopAbstractConsumer):
	path = '/poptestedstate?format=json'
	def handleResponse(self, body):
		try:
			response = json.read(body).get('PoPTestedState')
			#we want to write to database all failures possibly?!? as so we will record the list and then do counts on it
			serviceband_counts = {} #(service_id, band_id) => ([node_ids passing], [node_ids failing])
			#since this is service/band level we may see same node many times only count worst case so need to make list of all responses seen.
			band_counts = {} # band_id => ([node_ids passing], [node_ids failing])
			service_counts = {} # service_id => ([node_ids passing], [node_ids failing])
			myBandLals = {}
			other_pop_lals = {}
			other_band_lals = {}
			self_offline = 0
			for node in response[1:]:
				service_id, service_name, band_id, band_name, band_lal, pop_id, pop_name, pop_lal, node_id, node_hostname, node_ip, tested_state = node
				if service_id == -1:
					continue #no service, we don't care about it.
					#this could be bad idea for shield bands.

				# update the lal for this pop
				if pop_id == self.pop_id and not myBandLals.has_key(band_id):
					#silly way to go round to 1 decimal, but round function seems broken in python
					myBandLals[band_id] = int(float(band_lal)*10)/float(10)
				# record what this pop sees of itself
				service_band = (service_id, band_id)
				if band_id not in band_counts:
					band_counts[band_id] = ([], [])
				if service_id not in service_counts:
					service_counts[service_id] = ([], [])
				if service_band not in serviceband_counts:
					serviceband_counts[service_band] = ([], [])
				if tested_state == 0 and node_id in self.tested_state.online_nodes:
					#set as failing...
					serviceband_counts[service_band][1].append(node_id)
					band_counts[band_id][1].append(node_id)
					service_counts[service_id][1].append(node_id)
				elif tested_state == 1 and node_id in self.tested_state.online_nodes:
					#set as passing...
					self.tested_state.set_up_node(node_id)
					serviceband_counts[service_band][0].append(node_id)
					band_counts[band_id][0].append(node_id)
					service_counts[service_id][0].append(node_id)

			#now add info to tested state manager object...
			self.tested_state.set_pop_data(self.pop_id, myBandLals, serviceband_counts, service_counts, band_counts, other_band_lals)
		except Exception, e:
			if body > "":
				logging.warn("Error parsing %s.  Error:\n %s" %(self.path, traceback.format_exc()))
			return self.handleError(body, -1, "Error Parsing Response")

#[cdn@n5 ~]$ curl localhost:8402/date?format=json
#{"http-sites":1261,"dns":20365,"system-load-limit":20300,"date":1279841332,"contentDistribution":0}

class DnsConfigConsumer(CurlHandler):
	def __init__(self, node_id, ip, name, hostname, url, nodeinfo):
		self.node_id = node_id
		self.ip = ip
		self.url = url
		self.nodeinfo = nodeinfo
	def getOptions(self):
		return {pycurl.URL: str(self.url)}
	def getUnsetOptions(self):
		return {pycurl.URL: ""}
	def handleError(self, body, error_num, error):
		logging.error(error)
		self.nodeinfo.set('failed',True)
		self.nodeinfo.set('fail_reason',2)
		#self.nodeinfo.state_manager.stale_config_nodes.append((self.node_id, self.nodeinfo.hostname, 'http-sites'))
		if not str(error).startswith(SKIP_OUTPUT_ERRORS):
			logging.info('error in looking glass for node %d (%s): [%s]' % (self.node_id, self.ip, error))
		return self.nodeinfo.increment_done()
	def handleResponse(self, body):
		try:
			resp_json = json.read(body)
			# add key/value pairs to the nodeinfo dictionary
			self.nodeinfo.update(resp_json)
			stale_configs = []
 			all_dates = self.nodeinfo.values.get('Date')
 			for pair in all_dates:
 				if (pair[0] == 'http-sites') :
 					hs_date = calendar.timegm(time.strptime(pair[1], '%a %b %d %H:%M:%S %Z %Y'))
 				if (pair[0] == 'dns') :
 					d_date = calendar.timegm(time.strptime(pair[1], '%a %b %d %H:%M:%S %Z %Y'))
 				if (pair[0] == 'system-load-limit') :
 					sll_date = calendar.timegm(time.strptime(pair[1], '%a %b %d %H:%M:%S %Z %Y'))
 				if (pair[0] == 'contentDistribution') :
 					cd_date = calendar.timegm(time.strptime(pair[1], '%a %b %d %H:%M:%S %Z %Y'))
 			if (int(hs_date) < 0):
				stale_configs.append('http_sites')
				logging.error("DnsConfigConsumer saw stale http-sites on %s" %(self.ip))
			if (int(d_date) < 0):
				stale_configs.append('dns')
				logging.error("DnsConfigConsumer saw stale dns on %s" %(self.ip))
			if (int(sll_date) < 0):
				stale_configs.append('system-load-limit')
				logging.error("DnsConfigConsumer saw stale system-load-limit on %s" %(self.ip))
			if (int(cd_date) < 0):
				stale_configs.append('contentDistribution')
				logging.error("DnsConfigConsumer saw stale contentDist on %s" %(self.ip))
			
			if len(stale_configs) > 0 :
				self.nodeinfo.state_manager.stale_config_nodes.append((self.node_id, self.nodeinfo.hostname,','.join(stale_configs)))

		except:
			logging.error("Failed reading response into json for node %d (%s).  Response was:\n%s" %(self.node_id, self.ip, str(body)))
			logging.warn(traceback.format_exc())
		return self.nodeinfo.increment_done()

def queue_jobs(state_manager):
	"""
	Every time this is called the following occurrs:
	1. each pop is polled for system load digest and pop tested state via looking glass interface.
	2. each node is polled for node load via looking glass interface.
	3. each node has stats retrieved from cs menu stats page
	4. each dns node has date and timestamp on http-sites and contentDist pulled via looking glass

	This script executes the calls which are then processed concurrently.
	"""
	try:
		flush_id = NodeUpdateFlush.objects.latest().id-ACCEPTED_FLUSH_LAG
	except Exception, e:
		flush_id = -1
		logging.info("Failed to get flush id not testing: " + str(e))
	pops = get_all_pops()
	pop_list = list(pops.values_list('id',flat=True)) 
	band_list = list(Band.objects.values_list('id', flat=True))
	nodes = get_all_nodes()
	tasks = []
	for pop in pops.filter(offline=False):
		tasks.append(PopTestedStateConsumer(pop.id, state_manager,pop_list, band_list))
		tasks.append(PopToPopConsumer(pop.id, state_manager,pop_list, band_list))
	for node in nodes:
		nodeinfo = NodeInfo(node.id, node.ipv4_address, node.hostname, node.node_type, state_manager, flush_id)
		for item in nodeinfo.increment_done():
			tasks.append(item)
	return tasks

class TestedStateManager:
	def __init__(self):
		self.recent_alerts = {}
		self.repeated_alerts = {}
		self.high_traffic_nodes = []
		self.high_heap_nodes = []
		self.reset()
	def set_pop_to_pop_data(self, pop_id, pop_lal, pop_counts, pop_lals):
		"""*_counts should be tuples of 2 items list of nodes that passed and list of nodes that failed (node could be repeated or in both)
		*_lals - dictionary of lal by key,
		for pops_band_lals bands pop has atleast 1 node in with the value being the lal"""
		self.__set_lals__(self.pop_lals, pop_lals)
		if len(pop_counts) > 0 or len(pop_lals) > 0:
			def pop_failure_callback(source, target):
				PopFailure.objects.get_or_create(source_pop=Pop.objects.get(pk=source), target_pop=Pop.objects.get(pk=target))[0].save()
			self.__set_level_of_data__(pop_id, pop_counts, self.pop_pop_failing, see_failing_dict=self.pop_see_failing, skip_see_failing = self.offline_pops,
                        	info_dict = self.pop_info, info_lals={pop_id: pop_lal}, failing_callback=pop_failure_callback, self_only_info_dict=True)
	def set_up_node(self, node_id):
		"""node ids that are up..."""
		if node_id not in self.up_nodes:
			self.up_nodes.append(node_id)
	def set_pop_data(self, pop_id, pops_band_lals, serviceband_counts, service_counts, band_counts, all_band_lals):
		"""*_counts should be tuples of 2 items list of nodes that passed and list of nodes that failed (node could be repeated or in both)
		*_lals - dictionary of lal by key,
		for pops_band_lals bands pop has atleast 1 node in with the value being the lal"""
		self.__set_lals__(self.band_lals, all_band_lals)
		#these are really only seeing part each so pop_id should match to aggregate data...
		self.__set_level_of_data__(0, serviceband_counts, self.serviceband_pop_failing, info_dict = self.serviceband_pop_infodict)
		self.__set_level_of_data__(0, service_counts, self.service_pop_failing, info_dict = self.service_pop_infodict)
		self.__set_level_of_data__(0, band_counts, self.band_pop_failing, info_dict = self.band_info, info_lals=pops_band_lals)
	def __set_lals__(self,master_lals, lals):
		for key, value, in lals.iteritems():
			master_lals[key] = max(master_lals.get(key,-1), value)
	def __set_level_of_data__(self, reporter_id, counts, failing_dict, see_failing_dict=None, skip_see_failing = [], info_dict=None, info_lals=None, failing_threshold=50, failing_callback=None, self_only_info_dict=False):
		"""set info/failing based on each group..."""
		for id, pass_fail in counts.iteritems():
			failing = len(set(pass_fail[1]))
			passing = len(set(pass_fail[0]).difference(pass_fail[1]))
			if info_dict != None and (not self_only_info_dict or id == reporter_id):
				info = info_dict.get(id)
				if info == None:
					info = (BAD_LAL, 0, 0)
				if info_lals != None and id in info_lals:
					lal = max(info[0], info_lals.pop(id)) if info[0] < BAD_LAL else info_lals.pop(id)
				else:
					lal = info[0]
				passing += info[1]
				failing += info[2]
				info_dict[id] = (lal, passing, failing)
			failing_percent = int(float(failing) /(failing+passing) * 100) if failing > 0 or passing > 0 else 100
			failing_data = failing_dict.get(id)
			see_failing = see_failing_dict.get(reporter_id) if see_failing_dict != None else None
			if failing_percent > failing_threshold:
				if failing_data == None:
					failing_data = {}
					failing_dict[id] = failing_data
				if failing_callback:
					try:
						failing_callback(reporter_id,id)
					except Exception, e:
						logging.warn("Failure callback failed\n%s" % traceback.format_exc())
				failing_data[reporter_id] = failing_percent
				if see_failing_dict != None and id not in skip_see_failing:
					if see_failing == None:
						see_failing = {}
						see_failing_dict[reporter_id] = see_failing
					see_failing[id] = failing_percent
			else:
				#remove if listed as failing....
				#this could happen for a cross pop group (service, multi pop band, etc.) where it is failling in 1 pop and not in another...
				if failing_data != None:
					#see if it is already there and remove it....
					failing_data.pop(reporter_id,None)
				if see_failing != None:
					see_failing.pop(id,None)
				
		if info_lals != None and len(info_lals) > 0:
			for id, lal in info_lals.iteritems():
				if not info_dict.has_key(id):
					info_dict[id] = (lal, 0, 0)
	def __store_all_info__(self, stat_class, info_dict, id_filter, voted_lals = {}, id_conversion_function=lambda x:x):
		for id, info in info_dict.iteritems():
			try:
				id_val = id_conversion_function(id)
			except:
				id_val = "Unknown (ID: %s)" %(str(id))

			lal = info[0] if info != BAD_LAL else voted_lals.get(id,BAD_LAL)
			if info[1] > 0 or info[2] > 0:
				offline = Node.objects.filter(**{id_filter:id_val}).count() - info[1] - info[2]
				upsertStat(stat_class, id_filter, id_val, lal=lal, offline_count=offline, passing_count=info[1], failing_count=info[2])
			else:
				upsertStat(stat_class, id_filter, id_val, lal=lal)
	def reset(self):
		self.serviceband_pop_failing = {} #(service_id,band_id) => dictionary with pop that sees it failing as key and percent failing as value
		self.serviceband_pop_infodict = {} #to track cross pop data
		self.service_pop_failing = {} #service_id => dictionary with pop that sees it failing as key and percent failing as value
		self.service_pop_infodict = {} #to track cross pop data
		self.band_pop_failing = {} #band_id => dictionary with pop that sees it failing as key and percent failing as value
		self.pop_pop_failing = {} #pop_id => dictionary with pop that sees it failing as key and percent failing as value
		self.pop_see_failing = {} #pop_id => dictionary with pop that sees it failing as key and percent failing as value
		self.pop_info = {} #pop_id => (pop_lal, passing_count, failing_count)
		self.band_info = {} #band_id => (band_lal, passing_count, failing_count)
		self.prev_repeated_alerts = self.repeated_alerts #swap out so we lose non-repeated ones.
		self.pop_lals = {}
		self.band_lals = {}
		self.repeated_alerts = {}
		self.up_nodes = []
		self.lagging_flush_nodes = []
		self.offline_pops = list(get_all_pops().filter(offline=True).values_list('id',flat=True))
		self.online_bands = list(Band.objects.filter(node__pop__offline=False,node__offline=False).distinct().values_list('id',flat=True))
		self.online_nodes = list(get_all_nodes().filter(offline=False,pop__offline=False).values_list('id',flat=True))
		self.stale_config_nodes = []
		self.high_traffic_nodes = []
		self.high_heap_nodes = []
	def recordAndAlert(self):
		#record info...
		self.__store_all_info__(PopStat, self.pop_info, "pop", voted_lals=self.pop_lals, id_conversion_function=lambda x:Pop.objects.get(id=x))
		self.__store_all_info__(BandStat, self.band_info, "band", voted_lals=self.band_lals, id_conversion_function=lambda x:Band.objects.get(id=x))
		
		#check for problems and record/alert on them...
		alerts = {'pops': [], 'pops (sees 50% other pops failing)': [], 'bands': [], 'shields': [],
			'services (50% node failure)': [], 'service (band threshold exceeded)': [], 'nodes': [], 'node flushes': [], 'node traffic': [], 'heap usage': []}
		alert_order = ['pops', 'pops (sees 50% other pops failing)', 'service (band threshold exceeded)', 
			'services (50% node failure)', 'bands', 'shields', 'nodes', 'node flushes', 'node traffic', 'heap usage']
		email_not_alert = ['nodes', 'node traffic']

		bands_in_alert_state = []
		#this is threshold used for all checks... 1/2 of pops!
		threshold = 0
		for pop in self.pop_info.values():
			if pop[1] > 0 or pop[2] > 0:
				threshold += 1
		threshold = threshold / float(2)

		###Alert on PoPs seen failing###
		def popDownMessage(id, down_count, min_down, max_down):
			try:
				pop_name = Pop.objects.get(pk = id).shortname()
			except:
				pop_name = "Unknown (ID: %d)" %(id)
			return 'pop %s is down (according to %d other pops %d%% to %d%% nodes are down)' % (pop_name, down_count, min_down, max_down)
		alerts['pops'] = self.__over_threshold_down__(self.pop_pop_failing, threshold, popDownMessage, skip_ids = self.offline_pops)

		###Alert on PoPs seeing others failing###
		def popSeesDownMessage(id, down_count, min_down, max_down):
			try:
				pop_name = Pop.objects.get(pk = id).shortname()
			except:
				pop_name = "Unknown (ID: %d)" %(id)
			return 'pop %s sees %d other pops down (%d%% to %d%% nodes down per pop)' % (pop_name, down_count, min_down, max_down)
		alerts['pops (sees 50% other pops failing)'] = self.__over_threshold_down__(self.pop_see_failing, threshold, popSeesDownMessage, skip_ids = self.offline_pops)
		
		###Alert on Bands seen failing###
		def bandDownMessage(id, down_count, min_down, max_down):
			try:
				band_name = Band.objects.get(pk = id)
			except:
				band_name = "Unknown (ID: %d)" %(id)
			return 'band %s is down (%d%% nodes are down)' %(band_name, min_down)
		alerts['bands'] = self.__over_threshold_down__(self.band_pop_failing, .5, bandDownMessage, limit_ids = self.online_bands)

		###Make list of all bands that are in alert state###
		down_bands = []
		for value in alerts['bands']:
			down_bands.append(value[0])

		###Alert on Services seen failing###
		def serviceDownMessage(id, down_count, min_down, max_down):
			try:
				service_name = Service.objects.get(pk = id).name
			except:
				service_name = "Unknown (ID: %d)" %(id)
			return 'service %s is down (%d%% to %d%% nodes are down)' %(service_name, min_down, max_down)
		alerts['services (50% node failure)'] = self.__over_threshold_down__(self.service_pop_failing, .5, serviceDownMessage)

		###Alert on front end Services seen failing###
		#get all services with atleast 1 band failing...
		affected_services = Service.objects.filter(band__id__in = down_bands)
		for service in affected_services:
			fail = service.band_set.filter(id__in = down_bands).count()
			if fail >= service.pop_down_threshold:
				msg = '%d bands in %s are down (the threshold is %d)' %(fail, service.name, service.pop_down_threshold)
				if not alerts.has_key('service (band threshold exceeded)'):
					alerts['service (band threshold exceeded)'] = []
				alerts['service (band threshold exceeded)'].append((service.id,msg))

		###Alert on shields for shielded services seen failing###
		#get all shields with atleast 1 band failing...
		affected_shields = ShieldedServiceBand.objects.filter(band__id__in = down_bands)
		found_shields = {}
		for shield in affected_shields:
			key = (shield.shielded_service.id,shield.cache_level, shield.region)
			if found_shields.has_key(key):
				#already checked this combo so skip
				continue
			found_shields[key] = True
			if ShieldedServiceBand.objects.filter(shielded_service = shield.shielded_service, cache_level = shield.cache_level, region = shield.region).exclude(band__id__in = bands_in_alert_state).count() == 0:
				#if here then all bands in shielded_service/cache_level/region are failing
				msg = 'all bands in cache level %d, group %d for shielded service %s are down' %(shield.cache_level, shield.region, shield.shielded_service.name)
				if not alerts.has_key('shields'):
					alerts['shields'] = []
				alerts['shields'].append((key[0], key[1], key[2]), msg)

		###Now check nodes...
		#get list of nodes that are passing currently...
		passing_nodes = set(list(get_all_nodes().filter(nodestat__failed=False, nodestat__update_time__gt = datetime.now() - timedelta(minutes=5)).values_list('id',flat=True)))
		passing_not_seen = passing_nodes.difference(self.up_nodes)
		seen_not_passing = set(self.up_nodes).difference(passing_nodes)
		for node in seen_not_passing:
			if node in self.online_nodes:
				try:
					node_name = str(Node.objects.get(id=node))
				except:
					node_name = "Unknown (ID: %s)"  %(str(node))
				node_failed_text = NodeStat.objects.get(node=node).fail_reason_text()
				alerts['nodes'].append( ((node,'seen'), 'Node %s is up according to other nodes but down according to monitor because %s' %(node_name, node_failed_text)))
				

		for node in passing_not_seen:
			if node in self.online_nodes:
				try:
					node_name = str(Node.objects.get(id=node))
				except:
					node_name = "Unknown (ID: %s)"  %(str(node))
				#moved to log for now this is not critical
				logging.info('Node %s is down according to other nodes but up according to monitor' %(node_name) )
				#alerts['nodes'].append( ((node,'passing'), 'Node %s is down according to other nodes but up according to monitor' %(node_name)))

		###Alert on lagging flushes....
		for node in self.lagging_flush_nodes:
			if node in self.online_nodes and node in passing_nodes:
				try:
					node_name = str(Node.objects.get(id=node))
				except:
					node_name = "Unknown (ID: %s)"  %(str(node))
				alerts['node flushes'].append( ((node,'flush'), 'Node %s is behind on flushes %s' %(node_name, URL_FLUSH_EMAIL)))

		###Alert on nodes reporting high bytes served....
		for node in self.high_traffic_nodes:
			alerts['node traffic'].append( ((node,'nodes'), 'Node %s has served more than %s bytes/sec. It may be close to NIC limit, check for packet loss and slow responses.' %(node, MAX_BYTES_SERVED)))

		###Alert on nodes reporting high heap usage....
		for node in self.high_heap_nodes:
			alerts['heap usage'].append( ((node,'nodes'), 'Node %s is using more than %s percent heap. CS may be GC\'ing, check for slow responses.' %(node, MAX_HEAP_USAGE)))		

		## alert on stale configs
		while len(self.stale_config_nodes) > 0:
			node_id, node_name, reason = self.stale_config_nodes.pop()
			if node_id in self.online_nodes and node_id in passing_nodes:
				alerts['nodes'].append(((node_id,'stale config'), 'Node %s has stale config %s' %(node_name,reason)))

		###For writing to restart nodes file
		restart_nodes=[]
		###Now send out alert###
		message = ""
		total_items = 0
		email_message = ""
		email_items = 0
		for key in alerts:
			if key not in alert_order:
				alert_order.append(key)
		for key in alert_order:
			items = alerts[key]
			item_count = 0
			item_msg = ""
			email_count = 0
			email_msg = ""
			for item in items:
				self.repeated_alerts[(key,item[0])] = self.prev_repeated_alerts.get( (key,item[0]),0 ) + 1
				if self.repeated_alerts[(key,item[0])] <= IGNORE_FIRST_X_FAILURES:
					#haven't seen error enough times to know its legit
					logging.info("alert for type: %s and id: %s seen failing %d times, will alert after %d repeated failures" 
						%(str(key), str(item[0]), self.repeated_alerts[(key,item[0])], IGNORE_FIRST_X_FAILURES+1) )
					continue
				if self.recent_alerts.has_key((key,item[0])) and time.time() - self.recent_alerts.get((key,item[0])) < 60* REPEAT_THRESHOLD_MINS:
					logging.info("alert for type: %s and id: %s seen failing %d times, alert sent recently" 
						%(str(key), str(item[0]), self.repeated_alerts[(key,item[0])]) )
					#already reported within threshold so skip
					continue
				#if here add to alert message...
				logging.info("alert triggered for type: %s and id: %s" 
						%(str(key), str(item[0])) )
				if str(key) == 'heap usage':
					restart_nodes.append(item[0][0])

				self.recent_alerts[(key,item[0])] = time.time()
				if key in email_not_alert:
					email_count += 1
					email_msg += "\n\n" + item[1]
				else:
					item_count += 1
					item_msg  += "\n\n" + item[1]
			if item_count > 0:
				message += "\n\n\n---Issues found for %d %s---%s" %(item_count, key, item_msg)
				total_items += item_count
			if email_count > 0:
				email_message += "\n\n\n---Issues found for %d %s---%s" %(email_count, key, email_msg)
				email_items += email_count
		if total_items > 0:
			send_alert("App :: OUI", "[alert] %d Service affecting issues" %(total_items), message)
			logging.info("Alert sent with %d items to alert on" %(total_items))
		if email_items >0:
			send_email(NO_REPLY,[NOC], "%d Service affecting issues" %(email_items), email_message)
			logging.info(email_message)
			logging.info("email sent with %d items to alert on" %(email_items))
		if len(restart_nodes) > 0:
			filename = "/var/cdn/scripts/restart-nodes/" + str(int(time.time())) + ".heap"
			file = open(filename, "w")
	                for node in restart_nodes:
        	                file.write(node)
                	        file.write("\n")
             		file.close()


	def __over_threshold_down__(self, failing_dict, threshold, message_function, limit_ids=None, skip_ids=[]):
		"""Adds to alert any object with the size of failing_dict greater than the threshold value
		message_function should be a function that takes 4 arguments and returns a string
			arguments: id of object, # reporting it failing, min failing percent, max failing percent
				skip_ids are ids that will not cause alerts
				limit_ids if not set are the only ids that will cause alert
		This returns a list of tuples of 2 values: id of alert (id should be unique in this group) and alert messages to be sent out"""
		alerts = []
		for id, stats in failing_dict.iteritems():
			#go through stats and count only valid ids...
			if len(stats) > threshold and (limit_ids == None or id in limit_ids) and id not in skip_ids:
				#okay so we now need to alert...
				values = stats.values()
				alerts.append( (id, message_function(id,len(stats), min(values), max(values))) )
		return alerts

#Needs to be defined after classes...
TARGETS = (
        ('http://%s:' + str(NMON_WEB_PORT) + '/nodeload?format=json','NodeLoad',NmonConsumer),
	('http://%s:' + str(DNS_WEB_PORT) + '/date?format=json','',DnsConfigConsumer),
        ('http://%s/stats','Stats',CSMenuTestConsumer)
)

def main(reps):
	last_error = None
	stay_alive = True
	state_manager = TestedStateManager()
	while stay_alive:
		try:
			while reps is None or reps > 0:
				start_time = time.time()
				tasks = queue_jobs(state_manager)
				logging.info('launching %d jobs.' %(len(tasks)))
				processRequests(tasks, log=True, numConnections=200)
				transaction.commit_unless_managed() # this lets new nodes/pops get noticed
				logging.info('all jobs processed.')
				#now do post processing work...
				state_manager.recordAndAlert()
				state_manager.reset()
				transaction.commit_unless_managed() # this lets new nodes/pops get noticed
				logging.info('done with updating bands and checking for alerts to send')
				while time.time() - start_time < REQUEST_INTERVAL:
					time.sleep(2)
				if reps: reps -= 1
			stay_alive = False
			logging.info('shutting down...')
			die(email=False)
		except KeyboardInterrupt, e:
			die(email=False)
		except Exception, e:
			logging.error('%s\nHard Error!' % traceback.format_exc())
			if last_error != None and time.time() - last_error  < REQUEST_INTERVAL * 2:
				die()
				stay_alive = False #should never happen but be safe...
			last_error = time.time()

if __name__ == '__main__':
	s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
	s.connect(("pantheroui.cdnetworks.com",0))
	localIP = s.getsockname()[0]
	s.close()
	if len(sys.argv) < 2:
		reps  = None
	else:
		reps = int(sys.argv[1])
	main(reps)
