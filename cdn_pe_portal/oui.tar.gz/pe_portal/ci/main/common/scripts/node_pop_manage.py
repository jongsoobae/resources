from optparse import OptionParser
from ci.common.models.cdn import Pop, Node, PopLoadLimit, ServicePopRoutingFactors, PopNetworkDistance
from django.db.models import Q
from django.core.exceptions import ObjectDoesNotExist
from django.db import transaction, connection
from ci.common.models.stats import PopFailure

def move_nodes(src_pop_id, des_pop_id):
	try:
		src_pop_obj = Pop.objects.get(id = src_pop_id)
	except:
		src_pop_obj = None
	try:
		des_pop_obj = Pop.objects.get(id = des_pop_id)
	except:
		des_pop_obj = None

	if not src_pop_obj:
		print "no pop for source"
	if not des_pop_obj:
		print "no pop for destination"

	if src_pop_obj and des_pop_obj:
		src_nodes =  Node.objects.filter(pop = src_pop_id)
		for node in src_nodes:
			node.pop = des_pop_obj
			node.save()

def delete_pop(src_pop_id):
	src_pop_obj = None
	try:
	        src_pop_obj = Pop.objects.get(id = src_pop_id)
	except:
		pass

	node_cnt = src_pop_obj.node_set.count()
	if node_cnt > 0:
		print "This pop has nodes, can't be deleted"
	
	if src_pop_obj and node_cnt == 0:
		
		try:
		        item_obj = PopLoadLimit.objects.get(pop = src_pop_obj)
			item_obj.delete()
		except ObjectDoesNotExist:
			pass
		try:
		        item_obj = ServicePopRoutingFactors.objects.filter(pop = src_pop_obj)
	        	item_obj.delete()
		except ObjectDoesNotExist:
			pass

	        item_obj = PopNetworkDistance.objects.filter(Q(pop1 = src_pop_obj) | Q(pop2 = src_pop_obj))
		item_obj.delete()

		item_obj = PopFailure.objects.filter(Q(source_pop = src_pop_obj) | Q(target_pop = src_pop_obj))
		item_obj.delete()

		cursor = connection.cursor()
		cursor.execute ("delete from pop where pop_id = %d"%src_pop_id)
	else:
		print "No pop to delete"

	transaction.commit_unless_managed()


if __name__ == '__main__':
	parser = OptionParser()
	parser.add_option('-m', '--move', nargs=2)
	parser.add_option('-d', '--delete', nargs=1)
	(options, args) = parser.parse_args()

	if options.move:
 		src_pop_id = int(options.move[0])
		des_pop_id = int(options.move[1])
		move_nodes(src_pop_id, des_pop_id)
 
	if options.delete:
 		src_pop_id = int(options.delete)
		delete_pop(src_pop_id)
 
