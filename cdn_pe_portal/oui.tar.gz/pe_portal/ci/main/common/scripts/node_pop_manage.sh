#!/bin/bash

export DJANGO_SETTINGS_MODULE=ui.oui.settings
export PYTHONPATH=$PYTHONPATH:/opt/cdn/ui/prod

usage() {
	echo "arguments: -m|-d src_pop_id [des_pop_id]"
}

case "$1" in
	"-m")
		python ./node_pop_manage.py $1 $2 $3;;
	"-d")
		python ./node_pop_manage.py $1 $2;;
	*)
		usage;;
esac
