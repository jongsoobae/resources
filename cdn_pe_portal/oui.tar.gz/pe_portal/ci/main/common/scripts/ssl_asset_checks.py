"""
This script has three sections:
	SECTION ONE: Runs every 15 minutes and checks that all ssl assets listed in the db have the corresponding p12  and auth files on the ks box.
	 			 This should also verify the files using the stored md5 hash for both .auth and .p12 files.
	SECTION TWO: Runs once every day to make sure all keystore files on the ks box have a corresponding database entry.
	SECTION THREE: Runs once a week to notify customers whose certificates are expiring in three months or less. NOC is also CC-ed for tracking purposes.
"""
import logging
import logging.handlers
from optparse import OptionParser
from datetime import datetime,timedelta, date
from django.contrib.auth.models import User as AuthUser
from django.core.exceptions import ObjectDoesNotExist
from ci.common.models.customer import SSLKeystore, Customer
from ci.common.utils.alert import send_alert
from ci.common.utils.mail import send_email
from ci.constants import NOC_ADDR, NO_REPLY, KEYSTORE_HOST, KEYSTORE_USER, KEYSTORE_KEY_PRIV, KEYSTORE_PORT, KEYSTORE_PATH_PREFIX, TRUSTED_CERTS_PATH
from ci.common.utils.ssh_client import ssh_client

# TODO  This should also verify the files using the stored md5 hash for both .auth and .p12 files.


log_file = '/var/log/cdn/scripts/ssl_check.log'
log_handler = logging.handlers.RotatingFileHandler(log_file, maxBytes=2**20, backupCount=5)
log_handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s: %(message)s'))
logging.getLogger('').setLevel(logging.INFO)
logging.getLogger('').addHandler(log_handler)


def test_ks_files():
	client = ssh_client()

	client.ssh_settings(host=KEYSTORE_HOST, user=KEYSTORE_USER, port=KEYSTORE_PORT, key_priv=KEYSTORE_KEY_PRIV)

	ks_list = SSLKeystore.objects.all()

	for ks in ks_list:
		std_in_p12, std_out_p12, std_err_p12 = client.ssh_command("if [ -f %s02-ready/ks%d.p12 ] ; then echo True; fi" % (KEYSTORE_PATH_PREFIX, ks.keystore_id), shell=True)
		std_in_auth, std_out_auth, std_err_auth = client.ssh_command("if [ -f %s02-ready/ks%d.auth ] ; then echo True; fi" % (KEYSTORE_PATH_PREFIX, ks.keystore_id), shell=True)

		p12_check, auth_check = std_out_p12.read(), std_out_auth.read()

		if p12_check.startswith('True') and auth_check.startswith('True'):
                        if not ks.ks_file_hash == client.ssh_command("md5sum %s02-ready/ks%d.p12" % (KEYSTORE_PATH_PREFIX, ks.keystore_id), shell=True)[1].read().split(' ')[0].strip() \
                                or not ks.auth_file_hash == client.ssh_command("md5sum %s02-ready/ks%d.auth" % (KEYSTORE_PATH_PREFIX, ks.keystore_id), shell=True)[1].read().split(' ')[0].strip():
				send_alert('App :: OUI ', 'md5sum check of keystores file failed', "The check on SSL asset files for domain %s has failed. \n\n Keystore File(ks%d.p12)\n\n Auth file(ks%d.auth)" % (ks.domain,ks.keystore_id, ks.keystore_id))
		else:
                        send_alert('App :: OUI ', 'A keystore file has gone missing', "The check on SSL asset files for domain %s has failed. \n\n Keystore File(ks%d.p12): %s \n\n Auth file(ks%d.auth): %s " % (ks.domain,ks.keystore_id, 'found' if p12_check.startswith('True') else 'NOT FOUND', ks.keystore_id, 'found' if auth_check.startswith('True') else 'NOT FOUND'))


def verify_ks_files():
	client = ssh_client()
	client.ssh_settings(host=KEYSTORE_HOST, user=KEYSTORE_USER, port=KEYSTORE_PORT, key_priv=KEYSTORE_KEY_PRIV)

	p12_in, p12_out, p12_err = client.ssh_command('ls %s02-ready/*.p12' % KEYSTORE_PATH_PREFIX, shell=True)

	auth_in, auth_out, auth_err = client.ssh_command('ls %s02-ready/*.auth' % KEYSTORE_PATH_PREFIX, shell=True)

	p12_err_text = p12_err.read()
	auth_err_text = auth_err.read()
	if p12_err_text>'' or auth_err_text>'':
		send_email(NO_REPLY, NOC_ADDR, "Keystore file check failed", "The daily check for ghost SSL assets failed... \n %s\n%s" % (p12_err_text, auth_err_text))
	else:
		p12_file_list = p12_out.read().splitlines()
		auth_file_list = auth_out.read().splitlines()
		missing_auth = []
		missing_p12 = []
		for each in p12_file_list:
			k_id = int(each[:-4][11:])
			if '%s02-ready/ks%d.auth'% (KEYSTORE_PATH_PREFIX, k_id) in auth_file_list:
				try:
					k_row = SSLKeystore.objects.get(pk=k_id)
				except ObjectDoesNotExist:
					missing_auth.append("%s02-ready/ks%d.auth"%(KEYSTORE_PATH_PREFIX, k_id))
					missing_p12.append("%s02-ready/ks%d.p12"%(KEYSTORE_PATH_PREFIX, k_id))
				auth_file_list.remove("%s02-ready/ks%s.auth" % (KEYSTORE_PATH_PREFIX, k_id))
			else:
				missing_auth.append("%s02-ready/ks%d.auth (missed)"%(KEYSTORE_PATH_PREFIX, k_id))
		if auth_file_list:
			missing_auth+=auth_file_list
		if missing_auth or missing_p12:
			send_email(NO_REPLY, NOC_ADDR, "Keystore file cleanup list", "The following files on ks.panthercdc.com do not have matching db entries:%s %s" % ("\nGhost auth files:\n %s" %('\n'.join(missing_auth))if missing_auth else '',"\nGhost p12 files:\n %s"% ('\n'.join(missing_p12) if missing_p12 else '')))

def notify_for_expiring():
	ks_list = SSLKeystore.objects.filter(expiration_date__lt=datetime.today()+timedelta(days=60),frontends__isnull=False)
	for ks in ks_list:
		ks_cust = Customer.objects.get(pk=ks.customer.id)
		subject = "[CDNetworks] SSL Certificate expiration notification for %s" % ks_cust.name
		body = "This is an email to notify you that your active private SSL certificate for domain %s is expiring on %s. \n"% (ks.domain,ks.expiration_date.date().strftime("%a, %d %b %Y"))
		latest_uploader = SSLKeystore.objects.filter(customer__id=ks.customer.id).latest('create_time')
		recp = [ks.notification_email, NOC_ADDR, ks.create_user.email, latest_uploader.notification_email]
		recp = list(set(recp))
		
		send_email(NO_REPLY, recp, subject, body)
		

choices = {
	'check': test_ks_files,
	'verify': verify_ks_files,
	'notify': notify_for_expiring
}

def main():
	parser = OptionParser()
	parser.add_option('-r','--run',
		dest='run',
		type='string',
		help="specify which function to run")
	(options, args) = parser.parse_args()
	if not options.run:
		print "You must specify which ssl check you want to run with -r or --run."
	elif options.run not in choices:
		print "The '%s' command is not valid." % options.run
	else:
		logging.info("%s started"%(options.run))
		try:
			choices[options.run]()
		except Exception, e:
			logging.info("%s error message: %s"%(options.run, e.message))
		logging.info("%s ended"%(options.run))

if __name__ == '__main__':
	main()
