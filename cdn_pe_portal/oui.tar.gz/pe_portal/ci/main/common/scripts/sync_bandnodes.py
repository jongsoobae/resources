import logging
import logging.handlers
from ci.common.models.cache import Band, BandAggr

log_file = '/var/log/cdn/scripts/sync_bandnodes.log'
log_handler = logging.handlers.RotatingFileHandler(log_file, maxBytes=2**20, backupCount=5)
log_handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s: %(message)s'))
logging.getLogger('').setLevel(logging.INFO)
logging.getLogger('').addHandler(log_handler)

def main():
	bands = Band.objects.all()
	for band in bands:
		if band.band_aggr.ips != band.node_ips.count():
			band.band_aggr.ips = band.node_ips.count()
			band.band_aggr.save()
	exbs = BandAggr.objects.exclude(band__in = bands)
	exbs.delete()

if __name__ == '__main__':
	logging.info("bandnodes sync started")
	try:
		main()
	except Exception, e:
		logging.info("error message: %s"%(e))
	logging.info("bandnodes sync end")

