#!/bin/bash

export DJANGO_SETTINGS_MODULE=ui.oui.settings
export PYTHONPATH=$PYTHONPATH:/opt/cdn/ui/prod

usage() {
	echo "arguments: -r"
}

if [ "-r" == "$1" ]; then
	python /opt/cdn/ui/prod/ci/common/scripts/sync_bandnodes.py
else
	usage
fi


