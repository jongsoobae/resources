#!/usr/bin/python

from ci.common.models import Url, UrlCount, UrlCountCodes
import md5
mash = ''

for url in Url.objects.order_by('hash'):
    mash += '%s %s\n' % (url.hash, url.url)
    for ct in url.urlcount_set.order_by('site_id','stat_time'):
        mash += '  %d %d %s\n' % (ct.hits, ct.completes, ct.stat_time)
        for cd in ct.urlcountcodes_set.order_by('code'):
            mash += '    %d %d\n' % (cd.code, cd.hits)

#hash = md5.md5(mash).hexdigest()
#print hash 
print mash

# java: 	6614f0c0b84a0e1ef41afe03f2ea78be
# django: 	9aff0fd291e8053ae0e4e151a7c0e03d
