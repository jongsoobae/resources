"""
take url count files from the local filesystem and store them in the db.

FYI:
type	bytes	unpack code
---------------------------
short	2		h
int		4		i
long	8		q

see http://docs.python.org/lib/module-struct.html for full documentation 
"""

import logging
import logging.handlers
import MySQLdb
import md5
import os
import time
import gzip
from datetime import datetime
from django.db import transaction, connection
from struct import unpack
from ci.common.models import Url, UrlCount
from ci.common.utils.alert import send_alert
from ci.common.utils.mail import send_email
from ci.constants import NOC, hostname
#import gc; gc.disable()

class UrlCountEntry(object):
	"""a class representing the counts for a single url"""
	def __init__(self, site_id, url, timestamp):
		super(UrlCountEntry, self).__init__()
		self.site_id = site_id
		self.url = url
		self.hits, self.completes, self.incompletes = 0, 0, 0
		self.codes = {}
		self.timestamp = timestamp
	def add_values(self, hits, completes, incompletes):
		self.hits += hits
		self.completes += completes
		self.incompletes += incompletes
	def add_hits(self, code, count):
		if code not in self.codes:
			self.codes[code] = count
		else:
			self.codes[code] += count


class UrlCountRecord(object):
	"""parses UrlCountRecordMessage data from the nodes, aggregates it, and
	stores it in the db."""
	def __init__(self, filename=None):
		self.entries = {} # three-level dict: url, site id, timestamp
		self.entries_list = [] # list for looping through to count stats
		self.files = 0
		if filename:
			self.add(filename)
	
	def __str__(self):
		urls, sites, times = {}, {}, {}
		for entry in self.entries_list:
			if entry.url not in urls:
				urls[entry.url] = 1
			if entry.site_id not in sites:
				sites[entry.site_id] = 1
			if entry.timestamp not in times:
				times[entry.timestamp] = 1
				
		return '%d files, %d urls, %d url counts, %d sites, %d times' % \
			(self.files, len(urls), len(self.entries_list), len(sites), len(times))

 	def trim(self):
 		threshold = 2
 		trimmable = [entry for entry in self.entries_list if entry.hits <= threshold]
 		logging.info('trimming %d urls with <= %d hits each' % (len(trimmable), threshold))
		for entry in trimmable:
			del self.entries[entry.url][entry.site_id][entry.timestamp]
			if len(self.entries[entry.url][entry.site_id]) == 0:
				del self.entries[entry.url][entry.site_id]
			if len(self.entries[entry.url]) == 0:
				del self.entries[entry.url]
		logging.info('done trimming')
	
	@transaction.commit_manually
	def store(self):
		try:
			last_url = None
			count = 0
			real_count = 0
			url_counts, url_reponse_codes=[], []
			for url, site_dict in self.entries.items():
				logging.debug('storing %s' % url)
				logit = (count % 500 == 0)
				if logit:
					start_time = time.time()
					logging.info('At Url %d: storing url %s, total count %d, starting at %f' % (count, url, real_count, time.time()))
				count += 1
				# get a fresh url record if this entry has a different url
				# from the last one; otherwise, reuse the old value of url_obj.
				if url != last_url:
					url_hash = md5.md5(url).hexdigest()
					try:
					 	url_row = Url.objects.get(hash=url_hash)
					except Url.DoesNotExist:
						url_row = Url.objects.create(hash=url_hash, url=url)
					last_url = url
				if logit:
					logging.info('done md5 and getting Url obj after %f' % (time.time() - start_time))
				for site_id, time_dict in site_dict.items():

					for timestamp, entry in time_dict.items():
						real_count += 1
						
						stat_time = datetime.fromtimestamp(timestamp/1000) # convert from java (ms) to unix (s)
						
						url_counts.append("(%d, '%s', '%s', %d, %d)" % (site_id, url_row.id, stat_time, entry.hits, entry.completes))
						if logit:
							logging.info('done storing url count values after %f' % (time.time() - start_time))
					
						for code, hits in entry.codes.items():
							url_reponse_codes.append((site_id, url_row.id, stat_time, code, hits))
						
						if logit:
							logging.info('done updating code count after %f' % (time.time() - start_time))
			cursor = connection.cursor()
			start_time_db = time.time()
			url_counts_stmt = "insert into url_count2 (site_id, url_id, stat_time, hits, completes) values %s on duplicate key update hits=hits+values(hits), completes=completes+values(completes);" % (','.join(url_counts))
			logging.info(" done writing url counts to the db: Did %d rows in %f" % (len(url_counts), time.time()-start_time_db))
			if len(url_counts) > 0 :
				cursor.execute(url_counts_stmt)
			url_counts_stmt, url_counts = None , None
			response_rows = []
			start_time_db = time.time()
			for response_code in url_reponse_codes:
				try:
					response_object = UrlCount.objects.get(site_id=response_code[0], url=response_code[1], stat_time=response_code[2])
				except UrlCount.DoesNotExist:
					if logit:
						logging.error("url count could not be found. Creating with 0 counts")
					response_object=UrlCount.objects.create(url=url_row, site_id=site_id, stat_time=stat_time, hits=0, completes=0)
				response_rows.append("(%d, %d, %d)" % (response_object.id, response_code[3], response_code[4]))
			logging.info(" done looking up url counts for response code rows in %f" %  (time.time()-start_time_db))
			start_time = time.time()
			url_reponses_stmt = "insert into url_count_response_codes2 (url_count_id, code, hits) values %s on duplicate key update hits=hits+(values(hits));" % ",".join(response_rows)
			logging.info(" done writing url response code rows to the db: Did %d rows in %f" % (len(response_rows), time.time()-start_time))
			if len(response_rows) > 0 :
				cursor.execute(url_reponses_stmt)
			url_reponses_stmt, response_rows, url_reponse_codes = None, None, None
			logging.info("Done with all entries, now committing")
			transaction.commit()
			
			logging.info("Done committing")
			return True
		except Exception, e:
			transaction.rollback()
			raise e
	
	def add(self, filename):
		if filename.endswith('.dat'):
			# logging.info("file %s is a normal stream file" % filename)
			file = open(filename)
		elif filename.endswith('.dat.gz'):
			# logging.info("file %s is a gzipped file" % filename)
			file = gzip.open(filename)
		packed_data = file.read()
		sentinel, node_id = unpack('hh', packed_data[:4])
		timestamp, num_sites = unpack('qi', packed_data[4:16])
		
		# sanity checks
		assert sentinel == -1, 'sentinel value is missing'
			
		logging.debug('%s: node %d, time %d, %d sites' % (filename, node_id, timestamp, num_sites))
		
		# set the timestamp to a day boundary
		timestamp = timestamp - (timestamp % 86400000)
		
		new_entries, existing_entries, offset = 0, 0, 16
		
		for site_index in range(num_sites):
			site_id, num_urls = unpack('hh', packed_data[offset:offset+4])
			offset += 4
			
			logging.debug('  site %d' % site_id)
			
			for url_index in range(num_urls):
				url_size = unpack('B', packed_data[offset:offset+1])[0]
				offset += 1
				
				url = unpack('%ds' % url_size, packed_data[offset:offset+url_size])[0]
				offset += url_size
				
				# create the three-level dictionary structure on the fly
				if url not in self.entries:
					self.entries[url] = {}
					
				if site_id not in self.entries[url]:
					self.entries[url][site_id] = {}
				
				# create a new entry or reuse one if it already exists	
				if timestamp not in self.entries[url][site_id]:
					entry = UrlCountEntry(site_id, url, timestamp)
					self.entries[url][site_id][timestamp] = entry
					self.entries_list.append(entry)
					new_entries += 1
				else:
					entry = self.entries[url][site_id][timestamp]
					existing_entries += 1
					
				# for some reason the multi-byte character bug still persists.
				# so we duplicate the workaround for it here.
				hits, completes, incompletes = -1, -1, -1
				while hits != completes + incompletes:
					hits, completes, incompletes = unpack('qqq', packed_data[offset:offset+24])
					if hits != completes + incompletes:
						offset += 1
						logging.debug('    skipping a byte to fix multi-byte char bug')
				offset += 32 # jump 4 longs because there is an unused size counter as well as the above 3
				
				logging.debug('    %s, %d, %d, %d' % ('%s...' % url[:47], hits, completes, incompletes))
				
				entry.add_values(hits, completes, incompletes)
				
			 	num_codes = unpack('h', packed_data[offset:offset+2])[0]
				offset += 2
				
				for code_index in range(num_codes):
					# the two unpack calls need to be separate to circumvent data alignment expectations
					code = unpack('h', packed_data[offset:offset+2])[0]
					code_hits = unpack('q', packed_data[offset+2:offset+10])[0] 
					entry.add_hits(code, code_hits)
					offset += 10
					logging.debug('      code %d hits: %d' % (code, code_hits))
		
		file.close()
		logging.debug('  %d new, %d existing, %d total records' % (new_entries, existing_entries, new_entries + existing_entries))
		self.files += 1	


def main():
	
	ready_dir = '/var/cdn/nodedata/url/02-ready/'
	working_dir = '/var/cdn/nodedata/url/03-working/'
	failed_dir = '/var/cdn/nodedata/url/99-failed/'
	log_file = '/var/log/cdn/url-handler/url_count_handler.log'
	max_files = 1000
	sleep_minutes = 0
	log_handler = logging.handlers.RotatingFileHandler(log_file, maxBytes=2**20, backupCount=5)
	log_handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s: %(message)s'))
	logging.getLogger('').setLevel(logging.INFO)
	logging.getLogger('').addHandler(log_handler)
	
	logging.info("starting")
	if os.listdir(working_dir): #if there are files in the working directory at startup, move them to the failed directory, and do not start
		logging.error("Found files in the working directory!")
		files = sorted([f for f in os.listdir(working_dir)])
		logging.error("Moving working files to the failed directory")
		for f in files:
			os.rename(os.path.join(working_dir, f), os.path.join(failed_dir, f))
		logging.error("Stopping script. Please check the status of the files in failed_dir before trying to start this again.")
	else:
		try:
			while True:
				files = sorted([f for f in os.listdir(ready_dir) if f.endswith('.dat') or f.endswith('.dat.gz')])[:max_files]
				if len(files) < max_files / 5:
					logging.info("Only %d files are present, waiting for 5 minutes before checking again." % len(files))
					time.sleep(300)
					continue
				else:
					logging.info("Moving %d files to the working directory" % len(files))
					for f in files:
						os.rename(os.path.join(ready_dir, f), os.path.join(working_dir, f))

				logging.info("processing %d files" % len(files))
				u = UrlCountRecord()
				for f in files:
					u.add(os.path.join(working_dir, f))
				logging.info("read %s" % str(u))
				u.trim()

	#			logging.info("GC start")
	#			gc.collect()
	#			logging.info("GC end")
			
				# attempt to store; if it's successful, archive the files
				done = False
				start_time = time.time()
				error_count = 0
				while not done:
					logging.info("Storing in DB...")
					try:
						done = u.store()
					except MySQLdb.OperationalError, e:
						error_count += 1
						if error_count < 20:
							logging.error(str(e))
							logging.error("The current db error count is %d. Sleeping for 180 seconds before trying again." % error_count)
						else:
							raise
					if not done:
						time.sleep(180)

				elapsed = (time.time() - start_time) / 60.
				if files:
					logging.info("stored %d files in %.1f min (%.1f files/min)" % (len(files), elapsed, len(files)/elapsed))
				else:
					time.sleep(180)

				logging.info("Archiving files...")
				#if the needed structure for archiving the files does not exist, create it
				done_dir = '/var/cdn/nodedata/url/04-archived/%d/%02d/%02d/%02d/' % (datetime.now().year, datetime.now().month, datetime.now().day, datetime.now().hour)
				try:
					os.stat(done_dir)
				except:
					os.makedirs(done_dir)
				for f in files:
					os.rename(os.path.join(working_dir, f), os.path.join(done_dir, f))
				logging.info("Done archiving files")

				if sleep_minutes:
					logging.debug('sleeping for %d minutes' % sleep_minutes)
					time.sleep(sleep_minutes * 60)

				#break 
		except KeyboardInterrupt:
			logging.info('received keyboard interrupt')
		except Exception, e:
			import traceback
			logging.error(str(e))
			send_alert(code="App :: OUI", subject="[%s]Top URL exception" % hostname, body="Top URL handler hit the following exception \n\n"+str(e), urgent=True)
			send_email(NOC, NOC, "[%s]Top URL exception" % hostname, "Top URL handler hit the following exception \n\n"+str(e))
			logging.error("Sent an alert to oncall roster", )
	logging.info('stopping')

if __name__ == '__main__':
	#logging.info("Profiling")
	#profile.run('main()','/home/cdn/nodedata/prof2.log')
	main()

