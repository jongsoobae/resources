from django import template
from django.forms.fields import *

register = template.Library()

formToRestType = {
	CharField: 'String',
	BooleanField: 'Boolean',
	IntegerField: 'Integer',
	TypedChoiceField: 'ValueList',
	
}

@register.filter(name="isValueList")
def isValueList(field):
	return isinstance(field,TypedChoiceField)

@register.filter(name="restType")
def restType(field):
	if type(field) in formToRestType:
		return formToRestType[type(field)]
	return 'String'
