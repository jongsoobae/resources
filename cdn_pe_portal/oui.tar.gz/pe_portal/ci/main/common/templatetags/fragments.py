from django import template
from django.core.urlresolvers import reverse

register = template.Library()

link_menus = {
	'solutions': {
		'left_menu_header': 'Learn about our solutions for:',
		'right_links_header': 'Related Solutions',
		'root_view': 'solutions',
		'items': [
			('adserving', 'Adserving', None),
			('ecommerce', 'E-commerce', None),
			('gaming', 'Gaming', None),
			('hosting', 'Managed hosting', None),
			('multimedia', 'Multimedia', None),
			('news', 'News/blogs', None),
			('software', 'Software downloads', None),
			('web20', 'Web 2.0 applications', None),
			('video', 'Video', None),
		],
	},
	'technology': {
		'left_menu_header': 'Learn about our features:',
		'right_links_header': 'Related Features',
		'root_view': 'technology',
		'items': [
			('pdseek', 'PDSeek', 'skip ahead on progressive download files'),
			('h264', 'H.264', 'support for the H.264 codec'),
			('throttling', 'Bandwidth throttling', 'manage your bandwidth costs'),
			('shielding', 'Shielding', 'protect your origin from being overloaded'),
			('referrer-checking', 'Referrer checking', 'secure your valuable content'),
			('url-auth', 'URL authentication', 'prevent access by unauthorized users'),
			('cache-flushing', 'Rapid cache flushing', 'fastest and easiest content updates'),
		]
	},
	'about': {
		'root_view': 'home',
		'items': [
			('leadership', 'Leadership', None),
			('news', 'Newsroom', None),
			('events', 'Events', None),
			('advantage', 'Panther Advantage', None),
			('partners', 'Partners', None)
		]
	}
}

@register.inclusion_tag('fragment/readmore.html')
def readmore(view, view_arg=None):			
	return {'link': reverse(view, args=[view_arg]) if view_arg else reverse(view)}

@register.inclusion_tag('fragment/left-menu.html')
def left_menu(request, category):
	context = dict(link_menus[category])
	context['request'] = request
	context['url_base'] = reverse(context['root_view'])
	return context
	
@register.inclusion_tag('fragment/right-links.html')
def right_links(root_view, choices_string):
	choices = choices_string.split(',')
	context = dict(link_menus[root_view])
	context['items'] = [item for item in context['items'] if item[0] in choices]
	context['url_base'] = reverse(context['root_view'])
	return context
	
@register.inclusion_tag('fragment/form_field_tr.html')
def form_field_tr(field, tr_id=None):
	return {'field': field, 'id': tr_id}
	
@register.inclusion_tag('fragment/form_submit_tr.html')
def form_submit_tr(value="Submit"):
	return {'value': value}
	
@register.inclusion_tag('fragment/form_errors_tr.html')
def form_errors_tr(form):
	return {'form': form}

