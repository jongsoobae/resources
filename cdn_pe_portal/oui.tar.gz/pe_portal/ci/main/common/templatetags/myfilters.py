from django import template
from datetime import datetime, timedelta
import locale
import re
import types
from decimal import Decimal, ROUND_HALF_UP, ROUND_DOWN
from django.utils.encoding import smart_unicode
from django.core import urlresolvers
from ci.common.utils.chart import embed_chart as embed_chart_util
from ci.common.models.pusher import FLUSH_TYPES

register = template.Library()


@register.filter(name='flt_sort_nodes')
def flt_sort_nodes(obj_list):
     """sort a list of objects by some attribute of the object"""
     try:
          from ci.common.models.cdn import node_name_cmp
          obj_list = list(obj_list)
          obj_list.sort(cmp=node_name_cmp)
          return obj_list
     except:
          return obj_list

@register.filter(name='pop_utilize')
def pop_utilize(val,divider):
	ret = "good"
	per = float(val)/float(divider)
	if per>=0.8 and per <= 1:
		return "warn"
	elif per > 1:
		return "bad"
	return ret

@register.filter(name='flush_type')
def flush_type(val):
	return FLUSH_TYPES.get(int(val),'bad/unknown type')		

@register.filter(name='to_str')
def to_str(val):
	ret = ''
	try:
		ret = str(val)
	except:
		pass
	return ret

@register.filter(name='sort')
def listsort(value,key,upper=''):
	if upper == 'upper':
		value.sort(lambda a,b: cmp(a[1][key].upper(), b[1][key].upper())) 
	else:
		value.sort(lambda a,b: cmp(a[1][key], b[1][key]))
	return value 

@register.filter(name='plusminus')
def plusminus(val):
	if val >= 0:
		return '+%d' % val
	else:
		return str(val)

@register.filter(name='secs_to_days')
def seconds_to_days(val):
	try:
		return "%.1f" %(float(val)/86400)
	except ValueError:
		return "0.0"

@register.filter(name="clean_country")
def clean_country(country):
	"""strip anything in parentheses from the country name"""
	return re.sub(r'(\(.*\))','', country)

@register.filter(name="shortname")
def shortname(user):
	return '%s%s' % (user.first_name[:2], user.last_name[:2])

@register.filter(name="sum")
def sum_(val, func):
	"return the sum of the method run on each model instance in the query set being filtered"
	return sum([getattr(el, func)() for el in val])

@register.filter(name="modulo")
def modulo_filter(val, denominator):
	"""
	Return val % denominator.
	
	Useful in for loops to do something (a new header line, start a new column)
	every "denominator" iterations:
	{% for i in things %}
		{% if not forloop.counter0|modulo:8 %}
			{{ thing_i_want_to_show_every_8_iterations }}
		{% endif %}
		{{ thing_i_want_to_show_every_iteration }}
	{% endfor %}
	"""
	return val % denominator

@register.filter(name="csvclean")
def csvclean(val):
	return str(val).replace(",","").replace('"','')

@register.filter(name='abso')
def abso(val):
	try:
		return abs(val)
	except:
		return 0

@register.filter(name='lt')
def lt(val, cmp):
	if type(val) in (
		types.SliceType, types.ListType, types.TupleType, types.BufferType,
		types.GeneratorType, types.DictType
	):
		return len(val) < cmp
	else:
		return val < cmp
	
@register.filter(name='gt')
def gt(val, cmp):
	"""
	Return True if val is a sequence and its length is greater than cmp, or if
	val is a scalar value greater than cmp, otherwise False.
	"""
	if type(val) in (
		types.SliceType, types.ListType, types.TupleType, types.BufferType,
		types.GeneratorType, types.DictType
	):
		return len(val) > cmp
	else:
		return val > cmp

def getattr_chain(obj, attr_chain):
	if len(attr_chain) == 1:
		val = getattr(obj, attr_chain[0])
		return val() if callable(val) else val
	else:
		return getattr_chain(getattr(obj, attr_chain[0]), attr_chain[1:])

@register.filter(name='attrsort')
def attrsort(obj_list, attr_name):
	"""sort a list of objects by some attribute of the object"""
	try:
		return sorted(obj_list, key=lambda o: getattr_chain(o, attr_name.split('.')))
	except:
		return obj_list

def trim_decimals(val, size):
	"""
	Format val as a decimal number with a decimal point followed by as many digits as the integer value size
	@param val:  A number
	@param size: An int
	@return:     A string representing the number
	"""
	try:
		rounded_val = (10**size * Decimal(str(val))).to_integral(ROUND_HALF_UP) / (10**size)
		lpart = rounded_val.to_integral(ROUND_DOWN)
		rpart = (10**size * (rounded_val - lpart)).to_integral()
		return '%s.%0*d' % (lpart, size, abs(int(rpart)))
	except:
		return val

@register.filter(name='money_3place')
def money_3place(val, is_international):
	"""
	format number with commas and three numbers after decimal point. Made especially for rates with three decimal places
	"""
	try:
		sep = '.' if is_international else ','
		fnum = trim_decimals(val, 3)
		# "international" numbers use comma as the decimal point
		if is_international: fnum = fnum.replace('.', ',')
		fnum_pieces = re.match(r'(\s*)(-?)(\d+)(\.\d*)?(.*$)', fnum)
		with_commas = re.sub(r"(\d{3})", r"\1" + sep, str(fnum_pieces.group(3))[::-1])[::-1].lstrip(sep)
		spaces = ' ' * max(0, len(fnum_pieces.group(1)) - (len(with_commas) - len(fnum_pieces.group(3))))
		return ''.join([spaces, fnum_pieces.group(2), with_commas, ('%.3f' % float(fnum_pieces.group(4))).lstrip('0') if fnum_pieces.group(4) else '', fnum_pieces.group(5)])
	except TypeError, e:
		# import traceback
		# raise TypeError, 'inputs were [%s] and [%s]' % (val, fmt)
		return val
	except AttributeError, e:
		return val

@register.filter(name='money')
def money(val, is_international=False):
	"""
	format number with commas and two numbers after decimal point
	"""
	try:
		sep = '.' if is_international else ','
		fnum = trim_decimals(val, 2)
		# "international" numbers use comma as the decimal point
		if is_international: fnum = fnum.replace('.', ',')
		fnum_pieces = re.match(r'(\s*)(\-?)(\d+)(\.\d*)?(.*$)', fnum)
		with_commas = re.sub(r"(\d{3})", r"\1" + sep, str(fnum_pieces.group(3))[::-1])[::-1].lstrip(sep)
		spaces = ' ' * max(0, len(fnum_pieces.group(1)) - (len(with_commas) - len(fnum_pieces.group(3))))
		return ''.join([spaces, fnum_pieces.group(2), with_commas, ('%.2f' % float(fnum_pieces.group(4))).lstrip('0') if fnum_pieces.group(4) else '', fnum_pieces.group(5)])
	except TypeError, e:
		# import traceback
		# raise TypeError, 'inputs were [%s] and [%s]' % (val, fmt)
		return val
	except AttributeError, e:
		return val

@register.filter(name='commafy')
def commafy(val, fmt):
	"""stringformat for numbers, but with commas"""
	try:
		sep = ','
		fnum = (r'%' + fmt) % val
		fnum_pieces = re.match(r'(\s*)(-?)(\d+)(.*$)', fnum)
		with_commas = re.sub(r"(\d{3})", r"\1" + sep, str(fnum_pieces.group(3))[::-1])[::-1].lstrip(sep)
		spaces = ' ' * max(0, len(fnum_pieces.group(1)) - (len(with_commas) - len(fnum_pieces.group(3))))
		return ''.join([spaces, fnum_pieces.group(2), with_commas, fnum_pieces.group(4)])
	except TypeError, e:
		# import traceback
		# raise TypeError, 'inputs were [%s] and [%s]' % (val, fmt)
		return val
	except AttributeError, e:
		return val

@register.filter(name="truncchars")
def truncchars(st, size):
	st = smart_unicode(st)
	"""limit a string to a certain length and add '...' if it is truncated"""
	if st and len(st) > size:
		return st[:size-3] + '...'
	return st

@register.filter(name="addhours")
def addhours(date, hrs):
	if type(date) != datetime:
		return date
	return date + timedelta(hours=hrs)

@register.filter(name="smartdate")
def smartdate(date):
	"""human-readable date"""
	if type(date) != datetime:
		return date
	delta = datetime.now() - date
	totalseconds = delta.days * 86400 + delta.seconds
	if totalseconds < 60:
		return "%d second%s ago" % (totalseconds, ('','s')[totalseconds>1])
	elif totalseconds < 3600:
		return "%d minute%s ago" % (totalseconds/60, ('','s')[totalseconds>=120])
	elif totalseconds < 86400:
		hours = totalseconds / 3600
		minutes = (totalseconds - (hours * 3600)) / 60
		return "%d hour%s, %d minute%s ago" % (hours, ('','s')[hours>1], minutes, ('','s')[minutes>1])
	elif totalseconds < 7 * 86400:
		days = totalseconds / 86400
		hours = (totalseconds - (days * 86400)) / 3600
		if hours == 0:
			return "%d day%s ago" % (days, ('','s')[days>1])
		else:
			return "%d day%s, %d hour%s ago" % (days, ('','s')[days>1], hours, ('','s')[hours>1])
	elif totalseconds < 8 * 7 * 86400:
		weeks = totalseconds / (86400 * 7)
		days = (totalseconds - (weeks * 7 * 86400)) / 86400
		return '%d week%s%s ago' % (weeks, ('','s')[weeks>1], (', %d day%s' % (days, ('','s')[days>1]) if days else ''))
	elif totalseconds < 6 * 30 * 86400:
		months = totalseconds / (86400 * 30)
		weeks = (totalseconds - (months * 30 * 86400)) / (86400 * 7)
		return '%d month%s%s ago' % (months, ('','s')[months>1], (', %d week%s' % (weeks, ('','s')[weeks>1]) if weeks else ''))
	else:
		return date.strftime('%Y-%m-%d %H:%M:%S')

@register.filter(name="shortsmartdate")
def shortsmartdate(date):
	"""human-readable date. In short format."""
	if type(date) != datetime:
		return date
	delta = datetime.now() - date
	totalseconds = delta.days * 86400 + delta.seconds
	if totalseconds < 60:
		return "%ds ago" % totalseconds
	elif totalseconds < 3600:
		return "%dm ago" % (totalseconds / 60)
	elif totalseconds < 86400:
		hours = totalseconds / 3600
		minutes = (totalseconds - (hours * 3600)) / 60
		return "%dh, %dm ago" % (hours, minutes)
	elif totalseconds < 7 * 86400:
		days = totalseconds / 86400
		hours = (totalseconds - (days * 86400)) / 3600
		if hours == 0:
			return "%dd ago" % (days)
		else:
			return "%dd, %dh ago" % (days, hours)
	elif totalseconds < 8 * 7 * 86400:
		weeks = totalseconds / (86400 * 7)
		days = (totalseconds - (weeks * 7 * 86400)) / 86400
		return '%dw %s ago' % (weeks,(', %dd' % days )if days else '')
	elif totalseconds < 6 * 30 * 86400:
		months = totalseconds / (86400 * 30)
		weeks = (totalseconds - (months * 30 * 86400)) / (86400 * 7)
		return '%dm %s ago' % (months, (', %dw' % weeks) if weeks else '')
	else:
		return date.strftime('%Y-%m-%d %H:%M:%S')


@register.filter(name='in_sequence')
def in_sequence(member, seq):
	"""True if member is in seq"""
	return member in seq

@register.simple_tag
def under_construction():
	return """<p>This page is under construction. 
	Feel free to <a href="mailto:webmaster@pantherexpress.net">email the webmasters</a> 
	if there's something you'd like to see sooner than later.</p>"""

@register.filter(name='space_linebreak')
def space_linebreak(value):
	"""Break a string down based on spaces and replace that space with newline characters"""
	value = value.replace (' ', '\n')
	return value

@register.filter(name='html_list')
def make_html_list(value):
	"""Break a string down based on newline characters and for each line, enclose it in the <li> and </li> without the <ul> and </ul> tags. Similar to the unordered_list filter but not requiring a list"""
	value = re.sub(r'\r\n|\r|\n', '\n', value) # normalize newlines
	paras = re.split('\n', value)
	paras = ['<li>%s</li>' % p.strip().replace('\n', '<br/>') for p in paras]
	return '\n\n'.join(paras)

@register.filter(name="to_dict")
def convert_to_dict(value):
	try:
		return dict(value)
	except:
		return {}

@register.filter(name="get_item")
def get_item(dictionary, value):
	return get_dict_item(value, dictionary)
	
@register.filter(name="get_dict_item")
def get_dict_item (value, dictionary):
	try:
		return dictionary[value]
	except:
		return None
	
@register.filter(name="split")
def split(value, character):
        if isinstance(value, str) or isinstance(value, unicode):
                return value.strip().split(character)
        else:
                return []

@register.filter(name="contains")
def contains(value, substring):
	if isinstance(value, str) or isinstance(value, unicode):
		return value.find(substring) >= 0
	return False

@register.filter(name="concat")
def concat(value, value2):
	try:
		return str(value) + str(value2)
	except:
		return None

@register.filter(name="make_list")
def make_list(value):
	try:
		return range(value)
	except:
		return None
		
@register.filter(name="new_page_attr")
def new_page_attr(value):
	"""finds all URL's in a given text and adds the attribute target='_blank' so that all links would open in a new page/tab. Must be used after urlize or have hardcoded html links in the text already for the matching pattern to work"""
	def add_attr(matchObj):
	 	return matchObj.group(0)+' target="_blank" '
	return re.sub(r'<a ', add_attr, value)	
new_page_attr.is_safe=True

@register.filter(name="multiple_by")
def multiply_by(val1,val2):
	try:
		return val1 * val2
	except:
		return 0

@register.simple_tag
def embed_chart(params):
	return embed_chart_util(params)

@register.filter(name="islist")	
def is_list(value):
	if isinstance(value, list):
		return True
	else:
		return False
		
if __name__ == '__main__':
	from decimal import Decimal
	print money(Decimal("0.0967013600"), True)
