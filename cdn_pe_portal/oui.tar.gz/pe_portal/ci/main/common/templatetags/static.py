from django import template
from ci.constants import ENVIRONMENT, UI_HOST
import os

register = template.Library()

@register.simple_tag
def static_url(path, ocsp=False, prism=False):
	"""this tag is for making links to static content point to the CDN, but only in a
	production environment. The criteria are that ENVIRONMENT is set to 'prod' and
	the DJANGO_BASE_DIR environment variable has not been set. (The latter variable
	is set when running as an alternate, staging-like instance in production.)
	"""
	if ocsp and path.startswith("/static/pdf/"):
		#this is hacky but quick and eventually portal will go away...
		path = "/static/pdf/ocsp/" + path[12:] 

	if UI_HOST>'':
		return UI_HOST + path
	else:
		return path if not prism else "/oui" + path

@register.simple_tag
def ssl_url(path, ocsp=False, prism=False):
	"""this tag is for making links to static content point to the CDN, but only in a
	production environment. The criteria are that ENVIRONMENT is set to 'prod' and
	the DJANGO_BASE_DIR environment variable has not been set. (The latter variable
	is set when running as an alternate, staging-like instance in production.)
	"""
	if ocsp and path.startswith("/static/pdf/"):
		#this is hacky but quick and eventually portal will go away...
		path = "/static/pdf/ocsp/" + path[12:] 

	if ENVIRONMENT == 'prod' and 'DJANGO_BASE_DIR' not in os.environ:
		return 'https://oui.pantherssl.com' + path
	else:
		return path if not prism else  "/oui" + path
