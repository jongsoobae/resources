from django import template

register = template.Library()

@register.filter(name="lcut")
def lcut(val, val2):
	try:
		if val.startswith(val2):
			return val[len(val2):]
		else:
			return val
	except:
		return val

@register.filter(name="c")
def concat(val, val2):
	return '%s%s' % (val, val2)
	
@register.filter(name="wrap")
def wrap(val, size):
	try:
		if len(val) < size:
			return val
		return '<br/>'.join([val[i:i+size] for i in range(0, len(val), size)])
	except:
		return val

@register.filter(name='startswith')
def startswith(val, prefix):
	return unicode(val).startswith(prefix)

@register.filter(name="isstring")
def is_string(val):
	return type(val) in [str, unicode]
