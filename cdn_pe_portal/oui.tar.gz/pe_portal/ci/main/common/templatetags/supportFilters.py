from django import template
from django.utils import simplejson
from ci.common.models.cdn import Pop, Node
import re
import commands

register = template.Library()

@register.filter(name="percentOf")
def percentOf(dividend, divisor):
	try:
        	if divisor == 0:
                	return 0
        	return round(float(dividend) / float(divisor) * 100,1)
	except TypeError:
		return 0
	except ValueError:
		return 0

@register.filter(name="gt")
def gt(val, cmp):
	return val > cmp

@register.filter(name="boldFailures")
def boldFailures(string, failures):
	try:
		for failure in failures.split("\n"):
			pos = string.lower().find(failure.strip().lower())
			if pos >= 0:
				posE = string.find("\n",pos)
				if posE >= 0:
					string = string[:pos] + "<b>" + string[pos:posE] + \
						"</b>" + string[posE:]
				else:
					#end...
					 string = string[:pos] + "<b>" + string[pos:]
		return string
	except Exception: 
		return string

@register.filter(name="expandTxtRecord")
def expandTxtRecord(txt_record):
        #if parsing fails will just return txt_record as submitted
        try:
                search_result = re.search('(U2FsdGVkX1[^\s"]*)', txt_record)
                if search_result:
                        # Found a GSLB debug TXT record from the input
                        encrypted_txt = search_result.group(1)
                        # Following shell command will print out the decoded debug message.
                        decoded_txt = commands.getoutput('echo '+encrypted_txt+' | openssl enc -d -a -A -aes-128-cbc -k cdngpgslb')
                        items = decoded_txt.strip().split(' ')
                        txt_show = "GSLB VIP: " + items[0].split('g=')[1] + "\n"\
                                        + "Query Dst IP: " + items[1].split('d=')[1]  + "\n"\
                                        + "Query Src IP: " + items[2].split('s=')[1] + "\n"\
                                        + "Resolution Flow: " + items[3] + "\n"\
                                        + "Answer Count: " + items[4] + "\n"
                        idx = 0
                        for obj in items:
                                if idx >= 5:
                                        each_item = obj.split(',')
                                        txt_show = txt_show + each_item[0] + " : " + each_item[1]\
                                                                        + ", Score: " + each_item[2]\
                                                                        + ", Distance: " + each_item[3]\
                                                                        + ", Pop: " + each_item[4]\
                                                                        + ", Probe: " + each_item[5] + "\n"

                                idx = idx+1

                else:
                        txt_json = simplejson.loads(txt_record[txt_record.find("{"): \
                                txt_record.rfind("}")+1].replace("\n","").replace("\r","").replace("\\\"","\""))
                        txt_show = "DNS Node: " + str(txt_json['dNd']) + " (" \
                                + Node.objects.get(id = txt_json['dNd']).name() + ")\n" \
                                + "Resolver DNS IP: " + txt_json['dRIp'] + "\n"
                        if txt_json.has_key('sel'):
                                txt_show += "Selected Node: " + str(txt_json['sel']['nd']['id']) + " (" \
                                + Node.objects.get(id = txt_json['sel']['nd']['id']).name() + ")" \
                                + ", Load: " + str(txt_json['sel']['nd']['ld']) + "\n" \
                                + "Selected Pop: " + str(txt_json['sel']['pop']['id']) + " (" \
                                + Pop.objects.get(id = txt_json['sel']['pop']['id']).short_name + ")" \
                                + ", Score: " + str(txt_json['sel']['pop']['sc']) \
                                + ", Load: " + str(txt_json['sel']['pop']['ld']) \
                                + ", Raw Latency: " + str(txt_json['sel']['pop']['rL']) \
                                + ", Voted Latency: " + str(txt_json['sel']['pop']['vL']) \
                                + ", Cost: " + str(txt_json['sel']['pop']['cst']) + "\n"
                        if txt_json.has_key('cls'):
                                txt_show += "Closest Node: " + str(txt_json['cls']['nd']['id']) + " (" \
                                + Node.objects.get(id = txt_json['cls']['nd']['id']).name() + ")" \
                                + ", Load: " + str(txt_json['cls']['nd']['ld']) + "\n" \
                                + "Closest Pop: " + str(txt_json['cls']['pop']['id'])  + " (" \
                                + Pop.objects.get(id = txt_json['cls']['pop']['id']).short_name + ")" \
                                + ", Score: " + str(txt_json['cls']['pop']['sc']) \
                                + ", Load: " + str(txt_json['cls']['pop']['ld']) \
                                + ", Raw Latency: " + str(txt_json['cls']['pop']['rL']) \
                                + ", Voted Latency: " + str(txt_json['cls']['pop']['vL']) \
                                + ", Cost: " + str(txt_json['cls']['pop']['cst']) + "\n" \
                                + "Tied Closest PoPs: " + str(txt_json['cls']['pop']['ties'])
        except Exception, e:
                return txt_record
        return txt_show

@register.filter(name="is_list")
def is_list(obj):
	return isinstance(obj,list)

