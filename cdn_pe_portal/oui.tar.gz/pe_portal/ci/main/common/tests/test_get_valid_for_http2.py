import sys
import os
sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'ui.oui.settings'

import unittest
from ci.common.forms.admin import ServiceAdminForm


class Http2Test(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_get_valid_server_protocol_for_http2(self):

        test_set = (
            {'value': '', 'expect': ''},
            {'value': 'A,B,C,TLSv1.2', 'expect': 'TLSv1.2,A,B,C'},
            {'value': 'A,TLSv1.2,B,C', 'expect': 'TLSv1.2,A,B,C'},
            {'value': 'A,TLSv1.2,B,C,TLSv1.2,D', 'expect': 'TLSv1.2,A,B,C,D'},
            {'value': 'A,TLSv1.2,B,C,TLSv1.2,A', 'expect': 'TLSv1.2,A,B,C,A'},

            {'value': 'A, B, C, TLSv1.2', 'expect': 'TLSv1.2,A,B,C'},
            {'value': '  A , TLSv1.2 , B, C', 'expect': 'TLSv1.2,A,B,C'},
            {'value': 'A, TLSv1.2,B, C, TLSv1.2,D  ', 'expect': 'TLSv1.2,A,B,C,D'},
            {'value': '   A,TLSv1.2, B, C,TLSv1.2,A   ', 'expect': 'TLSv1.2,A,B,C,A'}
        )

        for ts in test_set:
            self.assertEqual(ServiceAdminForm.get_valid_server_protocol_for_http2(ts['value']), ts['expect'])

    def test_get_valid_server_cipher_for_http2(self):

        test_set = (
            {'value': '', 'expect': ''},

            {'value': 'A,B,C,TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256',
             'expect': 'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,A,B,C'},

            {'value': 'A,B,C,TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384',
             'expect': 'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,A,B,C'},

            {'value': 'A,B,C,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256',
             'expect': 'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,A,B,C'},

            {'value': 'A,B,C,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384',
             'expect': 'TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,A,B,C'},

            {'value': 'A,B,C,TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,D,E,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384',
             'expect': 'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,A,B,C,D,E'},

            {'value': 'A,B,C,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,D,E,TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256',
             'expect': 'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,A,B,C,D,E'},


            {'value': 'A, B, C, TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256',
             'expect': 'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,A,B,C'},

            {'value': 'A,B, C,TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384   ',
             'expect': 'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,A,B,C'},

            {'value': 'A,B,C,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384 ,TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 ',
             'expect': 'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,A,B,C'},

            {'value': '  A,B, C,  TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384',
             'expect': 'TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,A,B,C'},

            {'value': '  A,B,C,TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,D , E, TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384',
             'expect': 'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,A,B,C,D,E'},

            {'value': ' A ,B, C,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,D,E,TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 ',
             'expect': 'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,A,B,C,D,E'},
        )

        for ts in test_set:
            self.assertEqual(ServiceAdminForm.get_valid_server_cipher_for_http2(ts['value']), ts['expect'])

    def test_get_invalid_server_protocol_for_http2(self):
        ERROR_MESSAGE = 'Deployments of HTTP/2 that use TLS 1.2 MUST support TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 at the default priority (or higher)'
        test_set = (
            'TLSv1',
        )

        for ts in test_set:
            try:
                ServiceAdminForm.get_valid_server_protocol_for_http2(ts)
            except Exception, e:
                self.assertEqual(e.messages[0], ERROR_MESSAGE)
            else:
                self.assertTrue(False)


if __name__ == '__main__':
    unittest.main()
