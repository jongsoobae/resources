from ci.common.utils.JiraSoapServiceService_services import *
from ci.common.utils.JiraSoapServiceService_services_types import *
from ci.common.utils.timeouthttp import *
from urlparse import urlparse
from ci.common.utils.alert import send_alert

import sys
import getopt

from ci.common.utils.mail import send_email

from ci.constants import JIRA_DEFAULT_ISSUE_TYPE as DEFAULT_ISSUE_TYPE
from ci.constants import JIRA_DEFAULT_ISSUE_ID as DEFAULT_ISSUE_ID
from ci.constants import JIRA_SERVER_URL as SERVER_URL
from ci.constants import JIRA_SOAP_URL as SOAP_URL
from ci.constants import JIRA_BROWSE_URL as BROWSE_URL
from ci.constants import JIRA_USER as USER
from ci.constants import JIRA_PASSWORD as PASSWORD
from ci.constants import JIRA_TIMEOUT as TIMEOUT
from ci.constants import JIRA_DEFAULT_ASSIGNEE as DEFAULT_ASSIGNEE
from ci.constants import JIRA_SUPPORT_PROJECT as SUPPORT_PROJECT
from ci.constants import JIRA_SUPPORT_ID as SUPPORT_ID
from ci.constants import JIRA_SE_PROJECT as SE_PROJECT
from ci.constants import JIRA_MAINTAINER

# TODO: implement exception handling

def make_jira_issue(subject, body, issueTypeId, issueString, urgent=False, user=None):
	project = SE_PROJECT if issueString.startswith('Pad imp') else SUPPORT_PROJECT

	# try to talk to jira
	issuekey = None
	try:
		jira = JiraClient()
		issuekey = jira.CreateIssue(project, issueTypeId, subject, body)

	except Exception, e:
		send_email(JIRA_MAINTAINER,     [JIRA_MAINTAINER], 'jira error', 'error creating jira issue "%s":\n%s\n\noriginal message:\n%s\n' % (subject, e, body))
		pass
	
	# if we were able to create an issue, link to it from the message body
	if issuekey:
		body = 'JIRA issue: %s%s\n%s' % (BROWSE_URL, issuekey, body)

	# create the actual alert, whether issue creation was successful or not
	alert = send_alert('App :: CUI', subject, body, urgent=True if urgent else False, user=user)

	# update the alert record with the issue key if one exists
	if issuekey:
		alert.jira_info = issuekey
		alert.save()

	return issuekey

class JiraClient:
	"""Main client interface for JIRA administrative calls"""
	
	def __init__(self, url=SOAP_URL, jiraUser=USER, jiraPassword=PASSWORD, timeout=TIMEOUT):
		""" Force init with a URL and user/password pair for the remote JIRA support admin """
		kw = {}

		purl = urlparse(url)

		if purl.scheme == "https":
			self.transport = TimeoutHTTPSConnection
		elif purl.scheme == "http":
			self.transport = TimeoutHTTPConnection
		else:
			raise "server uri scheme should be (http or https) scheme (%s) is not supported" % (type)

		self.url = url
		self.jUsername = jiraUser
		self.jPassword = jiraPassword
		self.transport.timeout = timeout
		self.connection = jirasoapservice_v2SoapBindingSOAP(self.url, self.transport, **kw)
		self.authToken = None
		
	def __login(self):
		creds = loginRequest()
		creds._in0 = self.jUsername 
		creds._in1 = self.jPassword
		loginResponse = self.connection.login(creds)
		self.authToken = loginResponse._loginReturn
	
	def __logout(self):
		goodbye = logoutRequest()
		goodbye._in0 = self.authToken
		logoutResponse = self.connection.logout(goodbye)

	def GetSupportIssueTypes(self):
		self.__login()
		issueTypeRequest = getIssueTypesForProjectRequest()
		issueTypeRequest._in0 = self.authToken
		issueTypeRequest._in1 = SUPPORT_ID
		issueTypeResponse = self.connection.getIssueTypesForProject(issueTypeRequest)
		self.__logout()
		issueTypes = issueTypeResponse._getIssueTypesForProjectReturn
		issueDict = {}
		for itype in issueTypes:
			issueDict[itype._id] = itype._name
		return issueDict
	
	def CreateUser(self, username, fullname, password, email):	
		self.__login()
		newUser = createUserRequest()
		newUser._in0 = self.authToken
		newUser._in1 = username
		newUser._in2 = password
		newUser._in3 = fullname
		newUser._in4 = email
		createUserResponse = self.connection.createUser(newUser)
		self.__logout()
		createdUser = createUserResponse._createUserReturn
		if createdUser.username == username:
			return True
		else:
			return False
		# some due dilligence here to check that it worked?
		
	def CreateGroup(self, groupname, firstusername):	
		self.__login()
		newGroup = createGroupRequest()
		newGroup._in0 = self.authToken
		newGroup._in1 = groupname
		newGroup._in2 = firstusername
		createGroupResponse = self.connection.createGroup(newGroup)
		self.__logout()
		createdGroup = createGroupResponse._createGroupReturn
		if createdGroup.groupname == groupname:
			return True
		else:
			return False
		# some due dilligence here to check that it worked?
		
	def AddUserToGroup(self, groupname, username):
		self.__login()
		groupAdd = addUserToGroupRequest()
		groupAdd._in0 = self.authToken
		groupAdd._in1 = groupname
		groupAdd._in2 = username
		addedUserResponse = self.connection.addUserToGroup(groupAdd)
		self.__logout()
		# this returns void, so nothing really to be done except return true or null

	def AddCommentToTicket(self, issueKey, comment):
		self.__login()
		commentField = ns0.RemoteComment_Def("comment")
		commentField._body = comment
		commentAdd = addCommentRequest()
		commentAdd._in0 = self.authToken
		commentAdd._in1 = issueKey
		commentAdd._in2 = commentField
		addedCommentResponse = self.connection.addComment(commentAdd)
		self.__logout()
		# this returns void, so nothing really to be done except return true or null

	def CreateIssue(self, project, issueType, summary, description, assignee=DEFAULT_ASSIGNEE):
		self.__login()
		newIssueDef = ns0.RemoteIssue_Def(project)
		newIssueDef._project = project
		newIssueDef._type = issueType
		if assignee == None:
			newIssueDef._assignee = 'support'
		else:
			newIssueDef._assignee = assignee
		newIssueDef._summary = summary
		newIssueDef._description = description
		newIssueRequest = createIssueRequest()
		newIssueRequest._in0 = self.authToken
		newIssueRequest._in1 = newIssueDef
		createIssueResponse = self.connection.createIssue(newIssueRequest)
		self.__logout()
		createdIssueDef = createIssueResponse._createIssueReturn
		if createdIssueDef._assignee == newIssueDef._assignee:
			return createdIssueDef._key
		else:
			return None

	def ReassignIssue(self, issuekey, newUser):
		self.__login()
		updateIssueField = ns0.RemoteFieldValue_Def("assignee")
		updateIssueField._id = "assignee"
		# values is expected to be an array, so they get an array
		updateIssueField._values = [newUser]
		
		updateIssueReq = updateIssueRequest()
		updateIssueReq._in0 = self.authToken
		updateIssueReq._in1 = issuekey
		updateIssueReq._in2 = [updateIssueField]
		updateIssueResponse = self.connection.updateIssue(updateIssueReq)
		self.__logout()
		updatedIssueDef = updateIssueResponse._updateIssueReturn
		if updatedIssueDef._assignee == newUser:
			return True
		else:
			return False

	def IsIssue(self, issueKey, customer=""):
		#if customer provided checks if ticket is for that customer
		self.__login()
		#issue = ns0.RemoteFieldValue_Def(project)
		issue = getIssueRequest()
		issue._in0 = self.authToken
		issue._in1 = issueKey
		try:
			issueResponse = self.connection.getIssue(issue)
			if customer == "":
				return True
			return issueResponse._getIssueReturn._summary.startswith("[" + customer + "]")
		except:
			return False
				  	
def usage():
	print "Usage: JiraClient <url> <jira-username> <jira-password> <cmd> {args}"
	print "Cmd/Args: CreateUser <username> <fullname> <password> <email>"
	print "          AddToGroup <groupname> <username>"
	print "          CreateGroup <groupname> [initialusername]"
	print "          CreateIssue <issuetype_id> <summary> <description> [assignee]"
	print "	         AddComment <issue_id> <comment>"
	print "          ReassignIssue <issue_id> <new_assignee>"
	print "          IsIssue <issue_id>"
	print "          IsIssueForCustomer <issue_id> <customer>"
	print "          ListTypes"
	
def main(argv=None):
	if argv is None:
		argv = sys.argv

	argc = len(argv)
	print argc
	if argc > 6:
		
		#initialize object first...
		
		client = JiraClient(argv[1], argv[2], argv[3], 12)

		if argv[4] == "CreateUser":
			result = client.CreateUser(argv[5], argv[6], argv[7])
			if result == True:
				print "Successfully created user " + argv[5] + " in JIRA system"
			else:
				print "Error creating user!"
	
		elif argv[4] == "CreateGroup":
			if argc > 6:
				firstUser = argv[6]
			else:
				firstUser = None
			result = client.CreateUser(argv[5], firstUser)
			if result == True:
				print "Successfully created group " + argv[5] + " in JIRA system"
			else:
				print "Error creating group!"
	
		elif argv[4] == "AddToGroup":
			result = client.AddToGroup(argv[5], argv[6])

			# any way to error-check this?
			print "Successfully added user " + argv[6] + " to group " + argv[5] + " in JIRA system"

		elif argv[4] == "CreateIssue":
			if argc > 8:
				assignee = argv[8]
			else:
				assignee = None
			result = client.CreateSupportIssue(argv[5], argv[6], argv[7], assignee)
			if result is not None:
				print "Successfully created new issue in JIRA:\n"
				print result
			else:
				print "Error creating issue in JIRA"
		elif argv[4]  == "AddComment":
			result = client.AddCommentToTicket(argv[5], argv[6])

			# any way to error-check this?
			print "Successfully added comment " + argv[6] + " to ticket " + argv[5] + " in JIRA system"
		elif argv[4] == "ListTypes":
			print "you chose to list types!"
			iTypes = client.GetSupportIssueTypes()
			for id in iTypes.keys():
				print id + ": " + iTypes[id]

		elif argv[4] == "ReassignIssue":
			result = client.ReassignIssue(argv[5], argv[6])

			if result == True:
				print "Successfully reassigned " + argv[5]
				print " to " + argv[6]
			else:
				print "Couldn't reassign issue!!!"
		elif argv[4] == "IsIssue":
			result = client.IsIssue(argv[5])
			if result:
				print "Issue ID " + argv[5] + " is valid"
			else:
				print "Issue ID " + argv[5] + " is not valid"
		elif argv[4] == "IsIssueForCustomer":
			result = client.IsIssue(argv[5], argv[6])
			if result:
				print "Issue ID " + argv[5] + " is valid for customer " + argv[6]
			else:
				print "Issue ID " + argv[5] + " is not valid or not for customer " + argv[6]
		else:
			print "Error: Unknown Command"
			usage()
	else:
		usage()


	
if __name__=="__main__":
	main()

