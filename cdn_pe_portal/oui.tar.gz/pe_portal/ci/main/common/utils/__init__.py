from datetime import datetime, timedelta
from django.template import RequestContext
from django.shortcuts import render_to_response
from django.db.models import Q

def render_response(req, *args, **kwargs):
    "render_to_response, with RequestContext included by default"
    kwargs['context_instance'] = RequestContext(req)
    return render_to_response(*args, **kwargs)

def get_customer(request):
    """
    Method should be used to get the customer for an account
    this is to enable reseller functionality.
    """
    if request.session.get('aurora_default_group'):
        return request.session.get('aurora_default_group')
    if not request.user.is_authenticated():
        return None
    if request.session.get('sub_customer'):
        return request.session.get('sub_customer')
    return request.user.get_profile().customer 

def get_allowed_sites(request, customer=None, include_inactive=False):
    """
    Method takes a request object and returns the sites this user is allowed access to.  Only returns active sites.
    This method also returns all active sites if the request user is a staff member.
    """
    if customer is None:
        customer = get_customer(request)
    profile = request.user.get_profile()
    if not request.user.is_staff or request.session.get('aurora_user'):
        if include_inactive:
            sites = customer.site_set.all().order_by('pad')
        else:
            sites = customer.site_set.filter(status=True).order_by('pad')
    else:
        from ci.common.models import Site
        if include_inactive:
            sites = Site.objects.all().order_by('pad')
        else:
            sites = Site.objects.filter(status=True).order_by('pad')
    if profile.restrict_pads:
        sites = sites.filter(id__in=[d.site.id for d in profile.draft_whitelist.exclude(site__isnull=True)]).order_by('pad')

    if request.session.get('aurora_restrict_pads'):
        restrict_pads = request.session.get('aurora_restrict_pads',-1)
        sites=sites.filter(Q(id__in=restrict_pads))
    return sites

def get_created_pads_by_aurora_user(request):
    """
    [OUI-1884] There is 'PAD not found' gap when a pad is first published to production.
    Before pe2ngp module syncs PAD to NGP DB as stat keyword, it usually takes a minute until sync job is done,
    we need to find a way to show the PAD to its creator.
    Find a creator by searching DraftPadCreator model.
    :param request:
    :return:
    """
    from ci.common.models import SiteDraft, Site
    from ci.common.models.draft_creator import DraftPadCreator
    try:
        from ci.constants import PE2NGP_SYNC_MINUTES_THRESHOLD
        pe2ngp_sync_threshold = PE2NGP_SYNC_MINUTES_THRESHOLD
    except:
        pe2ngp_sync_threshold = 5
    aurora_username = request.session.get('aurora_user_id')
    draft_id_list = DraftPadCreator.objects.filter(creator_id=aurora_username).values_list('site_cui_id',flat=True)
    user_drafts = SiteDraft.objects.filter(pk__in=draft_id_list).filter(site__create_time__gte=datetime.now()-timedelta(minutes=pe2ngp_sync_threshold))
    recent_site_id_list = Site.objects.filter(pk__in=user_drafts.values_list('site_id',flat=True))
    return draft_id_list, recent_site_id_list


def get_allowed_drafts(request, customer=None):
    """
    Method takes a request object and returns the drafts (sitedraft) this user is allowed access to. Returns all drafts (active or inactive)
    This method also returns all drafts (for all customers) if the request user is a staff member.
    include disabled drafts list
    :param request:
    :param customer:
    :return:
    """
    if customer is None:
        customer = get_customer(request)
    profile = request.user.get_profile()

    if not request.user.is_staff or request.session.get('aurora_user'):
        drafts = customer.sitedraft_set.order_by('pad') if not profile.restrict_pads else profile.draft_whitelist
    else:
        from ci.common.models import SiteDraft
        drafts = SiteDraft.objects.order_by('pad')

    if request.session.get('aurora_restrict_pads'):
        restrict_pads = request.session.get('aurora_restrict_pads', -1)
        draft_id_list, recent_site_id_list = get_created_pads_by_aurora_user(request)
        if request.session.get('aurora_admin_flag'):
            drafts = drafts.filter(Q(site__in=restrict_pads) | Q(site__isnull=True, customer=customer))
        else:
            drafts = drafts.filter(Q(site__in=restrict_pads)
                                   | Q(site__in=recent_site_id_list)
                                   | Q(site__isnull=True, pk__in=draft_id_list, customer=customer)
                                   | Q(site__status=False, pk__in=draft_id_list, push_status__in=[3,4], status=False, customer=customer))
    return drafts

def get_allowed_staging_drafts(request, customer=None):
    drafts = get_allowed_drafts(request, customer).filter(push_status=2)
    return drafts

def get_allowed_staging_sites(request, customer=None):
    """
    For internal use from operator. customer user does not need to view stage_site
    :param request:
    :param customer:
    :return:
    """
    from ci.common.models import SiteStage
    if customer is None:
        customer = get_customer(request)
    profile = request.user.get_profile()
    if not request.user.is_staff or request.session.get('aurora_user'):
        stages = SiteStage.objects.filter(customer=customer).order_by('pad') if not profile.restrict_pads else profile.draft_whitelist
    else:
        stages = SiteStage.objects.order_by('pad')

    if request.session.get('aurora_restrict_pads'):
        restrict_pads = request.session.get('aurora_restrict_pads', -1)
        draft_id_list, recent_site_id_list = get_created_pads_by_aurora_user(request)

        if request.session.get('aurora_admin_flag'):
            stages=stages.filter(customer=customer)
        else:
            stages=stages.filter(Q(sitedraft__site__in=restrict_pads) | Q(sitedraft__site__in=recent_site_id_list)
                                 | Q(sitedraft__site__isnull=True, sitedraft__pk__in=draft_id_list))
    return stages

def get_needed_perms(request, obj=None):
    perms=[]
    if not obj:
        obj = request.GET['next'][len(request.META.get('SCRIPT_NAME',""))+1:-1]
        try:
            if not request.user.has_perm('oui.add_%s' % obj):
                perms.append("Can add %s " % obj)
            if not request.user.has_perm('oui.change_%s' % obj):
                perms.append("Can change %s " % obj)
            if not request.user.has_perm('oui.delete_%s' % obj):
                perms.append("Can delete %s " % obj)
        except Exception, e:
            return None
    else:     
        if not request.user.has_perm('oui.add_%s' % obj.model.__name__):
            perms.append("Can add %s " % obj.model.__name__)
        if not request.user.has_perm('oui.change_%s' % obj.model.__name__):
            perms.append("Can change %s " % obj.model.__name__)
        if not request.user.has_perm('oui.delete_%s' % obj.model.__name__):
            perms.append("Can delete %s " % obj.model.__name__)
    return perms

def add_message_to_session(request, message):
    if not request.session.has_key('messages_for_session'):
        request.session['messages_for_session'] = []
    request.session['messages_for_session'].append(message)
