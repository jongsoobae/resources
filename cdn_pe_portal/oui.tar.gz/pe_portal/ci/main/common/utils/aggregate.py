import decimal
from django import forms
from datetime import datetime, timedelta
from ci.common.utils.api import HttpResponseAPISafe
from ci.common.models.aggregate import Aggregate
from ci.common.utils.traffic import processQuery
from ci.constants import MySQL_AGGREGATE_DB

report_types = {'csv': (0,'Comma Separated File'),
	'sdf': (1,'Space Seperated File')
}

def aggregateReportGeneration(customer, form):
	"""Generates the report
	returns an HttpResponse if there is report data
	if there is no data it returns None
	"""
	#set report type specific fields...
	if form.cleaned_data['report_type'] == '1': #Space seperated file...
		report_seperator = ' '
		mime_type = 'text/plain'
		file_extension = 'log'
	else: #default is CSV (VALUE 0)
		report_seperator = ','
		mime_type = 'text/csv'
		file_extension = 'csv'

	#need to generate sql...
	agg_get = {'sites': form.cleaned_data['site'], 'sites__customer': customer, 'id': form.cleaned_data['aggregate']}
	agg = Aggregate.objects.get(**agg_get)
	splits = ['url','response_code', 'referrer', 'user_agent']
	split_fields = ""
	title_row = ""
	for split in splits:
		if not getattr(agg, 'split_' + split) in (None, ''):
			split_fields += ", " + split
			title_row += report_seperator + split
	split_fields = split_fields[1:]
	value_fields = ""
	for ad in agg.aggregatederived_set.all().order_by('derived_number'):
		if ad.derived_type == 1:
			value_fields += ", sum("
		first = True
		title_row += report_seperator + ad.title
		for av in ad.aggregatevalue.all():
			if first:
				first = False
				value_fields += "field" + str(av.field_number)
			else:
				value_fields += "+field" + str(av.field_number)
		value_fields += ") /" + str(ad.divisor_factor)
	for av in agg.aggregatevalue_set.all():
		value_fields += ", sum(field" + str(av.field_number) + ")/" + str(av.divisor_factor)
		title_row += report_seperator + av.title
	value_fields = value_fields[1:]
	sql = " select %s, %s from aggregate_%d where customer_site_id = %s and epoch >= '%s' and epoch < '%s' group by %s order by %s;" \
		%(split_fields,
			value_fields,
			agg.id,
			form.cleaned_data['site'],
			form.cleaned_data['start'].strftime('%Y-%m-%d %H:%M:%S'),
			form.cleaned_data['end'].strftime('%Y-%m-%d %H:%M:%S'),
			split_fields,
			value_fields)
	res = processQuery(sql, MySQL_AGGREGATE_DB, processRow=deliminatedReport, additionalArguments={'deliminator': report_seperator})
	if res == "" or res == None:
		return None
	filen = str(form.cleaned_data['site']) + "_" + form.cleaned_data['start'].strftime('%Y%m%d%H') + "_" + form.cleaned_data['end'].strftime('%Y%m%d%H') + '.' + file_extension
	if form.cleaned_data['show_header']:
		res = str(title_row[1:]) + "\n" + res
	httpr = HttpResponseAPISafe(res, mimetype=mime_type)
	httpr['Content-Disposition'] = 'attachment; filename="' + filen + '"'
	return httpr



class AggregateReportForm(forms.Form):
	site = forms.ChoiceField(label="PAD", choices=[(0, 'form not properly initialized')])
	start = forms.DateTimeField(initial = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=1), required=True)
	end = forms.DateTimeField(initial = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0), required=True)
	report_type = forms.ChoiceField(choices=report_types.values(), required=True)
	aggregate = forms.IntegerField(initial=0, required=True)
	show_header = forms.BooleanField(initial = True, required=False)
	def __init__(self, *args, **kwargs):
		try:
			initial_sites = kwargs.pop('initial_sites')
		except KeyError:
			raise KeyError('An initial_sites argument is required')
		super(AggregateReportForm, self).__init__(*args, **kwargs)
		self.fields['site'].choices = [(s.id, '%s [origin: %s]' % (s.pad, s.origin)) for s in initial_sites]
	def clean(self):
		start = self.cleaned_data.get('start')
		end = self.cleaned_data.get('end')
		if start == None or end == None:
			return self.cleaned_data
		if start != start.replace(minute=0, second=0, microsecond=0)    or \
				end != end.replace(minute=0, second=0, microsecond=0):
			raise forms.ValidationError("Dates must be to the hour.")
		if end <= start:
			raise forms.ValidationError("Start date must be prior to end date")
		if end >= datetime.utcnow().replace(minute=0, second=0, microsecond=0) - timedelta(hours = 1):
			raise forms.ValidationError("End date must be atleast 2 hours ago.")
		return self.cleaned_data
	def addDataError(self, message):
		if not self._errors.has_key('site') or not self._errors['site']:
			self._errors['site'] = []
		self._errors['site'].append(message)

def deliminatedReport(row, **kwargs):
	res = ""
	deliminator = kwargs.get('deliminator') if kwargs.has_key('deliminator') else ","
	for val in row:
		if isinstance(val,decimal.Decimal):
			val = float(val)
			if val == int(val):
				val = int(val)
			val = str(val)
		res += deliminator + val
	return res[1:]

