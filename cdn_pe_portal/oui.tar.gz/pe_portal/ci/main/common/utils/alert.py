from datetime import datetime, timedelta, date
from ci.constants import ALERT_ADDR, NOC, NO_REPLY, SJ_NOC
from ci.common.models.alert import Alert, OnCallSchedule
from ci.common.models import UserProfile
from ci.common.utils.mail import send_email
from ci.common.utils.timeutil import in_minutes, one_day
import traceback
import pickle
import time
import os

"""
example usage:

class MyTest(Test):
	def warn(self):
		...
	def alert(self):
		...
	
tester = Tester((MyTest(300, 'my_test'),), ...)
tester.run()
"""

ALERT_THROTTLE_FILENAME = '/opt/cdn/ui/prod/ui/scripts/alert_times.log'
MAX_SEND_COUNT = 10

# this is defined here for hotfix - remove after 09/2010 release is out
APAC_SD = "apac-sd@cdnetworks.co.kr"
US_SD = "ops-sd@cdnetworks.com"
KR_NOC = "noc@cdnetworks.co.kr"


class Tester:
	"""give it a list of Tests to run: it will do so and send notifications if the Tests
	produce any warnings or alerts."""
	def __init__(self, tests, warn_from, warn_to, subject_prefix, alert_code, throttle):
		self.tests = tests
		self.warnings, self.alerts = [], []
		self.warn_from = warn_from
		self.warn_to = warn_to
		self.subject_prefix = subject_prefix
		self.alert_code = alert_code
		self.throttle = throttle
		self.alert_subject="OUI alert :: "
		
	def run(self):
		for test in self.tests:
			try:
				test.run(self.throttle)
				self.warnings += test.warnings
				self.alerts += test.alerts
			except Exception, e:
				self.warnings.append('exception while running %s:\n%s' % (test.__class__, traceback.format_exc()))
		
		if self.warnings:
			send_email(self.warn_from, self.warn_to,
				'%s: %d warnings' % (self.subject_prefix, len(self.warnings)), '\n\n'.join(self.warnings))
		
		if self.alerts:
			send_alert(self.alert_code, 
				'%s: %d alert(s)' % (self.subject_prefix, len(self.alerts)), '\n\n'.join(self.alerts))

class Test:
	"""append strings to self.warnings and self.alerts in order to cause Tester to send alerts.
	set throttle_seconds and throttle_key to determine how often the alert should be throttled."""
	def __init__(self, throttle_seconds=0, throttle_key=None):
		self.warnings, self.alerts = [], []
		self.throttle_seconds = throttle_seconds
		self.throttle_key = throttle_key
	def warn(self):
		"""return a list of warning strings, which may be empty."""
		return []
	def alert(self):
		"""return a list of alert strings, which may be empty."""
		return []
	def warn_and_alert(self):
		"""use this when the same tests can produce warnings and/or alerts.
		the overriding method should return a tuple of lists: (warnings, alerts).
		do not duplicate tests between warn, alert, and warn_and_alert, because
		they will all be run.
		"""
		return [], []
	def run(self, throttle):
		if self.throttle_key is None or throttle.ok(self.throttle_key, self.throttle_seconds):
			self.warnings += self.warn()
			self.alerts += self.alert()
			
			w, a = self.warn_and_alert()
			self.warnings += w
			self.alerts += a
			
			if self.throttle_key and (self.warnings or self.alerts):
				throttle.update(self.throttle_key)

class Throttle:
	"""after an alert is fired, store the time in a file to suppress repeated alerts
	while the issue is fixed. 
	
	this file will be overwritten if a new build is deployed."""
	def __init__(self, filename=ALERT_THROTTLE_FILENAME):
		self.filename = filename
		if os.access(self.filename, os.F_OK):
			self.times = pickle.load(open(self.filename))
		else:
			self.times = {}
	def update(self, code):
		self.times[code] = time.time()
		pickle.dump(self.times, open(self.filename,'w'))
	def ok(self, code, seconds):
		try:
			return time.time() - self.times[code] > seconds
		except KeyError:
			return True

def send_alert(code, subject, body, urgent=True, jira_info=None, user=None):
	"""convenience method so any script can create a new alert."""
	alert = Alert()
	alert.urgent = urgent
	alert.alert_code = code[:Alert._meta.get_field('alert_code').max_length]
	alert.email_subject = subject[:Alert._meta.get_field('email_subject').max_length]
	alert.email_body = body
	alert.jira_info = jira_info 
	alert.user = user
	alert.save()
	return alert 

def get_live_alerts():
	return Alert.objects.filter(handled_by__isnull=True,urgent=True,
		last_send_time__lt=datetime.now()-timedelta(minutes=5), create_time__lt=datetime.now()-timedelta(minutes=15), alert_code="App :: CUI")\
		| Alert.objects.filter(handled_by__isnull=True, urgent=True, last_send_time__lt=datetime.now()-timedelta(minutes=5)).exclude(alert_code="App :: CUI") 
			
def get_current_oncall():
	now = datetime.now()
	try:
		contacts = OnCallSchedule.objects.get(start_time__lte=now, end_time__gt=now).oncallcontact_set.order_by('contact_order')
		return [[c.contact_order, c.contact.email, c.contact.id] for c in contacts]
	except:
		send_email(NO_REPLY, [ALERT_ADDR], '[alert] invalid/missing OUI on-call roster slot', "The on-call schedule does not have positions filled for the current shift. \n Please refer to the on-call schedule in the wiki and fill in the appropriate slots.")

def email_live_alerts():
	try:
		for alert in get_live_alerts():
			alert_app = alert.alert_code.split('::')[1]
			subject = "[URGENT/%s, #%d] %s"% (alert_app, alert.id, alert.email_subject)
			recipients = [KR_NOC, SJ_NOC, APAC_SD, US_SD]
			body = """The following alert is %d minutes old\n\n Visit the OUI alerts page to acknowledge this alert: \n https://pantheroui.cdnetworks.com/alert/ \n\n
Original alert message:\n\n%s	"""\
			 	% (in_minutes(datetime.now()-alert.create_time), alert.email_body)			
			send_email(ALERT_ADDR, recipients, subject, body, reply_to=NOC)
			# update the alert's record
			alert.last_send_time = datetime.now()
			alert.send_count += 1
			alert.save()
	except Exception:
		send_email(ALERT_ADDR, [NOC], 'exception in email_live_alerts', traceback.format_exc())

def oncall_roster_check():
	now = datetime.now()
	start = now.replace(hour=0, minute=0, second=0, microsecond=0)
	end = start + timedelta(days=14)
	oncall = OnCallSchedule.objects.filter(start_time__gte=start, start_time__lte=end)
	gaps = []
	for each in range(oncall.count()):
		try:
			if not oncall[each].end_time==oncall[each+1].start_time:
				gaps.append((oncall[each].end_time, oncall[each+1].start_time))
		except Exception:
			if oncall[each].end_time<end:
				gaps.append((oncall[each].end_time, end))
	body = "The on-call roster has the following gap(s) in the upcoming 2 weeks (times GMT): \n"
	if gaps:
		for each in gaps:
			body += "- %s to %s\n" % (each[0].strftime("%a, %d %b %Y %H:%M"), each[1].strftime("%a, %d %b %Y %H:%M"))
		send_email(NO_REPLY, [NOC], "[alert] on-call roster gap", body)

def send_oncall_reminders():
 	"""Find the on_call schedule for the next week (might add more time increments later) and send send a reminder email to each person on those oncall contacts remindig hem of the position
 	 and the start/end times of the shift """
 	position={0:'primary',1:'secondary',2:'tertiary'}
 	start, end = date.today()+timedelta(days=1), date.today()+timedelta(days=7)
	missing_slots = []
 	r = (end+timedelta(days=1)-start).days
 	for each in [start+timedelta(days=i) for i in range(r)]:
 		on_call_list=[]
		shift_range = one_day(each)
		oncall = OnCallSchedule.objects.filter(start_time__gte=shift_range[0], end_time__lt=shift_range[1])
		for c in oncall:
			on_call_list.append(c.oncallcontact_set.order_by('contact_order'))
		for each in on_call_list:
			for contact in each:
				start_time = contact.schedule.start_time-timedelta(hours=4)
				end_time = contact.schedule.end_time-timedelta(hours=4)
				email_body=u'This is an automated reminder of your upcoming shift as %s on-call support engineer.\n\n Shift dates & times...\n -Start: %s \n -End: %s \n\n All times Eastern time zone.' % (position[contact.contact_order],start_time.strftime("%a, %d %b %Y %H:%M"), end_time.strftime("%a, %d %b %Y %H:%M") )
				send_email(NO_REPLY, [contact.contact.email], u'[support] on-call shift reminder for %s: %s' %(contact.contact.username,start_time.strftime("%a, %d %b %Y")), email_body)
	#  		except:
	# 		missing_slots.append((shift_range[0], shift_range[1]))
	# if missing_slots:
	# 	body = "The following time slots do not have on-call rosters filled out: \n\n "
	# 	for each in missing_slots:
	# 		body += "From %s to %s\n" % (each[0], each[1])
	#  		# send_email(NO_REPLY, [NOC], "[alert] Missing slots in upcoming week's oncall roster", body)
	# 	print body
		
