from django.http import HttpResponse
from django.db.models.fields import *
from django.forms import fields as formfields
from django.forms.util import ErrorList
from django.shortcuts import get_object_or_404
from ci.common.utils import get_allowed_sites, get_allowed_drafts,get_allowed_staging_sites
from django.db.models.base import ModelBase
from ci.common.utils.misc import padded_cop_product_id

class APIErrorResponse(HttpResponse):
    def __init__(self, content, status=400):
        HttpResponse.__init__(self, content=content, status=status)


class APIException(Exception):
    def __init__(self, message, status=400):
        Exception.__init__(self, message)
        self.status_code = status

    def get_error_message_for_sam_error(self):
        def get_depth_first_message(o):
            if type(o) != dict:
                return o

            key = o.keys()[0]
            return key + ' -> ' + get_depth_first_message(o[key])
        try:
            return get_depth_first_message(self.message)
        except:
            return str(self.message)


class HttpResponseAPISafe(HttpResponse):
    pass

def page_not_found(request):
    return APIErrorResponse("404 Not Found: API Requested Not Found. This is most likely caused by a syntax error in the url.  Ensure all required parameters are supplied and the URL ends with a trailing '/'", 404)

def server_error(request):
    import traceback
    return APIErrorResponse("500 Server Error: Internal Error - Contact Support", 500)

def get_object_or_api_exception(*args, **kwargs):
    message = kwargs.pop('message',"Invalid value supplied.")
    as_query = kwargs.pop('as_query', False)
    try:
            
        obj = get_object_or_404(*args, **kwargs)
        if as_query:
            if isinstance(args[0],ModelBase):
                obj = args[0].objects.filter(pk = obj.pk)
            else:
                obj = args[0].filter(pk = obj.pk)
        return obj
    except Exception, e:
        raise APIException(message, status=400)

def get_site_or_api_exception(pRequest, pad, as_query=False, message=None, sites = None, include_inactive=False):
    try:
        if type(sites) is type(None): # avoid evaluation of queryset
            sites = get_allowed_sites(pRequest, include_inactive=include_inactive)
        if as_query:
            if not pad.isdigit():
                sites = sites.filter(pad=pad)
            else:
                sites = sites.filter(pk=pad)
            if sites.count() != 1:
                raise Exception(message if message else "Should only be a single site")
            return sites
        if not pad.isdigit():
            return sites.get(pad=pad)
        else:
            return sites.get(pk=pad)
    except:
        raise APIException(message if message else "Invalid PAD supplied.", status=400)

def get_stage_site_or_api_exception(pRequest, pad, as_query=False, message=None, sites = None):
    """
    For internal use from operator. customer user does not need to view stage_site
    :param pRequest:
    :param pad:
    :param as_query:
    :param message:
    :param sites:
    :return:
    """
    try:
        if type(sites) is type(None): # avoid evaluation of queryset
            sites = get_allowed_staging_sites(pRequest)
        if as_query:
            if not pad.isdigit():
                sites = sites.filter(pad=pad)
            else:
                sites = sites.filter(pk=pad)
            if sites.count() != 1:
                raise Exception(message if message else "Should only be a single site")
            return sites
        if not pad.isdigit():
            return sites.get(pad=pad)
        else:
            return sites.get(pk=pad)
    except:
        raise APIException(message if message else "Invalid PAD supplied.", status=400)

def get_draft_or_api_exception(pRequest, pad, as_query=False, message=None, drafts = None):
    try:
        if type(drafts) is type(None): # avoid evaluation of queryset
            drafts = get_allowed_drafts(pRequest)
        if as_query:
            drafts =drafts.filter(pad=pad)
            if drafts.count() != 1:
                raise Exception(message if message else "Should only be a single draft")
            return drafts
        return drafts.get(pad=pad)
    except Exception, e:
        raise APIException(message if message else "Invalid PAD supplied.", status=400)

def get_model_details(pRequest, model_query, opt_params, info_fields=None, default_fields=('id')):
    """This is a helper class for list/view api methods
    @param pRequest: Request object passed from django
    @param model_query: A model query instance that this will drill down
    @param opt_params: [Optional] This will be derived from pRequest.  
        Only pass this if you need to do preprocessing before querying this function
    @param info_fields: [Optional] If set will check for parameter info and use info_fields instead of default fields.  This should be a tuple or "*" to represent all fields.
    @param default_fields: What fields to return, should be a tuple or "*" to represent all fields. Default is just id
    """
    if info_fields and opt_params.has_key('info') and opt_params.pop('info') == [u"1"]:
        if info_fields == "*":
            query = model_query.values()
        else:
            query = model_query.values(info_fields)
    else:
        if default_fields == "*":
            query = model_query.values()
        else:
            query = model_query.values(default_fields)

def values_replace_choice(values, model, rename={}):
    """This goes through and replaces all values with their choice value.
    Will return a list object"""
    values_list = list(values)
    if len(values_list) < 1:
        return values_list
    for field_name in values_list[0]:
        try:
            field = model._meta.get_field(field_name)
            if len(field.choices) > 0:
                choices = dict(field.get_choices())
                for rec in values_list:
                    if choices.has_key(rec[field_name]):
                        rec[field_name] = choices.get(rec[field_name])
        except FieldDoesNotExist:
            pass
        except Exception, e:
            continue
    if rename:
        for old_name, new_name in rename.items():
            for rec in values_list:
                if rec.has_key(old_name):
                    rec[new_name] = rec.pop(old_name)
    return values_list

def get_available_choices(field,key):
    index_choices = ['Please Estimate','------']
    try:
        result_list = []
        for choice in field.choices:
            is_exist = False
            for index_choice in index_choices:
                if index_choice in choice[1]:
                    is_exist = True
                    break
            if not is_exist:
                if key=='shield_location':
                    result_list.append("'%s'" % str(choice))
                else:
                    result_list.append("'%s'" % choice[1])
        return ",".join(result_list)
    except:
        return ""


def create_api_modelform(modelform, fields_list):
    """Takes a modelform and the fields being edited and creates
    a new model form that is restricted to just these objects"""
    class APIGeneratedForm(modelform):
        class Meta(modelform.Meta):
            fields = fields_list

        def __init__(self, *args, **kwargs):
            """This handles converting 0 to None for boolean objects to work properly from API to model."""
            ret = super(APIGeneratedForm, self).__init__(*args,**kwargs)
            self.delayed_errors = {}

            try:
                for key in self.data.keys():
                    field = self.fields.get(key)
                    if isinstance(field,formfields.BooleanField) and self.data[key] in (0,"0",["0"]):
                        self.data[key] = None
                    elif hasattr(field, 'choices'):
                        try:
                            from ci.common.models.customer import Product
                            if key == 'product':
                                val = self.data.get(key,None)
                                val = str(Product.objects.get(cop_product_id=padded_cop_product_id(val)))
                            else:
                                val = self.data.get(key,None)
                            if key == 'shield_location':
                                try:
                                    val = int(val)
                                except:
                                    val = None
                            else:
                                if isinstance(val,list) and len(val) == 1:
                                    val = val[0]
                                val = val.lower()

                            found = False
                            choices = field.choices
                            if isinstance(field.choices,forms.models.ModelChoiceIterator):
                                choices = []
                                for i in field.choices.queryset:
                                    choices.append((i.pk,str(i)))
                            for choice, description in field.choices:
                                if key == 'shield_location':
                                    if choice == val:
                                        self.data[key] = choice
                                        found = True
                                        break
                                else:
                                    if unicode(description).lower() == val:
                                        self.data[key] = choice
                                        found = True
                                        break
                            if not found:
                                #this is bad so need to add errors and remove value.
                                err_msg = "Select a valid choice. That choice is not one of the available choices."
                                if field.choices:
                                    available_choices = get_available_choices(field, key)
                                    if len(available_choices) > 0:
                                        err_msg = "Select a valid choice. Available choice is one of %s." % (available_choices)
                                self.delayed_errors[key] = err_msg
                                self.data.pop(key)
                        except Product.DoesNotExist:
                            self.delayed_errors[key] = "Product input is not valid."
                        except Exception,e:
                            self.delayed_errors["general"] = "Unknown error in parsing input"
            except:
                return ret
            return ret

        def clean(self):
            if self.delayed_errors:
                for key,value in self.delayed_errors.items():
                    self._errors[key] = ErrorList([value])
            return super(APIGeneratedForm, self).clean()

    return APIGeneratedForm