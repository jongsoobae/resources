def get_beian_no(domain):
    import json
    from suds.client import Client
    try:
        wsdl = "http://60.30.128.74:43392/?wsdl"
        domains = [domain]
        param = json.dumps({"IcpRequest": {"domains": domains}})

        client = Client(wsdl)
        client.set_options(timeout=300)
        res = json.loads(client.service.findDomainState(param).encode('utf-8'))['IcpRespone']['domains'][0]
        if not res['result'] == 'success':
            raise Exception
        return res['phylicnum']
    except:
        return None
