import netaddr
from api.rapi.utils import RestResponse
from ci.common.models.cdn import Node, NodeIP


REGEX_IPV4 = '^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$'
REGEX_IPV6 = ''.join(['^(?:(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}',  # standard
                      '|(?=(?:[a-fA-F0-9]{0,4}:){0,7}[a-fA-F0-9]{0,4}$)',  # compressed with at most 7 colons
                      '(([0-9A-Fa-f]{1,4}:){1,7}|:)((:[0-9A-Fa-f]{1,4}){1,7}|:)|',  # at most 1 double colon
                      '(?:[a-fA-F0-9]{1,4}:){7}:|:(:[a-fA-F0-9]{1,4}){7})$'])  # compressed with 8 colons

JSON_SCHEMA = {
    "type": "object",
    "properties": {
        "hostname": {
            "type": "string",
        },
        "pair": {
            "type": "array",
            "items": [
                {"type": "string", "pattern": REGEX_IPV4},
                {"type": "string", "pattern": REGEX_IPV6}
            ]
        }
    },
    "required": ["hostname", "pair"]
}


class JsonResponse(RestResponse):
    def __init__(self, obj, error=None, label='data', status=200, custom_mode=True):
        if not error:
            error = {}
        super(JsonResponse, self).__init__(obj, error=error, label=label, status=status, custom_mode=custom_mode)
        self['Content-Type'] = 'application/json; charset=utf-8'


class ValidationException(Exception):
    def __init__(self, message, status=400):
        Exception.__init__(self, message)
        self.status_code = status


class NodeIpPairRegister(object):
    def __init__(self, hostname, pair):
        super(NodeIpPairRegister, self).__init__()
        self.hostname = hostname
        self.pair = pair
        self.v4 = pair[0] if pair else ''
        self.v6 = str(netaddr.IPAddress(pair[1])) if pair else ''

        try:
            self._node_object = Node.objects.get(ngp_hostname__icontains=self.hostname)
        except Node.DoesNotExist:
            raise ValidationException('There is no node for this ngp_hostname `%s`.' % self.hostname)
        self._node_ip_list = NodeIP.objects.filter(node=self.node_object, is_v6=False)
        self._node_ip_dict = {}
        for nodeip in self.node_ip_list:
            self._node_ip_dict[nodeip.ipv4_address] = nodeip

    def do_register(self):
        if not self.is_exist_v4():
            raise ValidationException(message='Not exist v4-ip %s in OUI. Can`t register v6 ip.' % self.v4)

        self._ip_update(self.v4, self.v6)
        results = {
            'added-pair': [self.v4, self.v6]
        }
        return results

    def do_delete(self):
        if not self.is_exist_v4():
            raise ValidationException(message='Not exist v4-ip %s in OUI. Can`t delete v6 ip.' % self.v4)

        v6_status = self.check_v6_status()
        if v6_status[0] != 2:
            raise ValidationException(message=v6_status[1], status=400 if v6_status[0] in [0, 1] else 500)

        self.node_ip_dict[self.v4].get_v6_node_ip_by_seq().delete()
        results = {
            'removed-pair': [self.v4, self.v6]
        }
        return results

    def is_exist_v4(self):
        return self.v4 in self.node_ip_dict

    def check_v6_status(self):
        status = (
            (0, 'v4-ip not exist. %s - %s.' % (self.v4, self.v6)),
            (1, 'v6-ip not exist. %s - %s.' % (self.v4, self.v6)),
            (2, 'v4-ip and v6-ip exist.'),
            (3, 'v6-ip exist but v4-ip & v6-ip pair is not valid. %s - %s.' % (self.v4, self.v6)),
            (4, 'v6-ip exist but used at BAND[#BAND#]. %s - %s.' % (self.v4, self.v6))
        )
        if not self.is_exist_v4():
            return status[0]

        if not NodeIP.objects.filter(ipv4_address=self.v6).exists():
            return status[1]

        v6_node_ip = self.node_ip_dict[self.v4].get_v6_node_ip_by_seq()
        if not v6_node_ip or not v6_node_ip.pk:
            return status[3]

        band_nodes = v6_node_ip.bandnode_set.all()
        if band_nodes.exists():
            message = status[4][1].replace('#BAND#', ' , '.join(["'%s'" % str(x) for x in band_nodes]))
            return status[4][0], message

        return status[2]

    def _ip_update(self, v4, v6):
        v4_node = self.node_ip_dict[v4]
        v6_node = v4_node.get_v6_node_ip_by_seq()
        if v6_node:
            v6_node.ipv4_address = v6
        else:
            v6_node = NodeIP(
                node=self._node_object,
                seq_num=int(v4_node.seq_num)+100,
                ipv4_address=v6,
                description='pair with %s' % str(v4_node),
                is_v6=True)
        v6_node.save()

    @property
    def node_object(self):
        return self._node_object or Node.objects.none()

    @property
    def node_ip_list(self):
        return self._node_ip_list or []

    @property
    def node_ip_dict(self):
        return self._node_ip_dict or {}


def is_match_v4_v6(v4, v6):
    word4 = map(lambda word: int('0x'+str(word), 0), netaddr.IPAddress(v4).words)
    word6 = map(lambda word: int(word), netaddr.IPAddress(v6).words[4:])

    return word4 == word6
