from ci.common.models import Site, SiteDraft
from ci.common.utils import get_allowed_drafts, get_customer
from ci.common.utils.api import APIException
from ci.common.utils.json_load_ordered import json_load_ordered
from ci.common.utils.sam_wizard import add_sam_sandbox, delete_sam_sandbox
from django.utils import simplejson as json
from ci.common.utils.json_load_ordered import json_load_ordered

def sam_viewrule(request, opts, pad):
    try:
        if pad not in get_allowed_drafts(request).values_list('pad', flat=True):
            return '', 'You can`t view sam rule on this pad(%s).' % pad

        try:
            site_draft = SiteDraft.objects.get(pad=pad)
        except SiteDraft.DoesNotExist:
            return '', 'There is no pad(%s).' % pad

        sam_json = site_draft.json_server_actions()
        if not sam_json:
            return 'There is no samrule on this pad(%s).' % pad, {}

    except APIException, ae:
        raise ae
    except Exception, e:
        raise APIException(e.message)

    return sam_json, ''


def sam_addrule(request, opts, pad):
    try:
        if pad not in get_allowed_drafts(request).values_list('pad', flat=True):
            return '', 'You can`t add sam rule on this pad(%s).' % pad

        try:
            site_draft = SiteDraft.objects.get(pad=pad)
        except SiteDraft.DoesNotExist:
            return '', 'There is no pad(%s).' % pad

        if site_draft.product and not site_draft.product.active:
            return '', 'Product is expired. If you want to proceed, please contact center'

        if not site_draft.is_modifiable():
            return '', {'general': "Unable to modify. PAD is currently in %s" % site_draft.get_pad_status()}
        if site_draft.is_waiting_implementation():
            return '', {'general': "Unable to modify. PAD is currently in %s" % site_draft.get_pad_status()}

        try:
            rule_data = json_load_ordered(opts.get('sam_json'))
        except ValueError, ve:
            raise APIException({'sam_json': 'Not a valid json.'})
        body_data = {
            'hash': site_draft.server_actions_hash(),
            'rule_data': rule_data
        }

        add_sam_sandbox(site_id=site_draft.pk, body_data=body_data,
                        aurora_user_id=request.session.get('aurora_user_id', ''),
                        customer=get_customer(request))
    except APIException, ae:
        raise ae
    except Exception, e:
        raise APIException(e.message)
    return 'Your samrule is successfully added on pad(%s).' % pad, {}


def sam_editrule(request, opts, pad):
    try:
        if pad not in get_allowed_drafts(request).values_list('pad', flat=True):
            return '', 'You can`t edit sam rule on this pad(%s).' % pad

        try:
            site_draft = SiteDraft.objects.get(pad=pad)
        except SiteDraft.DoesNotExist:
            return '', 'There is no pad(%s).' % pad

        if site_draft.product and not site_draft.product.active:
            return '', 'Product is expired. If you want to proceed, please contact center'

        if not site_draft.is_modifiable():
            return '', {'general': "Unable to modify. PAD is currently in %s" % site_draft.get_pad_status()}
        if site_draft.is_waiting_implementation():
            return '', {'general': "Unable to modify. PAD is currently in %s" % site_draft.get_pad_status()}

        try:
            rule_data = json_load_ordered(opts.get('sam_json'))
        except ValueError, ve:
            raise APIException({'sam_json': 'Not a valid json.'})
        body_data = {
            'hash': site_draft.server_actions_hash(),
            'rule_data': rule_data
        }

        add_sam_sandbox(site_id=site_draft.pk, body_data=body_data,
                        aurora_user_id=request.session.get('aurora_user_id', ''),
                        customer=get_customer(request))
    except APIException, ae:
        raise ae
    except Exception, e:
        raise APIException(e.message)
    return 'Your samrule is successfully edited on pad(%s).' % pad, {}


def sam_deleterule(request, opts, pad):
    try:
        if pad not in get_allowed_drafts(request).values_list('pad', flat=True):
            return '', 'You can`t delete sam rule on this pad(%s).' % pad

        try:
            site_draft = SiteDraft.objects.get(pad=pad)
        except SiteDraft.DoesNotExist:
            return '', 'There is no pad(%s).' % pad

        if site_draft.product and not site_draft.product.active:
            return '', 'Product is expired. If you want to proceed, please contact center'

        if not site_draft.is_modifiable():
            return '', {'general': "Unable to delete. PAD is currently in %s" % site_draft.get_pad_status()}
        if site_draft.is_waiting_implementation():
            return '', {'general': "Unable to delete. PAD is currently in %s" % site_draft.get_pad_status()}

        delete_sam_sandbox(site_id=site_draft.pk, aurora_user_id=request.session.get('aurora_user_id', ''))
    except APIException, ae:
        raise ae
    except Exception, e:
        raise APIException(e.message)
    return 'Your samrule is successfully deleted on pad(%s).' % pad, {}