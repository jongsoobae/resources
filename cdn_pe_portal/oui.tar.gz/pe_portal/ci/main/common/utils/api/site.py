import hashlib
import cPickle
import socket
import time
import json
import urllib
from django.utils import simplejson
from django.core.cache import cache
from django.utils.encoding import force_unicode, smart_unicode, smart_str
from ci.common.forms.site import get_EditPadForm, DuplicateForm, SiteForm
from ci.common.models.site import SiteDraft, Site, PADChangeTime, STAGING_READY, PRODUCTION_READY
from ci.common.models.customer import Customer
from ci.common.utils.api import get_draft_or_api_exception, get_site_or_api_exception, APIException, create_api_modelform
from ci.common.utils import get_allowed_drafts, get_allowed_sites, get_customer
from ci.common.utils.site import getFieldsFromFieldset, send_implementation_email, log_pad_change, \
    save_draft_creator, get_editable_fields, save_site_change_history
from ci.common.utils.curlwrapper.browser import Browser
from ci.common.utils.curlwrapper.request import Request
from ci.common.utils.pusher import NGP_BEPusher
from ci.constants import CS_PASSWORD
from ci.common.utils.misc import short_hostname, padded_cop_product_id

def make_cookie(cookie_ttl, test_hostname):
    """Make cookie
    :param cookie_ttl: cookie ttl
    :param test_hostname: test hostname
    :return: cookie
    """
    # example cookie_ttl = 10000
    auth_time = int(time.time()) + int(cookie_ttl)
    local_ip = socket.gethostbyname(socket.gethostname())

    auth = hashlib.sha1("%s%s%s%s" % (CS_PASSWORD, test_hostname, auth_time, local_ip)).hexdigest()
    cookies = 'authTime=%s;auth=%s' % (auth_time, auth)

    return cookies

def get_cs_auth_cookie(hostname):
    """
    deprecated
    :param hostname:
    :return:
    """
    browser = Browser()
    request = Request(url="https://%s/login" % (hostname), post={'password':CS_PASSWORD})
    resp = browser.request(request)
    cookies = []
    for header in resp.headers:
        if header[0] == 'Set-Cookie':
            cookies.append(header[1].split(';')[0])

    return "; ".join(cookies)

def get_aurora_username(pRequest):
    username = pRequest.user.username
    try:
        username = pRequest.POST.get('aurora_user_id')
    except:
        pass
    return username

def push_to_staging(pRequest,opts,pad):
    """
    TODO: if draft.status == -2 or -4, it needs to prevent another push since consequent calls are not necessary
    :param pRequest:
    :param opts:
    :param pad:
    :return:
    """
    result = ''
    errors = {}
    description = "[API] %s" % opts.get('description','')
    draft = get_draft_or_api_exception(pRequest, pad, message="Invalid site supplied to push to staging") if pad else None
    try:
        result = "You have requested to push the PAD configuration to our staging servers. " \
                 "Please wait a few mins, as the push is in progress."
        if draft.push_status == 1:
            pass
        elif draft.push_status == 2:
            result = "PAD is already pushed to staging servers."
        else:
            username = get_aurora_username(pRequest)
            draft.push_to_staging(username=username, description=description)
    except Exception,e:
        raise APIException(e)

    return result, errors

def get_pad_status(pRequest,opts,pad):
    result = {}
    errors = {}

    draft = get_draft_or_api_exception(pRequest, pad, message="Invalid site supplied to look up") if pad else None
    try:
        result = draft.get_deploy_status_dict()
    except Exception,e:
        raise APIException(e)

    return result, errors

def is_self_implementable_pad(pRequest, opts, pad):
    result = ''
    errors = {}
    draft = get_draft_or_api_exception(pRequest, pad, message="Invalid site supplied to look up") if pad else None
    try:
        result = draft.is_self_implementable()
    except Exception,e:
        raise APIException(e)

    return result, errors

def push_to_production(pRequest,opts,pad):
    result = ''
    errors = {}
    description = "[API] %s" % opts.get('description','')
    draft = get_draft_or_api_exception(pRequest, pad, message="Invalid site supplied to publish to production") if pad else None
    try:
        result = "You have requested to push the PAD configuration to our production servers. \n " \
                 "Please wait a few mins, as the push is in progress."
        if draft.push_status == 3:
            pass
        elif draft.push_status == 4:
            result = "PAD is already published to production."
        else:
            username = get_aurora_username(pRequest)
            draft.push_to_production(username=username, request=pRequest, description=description)
    except Exception,e:
        raise APIException(e)
    return result, errors

def get_customized_error_message(error_code, error_params=[]):
    """
    https://wiki.cdnetworks.com/confluence/pages/viewpage.action?pageId=140739006
    get error message with error code by pad
    :param error_code:
    :param error_params:
    :return:
    """
    if not error_params:
        error_param = ""
    try:
        if error_code in ['ER07','ER10']:
            error_param = urllib.unquote(error_params[0])
        elif error_code in ['ER09','ER12','ER13','ER16']:
            error_param = urllib.unquote(error_params[1])
        else:
            error_param = urllib.unquote(error_params[0])
    except:
        error_param = ""

    err_code_dict = {'ER01':"undefined",
     'ER02':"invalid rule '%s' in 'Validation Scheme'." % (error_param),
     'ER03':"Wildcard PAD suffix is too short, less than 5.",
     'ER04':"PAD '%s' duplicates with another PAD or a Alias." % (error_param),
     'ER05':"Alias '%s' duplicates with a PAD or another Alias." % (error_param),
     'ER06':"invalid regular expression rule in 'URI pattern to skip tag validation'." ,
     'ER07':"invalid rules '%s' in 'Cache Controller max-age rules'." % (error_param) ,
     'ER08':"invalid regular expression rule in 'Regex Rewrite Rules after validation' or 'Regex Rewrite Rules (URI)' or 'Regex Rewrite Rules (Full URL)'." ,
     'ER09':"invalid rewrite rule '%s' in 'Regex Rewrite Rules after validation' or 'Regex Rewrite Rules (URI)' or 'Regex Rewrite Rules (Full URL)'." % (error_param),
     'ER10':"invalid values '%s' in 'Track codes'." % (error_param),
     'ER11':"invalid regular expression rule in 'Referrer list'. ",
     'ER12':"invalid header '%s' in 'Custom Headers to Origin'." % (error_param),
     'ER13':"invalid header '%s' in 'Validaton Custom Headers'." % (error_param),
     'ER14':"invalid IP Address in 'Static Origin IP'." ,
     'ER15':"invalid regular expression rule in 'Content Variation Rules'. ",
     'ER16':"invalid rule '%s' in 'Content Variation Rules'." % (error_param),
     'ER17':"invalid JSON format in 'Server action manager rules(SAM)'.",
     'ER18':"undefined",
     'ER19':"undefined",
     'ER20':"invalid JSON format in 'Server action manager rules(SAM)'.",
     'ER21':"invalid JSON format in 'Server action manager rules(SAM)'.",
     'ER22':"invalid regular expression rule '%s' in 'Cache Controller max-age rules'." % (error_param),
     'ER23':"Invalid URL rewrite rule '%s' in 'Server action manager rules(SAM)'." % (error_param),
     'ER100':"undefined",}
    try:
        return err_code_dict.get(error_code)
    except:
        return "undefined"

def get_push_history(customer, username, draft=None, is_for_customer=False):
    """
    default 7 days of history queryset will be returned
    get history from  ConfigPushRequestHistory and look up config api with action id
    merge completion rate info
    :param customer:
    :param username:
    :return:
    """
    errors = {}
    try:
        cache_key = "push_history_%s_%s" % (str(customer.pk), username)
        if draft:
            cache_key = "%s_%s" % (cache_key, str(draft.pk))
        result_list = cache.get(cache_key)
    except Exception, e:
        result_list = None

    if result_list is not None:
        return result_list, errors

    result_list = []
    try:
        bepusher = NGP_BEPusher()
        #if size given as -1, default 7 days of history queryset will be returned
        bepush_history = bepusher.history(size=-1, types='SITESNG', user=username, customer=customer, draft=draft)
        try:

            history_id_list = bepush_history.values_list('pk',flat=True)
            all_push_result_items = bepusher.progress(history_id_list=history_id_list)
        except Exception,e:
            errors.update({'config_api': "failed to retrieve push history"})

        for history in bepush_history:
            push_result_items = all_push_result_items.get(history.pk) #filter again by history
            push_result_item = history.get_valid_push_result_item(push_result_items)
            if push_result_item:
                completion_rate, ok_list, total_list = history.get_push_completion_rate(push_result_item)
                completion_rate = "%s" % (str(completion_rate))
                status = push_result_item.get('status')

                parsed_msg, display_msg = history.get_parsed_status_message({history.pk:push_result_item})
                revision = push_result_item.get('revision')
                ok_list = push_result_item.get('ok')
            else:
                completion_rate = '0.0'
                status = 'Unknown'
                parsed_msg = ''
                display_msg = ''
                revision = -1
                ok_list = []

            try:
                site_draft = history.site_draft
            except:
                site_draft = None

            if site_draft is None:
                pad_name = ''
            else:
                pad_name = force_unicode(site_draft.get_display_name_for_customer())

            item = {'PAD': pad_name,
                    'status':status, # config api status
                    'level':history.get_push_level(),
                    'description':history.desc,
                    'history_revision': history.history_revision,
                    'status_msg': display_msg,
                    'user': history.request_user,
                    'request_time': str(history.create_time),
                    'pushed_rate':completion_rate}
            if not is_for_customer:
                item.update({'ok_list':ok_list, 'revision':revision})
            if customer is None and username is None: #internal debug call
                pad_id = site_draft.get_pad_id(history.get_push_level()) if site_draft else ''
                item.update({'history_id': str(history.pk),
                    'pad_id':str(pad_id),
                    'action_id': str(history.action),
                    'parsed_status_msg': parsed_msg,
                    'push_result': push_result_item} )
            result_list.append(item)
    except Exception,e:
        #raise APIException(e)
        errors.update({'general': "Failed to retrieve push history. Please contact support center."})

    try:
        cache.set(cache_key, result_list, 3)
    except:
        pass
    return result_list,errors

def validate_contract_shield_or_api_exception(pRequest, opts, edit_type, draft=None):
    """
    if draft is in edit mode, it does not need to validate contract or shield
    :param opts:
    :param draft:
    :return:
    """
    from ci.common.models.customer import Product
    from ci.common.models.cache import ShieldedService
    contract_no = opts.get('product')
    contract_no = padded_cop_product_id(contract_no)

    shield_id = opts.get('shield_location')
    product = None

    #if draft is not new, product parameter will be popped before this.
    if draft:
        if draft.is_new(): #draft.is_self_implementable(): #draft change call
            try:
                if draft.product:
                    product = draft.product
                else:
                    if contract_no:
                        product = Product.objects.get(cop_product_id=contract_no)
                if product and product.cop_product_id not in pRequest.session['aurora_restrict_items']:
                    raise APIException("Insufficient product access right.", status=400)
            except Product.DoesNotExist:
                raise APIException("Invalid product supplied.", status=400)
        else:
            product = draft.product

    else: #draft create call
        if is_draft_add_request(edit_type):
            if contract_no is not None and contract_no != '':
                try:
                    product = Product.objects.get(cop_product_id=contract_no)
                    if product.cop_product_id not in pRequest.session['aurora_restrict_items']:
                        raise APIException("Insufficient product access right.", status=400)
                except Product.DoesNotExist:
                    raise APIException("Invalid product supplied.", status=400)

                if product and product.is_dwa_contract():
                    if opts.has_key('copy_settings_from'):
                        if opts.has_key('shield_location'):
                            opts.pop('shield_location')

                    shield_service = None
                    if shield_id is None or shield_id == '':
                        if not opts.has_key('copy_settings_from'):
                            raise APIException("Shield input missing.", status=400)
                    else:
                        if not product.is_self_implementable():
                            raise APIException("Contract is not self implementable.", status=400)
                        try:
                            shield_service = ShieldedService.objects.get(pk=int(shield_id))
                        except:
                            raise APIException("Invalid shield supplied.", status=400)
                    if shield_service:
                        validated = product.validate_shield_locations(shield_id)
                        if not validated:
                            raise APIException("Invalid shield info supplied.", status=400)
                else:
                    try:
                        opts.pop('shielded_service')
                    except:
                        pass

    return product

def render_add_duplicate_form(pRequest, opts, draft, site, site_obj, product= None):
    """
    dup_form is only generated when request has key 'copy_settings_from'
    :param pRequest:
    :param opts:
    :param draft:
    :param site:
    :param site_obj:
    :return:
    """
    is_add_request = False
    dup_form = None
    opts_set = set(opts)
    customer = get_customer(pRequest)
    if draft is None and (site_obj is None or site_obj.pk is None): #add
        #This is an add so there is a minimum set of fields that must be set!
        #first see if it is a duplicate...
        is_add_request = True
        if opts.has_key('copy_settings_from'):
            if not site:
                cached_drafts = get_allowed_drafts(pRequest)
                copy_draft = get_draft_or_api_exception(pRequest, opts.get('copy_settings_from'),
                                                        message="Invalid draft site supplied to copy_settings_from parameter",
                                                        drafts=cached_drafts)
                site_set = cached_drafts.values_list('id','pad')
                #site_set = [(d.id, d.pad) for d in get_allowed_drafts(pRequest)]
            else:
                cached_sites = get_allowed_sites(pRequest)
                copy_draft = get_site_or_api_exception(pRequest, opts.get('copy_settings_from'),
                                                       message="Invalid site supplied to copy_settings_from parameter",
                                                       sites=cached_sites)
                site_set = cached_sites.values_list('id','pad')
                #site_set = [(d.id, d.pad) for d in get_allowed_sites(pRequest)]

            opts.pop('copy_settings_from') #remove so we know we used it...
            opts_set = set(opts)
            if product:
                dup_form = DuplicateForm(data={'copy_settings_from': copy_draft.id,
                                               'pad': opts.get('pad'),
                                               'product': product.pk,
                                               'customer':customer},
                                     site_set=site_set, site=site, is_api_call=True, dup_request=True)
            else:
                dup_form = DuplicateForm(data={'copy_settings_from': copy_draft.id,
                                               'pad': opts.get('pad'),
                                               'customer':customer},
                                     site_set=site_set, site=site, is_api_call=True, dup_request=True)

    return is_add_request, dup_form, opts_set

def validate_opts(opts, site, draft):
    if not site: #customer draft request
        valid_opts = SiteDraft.cui_editable_fields + getFieldsFromFieldset(SiteDraft.cui_stat_fields)
        valid_opts += ('product','shield_location',)
    else:
        valid_opts = SiteForm.Meta.fields + ('customer',)
    if not draft:
        valid_opts += ('pad',)

    opts_set = set(opts)
    invalid_opts = opts_set.difference(valid_opts)
    if len(invalid_opts) > 0:
        raise APIException("Invalid parameters in request: " + ",".join(invalid_opts))
    return opts

def render_form_from_model(customer, aurora_user_id, form_model, dup_form_validated, opts, dup_form,
                           site, draft, site_obj, edit_type, shield_location, product):
    """
    draft can be created if duplicate request. form is APIGeneratedForm
    :param pRequest:
    :param form_model:
    :param dup_form_validated:
    :param opts:
    :param dup_form:
    :param site:
    :param draft:
    :param site_obj:
    :param edit_type:
    :return:
    """
    form = create_api_modelform(form_model, set(opts))
    if dup_form_validated: #copy settings from and add request
        temp_form = form(data=opts, instance=None, is_api=True, dup_request=True)
        if site or temp_form.is_valid():
            #for site can't get is_valid on empty instance...
            #assume this is closest we can get to gaurantee passing....have error handling if somehow this passes and with draft it fails...
            if not site:
                draft = dup_form.save() #create duplicate form...

                save_draft_creator(draft, aurora_user_id)
            else:
                site_obj = dup_form.save()
            if not site:
                form = form(data=opts, instance=draft, is_api=True, dup_request=True)
            else:
                form = form(data=opts, instance=draft if draft != None else site_obj, site=site_obj, draft=draft,
                            edit_type=edit_type, is_api=True, dup_request=True, shield_location=shield_location, product=product)
        else:
            form = temp_form
            dup_form = None
    else:
        if not site: #draft request
            if is_draft_add_request(edit_type):
                contract_no = opts.get('product',None)
                if contract_no is not None and contract_no != '':
                    try:
                        from ci.common.models.customer import Product
                        product = Product.objects.get(cop_product_id=padded_cop_product_id(contract_no))
                    except Product.DoesNotExist:
                        raise APIException("Invalid contract supplied.", status=400)

                    form = form(data=opts, instance=draft, customer=customer, product=product, is_api=True)
                else:
                    form = form(data=opts, instance=draft, customer=customer, product=product, is_api=True)
            else:
                form = form(data=opts, instance=draft, customer=customer, product=product, is_api=True)
        else: #this could be draft add request which is not duplicate call or site edit request
            # if not pad:
            form = form(data=opts, instance=draft if draft != None else site_obj, site=site_obj, draft=draft, edit_type=edit_type, is_api=True)
            # else:
            #     assert False, opts
                # form_data =

    return form, dup_form, draft, site_obj

def render_message_details(draft, site, dup_form_validated, pad, product=None, request_implement=False):
    details = ''
    if draft is None and not site: #draft create request which is not duplicate call, if duplicate call, draft is created.
        if product and product.is_self_implementable():
            details = "PAD has been created and is self implementable. You can go ahead with staging push, for which please refer to API manual."
        else:
            if request_implement:
                details = "PAD has been created and implementation has been requested."
            else:
                details = "PAD has been created but implementation has not been requested. You can use request implement api, for which please refer to API manual."
    else:
        if dup_form_validated and not site:
            if draft.is_self_implementable():
                details = "PAD has been copied. The PAD is self implementable. You can go ahead with staging push, for which please refer to API manual."
            else:
                if request_implement:
                    details = "PAD has been copied and implementation has been requested"
                else:
                    details = "PAD has been copied but implementation has not been requested. You can use request implement api, for which please refer to API manual."
        elif not site: #draft change request
            if draft.is_self_implementable():
                #if draft.local_changes(): if not published, there is not site to compare
                details = "PAD changes have been applied. The PAD is self implementable. You can go ahead with staging push, for which please refer to API manual."
                #else:
                #    details = "PAD edit is done but no changes."
            else:
                if request_implement:
                    details = "PAD changes have been applied and implementation has been requested"
                else:
                    details = "PAD changes have been applied but implementation has not been requested. You can use request implement api, for which please refer to API manual."
        elif site and dup_form_validated: #production pad copy request
            details = "PAD has been copied"
        elif site and not pad:
            details = "PAD has been created"
        elif site and pad:
            details = "PAD has been edited"
    return details

PAD_EDIT_TYPE = ['new draft', 'changed draft', 'new site', 'normal_api']
def is_draft_add_request(edit_type):
    return edit_type == PAD_EDIT_TYPE[0]

def is_draft_change_request(edit_type):
    return edit_type == PAD_EDIT_TYPE[1]

def is_site_add_request(edit_type):
    return edit_type == PAD_EDIT_TYPE[2]

def is_site_change_request(edit_type):
    return edit_type == PAD_EDIT_TYPE[3]

def send_draft_implementation_mail(pRequest, changed_draft, request_implement=True):
    from ci.django_mailer.models import REQUEST_PAD,CANCEL_REQUEST_PAD
    try:
        subject = 'PAD implementation request (API)'
        comments = changed_draft.misc_comment
        event_id= REQUEST_PAD if request_implement else CANCEL_REQUEST_PAD
        worker_email = pRequest.user.email if not pRequest.session.get('aurora_user_id') else pRequest.session.get('aurora_user_id')
        send_implementation_email(subject, comments, changed_draft, urgent=False, worker_email=worker_email, event_id=event_id)
        return True, ""
    except:
        return False, "Fail to send PAD implementation request confirmation email."

def site_add_or_edit(pRequest, opts, pad, site=False):
    """General interface for modifying an existing pad or create a new PAD

    @pRequest = Request object in order to look at user object
    @opts = dictionary of passed options
    @pad if pad == None then this is an add, otherwise it is an edit of that pad name
    @site if site == True then this is a production domain addition

    returns tuple as follows: 
    0:    completion message if applicable or None if did not complete task
    1:    dictionary, if not empty is a list of error messages, if empty no errors found
    """
    errors = {}
    dup_form = None
    opts_set = set(opts)
    site_obj=None
    request_implement = True
    if opts.has_key('request_implement'):
        request_implement = opts.get('request_implement')
        opts.pop('request_implement')

    include_inactive = False
    if opts.has_key('restore_deleted'):
        include_inactive = opts.get('restore_deleted')
        opts.pop('restore_deleted')
    aurora_user_id = pRequest.session.get('aurora_user_id','')
    if not site:
        draft = get_draft_or_api_exception(pRequest, pad, message="Invalid site supplied to edit") if pad else None
        if draft:
            if not draft.is_modifiable():
                errors['general'] = "Unable to modify. PAD is currently in %s" % draft.get_pad_status()
            if errors:
                return ("", errors)
        edit_type = 'changed draft' if pad else 'new draft'
        form_model = get_EditPadForm(editable_fields=SiteDraft.cui_editable_fields if not draft else SiteDraft.cui_editable_fields+('pad',)).__class__
    else:
        draft = None
        if not opts.has_key('customer_id') and not pad:
            raise APIException("Following parameters are required to add a site: customer_id")
        customer = Customer.objects.get(pk=opts.pop('customer_id')[0]) if not pad else None
        site_obj = get_site_or_api_exception(pRequest,
                                             pad,
                                             include_inactive=include_inactive,
                                             message="Invalid site supplied to edit") if pad else Site(customer=customer)
        edit_type = 'normal_api' if pad else 'new site'
        form_model = SiteForm
        if not pad and customer.cdnetworks_customer:
            site_obj.cdnw = True
    if draft == None and (site_obj == None or site_obj.pk == None):
        #This is an add so there is a minimum set of fields that must be set!
        
        #first see if it is a duplicate...
        if opts.has_key('copy_settings_from'):
            if not site:
                cached_drafts =  get_allowed_drafts(pRequest)
                copy_draft = get_draft_or_api_exception(pRequest, opts.get('copy_settings_from'),message="Invalid draft site supplied to copy_settings_from parameter")
                site_set = cached_drafts.values_list('id','pad')                
                #site_set = [(d.id, d.pad) for d in get_allowed_drafts(pRequest)]
            else:
                cached_sites = get_allowed_sites(pRequest)
                copy_draft = get_site_or_api_exception(pRequest, opts.get('copy_settings_from'),message="Invalid site supplied to copy_settings_from parameter")
                site_set = cached_sites.values_list('id','pad')            
                #site_set = [(d.id, d.pad) for d in get_allowed_sites(pRequest)]
            opts.pop('copy_settings_from') #remove so we know we used it...
            opts_set = set(opts)
            dup_form = DuplicateForm(data={'copy_settings_from': copy_draft.id, 'pad': opts.get('pad')}, site_set=site_set, site=site, is_api_call=True)
        if dup_form and dup_form.is_valid():
            pass #we will handle saving it later after more error detection...
        else: 
            if dup_form:
                for item, value in dup_form.errors.items():
                    if item == "__all__":
                        item = "duplicate"
                    errors[item] = value.as_text()
                return (None, errors)
            #not a duplicate creation so verify minimum set for creating a pad.
            required_fields = set((name if f.required == True and f.initial == None else None) for name,f in form_model.base_fields.items() )
            required_fields.remove(None)
            missing_opts = required_fields.difference(opts_set)
            if len(missing_opts) > 0:
                raise APIException("Following parameters are required to add a site: " + ", ".join(missing_opts))
    if not site:
        valid_opts = SiteDraft.cui_editable_fields + getFieldsFromFieldset(SiteDraft.cui_stat_fields)
    else:
        valid_opts = SiteForm.Meta.fields + ('customer',)
    if not draft:
        valid_opts += ('pad',)
    opts_set = set(opts)
    invalid_opts = opts_set.difference(valid_opts)
    if len(invalid_opts) > 0:
        raise APIException("Invalid parameters in request: " + ",".join(invalid_opts))
    form = create_api_modelform(form_model, set(opts))
    if dup_form and dup_form.is_valid():
        temp_form = form(data=opts, instance=None)
        if site or temp_form.is_valid():
            #for site can't get is_valid on empty instance...
            #assume this is closest we can get to gaurantee passing....have error handling if somehow this passes and with draft it fails...
            if not site:
                draft = dup_form.save() #create duplicate form...
                save_draft_creator(draft, aurora_user_id)
            else:
                site_obj = dup_form.save()
            if not site:
                form = form(data=opts, instance=draft)
            else:
                form = form(data=opts, instance=draft if draft != None else site_obj, site=site_obj, draft=draft, edit_type=edit_type)
        else:
            form = temp_form
            dup_form = None
    else:
        if not site:
            form = form(data=opts, instance=draft)
        else:
            # if not pad:
            form = form(data=opts, instance=draft if draft != None else site_obj, site=site_obj, draft=draft, edit_type=edit_type)
            # else:
            #     assert False, opts
                # form_data =
    if form.is_valid():
        if not site:
            changed_draft = form.save(commit=False)
            changed_draft.approval_pending=True if not site else False
            if not changed_draft.customer_id:
                changed_draft.customer = get_customer(pRequest)
            if pad and changed_draft.customer.default_log_format:
                changed_draft.request_log_msg_format = changed_draft.customer.default_log_format
            if changed_draft.is_modifiable():
                if changed_draft.is_self_implementable():
                    errors['general'] = "Not supported. PAD is self implementable. Please use v2 version api."
                else:
                    change_comment = ""
                    changed_draft.approval_pending = request_implement
                    changed_draft.save_as_modified()
                    save_draft_creator(changed_draft, aurora_user_id)
                    if request_implement:
                        change_comment = "PAD implementation requested."
                        mail_sent, error = send_draft_implementation_mail(pRequest, changed_draft)
                        if not mail_sent:
                            change_comment = error
                    save_site_change_history(sitedraft=SiteDraft.objects.get(pk=changed_draft.pk),
                                             username=aurora_user_id,
                                             ops_type=1 if draft else 0,
                                             description=change_comment)
            else:
                errors['general'] = "PAD is currently in %s" % changed_draft.get_push_status()

        else:            
            changed_site = form.save(customer_id = customer.id if customer else site_obj.customer.id)
            # Log changes since this is a production call
            change_row  = PADChangeTime(site=changed_site, user=pRequest.user, comment=form.cleaned_data.get('change_comment'))
            change_row.save()
            log_pad_change(change_row, changed_site, form.cleaned_data, form_fields=form.fields)
            
        if draft == None and not site:
            if request_implement:
                details = "PAD has been created and implementation has been requested."
            else:
                details = "PAD has been created but implementation has not been requested. You can use request implement api, for which please refer to API manual."
        else:
            if dup_form and dup_form.is_valid() and not site:
                if request_implement:
                    details = "PAD has been copied and implementation has been requested."
                else:
                    details = "PAD has been copied but implementation has not been requested. You can use request implement api, for which please refer to API manual."
            elif not site:
                if request_implement:
                    details = "PAD changes have been applied and implementation has been requested."
                else:
                    details = "PAD changes have been applied but implementation has not been requested. You can use request implement api, for which please refer to API manual."
            elif site and dup_form and dup_form.is_valid():
                details = "PAD has been copied"
            elif site and not pad:
                details = "PAD has been created"
            elif site and pad:
                details = "PAD has been edited"
        if errors:
            details = "Not valid request."
        return (details, errors)
    else:
        for item, value in form.errors.items():
            if item == "__all__":
                item = "general"
            errors[item] = value.as_text()
        result = "PAD has been copied but could not edit settings besides PAD name. Please submit a follow-up edit request" if dup_form and dup_form.is_valid() else None
        return (result, errors)

def site_add_or_edit_v2(pRequest, opts, pad, site=False):
    """General interface for modifying an existing pad or create a new PAD

    @pRequest = Request object in order to look at user object
    @opts = dictionary of passed options
    @pad if pad == None then this is an add, otherwise it is an edit of that pad name
    @site if site == True then this is a production domain addition

    returns tuple as follows:
    0:    completion message if applicable or None if did not complete task
    1:    dictionary, if not empty is a list of error messages, if empty no errors found
    """
    errors = {}
    dup_form = None
    opts_set = set(opts)
    site_obj=None
    shield_location = opts.get('shield_location', None)
    aurora_user_id = pRequest.session.get('aurora_user_id','')
    request_implement = False
    if opts.has_key('request_implement'):
        request_implement = opts.get('request_implement')
        opts.pop('request_implement')
    if not site:
        site_obj=None
        customer = get_customer(pRequest)
        draft = get_draft_or_api_exception(pRequest, pad, message="Invalid site supplied to edit") if pad else None
        if draft and not draft.is_modifiable():
            errors['general'] = "PAD is currently in %s" % draft.get_pad_status()
            return ("", errors)

        edit_type = 'changed draft' if draft else 'new draft'
        product = validate_contract_shield_or_api_exception(pRequest, opts, edit_type, draft)
        dup_request = False
        if opts.has_key('copy_settings_from'):
            dup_request = True

        if product:
            if not product.is_ssl_contract():
                if opts.has_key('upstream_ssl'):
                    opts.pop('upstream_ssl')
                if opts.has_key('enable_ssl'):
                    opts.pop('enable_ssl')
            if not product.is_dwa_contract():
                if opts.has_key('shield_location'):
                    opts.pop('shield_location')
                    shield_location = None
            else:
                if dup_request:
                    if opts.has_key('shield_location'):
                        opts.pop('shield_location')
                        shield_location = None

            form_model = get_EditPadForm(instance=draft, material_no_list=[product.product_cd],
                                         editable_fields=get_editable_fields(draft),
                                         customer=customer, product=product, shield_location=shield_location,
                                         is_api=True, dup_request=dup_request).__class__
        else:
            if opts.has_key('upstream_ssl'):
                opts.pop('upstream_ssl')
            if opts.has_key('enable_ssl'):
                opts.pop('enable_ssl')
            if customer.get_active_contracts().exists():
                if customer.has_request_implementation_product():
                    if opts.has_key('product'):
                        opts.pop('product')
                    if opts.has_key('shield_location'):
                        opts.pop('shield_location')
                    form_model = get_EditPadForm(instance=draft, editable_fields=get_editable_fields(draft),
                                                 customer=customer, is_api=True, dup_request=dup_request).__class__
                else:
                    raise APIException("You have self implementable contract. please input contract info as product field. ")
            else:
                raise APIException("You have no available contracts. Please contact support center to proceed.")
    else: #for operator: internal use only
        product = None
        if not opts.has_key('customer_id') and not pad:
            raise APIException("Following parameters are required to add a site: customer_id")
        customer = Customer.objects.get(pk=opts.pop('customer_id')[0]) if not pad else None
        site_obj = get_site_or_api_exception(pRequest, pad, message="Invalid site supplied to edit") if pad else Site(customer=customer)
        draft = None

        edit_type = 'normal_api' if site_obj else 'new site'
        form_model = SiteForm
        if not pad and customer.cdnetworks_customer:
            site_obj.cdnw = True

    dup_form_validated = False
    is_add_request, dup_form, opts_set = render_add_duplicate_form(pRequest,opts,draft,site,site_obj, product)
    if is_add_request:
        if dup_form and dup_form.is_valid():
            dup_form_validated = True #we will handle saving it later after more error detection...
        else:
            if dup_form: #return errors since dup_form is not validated.
                for item, value in dup_form.errors.items():
                    if item == "__all__":
                        item = "duplicate"
                    errors[item] = value.as_text()
                return (None, errors)

            #not a duplicate creation so verify minimum set for creating a pad.
            required_fields = set((name if f.required and f.initial == None else None)
                                  for name,f in form_model.base_fields.items() )
            required_fields.remove(None)
            missing_opts = required_fields.difference(opts_set)
            if len(missing_opts) > 0:
                raise APIException("Following parameters are required to add a site: " + ", ".join(missing_opts))

    opts = validate_opts(opts, site, draft)
    if not dup_form_validated:
        dup_form_validated = dup_form and dup_form.is_valid()

    #draft can be created if duplicate request. form is APIGeneratedForm which inherits form_model
    form, dup_form, draft, site_obj = render_form_from_model(customer, aurora_user_id, form_model, dup_form_validated, opts,
                                                               dup_form, site, draft, site_obj, edit_type, shield_location, product)

    if form.is_valid():
        if not site: #draft request
            changed_draft = form.save(commit=False)
            if not changed_draft.customer_id:
                changed_draft.customer = customer
            if pad and changed_draft.customer.default_log_format:
                changed_draft.request_log_msg_format = changed_draft.customer.default_log_format

            if changed_draft.is_modifiable():
                change_comment = ""

                if changed_draft.is_self_implementable():
                    changed_draft.approval_pending = False
                    changed_draft.save_as_modified()
                    save_draft_creator(changed_draft, aurora_user_id)
                else:
                    changed_draft.approval_pending = request_implement
                    changed_draft.save_as_modified()
                    save_draft_creator(changed_draft, aurora_user_id)
                    if request_implement:
                        change_comment = "PAD implementation requested."
                        mail_sent, error = send_draft_implementation_mail(pRequest, changed_draft)
                        if not mail_sent:
                            change_comment = error

                save_site_change_history(sitedraft=SiteDraft.objects.get(pk=changed_draft.pk),
                                         username=aurora_user_id,
                                         ops_type=1 if draft else 0,
                                         description=change_comment)
            else:
                errors['general'] = "PAD is currently in %s" % changed_draft.get_push_status()
        else:
            changed_site = form.save(customer_id = customer.id if customer else site_obj.customer.id)
            # Log changes since this is a production call
            change_row  = PADChangeTime(site=changed_site, user=pRequest.user, comment=form.cleaned_data.get('change_comment'))
            change_row.save()
            log_pad_change(change_row, changed_site, form.cleaned_data, form_fields=form.fields)

        details = render_message_details(draft, site, dup_form_validated, pad, product, request_implement)
        return (details, errors)
    else:
        for item, value in form.errors.items():
            if item == "__all__":
                item = "general"
            errors[item] = value.as_text()
        result = "PAD has been copied but could not edit settings besides PAD name.  Please submit a follow-up edit request" \
            if dup_form and dup_form.is_valid() else None
        return (result, errors)


def get_trace_route(hostname, post_data, extra_headers=None, filename=None, file_contents=None):
    browser = Browser()
    #cookie = get_cs_auth_cookie(hostname)
    cookie = make_cookie(10000, hostname)
    #post_data = [('url','aadddde'),('header','adddd')]
    request = Request(url="https://%s/trace_internal" % (hostname),
                      post=post_data,
                      cookie=cookie,
                      multipart=True,
                      extraheaders=extra_headers,
                      filename=filename,
                      file_contents=file_contents)
    resp = browser.request(request)
    return resp

def get_trace_parsed_content(lines, hostname=None):
    """
    parse curl response resp.response
    :param resp: curl response object
    :return:
    """
    from ci.common.utils.misc import short_hostname
    REQUEST_PHRASE_START_LIST = ["receive request from","receive (https) request from"]
    REQUEST_PHRASE_END = "request was for pad"
    RESPONSE_STRART_PHRASE = "response sent to browser"
    REQUEST_PARSE_PHRASE_LIST = ['request is for pad','applying id','initial url','origin url']
    result_list = []
    response_started = False
    request_started = False
    need_request_processing = False
    header_skip_count = 0
    if hostname:
        hostname = short_hostname(hostname)
    for line in lines:
        if line.strip().lower().startswith(REQUEST_PHRASE_END):
            need_request_processing = False
        if hostname:
            line = line.replace(hostname, "*******")
        if need_request_processing:
            if header_skip_count > 1:
                result_list.append(line.strip())
                result_list.append('\n')
            header_skip_count += 1

        if line.strip().lower().startswith(RESPONSE_STRART_PHRASE):
            response_started = True
        if request_started:
            result_list.append(" " + line.strip())
            result_list.append('\n')
            request_started = False

        for phrase in REQUEST_PARSE_PHRASE_LIST:
            if line.strip().lower().startswith(phrase):
                result_list.append(line.strip())
                request_started = True
                break

        if response_started:
            result_list.append('\n')
            result_list.append(line.strip())
            if line.strip().lower().startswith(RESPONSE_STRART_PHRASE): #let's make lines pretty
                result_list.append("\n")

        for phrase in REQUEST_PHRASE_START_LIST:
            if line.strip().lower().startswith(phrase):
                need_request_processing = True
                break

    return "".join(result_list)

def trace_internal_request(hostname, postdata, extra_headers,filename, file_contents):
    """
    need to apply cache logic but not easy to generate cache key with md5key.
    let's cache only when file contents is none and extra_headers are none
    :param hostname:
    :param postdata:
    :param extra_headers:
    :param filename:
    :param file_contents:
    :return:
    """
    result = ''
    error = ''
    try:
        if extra_headers is None and file_contents == '':
            result = cache.get(get_cache_key(hostname, postdata))
            if result is not None:
                return result, result
    except:
        pass

    resp = get_trace_route(hostname=hostname, post_data=postdata, extra_headers=extra_headers,
                           filename=filename, file_contents=file_contents)
    if resp.error_code != '' or resp.status_code != 200:
        result = resp.get_error_message_for_customer()
        error=result
    else:
        result = get_trace_parsed_content(resp.response, hostname)
    try:
        if extra_headers is None and file_contents == '':
            cache_key = get_cache_key(hostname, postdata)
            cache.set(cache_key,result, 5)
    except:
        pass
    return error, result, resp.raw_content

def get_cache_key(hostname, postdata):
    try:
        source_string = "%s%s" % (hostname, cPickle.dumps(postdata, cPickle.HIGHEST_PROTOCOL))
        cache_key = hashlib.md5(source_string.encode('utf-8')).hexdigest()
        return cache_key
    except Exception,e:
        return None
