class APIParameter():
	valid_types = ('Boolean','Integer','String','DateTime','ValueList')
	def __init__(self, name, type, description, multiple, values=None, field=None, default_behavior="Not Applied"):
		if not type in valid_types:
			raise APIException("Invalid parameter type", status=400)
		if type == 'ValueList':
			if values == None:
				raise APIException("ValueList type requires a list of values supplied")
			self.values = values
		else:
			self.values = None
		if model_field == None:
			self.field = name
		else:
			self.field = field
		self.name = name
		self.type = type
		self.multiple = (multiple == True)
		self.default_behavior = default_behavior

def model_to_api_parameters(model, fields):
	"""Takes in a form and returns list of the APIParameter accepted"""
	model_to_api_type = {
		CharField: 'String',
		BooleanField: 'Boolean',
		IntegerField: 'Integer',
		TypedChoiceField: 'ValueList',
		DateTimeField: 'DateTime',
	}
	params = []
	for field_name in fields:
		field = model._meta.get_field(field_name)
		params.append(APIParameter(field_name, formToRestType.get(type(field),'String'), field.help_text, False, values = field.choices))
	return params

def cdn_site_list_req():
	pass
def cdn_site_list_opt():
	pass

def cdn_content_expire_req():
	return (APIParameter('type','ValueList',
		'Type of expiration of content to issue.',True,
		values=(("all","Will flush all content for the PAD"),
			("wildcard","Will do a wildcard flush for the provided path(s)"),
			('uri',"Will do a flush on the specified path(s)"),),
		),
		APIParameter('pad','String','The hostname of the PAD to issue the flush for'),
	)

def cdn_content_expire_opt():
	return (APIParameter('path','String',"The URL to flush.  This is required for type 'wildcard' and 'uri'.  This is not compatible with 'all'",True),
		APIParrameter('ims','Boolean',"If set to True, will do a 'soft flush' resulting in an If-Modified-Since request sent to origin. This is not compatible with type 'uri'", False, default_behavior="False"),
	)
