from django.db import models
from ci.common.models.cdn import Node, Service
from ci.common.models.cache import *
from ci.common.models.legacy_shield import *
from ci.common.utils.fields import SimpleIntermediateM2MField
from ci.common.utils.functional import assocLookup, concat, intercalate
from django.db import connection, transaction
from datetime import *
import random
from MySQLdb import IntegrityError

# fill new data model from old data model

# must be executed within a single transaction (not auto-commit)
def fillNewBandModelFromOldPopShieldModel():
	(keptHashpoints, keptBandNodes, keptDomainBands, keptShieldedServiceBands) = emptyNew()
	(popBand, instBand) = fillBandsFromCacheInstances()
	for x in keptHashpoints:
		try:
			x.save()
		except IntegrityError:
			pass  # kept data is duplicate of converted data, ignore
	for x in keptBandNodes:
		try:
			x.save()
		except IntegrityError:
			pass  # kept data is duplicate of converted data, ignore
	maxId = fillDomainBandsAndPadsFromServicePops(popBand)
	if maxId >= 2 ** 16:
		raise UnsupportedConfiguration ('a service id >= 2 ** 16')
	for x in keptDomainBands:
		try:
			x.save()
		except IntegrityError:
			pass  # kept data is duplicate of converted data, ignore
	shieldsFromCacheGroups(instBand)
	for x in keptShieldedServiceBands:
		try:
			x.save()
		except IntegrityError:
			pass  # kept data is duplicate of converted data, ignore

class UnsupportedConfiguration(Exception):
	def __init__(self, value):
		self.value = value
	def __str__(self):
		return repr(self.value)

def emptyNew():
	"Clear data in new model. use direct SQL so shielded_service delete won't cascade delete customer_site! plus it is much faster"
	"Don't delete records that were create by a user (as opposed to generated from old model), we can tell this because a generated record either has a name starting with 'Derived: ' or a join_time = '2001-01-01 00:00:00'"
	# cursor.execute("delete from node_hashpoint where join_time = '2000-01-01 00:00:00'")
	# cursor.execute("delete from band_node where join_time = '2000-01-01 00:00:00'")
	# cursor.execute("delete from cdndomain_band where join_time = '2000-01-01 00:00:00'")
	# cursor.execute("delete from shielded_service_band where join_time = '2000-01-01 00:00:00'")
	# cursor.execute("delete from band where name like 'Derived: %'")
	# cursor.execute("delete from shielded_service where name like 'Derived: %'")
	cursor = connection.cursor()
	#why do we delete all kept points and then delete everything...seems like it accomplishes nothing
	keptHashpoints = NodeHashpoint.objects.exclude (join_time = datetime(2000,1,1))
	for x in keptHashpoints:
		x.delete()
	cursor.execute("delete from node_hashpoint")
	
	keptBandNodes = BandNode.objects.exclude (join_time = datetime(2000,1,1))
	for x in keptBandNodes:
		x.delete()
	cursor.execute("delete from band_node")
	
	keptDomainBands = CdnDomainBand.objects.exclude (join_time = datetime(2000,1,1))
	for x in keptDomainBands:
		x.delete()
	cursor.execute("delete from cdndomain_band")
	
	keptShieldedServiceBands = ShieldedServiceBand.objects.exclude (join_time = datetime(2000,1,1))
	for x in keptShieldedServiceBands:
		x.delete()
	cursor.execute("delete from shielded_service_band")
	
	cursor.execute("delete from band where name like 'Derived: %%'")
	cursor.execute("delete from shielded_service where name like 'Derived: %%'")
	transaction.set_dirty()
	return (keptHashpoints, keptBandNodes, keptDomainBands, keptShieldedServiceBands)

def fillBandsFromCacheInstances():
	popBand = {}
	instBand = {}
	for inst in Cache_Instance.objects.all():
		band = Band (id = 0 - inst.id, name = 'Derived: ' + inst.name())
		band.save()
		nodePoints = {}
		for frag in inst.fragments():
			points = nodePoints[frag.node] if nodePoints.has_key(frag.node) else []
			points.append(float(frag.bucket_min - 1)/100)
			nodePoints[frag.node] = points
		for node, points in nodePoints.items():
			node_ip = NodeIP.objects.get (node = node, seq_num = 0)
			bn = BandNode (band = band, node = node, node_ip = node_ip, join_time = datetime(2000, 1, 1))
			bn.save()
			if len(node.nodehashpoint_set.select_related()) > 0:
				raise UnsupportedConfiguration (node.name() + ' in more than one instance')
			for h in points:
				nh = NodeHashpoint (node = node, hashpoint = h, join_time = datetime(2000, 1, 1))
				nh.save()
		pop = inst.mainPop()
		if not popBand.has_key(pop) or len(popBand[pop].members()) < len(band.members()):
			popBand[pop] = band		# pop's canonical band is its largest cache instance
		instBand[inst] = band
	return (popBand, instBand)

def fillDomainBandsAndPadsFromServicePops(popBand):
	cursor = connection.cursor()
	maxId = 0
	for service in Service.objects.all():
		# empty shielded service uses -1 * edge service id
		ss = ShieldedService (id = -1 * service.id, service = service, name = 'Derived: ' + service.dns_prefix)
		ss.save()
		for pop in service.pops.select_related():
			db = CdnDomainBand (service = service, band = popBand[pop], join_time = datetime(2000, 1, 1))
			db.save()
		for padId in service.site_set.values_list('id', flat=True):
			cursor.execute("update customer_site set shielded_service_id = %d where customer_site_id = %d and (shielded_service_id is NULL or shielded_service_id < 0)" % (ss.id, padId))
		if maxId < ss.id:
			maxId = ss.id
	transaction.set_dirty()
	return maxId

def shieldsFromCacheGroups(instBand):
	sitegLevelBands = {}		# SiteGroup -> (Id, CacheLevel -> [[Band]])   # list of groups of bands, bands within a group are order by order_num
	for cacheGroup in Cache_Group.objects.filter(site_group__id__gt = 0):
		ugs = cacheGroup.userGroups()
		if len(ugs) == 0: continue
		siteGrp = cacheGroup.site_group
		id, levelBands = sitegLevelBands[siteGrp] if sitegLevelBands.has_key(siteGrp) else (cacheGroup.id, {})
		level = 1 if ugs[0].site_group.id == 0 else 2
		bandss = levelBands[level] if levelBands.has_key(level) else []
		instances = cacheGroup.instance.select_related()
		instances = sorted(instances, key = lambda i: i.id)		# order by id within a group (happens to be correct for Veoh which is the only one with backup shield)
		bands = map (lambda i: instBand[i], instances)
		levelBands[level] = bandss + [bands]
		sitegLevelBands[siteGrp] = (id, levelBands)
	
	cursor = connection.cursor()
	for siteGrp, (id, levelBands) in sitegLevelBands.items():
	# clean up hierarchy which can be a mess in old model
		levelBands = removeDuplicateBands(levelBands)
		pads = []
		pads.extend(siteGrp.site.select_related())
		for service in set (map (lambda pad: pad.service, pads)):
			# usually just 1 service per site group
			# the id for shield needs to be stable, basing it on sitegroup and service
			# negative because autogenerated
			ssid = -1 * ((siteGrp.id << 16) + service.id)
			ss = ShieldedService (id = ssid, service = service, name = ('Derived: ' + service.dns_prefix + ' + shield for ' + siteGrp.name)[:50])
			ss.save()
			for level, bandss in levelBands.items():
				for g in range (0, len(bandss)):
					bands = bandss[g]
					for o in range (0, len(bands)):
						band = bands[o]
						print "Shielded Service: [%d], level [%d], g [%d], o [%d]" % (ssid, level, g, o)
						slb = ShieldedServiceBand (shielded_service = ss, cache_level = level, band = band, region = g, order = o, join_time = datetime(2000, 1, 1))
						slb.save()
			for pad in filter (lambda p: p.service == service, pads):
				# avoid pad.save() because it involves site draft
				cursor.execute("update customer_site set shielded_service_id = %d where customer_site_id = %d and (shielded_service_id is NULL or shielded_service_id < 0)" % (ss.id, pad.id))
	transaction.set_dirty()

def removeDuplicateBands(levelBands):
	newLevelBands = {}
	for level, bandss in levelBands.items():
		newLevelBands[level] = removeDuplicates(bandss)
	return newLevelBands

def removeDuplicates(bandss):
	"if the same band exists in two different groups remove from smaller group"
	"duplicates only happen on veoh shield because primary band is repeated in two different groups"
	bandss = sorted (bandss, key = lambda bands: len(bands), reverse = True)
	allBands = set([])
	newBandss = []
	for bands in bandss:
		newBands = []
		for band in bands:
			if band not in allBands:
				newBands.append(band)
				allBands.add(band)
		newBandss.append(newBands)
	return newBandss


# add random points for each node in a band so they each have n points (add nothing if node already has n or greater). Set preheat time of new points to x days

def addBandHashpoints (band, totalPointsPerNode, preheatDays):
	for node in band.nodes.all():
		addNodeHashpoints (node, totalPointsPerNode, preheatDays)

def addNodeHashpoints (node, totalPoints, preheatDays):
	n = len(node.hashpoints())
	preheatDone = datetime.now() + timedelta(preheatDays)
	for i in range(n, totalPoints):
		point = random.random()
		nh = NodeHashpoint (node = node, hashpoint = point, join_time = preheatDone)
		nh.save()

