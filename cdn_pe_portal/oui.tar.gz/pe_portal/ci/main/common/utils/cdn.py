
from django.core.cache import cache
from ci.common.models.cdn import Node, Pop, Service
from ci.common.models.cache import Band

#These get_all_* functions don't do anything useful with cache

def get_all_bands():
	"""convience function to get a queryset of all bands, caching the result."""
	bands_query = cache.get('all_bands_query')
	if not bands_query:
		bands = Band.objects.all()
		cache.set('all_bands_query', bands.query, 300)
	else:
		bands = Band.objects.all()
		bands.query = bands_query
	return bands

def get_all_pops():
	"""convenience function to get a queryset of all pops, caching the result."""
	pops_query = cache.get('all_pops_query')
	if not pops_query:
		pops = Pop.objects.filter(importance__gt=-1)
		# cache the query property, not the set itself, because the latter is not pickle-able
		cache.set('all_pops_query', pops.query, 300)
	else:
		pops = Pop.objects.filter(importance__gt=-1)
		pops.query = pops_query
	return pops

def get_all_nodes():
	"""convenience function to get a queryset of all nodes, caching the result."""
	nodes_query = cache.get('all_nodes_query')
	if not nodes_query:
		nodes = Node.objects.filter(pop__importance__gt=-1)
		# cache the query property, not the set itself, because the latter is not pickle-able
		cache.set('all_nodes_query', nodes.query, 300)
	else:
		nodes = Node.objects.filter(pop__importance__gt=-1)
		nodes.query = nodes_query
	return nodes

def get_all_services():
	"""convenience function to get a queryset of all services, caching the result."""
	services_query = cache.get('all_services_query')
	if not services_query:
		services = Service.objects.filter(status=True)
		cache.set('all_services_query', services.query, 300)
	else:
		services = Service.objects.filter(status=True)
		services.query = services_query
	return services


def CheckOOS(pop):
	single_service = []
	service_objs = pop.services()
	for obj in service_objs:
		pops = obj.pop_set()
		if len(pops) == 1 and pop in pops:
			single_service.append(obj.name)
	return single_service
