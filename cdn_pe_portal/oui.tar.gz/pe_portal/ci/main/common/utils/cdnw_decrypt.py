"""
This is a wrapper to handle decrypting a string using CDNetworks provided
aquacrypto.  To use this need to compile and put the CDNW_DECRYPT method 
into your working path.

Steps:
1. untar modules/ci/common/resources/aquacrypto.tar
2. run make in the _lib directory
3. run make in the exec directory
4. move the CDNW_DECRYPT into path
"""
import popen2

def decrypt(str):
	"""wrapper to c library to decrypt a key from CDNW encryption"""
	stdout, stdin = popen2.popen2('/usr/local/bin/CDNW_DECRYPT "%s"' %(str))
	stdin.close()
	res = stdout.read()
	stdout.close()
	return res
