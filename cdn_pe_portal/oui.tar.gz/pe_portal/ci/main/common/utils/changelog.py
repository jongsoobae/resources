from datetime import datetime
from ci.common.models.pusher import ChangeLogEntry

class ChangeCommand:
	def pushType(self):
		"""return String code of push type that pushes the type of data I change"""
	def actionDescription(self):
		"""return String describing my type of change but not the object I changed"""
	def objectDescription(self):
		"""return String describing my the object I changed but not what I did to it"""
	def _execute(self):
		"""make my change (within current transaction) and return undo command"""

def executeAndLog(changeCommand, user, description="Not pushed yet", push_user="", pop_id=None, actionDescription=None):
	pushType = changeCommand.pushType()
	changeCommand._execute()
	logEntry = ChangeLogEntry(user=user, pushType=pushType, pushDescription=description, pushUser=push_user, popId=pop_id, actionDescription=actionDescription)
	logEntry.save()
