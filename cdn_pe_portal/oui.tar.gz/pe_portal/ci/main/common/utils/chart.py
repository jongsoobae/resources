from cStringIO import StringIO
import traceback
from datetime import datetime, timedelta
from ci.constants import MAINTAINER
from ci.common.models.customer import Customer
from ci.common.models.cdn import Service, Pop, Node
from ci.common.models.geo import Country, Address, Region
from ci.common.models.chart import Chart, category_options
from ci.common.models.site import Site
from django.template import loader
from django import forms
from django.forms import util, ValidationError
from django.core import urlresolvers
from django.core.cache import cache
from django.http import HttpResponse
from django.utils.encoding import smart_unicode
from django.utils.html import escape
from ci.common.utils.mail import send_email
from ci.common.utils.traffic import round_time_to_epoch
from ci.common.utils.misc import short_hostname
from itertools import chain

dpi = 56

# Default width and height of a Chart image in pixels
default_width=750
default_height=410
no_data_height=200

#these are so the class only needs to be instaniated once w/o always importing matplotlib
yformatter = None
xformatter = None

def getFigure(width, height):
	#Import here so matplotlib is not imported with every page view
	from matplotlib.figure import Figure

	figsize = float(width) / dpi, float(height) / dpi
	return Figure(figsize=figsize)

def draw_chart(fig):
	#Import here so matplotlib is not imported with every page view
	from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas

	rv = StringIO()
	canvas = FigureCanvas(fig)
	canvas.print_figure(rv, dpi=dpi)
	return rv

def create_message_chart(message, width, height):
	#Import here so matplotlib is not imported with every page view
	from matplotlib.axes import Axes
	from matplotlib import text

	fig = getFigure(width, height)
	ax = Axes(fig, rect=[.1, .1, .8, .8])
	fig.add_axes(ax)

	ax.texts.append(
		text.Text(
			width/2, height/2,
			message,
			horizontalalignment='center', verticalalignment='center',
			# Assume a char is half as wide as tall, and set its point size
			# (where 1 pt is 1/72 inches) so that message's width will fit,
			# with 5% margin each side
			fontsize=(0.8 * fig.figwidth.get() * 72.0) / (len(message) * 0.5)
		)
	)

	ax.set_xticks([])
	ax.set_yticks([])
	ax.set_xticklabels([])
	ax.set_yticklabels([])


	ax.grid(True)
	ax.autoscale_view(tight=True, scalex=True, scaley=False)
	ax.autoscale_view(tight=False, scalex=False, scaley=True)

	fig.autofmt_xdate()

	return draw_chart(fig)


def create_chart(serieses, start, end, width, height, minute_interval=5, stacked=True, percentage=False, order=lambda x: x, ylabel = None, xlabel=None, show_axis = True, show_x = True, show_y = True, full_image=False, text_overlay=None,legend=False):
	"""
	Returns the binary contents of a chart image as StringIO
	@param serieses: List of lists of data points.  Each top level list is a group of data, each list of data points is an epoch of data
	@param start:	First epoch of data
	@param end:	Last epoch of data
	@param width:   Width in pixels
	@param height:  Height in pixels
	@param minute_interval: [Optional] This is an integer telling how far apart each epoch is, default is 5minutes
	@param order:	[Optional] function
	@param ylabel:	[Optional] string to be set for y-axis label
	@param xlabel:	[Optional] string to be set for x-axis label
	@param show_axis: [Optional] If false axis times will not be displayed
	@param full_image: [Optional] If true will always have image be full size regardless of items that normally shrink the image size such as show_axis
	@param text_overlay [Optional] If provided, value will be displayed in top left of chart.
	"""
	assert start < end

	if serieses == None or len(serieses) == 0:
		return create_message_chart('No data is available for the selected settings', width, height)

	#Import here so matplotlib is not imported with every page view
	from matplotlib.axes import Axes
	from matplotlib.mlab import poly_between
	
	#This one is because scope issues suck
 	from ci.common.utils.traffic import add_series
	global yformatter
	global xformatter
	if not yformatter:
		#Import here so matplotlib is not imported with every page view
		from matplotlib.ticker import ScalarFormatter
		# Y-axis values
		class ChartronFormatter(ScalarFormatter):
			def __init__(self):
				ScalarFormatter.__init__(self, useOffset=False)
				self.set_scientific(False)

			def pprint_val(self, value):
				s = '%f' % value
				if value == 0:
					return '0.0'
				elif '.' in s:
					rpart  = s.split('.')[1]
					if not rpart.lstrip('0'):
						# value is a whole number
						rv = '%.1f' % value
					else:
						nzeros = len(rpart) - len(rpart.lstrip('0'))
						rv = '%.*f' % (nzeros + 2, value)
				else:

					rv ='%.1f' % value
				return rv
		yformatter = ChartronFormatter

	if not xformatter:
		#Import here so matplotlib is not imported with every page view
		from matplotlib.dates import AutoDateFormatter, DateFormatter
		# X-axis vales
		class TimezonelessFormatter(AutoDateFormatter):
			"""
			Like an AutoDateFormatter, but without timezones.  We can't really
			determine the user's timezone, only its UTC offset.  UTC offsets
			aren't one-to-one with timezones, so we just use the offset and show
			dates as local times without the timezone suffix like DST.
			"""
			def __init__(self, *args, **kwargs):
				AutoDateFormatter.__init__(self, *args, **kwargs)
				self._formatter = DateFormatter("%b %d %Y %H:%M:%S")

			def __call__(self, x, pos=0):
				"""Copy of AutoDateFormatter's code, minus the timezones"""
				scale = float( self._locator._get_unit() )

				if ( scale == 365.0 ):
					self._formatter = DateFormatter("%Y")
				elif ( scale == 30.0 ):
					self._formatter = DateFormatter("%b %Y")
				elif ( (scale == 1.0) or (scale == 7.0) ):
					self._formatter = DateFormatter("%Y-%m-%d")
				else:
					self._formatter = DateFormatter("%Y-%m-%d  %H:%M:%S")

				return self._formatter(x, pos)
		xformatter = TimezonelessFormatter

	fig = getFigure(width, height)

	# left, bottom, width, height
	if show_axis and not full_image:
		rect = [.10,.18,.88,.80]
	else:
		rect = [.0, .0, 1.0, 1.0]

	ax = Axes(fig, rect=rect)
	fig.add_axes(ax)

	heights = previous_heights = None

	for series in order(serieses):
		# Time labels are in local timezone
		left   = [start + timedelta(minutes=minute_interval * i) for i in range(len(series.data))]
		heights = add_series(previous_heights, series.data) if previous_heights else series.data

		if not stacked:
			ax.plot(left, series.data, series.color, label=series.split_by_key)
		else:
			# Stack data by adding this series to the previous
			xs, ys = poly_between(
				left,
				previous_heights or 0,
				heights
			)
			for patch in ax.fill(xs, ys, facecolor=series.color, label=series.split_by_key):
				# Remove the default black border
				patch.set_linewidth(0)

		previous_heights = heights
	if not stacked and not percentage and len(serieses) > 1:
		left   = [start + timedelta(minutes=minute_interval * i) for i in range(len(heights))]
		ax.plot(left, heights, "black", label="Total")

	if ylabel and show_y:
		ax.set_ylabel(ylabel)
	ax.yaxis.set_major_formatter(yformatter())

	if xlabel and show_x:
		ax.set_xlabel(xlabel)
	ax.xaxis.set_major_formatter(xformatter(ax.xaxis.get_major_locator()))

	fig.autofmt_xdate()
	ax.autoscale_view(tight=True, scalex=True, scaley=False)
	ax.autoscale_view(tight=False, scalex=False, scaley=True)

	if text_overlay:
		from matplotlib import text
		ax.texts.append(
			text.Text(position=(5,height-5), text=text_overlay,
				ha='left', va='top',
				fontsize=30))
	if not show_x or not show_axis:
		ax.xaxis.set_visible(False)
	if not show_y or not show_axis:
		ax.yaxis.set_visible(False)

	if not show_x:
		ax.set_xticklabels([])
	if not show_y:
		ax.set_yticklabels([])

	ax.grid(True)

        if full_image:
		#move x labels
		labels = ax.get_xticklabels()
		for label in labels:
			label.set_rotation(90)
			label.set_horizontalalignment('center')
			label.set_verticalalignment('bottom')
			label.set_position((0,.02))
		#move y labels
		labels = ax.get_yticklabels()
		for label in labels:
			label.set_horizontalalignment('left')
			label.set_verticalalignment('center')
			label.set_position((.02,0))
		labels[0].set_verticalalignment('bottom')
		labels[-1].set_verticalalignment('top')

	if legend:
		if full_image:
			ax.legend(loc=9)
		else:
			ax.legend(loc=2)

	return draw_chart(fig)

def _div_body_contents(destination, chart, img_url, serieses, series_totals, extra_context={}, width=default_width, height=default_height, show_legend=True, title=None):
	"""
	@param destination:	     "web", "email", or "embedded" -- where this Chart will be displayed
	@param chart:		   A Chart instance
	@param img_url:		 A string, the url of the Chart's image
	@param serieses:		A sequence of Series objects, first return value of chart.get_serieses()
	@param series_totals:	   A sequence of Series objects, second return value of chart.get_serieses()
	@param extra_context:   Additional data for rendering templates
	@param width:		   Optional width in pixels
	@param height:		  Optional height in pixels
	@param show_legend:	     If True, show a legend
	@param title:		   If set will use this string as the title, otherwise will use chart.make_title()
	@return:				A string, the HTML body of a div displaying the chart
	"""
	assert destination in ("web", "email", "embedded")

	context = dict(
		extra_context,
		chart=chart,
		serieses=serieses,
		series_totals = series_totals,
		chart_image_url=img_url,
		destination=destination,
		show_legend=show_legend,
		title=title if title else chart.make_title(),
		width=width,
		height=height,
		num_format = chart.chart_type_info.num_format,
	)

	return loader.render_to_string(
		{
			'web':	  'chartron_chart_web.html',
			'email':	'chartron_chart_email.html',
			'embedded':     'chartron_chart_embedded.html'
		}[destination],
		context
	)

def LoadChartForm(user, is_cui=False):
	"""
	@param user:    An AuthUser instance
	param cui:	      If True, show CUI saved charts, else OUI saved charts
	@return:	A Django form instance showing user's saved charts
	"""
	class LoadChartFormUser(forms.Form):
		chart = forms.ChoiceField(
			choices	 = ((c.id, c.title) for c in user.chart_set.filter(is_cui=is_cui, is_saved=True).order_by('-create_time')),
			widget	  = forms.Select
		)

	return LoadChartFormUser(auto_id="loadform_%s")


_cached_class = [None, None]
def create_chartron_form_class(reload=False, category=0):
	"""
	This function caches all the Sites, Regions, POPs, etc. in the database
	into a Form class, so we don't have to reload this rarely-changing data
	on each page request
	@param reload:  If True, refresh the cached Sites, Regions, POPs, etc.
	@return:	 A class derived from Form
	"""
	if _cached_class[category] is None or reload:
		class ChartronFormClass(forms.Form):
			start = forms.DateTimeField()
			end = forms.DateTimeField()
			legend_count = forms.IntegerField(min_value=0, label='Legend Lines', widget=forms.TextInput(attrs={'size':2}))
			include_other = forms.BooleanField(required=False, initial=True, label='Include items past legend count as "other"')
			show_stacked = forms.BooleanField(required=False, initial=False, label='Show chart stacked (except percentage charts)')
			chart_total = forms.BooleanField(required=False, initial=False, label='Show total line (except percentage/stacked charts)')
			split_by = forms.ChoiceField()
			category = forms.IntegerField(min_value=0,max_value=1)
			use_gmt = forms.BooleanField(required=False, initial=False, label='Use GMT instead of local timezone')

			def __init__(self, data=None, initial=None, tzoffset=None, split_by_options={}, is_cui=False):
				super(ChartronFormClass, self).__init__(data=data, initial=initial)
				self.tzoffset = tzoffset
				self.is_cui = is_cui
				if initial and initial.has_key('tzoffset'):
					self.fields['use_gmt'].label += " (UTC%+d)"% initial['tzoffset']
				self.fields['split_by'].choices = [(s.name, s.label) for s in split_by_options]
			def _clean_time(self, fieldname):
				value = self.cleaned_data[fieldname]
				if value > datetime.now() + timedelta(hours=self.tzoffset):
					raise ValidationError('%s must be in the past' % fieldname)
				else:
					return value
			clean_start = lambda self: self._clean_time('start')
			clean_end = lambda self: self._clean_time('end')

			def clean(self):
				# Some other errors have already occurred
				if self.errors: return
				
				cleaned_data = super(ChartronFormClass, self).clean()
				if cleaned_data['use_gmt']:
					self.tzoffset = 0
				# Time span
				if cleaned_data['end'] <= cleaned_data['start']:
					raise ValidationError('end time must be after start')
				elif cleaned_data['end'] < (cleaned_data['start'] + timedelta(minutes=10)):
					cleaned_data['end'] = cleaned_data['start'] + timedelta(minutes=10)
				elif (cleaned_data['end'] - cleaned_data['start']) > timedelta(days=31):
					raise ValidationError("You cannot make a chart that spans more than 31 days")
				elif cleaned_data['start']<datetime.today() - timedelta(days=182) and (cleaned_data.get('split_by') in ('pop', 'region', 'country') or ('Pop_all' not in cleaned_data.get('pop',['Pop_all']) and len(cleaned_data.get('pop',[])) > 0) or ('Country_all' not in cleaned_data.get('country',[]) and len(cleaned_data.get('country',[])) > 0) ):
					raise forms.ValidationError("You cannot make a chart that starts more than 6 months ago for charts split by pop or region")
				elif cleaned_data['start'] < datetime.today() - timedelta(days=395):
					raise ValidationError("You cannot make a chart that starts more than 13 months ago for charts split by customer, site or service")
				all = False
				group_set = cleaned_data.get(cleaned_data['split_by'],[])
				for item in group_set:
					if item.endswith("_all"):
						all = True
						break
				if len(group_set) == 0:
					all = True
				group_size = len(self.fields.get(cleaned_data['split_by']).choices) if all else len(group_set)
				days = (cleaned_data['end'] - cleaned_data['start']).days+1
				if not self.is_cui and days * group_size > 30000:
					raise ValidationError("The chart size is to large, please reduce number of items inspected (%d)" %(days*group_size))

				return cleaned_data

		class ChartronFormClassHttp(ChartronFormClass):
			def __init__(self, data=None, initial=None, tzoffset=None, is_cui=False):
				super(ChartronFormClassHttp, self).__init__(data=data, initial=initial, tzoffset=tzoffset, split_by_options=category_options[0].split_by_options, is_cui=is_cui)

			customer_country = choice_for_model(
				Country.objects.order_by('name'),
				enable_set=set(get_all_address_country_ids_flat(reload)),
				show_disabled=False,
				required=False,
				size=5,
				style='width: 350px'
			)
			customer     = choice_for_model(
				Customer.objects.order_by('name'),
				enable_set=set(get_all_site_customer_ids_flat(reload)),
				tag_pairs = [('`Country`','address__country__id')],
				size=22,
				required=False,
				style='width: 350px'
			)
			site_service = choice_for_model(
				Service.objects.order_by('dns_prefix'),
				class_name='SiteService',
				additional_values=['dns_prefix','name'],
				name_attribute=lambda obj: '%s: %s' %(obj['dns_prefix'],obj['name']),
				enable_set=set(get_all_site_service_ids_flat(reload)),
				size=10,
				required=False,
				style='width: 350px'
			)
			# I understand why I need select_related() for the order_by() to work, but
			# this is weird and buggy:  if depth < 4, site.service.id is wrong!
			customer_site= choice_for_model(
				Site.objects.select_related(depth=4).order_by('customer__name', 'pad'),
				tag_pairs = [('Country','customer__address__country__id'),('Customer','customer__id'), ('SiteService','service__id')],
				size=10,
				required=False,
				name_attribute='pad',
				label='Site',
				style='width: 350px'
			)
			region	   = choice_for_model(
				Region.objects.order_by('name'),
				enable_set=set(get_all_pop_region_ids_flat(reload)),
				size=10,
				required=False,
				style='width: 350px'
			)
			# Not shown in OUI, only CUI
			country	  = choice_for_model(
				Country.objects.order_by('name'),
				tag_fn = lambda country: ['Region_%s' %(i) for i in Region.objects.filter(countries__id = country['id']).values_list('id',flat=True)],
				enable_set=set(get_all_pop_country_ids_flat(reload)),
				size=10,
				required=False,
				show_disabled=False,
				label ="PoP Location",
				style='width: 350px'
			)
			pop_service  = choice_for_model(
				Service.objects.order_by('dns_prefix'),
				class_name='POPService',
				enable_fn=lambda pop_service: Service.objects.get(id=pop_service['id']).pop_count(),
				size=10,
				required=False,
				additional_values=['dns_prefix','name'],
				name_attribute=lambda obj: '%s: %s' %(obj['dns_prefix'],obj['name']),
				# Can't split by POP service -- we don't actually store, in the traffic
				# tables, which service a POP used to process a request
				split_by=False,
				style='width: 350px'
			)
			pop	      = choice_for_model(
				Pop.objects.filter(importance__gt=-1).order_by('name'),
				name_attribute="short_name",
				tag_fn = lambda pop: ['POPService_%d' %(i) for i in Service.objects.filter(bands__id = pop['id']).values_list('id',flat=True)],
				tag_pairs = [('Region', 'region__id')],
				size=10,
				required=False,
				style='width: 350px'
			)

		class ChartronFormClassDns(ChartronFormClass):
			def __init__(self, data=None, initial=None, tzoffset=None, is_cui=False):
				super(ChartronFormClassDns, self).__init__(data=data, initial=initial, tzoffset=tzoffset, split_by_options=category_options[1].split_by_options, is_cui=is_cui)

			dns_region = choice_for_model(
				Region.objects.order_by('name'),
				class_name="DnsRegion",
				enable_set=set(get_all_pop_region_ids_flat(reload)),
				size=10,
				required=False,
				style='width: 350px'
			)
			dns_node = choice_for_model(
				Node.objects.filter(node_type__in = [2,3]).order_by('hostname'),
				class_name="DnsNode",
				additional_values=['hostname'],
				name_attribute=lambda obj: short_hostname(obj['hostname']),
				size = 10,
				required=True,
				tag_fn=lambda dns_node: ['NodeService_%s' %(i)  for i in Service.objects.filter(bands__node__id = dns_node['id']).values_list('id',flat=True)],
				tag_pairs=[('DnsRegion','pop__region__id')],
				style='width: 350px'
			)
			dns_service = choice_for_model(
				Service.objects.order_by('dns_prefix'),
				class_name='DnsService',
				additional_values=['dns_prefix','name'],
				name_attribute=lambda obj: '%s: %s' %(obj['dns_prefix'],obj['name']),
				enable_fn=lambda pop_service: Service.objects.get(id=pop_service['id']).pop_count(),
				size=10,
				required=False,
				style='width: 350px'
			)
			node_service = choice_for_model(
				Service.objects.order_by('dns_prefix'),
				class_name='NodeService',
				additional_values=['dns_prefix','name'],
				name_attribute=lambda obj: '%s: %s' %(obj['dns_prefix'],obj['name']),
				size=10,
				required=False,
				style='width: 350px'
			)
		_cached_class[0] = ChartronFormClassHttp
		_cached_class[1] = ChartronFormClassDns
	# return a class
	return _cached_class[category]

class SelectMultipleTagged(forms.SelectMultiple):
	"""
	Like the forms.SelectMultiple widget, but with configurable 'tags' for each
	option, encoded in the CSS class names
	"""
	def __init__(self, tags,  enabled, tags_dict={}, show_disabled=True, **kwargs):
		"""
		@param tags:  A sequence of sequences of tags
		@param tags_dict: A dictionary of tags where the key is the id
		"""
		self.tags = tags
		self.tags_dict = tags_dict
		self.enabled = enabled
		self.show_disabled = show_disabled
		super(SelectMultipleTagged, self).__init__(**kwargs)

	def render(self, name, value, attrs=None, choices=()):
		#assert len(self.tags) == len(choices), "SelectMultipleTagged widget expects the same number of tags as choices"

		if value is None: value = []
		final_attrs = self.build_attrs(attrs, name=name)
		output = [u'<select multiple="multiple"%s>' % util.flatatt(final_attrs)]
		str_values = set([smart_unicode(v) for v in value]) # Normalize to strings.
		all_choices = list(chain(self.choices, choices))
		for i, option in enumerate(all_choices):
			if not self.show_disabled and not self.enabled[i]:
				continue
			option_value, option_label = option
			option_value = smart_unicode(option_value)
			selected_html = (option_value in str_values) and ' selected="selected"' or ''
			enabled_html = '' if self.enabled[i] else ' disabled="disabled"'
			tag_value = smart_unicode(' '.join(self.tags_dict.get(option_value) or '') + ' ' + ' '.join(map(str, self.tags[i]))).strip()

			output.append(u'<option class="%s" id="%s" value="%s"%s%s>%s</option>' % (
				escape(tag_value), escape(option_value), escape(option_value), selected_html, enabled_html, escape(smart_unicode(option_label))
			))
		output.append(u'</select>')
		return u'\n'.join(output)

def choice_for_model(
		query_set,
		size=10,
		tag_fn=None,
		tag_pairs=[],
		additional_values=None,
		enable_fn=None,
		enable_set=None,
		required=True,
		name_attribute='name',
		class_name=None,
		split_by=True,
		label=None,
		show_disabled = True,
		style=None,
	):
	"""
	@param query_set:    A Django QuerySet of model instances
	@additional_values: Values that are needed by any of the fn methods from the query object 
	@param tag_fn:	 A function: model instance -> [ 'tag', ... ] If possible tag_pairs is preferred useage for performance reasons.
	@param tag_pairs:       A list of tuples.  Each tuple should be two elements, first being the element name and the second being the field of the linking element based off of the model_class.  If a relationship can not be directly made using (values_list function) then tag_fn should be utilized.
	NOTE: tag_fn and tag_pairs can not be used in conjunction but tag_pairs is heavily preferred if possible.
	@param enable_fn:      A function: model instance -> enabled/disabled
	@param enable_set:     A set: of id's.  If model.class[X].id is in enable_set then enabled, otherwise disabled if enable_set is a set.
	NOTE: enable_set overrides enable_fn so supplying both is pointless.  enable_set is the preferred option for performance reasons.
				the field should be enabled in UI else it is disabled.
	@param name_attribute: An attribute of instances of model_class that should
			       be used to display instances in the HTML form.  E.g.,
			       if Site().pad is a good way to display a Site, then
			       name_attribute should be 'pad'.  This can also be a function, if so it will call the function.
	@param class_name:     Optional name for use in IDs, etc., defaults to model name
	@param split_by:	   If True, user can split data by this key (e.g., split
						   by customer name)
	@param show_disabled   If False instead of showing fields as disabled it will not display the disabled items
	@return: A Field instance allowing the user to choose some of the model instances
	"""
	class_name = class_name or query_set.model.__name__

	if not tag_fn: tag_fn = lambda instance: []
	if enable_set: enable_fn = lambda obj: enable_set.issuperset(set([obj['id']]))
	if not enable_fn: enable_fn = lambda instance: True
	if not callable(name_attribute):
		additional_values = [name_attribute] + (additional_values if isinstance(additional_values,list) else [])
		name_func = lambda obj : obj[name_attribute]
	else:
		name_func = name_attribute
	#compile tag_pairs
	if isinstance(tag_pairs, tuple):
		tag_pairs = [tag_pairs]
	tag_pairs_compiled = {}

	values_needed=['id'] + [tag_pair[1] for tag_pair in tag_pairs] + additional_values
	vals = query_set.values(*values_needed)

	for tag_pair in tag_pairs:
		for val in vals:
			tag_key = '%s_%s' % (class_name, val['id'])
			tag_value = '%s_%s' % (tag_pair[0], val[tag_pair[1]])
			if not tag_pairs_compiled.has_key(tag_key):
				tag_pairs_compiled[tag_key] = []
			tag_pairs_compiled[tag_key].append(tag_value)
	# For a list of Customers, for example, the field will be rendered like
	# <select><option value="Customer_all">all</option><option value="Customer_1">Joe</option> ... </select>
	all = '%s_all' % class_name
	if style:
		attrs={'size':size,'class':'dash_select','style':style}
	else:
		attrs={'size':size,'class':'dash_select'}
	rv  = forms.MultipleChoiceField(
		choices=[(all, 'all')] + [('%s_%s' % (class_name, i['id']), name_func(i)) for i in vals],
		initial=[ all ],
		widget=SelectMultipleTagged(
			tags = [['all']] + map(tag_fn, vals),
			enabled = [True] + map(enable_fn, vals),
			tags_dict=tag_pairs_compiled,
			attrs=attrs,
			show_disabled = show_disabled,
		),
		required=required,
		label=label
	)

	rv.split_by = split_by
	return rv

class ChartSaveForm(forms.Form):
	chart     = forms.IntegerField(widget=forms.HiddenInput)
	dates_relative = forms.BooleanField(
		label='Use relative dates',
		help_text='If this is checked, the report will use a time range relative\nto the current time; otherwise, it will always use the absolute\ntime range you have specified',
		required=False
	)

def chartron_div_body(request, chart_type=None, is_cui=False, chart=None):
	"""
	AJAX responder:	 Returns the HTML <div> body for a chart
	@param chart_type:  One of the kinds of output, like 'mbps', 'hits_per_sec', ...
	@param is_cui:	  Whether this request comes from the CUI
	@param chart:	   Optional chart, otherwise a new one is created
	"""
	try:
		assert request.method == 'POST'

		if not chart:
			assert chart_type

			# Get the form class and instantiate it
			if not is_cui and (not request.POST or request.POST.get('category') not in ("0","1")):
				return HttpResponse("Internal error in form", status=500, mimetype='text/plain')
			post = request.POST.copy()
			if is_cui:
				post['category'] = 0
			category = int(post.get('category'))

			form  = create_chartron_form_class(category = category)(post, tzoffset=request.session.get('tzo',0), is_cui=is_cui)
			if not form.is_valid():
				return HttpResponse(form.errors.as_text(), status=500, mimetype='text/plain')

			cleaned_data = form.cleaned_data

			chart = request.user.chart_set.create(chart_type=chart_type, is_cui=is_cui, category = category)

			chart.initialize(
				tzoffset=request.session.get('tzo',0) if not cleaned_data['use_gmt'] else 0,
				form_data=cleaned_data
			)

			# Save the form_data
			chart.save()

		max_subject_length = 200

		class ChartEmailForm(forms.Form):
			subject   = forms.CharField(max_length=max_subject_length, widget=forms.TextInput(attrs={'size':30}))
			recipient = forms.EmailField(widget=forms.TextInput(attrs={'size':30}))
			chart     = forms.IntegerField(widget=forms.HiddenInput)

		serieses, grand_total = chart.get_serieses()

		height = default_height if serieses else no_data_height

		chart_image_url = urlresolvers.reverse(
			'chartron_chart_image_cui' if is_cui else 'chartron_chart_image',
			args=[
				chart.id,
				default_width,
				height,
				datetime.now().strftime('%Y%m%d%H%M%S')
			]
		)

		return HttpResponse(
			_div_body_contents(
				"web",
				chart,
				chart_image_url,
				serieses,
				grand_total,
				{
					'chart_email_form': ChartEmailForm(
						initial={
							'subject':chart.make_title(show_dates=False)[:max_subject_length],'chart':chart.id
						}
					),
					'chart_save_form': ChartSaveForm(
						initial={
							'dates_relative':True,'chart':chart.id
						}
					),
					'cui': is_cui
				},
				default_width,
				height
			)
		)
	except Exception, e:
		traceback.print_exc()

		# The AJAX requester will display the error to the user, so keep it brief
		send_email  (MAINTAINER,MAINTAINER,'[Django] a chartron error has occured', traceback.format_exc())
		return HttpResponse("Internal server error", status=500, mimetype='text/plain')

class ChartTypeFormHttp(forms.Form):
	type = forms.MultipleChoiceField(
		choices=[(t.name, t.label) for t in category_options[0].chart_types],
		initial=[category_options[0].chart_types[0].name],
		widget=forms.CheckboxSelectMultiple(attrs={'class':'types'}),
		required=True
	)
	def __init__(self, *args, **kwargs):
		is_cui = kwargs.pop('is_cui') if 'is_cui' in kwargs else False
		super(ChartTypeFormHttp, self).__init__(*args, **kwargs)
		if is_cui:
			self.fields['type'].choices = [(t.name, t.label) for t in category_options[0].chart_types if t.show_in_cui]

class ChartTypeFormDns(forms.Form):
	type = forms.MultipleChoiceField(
		choices=[(t.name, t.label) for t in category_options[1].chart_types],
		initial=[category_options[1].chart_types[0].name],
		widget=forms.CheckboxSelectMultiple(attrs={'class':'types'}),
		required=True
	)

def get_all_address_country_ids_flat(reload=False):
	address_ids = cache.get('all_address_country_ids') if not reload else None
	if not address_ids:
		address_ids = Address.objects.distinct().values_list('country__id', flat=True)
		cache.set('all_address_country_ids',address_ids, 600)
	return address_ids

def get_all_site_customer_ids_flat(reload=False):
	customer_ids = cache.get('all_site_customer_ids') if not reload else None
	if not customer_ids:
		customer_ids = Site.objects.distinct().values_list('customer__id', flat=True)
		cache.set('all_site_customer_ids', customer_ids, 600)
	return customer_ids

def get_all_site_service_ids_flat(reload=False):
	service_ids = cache.get('all_site_service_ids') if not reload else None
	if not service_ids:
		service_ids = Site.objects.distinct().values_list('service__id', flat=True)
		cache.set('all_site_service_ids', service_ids, 600)
	return service_ids

def get_all_pop_region_ids_flat(reload=False):
	region_ids = cache.get('all_pop_region_ids') if not reload else None
	if not region_ids:
		region_ids = Pop.objects.values_list('region__id', flat=True)
		cache.set('all_pop_region_ids', region_ids, 600)
	return region_ids

def get_all_pop_country_ids_flat(reload=False):
	country_ids = cache.get('all_pop_country_ids') if not reload else None
	if not country_ids:
		country_ids = Pop.objects.values_list('country__id', flat=True)
		cache.set('all_pop_country_ids', country_ids, 600)
	return country_ids

def embed_chart(chart_params):
	"""
	A utility method to create a chart directly using a number of given parameters. Originally a template tag by Jesse
	List of parameters below are all optional and part of a catch-all dictionary
	It is recommended to explicitly set user_id to the requester's in case no site_id is passed. As this function will always create a chart anyway

	All charts created by this function will NOT be marked saved and therefore will be cleaned out each night 
	One of user_id or site_id can be 0, but not both.

	@param user_id:		The logged-in user's id
	@param customer_id:	Int, a user.id (not AuthUser)
	@param site_id:		Int, a site.id, or 0 for all a user's sites
	@param chart_type:	String like 'mbps', 'hits_per_sec', etc.
	@param category:	Int, category like 0 for http and 1 for dns
	@param split_by:	A split-by option's name, like 'customer_site' or 'pop'
	@param duration:	String, one of 'hour', 'day', week', 'month', 'year'
	@param tzoffset:	The offset in hours from UTC (available to templates if
						the tzoffset context processor is enabled)
	@param width:		The width of the chart image
	@param height:		The height of the chart image
	@param show_axes:	1 or 0, whether to show a set of axes in the chart image
	@param show_legend:	1 or 0, whether to include the legend
	@param display_type:String. valid options are: embedded, email or web. Defaults to embedded
	"""
	arg, value = {
		'hour':		('seconds', 3600),
		'4hours':	('seconds', 14400),
		'day':		('days', 1),
		'week':		('days', 7),
		'2weeks':	('days', 14),
		'month':	('days', 30),
		'year':		('days', 365)
	}[chart_params.get('duration', 'day')]
	td = timedelta(**{arg: value})


	# TODO jesse: is there a way to decouple / refactor this w/ the form defn?
	# one_or_all = lambda i: 'all' if not (i and int(i)) else i
	form_data = {
		'country': chart_params.get('country_id', None),
		'customer': chart_params.get('customer_id', None),
		'customer_site': chart_params.get('site_id', None),
		'end': round_time_to_epoch(datetime.now() + timedelta(hours=chart_params.get('tzoffset', 0)), 5)-timedelta(minutes=5),
		'legend_count': 10,
		'pop': chart_params.get('pop_id', None),
		'pop_service': chart_params.get('pop_service_id', None),
		'region': chart_params.get('region_id', None),
		'site_service': chart_params.get('site_service_id', None),
		'split_by': chart_params.get('split_by', 'customer'),
		'start': round_time_to_epoch(datetime.now() + timedelta(hours=chart_params.get('tzoffset', 0)) - td, 5),
		'type': [chart_params.get('chart_type', 'mbps')],
		'category': chart_params.get('category_id', 0),
	}
	chart = Chart.objects.create(
		user_id=chart_params.get('user_id', 0),
		is_cui=False,
		dates_relative=True,
		chart_type=chart_params.get('chart_type', 'mbps'),
		category=chart_params.get('category', 0)
	)
	chart.setFormData(form_data, chart_params.get('tzoffset', 0))
	chart.initialize(chart_params.get('tzoffset', 0), nice_title_duration="%s (UTC%+d)" % (chart_params.get('duration', 'day'), chart_params.get('tzoffset', 0)))
	serieses, grand_total = chart.get_serieses()

	chart_image_url = urlresolvers.reverse(
		'chartron_chart_image',
		args=[chart.id, chart_params.get('width', 600),chart_params.get('height', 500) , datetime.now().strftime('%Y%m%d%H%M%S')]
	)
	chart_title = chart.make_title() # "%s for %s in %s by %s, %s" % (form_data['type'], form_data['customer'] )
	return _div_body_contents(
		chart_params.get('display_type',"embedded"),
		chart,
		chart_image_url,
		serieses,
		grand_total,
		width=chart_params.get('width', 600),
		height=chart_params.get('height', 500),
		show_legend=chart_params.get('show_legend', 1),
		title=chart_title
	).strip()
