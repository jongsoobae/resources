import socket
from httplib import HTTPSConnection
from xml.dom import minidom
from urllib import urlencode, quote
from ci.constants import COP_API_SERVER, COP_USER, COP_PASS, MAINTAINER, PORTAL_INTEGRATION
from ci.common.utils.mail import send_email

cop_response_codes = {0:"Success",
            201: "Duplicated the user key(ukey).",
            202: "Duplicated the email.",
            301: "Duplicated the domain name.",
            302: "Duplicated the site id.",
            403: "Failed to authenticate using credential.",
            404: "Can not find the ckey.",
            405: "Can not find the product_id in COP.",
            406: "Can not find the site_id in COP.",
            407: "Can not find the ukey.",
            999: "An unexpected error.",
            -1: "Error connecting to server",
            -2: "Error obtaining response code",
}

def cop_user_add(user, password):
    uri = "/PoUser/%d/add/" %(user.id)
    if hasattr(user.userprofile, '__call__'):
        customer_key =user.userprofile().customer.id
    else:
        customer_key = user.userprofile.customer.id
    params = {'ckey':customer_key, 'uname': "%s^%s" %(user.first_name,user.last_name), 'email': user.email, 'upass': password}
    return copCall(uri, params)[0]

def cop_user_update(user, password=None):
    uri = "/PoUser/%d/update/" %(user.id)
    if user and hasattr(user.userprofile, '__call__'):
        customer = user.userprofile().customer
    elif user and not hasattr(user.userprofile, '__call__'):
        customer = user.userprofile.customer
    else:
        customer = None
    params = {'ckey': customer.id, 'uname': "%s^%s" %(user.first_name,user.last_name), 'email': user.email, 'status': "active" if user.is_active else "inactive"}
    return copCall(uri, params)[0]

def get_site_path_string(site):
    return "$".join(["%d-%s:%s" %(site.id, x[0], x[1]) for x in site.get_paths().items()])

def cop_domain_add(site):
    if COP_API_SERVER in ("",None):
        return True
    uri = "/PoDomain/%s/add/" %(site.id)
    params = {'ckey': site.customer.id, 'domain': site.pad, 'product_id': site.product.cop_product_id if site.product else '', 'service_id': site.service.id, 'status': 'active' if site.status else 'inactive', 'platform_cd': site.platform_cd if site.platform_cd else '', 'customer_portal_flag':site.customer.customer_portal_flag}
    if site.stat_paths:
        params['path'] = get_site_path_string(site)
    return copCall(uri, params, acceptableResponses=[0,301,405])[0]

def cop_domain_link(site):
    if COP_API_SERVER in ("",None):
        return True
    uri = "/PoDomain/%s/link/" %(site.id)
    params = {'ckey': site.customer.id, 'domain': site.pad, 'product_id': site.product.cop_product_id if site.product else '', 'service_id': site.service.id, 'status': 'active' if site.status else 'inactive', 'platform_cd': site.platform_cd if site.platform_cd else '', 'customer_portal_flag':site.customer.customer_portal_flag}
    if site.stat_paths:
        params['path'] = get_site_path_string(site)
    return copCall(uri, params, acceptableResponses=[0,301,405])[0]

def ocsp_domain_status(site):
	ocsp_status = 'active'
	if site.customer.status == True and site.status == True:
		if site.product and site.product.active == False:
			ocsp_status = 'inactive'
		else:
			ocsp_status = 'active'
	else:
		ocsp_status = 'inactive'

	return ocsp_status


def cop_customer_update(service_country, customer, billing_country=None):
    if COP_API_SERVER in ("",None):
        return True
    uri = "/PoCustomer/%s/update/" %(customer.id)
    params = {'cname': customer.name.encode('utf8'), 'migration': 0 if customer.cdnetworks_customer else 1, 'customer_portal_flag':customer.customer_portal_flag}
    return copCall(uri, params, acceptableResponses=[0,301,405])[0]


def cop_domain_update(site, old_info={}):
    if COP_API_SERVER in ("",None):
        return True
    uri = "/PoDomain/%s/update/" %(site.id)
    params = {'ckey': site.customer.id,
              'domain': site.pad,
              'product_id': site.product.cop_product_id if site.product else '',
              'service_id': site.service.id,
              'status': site.get_ocsp_domain_status(),
              'platform_cd': site.platform_cd if site.platform_cd else '',
              'customer_portal_flag':site.customer.customer_portal_flag}
    if site.stat_paths:
        params['path'] = get_site_path_string(site)

    if len(old_info) > 0:
        params.update(old_info)

    resp = copCall(uri, params, acceptableResponses=[0,406])
    if resp[1] == 406:
        return cop_domain_add(site)
    return resp[0]


def copCall(uri_fragment, params, acceptableResponses=[0]):
    resp = -2
    resp_desc = None
    data = ""
    error = None
    server = ""
    final_uri = ""
    try:
        server = COP_API_SERVER
        if COP_API_SERVER in ("",None):
            #remove this once COP goes production
            return (True,0)
        final_uri = "/CopAdmin/%s:%s%s?%s" %(quote(COP_USER), quote(COP_PASS), uri_fragment, urlencode(params))
        socket.setdefaulttimeout(20)
        conn = HTTPSConnection(server)
        conn.request("GET",  final_uri)
        data = conn.getresponse().read()
        dom_obj = minidom.parseString(data)
        resp = int(dom_obj.getElementsByTagName("ReturnCode").item(0).lastChild.nodeValue)
        #need to parse resp to get code...
        resp_desc = dom_obj.getElementsByTagName("ReturnCodeDescription").item(0).lastChild.nodeValue
    except Exception, e:
        resp = -1
        error = e
    if resp not in acceptableResponses:
        message = "URL: %s%s\nResponse Code: %d\nResponse Description: %s\nFull Response:\n%s\nError:%s" %(server, final_uri, resp, resp_desc if resp_desc else cop_response_codes.get(resp,"Unknown Response"), data, error if error else "N/A")
        send_email(MAINTAINER, PORTAL_INTEGRATION, '[OUI-COP2] error occurred synching to COP portal', message)
        return (False,resp)
    return (True,resp)