#!/usr/bin/env python
import os
import sys
import tempfile
import random
import logging
import time
import StringIO
import urllib
import Cookie
import io
from ci.common.utils.curlwrapper.request import Request as Request

#todo switch to cStringIO
#todo support proxy

class NullHandler(logging.Handler):
    def emit(self, record):
        pass



h = NullHandler()
logging.getLogger("browser").addHandler(h)

PROXY_TYPES = [
    'SOCKS4',
    'SOCKS4A',
    'SOCKS5',
    'HTTP',
    'AUTO',
    'NONE'
]

REGULAR_USER_AGENTS = [
        'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:40.0) Gecko/20100101 Firefox/40.0',
]


class BaseBrowser(object):
    def __init__(self, cookies=False, redirect=True, verbose=True):
        # The browser doesn't need a proxy list it could be beneficial in
        # the case of repeated failures, but honestly probably doesn't
        # contribute much
        self.veryverbose = True
        self.has_cookies = cookies
        self.use_real_cookie_file = False
        self.redirect = redirect
        self.proxy_list = []
        self.verbose = verbose
        self.current_proxy = ''
        self.user_agent = random.choice(REGULAR_USER_AGENTS)
        self.retry_limit = 3
        self.timeout = 60
        self.keep_alive = True
        self.use_proxy_dns = True
        self.range = None
        #TODO: set default proxy type to AUTO req- enable detection
        self.proxy_type = "SOCKS4"
        self.proxies_only = False # for secure only connections
        #TODO: maybe make cookies read from memory
        if self.has_cookies:
            if self.use_real_cookie_file:
                self.cookie_file = tempfile.NamedTemporaryFile()
                self.cookie_file_path = self.cookie_file.name
            else:
                self.cookie_file_path = ""

            #self.tempfile, self.tempfilename = tempfile.TemporaryFile()
        self.headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            #'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
        }


    def __del__(self):
        """
        Shutdown
        """
        #print 'garbage collected'
        self.close()
    def enable_keep_alive(self):
        """
        turn on keep alives
        """
        if self.keep_alive == False:
            self.headers['Connection'] = 'keep-alive'
            self.headers['Keep-Alive'] = '300'
            self.keep_alive = True

    def disable_keep_alive(self):
        """
        turn off keep alives
        """
        if self.keep_alive == True:
            del self.headers['Connection']
            del self.headers['Keep-Alive']
            self.keep_alive = False
    def get_cookies(self):
        """
        stub for getting cookies
        """
        pass
    def set_cookies(self, cookies):
        """
        stub for setting cookies
        """
        pass
    def detect_proxy_type(self):
        """
        stub for detecting the type of proxy
        """
        pass
    def close(self):
        """
        this is a shutdown method
        """

    def fetch(self, url):
        """
        this is a simple call wrapper
        """
        return self.request(Request(url=url))
    def request(self, r):
        """
        Performs a http request
        """
        pass