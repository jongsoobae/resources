import urllib

class Request:
    """This is the Request object that contains the tricky stuff
    for a http request"""
    def __init__(self, url='', post=None, referer='',cookie='', extraheaders={},
                 trycount=None, multipart=False, filename=None, file_contents=None):
        """Download an URL with GET or POST methods.
        @param forbid_redirect: Set this flag if you do not want to handle
            HTTP 301 and 302 redirects.
        @param trycount: Specify the maximum number of retries here.
            0 means no retry on error. Using -1 means infinite retring.
            None means the default value (that is self.trycount).
        """
        self.cookies = cookie
        self.url = url
        if referer == '':
            self.referer = self.url
        else:
            self.referer = referer

        self.multipart = multipart

        if self.multipart:
            self.post = post
        elif isinstance(post, dict) :
            self.post = urllib.urlencode(post)
        elif isinstance(post, list) and not self.multipart:
            self.post = urllib.urlencode(post)
        else:
            self.post = post
        self.tries = 0
        self.max_try_count = trycount
        self.additional_headers = extraheaders
        self.filename = filename
        self.file_contents = file_contents