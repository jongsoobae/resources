#!/usr/bin/env python
import StringIO
from HTMLParser import HTMLParser

INVALID_CREDENTIAL_PHRASE = 'Wrong ID or password'

class Response:
    """This is a the response object to return all variables related to
    a browser request"""
    def __init__(self, success=True, response='', code=None, error_code='', error_msg='', response_URI=''):
        self.server = ''
        #Gets the URI of the Internet resource that responded to
        #the request.
        #Gets or sets the cookies that are associated with this response.
        self.cookies = []
        self.headers = []
        self.success = False
        self.raw_headers = StringIO.StringIO()
        self.raw_cookies = []
        self.status_code = code
        self.response_URI = response_URI
        self.redirect_count = None
        self.redirect_url = None
        self.statusCode = self.status_code
        self.response_buffer = StringIO.StringIO()
        self.success = success
        self.error_code = error_code
        self.error_msg = error_msg
        self.content_length = None
        self.htmlparser = None
        self.raw_content = ''

        self.set_data(code, error_code, error_msg)

    @property
    def response(self):
        return self.parse_content()

    @property
    def raw_contents(self):
        return self.raw_content

    def parse_content(self):
        self.raw_content = self.response_buffer.getvalue()
        if INVALID_CREDENTIAL_PHRASE in self.raw_content:
            return ['Invalid Credential']

        htmlparser = CSHTMLParser()
        htmlparser.feed(self.raw_content)
        self.htmlparser = htmlparser
        return self.htmlparser.content_list

    def get_error_message_for_customer(self):
        if self.error_code and self.error_code != '':
            return "Unable to fetch result from a test node of PAD. Error_Code:%s\nPlease contact Support Center." % self.error_code
        else:
            if self.status_code != 200:
                return "Unable to fetch result from a test node of PAD. Error_Code:%s\nPlease contact Support Center." % self.status_code
            else:
                return ''

    def set_data(self, code=None, error_code='', error_msg=''):
        self.status_code = code
        self.statusCode = self.status_code
        #maybe call this .body as well?
        self.parse_headers()
        self.parse_cookies()

    def parse_headers(self):
        headers = self.raw_headers.getvalue().splitlines()
        #print headers
        #headers should be a list not a dict as there can be more than one Set-Cookie header etc
        new_h = []
        for h in headers:
            values = h.split(':', 1)
            if len(values) == 2:
                new_h.append((values[0].strip(), values[1].strip()))
        self.headers = new_h
        #print self.headers

    def parse_cookies(self):
        for cookie in self.raw_cookies:
            pass
            #print cookie.split('\t')

    def parse_refresh(self):
        refresh_url = False
        try:
            refresh_url = self.parse_refresh_line(self.headers['Refresh'])
        except KeyError:
            #print self.headers
            pass
        if refresh_url:
            return refresh_url
        return False

    @staticmethod
    def parse_refresh_line(refresh_line):
        if refresh_line.find(';') == -1:
            return False
        refresh_line = refresh_line.split(';',2)[1]
        refresh_line = refresh_line.replace('url=','')
        refresh_line = refresh_line.replace('URL=','')
        refresh_line = refresh_line.strip()
        return refresh_line

class CSHTMLParser(HTMLParser):
    def __init__(self,start_message=None, end_message=None):
        HTMLParser.__init__(self)
        self.intag = False
        self.indata = False
        self.incontent = False
        self.title_list = []
        self.content_list = []
        self.error_title = ""
        self.started = False
        self.ended = False
        if start_message is None:
            self.start_message = 'journey starts here'
        if end_message is None:
            self.end_message = '-- the end --'

    def add_content(self,data):
        if data.lower() == self.end_message:
            self.ended = True
        if self.started and not self.ended:
            self.content_list.append(data)

        if data.lower() == self.start_message:
            self.started = True

    def handle_starttag(self, tag, attrs):
        if tag == 'title':
            self.intag = True
        elif tag == 'pre':
            self.incontent = True
        elif tag == 'p':
            self.indata = True
        elif tag =='hr':
            self.add_content('-----------------------')


    def handle_endtag(self, tag):
        if tag == 'title':
            self.intag = False
        elif tag == 'pre':
            self.incontent = False
        elif tag == 'p':
            self.indata = False

    def handle_data(self, data):
        if self.intag:
            self.title_list.append(data)

        if self.indata:
            self.add_content(data)

    def handle_comment(self, data):
        # print "Comment  :", data
        pass

    def handle_entityref(self, name):
        # c = unichr(name2codepoint[name])
        # print "Named ent:", c
        pass

    def handle_charref(self, name):
        # if name.startswith('x'):
        #    c = unichr(int(name[1:], 16))
        # else:
        #    c = unichr(int(name))
        # print "Num ent  :", c
        pass

    def handle_decl(self, data):
        # print "Decl     :", data
        pass