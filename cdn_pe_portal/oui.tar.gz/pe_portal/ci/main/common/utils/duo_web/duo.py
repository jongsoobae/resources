from django.contrib.auth import login, authenticate
from django.http import HttpResponseRedirect
from ci.common.utils.duo_web import sign_request, verify_response
from ci.constants import DUO_IKEY, DUO_SKEY, DUO_AKEY, DUO_TIMEOUT

from django.contrib import messages

from datetime import datetime

ikey = DUO_IKEY
skey = DUO_SKEY
akey = DUO_AKEY


def get_sig_request(username):
    # username = 'test'

    return sign_request(ikey, skey, akey, username)


def duo_login(request, *args, **kwargs):
    sig_response = request.POST.get('sig_response')
    username = request.session.pop('duo_user_id')
    password = request.session.pop('duo_user_password')
    duo_login_time = request.session.pop('duo_login_time')
    duo_next = request.session.pop('duo_next')

    td = datetime.now() - duo_login_time
    passed_seconds = (td.microseconds + (td.seconds + td.days * 24 * 3600) * 10**6) / 10**6

    if passed_seconds >= DUO_TIMEOUT or not username:
        message = 'Must login within %s seconds. Please retry.' % DUO_TIMEOUT
        messages.add_message(request, messages.WARNING, message)
        HttpResponseRedirect('/login?next=%s' % duo_next)

    authenticated_username = verify_response(ikey, skey, akey, sig_response)
    if authenticated_username:
        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
    return HttpResponseRedirect(duo_next)
