"""
Tools for adding/editing/deleting CustomerAdjustment and InvoiceAdjustment
model instances in views
"""

from django.utils.datastructures import SortedDict
from django import forms
from django.template.loader import render_to_string
from django.forms.forms import BoundField
from django.utils.safestring import mark_safe
from datetime import timedelta
import re

is_percentage_choices = lambda currency: [
	(1, 'percentage'),
	# Prevent RadioInput class from escaping the html_symbol
	(0, mark_safe('constant %s' % currency.html_symbol))
]

class EditAdjustmentWidget(forms.MultiWidget):
	"""
	A multi-widget widget for editing an adjustment, or creating a new one.
	"""
	def __init__(
			self, currency, adjustment, is_intl, enabled=True, hidden=False, tr_id=None
		):
		"""
		@param currency:	A Currency instance
		@param adjustment:  An InvoiceAdjustment or CustomerAdjustment instance, or None
		@param is_intl:		True unless customer is US or Canadian
		@param enabled:		If False, this widget is read-only
		@param hidden:		If True, the template will mark this hidden from the user
		@param tr_id:		The id of the <tr> element this will render as
		"""
		self.is_new 		= not adjustment
		self.currency 		= currency
		self.adjustment		= adjustment
		self.is_intl		= is_intl
		self.enabled 		= enabled
		self.hidden			= hidden
		self.tr_id			= tr_id
		
		attrs 				= { 'class': 'textinput' }
		attr_list			= [dict(attrs, size=25), dict(attrs, size=20)]
		
		# description, is_percentage, amount, delete: coupled with EditAdjustmentField's fields
		widgets 		= [
			forms.TextInput(),
			forms.RadioSelect(choices=is_percentage_choices(currency)),
			forms.TextInput(),
			forms.CheckboxInput()
		]
		
		super(EditAdjustmentWidget, self).__init__(widgets, attrs=attrs)
	def decompress(self, value):
		return value
	def format_output(self, rendered_widgets):
		"""
		As a <tr> element
		"""
		context = {
			'description': 		rendered_widgets[0] if self.enabled else self.adjustment.description,
			'is_percentage':	rendered_widgets[1] if self.enabled else self.adjustment.is_percentage,
			'amount': 			rendered_widgets[2] if self.enabled else self.adjustment.amount,
			'delete':			rendered_widgets[3] if self.enabled else None,
			'adj_amount':		(self.adjustment.amount/100)*self.adjustment.invoice.new_charge if not self.enabled and self.adjustment.is_percentage else None,
			'is_new': 			self.is_new,
			'currency': 		self.currency,
			'is_intl':			self.is_intl,
			'enabled':			self.enabled,
			'hidden': 			self.hidden,
			'tr_id': 			self.tr_id
		}
		
		return render_to_string("fragment/adjustment_form.html", context)


class EditAdjustmentField(forms.MultiValueField):
	"""
	A multi-field field for editing an adjustment, or creating a new one.
	"""
	def __init__(
		self, currency, adjustment, description, is_percentage, amount, is_intl, 
		enabled=True, hidden=False, tr_id=None, required=False, validate=True,
		data=None
	):
		"""
		@param currency:			A Currency instance
		@param adjustment:  		An InvoiceAdjustment instance, or None
		@param amount:				For a bound form, the amount of a submitted adjustment
		@param is_percentage:		For a bound form, whether the amount is a percentage or fixed
		@param description:			For a bound form, the description of a submitted adjustment
		@param is_intl:				True unless customer is US or Canadian
		@param enabled:				If False, this widget is read-only (for published invoices)
		@param hidden:				If True, the template will mark this hidden from the user
		@param tr_id:				The id of the <tr> element this will render as
		@param required:			Required?
		@param validate:			If False, don't clean or validate this field (it's just a
									spare for Javascript to use)
		"""
		self.is_adjustment_field 	= True # for templates' use
		
		# description, is_percentage, amount, delete: coupled with EditAdjustmentWidget's widgets
		fields=[
			forms.CharField(label='description'),
			forms.TypedChoiceField(
				coerce=int,
				choices=is_percentage_choices(currency),
				initial=adjustment.is_percentage if adjustment else is_percentage
			),
			forms.DecimalField(decimal_places=2, max_digits=10),
			forms.BooleanField()
		]
		
		if adjustment:
			self.type = 'edit_adjustment'
			initial = [
				adjustment.description,
				adjustment.is_percentage,
				adjustment.amount,
				False
			]
		elif amount or description:
			self.type = 'add_adjustment'
			initial = [
				description,
				is_percentage,
				amount,
				False
			]
		else:
			self.type = 'add_adjustment'
			initial = [
				'adjustment description',
				0,
				'adjustment amount',
				False
			]
		
		self.hidden 	= hidden
		self.validate	= validate
		
		widget = EditAdjustmentWidget(currency, adjustment, is_intl, enabled, hidden, tr_id)
		super(EditAdjustmentField, self).__init__(fields, initial=initial, widget=widget, required=required)
	def compress(self, data_list):
		return data_list
	def clean(self, value):
		if not self.validate:
			return [None for field in self.fields]
		else:
			return super(EditAdjustmentField, self).clean(value)


class EditAdjustmentForm(forms.ModelForm):
	def __init__(self, *args, **kwargs):
		"""
		@param enabled:		If True, allow editing
		@param is_intl:		If True, use international format for numbers
		@param currency:	A Currency instance
		@param adjustments:	A sequence of adjustment instances
							(CustomerAdjustments or InvoiceAdjustments)
		"""
		enabled, is_intl, currency, adjustments = (
			kwargs.pop(kw) for kw in ['enabled', 'is_intl', 'currency', 'adjustments']
		)
		
		super(EditAdjustmentForm, self).__init__(*args, **kwargs)
		
		# ------[ Fields to edit existing adjustments ]------------------------
		self._adjustments = SortedDict()
		for adjustment in adjustments:
			self._adjustments['adjustment_' + str(adjustment.id)] = EditAdjustmentField(
				currency,
				adjustment,
				None,
				None,
				None,
				is_intl,
				enabled=enabled
			)

		# ------[ Capture POSTED new adjustments ]-----------------------------
		self._new_adjustments = SortedDict()
		if self.is_bound:
			pat = re.compile(r'add_adjustment_(?P<id>\d+)_\d+')
			for key in sorted(self.data):
				match = pat.match(key)
				if match:
					id = match.group('id')
					field_name = 'add_adjustment_%s' % id
					widgy = EditAdjustmentWidget(currency, None, is_intl)
					description, is_percentage, amount, ignored = widgy.value_from_datadict(self.data, None, field_name)
					if field_name not in self._new_adjustments:
						self._new_adjustments[field_name] = EditAdjustmentField(
							currency,
							None,
							amount,
							is_percentage,
							description,
							is_intl,
						)
		
		# ------[ Combine the fields so far ]----------------------------------
		for d in self._adjustments, self._new_adjustments:
			self.fields.update(d)
		
		# ------[ Text fields to add new adjustment ]--------------------------
		# When the user wants to add another adjustment, Javascript will clone
		# the hidden one and unhide the clone
		self.fields['add_adjustment_spare'] = EditAdjustmentField(
			currency,
			None,
			None,
			None,
			None,
			is_intl,
			hidden=True,
			tr_id='customerform_add_adjustment_spare',
			required=False,
			validate=False
		)
	
	def adjustments(self):
		"""
		@return:	Iterator, sequence of bound EditAdjustmentFields
		"""
		for name, field in self._adjustments.items():
			yield BoundField(self, field, name)
		
		for name, field in self._new_adjustments.items():
			yield BoundField(self, field, name)

	def save_adjustments(self, model_instance, related_name):
		"""
		Create or delete adjustment instances
		@param model_instance:	A Customer or Invoice instance
		@param related_name:	Like 'customer_adjustment_set' or 'invoice_adjustment_set'	
		"""
		related_manager = getattr(model_instance, related_name)
		# Sort by form element ids, so that we create adjustment instances in
		# the DB in the order that Javascript created the form elements
		for key, value in sorted(self.cleaned_data.items()):
			if key == 'add_adjustment_spare':
				pass
			elif key.startswith('add_adjustment_'):
				description, is_percentage, amount, ignored = value
				related_manager.create(
					description=description,
					is_percentage=is_percentage,
					amount=amount
				)
			elif key.startswith('adjustment_'):
				adjustment_id = int(key.split('_')[-1])
				description, is_percentage, amount, delete = value
				adjustment = related_manager.get(id=adjustment_id)
				if delete:
					adjustment.delete()
				else:
					if (adjustment.description != description
						or adjustment.amount != amount
						or adjustment.is_percentage != is_percentage
					):
						adjustment.description = description
						adjustment.is_percentage = is_percentage
						adjustment.amount = amount
						adjustment.save()
