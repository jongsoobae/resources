import re
from django.db import models
from django import forms

class SimpleIntermediateM2MField(models.ManyToManyField):
	"""Normally, M2M fields with intermediate relations cannot use the M2M features in the admin interface, but
	this makes it possible if the intermediate relation's extra fields all have default values.
	
	Usage:
	 1. Use this class instead of ManyToManyField.
	 2. Override the form used in the ModelAdmin and add the ModelMultipleChoiceField manually, e.g.:
		nodes = forms.ModelMultipleChoiceField(queryset=Node.objects.all(), widget=widgets.FilteredSelectMultiple('Nodes', False))

	@table_to_field - dictionary mapping table name to the field name in the model
	"""
	def __init__(self, *args, **kwargs):
		self.replacements = kwargs.pop('table_to_field',None)
		super(SimpleIntermediateM2MField,self).__init__(*args, **kwargs)
	def save_form_data(self, instance, data):
		relation = self.rel.through
		to_field = self.rel.to._meta.object_name.lower()
		from_field = self.m2m_column_name()[:-3]
		if self.replacements:
			if self.replacements.get(to_field):
				to_field = self.replacements.get(to_field)
			if self.replacements.get(from_field):
				from_field = self.replacements.get(from_field)
		try:
			relation.objects.filter(**{from_field: instance}).exclude(**{'%s__pk__in' % to_field: [r.id for r in data]}).delete()
			current_set = [r.id for r in getattr(instance, self.attname).all()]
			for r in data:
				if r.id not in current_set:
					relation.objects.create(**{from_field: instance, to_field: r})
		except Exception, e:
			raise Exception("SimpleIntermediateM2MField needs table_to_field keyword set if the object name does not match the database table name (from: %s, to: %s), error message: %s" %(from_field, to_field, str(e)))

def regex_valid(value):
	if value and re.match(".*[\*\+]\)*[\*\+].*",value):
		return False
	return True

def regex_tester(value):
	ret = True
	try:
		re.match(value, "")
	except Exception, e:
		ret = False
	return ret

class RawCharField(forms.CharField):
	pass

class RegexFormField(forms.CharField):
	def clean(self, value):
		"""Checks if regex has **, if so raises error"""
		ret_value = super(RegexFormField, self).clean(value)
		if not regex_valid(ret_value):
			raise forms.ValidationError("Can not have * followed by an *")
		return ret_value

class RegexCustFormField(forms.CharField):
	def clean(self, value):
		"""Checks if regex has **, if so raises error"""
		ret_value = super(RegexCustFormField, self).clean(value)
		if not regex_tester(ret_value):
			raise forms.ValidationError("Invalid regular expression")
		if not regex_valid(ret_value):
			raise forms.ValidationError("Can not have * followed by an *")
		return ret_value

class RegexTextField(models.TextField):
	"""Changes default widget to RegexFormField"""
	def get_db_prep_value(self, value, connection, prepared=False):
		if not regex_valid(value):
			raise Exception("Can not have * followed by an *")
		return super(RegexTextField,self).get_db_prep_value(value)
	def formfield(self, **kwargs):
		defaults = {'form_class': RegexFormField}
		defaults.update(kwargs)
		return super(RegexTextField,self).formfield(**defaults)

def check_password_complexity(passwd):
    conditions_met = 0
    if len(passwd) >= 8:
		if re.search(r'[A-Z]{1,}', passwd):
			conditions_met += 1
		if re.search(r'[a-z]{1,}', passwd):
			conditions_met += 1
		if re.search(r'[!,@#$%^&*?_~]{1,}', passwd):
			conditions_met += 1
		if re.search(r'[0-9]{1,}', passwd):
			conditions_met = conditions_met + 1
    return conditions_met

