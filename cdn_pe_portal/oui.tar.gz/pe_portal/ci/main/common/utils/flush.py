from datetime import datetime, timedelta
from django.core.cache import cache
from django.db import connection
from ci.common.models.pusher import NodeUpdateFlushStatus, PusherToNodeUpdateFlush
from ci.common.models.site import Site


from ci.common.utils.flush_api import flush_stat_per_pad, list_top_flush_pad, list_flush_by_pad, get_near_limit_pads_api

def get_flush_rows(site):
	ten_days_ago = datetime.now() - timedelta(days=10)
	cursor = connection.cursor()
	q_wildcard = "select count(*)  from pusher_flush_xref where site_id = %d and create_time >= '%s' and type in ('3', '5') group by substr(create_time,1,13)" % ( site.id, ten_days_ago)
	
	cursor.execute(q_wildcard)
	sum_rows_wildcard = cursor.fetchall()
	q_item = "select count(*)  from pusher_flush_xref where site_id = %d and create_time >= '%s' and type not in ('3', '5') group by substr(create_time,1,13)" % (site.id, ten_days_ago)
	cursor.execute(q_item)
	sum_rows_item = cursor.fetchall()
	return sum_rows_wildcard, sum_rows_item 
		
def get_top_flush_pads(hour_range=1, type='wildcard'):
	create_time = datetime.now() - timedelta(hours=hour_range)
	ret_list = list_top_flush_pad(create_time, 'wildcard_items' if type=='wildcard' else 'item_items')
	ret_res = [(ret['customer_id'], 
				ret['customer_name'], 
				ret['site_id'], 
				ret['site'], 
				ret['wildcard_requests'], 
				ret['wildcard_items'], 
				ret['item_requests'], 
				ret['item_items']) for ret in ret_list]	
	return ret_res

def get_max_avg(data):
	"""Given a set of rows, send back the max value and the avg."""
	max_val, total = 0,0
	for r in data:
		total += r[0]
		if r[0]>max_val:
			max_val = r[0]
	try:
		avg_val = total/len(data)
	except ZeroDivisionError:
		avg_val = 0.0
	return max_val, avg_val

def flush_percent_done(repository_id, service_id=None):
	nufs = NodeUpdateFlushStatus.objects.filter(node__offline = False, node__nodestat__failed=0, node__pop__offline=0)
	if service_id != None:
		nufs = nufs.filter(node__band__service=service_id)
	try:
		behind_nodes = nufs.filter(update__lt = repository_id).count()
		
		if behind_nodes == 0:
			percent_done = 100.0
		else:
			active_node_count = float(nufs.count())
			percent_done = (active_node_count - behind_nodes) / active_node_count * 100
	except:
		percent_done = 0.0
	
	return percent_done

def get_customer_flush_stats(customer, sites=None):
	"""pass a customer and an optional site queryset and return all the flush stats of these pads"""
	if not sites:
		sites = Site.objects.filter(customer=customer)
	stats = dict([(site, {}) for site in sites]) 
	for site in sites:
		create_time = datetime.now() - timedelta(hours=1)
		wildcards_last_hour, non_wc_last_hour, max_wc_flush, avg_wc_flush, max_item_flush, avg_item_flush = flush_stat_per_pad (site)
		stats[site]['flushes_this_hour'] = non_wc_last_hour
		stats[site]['wildcards'] = wildcards_last_hour

		stats[site]['wildcard_stats'] = {
				'max_num': max_wc_flush,
				'avg_num': avg_wc_flush }
		stats[site]['item_stats'] = {
				'max_num': max_item_flush,
				'avg_num': avg_item_flush }

		if int(stats[site]['flushes_this_hour'])>=site.nonwildcard_hour:
			stats[site]['nonwildcard_above_limit']=True

		if int(stats[site]['wildcards'])>= site.wildcards_per_hour:
			stats[site]['wildcard_above_limit']=True
	return stats

def get_near_limit_pads(start_date, end_date):
	# TODO : It'd be nice if we could make this into an ORM query
	api_rows = get_near_limit_pads_api(str(start_date), str(end_date))
	rows = []
	for obj in api_rows:
		obj_row = []
		obj_row.append(int(obj.get('customer_id')))
		obj_row.append(obj.get('name'))
		obj_row.append(obj.get('serve_domain'))
		obj_row.append(int(obj.get('site_id')))
		obj_row.append(int(obj.get('item_requests')))
		obj_row.append(int(obj.get('flushes_per_hour')))
		obj_row.append(int(obj.get('wildcard_requests')))
		obj_row.append(int(obj.get('wildcards_per_hour')))
		obj_row.append(int(obj.get('item_group')))
		obj_row.append(int(obj.get('items_per_request')))
		obj_row.append(int(obj.get('wildcard_group')))
		obj_row.append(int(obj.get('wildcards_per_request')))
		rows.append(obj_row)
	return rows

def flush_list(site, can_cache=True, user=None, history_size=10000):
	flushes_pending = [] 
	flushes_complete = []
	flush_list = list_flush_by_pad(site, requester=user, max_result=20)
	for obj in flush_list:
		if float(obj['percent']) == 100.0:
			flushes_complete.append(obj)
		else:
			flushes_pending.append(obj)
	return (flushes_pending, flushes_complete)
	
def find_less_than_index(list_val, search_val):
	"""This assumes an ordered list"""
	if not list_val or len(list_val) <= 0 or list_val[0] >= search_val:
		return -1
	hi_pos = len(list_val) -1
	lo_pos = 0
	while hi_pos != lo_pos:
		mid = (hi_pos + lo_pos) / 2
		if mid==lo_pos:
			return lo_pos
		if list_val[mid] >= search_val:
			hi_pos = mid
		else:
			lo_pos = mid
	return lo_pos
