from django.utils import simplejson
from datetime import datetime, timedelta

from ci.common.models import get_request
from ci.common.models.site import Site
from httplib import HTTPConnection
from urllib import urlencode
from django.utils import simplejson
from ci.common.models.cdn import Node
from ci.constants import BACKEND_API_SERVER

class SiteOtg(object):
	id = 0
	pk = 0
	pad = ''
	origin = ''
	use_pad_as_host_header = False
	pad_aliases = ''
	use_sub_files = True
	optimal_ratio = 100

	def __init__(self, pad):
		data = get_site_info(pad)
		self.id = int(data['customer_site_id'])
		self.pk = int(data['customer_site_id'])
		self.pad = data['serve_domain']
		self.origin = data['domain']
		self.use_pad_as_host_header = True if data['use_pad_as_host_header'] == '1' else False
		self.pad_aliases = data['pad_aliases']
		self.use_sub_files = True if data['use_sub_files'] == '1' else False
		self.optimal_ratio = 100

def create_site_otg(pad):
	site = None
	try:
		site = SiteOtg(pad=pad)
	except:
		raise APIException("PAD information is failed.", status=400)
	return site


def HttpPostConnection(domain, uri, postParams):
	headers = {"Content-type": "application/json",
			"Accept": "text/plain"}
	try:
		conn = HTTPConnection(domain)
		conn.request("POST", uri, postParams, headers)
	except:
		return 600
	resp = conn.getresponse()
	resp_json = resp.read()
	resp_status = resp.status
	conn.close()
	if resp_status == 200:
		return simplejson.loads(resp_json)
	return resp_status


def get_site_info(pad):
	post_param = {}	
	post_param["domain"] = pad
	post_param = simplejson.dumps(post_param)
	obj_json = HttpPostConnection(BACKEND_API_SERVER, '/flush/get_site_info/', post_param)

	ret_data = obj_json['data'][0]
	return ret_data

#api 1
#ui for pad detail page
#ui for view current flush usage by pad
def flush_stat_per_pad(site):

	post_param = {}
	post_param["site_id"] = str(site.pk)
	post_param = simplejson.dumps(post_param)
	obj_json = HttpPostConnection(BACKEND_API_SERVER, '/flush/flush_stat_per_pad/', post_param)

	wildcard_cnt = non_wildcard_cnt = max_wildcard_flush = avg_wildcard_flush = max_item_flush = avg_item_flush = 0
	if len(obj_json['data']) > 0:
		wildcard_cnt = obj_json['data'][0]['wildcard_cnt']
		non_wildcard_cnt = obj_json['data'][0]['non_wildcard_cnt']
		max_wildcard_flush = obj_json['data'][0]['max_wildcard_flush']
		avg_wildcard_flush = obj_json['data'][0]['avg_wildcard_flush']
		max_item_flush = obj_json['data'][0]['max_item_flush']
		avg_item_flush = obj_json['data'][0]['avg_item_flush']

	return wildcard_cnt, non_wildcard_cnt, max_wildcard_flush, avg_wildcard_flush, max_item_flush, avg_item_flush


#api 2
# ui for history in flush page
def get_flush_history(content=None, site=None, cui_flush=None, limit=None):
	post_param = {}
	if site:
		if isinstance(site, list):
			post_param["sites"] = [str(id) for id in site]
		else:
			post_param["sites"] = [str(site)]
	if limit:
		post_param["max_result"] = str(limit)
	if content:
		post_param["content"] = content
	if cui_flush:
		post_param["cui_flush_id"] = str(cui_flush)
	post_param = simplejson.dumps(post_param)
	obj_json = HttpPostConnection(BACKEND_API_SERVER, '/flush/flush_history/', post_param)

	try:	
		ret_data = obj_json['data']
	except:
		ret_data = []
	for obj in ret_data:
		obj['create_time'] = datetime.strptime(obj['create_time'], "%Y-%m-%d %H:%M:%S")
	return ret_data


#api 3 
# for ui of result searching by pad (cui) menu : flush status
def list_flush_by_pad(site, requester=None, max_result=20):
	post_param = {}
	if site:
		post_param["sites"] = [str(site.pk)]
	if max_result:
		post_param["max_result"] = str(max_result)
	if requester:
		post_param["requester"] = str(requester)
	post_param = simplejson.dumps(post_param)
	obj_json = HttpPostConnection(BACKEND_API_SERVER, '/flush/list_flush_by_pad/', post_param)
	for obj in obj_json['data']:
		str_user = obj['create_user'].split('(via:')[0].strip()
		obj['create_user'] = str_user if str_user.rfind('aggregated.by.purge_openapi') < 0 else 'Aggregated purge request'
		obj['submitted'] = get_time_for_user_gmt(datetime.strptime(obj['submitted'], "%Y-%m-%d %H:%M:%S"))
		obj['create_time'] = datetime.strptime(obj['create_time'], "%Y-%m-%d %H:%M:%S")
		obj['percent'] = '100.0' if float(obj['percent']) >= site.optimal_ratio else obj['percent']

	return obj_json['data']


#api 4
#ui for ui flush lagging nodes
def get_lagging_nodes():
	post_param = {}
	post_param = simplejson.dumps(post_param)
	obj_json = HttpPostConnection(BACKEND_API_SERVER, '/flush/lagging_nodes/', post_param)

	if len(obj_json['data']) == 0:
		lastest_flush = {'id':0, \
						'create_time':datetime.now().replace(microsecond=0)}
		active_nodes = inactive_nodes = failed_nodes = []
	else:
		lastest_flush = {'id':obj_json['data'][0]['latest_repository_id'], \
							'create_time':datetime.strptime(obj_json['data'][0]['create_time'], "%Y-%m-%d %H:%M:%S")}
		failed_nodes = obj_json['data'][0]['failed_nodes']
		inactive_nodes = obj_json['data'][0]['inactive_nodes']
		active_nodes = obj_json['data'][0]['active_nodes']

		qs = Node.objects.all()
		nodes = {}
		for obj in qs:
			nodes[obj.id] = obj.name
		for obj in active_nodes:
			obj['update_time'] = datetime.strptime(obj['update_time'], "%Y-%m-%d %H:%M:%S")
			obj['node_name'] = nodes.get(obj['node_id'], '')
		for obj in inactive_nodes:
			obj['update_time'] = datetime.strptime(obj['update_time'], "%Y-%m-%d %H:%M:%S")
			obj['node_name'] = nodes.get(obj['node_id'], '')
		for obj in failed_nodes:
			obj['update_time'] = datetime.strptime(obj['update_time'], "%Y-%m-%d %H:%M:%S")
			obj['node_name'] = nodes.get(obj['node_id'], '')

	return lastest_flush, active_nodes, inactive_nodes, failed_nodes

#api 5
#ui for detail flush in OUI
def flush_detail_by_repo_id(repository_id):
	post_param = {}
	post_param["repository_id"] = str(repository_id)
	post_param = simplejson.dumps(post_param)
	obj_json = HttpPostConnection(BACKEND_API_SERVER, '/flush/flush_detail_by_repository_id/', post_param)
	if len(obj_json['data']) > 0:
		ret_data = obj_json['data'][0]
		ret_data['repo_create_time'] = datetime.strptime(ret_data['repo_create_time'], "%Y-%m-%d %H:%M:%S")
		ret_data['current_time'] = get_time_for_user_gmt(datetime.strptime(datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"), "%Y-%m-%d %H:%M:%S"))
		ret_data['req_latest_create_time'] = datetime.strptime(ret_data['req_latest_create_time'], "%Y-%m-%d %H:%M:%S")
		ret_data['req_latest_submitted_time'] = get_time_for_user_gmt(datetime.strptime(ret_data['req_latest_submitted_time'], "%Y-%m-%d %H:%M:%S"))
		ret_data['request_cnt'] = int(ret_data['request_cnt'])
		ret_data['receipt'] = False

		site = Site.objects.get(pk = ret_data['site_id'])
		ret_data['customer'] = site.customer.name
	else:
		ret_data = {}

	return ret_data

#api 6
#ui for flush detail of CUI
def flush_detail_by_req_id(push_request_id):
	post_param = {}
	post_param["push_request_id"] = str(push_request_id)
	post_param = simplejson.dumps(post_param)
	obj_json = HttpPostConnection(BACKEND_API_SERVER, '/flush/flush_detail_by_request_id/', post_param)

	if len(obj_json['data']) > 0:
		ret_data = obj_json['data'][0]
		ret_data['repo_create_time'] = get_time_for_user_gmt(datetime.strptime(ret_data['repo_create_time'], "%Y-%m-%d %H:%M:%S"))
		ret_data['req_create_time'] = get_time_for_user_gmt(datetime.strptime(ret_data['req_create_time'], "%Y-%m-%d %H:%M:%S"))
		ret_data['req_submitted_time'] = get_time_for_user_gmt(datetime.strptime(ret_data['req_submitted_time'], "%Y-%m-%d %H:%M:%S"))
		ret_data['current_time'] = get_time_for_user_gmt(datetime.strptime(datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"), "%Y-%m-%d %H:%M:%S"))
		str_user = ret_data['req_create_user'].split('(via:')[0].strip()
		ret_data['req_create_user'] = str_user if str_user.rfind('aggregated.by.purge_openapi') < 0 else 'Aggregated purge request'
		ret_data['request_cnt'] = int(ret_data.get('request_cnt', 1))
		ret_data['receipt'] = True
		try:
			site = Site.objects.get(pk = ret_data['site_id'])
			ret_data['customer'] = site.customer.name
		except:
			ret_data['customer'] = ''

		ret_data['percent'] = '100.0' if float(ret_data['percent']) >= site.optimal_ratio else ret_data['percent']
	else:
		ret_data = {}

	return ret_data

#api 7
#ui link top flush in OUI flush page 
def list_top_flush_pad(create_time, order_by):
	post_param = {}
	post_param["order_by"] = order_by 
	post_param["create_time"] = str(create_time)[:19]
	post_param = simplejson.dumps(post_param)
	obj_json = HttpPostConnection(BACKEND_API_SERVER, '/flush/list_top_flush_pad/', post_param)
	return obj_json['data']


#api 8
def flush_request_api(site_id, stage, content):
	post_param = {}
	post_param['site_id'] = str(site_id)
	post_param['content'] = simplejson.loads(content) 
	post_param = simplejson.dumps(post_param)
	obj_json = HttpPostConnection(BACKEND_API_SERVER, '/flush/flush_request/', post_param)
	ret_data = obj_json['data'][0]
	push_id = int(ret_data['push_request_id'])
	return push_id 

#api 9 
def check_flush_limit_status(site, items_count, type):
	post_param = {}
	post_param['site'] = str(site.pk)
	post_param['type'] = str(type)
	post_param['items_count'] = str(items_count)
	post_param = simplejson.dumps(post_param)
	obj_json = HttpPostConnection(BACKEND_API_SERVER, '/flush/flush_limit_status/', post_param)
	res_code = int(obj_json['data'][0]['res_code'])
	return res_code

#api 10
def get_near_limit_pads_api(start_date, end_date):
	post_param = {}
	post_param['start_date'] = start_date
	post_param['end_date'] = end_date
	post_param = simplejson.dumps(post_param)
	obj_json = HttpPostConnection(BACKEND_API_SERVER, '/flush/near_limit_pads/', post_param)
	return obj_json['data']


def get_time_for_user_gmt(origin_time):
	delta_gmt_hour = int(get_request().session.get('aurora_gmt_hh', 0))
	return origin_time + timedelta(hours=delta_gmt_hour)