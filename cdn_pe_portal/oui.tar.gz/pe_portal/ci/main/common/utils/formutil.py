"""namespace for functions that help with Django forms
and are not dependent on anything outside the standard libraries."""

import types

def form_list_to_id_set(data):
	"""
	Convert from a form's list of site ids, region ids, whatever, to a
	set of ints, possibly containing the string 'all'
	@param data:  	A list like ['Site_all', 'Site_11', ...]
	@return: 		A set like ['all', 11, ...]
	"""
	numberify = lambda s: 'all' if s == None or str(s).lower().endswith('all') else int(str(s).split('_')[-1])
	try:
		len(data)
	except:
		# data not a sequence
		return set([numberify(data)])
	return set(numberify(s) for s in data)

def id_set_to_form_list(data, prefix):
	"""
	Convert from a sequence of site ids, region ids, whatever, to a list suitable
	as a Form's 'initial' or 'data' argument
	@param data:  	A sequence like ['all', 11, ...]
	@param prefix:	A string like 'Site' or 'Region'
	@return:	  	A list like ['Site_all', 'Site_11', ...]
	"""
	unnumberify = lambda i: '%s_all' % prefix if str(i).lower().endswith('all') else '%s_%d' % (prefix, i)
	try:
		len(data)
	except:
		# data not a sequence
		return []
	return [unnumberify(s) for s in data]

def unsequence(value):
	"""
	@param value:	Anything?
	@return:	   	value[0] if value is a sequence, otherwise value
	"""
	if type(value) in (types.StringType, types.UnicodeType):
		return value
	
	try:
		return value[0]
	except TypeError:
		return value
