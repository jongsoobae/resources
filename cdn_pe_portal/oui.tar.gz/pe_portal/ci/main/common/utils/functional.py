
from types import *

def intersperse(x, list):	# a -> [a] -> [a]
	if len(list) == 0: return []
	newList = []
	for a in list:
		newList.append(a)
		newList.append(x)
	newList.pop()
	return newList

def intercalate(xs, xss, onEmpty):	# [a] -> [[a]] -> [a] -> [a]
	return concat (intersperse (xs, xss), onEmpty)

def com(*funs):  # compose functions from right to left
    fs = list(funs)
    fs.reverse()
    return lambda x: reduce (lambda y,f: f(y), [x] + fs)

def mapf(fun):
    return lambda list: map(fun, list)

def proj(*funs):
    return lambda x: tuple (map (lambda f: f(x), funs))

def it(x):
    return x

def ife(test, true, false):
    if test: return true
    else: return false

def conc(list1, list2):
    return list1 + list2

def concat(lists, onEmpty):		# without onEmpty we don't know what type of empty to return (string or list)
	if len(lists) == 0: return onEmpty
	return reduce(conc, lists)

def unzip(pairs):
    xs = []
    ys = []
    for x, y in pairs:
        xs.append(x)
        ys.append(y)
    return (xs, ys)

def unzip3(triples):
    xs = []
    ys = []
    zs = []
    for x, y, z in triples:
        xs.append(x)
        ys.append(y)
        zs.append(z)
    return (xs, ys, zs)

def And(b1,b2):
    return b1 and b2

def Or(b1,b2):
    return b1 or b2

def andAll(bools):
    return reduce(And, bools, True)

def orAll(bools):
    return reduce(Or, bools, False)

def partition(pred, list):
    yes = []
    no = []
    for x in list:
        if pred(x): yes.append(x)
        else: no.append(x)
    return (yes, no)

def findFirst(pred, list): # (a -> Bool) -> [a] -> Maybe a
    for x in list:
        if pred(x): return x
    return None

def nub(alist):
    return list(set(alist))

def lookup(dict,key):
    try:
        return dict[key]
    except:
        return None

def assocLookup(associationList,key): # [(k,v)] -> k -> Maybe v
	for (k,v) in associationList:
		if k == key: return v
	return None

def lookupIfAbsent(dict,key,otherwiseFun):
    val = lookup(dict,key)
    if val is None: return otherwiseFun(key)
    return val

def fst((x,y)):
    return x

def snd((x,y)):
    return y

def const(val):
    return lambda ignore: val

def at(methodCallExprString):
    return lambda obj: eval("obj.%s" % methodCallExprString)

def groupBy(keyFun, records):
    groups = {}
    for rec in records:
        key = keyFun(rec)
        if key not in groups: groups[key] = []
        groups[key].append(rec)
    return groups

def mapValues(valueFun, dict):
    newDict = {}
    for key, value in dict.iteritems():
        newDict[key] = valueFun(value)
    return newDict

def mapValuesWithKey(keyValueFun, dict):
    newDict = {}
    for key, value in dict.iteritems():
        newDict[key] = keyValueFun(key,value)
    return newDict

def inRange(range,val):
    if range is None:
        return True
    elif type(range) is TupleType:
        (low,high) = range
        return (low is None or low <= val) and (high is None or high >= val)
    elif type(range) is ListType:
        return val in range
    else: # predicate
        return range(val)

def avg(list):
    s = sum(list)
    c = len(list)
    return s / c

def head(list): return list[0]
