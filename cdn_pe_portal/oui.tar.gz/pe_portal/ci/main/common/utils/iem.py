"""
Methods for sending mail. For basic mail sending functionality, you should probably use
django.core.mail instead, but the send_email method below handles attachments.
"""

from django.utils.encoding import smart_unicode
from django.conf import settings
import httplib, urllib
import socket
import time

URL_IEM = "iel.cdnetworks.com"
PARAM_IEM = {'MonitoringAgent':'16','ObjectValue':'91', 'DeviceName':'s1445-lot1-sel', 'EventLevel':'30', 'EventTimestamp':'1271839200', 'ObjectName' :'OUI DashboardItem'}

def send_iem(level, oval, msg):
	try :
		param = PARAM_IEM
		tmp = "%f"%time.time()
		param['EventLevel'] = level
		param['EventTimestamp'] = tmp.split(".")[0]
		param['DeviceName'] = socket.gethostname()
		param['ObjectValue'] = oval
		param['ObjectRawMessage'] = msg

		print "param : ", param

		param = urllib.urlencode(param)
		conn = httplib.HTTPConnection(URL_IEM)
		headers = {"Content-type": "application/x-www-form-urlencoded","Accept": "text/plain"}
		conn.request("POST", "/spider/event/ReceiveEvent.jsp", param, headers)
		response = conn.getresponse()
		print response.status, response.reason
	except Exception, e:
		print "[%s] exception : [%s]"%(sys._getframe().f_code.co_name, str(e))
		return
