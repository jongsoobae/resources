from ci.common.models.invoice import Invoice
from ci.common.models.adjustment import InvoiceAdjustment
from ci.common.models.billing import BillRate
from ci.common.utils.edit_adjustment import EditAdjustmentForm
from ci.common.utils import render_response
from ci.common.utils.api import HttpResponseAPISafe
from ci.constants import BASE_DIR
import popen2
import time, calendar
from django.http import HttpResponseRedirect
from django.utils.datastructures import SortedDict
from django.forms.forms import BoundField
from django import forms
from django.core.urlresolvers import reverse
from datetime import datetime, timedelta

class SiteRateChoice(forms.ChoiceField):
	def __init__(self, choices, label, rate_charge, volume, is_first, is_last, initial, enabled=True):
		"""
		Shows the BillRates that can be applied for one Site, and holds extra
		info for the template.
		@param choices:	 A sequence of (id, name)
		@param label:	   What to label this choice field
		@param rate_charge:     A RateCharge instance, applicable to this Site
		@param volume:	  This Site's GB this month or 95th-percentile mbps, depending
							on the BillRate
		@param is_first:	True if this is the first Site billed at this rate
		@param is_last:	 True if this is the last Site billed at this rate
		@param initial:	 The id of the Site's current BillRate
		@param enabled:	 If False, this widget is read-only (for published invoices)
		"""
		self.rate_charge	= rate_charge
		self.volume		     = volume
		self.is_first	   = is_first
		self.is_last	    = is_last
		self.type		       = 'site_rate'
		self.enabled	    = enabled
		super(SiteRateChoice, self).__init__(choices=choices, label=label, initial=initial)

	def widget_attrs(self, widget):
		return {} if self.enabled else {'disabled': 'disabled'}

class InvoiceDetailForm(EditAdjustmentForm):
	class Meta:
		model = Invoice
		fields = ['id']
		# this short fields list is a hack. EditAdjustmentForm is a ModelForm because CustomerForm requires it;
		# however, InvoiceDetailForm isn't a ModelForm. Even though it works with an instance of Invoice, it
		# only modifies the relationships between that invoice and adjustments and rates, not any properties of
		# the invoice itself. So the fields list should really be empty. Django doesn't like that, however, so
		# we stick the id field in the list, and insert it into the data dictionary manually when using the
		# form so that it doesn't complain about missing fields.
	def __init__(self, *args, **kwargs):
		self.invoice = kwargs['instance']

		super(InvoiceDetailForm, self).__init__(
			enabled=not self.invoice.published,
			is_intl=self.invoice.is_intl,
			currency=self.invoice.rate.currency,
			adjustments=self.invoice.invoice_adjustment_set.all(),
			*args,
			**kwargs
		)

		# ------[ Create dropdown lists to select per-site rates ]-------------
		self._site_rates = SortedDict()

		rate_choices = [(rate.id, '%s [id %d]' % (rate.description, rate.id)) for rate in BillRate.objects.order_by('description')]
		for rate_charge in self.invoice.new_rate_charges:
			site_volumes = rate_charge.site_volumes
			for i, (site, volume) in enumerate(sorted(
				site_volumes,
				lambda a, b: cmp(a[0].pad, b[0].pad)
			)):
				self._site_rates['site_' + str(site.id)] = SiteRateChoice(
					choices	 = rate_choices,
					label	   = site.pad,
					rate_charge     = rate_charge,
					volume	  = volume,
					is_first	= i == 0,
					is_last	 = i == len(site_volumes) - 1,
					initial	 = rate_charge.rate.id,
					enabled	 = not self.invoice.published
				)

		self.fields.update(self._site_rates)

	def site_rates(self):
		"""
		@return:	Iterator, sequence of bound SiteRateChoices
		"""
		for name, field in self._site_rates.items():
			yield BoundField(self, field, name)

	def save(self):
		"""
		Save the changes to site rates for this invoice. This method does not save any changes
		on the Invoice model itself, only its relationships to rates.
		"""
		# Process changes to per-site rates and adjustments
		for key, value in self.cleaned_data.items():
			if key.lower().startswith('site_'):
				site_id = int(key.split('_')[-1])
				rate_for_site = self.invoice.rate_for_site(site_id)
				if rate_for_site and rate_for_site.id != int(value):
					# Don't hit the DB, the site is already in invoice.sites list
					site = [site for site in self.invoice.sites if site.id == int(site_id)][0]

					# Change the rate applied to this Site for this Invoice
					rate = BillRate.objects.get(id=value)
					self.invoice.set_rate_for_site_and_save(site, rate)

					# Make this the default rate for future Invoices, too
					site.default_rate = rate
					site.save()

		self.save_adjustments(self.invoice, 'invoice_adjustment_set')

def raw_invoice_detail(request, object_id, is_pdf):
	# FIXME is is_pdf necessary?
	redirect = lambda: HttpResponseRedirect(reverse('invoice_detail', args=[object_id]))

	invoice = Invoice.objects.get(id=object_id)

	if request.method == 'POST':
		# Can't modify published Invoice; the form should be disabled, but just in case
		if invoice.published: return redirect()
		post = request.POST.copy()
		post.update({'id': invoice.id})
		invoice_detail_form = InvoiceDetailForm(data=post, instance=invoice)

		if invoice_detail_form.is_valid():
			invoice_detail_form.save()
			return redirect()
	else:
		# Request is a GET
		invoice_detail_form = InvoiceDetailForm(instance=invoice)
	invoice_date = invoice.month.date()
	if invoice_date.month<12:
		num_days_in_month = calendar.mdays[invoice_date.month+1]
		due_date = invoice_date.replace(month=invoice_date.month+1, day=num_days_in_month)
		try:
			late_date = due_date.replace(day=invoice_date.day+14, month=invoice_date.month+2).strftime("%B %d, %Y")
		except ValueError:
			late_date = due_date.replace(day=invoice_date.day+14, month=1).strftime("%B %d, %Y")
	else: #special case for December. Because the calendar module is not that smart
		num_days_in_month = calendar.mdays[1]
		due_date = invoice_date.replace(month=1, day=num_days_in_month)
		late_date = due_date.replace(day=invoice_date.day+14, month=2).strftime("%B %d, %Y")
	due_date = due_date.strftime("%B %d, %Y")
	context = {
		'invoice': invoice,
		'invoice_detail_form': invoice_detail_form,
		'currency': invoice.rate.currency.html_symbol,
		'sales_rep': invoice.customer.sales_rep,
		'addr': invoice.customer.address,
		'is_pdf': is_pdf,
		'due_date': due_date,
		'late_date': late_date
	}

	return render_response(request, 'invoice_detail.html', context)

def raw_invoice_pdf(request, object_id):
	html = raw_invoice_detail(request, object_id, True).content
	margin = '.5in'
	child_stdout, child_stdin = popen2.popen2(
		'htmldoc -v -t pdf --top "%s" --bottom "%s" --left "%s" --right "%s" --path "%s" --webpage --size letter -' % (
			margin, margin, margin, margin, BASE_DIR
		)
	)
	child_stdin.write(html.decode('utf8').encode('ascii', 'xmlcharrefreplace'))
	child_stdin.close()
	ret = child_stdout.read()
	child_stdout.close()
	return ret

def raw_invoice_detail_pdf(request, object_id):
	response = HttpResponseAPISafe(raw_invoice_pdf(request, object_id), mimetype='application/pdf')
	invoice = Invoice.objects.get(pk=object_id)
	response['Content-Disposition'] = 'attachment; filename="%s - CDNetworks - Invoice for %s.pdf"' % \
		(invoice.customer.name.encode("ascii", "ignore"), time.strftime('%B %Y', invoice.month.timetuple()))
	return response
