def int4BytesLE(n):
	if n < 0: return int4BytesLE(2 ** 32 + n)
	bytes = [0,0,0,0]
	for i in range(4):
		b = n % 256
		bytes[i] = b
		n = n / 256
	return bytes

def int4BytesBE(n):
	bytes = int4BytesLE(n)
	bytes.reverse()
	return bytes

def bytesBEInt4(bytes):
	if len(bytes) > 4:
		raise Exception, "expected no more than four bytes"
	n = 0
	for b in bytes:
		n = n * 256
		n = n + b
	if n >= 2 ** 31:
		n = n - 2 ** 32
	return n

def ipStringToInt(string):
	bytes = map(int,string.split('.'))
	return bytesBEInt4(bytes)

def ipIntToString(n):
	return '.'.join(map(str,int4BytesBE(n)))
