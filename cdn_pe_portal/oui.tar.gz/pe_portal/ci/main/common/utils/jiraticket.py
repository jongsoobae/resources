from django import forms
from django.template import Context
from django.template.loader import get_template
from django.utils.encoding import smart_unicode
from ci.constants import SUPPORT_ADDR
from ci.common.utils import get_customer
from ci.common.utils.supporttools import supporttoolsTestFileSubmission
from ci.common.utils.mail import send_email
# from ci.common.utils import JiraClient

# def getSupportForm(*args, **kwargs):
# 	"""return a SupportForm class instance"""
# 	try:
# 		jira = JiraClient.JiraClient()
# 		issueTypes = jira.GetSupportIssueTypes()
# 	except Exception:
# 		issueTypes = {JiraClient.DEFAULT_ISSUE_ID : JiraClient.DEFAULT_ISSUE_TYPE}
# 
issueTypes = {}
class SupportForm(forms.Form):
	urgent = forms.BooleanField(widget=forms.CheckboxInput(attrs={'class':'normal'}), required=False)
	issue = forms.ChoiceField(
		label = 'Issue Type',
		# looks ugly, but basically we want:
		# <OPTION VALUE="17: Flush Request">Flush Request</OPTION>
		choices = sorted([(key, issueTypes[key]) for key in issueTypes.keys()], key=lambda e:e[1])
	)
	subject = forms.CharField(max_length=200)
	message = forms.CharField(widget=forms.Textarea(attrs={'rows':16}))
	test_file = forms.CharField(max_length=2000, required=False)

	# return SupportForm(*args, **kwargs)
	
def create_support_ticket(post, request,  ip, useragent):
	"""Takes a QuerySet object (POST or GET) and creates a ticket.

	@return: str of ticket name if successfully or the invalid SupportForm if failed.
	"""
	user = request.user
	if post:
		support_form = getSupportForm(post, auto_id='supportform_%s')
		
		if support_form.is_valid():
			
			# message parts
			subject = support_form.cleaned_data['subject']
			message = support_form.cleaned_data['message']
			urgent = support_form.cleaned_data['urgent']
			test_file = support_form.cleaned_data['test_file']
			issuetypeid = support_form.cleaned_data['issue']
			issuestring = dict(support_form.fields['issue'].choices)[issuetypeid]
			test_page = None
			# send email
			full_subject = '[%s] %s' % (get_customer(request), subject)
			full_message = u'sent by %s %s (%s) for %s:\n\n%s\n\nIP: %s\nUser agent: %s\nTest URL: %s' \
				% (
					smart_unicode(user.first_name), 
					smart_unicode(user.last_name), 
					user.email, get_customer(request), message, ip, useragent, test_file or 'Not Provided')
			
			# issuekey = JiraClient.make_jira_issue(full_subject, full_message, issuetypeid, issuestring, urgent=urgent, user=user)
			# if issuekey:
			# 	full_message = 'JIRA issue: %s%s\n%s' % (JiraClient.BROWSE_URL, issuekey, full_message)
			if issuekey and test_file and False: #this comments out new code until its ready to be turned on
				resp = supporttoolsTestFileSubmission(test_file, issuekey, request)

				if resp.get('request_key'):
					test_page = 'Test Page: http://www.pantherexpress.net/test-file/%s' \
						% ( resp.get('request_key'))
					full_message += '\n' + test_page

			send_email(SUPPORT_ADDR, [SUPPORT_ADDR], full_subject, full_message, reply_to=user.email)
			confirmation = get_template('email/support_confirmation.html').render(Context({
				'user': user,
				'urgent': urgent,
				'issuekey': issuekey,
				'test_page': test_page,
			}))
			send_email(SUPPORT_ADDR, [user.email], '[Panther] Support request confirmation', confirmation)
			return issuekey			
			
	else:
		support_form = SupportForm(auto_id='supportform_%s')
	return support_form

