from ci.common.utils import simplejson as sjson


def json_load_ordered(json_string):
    return sjson.loads(json_string, object_pairs_hook=sjson.OrderedDict)

