#!/usr/local/bin/python
# -*- coding: euc-kr -*-

import sys
import os
import time
import logging
from logging import handlers, Formatter
from ci.common.models import UseLogByUser

def init_log(logger, log_file, level):
#	logger = logging.getLogger(appname)
	info = os.path.split(log_file)
	if(not os.path.exists(info[0])) :
		os.makedirs(info[0])

	hdlr = handlers.RotatingFileHandler(log_file, maxBytes=100000000, backupCount=5)
	formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
	hdlr.setFormatter(formatter)
	logger.addHandler(hdlr)
	logger.setLevel(level)

def use_log_by_user(user, url_function=None, desc=None):
	if True:
		return
	try:
		uselog_obj = UseLogByUser(user_id=user.pk, url_function=url_function, desc=desc)
		uselog_obj.save()
	except:
		pass

			
	
