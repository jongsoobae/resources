"""
Methods for sending mail. For basic mail sending functionality, you should probably use
django.core.mail instead, but the send_email method below handles attachments.
"""

from django.utils.encoding import smart_unicode
from django.conf import settings
from email import Encoders
from email.Header import Header
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
from email.Utils import parseaddr, formataddr
from smtplib import SMTP
from ci.constants import SEND_EMAIL

SMTP_HOST = settings.EMAIL_HOST

def send_raw_email(from_addr, to_addrs, msg, debuglevel=False):
	if not SEND_EMAIL:
		return msg
	
	server = SMTP(SMTP_HOST)
	server.set_debuglevel(debuglevel)
	# it's necessary to first ensure the string is unicode before downgrading it to ascii.
	if type(msg) != unicode:
		try:
			msg = unicode(msg, errors='replace')
		except:
			pass
	server.sendmail(from_addr, to_addrs, msg.encode('utf8','replace'))
	server.quit()


def send_email(sender, recipients, subject, body, reply_to=None, bcc=[], attachments=[]):
	"""Send an email, optionally with attachments.
	
	sender, reply_to: ASCII string.
	recipients, bcc: list of ASCII strings.
	subject, body: Unicode string.
	attachments: list of tuples (file_name, file_contents)
	
	The charset of the email will be the first one out of US-ASCII, ISO-8859-1
	and UTF-8 that can represent all the characters occurring in the email.
	
	Credit: http://mg.pov.lt/blog/unicode-emails-in-python.html
	"""
	if type(recipients) != list:
		recipients = [recipients]
	else:
		recipients = recipients[:]
	body = smart_unicode(body)
	subject = smart_unicode(subject)
	# Header class is smart enough to try US-ASCII, then the charset we
	# provide, then fall back to UTF-8.
	header_charset = 'ISO-8859-1'
	
	# We must choose the body charset manually
	for body_charset in 'US-ASCII', 'ISO-8859-1', 'UTF-8':
		try:
			body.encode(body_charset)
		except UnicodeError:
			pass
		else:
			break

	# Create the message ('plain' stands for Content-Type: text/plain)
	msg = MIMEText(body.encode(body_charset), 'plain', body_charset)
			
	if attachments:
		msg_text = msg
		msg = MIMEMultipart()
		msg.attach(msg_text)
	  	for filename, content in attachments:
			part = MIMEBase('application','octet-stream')
			part.set_payload(content)
			Encoders.encode_base64(part)
			part.add_header('Content-Disposition', 'attachment; filename="%s"' % filename)
			msg.attach(part)
	
	msg['From'] = sender
	msg['To'] = ', '.join(recipients)
	msg['Subject'] = Header(unicode(subject), header_charset)
	if reply_to:
		msg['Reply-To'] = reply_to
	if bcc:
		recipients += bcc
	
	if SEND_EMAIL:
		smtp = SMTP(SMTP_HOST)
		smtp.sendmail(sender, recipients, msg.as_string())
		smtp.quit()
	else:
		return msg.as_string()

