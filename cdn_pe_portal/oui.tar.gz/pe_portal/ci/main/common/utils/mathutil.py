"""namespace for functions that perform mathematical transformations
and are not dependent on anything outside the standard libraries."""

def bytes_to_mbps(bytes):
	"""given total bytes in a 5-minute period, return average mbps"""
	return bytes * 8 / 300. / 1000000.

def find_95th(lst):
	lst_copy = lst[:]
	lst_copy.sort()
	return lst_copy[int(len(lst_copy)*.95)]

def convert_currency(source_dollar_equiv, target_dollar_equiv, value):
	"""
	@param source_dollar_equiv:		The Currency.dollar_equiv of the value's currency
	@param target_dollar_equiv:		The Currency.dollar_equiv the desired currency
	@param value:					A monetary value to convert
	>>> # Convert from euros to pounds
	>>> import Currency
	>>> convert_currency(
	... 	1,
	... 	Currency.objects.get(description='euro')).dollar_equiv,
	... 	12.50 # value in dollars
	... )
	23.12 # value in euros
	>>> convert_currency(
	... 	Currency.objects.get(description='pound')).dollar_equiv,
	... 	Currency.objects.get(description='euro')).dollar_equiv,
	... 	42.00 # value in pounds
	... )
	62.38
	"""
	return (float(value) * float(source_dollar_equiv)) / float(target_dollar_equiv)
