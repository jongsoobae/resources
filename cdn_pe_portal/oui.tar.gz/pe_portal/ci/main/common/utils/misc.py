# assorted small (non-CDN-specific) utilities go in this file
import time
import logging
from datetime import datetime
import string
from django.utils.encoding import smart_unicode

KEYNOTFOUND = '<KEYNOTFOUND>'       # KeyNotFound for dictDiff

def dict_diff(first, second, ignored_fields=[]):
    """ Return a dict of keys that differ with another config object.  If a value is
        not found in one fo the configs, it will be represented by KEYNOTFOUND.
        @param first:   Fist dictionary to diff.
        @param second:  Second dicationary to diff.
        @return diff:   Dict of Key => (first.val, second.val)
    """
    diff = {}
    # Check all keys in first dict
    for key in first.keys():
        if (not second.has_key(key)):
            diff[key] = (first[key], KEYNOTFOUND)
        elif (first[key] != second[key]):
            if key not in ignored_fields:
                diff[key] = (first[key], second[key])
    # Check all keys in second dict to find missing
    for key in second.keys():
        if (not first.has_key(key)):
            diff[key] = (KEYNOTFOUND, second[key])
    return diff

def get_elapsed_total_seconds(recent_date, past_date):
    """
    In python 2.7 you can do as: (datetime.now() - site_events[0].create_time).total_seconds()
    :param recent_date:
    :param past_date:
    :return:
    """
    from_dt = recent_date if isinstance(recent_date, datetime) else datetime.strptime(recent_date, '%Y-%m-%d %H:%M')
    to_dt = past_date if isinstance(past_date, datetime) else datetime.strptime(past_date, '%Y-%m-%d %H:%M')
    diff_obj = from_dt - to_dt
    total_seconds = diff_obj.days * 24 * 3600 + diff_obj.seconds
    return total_seconds

def list_contains(plist,sublist):
    return str(plist)[1:-1].find(str(sublist)[1:-1]) >= 0

def padded_cop_product_id(contract_no):
    try:
        temps = contract_no.split('-')
        return "%s-%s" % (temps[0].zfill(10), temps[1].zfill(6))
    except:
        return contract_no

def make_csv_row(val_tuple):
    """take in a tuple of values and return it as a string in csv format 
    This was created because the built in python csv library deos not support unicode"""
    csv_string = ""
    for value in val_tuple:
        string_val = smart_unicode(value)
        string_val.replace('"','"""' )
        csv_string += ',"' + string_val + '"'
    csv_string+='\n'
    return csv_string[1:]

def get_session_from_id(session_id):
    "given a django session id, e.g. from a server error email, get the session object."
    import base64, cPickle
    from django.contrib.sessions.models import Session
    from django.contrib.auth.models import User
    data = cPickle.loads(base64.decodestring(Session.objects.get(session_key=session_id).session_data)[:-32])
    return data, User.objects.get(pk=data['_auth_user_id'])

class curry:
    def __init__(self, fun, *args, **kwargs):
        self.fun = fun
        self.pending = args[:]
        self.kwargs = kwargs.copy()

    def __call__(self, *args, **kwargs):
        if kwargs and self.kwargs:
            kw = self.kwargs.copy()
            kw.update(kwargs)
        else:
            kw = kwargs or self.kwargs
        return self.fun(*(self.pending + args), **kw)

def mysql_now():
    return time.strftime('%Y-%m-%d %H:%M:%S')

def datetimeToEpochTime(dtime):
    return int(time.mktime(dtime.timetuple()))

def epochTimeToDatetime(n):
    return datetime.fromtimestamp(n)

def timeP(intervalSecs, dtime):
    """return the interval/period start time of this specific time. Eg. timeP(300,datetime(10:07:32)) == datetime(10:05)"""
    epochSecs = datetimeToEpochTime(dtime)
    epochIntervalSecs = (epochSecs / intervalSecs) * intervalSecs
    return epochTimeToDatetime(epochIntervalSecs)

def blank(string):
    return len(string) == 0 or string.isspace()

def binarySearch (sortedList, item):  # return (True, index) or (False, indexAbove)
    low = 0
    high = len(sortedList) - 1
    while True:
        if low > high:
            return (False, low)
        mid = (low + high) / 2
        if item == sortedList[mid]:
            return (True, mid)
        if item < sortedList[mid]:
            high = mid - 1
        else:
            low = mid + 1

def short_hostname(hostname):
    try:
        if len(hostname.split('.')) > 2:
            return hostname[:hostname.rfind('.',0,hostname.rfind('.'))]
        else:
            return hostname
    except:
        return hostname

def full_cdn_hostname(hostname):
    try:
        if len(hostname.split('.')) == 2:
            return "%s.cdngp.net" % (hostname)
        else:
            return hostname
    except:
        return hostname

def get_request_initiator(request):
    """
    return who initiated the request
    :param request:
    :return: one of 'ocsp','aurora','cui'
    """
    if request.session.get('aurora_user'):
        if request.session.get('aurora_user_id') == '':
            return 'ocsp'
        else:
            return 'aurora'
    else:
        return 'cui'