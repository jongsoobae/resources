from random import randrange 
from httplib import HTTPSConnection
from xml.dom import minidom
from urllib import urlencode
from ci.constants import OCSP_API_SERVERS, OCSP_USER, OCSP_PASS, MAINTAINER, PORTAL_INTEGRATION
from ci.common.utils.mail import send_email

ocsp_response_codes = {0:"Successful",
			101: "Duplicated PE Customer Key",
			102: "Duplicated PE Customer Name",
			201: "Duplicated PE User Key",
			202: "Duplicated PE User e-mail",
			301: "Duplicated PE Service Name (domain+path)",
			302: "Duplicated PE Keyword (sid+path)",
			303: "Duplicate PE Service Key",
			400: "More input needed. Check your input",
			404: "No Changes. There are no data which are coincident",
			999: "Temporary error",
			-1: "Error connecting to server",
			-2: "Error obtaining response code",
}

def ocsp_user_add(service_country, user, password):
	uri = "/ocsp/services/Admin/addPeUser"
	params = {'user': OCSP_USER, 'pass': OCSP_PASS, 'ckey': user.userprofile.customer.id, 'ukey': user.id, 'uname': "%s^%s" %(user.first_name,user.last_name), 'email': user.email, 'upass': password}
	return ocspCall(service_country, uri, params)[0]

def ocsp_user_update(service_country, user, password=None):
	uri = "/ocsp/services/Admin/updatePeUser"
	params = {'user': OCSP_USER, 'pass': OCSP_PASS, 'ckey': user.userprofile.customer.id, 'ukey': user.id, 'uname': "%s^%s" %(user.first_name,user.last_name), 'email': user.email}
	if password:
		params['upass'] = password
	return ocspCall(service_country, uri, params, acceptableResponses=[0,404])[0]

def ocsp_domain_add(service_country, site, path=None, path_id=None):
	uri = "/ocsp/services/Admin/addPeStatPath"
	params = {'user': OCSP_USER, 'pass': OCSP_PASS, 'ckey': site.customer.id, 'spkey': str(site.id) + ("-" + path_id if path and path_id else ""), 'domain': site.pad, 'sid': site.id}
	if path and path_id:
		params['path'] = path
	return ocspCall(service_country, uri, params, acceptableResponses=[0,301])[0]

def ocsp_domain_update(service_country, site, path=None, path_id = None):
	if not site.status:
		return ocsp_domain_deactivate(service_country, site, path_id=path_id)
	uri = "/ocsp/services/Admin/updatePeStatPath"
	params = {'user': OCSP_USER, 'pass': OCSP_PASS, 'spkey': str(site.id) + ("-" + path_id if path and path_id else ""), 'domain': site.pad, 'sid': site.id}
	if path and path_id:
		params['path'] = path
	success, code = ocspCall(service_country, uri, params, acceptableResponses=[0,301,404])
	if code == 404:
		return ocsp_domain_add(service_country, site, path=path, path_id=path_id)
	return success

def ocsp_domain_deactivate(service_country, site, path_id = None):
	uri = "/ocsp/services/Admin/deactivatePeStatPath"
	params = {'user': OCSP_USER, 'pass': OCSP_PASS, 'spkey': str(site.id) + ("-" + path_id if path_id else "")}
	return ocspCall(service_country, uri, params)[0]

def ocsp_customer_add(service_country, customer, billing_country):
	uri = "/ocsp/services/Admin/addPeCustomer"
	bcodes = {1:'US',2:'KR',3:'CN',4:'JP'}
	params = {'user': OCSP_USER, 'pass': OCSP_PASS, 'ckey': customer.id, 'cname': customer.name, 'bcode': bcodes.get(billing_country,''), 'migration': 0 if customer.cdnetworks_customer else 1}
	ret = ocspCall(service_country, uri, params)
	if ret[0]:
		#now sync all sites...
		for site in customer.site_set.filter(status=True):
			ocsp_domain_add(service_country, site)
		#now sync all users...
		def randchar():
			return chr(randrange(65,122,1))
		for user in customer.users():
			ocsp_user_add(service_country, user, randchar() + randchar() + randchar() + randchar() + randchar() + randchar() + randchar() + randchar())
	return ret[0]

def ocsp_customer_update(service_country, customer, billing_country=None):
	uri = "/ocsp/services/Admin/updatePeCustomer"
	params = {'user': OCSP_USER, 'pass': OCSP_PASS, 'ckey': customer.id, 'cname': customer.name, 'migration': 0 if customer.cdnetworks_customer else 1, 'bcode': ''}
	if billing_country:
		params['billing_country']
	return ocspCall(service_country, uri, params)[0]

def ocspCall(service_country, uri, postParams, acceptableResponses=[0]):
	resp = -2
	data = ""
	error = None
	server = ""
	final_uri = ""
	try:
		if OCSP_API_SERVERS in ['', None]:
			#this is here for cop mode
			return (True, 0)
		server = OCSP_API_SERVERS[int(service_country)]
		if server in ['', None]:
			#this is here for partial cop mode
			return (True, 0)
		final_uri = "%s?%s" %(uri, urlencode(postParams))
		conn = HTTPSConnection(server)
		conn.request("GET",  final_uri)
		data = conn.getresponse().read()
		resp = int(minidom.parseString(data).getElementsByTagName("ns:return").item(0).lastChild.nodeValue)
		#need to parse resp to get code...
	except Exception, e:
		resp = -1
		error = e
	if resp not in acceptableResponses:
		message = "URL: %s%s\nResponse Code: %d\nResponse Description: %s\nFull Response:\n%s\nError:%s" %(server, final_uri, resp, ocsp_response_codes.get(resp) if ocsp_response_codes.has_key(resp) else "Unknown Response", data, error if error else "N/A")
		send_email(MAINTAINER, PORTAL_INTEGRATION, '[Django] error occurred synching to OCSP portal', message)
		return (False,resp)
	return (True,resp)
