from django.db import connections
from datetime import datetime, timedelta
from numpy import array
from ci.common.utils.mathutil import find_95th


class ChartType:
	def __init__(self, name, label, traffic_tables, factor, total_label, operator="", num_format="%.0f", total_factor=1,
				 extra_filter="", group_by_key=False, percentage=False, maximum=False):
		self.name = name
		self.label = label
		self.traffic_tables = traffic_tables
		self.factor = factor
		self.total_label = total_label
		self.operator = operator
		self.num_format = num_format
		self.total_factor = total_factor
		self.extra_filter = extra_filter
		self.group_by_key = group_by_key
		self.percentage = percentage
		self.maximum = maximum


class SplitByOption:
	def __init__(self, name, label, columns):
		self.name = name
		self.label = label
		self.columns = columns


CHART_FOR_HTTP1_BYTES = ChartType(
	name='ssl_bytes_h1', label='SSL Bytes(HTTP/1.x)',
	traffic_tables=('one_stat.tb_site_method_requests', 'one_stat.tb_traffic_edge_h2_bytes',),
	factor=8./(5.*60*1000000), total_label='GB transferred',num_format="2",
	total_factor=1./(1000**3), operator="-",
	extra_filter=("key_value = 'SSL_BYTES'", "", ))

CHART_FOR_HTTP2_BYTES = ChartType(
	'ssl_bytes_h2', 'SSL Bytes(HTTP/2)',('one_stat.tb_traffic_edge_h2_bytes',), 8./(5.*60*1000000), 'GB transferred',
	num_format="2", total_factor=1./(1000**3), )


CHART_FOR_HTTP1_ITEMS = ChartType(
	name='ssl_items_h1', label='SSL Hit Total(HTTP/1)',
	traffic_tables=('one_stat.tb_traffic_edge_ssl_requests', 'one_stat.tb_traffic_edge_h2_requests',),
	factor=1/(5.*60), total_label='total hits',num_format="2",
	total_factor=1, operator="-",)

CHART_FOR_HTTP2_ITEMS = ChartType('ssl_items_h2', 'SSL Hit Total(HTTP/2)',
								  ('one_stat.tb_traffic_edge_h2_requests',), factor=1/(5.*60),
								  total_label='Total hits', num_format="2", total_factor=1, )


chart_types = [
		ChartType('Mbps', 'Mbps', ('one_stat.tb_traffic_edge_bytes',), 8./(5.*60*1000000), 'GB transferred',num_format="2", total_factor=1./(1000**3) ),
		ChartType('Hits_Sec', 'Hits/Sec', ('one_stat.tb_traffic_edge_requests',), 1/(5.*60), 'total hits',num_format="2", total_factor=1 ),
		ChartType('mbps_from_origin', 'Origin Mbps', ('one_stat.tb_traffic_origin_bytes',), 8./(5.*60*1000000),
				  'GB transferred', num_format="2", total_factor=1./(1000**3) ),
		ChartType('hits_per_sec_from_origin', 'Origin Hits/Sec', ('one_stat.tb_traffic_origin_requests',), 1/(5.*60),
				  'total hits',num_format="2", total_factor=1 ),
		CHART_FOR_HTTP1_BYTES,
		CHART_FOR_HTTP2_BYTES,
		ChartType(name='ssl_bytes_total_http12', label='SSL Bytes Total(HTTP/1.X vs HTTP/2)',
				  traffic_tables=('',), factor=8./(5.*60*1000000), total_label='GB transferred',
				  num_format="2", total_factor=1./(1000**3), group_by_key=True),
		ChartType(name='ssl_items_total_http12', label='SSL Hit Total(HTTP/1.X vs HTTP/2)',
				  traffic_tables=('',), factor=1/(5.*60), total_label='total hits',
				  num_format="2", total_factor=1, group_by_key=True),
		ChartType('pct_data_from_cache', 'Cache Miss % (by Mbps)', ('one_stat.tb_traffic_origin_bytes', 'one_stat.tb_traffic_edge_bytes'), 100,
				  'Total of avg', operator="/", num_format="2", total_factor=100, percentage=True, maximum=100),
		ChartType('pct_hits_per_sec_from_cache', 'Cache Miss % (by Hits)', ('one_stat.tb_traffic_origin_requests', 'one_stat.tb_traffic_edge_requests'), 100,
				  'Total of avg', operator="/", num_format="2", total_factor=100, percentage=True, maximum=100),
		ChartType('Average_Object_Size_kb', 'Average Object Size (kb)', ('one_stat.tb_traffic_edge_bytes', 'one_stat.tb_traffic_edge_requests'), 0.001,
				  'Mb (Total of avg)', operator="/", num_format="2", total_factor=0.001, percentage=True),
		ChartType('avg_object_size_from_origin', 'Average objects size fetched from origin (kb)', ('one_stat.tb_traffic_origin_bytes', 'one_stat.tb_traffic_origin_requests'), 0.001,
				  'Mb (Total of avg)', operator="/", num_format="2", total_factor=0.001, percentage=True),
		ChartType('Hits_Sec_by_Response_Code', 'Hits/Sec by Response Code', ('one_stat.tb_site_response_code_requests',), 1/(5.*60),
				  'total hits',num_format="2", total_factor=1, group_by_key=True),
		ChartType('responses_per_sec_20x', '20x Hits/Sec', ('one_stat.tb_site_response_code_requests',), 1/(5.*60), 'total hits',
				  num_format="2", total_factor=1, extra_filter="key_value like '2%%'"),
		ChartType('responses_per_sec_30x', '30x Hits/Sec', ('one_stat.tb_site_response_code_requests',), 1/(5.*60), 'total hits',
				  num_format="2", total_factor=1, extra_filter="key_value like '3%%'"),
		ChartType('responses_per_sec_40x', '40x Hits/Sec', ('one_stat.tb_site_response_code_requests',), 1/(5.*60), 'total hits',
				  num_format="2", total_factor=1, extra_filter="key_value like '4%%'"),
		ChartType('responses_per_sec_50x', '50x Hits/Sec', ('one_stat.tb_site_response_code_requests',), 1/(5.*60), 'total hits',
				  num_format="2", total_factor=1, extra_filter="key_value like '5%%'"),
		ChartType('responses_per_sec_504', 'Error to Origin (50x) Hits/Sec', ('one_stat.tb_site_response_code_requests',), 1/(5.*60), 'total hits',
				  num_format="2", total_factor=1, extra_filter="key_value = '504'"),
		ChartType('responses_per_sec_505', 'Internal CDN Error (50x) Hits/Sec', ('one_stat.tb_site_response_code_requests',), 1/(5.*60), 'total hits',
				  num_format="2", total_factor=1, extra_filter="key_value = '505'"),
		ChartType('responses_per_sec_external_50x', 'External Error (50x) Hits/Sec', ('one_stat.tb_site_response_code_requests',), 1/(5.*60), 'total hits',
				  num_format="2", total_factor=1, extra_filter="key_value like '5%%' and key_value != '504' and key_value != '505'"),
		ChartType('Hits_Sec_by_Method', 'Hits/Sec by Method', ('one_stat.tb_site_method_requests',), 1/(5.*60), 'total hits',
				  num_format="2", total_factor=1, group_by_key=True, extra_filter="key_value <> 'SSL_BYTES'"),

		######################################################################################################

		ChartType('Shield_Mbps_for_Dynamic', 'Shield Mbps for Dynamic', ('one_stat.tb_traffic_shield_dynamic_bytes',), 8./(5.*60*1000000), 'GB transferred',num_format="2", total_factor=1./(1000**3) ),
		ChartType('Shield_Mbps', 'Shield Mbps', ('one_stat.tb_traffic_shield_outbound_bytes',), 8./(5.*60*1000000), 'GB transferred',num_format="2", total_factor=1./(1000**3) ),
		ChartType('Shield_Mbps_for_Static', 'Shield Mbps for Static', ('one_stat.tb_traffic_shield_outbound_bytes','one_stat.tb_traffic_shield_dynamic_bytes',), 8./(5.*60*1000000), 'GB transferred',operator="-",num_format="2", total_factor=1./(1000**3) ),

		ChartType('Hits_Sec_by_Origin_Response_Code', 'Hits/Sec by Origin Response Code', ('one_stat.tb_site_origin_response_code_requests',), 1/(5.*60), 'total hits',num_format="2", total_factor=1, group_by_key=True ),
		ChartType('Page_View', 'Page View', ('one_stat.tb_traffic_page_view',), 8./(5.*60*1000000), 'GB transferred',num_format="2", total_factor=1./(1000**3) ),
		ChartType('Request_Inbound_Mbps', 'Request Inbound Mbps', ('one_stat.tb_traffic_edge_inbound_bytes',), 8./(5.*60*1000000), 'GB transferred',num_format="2", total_factor=1./(1000**3) ),
		ChartType('Dynamic_contents_inbound', 'Dynamic contents inbound', ('one_stat.tb_traffic_dynamic_inbound_bytes',), 8./(5.*60*1000000), 'GB transferred',num_format="2", total_factor=1./(1000**3) ),
		ChartType('Dynamic_contents_outbound', 'Dynamic contents outbound', ('one_stat.tb_traffic_dynamic_outbound_bytes',), 8./(5.*60*1000000), 'GB transferred',num_format="2", total_factor=1./(1000**3) ),
		ChartType('Active_connection', 'Active connection', ('one_stat.tb_traffic_active_connection',), 1, 'Connections',num_format="2", total_factor=1 ),
		]

split_by_options = [
		SplitByOption('customer', 'customer', ['local_site_for_chartron.customer_id', 'local_site_for_chartron.customer_name', 'stat.stat_time']),
		SplitByOption('site_service', 'site service', ['local_site_for_chartron.cdn_service_id', 'local_site_for_chartron.cdn_service_name', 'stat.stat_time']),
		SplitByOption('site', 'site', ['local_site_for_chartron.CUSTOMER_SITE_ID', 'local_site_for_chartron.SERVE_DOMAIN', 'stat.stat_time']),
		SplitByOption('pop_region', 'pop region', ['ihms_pop_for_chartron.region_id','ihms_pop_for_chartron.region_name','stat.stat_time']),
		SplitByOption('pop', 'pop', ['ihms_pop_for_chartron.cdnw_pop_id', 'ihms_pop_for_chartron.short_name','stat.stat_time']),
		]
		


def get_query_by(conditions, split_by, chart_type):
	query_by = ''
	if (len(conditions['stat_id']) > 0) \
			and (len(conditions['pop_id']) == 0) \
			and (split_by in ('customer', 'site', 'site_service')):
			query_by = 'site'
	elif (len(conditions['pop_id']) > 0) \
			and (len(conditions['stat_id']) == 0) \
			and (split_by in ('pop', 'pop_region')):
			query_by = 'pop'
	elif (len(conditions['stat_id']) > 0) \
			and (split_by in ('pop', 'pop_region')):
			query_by = 'pop_site'
	elif (len(conditions['pop_id']) > 0) \
			and (split_by in ('customer', 'site', 'site_service')):
			query_by = 'site_pop'
	elif len(conditions['pop_id']) == 0 \
			and len(conditions['stat_id']) == 0: 
		if split_by in ('customer', 'site', 'site_service'):
			query_by = 'site'
		if split_by in ('pop', 'pop_region'):
			query_by = 'pop'

	if chart_type.name == 'Hits_Sec_by_Origin_Response_Code':
		if len(conditions['pop_id']) > 0 \
			and len(conditions['stat_id']) == 0:
			query_by = 'pop'
		elif len(conditions['stat_id']) > 0 \
			and len(conditions['pop_id']) == 0:
			query_by = 'site'
		elif len(conditions['stat_id']) > 0 \
			and len(conditions['pop_id']) > 0:
			query_by = 'pop_site'

	return query_by


def make_query2(
		chart_type,
		split_by_option,
		start_time,
		end_time,
		conditions,
		add_key_value=""
		):
	traffic_tables = [] 
	split_by = split_by_option.name
	group_by = split_by_option.columns

	if chart_type.group_by_key:
		group_by = ['stat.key_value', 'stat.key_value', 'stat.stat_time']

	query_by = get_query_by(conditions, split_by, chart_type)

	for tbl in chart_type.traffic_tables:
		if query_by != 'site':
			tbl = tbl + '_pop'
		traffic_tables.append(tbl)

	query = []	
	for j in range(0,2):
		traffic_table = traffic_tables[j]
		sql = " select %s "%(",".join(group_by))
		if j == 0:
			sql += " , %s "%(', '.join(['sum(e%s) as e%s_p%s'%(str(i),str(i), 0) for i in range(0,12)]))
			sql += " , %s "%(', '.join(['0 as e%s_p%s'%(str(i), '1') for i in range(0,12)]))
		else:
			sql += " , %s "%(', '.join(['0 as e%s_p%s'%(str(i), 0) for i in range(0,12)]))
			sql += " , %s "%(', '.join(['sum(e%s) as e%s_p%s'%(str(i), str(i), '1') for i in range(0,12)]))

		#split by site..
		if query_by in ('site', 'site_pop'):
			sql += " from %s stat inner join oui_federated.local_site_for_chartron local_site_for_chartron on stat.stat_id = local_site_for_chartron.stat_id "%(traffic_table)

		#split by pop..
		if query_by in ('pop_site', 'pop'):
			sql += " from %s stat inner join oui_federated.ihms_pop_for_chartron ihms_pop_for_chartron on stat.pop_id = ihms_pop_for_chartron.cdnw_pop_id "%(traffic_table)

		sql += " where stat_time >= '%s' and stat_time <= '%s' "%(start_time, end_time)

		if len(conditions['stat_id']) > 0:
			sql += " and stat.stat_id in (%s) "%(",".join(conditions['stat_id']))

		if len(conditions['pop_id']) > 0:
			sql += " and stat.pop_id in (%s) "%(",".join(conditions['pop_id']))

		if type(chart_type.extra_filter) == str:
			if len(chart_type.extra_filter) > 0:
				sql += " and %s " % chart_type.extra_filter

		if type(chart_type.extra_filter) == list:
			if chart_type.extra_filter[j]:
				sql += " and %s "%chart_type.extra_filter[j]

		sql += " group by %s "%(",".join(group_by))
		query.append(sql)

	op = chart_type.operator
	sql = "select %s "%(", ".join([i.split('.')[1] for i in group_by]))
	if op == '/':
		sql += ", case when sum(e0_p1) = 0 then 0 else sum(e0_p0) %s sum(e0_p1) end e0, "%op
		sql += " case when sum(e1_p1) = 0 then 0 else sum(e1_p0) %s sum(e1_p1) end e1, "%op
		sql += " case when sum(e2_p1) = 0 then 0 else sum(e2_p0) %s sum(e2_p1) end e2, "%op
		sql += " case when sum(e3_p1) = 0 then 0 else sum(e3_p0) %s sum(e3_p1) end e3, "%op
		sql += " case when sum(e4_p1) = 0 then 0 else sum(e4_p0) %s sum(e4_p1) end e4, "%op
		sql += " case when sum(e5_p1) = 0 then 0 else sum(e5_p0) %s sum(e5_p1) end e5, "%op
		sql += " case when sum(e6_p1) = 0 then 0 else sum(e6_p0) %s sum(e6_p1) end e6, "%op
		sql += " case when sum(e7_p1) = 0 then 0 else sum(e7_p0) %s sum(e7_p1) end e7, "%op
		sql += " case when sum(e8_p1) = 0 then 0 else sum(e8_p0) %s sum(e8_p1) end e8, "%op
		sql += " case when sum(e9_p1) = 0 then 0 else sum(e9_p0) %s sum(e9_p1) end e9, "%op
		sql += " case when sum(e10_p1) = 0 then 0 else sum(e10_p0) %s sum(e10_p1) end e10, "%op
		sql += " case when sum(e11_p1) = 0 then 0 else sum(e11_p0) %s sum(e11_p1) end e11 "%op
		if add_key_value:
			sql += ", '%s' as key_value" % add_key_value
		sql += " from ( "
		sql += " union all ".join (query)
		sql += " ) aa "
		sql += " group by %s "%(", ".join([i.split('.')[1] for i in group_by]))
	else:
		sql += ", sum(e0_p0) %s sum(e0_p1) e0, "%op
		sql += "sum(e1_p0) %s sum(e1_p1) e1, "%op
		sql += "sum(e2_p0) %s sum(e2_p1) e2, "%op
		sql += "sum(e3_p0) %s sum(e3_p1) e3, "%op
		sql += "sum(e4_p0) %s sum(e4_p1) e4, "%op
		sql += "sum(e5_p0) %s sum(e5_p1) e5, "%op
		sql += "sum(e6_p0) %s sum(e6_p1) e6, "%op
		sql += "sum(e7_p0) %s sum(e7_p1) e7, "%op
		sql += "sum(e8_p0) %s sum(e8_p1) e8, "%op
		sql += "sum(e9_p0) %s sum(e9_p1) e9, "%op
		sql += "sum(e10_p0) %s sum(e10_p1) e10, "%op
		sql += "sum(e11_p0) %s sum(e11_p1) e11 "%op
		if add_key_value:
			sql += ", '%s' as key_value" % add_key_value
		sql += " from ( "
		sql += " union all ".join (query)
		sql += " ) aa "
		sql += " group by %s "%(", ".join([i.split('.')[1] for i in group_by]))

	return sql


def make_query(
		chart_type,
		split_by_option,
		start_time,
		end_time,
		conditions,
		add_key_value=""
		):

	traffic_table = chart_type.traffic_tables[0]
	split_by = split_by_option.name
	group_by = split_by_option.columns

	if chart_type.group_by_key:
		group_by = ['stat.key_value', 'stat.key_value', 'stat.stat_time']
	
	query_by = get_query_by(conditions, split_by, chart_type)

	if query_by != 'site':
		traffic_table = traffic_table + '_pop'
		
	sql = " select %s "%(",".join(group_by))
	sql += " ,sum(e0),sum(e1),sum(e2),sum(e3),sum(e4),sum(e5),sum(e6),sum(e7),sum(e8),sum(e9),sum(e10),sum(e11) "
	if add_key_value:
		sql += ", '%s' as http_type " % add_key_value

	#split by site..
	if query_by in ('site', 'site_pop'):
		sql += " from %s stat inner join oui_federated.local_site_for_chartron local_site_for_chartron on stat.stat_id = local_site_for_chartron.stat_id "%(traffic_table)

	#split by pop..
	if query_by in ('pop_site', 'pop'):
		sql += " from %s stat inner join oui_federated.ihms_pop_for_chartron ihms_pop_for_chartron on stat.pop_id = ihms_pop_for_chartron.cdnw_pop_id "%(traffic_table)

	sql += " where stat_time >= '%s' and stat_time <= '%s' "%(start_time, end_time)

	if len(conditions['stat_id']) > 0:
		sql += " and stat.stat_id in (%s) "%(",".join(conditions['stat_id']))

	if len(conditions['pop_id']) > 0:
		sql += " and stat.pop_id in (%s) "%(",".join(conditions['pop_id']))

	if len(chart_type.extra_filter) > 0:
		sql += " and %s "%chart_type.extra_filter

	sql += " group by %s "%(",".join(group_by))

	return sql



def get_conditions(options):
	conditions = {
			'stat_id':[],
			'pop_id':[],
		}

	if len(options['site']) > 0 or  len(options['customer']) > 0 or len(options['site_service']) > 0:
		sql = "select distinct local_site_for_chartron.stat_id from oui_federated.local_site_for_chartron local_site_for_chartron "
		sql += " where local_site_for_chartron.stat_id is not null and local_site_for_chartron.CUSTOMER_SITE_ID > 0 "
		if len(options['site']) > 0:
			sql += " and local_site_for_chartron.customer_site_id  in (%s) "%(",".join(options['site']))
		if len(options['customer']) > 0:
			sql += " and local_site_for_chartron.customer_id in (%s) "%(",".join(options['customer']))
		if len(options['site_service']) > 0:
			sql += " and local_site_for_chartron.cdn_service_id in (%s)"%(",".join(options['site_service']))
		sql += "; "

		rets = []
		cursor = None
		try:
			cursor = connections['one_stat'].cursor()
			rows = cursor.execute(sql)
			rets = cursor.fetchall()
		finally:
			if cursor:
				cursor.close()
				del cursor

		for ret in rets:
			conditions['stat_id'].append(str(ret[0]))

	if len(options['pop']) > 0 or len(options['pop_region']) > 0:
		sql = "select distinct ihms_pop_for_chartron.cdnw_pop_id from oui_federated.ihms_pop_for_chartron ihms_pop_for_chartron "
		sql += " inner join oui_federated.oui_pop_for_chartron oui_pop_for_chartron on oui_pop_for_chartron.cdnw_pop_id = ihms_pop_for_chartron.cdnw_pop_id "
		sql += " where ihms_pop_for_chartron.cdnw_pop_id > 0 "
		if len(options['pop']) > 0:
			sql += " and oui_pop_for_chartron.pop_id in (%s) "%(",".join(options['pop']))
		if len(options['pop_region']) > 0:
			sql += " and oui_pop_for_chartron.region_id in (%s) "%(",".join(options['pop_region']))
		sql += "; "

		rets = []
		cursor = None
		try:
			cursor = connections['one_stat'].cursor()
			rows = cursor.execute(sql)
			rets = cursor.fetchall()
		finally:
			if cursor:
				cursor.close()
				del cursor

		for ret in rets:
			conditions['pop_id'].append(str(ret[0]))

	return conditions

def check_result_condition(options, conditions):
	stat_ret = False
	pop_ret = False
	
	if (len(options['customer']) == 0 and \
		len(options['site_service']) == 0 and \
   		len(options['site']) == 0):
		stat_ret = True
	elif (len(options['customer']) > 0 or \
		len(options['site_service']) > 0 or \
   		len(options['site']) > 0) and \
		len(conditions['stat_id']) > 0:
		stat_ret = True

	if (len(options['pop']) == 0 and \
		len(options['pop_region']) == 0):
		pop_ret = True
	elif (len(options['pop']) > 0 or \
		len(options['pop_region']) > 0) and \
		len(conditions['pop_id']) > 0:
		pop_ret = True
	return stat_ret & pop_ret 

def get_grouped_rows(
			chart_type,
			split_by_option,
			options,
			datefrom,
			dateto,
			legend_cnt,
			others_flag,
			total_line_flag,
			):

	datefrom_obj = datetime.strptime(datefrom, '%Y-%m-%d %H:%M')
	dateto_obj = datetime.strptime(dateto, '%Y-%m-%d %H:%M')
	datefrombase_obj = datefrom_obj.strptime(datefrom_obj.strftime("%Y-%m-%d %H:00"), '%Y-%m-%d %H:%M')
	datetobase_obj = dateto_obj.strptime(dateto_obj.strftime("%Y-%m-%d %H:00"), '%Y-%m-%d %H:%M')
	
	diff_obj = datetobase_obj - datefrombase_obj
	cnt_hours = divmod(diff_obj.days * 86400 + diff_obj.seconds, 60 * 60)[0] + 1

	date_data = []
	for i in range(cnt_hours):
		date_data.append(datefrombase_obj + timedelta(hours=1 * i))

	stat_time_from = datefrombase_obj.strftime("%Y-%m-%d %H:%M:%S")
	if dateto_obj.minute == 0:
		stat_time_to = (datetobase_obj - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
	else:
		stat_time_to = datetobase_obj.strftime("%Y-%m-%d %H:%M:%S")

	conditions = get_conditions(options)

	check_result_condition_flag = check_result_condition(options, conditions)

	rets = []
	if check_result_condition_flag:
		sql = get_sql(chart_type, split_by_option, stat_time_from, stat_time_to, conditions)
		cursor = None
		try:
			cursor = connections['one_stat'].cursor()
			rows = cursor.execute(sql)
			rets = cursor.fetchall()
		finally:
			if cursor:
				cursor.close()
				del cursor
	chart_data = {}
	order_base_data = {}

	date_from_div = datefrom_obj.minute/5
	date_to_div = dateto_obj.minute/5
	total_bucket = cnt_hours*12 - date_from_div - (12 - date_to_div)
	len_date_data = len(date_data)
	str_date_to = datetime.strptime(stat_time_to, '%Y-%m-%d %H:00:00')
	str_date_from = datetime.strptime(stat_time_from, '%Y-%m-%d %H:00:00')

	for ret in rets:
		if not chart_data.has_key(ret[0]):
			chart_data[ret[0]] = {'name':ret[1], 'date_data':total_bucket*[0]}
			order_base_data[ret[0]] = {'aggr_total':[-1,0,0,0,0]} # min, max, avg, 95th, total hits

		#######################################################################################
		idx = date_data.index(ret[2])
		bucket_idx = idx*12
		if idx > 0:
			bucket_idx = bucket_idx - date_from_div

		ret_idx = 3
		if idx == 0:
			ret_idx = ret_idx + date_from_div

		rangeto = bucket_idx+12
		if str_date_to == str_date_from:
			if date_to_div == 0:
				rangeto = rangeto - date_from_div
			else:
				rangeto = rangeto - date_from_div - (12 - date_to_div)
		else:
			if idx == 0:
				rangeto = rangeto - date_from_div
			elif idx == len_date_data -1:
				rangeto = rangeto - (12 - date_to_div)

		#######################################################################################
		dt = chart_data[ret[0]]['date_data']
		ag_total = order_base_data[ret[0]]['aggr_total']
		min_val = ag_total[0]
		max_val = ag_total[1]
		total_val = ag_total[4]

		for i in range(bucket_idx, rangeto):
			if False:
				int_val = int(ret[ret_idx])
			else:
				int_val = float(ret[ret_idx])

			val = int_val*chart_type.factor
			if chart_type.maximum and val > chart_type.maximum:
				val = chart_type.maximum
				total_val = total_val + val / chart_type.factor
			else:
				total_val = total_val + int_val

			dt[i] = val
			if min_val < 0:
				min_val = val
			else:
				if min_val > val:
					min_val = val
			if max_val == 0:
				max_val = val
			else:
				if max_val < val and val != 0:
					max_val = val
			ret_idx = ret_idx + 1

		chart_data[ret[0]]['date_data'] = dt

		ag_total[0] = min_val
		ag_total[1] = max_val
		ag_total[4] = total_val

	ordered_list = order_base_data.items()
	ordered_list.sort(lambda a,b: -cmp(a[1]['aggr_total'][4], b[1]['aggr_total'][4]))

	ordered_chart_data = []
	ordered_index = []

	legend_array = []
	legend_index = []

	if legend_cnt >= len(ordered_list):
		others_flag = False
		legend_cnt = len(ordered_list)

	if chart_type.percentage:
		others_flag = False
		total_line_flag = False

	for i in range(0,legend_cnt):
		ordered_list[i][1]['aggr_total'][3] = find_95th(chart_data[ordered_list[i][0]]['date_data'])
		total = ordered_list[i][1]['aggr_total'][4]
		ordered_list[i][1]['aggr_total'][2] = (total * chart_type.factor) / total_bucket
		ordered_list[i][1]['aggr_total'][4] = total * chart_type.total_factor
		ordered_index.append({'name': chart_data[ordered_list[i][0]]['name'], 'aggr_total':ordered_list[i][1]['aggr_total']})
		ordered_chart_data.append(chart_data[ordered_list[i][0]])
		legend_array.append(chart_data[ordered_list[i][0]]['date_data'])
		legend_index.append(ordered_list[i][1]['aggr_total'])

	others_array = []
	others_index = []
	if others_flag and len(ordered_list) > legend_cnt:
		for i in range(legend_cnt,len(ordered_list)):
			others_array.append(chart_data[ordered_list[i][0]]['date_data'])
			ordered_list[i][1]['aggr_total'][3] = find_95th(chart_data[ordered_list[i][0]]['date_data'])
			total = ordered_list[i][1]['aggr_total'][4]
			ordered_list[i][1]['aggr_total'][2] = (total * chart_type.factor) / total_bucket
			ordered_list[i][1]['aggr_total'][4] = total * chart_type.total_factor
			others_index.append(ordered_list[i][1]['aggr_total'])

		others_array = sum(array(others_array))
		others_index = sum(array(others_index))

		ordered_chart_data.append({'name':'other', 'date_data':others_array.tolist()})
		ordered_index.append({'name':'other', 'aggr_total':others_index.tolist()})

		legend_array.append(others_array.tolist())
		legend_index.append(others_index.tolist())

	total_array = sum(array(legend_array))
	total_index = sum(array(legend_index))

	if total_line_flag and len(ordered_list) > 0:
		list_total_array = total_array.tolist()
		list_total_index = total_index.tolist()

		ordered_chart_data.append({'name':'total', 'date_data':list_total_array})
		total_min = min(list_total_array)
		total_max = max(list_total_array)
		total_97th = find_95th(list_total_array)

		total_avg = sum(list_total_array) / total_bucket
		total_index_new = [total_min, total_max, total_avg, total_97th, list_total_index[4]]
		ordered_index.append({'name':'total', 'aggr_total':total_index_new})

	split_by_name_title = split_by_option.name
	if chart_type.name in ['Hits_Sec_by_Origin_Response_Code', 'Hits_Sec_by_Response_Code']:
		split_by_name_title = 'HTTP response code'
	elif chart_type.name in ['ssl_bytes_total_http12', 'ssl_items_total_http12',]:
		split_by_name_title = 'HTTP version'
	index_title = [split_by_name_title,'min','max','avg','95th',chart_type.total_label]

	return ordered_chart_data, ordered_index, index_title


def get_sql(chart_type, split_by_option, stat_time_from, stat_time_to, conditions):

	CHART1 = {
		'ssl_bytes_total_http12': CHART_FOR_HTTP1_BYTES,
		'ssl_items_total_http12': CHART_FOR_HTTP1_ITEMS
	}

	CHART2 = {
		'ssl_bytes_total_http12': CHART_FOR_HTTP2_BYTES,
		'ssl_items_total_http12': CHART_FOR_HTTP2_ITEMS
	}

	if chart_type.name in ['ssl_bytes_total_http12','ssl_items_total_http12',]:
		sql2 = make_query2(chart_type=CHART1[chart_type.name],
			split_by_option=split_by_option,
			start_time=stat_time_from,
			end_time=stat_time_to,
			conditions=conditions,
			add_key_value='h1')

		sql1 = make_query(
			chart_type=CHART2[chart_type.name],
			split_by_option=split_by_option,
			start_time=stat_time_from,
			end_time=stat_time_to,
			conditions=conditions,
			add_key_value='h2'
		)



		sql_list = [
			'select key_value, key_value, stat_time, ',
			' , '.join(['sum(e%s)' % x for x in range(0, 12)]),
			'from (%s union all %s) x' % (sql2, sql1),
			'group by key_value, stat_time'
		]

		return ' '.join(sql_list)


	if len(chart_type.traffic_tables) > 1:
		return make_query2(
			chart_type=chart_type,
			split_by_option=split_by_option,
			start_time=stat_time_from,
			end_time=stat_time_to,
			conditions=conditions)

	return make_query(
		chart_type=chart_type,
		split_by_option=split_by_option,
		start_time=stat_time_from,
		end_time=stat_time_to,
		conditions=conditions)
