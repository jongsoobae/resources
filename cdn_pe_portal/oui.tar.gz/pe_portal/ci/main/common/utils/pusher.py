import base64
import time
import httplib
from datetime import datetime, timedelta
from django.db.models import Q
from ci.common.models.cdn import Node
from ci.common.models.pusher import PUSH_FLUSH, PUSH_SYSINFO, PUSH_CACHECONF, PUSH_CONTDIST, PushTest
from ci.common.models.pusher import ConfigRequestJson, ConfigRequestJsonTest
from ci.common.models.pusher import ConfigPushRequestHistory, PUSH_VISIBLE, BE_CONFIG_GROUP
from ci.common.utils.changelog import ChangeCommand
from django.core.cache import cache
from django.utils import simplejson
from django.db import transaction
from django.utils.translation import ugettext_lazy as _
import re
from ci.common.utils.flush_api import check_flush_limit_status, flush_request_api
from ci.constants import SPECTRUMAPI_SERVER, SPECTRUMAPI_USER, SPECTRUMAPI_PASS,\
            CONFIG_API_HOST, PRISMAPI_SERVER, PRISMAPI_USER, PRISMAPI_PASS
from ci.common.utils.supporttools import handleHttpGetConnection2

FLUSH_ALL = 'all'
FLUSH_PATHS = 'paths'
CANCEL_FLUSH_ALL = 'cancel_all'
CANCEL_FLUSH_WILDCARD = 'cancel_wildcard'


flush_limit_error_codes = {
        0: "Flush is allowed",
        1: "Over the limit of flush requests per hour",
        2: "Over the limit of items per flush",
        3: "Over the limit of wildcards per flush",
        4: "Over the limit for 'flush all' requests per hour"
}


class NodeChangeCommand(ChangeCommand):
    def __init__(self):
        pass

    def pushType(self):
        return PUSH_SYSINFO

    def objectDescription(self):
        return "Nodes offline/online"


def flush_limit_status(site, items, _type):
    ret = check_flush_limit_status(site, items, _type)

    return ret


def get_non_ngp_nodes(types):
    nodes = Node.objects.filter(ngp_flag=False)
    test_nodes = PushTest.objects.all().values('node_id')
    if len(types) == 1 and types[0] == 'DNS':
        nodes = nodes.filter(node_type__in=[2, 3]).exclude(id__in=test_nodes)
    else:
        nodes = nodes.filter(Q(broken=False) | Q(broken=True, node_type__in=[2, 3])).exclude(id__in=test_nodes)

    return nodes


@transaction.commit_on_success
def request_push(types, description, user, targets=[], params={}, stage=False):
    """
    returns a push request ID
    @param types: A list of configuration types to push.
                  Possible values are defined in the ci.common.models.pusher file.
                  Note that some of them are deprecated.
    @param description: a string describing the push request
    @param user: a string with the username triggerring the request
    @param targets: an optional parameter that is a list of nodes to push to. If not passed,
                    targets remains an empty list which means push to all valid nodes
    @param params: Additional parameters to pass in the push request
                   (you can clarify possible values for this with the PE pusher team)
    @param stage: Use the staging queue table instead of production.
                  This is when testing a new pusher release after deployement
    """
    if PUSH_SYSINFO in types or PUSH_CACHECONF in types:
        types.append(PUSH_CONTDIST)

    d = {
        'types': types,
        'description': description,
        'user': user
    }
    if len(targets) > 0:
        d['targets'] = targets
    if len(params) > 0:
        d['params'] = params

    # block start... if all nodes have ngp_flag=1, this block is not need.
    non_ngp_node = get_non_ngp_nodes(types)

    if len(targets) > 0:
        non_ngp_node = non_ngp_node.filter(id__in=targets)

    if non_ngp_node.exists():
        non_ngp_node = non_ngp_node.values_list("id", flat=True)
        d['targets'] = [i for i in non_ngp_node]
    else:
        # If pusher should be process only non ngp flaged nodes.
        return False
    # block end...

    content = simplejson.dumps(d)
    if stage:
        req = ConfigRequestJsonTest()
    else:
        req = ConfigRequestJson()
    req.content = content
    req.save()
    return req.id


def request_sites_push(description, user):
    from ci.common.utils.pusher import NGP_BEPusher
    skip_testing = False
    bepusher = NGP_BEPusher()
    bepusher.push(phase='SITESNG',
                  request_user=user,
                  description=description,
                  skip_testing=skip_testing)
    request_push(['SITESNG'], description, user)


def clean_flush_paths(site, paths, ims=False, wildcard=False, allow_any_domain=False):
    """Convenience method to verify the paths passed to a flush request. This should be called by any code that will make a flush request to make sure that the paths passed are valid. Paths must already be in a list before being passed to this function."""
    max_length = 8192
    wildcard_pad = '*' in site.pad
    errors = []
    if ims and site.use_sub_files:
        errors.append('This PAD uses chunking, so the "Expire only" setting must be disabled.')
    if wildcard_pad and site.use_pad_as_host_header:
        site_regex = re.compile(r'^http://%s/\S*$' % site.pad.replace('.','\.').replace('*','.*'))
    elif wildcard_pad:
        site_regex = re.compile(r'^http://%s/\S*$' % site.origin.replace('.','\.').replace('*','.*'))
    elif site.use_pad_as_host_header and site.pad_aliases <> "":
        site_regex = re.compile(r'^(http://(%s|%s))?/\S*$' %(site.origin.replace('.','\.'), site.pad_aliases.replace('.','\.').replace('\n','|').replace('\r','')))
    elif site.use_pad_as_host_header:
        # this one is a work around until 1.5.20 for internal use....
        site_regex = re.compile(r'^(http://%s)?/\S*$' % (site.origin.replace('.', '\.')))
    else:
        site_regex = re.compile(r'^/\S*$')
    for linenum, line in enumerate(paths):
        if not allow_any_domain and not re.match(site_regex, line.strip()):
            errors.append("'%s' is not a valid path." % line.strip())
        # remove False and when it is time to put this live
        if False and len(line) > max_length:
            errors.append("'%s' is over supported path length of %d characters." %(line.strip(), max_length))
    if wildcard:
        flag = False
        for each in paths:
            if not re.search(r'[\*\?]', each):
                flag = True
        if flag:
            errors.append('Wildcard mode is active but no wildcard characters ("?" or "*") are present.')
    return errors


def request_cache_flush(description, user, site, flushtype, paths=[], wildcard=False, use_ims=False, stage=False):
    """Convenience method that allows callers to perform cache flushes without knowing about
    the implementation details of the push type.
    """
    if not isinstance(paths, list):
        raise Exception("Paths has to be a list")
    if flushtype == FLUSH_ALL:
        flushtype_int = 1 if use_ims else 4
    elif flushtype == FLUSH_PATHS:
        if wildcard:
            flushtype_int = 3 if use_ims else 5
        else:
            if use_ims:
                raise Exception('use_ims cannot be set to True if wildcard is False')
            flushtype_int = 2
    elif flushtype == CANCEL_FLUSH_ALL:
        flushtype_int = 6
    elif flushtype == CANCEL_FLUSH_WILDCARD:
        flushtype_int = 7
    params = {
        'site': str(site.id),
        'type': str(flushtype_int),
        'values': paths
    }
    d = {
        'types': [PUSH_FLUSH],
        'description': description,
        'user': user,
        'params':params
    }
    content = simplejson.dumps(d)

    req_id = flush_request_api(site.id, stage, content)

    return req_id
    # return request_push([PUSH_FLUSH], description, user, params=params, stage=stage)


def get_config_diff(history_id):
    """
    Get SVN Diff via PRISM API

    https://prismapi.cdnetworks.com/config/svndiff?action_id=22

    :param history_id: (string) history_id
    :returns: Return PRISM API view svn diff
    """
    try:
        be_push_history = ConfigPushRequestHistory.objects.get(config_push_request_history=history_id)

        _headers = {"Content-Type": "text/plain;charset=utf8",
                    "User-Agent": "OUI SVN Diff UA/Python"}
        auth_hash = base64.b64encode("%s:%s" % (PRISMAPI_USER, PRISMAPI_PASS))
        _headers["Authorization"] = "Basic %s" % (auth_hash.strip("\n"))

        url = "/config/svndiff?action_id=%s" % be_push_history.action

        response = handleHttpGetConnection2(PRISMAPI_SERVER, url, headers=_headers, request_type='POST')
        return response
    except ConfigPushRequestHistory.DoesNotExist:
        return "Config SVN diff does not exist"
    except (httplib.NotConnected, httplib.ImproperConnectionState) as e:
        raise Exception("PRISM API Server Connection failed. (%s)" % e)
    except Exception as e:
        raise e

def _is_https(config_hostname):
    """
    Detect HTTP or HTTPS protocol

    :param config_hostname: (str) hostname has https://host or http://host
    :returns: Is HTTPS or not.
    """
    try:
        hostname = config_hostname.strip()
        if hostname and re.match('^https', hostname):
            return True
        else:
            return False
    except Exception:
        return True

def _parse_url(config_uri):
    """
    Parse configured API URI
    Get hostname, protocol, Port, path

    Configured parameter hostname has to end by slash(/).

    Example)
        - foobar.com/
        - https://foobar.com/
        - https://foobar.com:443/
        - https://foobar.com:443/?max=40
        - http://insecure.foobar.com/?max=40#root

    :param config_uri: (str) Configured API URI
    :returns: object of URI information
    """
    parser = re.compile('^((?P<scheme>https?):\/)?\/?((?P<username>.*?)(:(?P<password>.*?)|)@)?(?P<hostname>[^:\/\s]+)(?P<port>:([^\/]*))?(?P<path>(\/\w+)*\/)?(?P<filename>[-\w.]+[^#?\s]*)?(?P<query>\?([^#]*))?(?P<fragment>#(.*))?$')

    class URInfo(object):
        _scheme = "https"
        _hostname = ""
        _port = httplib.HTTPS_PORT
        _path = ""

        def __init__(self, config_url):
            try:
                parsed = parser.match(config_url)
                self.scheme = parsed.group('scheme') or self._scheme
                self.is_https = _is_https(self.scheme)
                self.hostname = parsed.group('hostname') or self._hostname
                if parsed.group('port'):
                    self.port = parsed.group('port').strip(":")
                else:
                    if self.is_https:
                        self.port = self._port
                    else:
                        self.port = httplib.HTTP_PORT

                self.path = self._path
                if parsed.group('path'):
                    path = parsed.group('path').strip()
                    if path != "/":
                        self.path = path

            except Exception:
                raise Exception('Unable to parse API URI configuration')

    return URInfo(config_uri)

class ConfigApi():
    _config_api_host = ""
    _config_api_port = httplib.HTTPS_PORT
    _config_api_path = "/config/push_completion_rate"
    _time_out = 30

    _headers = {"Content-Type": "application/json;charset=utf8",
                "User-Agent": "OUI Pusher Monitoring UA/Python"}

    def __init__(self):
        self.time_out = self._time_out

        try:
            config_api_info = _parse_url(CONFIG_API_HOST)
        except Exception:
            raise Exception('[ERROR] ci.constants.CONFIG_API_HOST is incorrect. Please check the parameter')

        if config_api_info.is_https:
            self.config_api_request = httplib.HTTPSConnection
        else:
            self.config_api_request = httplib.HTTPConnection

        if config_api_info.hostname:
            self.config_api_host = config_api_info.hostname
        else:
            raise Exception('[ERROR] ci.constants.CONFIG_API Hostname is invalid. Please check the parameter')

        self.config_api_port = config_api_info.port
        self.config_api = config_api_info.path or self._config_api_path

    def _config_api_push_progress(self, action_id_list):
        """
        Get Push progres via CONFIG API
        :link https://wiki.cdnetworks.com/confluence/display/TX/Pusher+migration+to+BE_Config+-+Backend+SDD#PushermigrationtoBE_Config-BackendSDD-3.3.1.1.APISpec
        '{"140595": {"parent_joint_action_id": 140594, "status": "Completed", "group": "HTTP_SITES",
        "status_msg": "auto promoted from phase TEST", "down": [], "phase": "GLOBAL", "ok": [], "type": "CFG", "revision": 12},
        "140589": {"parent_joint_action_id": 140588, "status": "Completed", "group": "HTTP_SITES",
        "status_msg": "auto promoted from phase TEST", "down": [], "phase": "GLOBAL", "ok": [], "type": "CFG", "revision": 11}}'
        :param action_id_list: config_dist_action.action_id list
        :returns: Response of CONFIG API
        """
        data = None
        params = simplejson.dumps({"action_id": action_id_list})
        headers = self._headers

        if action_id_list and len(action_id_list) <= 0:
            return data
        try:
            conn = self.config_api_request(self.config_api_host,
                                           self.config_api_port, timeout=self.time_out)
            conn.request("POST", self.config_api, params, headers=headers)
            response = conn.getresponse()
            if response.status == httplib.OK:
                data = response.read()
            else:
                data = None
            return data

        except (httplib.NotConnected, httplib.ImproperConnectionState):
            raise Exception(_('CONFIG API:Connection Fail'))

        except Exception, e:
            raise Exception('CONFIG API Error : %s' % e)

class SpectrumApi():
    _spectrum_api_host = ""
    _spectrum_api_port = httplib.HTTPS_PORT
    _spectrum_api_push_path = "/api/config/push/"
    _time_out = 30

    _headers = {"Content-Type": "application/json;charset=utf8",
                "User-Agent": "OUI Pusher Monitoring UA/Python"}
    code_converted_map = {}

    def __init__(self, code_converted_map=None):
        """git initialize spectrum api class
        :param code_converted_map: BE_CONFIG_GROUP tulple to dict
        :return:
        """
        self.time_out = self._time_out
        if code_converted_map:
            self.code_converted_map = code_converted_map
        else:
            convert_map = [{k[1]:k[0]} for k in BE_CONFIG_GROUP]
            for item in convert_map:
                self.code_converted_map.update(item)

        try:
            spectrum_api_info = _parse_url(SPECTRUMAPI_SERVER)
        except Exception:
            raise Exception('[ERROR] ci.constants.SPECTRUM_API_HOST is incorrect. Please check the parameter')

        if spectrum_api_info.is_https:
            self.spectrumapi_api_request = httplib.HTTPSConnection
        else:
            self.spectrumapi_api_request = httplib.HTTPConnection

        if spectrum_api_info.hostname:
            self.spectrum_api_host = spectrum_api_info.hostname
        else:
            raise Exception('[ERROR] ci.constants.SPECTRUM_API Hostname is invalid. Please check the parameter')

        self.spectrum_api_port = spectrum_api_info.port
        self.spectrum_api_path = spectrum_api_info.path or self._spectrum_api_push_path

    def _get_config_phase_name(self, push_code, skip_testing=False, is_staging=False):
        try:
            config_group = self.code_converted_map[push_code]
        except Exception, e:
            raise e

        if is_staging:
            config_type = "CFGT"
        else:
            config_type = "CFG"

        if skip_testing:
            config_phase = "MNT"
        else:
            config_phase = "TEST"

        return config_group, config_type, config_phase

    def _get_phase_id(self, push_code, skip_testing=False, is_staging=False):
        """
        let's avoid frequent spectrum api call, since this info is configuration rarely changed.
        :param push_code:
        :param skip_testing:
        :param is_staging:
        :return:
        """
        try:
            (config_group, config_type, config_phase) = self._get_config_phase_name(push_code, skip_testing, is_staging=is_staging)
            res = self.get_config_phase(config_group,config_type,config_phase)
            if len(res) > 0:
                return res[0]["config_phase_id"]
            else:
                raise Exception("There is not exists phase id of (%s/%s/%s)" % (config_group,
                                                                                config_type,
                                                                                config_phase))
        except (httplib.NotConnected, httplib.ImproperConnectionState):
            raise Exception(_('SPECTRUM API:Connection Fail'))

        except Exception, e:
            raise Exception('SPECTRUM API Error : %s' % e.message)

    def get_config_phase(self,config_group,config_type,config_phase):
        """
        let's avoid frequent spectrum api call, since this info is configuration rarely changed.
        cache phase id. we need to handle spectrum api maintenance or outage situation as well.
        :param config_group:
        :param config_type:
        :param config_phase:
        :return:
        """
        try:
            cache_key = "%s_%s_%s" % (config_group,config_type, config_phase)
            res = cache.get(cache_key)
            if res is None:
                params = "config_group_name=%s&config_type_name=%s&name=%s" % (config_group,
                                                                               config_type,
                                                                               config_phase)
                headers = self._headers

                auth_hash = base64.b64encode("%s:%s"%(SPECTRUMAPI_USER, SPECTRUMAPI_PASS))
                headers["Authorization"] = "Basic %s"%(auth_hash.strip("\n"))
                conn = self.spectrumapi_api_request(self.spectrum_api_host,
                                                    self.spectrum_api_port, timeout=self.time_out)
                conn.request("GET", "/api/config/phases/?%s" % params, headers=headers)
                response = conn.getresponse()
                data = response.read()
                res = simplejson.loads(data)
                cache.set(cache_key, res, 60*60) #TTL : 1hour

            return res
        except:
            return {}


    def _pusher_code_to_phase_id(self, code, skip_testing=False, is_staging=False):
        """
        Convert push config type to phase ID

        :param code: Pusher Config Type code
        :param skip_testing: Pusher Config Type code
        :param is_staging: push to staging

        :returns: converted NGP BE_CONFIG phase_id
        """
        try:
            if code in PUSH_VISIBLE:
                return self._get_phase_id(code, skip_testing, is_staging=is_staging)
            else:
                return None
        except KeyError:
            return None

    def pusher_code_to_phase_id(self, push_codes, skip_testing=False, is_staging=False):
        """
        (multiple) Convert push config type to phase ID

        :param push_codes: Pusher Config Types ( list or ? )
        :returns: converted NGP BE_CONFIG phase_id
        """
        if isinstance(push_codes, list):
            phase_code = []
            for pusher_code in push_codes:
                phase_code.append(self._pusher_code_to_phase_id(pusher_code, skip_testing, is_staging=is_staging))
        else:
            phase_code = self._pusher_code_to_phase_id(push_codes, skip_testing, is_staging=is_staging)

        return phase_code

    def _get_related_action_ids(self,action_id_list):
        """
        get GLOBAL phases promoted TEST
        :param action_id_list:
        :return:
        """
        try:
            result_list = []
            action_results = self._get_related_promoted_action_ids(action_id_list)
            for action in action_results:
                result_list.append(action['action_id'])
            return result_list
        except Exception,e:
            return []

    def _get_related_promoted_action_ids(self, action_id_list):
        """
        Get related action_id by parent_action_id

        :param action_id_list: config_dist_action.action_id list
        :returns: All related action_id by parent_action_id
        """
        data = None

        #params = "page_size=max&parent_id__in=%s" % (",".join([str(i) for i in action_id_list]))
        params="'config_group_name=HTTP_SITES&action_id_list=%s" % (",".join([str(i) for i in action_id_list]))
        headers = self._headers
        auth_hash = base64.b64encode("%s:%s"%(SPECTRUMAPI_USER, SPECTRUMAPI_PASS))
        headers["Authorization"] = "Basic %s"%(auth_hash.strip("\n"))
        if len(action_id_list) <= 0:
            return data

        try:
            promted_api_path = '/api/config/promotedactions/'
            conn = self.spectrumapi_api_request(self.spectrum_api_host,
                                    self.spectrum_api_port, timeout=self.time_out)

            conn.request("GET", "%s?%s"%(promted_api_path, params), headers=headers)
            response = conn.getresponse()

            if response.status == httplib.OK:
                data = response.read()
                res = simplejson.loads(data)
                return res
            else:
                raise Exception("[HTTP STATUS :%s]")
        except (httplib.NotConnected, httplib.ImproperConnectionState):
            raise Exception(_('SPECTRUM API:Connection Fail'))

        except Exception, e:
            raise Exception('SPECTRUM API Error : %s' % e.message)


class NGP_BEPusher():
    _model = ConfigPushRequestHistory
    _code_conv = {}
    _mnt_code_conv = {}

    push_history = None

    def __init__(self):
        self.push_history = self._model.objects.all()
        convert_map = [{k[1]:k[0]} for k in BE_CONFIG_GROUP]
        for item in convert_map:
            self._code_conv.update(item)

        self.config_api = ConfigApi()
        self.spectrum_api = SpectrumApi(self._code_conv)

    def _get_config_phase_name(self, push_code, skip_testing=False, is_staging=False):
        return self.spectrum_api._get_config_phase_name(push_code, skip_testing,is_staging)

    def _get_phase_id(self, push_code, skip_testing=False, is_staging=False):
        return self.spectrum_api._get_phase_id(push_code,skip_testing,is_staging)

    def progress(self, history_id_list):
        """
        status = {0: "Pending",
            1: "Creating",
            2: "Testing",
            3: "Deploying",
            4: "Completed",
            5: "Validating",
            6: "Processing Rollback",
            7: "Complete, auto promote pending",
            -1: "Failed"}
        Get Push progres via CONFIG API
        return dictionary composed of history_id: config api response
        :param history_id_list: config_push_request_history.pk list ( format : [job-10, job-11] )
        :returns: Response of CONFIG API
        """
        def _strip_id(_history_id_list):
            """
            Remove key name "job-" from request param

            :param history_id_list: History id list
            :returns: (list) history pk list
            """
            for hi in _history_id_list:
                try:
                    h_id = int(hi.replace("job-", ""))
                    yield h_id
                except Exception:
                    pass

        def _get_related_config_response(http_test_action_id, items):
            rets = {}

            if not str(http_test_action_id) in items.keys():
                return rets

            parent_id = items[str(http_test_action_id)]['parent_joint_action_id']

            for key in items.keys():
                if items[key]["parent_joint_action_id"] == parent_id:
                    rets[key] = items[key]
            return rets

        def _check_is_broken(check_name, broken_nodes):
            for name in broken_nodes:
                if name.find(check_name) > -1:
                    return True
            return False

        def _remove_broken_node(api_response, broken_nodes):
            for act_id, _data in api_response.items():
                _data['ok'] = [node for node in _data['ok'] if not _check_is_broken(node, broken_nodes=broken_nodes)]
                _data['down'] = [node for node in _data['down'] if not _check_is_broken(node, broken_nodes=broken_nodes)]

        def _mapping(history_list, config_response):
            """
            Mapping ngp action item from Config API Response and cdb Push request history list

            :param history_list: Push request history (history_id, action_id) pair list
            :param config_response: Config API response
            :returns: (dict) Mapped Response
            """
            mapped = {}
            if config_response is not None:
                config_response = simplejson.loads(config_response)
            else:
                config_response = {}

            broken_nodes = Node.objects.filter(broken=True).values_list('hostname', flat=True)
            for h in history_list:
                history_id = h[0]
                action_id = h[1]
                api_response = _get_related_config_response(action_id, config_response)

                try:
                    if action_id:
                        mapped[history_id] = api_response
                except Exception:
                    pass

            return mapped
        # start of main function 'progress'#

        if len(history_id_list) > 0:
            if "job" in str(history_id_list[0]):
                history_ids = [i for i in _strip_id(history_id_list)]
            else:
                history_ids = [i for i in history_id_list]
        else:
            history_ids = []

        try:
            qs = self.push_history.filter(pk__in=history_ids)\
                                    .values_list('config_push_request_history', 'action')
            action_id_list = [i[1] for i in qs if i[1]]
            all_action_id_list = self.spectrum_api._get_related_action_ids(action_id_list)
            data = self.config_api._config_api_push_progress(all_action_id_list)
        except Exception, e:
            raise e

        res_data = _mapping(qs, data)
        return res_data

    ### end of __init__###

    def history(self, size=20, types=None, description=None,
                user=None, customer=None, draft=None, only_in_progress=None):
        """
        Recent BE_CONFIG push history: return ConfigPushRequestHistory queryset
        if size == -1 return last 7days of request history

        :param size: Number of returned push histories, Default 20
        :param types: filter by push Config Type list or string
                      ( CONTENT_DISTRIBUTION, HTTP_SITES, SYSTEM_LOAD_LIMIT, DNS )
        :param description: filter by push description
        :param user: filter by push user
        :param only_in_progress: message to display
        :returns: (list) filtered NGP BE_CONFIG push history list: ConfigPushRequestHistory queryset
        """
        DEFAULT_SIZE = 30
        qs = self.push_history
        if not isinstance(size, int):
            size = 20

        if types:
            if isinstance(types, list):
                _types = []
                for t in types:
                    (g, t, p) = self._get_config_phase_name(t)
                    _types.append(g)
                qs = qs.filter(config_group__in=_types)
            else:
                (types, t, p) = self._get_config_phase_name(types)
                qs = qs.filter(config_group=types)

        if description:
            qs = qs.filter(desc__icontains=description)

        if user:
            qs = qs.filter(request_user__icontains=user)

        if customer:
            qs = qs.filter(site_draft__customer=customer)

        if draft:
            qs = qs.filter(site_draft=draft)

        if size == -1:
            start = datetime.now() + timedelta(days=-7)
            dated_qs = qs.filter(create_time__gte=start)
            if dated_qs.count() == 0:
                return qs[:DEFAULT_SIZE]
            else:
                return dated_qs
        else:
            return qs[:size]

    def push(self, phase, request_user, is_staging=False, site_draft_id=None, description="", skip_testing=False, history_revision=0):
        """
        Request BE_CONFIG push

        :param skip_testing: If enabled, pushed config(s) will be propagated to target production nodes without testing
        :param phase: phase push id ( list or string ), Defiend in `ci.common.models.pusher.BE_CONFIG_GROUP`
        :param request_user: push requester user name
        :param site_draft_id: Site Draft ID ( this parameter works "PUSH_SITESNG" )
        :param description: push description
        :returns: NGP BE_CONFIG push history item(s)
        """
        ngp_nodes = Node.objects.filter(ngp_flag=True)
        if not ngp_nodes.exists():
            return False

        if isinstance(phase, list):
            request = []
            for phase_code in phase:
                phase_id = self.spectrum_api.pusher_code_to_phase_id(phase_code, skip_testing, is_staging=is_staging)
                (group_name, type_name, phase_name) = self._get_config_phase_name(phase_code, skip_testing, is_staging=is_staging)
                request_item = self._save_request(
                    config_group=group_name,
                    config_type=type_name,
                    config_phase=phase_name,
                    phase=phase_id,
                    request_user=request_user,
                    site_draft_id=site_draft_id,
                    desc=description,
                    history_revision=history_revision
                )
                request.append(request_item)
        else:
            phase_id = self.spectrum_api.pusher_code_to_phase_id(phase, skip_testing, is_staging=is_staging)
            (group_name, type_name, phase_name) = \
                self._get_config_phase_name(phase, skip_testing, is_staging=is_staging)
            request = self._save_request(
                    config_group=group_name,
                    config_type=type_name,
                    config_phase=phase_name,
                    phase=phase_id,
                    request_user=request_user,
                    site_draft_id=site_draft_id,
                    desc=description,
                    history_revision=history_revision
                )

        return request


    def _save_request(self, config_group, config_type, config_phase, phase, request_user, site_draft_id=None, desc="", history_revision=0):
        """
        (internal )Request BE_CONFIG push

        :param skip_testing: If enabled, pushed config(s) will be propagated to target production nodes without testing
        :param phase: phase push id ( list or string ), Defiend in `ci.common.models.pusher.BE_CONFIG_GROUP`
        :param request_user: push requester user name
        :param site_draft_id: Site Draft ID ( this parameter works "PUSH_SITESNG" )
        :param desc: push description
        :returns: NGP BE_CONFIG push history item
        """

        push_request = self._model(
                    config_group=config_group,
                    config_type=config_type,
                    config_phase=config_phase,
                    phase=phase,
                    request_user=request_user,
                    desc=desc,
                    history_revision=history_revision
        )

        if config_group == 'HTTP_SITES':
            push_request.site_draft = site_draft_id

        push_request.save()

        return push_request
