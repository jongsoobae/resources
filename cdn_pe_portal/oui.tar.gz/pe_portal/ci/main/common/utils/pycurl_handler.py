"""
This script abstracts the work needed to do many curl requests in parallel.
To accomplish this it has a process request script which takes a list of CurlHandler class objects.
To use the script subclass CurlHandler as described in its comments and then make calls to processRequest with a list
of CurlHandler objects (children classes) and it will process all requests handed then return to the originator.  

If a logging element is provided to processRequests it will write any output there, otherwise it will print to standard out. 

For each request type a class which is a subclass of CurlHandler needs to be created.  
The class has several methods will be called at different times to accomplish the request.
See that class definition below for further explanation about the functions there.

Each call to processRequests needs 1 parameter of a list of CurlHandlers.  
"""

import time
import hashlib
import pycurl
import logging
from StringIO import StringIO
from datetime import datetime
import socket
socket.setdefaulttimeout(5) #this is for the httpconnections...

def authGenerator(hostname, localIP):
        authTime=int(time.time())+10000
        auth=hashlib.sha1("p@nther!%s%s%s" %(hostname,authTime,localIP)).hexdigest()
        return "authTime=%d;auth=%s" %(authTime,auth)

class CurlHandler():
	"""
	This is an abstract  class that handles running a curl and parsing the response.

	There are 4 required functions to override:
		getOptions
		getUnsetOptions
		handleResponse
		handleError
	There is 1 optional function to override:
		finished
	"""
	def __init__(self, *args, **kwargs):
		"""feel free to write a custom init for any advanced creation techniques.
		This one is just here to handle conversion from older uglier code.
		"""
		self.taskDict = kwargs.pop('taskDict',{})
		if self.taskDict == {} and len(args) == 1:
			self.taskDict = args[0]
	def getOptions(self):
		"""per task sets curl option for request

		Needs to return a dictionary of all the curl options
		in order to successfully make the desired request`"""
		raise Exception("getOptions definition must be overriden")
	def getUnsetOptions(self):
		"""this needs to back out getOptions settings 

		In order to restore the curl object to original state
		as they are recycled for speed"""
		raise Exception("getUnusetOptions definition must be overriden")
	def handleResponse(self, responseText):
		"""called on successful curl request
		
		This should handle parsing/storing the result
		as well returning a list of more CurlHandler objects
		if there are more curl's to run after this"""
		raise Exception("handleRespone definition must be overriden")
	def handleError(self, responseText, errorNumber, errorMessage):
		"""called on failed curl request

		This should handle storing the failed result
		as well returning a list of more CurlHandler objects
		if there are more curl's to run after this"""
		raise Exception("handleError definition must be overriden")
	def finished(self):
		"""Called after the appropiate handle function is called
		
		**Optional**
		The point of this is to do any final work before this object
		is no longer used.  Good spot to do any cleanup or response type
		independent work."""
		pass

def readWhileAvaliable(multiCurl):
	#run the internal curl state machine for the multi stack
	while 1:
		ret, numHandles = multiCurl.perform()
		if ret != pycurl.E_CALL_MULTI_PERFORM:
			break

def processRequests(list_CurlHandler, log = False, defaultCurlOptions=None, numConnections=50):
	#numConnections = 50 #concurrent http processes
	maxTimeExceeded = 3000 #seconds to consider the script in invalid state
	logTimeInterval = 60 #how often should log warning of progress time
	#these are used for all connections (a type of connection could override in their getOptions function
	if not defaultCurlOptions:
		defaultCurlOptions = { 
			pycurl.CONNECTTIMEOUT: 10,
			pycurl.TIMEOUT: 20,
			pycurl.NOBODY: 0,
			pycurl.HEADER: 0,
			pycurl.FOLLOWLOCATION: 0,
		}
	if not isinstance(list_CurlHandler,list):
		mess = "processRequests accepts only a list"
		if log:
			logging.error(mess)
		else:
			print mess
		raise TypeError("Invalid list_CurlHandler argument")

	#the queue to process...
	queue = list_CurlHandler

	#Below is implementation using pycurl (libcurl extension for python)
	#This was built off of an example on the pycurl site which can be found at:
	#http://pycurl.cvs.sourceforge.net/pycurl/pycurl/examples/retriever-multi.py?revision=1.29&view=markup

	#Create curl worker objects...
	multiCurl = pycurl.CurlMulti()
	multiCurl.handles = []
	for loop in range(numConnections):
		#static headers to always use
		#when executing each object will add specific headers
		curlObject = pycurl.Curl()
		for key in defaultCurlOptions:
			curlObject.setopt(key, defaultCurlOptions[key])
		curlObject.handler = None
		curlObject.stringOutput = None
		multiCurl.handles.append(curlObject)

	#do concurrent requests using worker curl objects...
	availableCurlObjects = multiCurl.handles[:]

	startTime = datetime.now()
	lastLogTime = startTime = datetime.now()
	while len(queue) > 0 or len(availableCurlObjects) < numConnections:
		#keep going until all work is complete...
		currentTime = datetime.now()
		if (currentTime - startTime).seconds > maxTimeExceeded:
			mess = "Max process time exceeded, started: " + tr(startTime) + ", now: " + str(currentTime)
			if log:
				logging.error(mess)
			else:
				print mess
			break
		elif (currentTime - lastLogTime).seconds > logTimeInterval:
			mess = "Process execution has been running for " + str(currentTime - startTime)
			if log:
				logging.info(mess)
			else:
				print mess
			lastLogTime = currentTime
		while len(queue) > 0 and len(availableCurlObjects) > 0:
			#if there is a queue object to process and a free curl object add to multi stack...
			curlObject = availableCurlObjects.pop(0)
			if curlObject.stringOutput != None and not curlObject.stringOutput.closed:
				curlObject.stringOutput.close()
			curlObject.stringOutput = None
			curlObject.handler = queue.pop(0) #get work item
			if not isinstance(curlObject.handler,CurlHandler):
				#something went wrong, add back to available workers queue
				#we did get item out of task queue atleast
				curlObject.handler = None
				mess = "Queue item not a CurlHandler child which is a requirement"
				if log:
					logging.error(mess)
				else:
					print mess
				availableCurlObjects.append(curlObject)
				continue
				
			for opt, value in curlObject.handler.getOptions().items():
				try:
					curlObject.setopt(opt,value)
				except Exception, e:
					mess = "error for option: %s and value %s of type %s" %(str(opt), str(value), str(type(value)))	
					if log:
						logging.info(mess)
					else:
						print mess
					raise e
			curlObject.stringOutput = StringIO()
			curlObject.setopt(pycurl.WRITEFUNCTION, curlObject.stringOutput.write)
			multiCurl.add_handle(curlObject)
		readWhileAvaliable(multiCurl)
		#check for curl objects which have terminated and process/put them back in queue
		while 1:
			numQ, okList, errorList = multiCurl.info_read()
			for curlObject in okList:
				readWhileAvaliable(multiCurl) #as operations can take a while, keep reading
				multiCurl.remove_handle(curlObject)
				#process result....
				resp = curlObject.handler.handleResponse(curlObject.stringOutput.getvalue())
				curlObject.handler.finished()
				if resp != None:
					for handler in resp:
						if not isinstance(handler,CurlHandler):
							mess = "Potential queue item is not a subclass of CurlHandler"
							if log:
								logging.error(mess)
							else:
								print mess
						else:
							queue.append(handler)
				for opt, value in curlObject.handler.getUnsetOptions().items():
					if defaultCurlOptions.has_key(opt):
						curlObject.setopt(opt,defaultCurlOptions[opt])
					else:
							curlObject.setopt(opt,value)

				curlObject.handler = None
				if curlObject.stringOutput != None and not curlObject.stringOutput.closed:
					curlObject.stringOutput.close()
				curlObject.stringOutput = None	
				#done processing result...
				availableCurlObjects.append(curlObject)
			for curlObject, errorNumber, errorMessage in errorList:
				readWhileAvaliable(multiCurl) #as operations can take a while, keep reading
				multiCurl.remove_handle(curlObject)
				#process failure...
				resp = curlObject.handler.handleError(curlObject.stringOutput.getvalue(), errorNumber, errorMessage)
				curlObject.handler.finished()
				if resp != None:
					for handler in resp:
						if not isinstance(handler,CurlHandler):
							mess = "Potential queue item is not a subclass of CurlHandler"
							if log:
                                                        	log.error(mess)
							else:
								print mess
                                                queue.append(handler)
				for opt, value in curlObject.handler.getUnsetOptions().items():
					if defaultCurlOptions.has_key(opt):
						curlObject.setopt(opt,defaultCurlOptions[opt])
					else:
						curlObject.setopt(opt,value)
				curlObject.handler = None
				if curlObject.stringOutput != None and not curlObject.stringOutput.closed:
					curlObject.stringOutput.close()
				curlObject.stringOutput = None
				#done processing result...
				availableCurlObjects.append(curlObject)
			if numQ == 0:
				break
		multiCurl.select(1.0)

	#cleanup...should just have to close curlObject and multiCurl but check to make sure...
	for curlObject in multiCurl.handles:
		if curlObject.handler != None and not curlObject.stringOutput == None and not curlObject.stringOutput.closed: 
			curlObject.handler.handleResponse(curlObject.stringOutput.getvalue())
		elif curlObject.handler != None:
			curlObject.handler.handleError(curlObject.stringOutput.getvalue(),-1,'')
			curlObject.handler.finished()
		if not curlObject.stringOutput == None and not curlObject.stringOutput.closed:
			curlObject.stringOutput.close()
		curlObject.close()
	multiCurl.close()
