import re

def match_list(string_list):
	return [re.compile(d) for d in string_list]

def matches_any(patterns, path):
	path = re.sub(r'^/','',path) # trim leading slash
	for pattern in patterns:
		if pattern.match(path):
			return True
	return False
