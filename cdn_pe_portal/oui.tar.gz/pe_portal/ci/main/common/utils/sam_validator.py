import re
from django.utils import simplejson as json
from ci.common.models.sam_admin import SamRuleItemField, req_required


class ItemFieldTypes(object):
    id = ''
    name = ''
    data = ''
    c_regex = ''
    default = ''
    errors = {}
    fields = ['field_type', 'field_name', 'default', 'display_name', 'c_regex',
              'min_value', 'max_value', 'description', 'data', 'is_base']

    def __init__(self, admin_data_dict):
        self.admin_data_dict = admin_data_dict
        self.data = admin_data_dict.get('data')
        self.c_regex = admin_data_dict.get('c_regex')
        self.errors = {}
        self.default = self.admin_data_dict.get('default')

    def validate_for_admin(self):
        return True

    def validate_for_input(self, input_value):
        if self.admin_data_dict['required'] == req_required[0] and (input_value == '' or input_value is None):
            self.errors = {'detail': 'This field is required.'}
            return False
        return True

    def get_save_data_for_admin(self):
        for key, value in self.admin_data_dict.items():
            if key not in self.fields:
                del self.admin_data_dict[key]
        return self.admin_data_dict

    @staticmethod
    def is_valid_json(possible_json):
        try:
            json.loads(possible_json)
            return True
        except ValueError:
            return False

    @staticmethod
    def is_valid_regex(possible_regex):
        try:
            re.compile(possible_regex)
            return True
        except re.error:
            return False

    @staticmethod
    def is_dict_has_only_num_str(dict_obj):
        if not isinstance(dict_obj, dict):
            return False

        for (key, value) in dict_obj.items():
            if not isinstance(value, (str, int, long, float, unicode)):
                return False
        return True

    @staticmethod
    def json_load(possible_json):
        try:
            return json.loads(possible_json)
        except (ValueError, ):
            return ''

    @staticmethod
    def is_number(check_num):
        if isinstance(check_num, (int, long, float, complex)):
            return True
        elif isinstance(check_num, (str, unicode)):
            try:
                float(check_num)
                return True
            except(Exception, ):
                pass
            try:
                int(check_num)
                return True
            except(Exception, ):
                pass
            try:
                long(check_num)
                return True
            except(Exception, ):
                pass
        return False

    @staticmethod
    def get_number(check_num):
        if isinstance(check_num, (int, long, float, complex)):
            return check_num
        elif isinstance(check_num, (str, unicode)):
            try:
                return int(check_num)
            except(Exception, ):
                pass
            try:
                return long(check_num)
            except(Exception, ):
                pass
            try:
                return float(check_num)
            except(Exception, ):
                pass
        return None


class FieldTypeSelect(ItemFieldTypes):
    fields = ['field_type', 'field_name', 'default', 'display_name', 'description', 'data', 'is_base']

    def validate_for_admin(self):
        if not self.data:
            self.errors['data'] = 'Not allowed empty data for this type.'
            return False
        if not self.is_valid_json(self.data):
            self.errors['data'] = 'Not a valid json.'
            return False
        if not self.is_dict_has_only_num_str(self.json_load(self.data)):
            self.errors['data'] = 'Json must be only key, value. Don`t use nested json.'
            return False
        if self.default and self.default not in self.json_load(self.data):
            self.errors['default'] = 'Default value is not a valid.'
            return False

        return True

    def validate_for_input(self, input_value):
        if not super(FieldTypeSelect, self).validate_for_input(input_value):
            return False
        if not self.validate_for_admin():
            self.errors = {
                'detail': 'Cannot use this type. Please contact to administrator.'
            }
            return False

        if input_value in json.loads(self.data):
            return True
        else:
            self.errors = {'detail': '%s is not allowed.' % input_value}
            return False


class FieldTypeMultiSelect(ItemFieldTypes):
    fields = ['field_type', 'field_name', 'default', 'display_name', 'description', 'data', 'is_base']

    def __init__(self, admin_data_dict):
        super(FieldTypeMultiSelect, self).__init__(admin_data_dict=admin_data_dict)

    def validate_for_admin(self):
        if not self.data:
            self.errors['data'] = 'Not allowed empty data for this type.'
            return False
        if not self.is_valid_json(self.data):
            self.errors['data'] = 'Not a valid json.'
            return False
        if not self.is_dict_has_only_num_str(self.json_load(self.data)):
            self.errors['data'] = 'Json must be only key, value. Don`t use nested json.'
            return False
        if self.default:
            if ',' in self.default:
                for dv in self.default.split(','):
                    if dv not in self.json_load(self.data):
                        self.errors['default'] = 'Default value is not a valid.'
                        return False
            else:
                if self.default not in self.json_load(self.data):
                    self.errors['default'] = 'Default value is not a valid.'
                    return False

        return True

    def validate_for_input(self, input_values):
        if not super(FieldTypeMultiSelect, self).validate_for_input(input_values):
            return False
        if not self.validate_for_admin():
            self.errors = {
                'detail': 'Cannot use this type. Please contact to administrator.'
            }
            return False
        if ',' in input_values:
            for input_value in input_values.split(','):
                if input_value not in json.loads(self.data):
                    self.errors = {'detail': '%s is not allowed.' % input_value}
                    return False
        else:
            if input_values and input_values not in json.loads(self.data):
                self.errors = {'detail': '%s is not allowed.' % input_values}
                return False
        return True


class FieldTypeString(ItemFieldTypes):
    fields = ['field_type', 'field_name', 'default', 'display_name', 'c_regex', 'description', 'is_base']

    def validate_for_admin(self):
        if self.c_regex and not self.is_valid_regex(self.c_regex):
            self.errors['c_regex'] = 'Not a valid regex.'
        if self.c_regex and self.default and not re.match(self.c_regex, self.default):
            self.errors['default'] = 'Default value is not a valid.'

        if len(self.errors) >= 1:
            return False
        return True

    def validate_for_input(self, input_value):  # if regex, need to check regex with c_regex.
        if not super(FieldTypeString, self).validate_for_input(input_value):
            return False
        if not self.c_regex or re.match(self.c_regex, input_value):
            return True
        else:
            self.errors['detail'] = '%s is not allowed.' % input_value
            return False

class FieldTypeRegex(ItemFieldTypes):
    fields = ['field_type', 'field_name', 'default', 'display_name', 'description', 'is_base']

    def validate_for_admin(self):
        if self.default and not self.is_valid_regex(self.default):
            self.errors['default'] = 'Default value is not a valid regex.'
            return False
        return True

    def validate_for_input(self, input_value):  # if regex, need to check regex with c_regex.
        if not super(FieldTypeRegex, self).validate_for_input(input_value):
            return False
        if not self.is_valid_regex(input_value):
            self.errors['detail'] = '%s is not a valid regex.' % input_value
            return False
        return True


class FieldTypeNumber(ItemFieldTypes):
    fields = ['field_type', 'field_name', 'default', 'display_name', 'min_value', 'max_value', 'description', 'is_base']
    min_value = None
    max_value = None

    def __init__(self, admin_data_dict):
        super(FieldTypeNumber, self).__init__(admin_data_dict)
        self.min_value = admin_data_dict.get('min_value')
        self.max_value = admin_data_dict.get('max_value')
        if self.min_value != 0 and not self.min_value:
            self.min_value = None
        if self.max_value != 0 and not self.max_value:
            self.max_value = float('inf')

    def validate_for_admin(self):
        if self.min_value and not self.is_number(self.min_value):
            self.errors['min_value'] = 'Min value must be number.'
        if self.max_value and not self.is_number(self.max_value):
            self.errors['max_value'] = 'Max value must be number.'
        if len(self.errors) >= 1:
            return False

        if self.min_value and self.max_value and self.get_number(self.min_value) > self.get_number(self.max_value):
            self.errors['min_value'] = 'Max value must bigger than Min value.'

        value_valid, value_error_message = self.check_for_input(self.default)
        if not value_valid:
            self.errors['default'] = value_error_message

        if len(self.errors) >= 1:
            return False
        return True

    def validate_for_input(self, input_value):
        if not super(FieldTypeNumber, self).validate_for_input(input_value):
            return False
        if not self.validate_for_admin():
            self.errors = {'detail': 'Cannot use this type. Please contact to administrator.'}
            return False

        value_valid, value_error_message = self.check_for_input(input_value)
        if not value_valid:
            self.errors = {'detail': value_error_message}
        return value_valid

    def check_for_input(self, input_value):
        if not input_value:
            return True, None
        if not self.is_number(input_value):
            return False, 'This value must be number.'
        if self.get_number(self.min_value) <= self.get_number(input_value) <= self.get_number(self.max_value):
            return True, None
        else:
            return False, 'This field is allowed range %s ~ %s' % (self.min_value, 'infinite' if self.max_value == float('inf') else self.max_value)


class FieldTypeBoolean(ItemFieldTypes):
    fields = ['field_type', 'field_name', 'default', 'display_name', 'description', 'data', 'is_base']

    def validate_for_admin(self):
        if not self.data:
            self.errors['data'] = 'Not allowed empty data for this type.'
            return False
        if not self.is_valid_json(self.data):
            self.errors['data'] = 'Not a valid json.'
            return False
        if not self.is_dict_has_only_num_str(self.json_load(self.data)):
            self.errors['data'] = 'Json must be only key, value. Don`t use nested json.'
            return False
        if self.default and self.default not in self.json_load(self.data):
            self.errors['default'] = 'Default value is not a valid.'
            return False
        return True

    def validate_for_input(self, input_value):
        if not super(FieldTypeBoolean, self).validate_for_input(input_value):
            return False
        if not self.validate_for_admin():
            self.errors = {
                'detail': 'Cannot use this type. Please contact to administrator.'
            }
            return False

        if input_value in json.loads(self.data):
            return True
        else:
            self.errors = {'detail': '%s is not allowed.' % input_value}
            return False


class FieldTypeText(ItemFieldTypes):
    fields = ['field_type', 'field_name', 'default', 'display_name', 'c_regex', 'description', 'is_base']

    def validate_for_admin(self):
        if self.c_regex and not self.is_valid_regex(self.c_regex):
            self.errors['c_regex'] = 'Not a valid regex.'
        if self.c_regex and self.default and not re.match(self.c_regex, self.default):
            self.errors['default'] = 'Default value is not a valid.'

        if len(self.errors) >= 1:
            return False
        return True

    def validate_for_input(self, input_value):  # if regex, need to check regex with c_regex.
        if not super(FieldTypeText, self).validate_for_input(input_value):
            return False
        if not self.c_regex or re.match(self.c_regex, input_value):
            return True
        else:
            self.errors['detail'] = '%s is not allowed.' % input_value
            return False


class SamRuleAdminValidator(object):

    field_types = {
        '1': FieldTypeString,
        '2': FieldTypeSelect,
        '3': FieldTypeMultiSelect,
        '4': FieldTypeRegex,
        '5': FieldTypeNumber,
        '6': FieldTypeBoolean,
        '7': FieldTypeText
    }

    def __init__(self, field_type, admin_data_dict):
        self.field_type = self.field_types[field_type](admin_data_dict)

    def validate_for_admin(self):
        if not self.field_type.validate_for_admin():
            errors = self.field_type.errors
            return False, errors
        return True, None

    def validate_for_input(self, input_value):
        if input_value is None:
            input_value = ''
        if not self.field_type.validate_for_input(input_value):
            errors = self.field_type.errors
            return False, errors
        return True, None

    def get_save_data_for_admin(self):
        return self.field_type.get_save_data_for_admin()
