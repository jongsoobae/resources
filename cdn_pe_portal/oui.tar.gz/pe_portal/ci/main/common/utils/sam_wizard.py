import copy
from ci.common.models import Site, SiteDraft
from ci.common.models.sam_admin import SamRuleItem, SamRuleItemBaseConditionField, SamRuleItemBaseActionField, \
    field_type_select, field_type_multi_select, field_type_boolean, CustomerControlSam
from django.utils import simplejson as json
from ci.common.utils.api import APIException
from ci.common.utils.sam_validator import SamRuleAdminValidator
from ci.common.utils import simplejson as sjson
from ci.common.utils.site import save_site_change_history
from ci.common.utils.json_load_ordered import json_load_ordered
import simplejson as sjson


def check_add(site_id=0):
    try:
        sandbox = SiteDraft.objects.get(pk=site_id)
        this_hash = sandbox.server_actions_hash()
    except SiteDraft.DoesNotExist:
        this_hash = SiteDraft().server_actions_hash()

    return {'factor': 'success', 'hash': this_hash}


def get_sam_prod_all_rule(site_id=0):
    display_json = []
    try:
        site = Site.objects.get(pk=site_id)
        site_json = site.json_server_actions_for_proc_default()
        for rule in site_json:
            copied_rule = copy.deepcopy(rule)
            get_display_json_for_one_rule(copied_rule)
            display_json.append(copied_rule)

    except Site.DoesNotExist:
        raise APIException('There is no samrule on this site_id(%s)' % site_id)

    return {'factor': 'success', 'data': site_json, 'display_data': display_json}


def get_sam_sandbox_all_rule_cui(site_id=0):
    display_json = []
    try:
        sam_sandbox = SiteDraft.objects.get(pk=site_id)
        sam_json = sam_sandbox.json_server_actions_for_proc_default()
        this_hash = sam_sandbox.server_actions_hash()
        if sam_json:
            for rule in sam_json:
                copied_rule = copy.deepcopy(rule)
                get_display_json_for_one_rule(copied_rule)
                display_json.append(copied_rule)

    except SiteDraft.DoesNotExist:
        sam_json = None
        this_hash = SiteDraft().server_actions_hash()

    return {'factor': 'success', 'data': sam_json, 'display_data': display_json, 'hash': this_hash}


def get_sam_sandbox_rule(site_id=0, rule_id=0, customer=None):
    try:
        expose_for_customer_message = ''
        sam_sandbox = SiteDraft.objects.get(pk=site_id)
        sam_json = sam_sandbox.json_server_actions_for_proc_default()
        if not sam_json:
            target_rule = ''
        else:
            target_rule = sam_sandbox.json_server_actions_for_proc_default()[int(rule_id)]
        this_hash = sam_sandbox.server_actions_hash()
        try:
            check_expose_for_customer(target_rule, customer=customer)
        except APIException, e:
            expose_for_customer_message = e.message

    except SiteDraft.DoesNotExist:
        raise APIException('There is no samrule on this site_id(%s)' % site_id)
    except IndexError:
        raise APIException('Wrong access.')

    return {
        'factor': 'success', 'data': target_rule, 'hash': this_hash,
        'editable': not expose_for_customer_message,
        'not_editable_message': expose_for_customer_message
    }


def check_expose_for_customer(rule_data, customer=None):
    conditions = rule_data.get('if', None)
    if conditions:
        condition_list = get_condition_list_from_json(conditions)
        condition_ids = [(c['id'] if 'id' in c else '') for c in condition_list]
        for cid in list(set(condition_ids)):
            if not check_can_edit(cid, customer=customer):
                raise APIException({
                    'if': {cid: 'This condition is not editable.'}
                })

    actions = rule_data.get('do', None)
    if actions:
        action_ids = [(a['id'] if 'id' in a else '') for a in actions]
        for aid in list(set(action_ids)):
            if not check_can_edit(aid, customer=customer):
                raise APIException({
                    'do': {aid: 'This action is not editable.'}
                })


def rule_validation(rule_data, cui=False, customer=None):  # use oui
    errors = {}
    if 'name' not in rule_data or not rule_data['name']:
        errors.update({'name': 'This field is required.'})
    if 'proc' not in rule_data or not rule_data['proc']:
        errors.update({'proc': 'This field is required.'})

    validate_fields = ['if', 'do', 'name', 'proc', 'rule_id']
    if type(rule_data) not in [dict, sjson.OrderedDict]:
        raise APIException('This rule is not acceptable.')

    for key in rule_data.keys():
        if key not in validate_fields:
            errors.update({key: 'This field is not allowed.'})

    if len(errors) >= 1:
        raise APIException(errors)

    if cui:
        check_expose_for_customer(rule_data, customer=customer)

    conditions = rule_data.get('if', None)
    if conditions:
        if type(conditions) not in [dict, sjson.OrderedDict]:
            raise APIException({'if': 'This field is must be JSON object type.'})
        condition_list = get_condition_list_from_json(conditions)
        if get_condition_max_depth(conditions) > 14:
            raise APIException({'if': 'Maximum depth of condition is 14.'})

        cur_id = ''
        try:
            for condition in condition_list:
                cur_id = condition['id']
                validation_for_one_rule_item(condition)
        except APIException, e:
            raise APIException({'if': {cur_id: e.message}})
        except Exception:
            raise APIException({'if': 'This field is not acceptable.'})

    actions = rule_data.get('do', None)
    if actions:
        if type(actions) is not list:
            raise APIException({'do': 'This field is must be JSON array type.'})

        cur_id = ''
        try:
            for action in actions:
                cur_id = action['id']
                validation_for_one_rule_item(action)
        except APIException, e:
            raise APIException({'do': {cur_id: e.message}})
        except Exception:
            raise APIException({'do': 'This field is not acceptable.'})


def get_condition_list_from_json(conditions):
    if 'c' not in conditions:
        return [conditions]
    if not isinstance(conditions['c'], list):
        return [conditions]
    return_list = []
    for c in conditions['c']:
        return_list = return_list + get_condition_list_from_json(c)
    return return_list


def get_condition_max_depth(conditions):
    deepest = 0
    if 'c' not in conditions:
        return deepest
    if not isinstance(conditions['c'], list):
        return deepest
    for condition in conditions['c']:
        deepest = max(deepest, get_condition_max_depth(condition))
    return deepest + 1


def validation_for_one_rule_item(rule_item_obj):
    try:
        rule_item = SamRuleItem.objects.get(rule_item_str_id=rule_item_obj.get('id'))
        field_list = [b for b in rule_item.get_base_fields()] + [f for f in rule_item.samruleitemfield_set.all()]

        validation_data = [(field.field_type, field.to_json()) for field in field_list]

        validation_errors = {}
        for data in validation_data:
            validator = SamRuleAdminValidator(data[0], data[1])
            if data[1]['field_name'] in rule_item_obj:
                is_valid, errors = validator.validate_for_input(rule_item_obj[data[1]['field_name']])
                if errors:
                    message = errors['detail']
                    errors['detail'] = '%s at [%s] type - [%s] field ' % (
                        message, rule_item_obj['id'], data[1]['field_name'])
                    validation_errors[data[1]['field_name']] = message
        if len(validation_errors) > 0:
            raise APIException(validation_errors)

    except APIException, e:
        raise e
    except (SamRuleItem.DoesNotExist, ):
        if not rule_item_obj.get('id'):
            raise APIException({'id': 'This field is required.'})
        else:
            raise APIException({'id': 'This ID is not exists (%s).' % rule_item_obj['id']})
    except (Exception,), ee:
        raise ee


def check_rule_item_validate(body_data=None):  # use oui
    if not body_data:
        body_data = {}
    validation_for_one_rule_item(body_data)  # if error, raise APIException
    return {'factor': 'success'}


def add_sam_sandbox(site_id=0, body_data=None, aurora_user_id='', customer=None):  # just used for api.
    if not body_data:
        body_data = {}
    try:
        page_hash = body_data.get('hash')
        rule_data = body_data.get('rule_data', [])

        if not page_hash:
            raise APIException('There is a problem to edit this item.'
                               'Please refresh your page.')

        if type(rule_data) is not list:
            raise APIException('Sam json is not valid. It must be list type.')

        for rule in rule_data:
            rule_validation(rule, cui=True, customer=customer)
        try:
            sam_sandbox = SiteDraft.objects.get(pk=site_id)
            if page_hash != sam_sandbox.server_actions_hash():
                raise APIException('There has been a change to this rule set. '
                                   'Please refresh your page before trying to make changes')

        except SiteDraft.DoesNotExist:
            raise APIException('There is no pad.')

        sam_sandbox.server_action_rules = json.dumps(rule_data, indent=4)
        sam_sandbox.save_as_modified()
        save_site_change_history(sitedraft=SiteDraft.objects.get(pk=sam_sandbox.pk),
                                 username=aurora_user_id,
                                 ops_type=1 if sam_sandbox else 0,
                                 description="save SAM from Control Portal.")
    except APIException, ae:
        raise ae

    return {'factor': 'success', 'site_id': site_id, 'hash': sam_sandbox.server_actions_hash()}


def add_sam_sandbox_rule(site_id=0, body_data=None, aurora_user_id='', customer=None):
    if not body_data:
        body_data = {}
    try:
        page_hash = body_data.get('hash')
        rule_data = body_data.get('rule_data', {})

        if not page_hash:
            raise APIException('There is a problem to edit this item.'
                               'Please refresh your page.')

        rule_validation(rule_data, cui=True, customer=customer)
        try:
            sam_sandbox = SiteDraft.objects.get(pk=site_id)
            sam_action_json = sam_sandbox.json_server_actions_for_proc_default()
            if page_hash != sam_sandbox.server_actions_hash():
                raise APIException('There has been a change to this rule set. '
                                   'Please refresh your page before trying to make changes')

        except SiteDraft.DoesNotExist:
            sam_sandbox = SiteDraft()
            sam_sandbox.site_id = site_id
            sam_action_json = []

        if not sam_action_json:
            sam_action_json = []
        rule_id = len(sam_action_json)

        sam_action_json.append(rule_data)

        sam_sandbox.server_action_rules = json.dumps(sam_action_json, indent=4)
        sam_sandbox.save_as_modified()
        save_site_change_history(sitedraft=SiteDraft.objects.get(pk=sam_sandbox.pk),
                                 username=aurora_user_id,
                                 ops_type=1 if sam_sandbox else 0,
                                 description="save SAM from Control Portal.")
    except APIException, ae:
        raise ae

    return {'factor': 'success', 'site_id': site_id, 'rule_id': rule_id, 'hash': sam_sandbox.server_actions_hash()}


def save_sam_sandbox_rule(body_data=None, site_id=0, rule_id=0, aurora_user_id='', customer=None):
    if not body_data:
        body_data = {}
    try:
        page_hash = body_data.get('hash')
        rule_data = body_data.get('rule_data')

        if not page_hash:
            raise APIException('There is a problem to edit this item.'
                               'Please refresh your page.')

        sam_sandbox = SiteDraft.objects.get(pk=site_id)
        if page_hash != sam_sandbox.server_actions_hash():
            raise APIException('There has been a change to this rule set. '
                               'Please refresh your page before trying to make changes')

        rule_validation(rule_data, cui=True, customer=customer)
        sam_action_json = sam_sandbox.json_server_actions_for_proc_default()
        if not sam_action_json:
            sam_action_json = [rule_data]
        else:
            sam_action_json[int(rule_id)] = rule_data

        sam_sandbox.server_action_rules = json.dumps(sam_action_json, indent=4)
        sam_sandbox.save_as_modified()
        save_site_change_history(sitedraft=SiteDraft.objects.get(pk=sam_sandbox.pk),
                                 username=aurora_user_id,
                                 ops_type=1 if sam_sandbox else 0,
                                 description="save SAM from Control Portal.")

    except SiteDraft.DoesNotExist:
        raise APIException('There is no SAM rule on this site(%s)' % site_id)

    return {'factor': 'success', 'site_id': site_id, 'rule_id': rule_id, 'hash': sam_sandbox.server_actions_hash()}


def delete_sam_sandbox(site_id=0, aurora_user_id=''):  # just used for api
    try:
        sam_sandbox = SiteDraft.objects.get(pk=site_id)
        sam_sandbox.server_action_rules = ''
        sam_sandbox.save_as_modified()
        save_site_change_history(sitedraft=SiteDraft.objects.get(pk=sam_sandbox.pk),
                                 username=aurora_user_id,
                                 ops_type=1 if sam_sandbox else 0,
                                 description="save SAM from Control Portal.")

    except SiteDraft.DoesNotExist:
        raise APIException('There is no SAM rule on this site(%s)' % site_id)

    return {'factor': 'success', 'site_id': site_id, 'hash': sam_sandbox.server_actions_hash()}


def delete_sam_sandbox_rule(site_id=0, rule_id=0, aurora_user_id=''):
    try:
        sam_sandbox = SiteDraft.objects.get(pk=site_id)
        sam_action_json = sam_sandbox.json_server_actions_for_proc_default()

        del sam_action_json[int(rule_id)]

        sam_sandbox.server_action_rules = json.dumps(sam_action_json, indent=4)
        sam_sandbox.save_as_modified()
        save_site_change_history(sitedraft=SiteDraft.objects.get(pk=sam_sandbox.pk),
                                 username=aurora_user_id,
                                 ops_type=1 if sam_sandbox else 0,
                                 description="save SAM from Control Portal.")

    except SiteDraft.DoesNotExist:
        raise APIException('There is no SAM rule on this site(%s)' % site_id)

    return {'factor': 'success', 'site_id': site_id, 'rule_id': rule_id, 'hash': sam_sandbox.server_actions_hash()}


def sortup_sam_sandbox_rule(this_hash, site_id=0, rule_id=0):
    if not this_hash:
        raise APIException('Wrong access!')

    try:
        if rule_id <= 0:
            raise APIException('Can`t sort up this item.')
        sam_sandbox = SiteDraft.objects.get(pk=site_id)

        if this_hash != sam_sandbox.server_actions_hash():
            raise APIException('There has been a change to this rule set. '
                               'Please refresh your page before trying to make changes')

        sam_json = sam_sandbox.json_server_actions_for_proc_default()
        sam_json[int(rule_id)], sam_json[int(rule_id)-1] = sam_json[int(rule_id)-1], sam_json[int(rule_id)]
        sam_sandbox.server_action_rules = json.dumps(sam_json, indent=4)
        sam_sandbox.save_as_modified()
    except SiteDraft.DoesNotExist:
        raise APIException('There is no SAM rule on this site(%s)' % site_id)
    return {'factor': 'success', 'site_id': site_id, 'rule_id': rule_id, 'hash': sam_sandbox.server_actions_hash()}


def sortdown_sam_sandbox_rule(this_hash, site_id=0, rule_id=0):
    if not this_hash:
        raise APIException('Wrong access!')

    try:
        sam_sandbox = SiteDraft.objects.get(pk=site_id)

        if this_hash != sam_sandbox.server_actions_hash():
            raise APIException('There has been a change to this rule set. '
                               'Please refresh your page before trying to make changes')

        sam_json = sam_sandbox.json_server_actions()
        if int(rule_id) >= len(sam_json):
            raise APIException('Can`t sort down this item.')

        sam_json[int(rule_id)], sam_json[int(rule_id)+1] = sam_json[int(rule_id)+1], sam_json[int(rule_id)]
        sam_sandbox.server_action_rules = json.dumps(sam_json, indent=4)
        sam_sandbox.save_as_modified()
    except SiteDraft.DoesNotExist:
        raise APIException('There is no SAM rule on this site(%s)' % site_id)
    return {'factor': 'success', 'site_id': site_id, 'rule_id': rule_id, 'hash': sam_sandbox.server_actions_hash()}


def get_key_str():  # use oui
    ret_dict = {}

    base_conditions = SamRuleItemBaseConditionField.objects.all().values_list('field_name', 'display_name')
    none_base_conditions = SamRuleItem.condition_objects.all().values_list(
        'samruleitemfield__field_name', 'samruleitemfield__display_name')

    _abase = SamRuleItemBaseActionField.objects.all().values_list('field_name', 'display_name')
    _n_abase = SamRuleItem.action_objects.all().values_list(
        'samruleitemfield__field_name', 'samruleitemfield__display_name')

    for cb in base_conditions:
        ret_dict[cb[0]] = cb[1]

    for cn in none_base_conditions:
        ret_dict[cn[0]] = cn[1]

    for ab in _abase:
        ret_dict[ab[0]] = ab[1]

    for an in _n_abase:
        ret_dict[an[0]] = an[1]
    return ret_dict


def get_display_json_for_one_item(rule_item_json):  # condition, action
    #  ret_json = copy.deepcopy(rule_json)
    ret_json = {}

    if 'id' not in rule_item_json:
        return rule_item_json

    try:
        rule_item = SamRuleItem.objects.get(rule_item_str_id=rule_item_json['id'])
        field_list = [b for b in rule_item.get_base_fields()] + [f for f in rule_item.samruleitemfield_set.all()]

        for field in field_list:
            if field.field_name in rule_item_json:
                value = rule_item_json[field.field_name]
                if field.field_type in [field_type_select[0], field_type_multi_select[0], field_type_boolean[0]]:
                    try:
                        value = json.loads(field.data)[value]
                    except (Exception,):
                        value = value
                ret_json[field.display_name if field.field_name != 'id' else field.field_name] = value

        return ret_json
    except SamRuleItem.DoesNotExist:
        return rule_item_json
    except (Exception, ):
        return rule_item_json


def get_display_json_for_one_rule(rule_json):
    if 'if' in rule_json and len(rule_json['if']) >= 1:
        condition_rule = rule_json['if']
        node_to_visit = [(None, -1, condition_rule)]

        while len(node_to_visit) >= 1:
            parent_node, current_idx, current_node = node_to_visit[0]
            del node_to_visit[0]
            if 'c' in current_node and isinstance(current_node['c'], list):
                c_idx = 0
                for c in current_node['c']:
                    node_to_visit.append((current_node, c_idx, c))
                    c_idx += 1

            else:
                current_node = get_display_json_for_one_item(current_node)
                if parent_node:
                    parent_node['c'][current_idx] = current_node
                else:
                    rule_json['if'] = current_node

    if 'do' in rule_json:
        action_rule = rule_json['do']

        a_idx = 0
        for arule in action_rule:
            action_rule[a_idx] = get_display_json_for_one_item(arule)
            a_idx += 1


def check_can_edit(rule_item_str_id, customer=None):
    if not rule_item_str_id or not customer:
        return False
    try:
        if SamRuleItem.objects.get(rule_item_str_id=rule_item_str_id).expose_for_customer == '0':
            return False

        return CustomerControlSam.objects.filter(customer=customer, sam_rule_item__rule_item_str_id=rule_item_str_id).exists()
    except SamRuleItem.DoesNotExist:
        return False

