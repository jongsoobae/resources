import re
import socket
from urllib2 import Request, urlopen, URLError, HTTPError
from django.db import connections
from django.db.models import BooleanField, IntegerField, PositiveIntegerField, \
        PositiveSmallIntegerField, SmallIntegerField
from django.utils.encoding import smart_unicode
from django.db.models import Q
from django.http import Http404
from django.conf import settings
if "ci.django_mailer" in settings.INSTALLED_APPS:
    from ci.django_mailer import send_mail
else:
    from django.core.mail import send_mail
from ci.constants import MAINTAINER, CDNW_IMPL, SALES_IMPL, NO_REPLY, HTTP_RESPONSE_CODES as http_codes, \
    IMPL_OPS_CS_JP, IMPL_NOC_JP, IMPL_NOC_KR, IMPL_OPS_CS_KR, EMAIL_ALERTS, ENVIRONMENT
from ci.common.models.site import Site, SiteDraft, PADChangeLog, DEPLOY_STATUS_NEW, DEPLOY_STATUS_CHANGED, \
    DEPLOY_STATUS_SELF_PUSHING_STAGE, DEPLOY_STATUS_SELF_FAIL_STAGE, DEPLOY_STATUS_SELF_STAGE, \
    DEPLOY_STATUS_SELF_PUSHING_PROD, DEPLOY_STATUS_SELF_FAIL_PROD, DEPLOY_STATUS_WAITING_REQ, DEPLOY_STATUS_SELF_PROD, \
    DEPLOY_STATUS_DISABLED
from ci.common.models.site_history import CustomerSiteChangeHistory, CustomerSiteSnapshot
from ci.common.utils.alert import send_alert
from ci.constants import TEST_PADS
from ci.common.models.draft_creator import DraftPadCreator

PRODUCT_CODES = {
    1028: "Web Acceleration",
    1115: "Application Acceleration",
    1118: "Application Acceleration",
    1029: "Web Acceleration SSL",
    1056: "CDN Service",
    1030: "Web Acceleration",
    1006: "Download",
}

RELATED_PRODUCT_CODES = {
    1028: [1006,1029,1030,1056],
    1115: [1118],
}

DUMMY_SENDER_EMAIL = "no_reply@cdnetworks.com"

def draft_groups_for_query(draft_id_list, material_no_list=[], verbose=False, origin= None):
    from ci.common.models import CNameStatus
    if verbose:
        common_query = """
            SELECT a.site_cui_id, a.serve_domain as pad, a.domain as origin, b.customer_site_id, a.description, cus.cop_product_id as product
              FROM customer_site_cui a
              LEFT OUTER JOIN customer_site b ON a.customer_site_id = b.customer_site_id
              LEFT OUTER JOIN customer_product cus ON a.product_id = cus.product_id
             WHERE a.site_cui_id in (%s)
        """ % ','.join(str(x) for x in (draft_id_list if len(draft_id_list)>=1 else [0]))

        stage_query = """
            SELECT a.site_cui_id, a.serve_domain as pad, a.domain as origin, b.customer_site_id, a.description, cus.cop_product_id as product
              FROM customer_site_cui a
              LEFT OUTER JOIN customer_site b ON a.customer_site_id = b.customer_site_id
              LEFT OUTER JOIN customer_product cus ON a.product_id = cus.product_id
             WHERE a.site_cui_id in (%s)
        """ % ','.join(str(x) for x in (draft_id_list if len(draft_id_list)>=1 else [0]))
    else:
        common_query = """
            SELECT a.site_cui_id, a.serve_domain as pad, a.domain as origin, b.customer_site_id, a.description
              FROM customer_site_cui a
              LEFT OUTER JOIN customer_site b ON a.customer_site_id = b.customer_site_id
              LEFT OUTER JOIN customer_product cus ON a.product_id = cus.product_id
             WHERE a.site_cui_id in (%s)
        """ % ','.join(str(x) for x in (draft_id_list if len(draft_id_list)>=1 else [0]))

        stage_query = """
            SELECT a.site_cui_id, a.serve_domain as pad, a.domain as origin, b.customer_site_id, a.description
              FROM customer_site_cui a
              LEFT OUTER JOIN customer_site b ON a.customer_site_id = b.customer_site_id
              LEFT OUTER JOIN customer_product cus ON a.product_id = cus.product_id
             WHERE a.site_cui_id in (%s)
        """ % ','.join(str(x) for x in (draft_id_list if len(draft_id_list)>=1 else [0]))

    cname_count_query = 'select site_id, IFNULL(count(*), 0) from cname_status group by site_id'
    bad_cname_count_query = 'select site_id, IFNULL(count(*), 0) from cname_status where status not in (%s) group by site_id' % ','.join(str(x) for x in CNameStatus.correct_choices)

    if len(material_no_list) >=1:
        material_no_query = ','.join(material_no_list)
    else:
        material_no_query = None
    new_query = common_query + ' AND b.customer_site_id is null AND a.approval_pending = 0 AND a.push_status=0'
    changed_query = common_query + ' AND b.customer_site_id is not null AND a.approval_pending = 0 AND has_customer_edits = 1 AND a.push_status in (0, 4)'
    pending_query = common_query + ' AND a.approval_pending = 1 '
    pending_stage_query = stage_query + ' AND a.push_status=1'
    on_stage_query = stage_query + ' AND a.push_status=2'
    failed_stage_query = stage_query + ' AND a.push_status=-2'
    pending_live_query = common_query + ' AND a.push_status=3'
    failed_live_query = common_query + ' AND a.push_status=-4'
    #### active_query need to fix
    active_query = common_query + ' AND b.customer_site_id is not null AND a.approval_pending = 0 AND has_customer_edits = 0 AND b.status = 1 and a.push_status in (0, 4)'
    disable_query = common_query + ' AND b.customer_site_id is not null AND a.approval_pending = 0 AND b.status = 0'

    if material_no_query:
        common_tail_query = ' AND (cus.product_id is null or cus.product_cd in (%s)) ORDER BY a.serve_domain ASC' % material_no_query
    else:
        common_tail_query = ' ORDER BY a.serve_domain ASC'

    if origin:
        common_tail_query = " AND (a.domain in ('%s')) %s" % ("','".join(origin), common_tail_query)

    cursor = connections['default'].cursor()
    try:
        cursor.execute(cname_count_query)
        cname_count_result = cursor.fetchall()

        cursor.execute(bad_cname_count_query)
        bad_cname_count_result = cursor.fetchall()

        count_dict = {}
        for site_id, cname_count in cname_count_result:
            count_dict[site_id] = {'cname_count': cname_count}

        for site_id, bad_cname_count in bad_cname_count_result:
            if site_id not in count_dict:
                count_dict[site_id] = {'bad_cname_count': bad_cname_count}
            else:
                count_dict[site_id]['bad_cname_count'] = bad_cname_count

        cursor.execute(new_query + common_tail_query)
        new_result = cursor.fetchall()

        cursor.execute(changed_query + common_tail_query)
        change_result = cursor.fetchall()

        cursor.execute(pending_query + common_tail_query)
        pend_result = cursor.fetchall()

        cursor.execute(active_query + common_tail_query)
        active_result = cursor.fetchall()

        cursor.execute(disable_query + common_tail_query)
        disable_result = cursor.fetchall()

        cursor.execute(pending_stage_query + common_tail_query)
        pending_stage_result = cursor.fetchall()

        cursor.execute(failed_stage_query + common_tail_query)
        failed_stage_result = cursor.fetchall()

        cursor.execute(on_stage_query + common_tail_query)
        on_stage_result = cursor.fetchall()

        cursor.execute(pending_live_query + common_tail_query)
        pending_live_result = cursor.fetchall()

        cursor.execute(failed_live_query + common_tail_query)
        failed_live_result = cursor.fetchall()
    finally:
        cursor.close()

    return (
        (DEPLOY_STATUS_NEW, new_result, 'Newly-created PADs not yet submitted for implementation.', True),
        (DEPLOY_STATUS_CHANGED, change_result, 'Newly-modified PADs not yet submitted for implementation.', False),
        (DEPLOY_STATUS_SELF_PUSHING_STAGE, pending_stage_result, 'Pending to stage.', False),
        (DEPLOY_STATUS_SELF_FAIL_STAGE, failed_stage_result, 'Failed to stage deploy.', False),
        (DEPLOY_STATUS_SELF_STAGE, on_stage_result, 'These PAD configuration on staging.', False),
        (DEPLOY_STATUS_SELF_PUSHING_PROD, pending_live_result, 'Pending to Production.', False),
        (DEPLOY_STATUS_SELF_FAIL_PROD, failed_live_result, 'Failed to Production deploy.', False),
        (DEPLOY_STATUS_WAITING_REQ, pend_result, 'These will be reviewed by CDNetworks staff and put into service shortly.', False),
        (DEPLOY_STATUS_SELF_PROD, active_result, None, False),
        (DEPLOY_STATUS_DISABLED, disable_result, None, True),
    ), count_dict

def get_editable_fields(draft=None):
    if draft:
        return SiteDraft.cui_editable_fields
    else:
        return SiteDraft.cui_editable_fields+('pad',)


def aurora_editable(func):
    def _pad_editable_check(request, *args, **kwargs):
        editable = request.session.get('aurora_editable', True)
        if not editable:
            raise Http404
        return func(request, *args, **kwargs)
    return _pad_editable_check


def getFieldsFromFieldset(fieldset, blacklist = None):
    """Flatten a fieldset to a fields list"""
    all_fields = tuple()
    blackset = set(blacklist) if blacklist else None
    for group in fieldset:
        sub_groups = group[1]
        if isinstance(sub_groups,dict):
            #  no subgroup so create subgroup with name of None...
            sub_groups = [(None, sub_groups)]
        for sub_group in sub_groups:
            fields = sub_group[1]['fields']
            if not isinstance(fields,tuple):
                fields = (fields,)  # to ensure it is iterable as 1 loop
            for field in fields:
                if blackset and blackset.issuperset([field]):
                    continue  # skip blacklisted elements
                all_fields += (field,)
    return all_fields


def display_fields(model, object, diff_object=None, blacklist=[], whitelist=[], diff_ignore=[], conditional_fields = {}, flag_thresholds = {}, fieldset_name="fieldsets"):
    """
    This goes through the fieldsets object on the model and creates a field_groups that can be used to display the table

    # TODO
    # this chunk of code below definitely should be made reusable for all models

    model: The django model to get display fields for
    object: Object to get values from
    diff_object: Object to compare for difference, if None no diff comparison
    blacklist: list of field names to never display
    whitelist: list of field names to  always display
    diff_ignore: list of field names to not do diff on
    conditional_fields: dictionary, key is field to display only if value is displayed.  Value must appear before key in the field sets hierarchy
    flag_thresholds: dictionary of field names, if present and value is greater than the dictionary value flag = True, if dictionary value is a function will call the function passing value and expecting True/False response
    fieldset_name: attribute name on the model object that has fieldset
    return: list of tuples as follows:
        first item: the group name
        second item: tuple as follows (support for two level deep subgroups
            first item: is a subgroup name or null for no subgroup
            second item: list of tuple representing guides related to this group.  Each tuple is as follows:
                first item: name of guide
                second item: url of guide
            third item: list each item tuple as follows
                first item: is field name
                second item: field value
                third item: help text
                fourth item: if field should be displayed
                fifth item: If the field's value should be compared for difference.
                sixth item: If the field's value should be checked for being over a threshold
                seventh item: If the field is editable in the CUI


    """
    form_ext_fields = ("shield_location", )
    field_groups = []
    whitelist_set = set(whitelist)
    blacklist_set = set(blacklist)
    diff_ignore_set = set(diff_ignore)
    tracked_fields = {}  # set to true if the tracked field is displayed...
    for value in conditional_fields.values():
        tracked_fields[value] = False

    for group in getattr(model,fieldset_name):
        this_groups = []
        sub_groups = group[1]
        if isinstance(sub_groups,dict):
            # no subgroup so create subgroup with name of None...
            sub_groups = [(None, sub_groups)]
        for sub_group in sub_groups:
            this_subgroup_fields = []
            fields = sub_group[1]['fields']
            if not isinstance(fields,tuple):
                fields = [fields]  # to ensure it is iterable as 1 loop
            for field_name in fields:
                display = True
                if blacklist_set.issuperset([field_name]):
                    # nothing can override blacklist...
                    continue

                if field_name not in form_ext_fields:
                    field = model._meta.get_field(field_name)
                    try:
                        orig_value = value = getattr(object, field_name)
                    except:
                        orig_value = value = None
                else:
                    pass

                if value is None:
                    display = False
                    value = ""
                elif type(field) == BooleanField:
                    value = True if value else False
                elif field.choices:
                    try:
                        value = [c[1] for c in field.choices if c[0] == value][0]
                    except:
                        try:
                            # go for blank value...
                            value = [c[1] for c in field.choices if c[0] == ''][0]
                        except:
                            value = "Unknown (" + str(value) + ")"
                elif type(field) in [IntegerField, PositiveIntegerField,PositiveSmallIntegerField,SmallIntegerField] and int(value) == int(field.default):
                    display = False
                elif type(value) in [str,unicode] and value.replace("\n","").replace("\r","").strip() == "":
                    display = False

                if conditional_fields.has_key(field_name):
                    if not tracked_fields.get(conditional_fields[field_name]):
                        display = False

                if whitelist_set.issuperset([field_name]):
                    # nothing can override whitelist...
                    display = True

                if tracked_fields.has_key(field_name):
                    if type(field) == BooleanField and not value:
                        tracked_fields[field_name] = False
                    elif field.choices and type(field) in [IntegerField, PositiveIntegerField,PositiveSmallIntegerField,SmallIntegerField] and int(orig_value) == int(field.default):
                        tracked_fields[field_name] = False
                    else:
                        tracked_fields[field_name] = display

                if field_name not in form_ext_fields:
                    set_tup = settings_tuple(object, field_name)

                if diff_object:
                    try:
                        if diff_ignore_set.issuperset([field_name]):
                            # do not do diff on these...
                                                diff = False
                        else:
                            comp_value = orig_value if orig_value != "" else None
                            diff_value = getattr(diff_object, field_name)
                            if diff_value  == "":
                                diff_value = None
                            diff = comp_value != diff_value
                    except:
                        diff = True
                else:
                    diff = False
                flag = ["Exceeds threshold of " + str(flag_thresholds[field_name])] if field_name in flag_thresholds and orig_value > flag_thresholds[field_name] else None
                flag = flag_thresholds[field_name](orig_value) if field_name in flag_thresholds and callable(flag_thresholds[field_name]) else flag
                if model.__name__ == 'Site' and hasattr(object, 'sitedraft'):
                    editable = True if field_name in object.sitedraft.cui_editable_fields else False
                elif model.__name__ == 'SiteDraft':
                    editable = True if field_name in object.cui_editable_fields else False
                else:
                    editable = None
                this_subgroup_fields.append((field.verbose_name, value, field.help_text, display, diff, flag, editable))
            if len(this_subgroup_fields) > 0:
                this_groups.append((sub_group[0], sub_group[1].get('guides'), this_subgroup_fields))
        field_groups.append((group[0], this_groups))
    return field_groups


def find_adjustments (row):
    """function to find out if the related customer receives any billing adjustments (e.g.: shielding, logging, etc.) or is using REST service on any of their PAD's """
    if row:
        # adj_set=row.customer.customer_adjustment_set.filter(Q(description__icontains='log') | Q(description__icontains='shield') | Q(description__icontains='storage'))
        adj_set=row.customer.customer_adjustment_set.filter(Q(description__icontains='shield') | Q(description__icontains='storage'))
        cust_flag = ''
        if adj_set:
            cust_flag= 'This customer uses the following service(s): '
            for adj in adj_set:
                cust_flag += u'%s, ' % adj.description
        if row.customer.site_set.filter(auth_key__gt='').count():
            if cust_flag:
                cust_flag += u'REST web service, '
            else:
                cust_flag = u'This customer uses REST web services.  '
        if row.customer.site_set.filter(status=True).filter(request_log_msg_format__gt='').count():
            if cust_flag:
                cust_flag += u'full logging service. '
            else:
                cust_flag += u' This customer uses full logging on one of their PADs.  '
        if row.pk and row.__class__.__name__ == 'Site' and row.aggregate_set.count() > 0:
            cust_flag += u'\nThis PAD uses aggregate logs, Please do not add any URL manipulation rules without first contacting Panther Engineers. '
    if cust_flag:
        return cust_flag[:-2]  # if cust_flag else None
    else:
        return None


def test_url(url):
    """a helper function to retrieve test URL headers and create error strings as needed"""
    test_url_errors = []
    if not url:
        test_url_errors.append('URL is blank')
        return test_url_errors
    url_request = Request(url)
    url_request.add_header('User-Agent', "Mozilla/5.0 (compatible; Panther)")
    url_request.add_header('Range', 'bytes=2-3')
    url_request.add_header('Via', '1.1 jfk-ui.panthercdn.com PWS/1.1.1')
    try:
        socket.setdefaulttimeout(5)
        url_header = urlopen(url_request).info()
    except HTTPError, e:
        if e.code in http_codes:
            test_url_errors.append(http_codes[e.code])
        else:
            test_url_errors.append('Unknown URL error')
        return test_url_errors
    except URLError, e:
        try:
            test_url_errors.append(e.reason[1])
        except:
            test_url_errors.append("Unknown error")
        return test_url_errors
    except socket.timeout:
        test_url_errors.append('This URL is not valid, or could not be reached. Please use another one')
        return test_url_errors
    except Exception, e:    # we should never get here! if we do, then some case has not been covered and the traceback shold be examined
        import traceback
        test_url_errors.append('This URL is not valid, or could not be reached. Please use another one')
        body=url+"\n"+traceback.format_exc()
        send_mail('Another rogue error from the test_url function...', body, 'test_url_error@pantherexpress.net', [MAINTAINER])
        return test_url_errors

    if ('content-length' not in url_header) or (url_header['content-length']==0):
        test_url_errors.append('Content length not set or is set to zero ')
    if 'content-type' not in url_header:
        test_url_errors.append('Content type not set')
    if 'last-modified' not in url_header:
        test_url_errors.append('No last modifed date')
    if ('Cache-Control' not in url_header and 'Expires' not in url_header) or ('Expires' in url_header and url_header['Expires']<1):
        test_url_errors.append('No cache control value found')
    if 'Content-Length' in url_header and  url_header['Content-Length'] != '2':
        test_url_errors.append('Origin does not accept byte ranges')
    return test_url_errors if test_url_errors else False

# helper function to display site/draft settings correctly
# display_fields has a lot of overlap with this function and bored from it
def settings_tuple(row, name, diff_row=None):
    field = row._meta.get_field(name)
    try:
        value = getattr(row, name)
    except:
        value = None
    diff = False
    if diff_row:
        diff_value = getattr(diff_row, name)
        if diff_value == "":
            diff_value = None
        if value == "":
            value = None
        diff = (value != diff_value)
    if type(field) == BooleanField:
        value = True if value else False
    if value is None:
        value = ''

    # flag unusual specs
    thresholds = {
        'mbps_avg': 1000,
        'mbps_peak': 1000,
        'rps_avg': 5000,
        'rps_peak': 5000,
        'files_size_avg': 10000, # KB
        'files_size_max': 1000, # MB
        'apac_percent': 15,
        'dynamic_content': False,
        'authentication_type': False,
        'misc_comment': '',
        'checklist_comment': ''
    }

    flag = (name in thresholds and value > thresholds[name])

    if field.choices:
        try:
            value = [c[1] for c in field.choices if c[0] == value][0]
        except:
            "Unknown (" + str(value) + ")"

    if name == 'url_test':
        flag = test_url(value)

    #try:
    #    if name.startswith('mbps_') or name.startswith('rps_') or  name == 'files_size_max':
    #        value = getattr(row,'get_'+name+'_display')()
    #except AttributeError:
    #    pass

    return (field.verbose_name, smart_unicode(value), field.help_text, diff, flag)


def name_and_email(user):
    return u'%s %s, %s' % (smart_unicode(user.first_name), smart_unicode(user.last_name), smart_unicode(user.email))


def get_pad_change_event_subscribers_from_aurora(ckey, site_id=None):
    from ci.constants import AURORAAPI_SERVER, AURORAAPI_USER, AURORAAPI_PASS
    from ci.common.utils.supporttools import handleHttpGetConnection2
    recipients = []
    if site_id is None:
        uri = '/rest/user/email/list/ckey/' + str(ckey) + '/?username=' + AURORAAPI_USER  + '&password=' + AURORAAPI_PASS
    else:
        uri = '/rest/user/email/list/site/' + str(site_id) + '/?username=' + AURORAAPI_USER  + '&password=' + AURORAAPI_PASS
    resp = handleHttpGetConnection2(AURORAAPI_SERVER, uri)
    if isinstance(resp,dict):
        if str(resp['returnCode']) == '600':
            uri = '/rest/user/email/list/ckey/' + str(ckey) + '/?username=' + AURORAAPI_USER  + '&password=' + AURORAAPI_PASS
            resp = handleHttpGetConnection2(AURORAAPI_SERVER, uri)
        if resp['returnMsg'] == 'Success':
            recipients += resp['data']
    else:
        pass
    return recipients


def send_implementation_email(subject, comments, draft, implementer=None, urgent=False, diff_site=None,
                              display_cust_flags=True, worker_email=None, event_id=0):
    """
    get recipients info when send mail by mail sending module
    urgency disabled per CUI-124
    :param subject: subject will be overridden
    :param comments:
    :param draft:
    :param implementer:
    :param urgent:
    :param debug:
    :param diff_site:
    :param display_cust_flags:
    :param worker_email:
    :return:
    """

    if draft.pad in TEST_PADS:
        return
    operator_recipients = draft.get_pad_change_event_operator_subscribers(event_id=event_id, implementer=implementer)

    customer_recipients = [NO_REPLY]
    if worker_email and worker_email != '':
        sender = worker_email
        if worker_email not in customer_recipients:
            customer_recipients.append(worker_email)
    else:
        sender = CDNW_IMPL
        #operators = draft.customer.get_default_event_operator_subscriber_emails()
        #if operators:
        #    sender = operators[0]
        #else:
        #    sender = NO_REPLY

    if not worker_email: #for audit log
        worker_email = implementer.email if implementer else NO_REPLY

    subject = draft.get_pad_change_event_mail_subject_by_event_id(event_id, subject=subject)
    body = draft.get_pad_change_event_mail_body_contents(subject, comments,
                                                         operator_recipients, customer_recipients, implementer,
                                                         display_cust_flags)
    if draft.approval_pending:
        send_mail_wrapping(subject, body, sender, operator_recipients, worker_email, draft, event_id, for_operator=True)

    #send email to customer with NO_REPLY mail account to prevent reject when using customer user mail account
    send_mail_wrapping(subject, body, NO_REPLY, customer_recipients, worker_email, draft, event_id)
    if urgent:
        # make_jira_issue(subject, body, urgent=True)
        send_alert("APP :: CUI", subject, body, urgent=True)

def send_mail_wrapping(subject, body, sender, receiver, worker_email, draft, event_id, for_operator=False):
    try:
        result = send_mail(subject, body, sender, receiver, actor=worker_email, draft=draft,
                           event_id=event_id, for_operator=for_operator)
    except Exception,e:
        # aurora_user, draft_id, event_id are invalid signature parameters for django.core.mail.send_mail
        if ENVIRONMENT in ['local','qa']:
            receiver = EMAIL_ALERTS
        result = send_mail(subject, body, sender, receiver)
    return result


def get_cache_group_val(cache_id, domain_unique_key, origin_host_header, origin):
    if cache_id:
        return cache_id
    elif domain_unique_key:
        return domain_unique_key
    elif origin_host_header:
        return origin_host_header
    else:
        return origin


def log_pad_change(change_time_row,  old_row, form_data=None, form_fields=None):
    if form_fields:
        model_fields = [(name, name) for name in form_fields]
    else:
        model_fields = [(f.name, f.verbose_name if f.verbose_name else f.name) for f in Site._meta.fields ]
    skip_fields = ['id', 'create_user', 'create_time', 'modify_user', 'modify_time', 'customer']
    if old_row.product:
        skip_fields.append('product')
        skip_fields.append('preserve_url_on_validation')
    for field_name, verbose_name in model_fields:
        if field_name not in skip_fields:
            new_log_row = PADChangeLog(pad_change=change_time_row, field=verbose_name, value=form_data.get(field_name) if form_data else getattr(old_row, field_name, ''))
            if form_data and form_data.get(field_name)!=getattr(old_row, field_name,'') :
                new_log_row.changed = True
            new_log_row.save()


def save_draft_creator(draft_obj, aurora_user_id):
    """
    save pad creator only if customer is aurora customer
    :param draft_obj:
    :param aurora_user_id:
    :return:
    """
    if draft_obj.customer.customer_portal_flag == 'A' and aurora_user_id != '':
        objs = DraftPadCreator.objects.filter(site_cui_id=draft_obj.pk, creator_id=aurora_user_id)
        if not objs.exists():
            draftcreator_obj = DraftPadCreator(site_cui_id=draft_obj.pk, creator_id=aurora_user_id)
            draftcreator_obj.save()


def save_site_change_history(sitedraft, username, ops_type=1, description=""):
    """
    Save Site Draft Change history

    :param sitedraft   Site object isinstance
    :param request django Request object
    :param ops_type  models.site.CustomerSiteChangeHistory.OPERATION_TYPE = (
                                                                                (0, 'Add'),
                                                                                (1, 'Update'),
                                                                                (2, 'Restore'),
                                                                            )
    :param description
    :return bool successful save or not
    """
    try:
        latest_version = CustomerSiteChangeHistory.objects\
                                        .filter(sitedraft=sitedraft)\
                                        .order_by('-pk')[0].version + 1
    except IndexError:
        latest_version = 1

    try:
        site_change_history = CustomerSiteChangeHistory(sitedraft=sitedraft,
                                                        version=latest_version,
                                                        operation_type=ops_type,
                                                        modify_user=username,
                                                        description=description)
        site_change_history.save()

        snapshot = CustomerSiteSnapshot(customer_site_history=site_change_history,
                                        config_diff=sitedraft.toJSON())
        snapshot.save()

        return True
    except Exception, e:
        print e
        return False


def get_site_config_from_history(sitedraft_id, restore_version):
    """
    ** You have check PAD permit before use this function **

    Get PAD Configuration from Change History

    :param sitedraft_id   Site object isinstance
    :param restore_version History version
    
    :return string JSON encoded PAD configuration
    """

    try:
        snapshot = CustomerSiteChangeHistory.objects.get(sitedraft_id=sitedraft_id,\
                                                        version=restore_version,\
                                                        operation_type=1)
        return snapshot.customersitesnapshot.config_diff
    except CustomerSiteChangeHistory.DoesNotExist:
        return None


def get_error_example_from_file(filename):
    """
    for debug purpose only
    :return:
    """
    result_dict = {}
    import os
    from django.utils import simplejson
    try:
        cwd = os.path.abspath(os.path.dirname(__file__))
        filename =  "%s/fixture/%s" % (os.path.dirname(cwd), filename)
        f = open(filename, "r")
        try:
            contents = f.read()
            result_dict = simplejson.loads(contents)
        except:
            pass
        finally:
            f.close()
    except:
        pass
    return result_dict


def validate_ssl_cert_for_draft(draft, edge_service):
    if not edge_service.pk or not edge_service.ssl_cert:
        raise Exception("Please check ssl_cert for this service.")
    if edge_service.allow_nonmatching_domains or not draft.enable_ssl:
        return True

    cert_domain = edge_service.ssl_cert.domain if edge_service.ssl_cert else None
    alt_domains = [d.domain for d in edge_service.ssl_cert.keystoredomains_set.all()] if edge_service.ssl_cert else []

    is_valid = False
    if cert_domain and cert_domain[0] == '*':
        if cert_domain.partition('.')[2] == draft.pad.partition('.')[2]:
            is_valid = True
    else:
        if cert_domain == draft.pad:
            is_valid = True

    if not is_valid:
        for domain_check in alt_domains:
            if domain_check != '' and domain_check[0] == '*':
                if domain_check.partition('.')[2] == draft.pad.partition('.')[2] and draft.enable_ssl:
                    is_valid = True
            else:
                if domain_check == draft.pad and draft.enable_ssl:
                    is_valid = True
    if not is_valid:
        raise Exception("Your PAD name does not match the domain of the SSL certificate you are trying to assign this to.")


class ValidatorCertAndDomain(object):
    def __init__(self):
        super(ValidatorCertAndDomain, self).__init__()

    @classmethod
    def validate_for_pad(cls, pad, enable_ssl, service, service_n_ssl_cert=None, service_n_sni_group=None, domain_check_list=None, keystore_list=None, old_cert=None, new_cert=None):
        """
        used for SNI, Cert, Service, Pad Page.
        compare pad_domain and
        :param pad: for_pad;
        :param enable_ssl: for_pad; pad.cleaned_data['enable_ssl']
        :param service: for_pad; pad.cleaned_data['service']
        :param service_n_ssl_cert: for_service; service.cleaned_data['ssl_cert']
        :param service_n_sni_group: for_service; service.cleaned_data['sni_group']
        :param domain_check_list: for_cert; newaly added MDC cert_domains.
        :param keystore_list: for_sni; newaly added keystores for SNI.
        :return:
        """
        def check_service_keystore(_ssl_cert, _domain_check_list):
            return validate(_keystore_list=[_ssl_cert], _domain_check_list=_domain_check_list)

        def check_sni_keystore(_sni_group, _keystore_list=None, _old_cert=None, _new_cert=None):
            return _sni_group and validate(
                _keystore_list=_keystore_list if _keystore_list else [keystore for keystore in _sni_group.sslkeystore_set.all()], _old_cert=_old_cert, _new_cert=_new_cert
            )

        def validate(_keystore_list, _domain_check_list=None, _old_cert=None, _new_cert=None):
            for keystore in _keystore_list:
                if _old_cert and _new_cert and _old_cert.pk == keystore.pk:
                    keystore = _new_cert

                ssl_alt_domains = []
                if keystore.domain:
                    ssl_alt_domains = [keystore.domain]

                if _domain_check_list:
                    ssl_alt_domains += _domain_check_list
                else:
                    ssl_alt_domains += [d.domain for d in keystore.keystoredomains_set.all()]
                for domain_check in ssl_alt_domains:
                    if domain_check != '' and domain_check[0] == '*':
                        if domain_check.partition('.')[2] == pad.partition('.')[2]:
                            return True
                    else:
                        if domain_check == pad:
                            return True
            return False
        ssl_cert = service_n_ssl_cert  # or service.ssl_cert
        sni_group = service_n_sni_group  # or service.sni_group

        if not service or not ssl_cert or not enable_ssl or service.allow_nonmatching_domains:
            return True

        return check_service_keystore(_ssl_cert=ssl_cert, _domain_check_list=domain_check_list) \
            or check_sni_keystore(_sni_group=sni_group, _keystore_list=keystore_list, _old_cert=old_cert, _new_cert=new_cert)

    @classmethod
    def validate_for_service(cls, service, ssl_cert, sni_group, allow_nonmatching_domains):
        if not service or not service.pk or not (service.ssl_cert or ssl_cert) or allow_nonmatching_domains:
            return True

        for site in service.site_set.filter(status=True):
            if not cls.validate_for_pad(pad=site.pad, enable_ssl=site.enable_ssl, service=service, service_n_ssl_cert=ssl_cert, service_n_sni_group=sni_group):
                raise Exception("%s uses the original certificate on this edge service and is not compatible with this new certificate" % site.pad)
        return True

    @classmethod
    def validate_for_cert(cls, old_cert, domain_checklist, new_cert):
        if old_cert.keystoredomains_set.count() <= 0:
            return True
        for frontend in old_cert.frontends.all():
            for site in frontend.site_set.all():
                if not cls.validate_for_pad(pad=site.pad, enable_ssl=site.enable_ssl,
                                            service=frontend,
                                            service_n_ssl_cert=frontend.ssl_cert,
                                            service_n_sni_group=frontend.sni_group,
                                            domain_check_list=domain_checklist,
                                            old_cert=old_cert,
                                            new_cert=new_cert):
                    raise Exception("%s uses the original certificate on edge service %s and is not compatible with this new certificate" % (site.pad, frontend.dns_prefix))

        if not old_cert.sni_group:
            return True
        for frontend in old_cert.sni_group.service_set.all():
            for site in frontend.site_set.all():
                if not cls.validate_for_pad(pad=site.pad, enable_ssl=site.enable_ssl,
                                            service=frontend,
                                            service_n_ssl_cert=frontend.ssl_cert,
                                            service_n_sni_group=frontend.sni_group,
                                            domain_check_list=domain_checklist,
                                            old_cert=old_cert,
                                            new_cert=new_cert):
                    raise Exception("%s uses the original certificate on edge service %s and is not compatible with this new certificate" % (site.pad, frontend.dns_prefix))
        return True

    @classmethod
    def validate_for_sni(cls, sni, services, certs):
        validate_services = [s for s in services]

        for service in validate_services:
            for site in service.site_set.all():
                if not cls.validate_for_pad(pad=site.pad, enable_ssl=site.enable_ssl,
                                            service=service,
                                            service_n_ssl_cert=service.ssl_cert,
                                            service_n_sni_group=sni,
                                            keystore_list=certs):
                    raise Exception("%s uses the original certificate on edge service %s and is not compatible with this new certificate" % (site.pad, service.dns_prefix))

        old_services = []
        if sni and sni.pk:
            old_services = [s for s in sni.service_set.all()]
        removed_services = set(old_services) - set(validate_services)

        for service in removed_services:
            for site in service.site_set.all():
                if not cls.validate_for_pad(pad=site.pad, enable_ssl=site.enable_ssl,
                                            service=service,
                                            service_n_ssl_cert=service.ssl_cert,
                                            service_n_sni_group=None,
                                            keystore_list=None):
                    raise Exception("%s uses the original certificate on edge service %s and is not compatible with this new certificate" % (site.pad, service.dns_prefix))


def get_valid_origin_domain(origin):
    from urlparse import urlparse
    try:
        if origin.lower().startswith('http'):
            parsed = urlparse(origin)
        else:
            parsed = urlparse('http://' + origin)

        return origin.replace(parsed.path, '').lower() + parsed.path
    except:
        return origin

