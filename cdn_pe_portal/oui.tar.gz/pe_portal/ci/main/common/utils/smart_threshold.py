#!/usr/local/bin/python
# -*- coding: euc-kr -*-

import sys
import os
import time
import datetime
import smtplib
import mimetypes
import glob
import getopt
import socket
from stat import *
from operator import itemgetter, attrgetter
import operator
import shutil
import string
from subprocess import *
import MySQLdb
from MySQLdb import cursors
from email import Encoders
from email.Message import Message
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
import httplib, urllib
from threading import Thread
import inspect

import math
import locale
import operator
import random
from operator import itemgetter

# time:traffic
_data = {3:100, 2:300, 1:100}
DEBUG = 1

def make_test_data(data):
	t = get_ctime()
	for i in range(0, 100):
#		traffic = random.randrange(1, 1000000*10000)
		# $outbound = sprintf('%d',(float)$tmp[2]*8/1000000); MEGA bit
		traffic = random.randrange(1, 10000)
		if not data.has_key(t):
			data[t] = traffic
		t -= 300

def make_test_data2(data):
	for i in range(0, 288):
		traffic = random.randrange(1, 10000)
		data.append(traffic)
		print "data[%d] : [%d]"%(i, data[i])

def extract_sample(sourceData):
	# data has only traffic
	try :
		sourceCount = len(sourceData)
#		epoch = get_epoch(time.time())
		epoch = sourceCount - 1
#		print "sourceData[%d]=[%d] <== CURRENT(X)"%(epoch, sourceData[epoch])

		# make dictionary on tmpData
		tmpData = {}
		for i in range(0, 288):
			if (i >= sourceCount):
				break

			if not tmpData.has_key(i):
				tmpData[i] = sourceData[i]

		sampleData = {} # sample data
		count = 0
		idx = 72

		if (idx > sourceData):
			idx = sourceCount
		BASE_COUNT = idx

		i = epoch
		# extract 72
		while (count < BASE_COUNT):
			if (i < 0):
				i = 287

			if tmpData.has_key(i):
				if not sampleData.has_key(idx):
					sampleData[idx] = tmpData[i]
					idx -= 1
					i -= 1
				count += 1
		return sampleData
	except Exception, e:
		print "except : [%s]"%str(e)
		sampleData = {}
		return sampleData
		

def time_to_str(ltime):
	now = time.localtime(ltime)
	date = "%d%.2d%.2d %.2d:%.2d:%.2d"%(now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)
	return date

def get_ctime():
	curTime = time.time()
#	print "curTime : [%d] [%s]"%(curTime, time_to_str(curTime))
	now = time.localtime(curTime)
	m = math.floor((now.tm_min / 5) * 5.0)

	date = "%d%.2d%.2d%.2d%.2d00"%(now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, m)
	tmp = time.strptime(date, "%Y%m%d%H%M%S")
	return int(time.mktime(tmp))

def get_cdata(data, cepoch):
	try :
		tmp = [cepoch, cepoch-1, cepoch-2, cepoch-3, cepoch-4]
		for t in tmp:
			if data.has_key(t):
#			print "get_cdata : time:[%s] traffic:[%d]"%(time_to_str(t), data[t])
				return t
	except Exception, e:
		return -1

def get_weight(data):
	up = []
	down = []
	delList = []

	sortedData = sorted(data.iteritems(), key=itemgetter(1), reverse=True)
	i = 0
	for item in sortedData:
		if (i == 2):
			break
		delList.append(sortedData[i])
		i += 1

	sortedData = sorted(data.iteritems(), key=itemgetter(1), reverse=False)
	i = 0
	for item in sortedData:
		if (i == 2):
			break
		delList.append(sortedData[i])
		i += 1

	for item in delList:
		if data.has_key(item[0]):
			data.pop(item[0])

	# sort by time
	sortedData = sorted(data.iteritems(), key=itemgetter(0), reverse=True)
	for i in range(0, len(sortedData)):
		if ((i+1) >= len(sortedData)):
			break
		diffVal = sortedData[i][1] - sortedData[i+1][1]
		if (diffVal > 0):
			up.append(diffVal)
		else:
			down.append(abs(diffVal))

	if (len(up) > 0):
		deltau = sum(up)/len(up)
	else:
		deltau = 1

	if (len(down) > 0):
		deltad = sum(down)/len(down)
	else:
		deltad = 1

#	print "sum(up)   : [%.5d] len(up)   : [%d]"%(sum(up), len(up))
#	print "sum(down) : [%.5d] len(down) : [%d]"%(sum(down), len(down))
#	print "DELTAU(up avg)   : [%d]"%deltau
#	print "DELTAD(down avg) : [%d]"%deltad
	return [deltau, deltad]

def print_data(data):
	for item in data:
		print "[%s] [%d]"%(time_to_str(item[0]), item[1])

def get_xyz(data):
	try:
		x = 0
		y = 0
		z = 0

		# data unit : Mega Byte
		# smart threshold unit : Mega bit

		dataCount = len(data)
		xepoch = get_cdata(data, dataCount) # current epoch
		if (xepoch < 0):
			return 0
		else:
			x = data[xepoch]

		yepoch = get_cdata(data, xepoch-1)
		if (yepoch < 0):
			return 0
		else:
			y = data[yepoch]

		end = yepoch-6 # 30 minutes
		i = 1
		tmp = []
		delList = []

		for t in range(yepoch-1, end, -1): # get 3 buckets
			if (i > 3):
				break
			if data.has_key(t):
				tmp.append(data[t])
				i += 1

		if (len(tmp) > 0):
			tsum = 0
			for t in tmp:
				tsum += t
			z = round(tsum/len(tmp))

		if (len(data) > 5):
			# get 6 hours data : 2 ~ 71 buckets
			# sort by time
			sortedData = sorted(data.iteritems(), key=itemgetter(0), reverse=True)
			i = 0
			pData = []
			for item in sortedData:
				if (i == 72):
					break
				if (i < 2):
					i += 1
					continue
				else:
					pData.append(item)	
					i += 1
			# sort by traffic (remove min 2)
			sortedData = sorted(pData, key=itemgetter(1), reverse=False)
			i = 0
			for item in sortedData:
				if (i == 2):
					break
				delList.append(sortedData[i])
				i += 1

			# sort by traffic (remove max 2)
			sortedData = sorted(pData, key=itemgetter(1), reverse=True)
			i = 0
			for item in sortedData:
				if (i == 2):
					break
				delList.append(sortedData[i])
				i += 1

			tmpMax = sortedData[i][1]
			for item in delList:
				pData.remove(item)

			if (len(pData) > 0):
				tsum = 0
				for item in pData:
					tsum += item[1]
				pavg = tsum * 0.1/len(pData)

			pmax = math.floor(tmpMax * 0.1)
			weight = get_weight(data) # get up/down average
		return [x, y, z, xepoch, pavg, pmax, weight]

	except Exception, e:
		print "[%s] exception : [%s]"%(sys._getframe().f_code.co_name, str(e))


def number_format(num, places=0):
	return locale.format("%.*f", (places, num), True)

def check_xyz(debug, logger, customer, x, y ,z, maxmbit, pavg, pmax, weight):
	try :
		if (x == 0 or y == 0 or z == 0):
			return ["", "", ""]

		alert = ""

		if ((x+y)/2 > z):
			pattern = 'increase'
		else:
			pattern = 'decrease'

		################################
		# CORE
		################################
		xy = abs(x - y)
		xz = abs(x - z)
		xyp = math.floor(xy*100/y)
		xzp = math.floor(xz*100/z)
		base = max(xy, xz)
		pp = max(xyp, xzp)

		detailInfo = {}
		if debug:
			print "PATTERN:[%s] XY:[%d] XZ:[%d]"%(pattern, xy, xz)
			print "XYP:[%d] XZP:[%d]"%(xyp, xzp)
			print "BASE:[%d] PP:[%d] PMAX:[%d]"%(base, pp, pmax)

		if debug:
			detailInfo = {'CUSTOMER':customer, 'BASE':base, 'PP':pp, 'PAVG':pavg}
		
		# changed 10% under
		if (pp < 10):
			if debug:
				print "\033[033;40m### PP(%d) < 10 \033[0m"%pp
			logger.info("[NORMAL] [%s] %d(pct.) %s [avg:%d max:%d]"%(customer, pp, pattern, pavg*10, pmax*10))
			return [pattern, "", detailInfo]
		if (base < max(maxmbit, pmax, 650)):
			if debug:
				print "\033[033;40m### BASE(%d) < max(PMAX, 650)=[%d]\033[0m"%(base, max(pmax, 650))
			logger.info("[NORMAL] [%s] %d(Mbps) %s [avg:%d max:%d]"%(customer, base, pattern, pavg*10, pmax*10))
			return [pattern, "", detailInfo]

#		# MRTG-rrd overflow, 2008.11.04
#		if (type == '+' and pp > 900 and base > 40000):
#			return [pattern, 0, detailInfo, base]
		
		d = max(math.ceil(pmax/pavg), 1) + math.ceil(pavg/500) + 2.5
		if (pattern == 'increase'):
			p = pmax * 7
		else:
			p = max(weight)*d

		if debug:
			print "D : [%d]"%d
			print "P : [%d]"%p
		
		if (base > p):
			alert = "[ABNORMAL] [%s] %s %d Mbps (by.BASE-logic)"%(customer, pattern, base)
			alert += "\nBASE-logic:[changed amount[%d] > Smart Threshold[%d]]"%(base,p)
			alert += "\nlast value:[%d]\n5min ago:[%d]\n10,15,20min ago avg:[%d]"%(x,y,z)
		else:
			alert = ""

		if debug:
			detailInfo['D'] = d
			detailInfo['P'] = p

		# check low traffic
		if (alert and pattern == 'decrease'):
			if (pmax > 500 and pmax > base):# if large down is alert
				if debug:
					print "\033[033;40m### [NORMAL] PMAX > 500 and PMAX > BASE \033[0m"
				alert = ""
		elif (len(alert) == 0 and pattern == 'decrease'):
			if (base > 5000):
				alert = "\n\n[ABNORMAL] [%s] %s %d Mbps (by.5G-logic)"%(customer, pattern, base)
				alert += "\n5G-logic:[change amount > 5000Mpbs]"
				alert += "\nlast value:[%d]\n5min ago:[%d]\n10,15,20min ago avg:[%d]"%(x,y,z)
			'''
			else:
				gmtNow = time.gmtime()
				# this is ddmonx logic ==> must be changed
				if (gmtNow.tm_hour > 0 and gmtNow.tm_hour < 8):
					if (base > 1500):
						alert = "%d (by.DOWN-logic)"%base 
					else:
						alert = ""
			'''
		return [pattern, alert, detailInfo]
	except Exception, e:
		print "[%s] except : [%s]"%(sys._getframe().f_code.co_name, str(e))
		return

def get_epoch(ltime):
	now = time.localtime(ltime)
	seconds = now.tm_hour*60*60+now.tm_min*60+now.tm_sec
	return seconds/300

def check_smart_threshold(debug, customer, data, logger=None):
	try :
		# data : Mega bit/second
		alert = ""
		sampleData = extract_sample(data)
		x, y, z, xepoch, pavg, pmax, weight = get_xyz(sampleData)
		deltau, deltad = weight
		if debug:
			print "X:[%d] Y:[%d] Z:[%d] PAVG:[%d] PMAX:[%d] WEIGHT[DELTAU,DELTAD]:[%d,%d]"%(x, y, z, pavg, pmax, deltau, deltad)
		maxmbit = 0
		pattern, alert, detailInfo = check_xyz(debug, logger, customer, x,y,z,maxmbit,pavg,pmax,weight)
		if (len(alert) > 0):
			if debug:
				print "[%s] \033[035;40m[ABNORMAL]\033[0m alert:[%s] detailInfo:"%(datetime.datetime.now(), alert), detailInfo
#			logger.error("%s"%alert)
		else:
			 if debug:
				print "[%s] \033[033;40m[NORMAL]\033[0m detailInfo: "%datetime.datetime.now(), detailInfo
		return alert

	except Exception, e:
		print "[%s] except : [%s]"%(sys._getframe().f_code.co_name, str(e))
		return ""
