# -*- coding: utf-8 -*-
from ci.common.models.cdn import Service
from ci.common.models.customer import SSLKeystore


def validate_ssl_cert_for_sni(sni_group, cert_id_list, service_id_list):
    certs = SSLKeystore.objects.filter(pk__in=cert_id_list)

    errors = {}
    if len(certs) < 1:
        errors['ssl_certs'] = ['This field cannot be blank.']

    cert_has_other_sni = certs.exclude(sni_group=sni_group).exclude(sni_group__isnull=True)
    if len(cert_has_other_sni) > 0:
        errors = add_to_error_list(
            errors,
            'ssl_certs',
            'There are ssl certs that already assigned to SNI_Group with ID%s' % [int(str(cert)) for cert in cert_has_other_sni.values_list('pk', flat=True)]
        )

    cert_has_algorithm = list(set(certs.values_list('algorithm', flat=True)))
    if len(cert_has_algorithm) > 1:
        errors = add_to_error_list(
            errors,
            'ssl_certs',
            'Selected certs has different algorithm.'
        )
    return errors


class ValidatorForSniService(object):
    def __init__(self):
        super(ValidatorForSniService, self).__init__()

    @classmethod
    def check_sni_service_is_empty(cls, service_list):
        return len(service_list) == 0

    @classmethod
    def check_sni_service_has_cert(cls, service_list):
        for s in service_list:
            if s.pk and not s.ssl_cert:
                return False
        return True

    @classmethod
    def check_sni_service_has_other_sni(cls, services, sni_group):
        if not sni_group:
            return True

        service_has_other_sni = services.exclude(sni_group=sni_group).exclude(sni_group__isnull=True)
        if len(service_has_other_sni) > 0:
            raise Exception('There are services that already assigned to SNI_Group %s(ID:%s)' % (service_has_other_sni[0].sni_group.sni_group_name, service_has_other_sni[0].sni_group.pk))

        return True

    @classmethod
    def check_sni_cert_and_services_same_algorithm(cls, services, certs):
        algorithms = []

        for cert in certs:
            algorithms.append(str(cert.algorithm))
        for service in services:
            algorithms.append(str(service.ssl_cert.algorithm))

        if len(set(algorithms)) > 1:
            raise Exception('Selected services with this SNI has different algorithm.')

    @classmethod
    def check_sni_service_same_cipher_proto(cls, service_list, input_data=None):
        def get_str(_str):
            return _str if _str else ''
        server_cipher_dict = {}
        server_protocol_dict = {}
        client_protocol_dict = {}
        client_cipher_dict = {}

        if input_data and isinstance(input_data, dict):
            input_sc = input_data.get('ssl_server_ciphers')
            input_sp = input_data.get('ssl_server_protocols')
            input_cc = input_data.get('ssl_client_ciphers')
            input_cp = input_data.get('ssl_client_protocols')
            for _dict, _input in [(server_cipher_dict, input_sc),
                                  (server_protocol_dict, input_sp),
                                  (client_cipher_dict, input_cc),
                                  (client_protocol_dict,  input_cp)]:
                if _input:
                    _dict[get_str(_input)] = True

        for s in service_list:
            server_cipher_dict[get_str(s.ssl_server_ciphers)] = True
            server_protocol_dict[get_str(s.ssl_server_protocols)] = True
            client_cipher_dict[get_str(s.ssl_client_ciphers)] = True
            client_protocol_dict[get_str(s.ssl_client_protocols)] = True
            if len(server_cipher_dict) >= 2 or len(server_protocol_dict) >= 2 or len(client_cipher_dict) >= 2 or len(client_protocol_dict) >= 2:
                return False

        return True

    @classmethod
    def check_sni_service_has_same_type(cls, sni_group):
        if not sni_group:
            return True

        services = sni_group.service_set.all()
        if services.count() < 2:
            return True

        first_service_type = services[0].is_http2
        return all(service.is_http2 == first_service_type for service in services[1:])


def validate_sni_service_for_sni(sni_group, cert_id_list, service_id_list):
    services = Service.objects.filter(pk__in=service_id_list)
    service_list = [s for s in services]

    errors = {}
    if ValidatorForSniService.check_sni_service_is_empty(service_list=service_list):
        errors['services'] = ['SNI Group %s must have at least1 service.' % str(sni_group)]

    if not ValidatorForSniService.check_sni_service_has_cert(service_list=service_list):
        add_to_error_list(
            errors,
            'services',
            'There are Services without ssl_keystore.'
        )

    try:
        ValidatorForSniService.check_sni_service_has_other_sni(services=services, sni_group=sni_group)
    except Exception, e:
        add_to_error_list(
            errors,
            'services',
            e.message
        )

    try:
        certs = SSLKeystore.objects.filter(pk__in=cert_id_list)
        ValidatorForSniService.check_sni_cert_and_services_same_algorithm(services=services, certs=certs)
    except Exception, e:
        add_to_error_list(
            errors,
            'services',
            e.message
        )
    """
    if not ValidatorForSniService.check_sni_service_same_cipher_proto(service_list=service_list):
        add_to_error_list(
            errors,
            'services',
            'Selected services with this SNI has different protocol or chphers.'
        )
    """
    return errors


def validate_sni_service_for_service_admin(service, sni_group, cleaned_data):
    if not sni_group or not sni_group.pk:
        # do not need validate.
        return {}

    service_list = [s for s in sni_group.service_set.all() if s.pk != service.pk]
    errors = {}

    if not ValidatorForSniService.check_sni_service_has_cert(service_list=service_list):
        add_to_error_list(
            errors,
            'services',
            'There are Services without ssl_keystore.'
        )

    if not ValidatorForSniService.check_sni_service_same_cipher_proto(
            service_list=service_list,
            input_data=cleaned_data):
        add_to_error_list(
            errors,
            'services',
            'Selected services with this SNI has different protocol or chphers.'
        )
    return errors


def add_to_error_list(_obj, key_str, item):
    if key_str in _obj:
        _obj[key_str].append(item)
    else:
        _obj[key_str] = [item]
    return _obj


def get_algorithm(_crt_obj=None, _crt_file=None):
    import re
    import M2Crypto

    def get_algorithm_with_obj(co):
        _str = co.as_text()
        pattern = 'Signature Algorithm: (\w+\n)'
        try:
            algorithm_str = re.search(pattern, _str).groups()[0]
            if not algorithm_str:
                return 'sha2'
            if algorithm_str.find('sha1') > -1:
                return 'sha1'
            elif algorithm_str.find('sha2') > -1:
                return 'sha2'
        except (Exception, ):
            return ''

    if _crt_obj:
        return get_algorithm_with_obj(_crt_obj)

    elif _crt_file:
        return get_algorithm_with_obj(M2Crypto.X509.load_cert_string(_crt_file))
    else:
        return 'sha2'
