"""namespace for functions that help with Django SortedDict
and are not dependent on anything outside the standard libraries."""

from django.utils.datastructures import SortedDict

def init_sorted_dict(items):
	"""
	@param items:	A sequence of (key, value)
	@return:		A SortedDict preserving items' key order
	"""
	rv = SortedDict()
	for key, value in items:
		rv[key] = value
	
	return rv
