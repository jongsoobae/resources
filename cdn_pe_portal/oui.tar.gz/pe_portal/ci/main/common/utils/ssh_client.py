
import os
from subprocess import call

class ssh_client:
	def __init__(self):
		self.ssh_settings(None);

	def ssh_settings(self, host, user=None, port=None, timeout=0, key_priv=None, verify_host_dns=False):
		self.ssh_host = host
		self.ssh_user = user
		self.ssh_port = port
		self.timeout = timeout
		self.ssh_key_priv = key_priv
		self.verify_host_dns = verify_host_dns
		
	
	def ssh_command(self, cmd_str, shell=False, execute=True):
		cmd = ['ssh']
		if self.ssh_key_priv:
			cmd += ['-i', self.ssh_key_priv]
		if self.ssh_port:
			cmd += ['-p', self.ssh_port]
		if self.timeout > 0:
			cmd += ['-o', "ConnectTimeout=%d" % self.timeout]
		# cmd += ['-o', 'VerifyHostKeyDNS %d' % 'yes' if self.verify_host_dns else 'no' ]
		cmd += ['-o', 'StrictHostKeyChecking no']
		host = ""
		if self.ssh_user is not None:
			host += self.ssh_user + "@"
		host += self.ssh_host
		cmd.append(host)

		if cmd_str is not None:
			cmd.append(cmd_str)

		if not execute:
			return cmd
		#print "executing on %s command: %s" % (self.ssh_host, cmd_str)
		if not shell:
			return call(cmd)
		else:
			return os.popen3(cmd)
	
	def scp_to_server(self, local_path, dest_path, shell=False, execute=True):
		cmd = ['scp']
		if self.ssh_key_priv:
			cmd += ['-i', self.ssh_key_priv]
		if self.ssh_port:
			cmd += ['-P', self.ssh_port]
		cmd += ['-o', 'StrictHostKeyChecking no']
		if os.path.isdir(local_path):
			cmd.append('-r')
		cmd.append(local_path)

		host = ""
		if self.ssh_user is not None:
			host += self.ssh_user + "@"
		host += self.ssh_host + ":" + dest_path
		cmd.append(host)

		if not execute:
			return cmd
		print "uploading %s to %s at host %s" % (local_path, dest_path, self.ssh_host)
		if shell:
			return os.popen3(cmd)
		else:
			call(cmd)
	
	def rsync(self, local_path, dest_path, execute=True, relative=False):
		# rsync synchronization
		rsync_options = "-auvC --delete --delete-excluded"
		if relative:
			rsync_options += " -R"
		cmd_str = "rsync " + rsync_options
		cmd = cmd_str.split()
		
		# ssh option
		ssh = "ssh"
		if self.ssh_key_priv:
			ssh += ' -i %s' % self.ssh_key_priv
		if self.ssh_port:
			ssh += ' -p %s' % str(self.ssh_port)
		cmd += ['-e', ssh]
	
		cmd.append(local_path)
	
		host = ""
		if self.ssh_user is not None:
			host += self.ssh_user + "@"
		host += self.ssh_host + ":" + dest_path
		cmd.append(host)
	
		if not execute:
			return cmd
		print "rsync %s to %s at host %s" % (local_path, dest_path, self.ssh_host)
		call(cmd)
