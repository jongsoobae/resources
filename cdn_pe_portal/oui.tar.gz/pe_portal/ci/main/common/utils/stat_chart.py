from django.db import connections
from datetime import datetime, timedelta
from ci.common.utils.mathutil import find_95th


class WPOChart:
    def __init__(self, name, label, traffic_table, value_field, total_label, factor, extra_filter='', num_format='%.0f',
                 total_factor=1):
        self.name = name
        self.label = label
        self.traffic_table = traffic_table
        self.value_field = value_field
        self.extra_filter = extra_filter
        self.num_format = num_format
        self.total_label = total_label
        self.factor = factor
        self.total_factor = total_factor
        self.percentage = False

    @staticmethod
    def get_chart_type_by_name(name):
        for cur_chart_type in chart_types_wpo:
            if cur_chart_type.name == name:
                return cur_chart_type
        return chart_types_wpo[0]

    @staticmethod
    def get_split_option_by_name(name):
        for cur_split_by in split_by_options:
            if cur_split_by.name == name:
                return cur_split_by
        return split_by_options[0]

    def get_chart_data(self, split_by_option, options,
                       datefrom, dateto, legend_cnt, others_flag, total_line_flag):

        conditions = self.get_conditions(options)

        if not self.check_result_condition(options, conditions):
            return [], [], []

        cnt_5mins = self.get_cnt_5mins(datefrom, dateto)
        date_data = self.get_date_data(datefrom, cnt_5mins)
        stat_time_from = datetime.strptime(datefrom, '%Y-%m-%d %H:%M').strftime("%Y-%m-%d %H:%M:%S")
        stat_time_to = datetime.strptime(dateto, '%Y-%m-%d %H:%M').strftime("%Y-%m-%d %H:%M:%S")

        q = QueryMaker(
            chart=self,
            conditions=conditions,
            split_by=split_by_option,
            stat_times=[stat_time_from, stat_time_to]
        )
        sql = q.get_query()
        cursor = None

        try:
            cursor = connections['wpo_stat'].cursor()
            cursor.execute(sql)
            rets = cursor.fetchall()
        finally:
            if cursor:
                cursor.close()
                del cursor

        chart_data = {}
        chart_ids = []

        for count, ret in enumerate(rets):
            chartron_id = ret[0]
            chartron_name = ret[1]
            stat_time = ret[2]
            data = int(ret[3])*self.factor
            if chartron_id not in chart_ids and len(chart_ids) < legend_cnt:
                chart_ids.append(chartron_id)

            if chartron_id not in chart_ids:
                if others_flag:
                    chartron_id = 'others'
                    chartron_name = 'others'
                else:
                    continue

            if chartron_id not in chart_data:
                chart_data[chartron_id] = {
                    'name': chartron_name, 'date_data': [0]*cnt_5mins, 'aggr_total': [-1, 0, 0, 0, 0]}

            idx = date_data.index(stat_time)
            chart_data[chartron_id]['aggr_total'][4] += data
            chart_data[chartron_id]['date_data'][idx] += data

            if total_line_flag:
                if 'total' not in chart_data:
                    chart_data['total'] = \
                        {'name': 'total', 'date_data': [0] * cnt_5mins, 'aggr_total': [-1, 0, 0, 0, 0]}
                chart_data['total']['aggr_total'][4] += data
                chart_data['total']['date_data'][idx] += data

        return_data = []
        others_data = []
        total_data = []
        summary = []
        others_summary = []
        total_summary = []
        for idx, (key, item) in enumerate(chart_data.items()):
            append_data = {'name': item['name'], 'date_data': item['date_data']}
            v_min = min(item['date_data'])
            v_max = min(item['date_data'])
            v_95th = find_95th(item['date_data'])
            v_total = sum(item['date_data'])
            v_avg = v_total / cnt_5mins
            append_sum_data = {'name': item['name'], 'aggr_total': [v_min, v_max, v_avg, v_95th, v_total]}

            if item['name'] == 'others':
                others_data.append(append_data)
                others_summary.append(append_sum_data)
            elif item['name'] == 'total':
                total_data.append(append_data)
                total_summary.append(append_sum_data)
            else:
                return_data.append(append_data)
                summary.append(append_sum_data)

        split_by_name_title = split_by_option.name
        if self.name == 'Hits_Sec_by_Origin_Response_Code':
            split_by_name_title = 'HTTP response code'
        index_title = [split_by_name_title, 'min', 'max', 'avg', '95th', self.total_label]

        if len(others_data) > 0:
            return_data = return_data + others_data
        if len(total_data) > 0:
            return_data = return_data + total_data
        if len(others_summary) > 0:
            summary = summary + others_summary
        if len(total_summary) > 0:
            summary = summary + total_summary

        return return_data, summary, index_title

    @classmethod
    def get_cnt_5mins(cls, datefrom, dateto):
        diff_obj = datetime.strptime(dateto, '%Y-%m-%d %H:%M') - datetime.strptime(datefrom, '%Y-%m-%d %H:%M')
        total_seconds = diff_obj.days * 24 * 3600 + diff_obj.seconds
        return int(total_seconds / 300)

    @classmethod
    def get_date_data(cls, datefrom, cnt_5mins):
        date_data = []
        for i in range(cnt_5mins):
            date_data.append(datetime.strptime(datefrom, '%Y-%m-%d %H:%M') + timedelta(minutes=5*i))
        return date_data

    @classmethod
    def check_result_condition(cls, options, conditions):
        stat_ret = False
        pop_ret = False
        if len(options['customer']) == 0 and len(options['site_service']) == 0 and len(options['site']) == 0:
            stat_ret = True
        elif (len(options['customer']) > 0
              or len(options['site_service']) > 0
              or len(options['site']) > 0) and len(conditions['stat_id']) > 0:
            stat_ret = True

        if len(options['pop']) == 0 and len(options['pop_region']) == 0:
            pop_ret = True
        elif (len(options['pop']) > 0 or len(options['pop_region']) > 0) and len(conditions['pop_id']) > 0:
            pop_ret = True
        return stat_ret & pop_ret

    @classmethod
    def get_conditions(cls, options):
        conditions = {
            'stat_id': [],
            'pop_id': [],
        }

        if len(options['site']) > 0 or len(options['customer']) > 0 or len(options['site_service']) > 0:

            sql = ' '.join([
                'select distinct local_site_for_chartron.stat_id',
                'from oui_federated.local_site_for_chartron local_site_for_chartron',
                'where local_site_for_chartron.CUSTOMER_SITE_ID > 0'
            ])

            if len(options['site']) > 0:
                sql += " and local_site_for_chartron.customer_site_id  in (%s) " % (",".join(options['site']))
            if len(options['customer']) > 0:
                sql += " and local_site_for_chartron.customer_id in (%s) " % (",".join(options['customer']))
            if len(options['site_service']) > 0:
                sql += " and local_site_for_chartron.cdn_service_id in (%s)" % (",".join(options['site_service']))
            sql += "; "

            cursor = None
            try:
                cursor = connections['wpo_stat'].cursor()
                cursor.execute(sql)
                rets = cursor.fetchall()
            finally:
                if cursor:
                    cursor.close()
                    del cursor

            for ret in rets:
                conditions['stat_id'].append(str(ret[0]))

        if len(options['pop']) > 0 or len(options['pop_region']) > 0:
            sql = ' '.join([
                'select distinct ihms_pop_for_chartron.cdnw_pop_id',
                'from oui_federated.ihms_pop_for_chartron ihms_pop_for_chartron',
                'inner join oui_federated.oui_pop_for_chartron oui_pop_for_chartron',
                'on oui_pop_for_chartron.cdnw_pop_id = ihms_pop_for_chartron.cdnw_pop_id',
                'where ihms_pop_for_chartron.cdnw_pop_id > 0'
            ])
            if len(options['pop']) > 0:
                sql += " and oui_pop_for_chartron.pop_id in (%s) " % (",".join(options['pop']))
            if len(options['pop_region']) > 0:
                sql += " and oui_pop_for_chartron.region_id in (%s) " % (",".join(options['pop_region']))
            sql += "; "

            cursor = None
            try:
                cursor = connections['wpo_stat'].cursor()
                cursor.execute(sql)
                rets = cursor.fetchall()
            finally:
                if cursor:
                    cursor.close()
                    del cursor

            for ret in rets:
                conditions['pop_id'].append(str(ret[0]))

        return conditions

chart_types_wpo = [
    WPOChart(
        name='Mbps',
        label='Mbps',
        total_label='GB transferred',
        traffic_table='db_wpo_stat.tb_traffic_wpo_bytes',
        value_field='traffic',
        num_format='2',
        factor=8. / (5. * 60 * 1000000)
    ),
    WPOChart(
        name='Hits_Sec',
        label='Hits/Sec',
        total_label='total hits',
        traffic_table='db_wpo_stat.tb_traffic_wpo_origin_requests',
        value_field='requests',
        num_format='2',
        factor=1 / (5. * 60)
    ),
    WPOChart(
        name='mbps_from_origin',
        label='Origin Mbps',
        total_label='GB transferred',
        traffic_table='db_wpo_stat.tb_traffic_wpo_origin_bytes',
        value_field='traffic',
        num_format='2',
        factor=8. / (5. * 60 * 1000000)
    ),
    WPOChart(
        name='hits_per_sec_from_origin',
        label='Origin Hits/Sec',
        total_label='total hits',
        traffic_table='db_wpo_stat.tb_traffic_wpo_origin_requests',
        value_field='requests',
        num_format='2',
        factor=1 / (5. * 60)
    ),
    WPOChart(
        name='responses_per_sec_50x',
        label='50x Hits/Sec',
        total_label='total hits',
        traffic_table='db_wpo_stat.tb_wpo_response_code_requests',
        value_field='code_requests',
        extra_filter='key_value like `5%%`',
        num_format='2',
        factor=1 / (5. * 60)
    ),
    WPOChart(
        name='responses_per_sec_504',
        label='Error to Origin (50x) Hits/Sec',
        total_label='total hits',
        traffic_table='db_wpo_stat.tb_wpo_response_code_requests',
        value_field='code_requests',
        extra_filter='key_value = `504`',
        num_format='2',
        factor=1 / (5. * 60)
    ),
    WPOChart(
        name='responses_per_sec_external_50x',
        label='External Error (50x) Hits/Sec',
        total_label='total hits',
        traffic_table='db_wpo_stat.tb_wpo_response_code_requests',
        value_field='code_requests',
        extra_filter='key_value like `5%%` and key_value != `504` and key_value ~= `505`',
        num_format='2',
        factor=1 / (5. * 60)
    ),

    WPOChart(
        name='Mbps_ic',
        label='Mbps',
        total_label='GB transferred',
        traffic_table='db_ic_stat.tb_traffic_ic_bytes',
        value_field='traffic',
        num_format='2',
        factor=8. / (5. * 60 * 1000000)
    ),
    WPOChart(
        name='Hits_Sec_ic',
        label='Hits/Sec',
        total_label='total hits',
        traffic_table='db_ic_stat.tb_traffic_ic_origin_requests',
        value_field='requests',
        num_format='2',
        factor=1 / (5. * 60)
    ),
    WPOChart(
        name='mbps_from_origin_ic',
        label='Origin Mbps',
        total_label='GB transferred',
        traffic_table='db_ic_stat.tb_traffic_ic_origin_bytes',
        value_field='traffic',
        num_format='2',
        factor=8. / (5. * 60 * 1000000)
    ),
    WPOChart(
        name='hits_per_sec_from_origin_ic',
        label='Origin Hits/Sec',
        total_label='total hits',
        traffic_table='db_ic_stat.tb_traffic_ic_origin_requests',
        value_field='requests',
        num_format='2',
        factor=1 / (5. * 60)
    ),
    WPOChart(
        name='responses_per_sec_50x_ic',
        label='50x Hits/Sec',
        total_label='total hits',
        traffic_table='db_ic_stat.tb_ic_response_code_requests',
        value_field='code_requests',
        extra_filter='key_value like `5%%`',
        num_format='2',
        factor=1 / (5. * 60)
    ),
    WPOChart(
        name='responses_per_sec_504_ic',
        label='Error to Origin (50x) Hits/Sec',
        total_label='total hits',
        traffic_table='db_ic_stat.tb_ic_response_code_requests',
        value_field='code_requests',
        extra_filter='key_value = `504`',
        num_format='2',
        factor=1 / (5. * 60)
    ),
    WPOChart(
        name='responses_per_sec_external_50x_ic',
        label='External Error (50x) Hits/Sec',
        total_label='total hits',
        traffic_table='db_ic_stat.tb_ic_response_code_requests',
        value_field='code_requests',
        extra_filter='key_value like `5%%` and key_value != `504` and key_value ~= `505`',
        num_format='2',
        factor=1 / (5. * 60)
    ),
]


class QueryMaker:
    def __init__(self, chart, conditions, split_by, stat_times):
        self.chart = chart
        self.conditions = conditions
        self.split_by = split_by
        self.from_time = stat_times[0]
        self.to_time = stat_times[1]
        self.stat_table = ''

        self.sql = ' '.join([
            'select :for_chartron_field, stat.stat_time, sum(:data_field)',
            '  from :traffic_table stat',
            ' inner join :for_chartron_table for_chartron',
            '    on stat.stat_id = for_chartron.stat_id',
            ' where stat_time >= \':from_time\' and stat_time < \':to_time\'',
            ':conditions',
            ' group by :for_chartron_field, stat.stat_time'
        ])

    def init_new_data(self, chart, conditions, split_by, stat_times):
        self.__init__(chart, conditions, split_by, stat_times)

    def _get_for_chartron(self):
        for_chartron = {'table': '', 'field': ''}
        query_by = self.get_query_by(self.conditions, self.split_by.name, self.chart)
        if query_by in ('site', 'site_pop'):
            for_chartron['table'] = 'oui_federated.local_site_for_chartron'
            for_chartron['field'] = 'for_chartron.customer_id, for_chartron.customer_name'
        if query_by in ('pop_site', 'pop'):
            for_chartron['table'] = 'oui_federated.ihms_pop_for_chartron'
            for_chartron['field'] = 'for_chartron.region_id, for_chartron.region_name'
        if query_by != 'site':
            self.stat_table = self.chart.traffic_table + '_pop'
        else:
            self.stat_table = self.chart.traffic_table
        return for_chartron

    def _get_condition_query(self):
        query = ''
        if len(self.conditions['stat_id']) > 0:
            query += ' and stat.stat_id in (%s)' % ','.join(self.conditions['stat_id'])
        if len(self.conditions['pop_id']) > 0:
            query += ' and stat.pop_id in (%s)' % ','.join(self.conditions['pop_id'])
        return query

    def get_query(self):
        sql = self.sql
        for_chartron = self._get_for_chartron()
        sql = sql.replace(':for_chartron_field', for_chartron['field'])
        sql = sql.replace(':for_chartron_table', for_chartron['table'])
        sql = sql.replace(':traffic_table', self.stat_table)
        sql = sql.replace(':data_field', self.chart.value_field)
        sql = sql.replace(':from_time', self.from_time)
        sql = sql.replace(':to_time', self.to_time)
        sql = sql.replace(':conditions', self._get_condition_query())
        sql = sql.replace(':extra', self.chart.extra_filter)
        return sql

    @classmethod
    def get_query_by(cls, conditions, split_by, chart_type):
        query_by = ''
        if (len(conditions['stat_id']) > 0) \
                and (len(conditions['pop_id']) == 0) \
                and (split_by in ('customer', 'site', 'site_service')):
            query_by = 'site'
        elif (len(conditions['pop_id']) > 0) \
                and (len(conditions['stat_id']) == 0) \
                and (split_by in ('pop', 'pop_region')):
            query_by = 'pop'
        elif (len(conditions['stat_id']) > 0) \
                and (split_by in ('pop', 'pop_region')):
            query_by = 'pop_site'
        elif (len(conditions['pop_id']) > 0) \
                and (split_by in ('customer', 'site', 'site_service')):
            query_by = 'site_pop'
        elif len(conditions['pop_id']) == 0 \
                and len(conditions['stat_id']) == 0:
            if split_by in ('customer', 'site', 'site_service'):
                query_by = 'site'
            if split_by in ('pop', 'pop_region'):
                query_by = 'pop'

        if chart_type.name == 'Hits_Sec_by_Origin_Response_Code':
            if len(conditions['pop_id']) > 0 \
                    and len(conditions['stat_id']) == 0:
                query_by = 'pop'
            elif len(conditions['stat_id']) > 0 \
                    and len(conditions['pop_id']) == 0:
                query_by = 'site'
            elif len(conditions['stat_id']) > 0 \
                    and len(conditions['pop_id']) > 0:
                query_by = 'pop_site'

        return query_by


class SplitByOption:
    def __init__(self, name, label, columns):
        self.name = name
        self.label = label
        self.columns = columns


split_by_options = [
    SplitByOption(
        name='customer',
        label='customer',
        columns=['local_site_for_chartron.customer_id', 'local_site_for_chartron.customer_name', 'stat.stat_time']),
    SplitByOption(
        name='site_service',
        label='site service',
        columns=['local_site_for_chartron.cdn_service_id', 'local_site_for_chartron.cdn_service_name',
                 'stat.stat_time']),
    SplitByOption(
        name='site',
        label='site',
        columns=['local_site_for_chartron.CUSTOMER_SITE_ID', 'local_site_for_chartron.SERVE_DOMAIN', 'stat.stat_time']),
    SplitByOption(
        name='pop_region',
        label='pop region',
        columns=['ihms_pop_for_chartron.region_id', 'ihms_pop_for_chartron.region_name', 'stat.stat_time']),
    SplitByOption(
        name='pop',
        label='pop',
        columns=['ihms_pop_for_chartron.cdnw_pop_id', 'ihms_pop_for_chartron.short_name', 'stat.stat_time']),
]