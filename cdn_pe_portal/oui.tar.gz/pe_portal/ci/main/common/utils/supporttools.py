import re
from os import popen
from base64 import b64encode
from httplib import HTTPSConnection, HTTPConnection
from urllib import urlencode, quote_plus

from django import forms
from django.utils import simplejson
from django.http import Http404, HttpResponse
from django.core.exceptions import ObjectDoesNotExist
from django.template import RequestContext
from django.template.loader import get_template
from django.views.decorators.csrf import csrf_exempt

from ci.constants import SUPPORT_SERVER, SUPPORT_AUTHENTICATION_KEY
from ci.common.utils import render_response
from ci.common.models.cdn import Node


# duplicate function in oui
def supporttoolsPreheatFilter(form):
        class PreheatFilterForm(forms.Form):
                filter_by_user = forms.CharField(required=False)
                filter_by_customer = forms.CharField(required=False)
                filter_by_url = forms.CharField(required=False)
        if form and form.get('action') == 'filter':
                filter_form = PreheatFilterForm(form)
        else:
                filter_form = PreheatFilterForm()
        #this is to create the cleaned_data...
        return filter_form

# duplicate function in oui
def supporttoolsPreheatListRetrieve(params):
        uri = "/rest/get/preheat-list/"
        filter_form = supporttoolsPreheatFilter(params)
        queryString = convertFormToQueryString(filter_form)
        authQueryString = "auth_key=" + SUPPORT_AUTHENTICATION_KEY
        uri += concatQueryStrings(queryString,authQueryString)
        resp = handleHttpGetConnection(SUPPORT_SERVER, uri)
        if isinstance(resp,dict):
                passObjects = resp
        else:
                passObjects = {'preheatsupport_error': [
                        "Internal error retrieving request (" +  str(resp) + ")"]}
        passObjects['verifyHeaders'] = supporttoolsVerifyHeaders()
        passObjects['filter_form'] = filter_form
        return passObjects


def handleHttpPostConnection(domain, uri, postParams):
    headers = {"Content-type": "application/x-www-form-urlencoded",
            "Accept": "text/plain"}
    try:
        conn = HTTPSConnection(domain)
        conn.request("POST", uri, urlencode(postParams), headers)
    except:
        return 600
    resp = conn.getresponse()
    conn.close()
    if resp.status == 200:
        return simplejson.load(resp)
    return resp.status

def handleHttpGetConnection(domain, uri):
    try:
        conn = HTTPSConnection(domain)
        conn.request("GET", uri)
    except:
        return 600
    resp = conn.getresponse()
    conn.close()
    if resp.status == 200:
        return simplejson.load(resp)
    return resp.status

def handleHttpGetConnection2(domain, uri, headers={}, request_type='GET'):
    try:
        conn = HTTPSConnection(domain)
        conn.request(request_type, uri, headers=headers)
    except:
        try:
            conn = HTTPConnection(domain)
            conn.request(request_type, uri, headers=headers)
        except Exception,e:
            raise e
    resp = conn.getresponse()
    response = resp.read()
    resp_status = resp.status
    conn.close()
    if resp_status == 200:
        return simplejson.loads(response)
    else:
        return resp_status

def mergeDictionaries(dict1, dict2):
    """Merges dict2 and dict1, if both have same key keeps value from dict1"""
    ret = dict1.copy()
    for key in dict2:
        if not ret.has_key(key):
            ret[key] = dict2[key]
    return ret

def concatQueryStrings(*list_of_strings):
    uri = "?"
    for string in list_of_strings:
        if string:
            if string.startswith("&") or string.startswith("?"):
                uri += string[1:]
            else:
                uri += string
        if not uri.endswith("&"):
            uri += "&"
    return uri[:-1]

def convertFormToQueryString(filter_form):
    queryString = ""
    if filter_form.is_valid():
        for field in filter_form:
            if isinstance(field.data,bool):
                queryString += "&" + quote_plus(field.name) + "="
                if field.data:
                    queryString += "2"
                else:
                    queryString += "3"
            elif field.data != None and field.data != "":
                queryString += "&" + quote_plus(field.name) + "=" + quote_plus(field.data)
        if queryString != "":
            queryString = "?" + queryString[1:]
    return queryString

def supporttoolsVerifyHeaders():
    return "response code,content-length,content-type,last-modified,etag"

@csrf_exempt
def supporttoolsJsonList(pRequest, passObjects, prefix, template):
    response = {'itemdata': []}
    if isinstance(passObjects.get(prefix),list):
        for request in passObjects.get(prefix):
            response['itemdata'].append({
                'id': prefix + str(request['id']),
                'trCode': get_template(template). \
                render(RequestContext(pRequest, {prefix + 'Request': request}))
            })
    return HttpResponse(simplejson.dumps(response, ensure_ascii=False), mimetype='text/plain; charset=utf-8')

def supporttoolsParseURL(pAddress):
    '''Simple parser of url into protocol, domain, path

    #urlparser.urlsplit seems to not work without service prefix
    #so making my own parser...'''

    returnDict = {'protocol':'http://', 'domain':'', 'path':''}
    pAddress = pAddress.strip()
    pos = pAddress.find("://")
    if pos != -1 and pos <= 5:
        #assume that service is not longer than 5 chars
        returnDict['protocol'] = pAddress[:pos+3]
        pAddress = pAddress[pos+3:]
    pos = pAddress.find("/")
    if pos != -1:
        returnDict['domain'] = pAddress[:pos]
        returnDict['path'] = pAddress[pos:]
    else:
        returnDict['domain'] = pAddress
        returnDict['path'] = "/"
    return returnDict

def supporttoolsInfo(pRequest, base_uri, object_id, template, outputDict = None, queryString = ""):

    authQueryString = "auth_key=" + SUPPORT_AUTHENTICATION_KEY
    uri = base_uri + object_id + "/" + concatQueryStrings(queryString,authQueryString)
    resp = handleHttpGetConnection(SUPPORT_SERVER, uri)
    if not isinstance(resp,dict) or resp.has_key('error'):
        raise Http404
    if outputDict != None:
        resp = mergeDictionaries(resp, outputDict)
    if pRequest.GET and pRequest.GET.get("display") == "all":
        resp['sliceString'] = ":"
        resp['display_all'] = True
    else:
        resp['sliceString'] = ":10"
    return render_response(pRequest, template, resp)

def supporttoolsCNameCheck(domainToVerify, dns, cnameTopLevelDomainDesired, cnameDesired=""):

    """Looks up CNAME record for domain on dns server,
    compares to top level domain and if set desired domain"""

    # run the dig command for desired url and dns server
    # then put output into dig variable

    digResults = popen('dig +time=1 @' + dns + ' ' + domainToVerify, 'r').read()

    # run regular expression to see if ANSWER SECTION ends with:
    #<text that doesn't include a ;>
    #<any tex> CNAME <panther_domain>
    #<panther_domain><text on same line> A <ip address>
    #<blank line>
    #;;

    #Status Codes as follows (desirable to sort this in preference order):
    # 1 = Lookup Successful
    # -1 = Unknown Error During Lookup
    # -2 = DNS Could Not Resolve Domain
    # -3 = DNS Lookup Failed
    # -4 = CNAME Not Set
    # -5 = Resolved ip address ... is not a panther node
    # -6 = "CNAME not pointing to: ...

    searchResults = re.compile(";;\s*ANSWER SECTION:([^;]+CNAME\s+([^\s^\n]+\.[^\s^\n^\.]+\.?)\s*\n\s*([^\s^\n]*)[^\n]*\s+A\s+([0-9.]+)\s*\n(\s*([^\s^\n]*)[^\n]*\s+A\s+[0-9.]+\s\n*)*)\s*\n;;",re.S + re.I).search(digResults)

    if searchResults == None:
        searchResults= re.compile(";;\s*ANSWER SECTION:([^;]*)\n;;",re.S + re.I).search(digResults)
        returnDictionary = {'statusCd':-3,
            'statusMsg':'DNS Lookup Failed',
            'cname':'N/A',
            'ip':'N/A',
            'answer':'N/A'}

        if not searchResults == None:
            returnDictionary['statusMsg'] = 'CNAME Not Set'
            returnDictionary['statusCd'] = -4
            returnDictionary['answer'] = searchResults.groups()[0].strip("\n ")
        elif digResults.find("connection timed out; no servers could be reached") == -1:
            returnDictionary['statusMsg'] = "DNS Could Not Resolve Domain"
            returnDictionary['statusCd'] = -2
        return returnDictionary

    #This is object that will be returned
    returnDictionary = {'statusCd':-1,
        'statusMsg':'Unknown Error During Lookup',
        'cname':searchResults.groups()[1],
        'ip':searchResults.groups()[3],
        'answer':searchResults.groups()[0].strip("\n ")}

    if cnameDesired and cnameDesired != searchResults.groups()[1]:
        returnDictionary['statusMsg'] = "CNAME not pointing to: " + cnameDesired
        returnDictionary['statusCd'] = -6
    elif not searchResults.groups()[1].endswith(cnameTopLevelDomainDesired):
        returnDictionary['statusMsg'] = "CNAME not pointing to: *." + cnameTopLevelDomainDesired
        returnDictionary['statusCd'] = -6
    elif Node.objects.filter(ipv4_address = searchResults.groups()[3]).count() == 0:
        returnDictionary['statusMsg'] = "Resolved ip address " + \
            searchResults.groups()[3] + \
            " is not a panther node"
        returnDictionary['statusCd'] = -5
    else:
        returnDictionary['statusMsg'] = "Correct CNAME"
        returnDictionary['statusCd'] = 1

    return returnDictionary

def supporttoolsCNameVerify(domainToVerify, cnameTopLevelDomainDesired, additionalDnsServers="", cnameDesired=""):
    """Calls supporttoolsCNameChecker for hard coded and supplied dns servers to verify proper DNS entry"""

    dnsServers = {"Open DNS":"208.67.222.222",
        "Open NIC US":"63.226.12.96",
        "Open NIC FR":"82.229.244.191",
        "ScrubIT": "67.138.54.100",
        "DNS Advantage":"156.154.70.1"}
    dnsServers.update(additionalDnsServers)
    responses =  []
    for title, dns in dnsServers.iteritems():
        cnameResponse = supporttoolsCNameCheck(
            domainToVerify.strip(),
            dns,
            cnameTopLevelDomainDesired.strip(),
            cnameDesired.strip())
        cnameResponse['dnsName'] = title
        responses.append(cnameResponse)
    return responses

def supporttoolsCNameVerifier(pRequest, passObjects, successURL, errorURL, prefixName = "cname"):
    additionalDns = {}
    for loop in range(1,4):
        if pRequest.POST['optional_dns' + str(loop)] != "":
            additionalDns['Optional DNS' + str(loop)] = \
                pRequest.POST['optional_dns' + str(loop)].strip()

    #find origin and service level of object
    if not pRequest.POST.has_key('verify_domain') or pRequest.POST['verify_domain'] == "":
        passObjects[prefixName + '_error'] = ['PAD field is required'];
        return render_response(pRequest, errorURL, passObjects)

    checkedDomain = supporttoolsParseURL(pRequest.POST['verify_domain'])['domain']
    try:
        site = passObjects['sites'].get(pad=checkedDomain)
    except ObjectDoesNotExist:
        passObjects[prefixName + '_error'] = \
            ['Domain (' + checkedDomain + ') not configured as a PAD']
        return render_response(pRequest, errorURL, passObjects)
    try:
        expectedRootDomain = site.service.dns_zone.domain_name + "."
        expectedCName = site.service.dns_prefix + '.' + expectedRootDomain
    except ObjectDoesNotExist:
        passObjects[prefixName + '_error'] = \
            ['PAD (' + checkedDomain + ') has error in configuration']
        return render_response(pRequest, errorURL, passObjects)

    cnameResults = supporttoolsCNameVerify(checkedDomain,expectedRootDomain, additionalDns,expectedCName)
    success = 0
    fail = 0
    cnameOutput = []
    for results in cnameResults:
        cnameOutput.append(results)
        if results['statusCd'] == 1:
            success = success + 1
        else:
            fail = fail + 1
    passObjects['success'] = success
    passObjects['total'] = success+fail
    passObjects['results'] = cnameOutput
    passObjects['cname'] = expectedCName
    passObjects['domain'] = checkedDomain
    return render_response(pRequest, successURL, passObjects)

def supporttoolsGenericSubmission(pRequest, sites, prefixName, visible_to_user, uri):
    if visible_to_user != True:
        visible_to_user = False
    passObjects = {}
    maxConcurrentRequests = 20

    if not pRequest.POST.has_key('urls') or pRequest.POST['urls'].strip("\n ") == "":
        passObjects[prefixName + '_error'] = ["URL field is required"]
        return passObjects

    if pRequest.POST.has_key('compareHeaders') and pRequest.POST['compareHeaders'].strip("\n ") != "":
        verifyHeaders =  pRequest.POST['compareHeaders'].strip("\n ")
    else:
        verifyHeaders = supporttoolsVerifyHeaders()

    urls = pRequest.POST.get('urls').split("\n")

    #Add urls to cache checker request object
    urlsProcessed = 0
    urlsSkipped = 0

    #clean up urls...
    for index in range(len(urls)*-1+1,1):
        if urls[index*-1].strip() == "":
            urls.pop(index*-1)
        elif urls[index*-1].strip() != urls[index*-1]:
            urls.insert(index*-1,urls[index*-1].strip())
            urls.pop(index*-1+1)
    if len(urls) > maxConcurrentRequests:
        #still greater than maxConcurrentRequests? report error...
        passObjects[prefixName + '_error'] = \
            ["Maximum requests allowed is " + str(maxConcurrentRequests)]
        return passObjects

    for url in urls:
        urlComponents = supporttoolsParseURL(url)
        if urls.count(url) > 1 and urls.index(url) < urlsProcessed + urlsSkipped:
            if not passObjects.has_key(prefixName + '_error'):
                passObjects[prefixName + '_error'] = []
            passObjects[prefixName + '_error'].append(
                "Duplicate entry (will only process request once): "  + url)
            urlsSkipped += 1
            continue
        if not url.startswith("http://") and url.find("://") in range(0,8):
            if not passObjects.has_key(prefixName + '_error'):
                passObjects[prefixName + '_error'] = []
            passObjects[prefixName + '_error'].append(
                "Only supported protocol at this time is http://, will not process the following url: " + url)
            urlsSkipped += 1
            continue

        try:
            site = sites.get(pad=urlComponents['domain'])
        except ObjectDoesNotExist:
            if not passObjects.has_key(prefixName + '_error'):
                passObjects[prefixName + '_error'] = []
            passObjects[prefixName + '_error'].append(
                "Domain (%s) not configured as a PAD (will not process): %s" %(urlComponents['domain'],url))
            urlsSkipped += 1
            continue

        try:
            siteDnsRoot = site.service.dns_zone.domain_name + "."
            siteDnsPrefix = site.service.dns_prefix
        except ObjectDoesNotExist:
            if not passObjects.has_key(prefixName + '_error'):
                passObjects[prefixName + '_error'] = []
            passObjects[prefixName + '_error']. \
                append("Error in PAD configuration (will not process): " + url)
            urlsSkipped += 1
            continue

        #check that cname is proper
        cnameResults = supporttoolsCNameCheck(urlComponents['domain'],"208.67.222.222",siteDnsRoot, siteDnsPrefix + '.' + siteDnsRoot)
        postParams = {'create_user': pRequest.user.username,
            'visible_to_user': visible_to_user,
            'submittedUrl': url,
            'protocol': urlComponents['protocol'],
            'path': urlComponents['path'],
            'follow_redirect': 0,
            'use_sub_files': site.use_sub_files,
            'rewrite_rules': site.rewrite_rules,
            'rewrite_rules_post_validation': site.rewrite_rules_post_validation,
            'custom_origin_headers': site.custom_headers,
            'custom_node_headers': "",
            'case_insensitive_urls': site.case_insensitive_urls,
            'drop_params': site.drop_params,
            'drop_precise_params_post_validation': site.drop_precise_params_post_validation,
            'service_dns_prefix': site.service.dns_prefix,
            'customername': site.customer.name,
            'origin': site.origin,
            'pad': site.pad,
            'verifyHeaders': verifyHeaders,
            'override_size': "False"}
        if pRequest.POST.has_key('override_size') and pRequest.POST['override_size'] == "on":
            postParams['override_size'] = "True"
        keys = postParams.keys()
        for key in keys:
            if postParams[key] == None:
                postParams[key] = ""
        if pRequest.POST.has_key('custom_node_headers') and pRequest.POST['custom_node_headers'].strip("\n ") != "":
            postParams['custom_node_headers'] = pRequest.POST['custom_node_headers'].strip("\n ")
        if postParams['drop_params'] != True and site.drop_params_post_validation == True:
            postParams['drop_params'] = 1
        if site.origin_host_header != "" and site.origin_host_header != None:
            if postParams['custom_origin_headers'] != None and postParams['custom_origin_headers'] != "":
                postParams['custom_origin_headers'] += "\n"
            else:
                postParams['custom_origin_headers'] = ""
            postParams['custom_origin_headers'] += "Host: " + site.origin_host_header
        if site.validation_scheme == 1:
            postParams['follow_redirect'] = 1
        elif site.validation_scheme == 2 and site.http_auth_user != "" and site.http_auth_user != None and site.http_auth_password != "" and site.http_auth_user != None:
            if postParams['custom_origin_headers'] != None and postParams['custom_origin_headers'] != "":
                 postParams['custom_origin_headers'] += "\n"
            else:
                postParams['custom_origin_headers'] = ""
            postParams['custom_origin_headers'] += "Authorization: Basic " + \
                b64encode(site.http_auth_user + ":" + site.http_auth_password)
        if site.origin_ip != "" and site.origin_ip != None:
            postParams['origin'] = site.origin_ip
        if site.origin_port != "" and site.origin_port > 0:
            postParams['origin'] += ":" + str(site.origin_port)
        resp = handleHttpPostConnection(SUPPORT_SERVER, uri, postParams)
        if isinstance(resp,dict) and resp.get('status') == 1:
            urlsProcessed += 1
            if resp.has_key("error"):
                if not passObjects.has_key(prefixName + '_error'):
                    passObjects[prefixName + '_error'] = []
                passObjects[prefixName + '_error'].append(resp['error'])
        else:
            if not passObjects.has_key(prefixName + '_error'):
                passObjects[prefixName + '_error'] = []
            passObjects[prefixName + '_error'].append(
                "Internal error processing request for: " + url)

        if cnameResults['statusCd'] != 1:
            if not passObjects.has_key(prefixName + '_error'):
                passObjects[prefixName + '_error'] = []
            passObjects[prefixName + '_error'].append("DNS Warning(" + \
                urlComponents['domain'] + \
                "): " + \
                cnameResults['statusMsg'])
    if urlsProcessed > 0:
        if not passObjects.has_key(prefixName + '_msg'):
            passObjects[prefixName + '_msg'] = []
        passObjects[prefixName + '_msg'].append(str(urlsProcessed) + \
            " cache status request have been submitted")
    return passObjects

def supporttoolsCacheStatusFilter(fields):
    class CacheStatusFilterForm(forms.Form):
        filter_by_user = forms.CharField(required=False)
        filter_by_customer = forms.CharField(required=False)
        filter_by_url = forms.CharField(required=False)
        filter_by_visible_to_user = forms.NullBooleanField(required=False)
    if fields and fields.get('action') == 'filter':
        filter_form = CacheStatusFilterForm(fields)
    else:
        filter_form = CacheStatusFilterForm()
    return filter_form

def supporttoolsCacheStatusSubmission(pRequest, sites, prefixName = "cache", visible_to_user = False):
    """Checks how many nodes have correct, outdate, and do not have the desired object (url) in memory/disk"""
    uri = "/rest/request/cache/?auth_key=" + SUPPORT_AUTHENTICATION_KEY
    return supporttoolsGenericSubmission(pRequest, sites, prefixName, visible_to_user, uri)

def supporttoolsCacheStatusListRetrieve(params):
    uri = "/rest/get/cache-list/"

    filter_form = supporttoolsCacheStatusFilter(params)
    queryString = convertFormToQueryString(filter_form)
    authQueryString = "auth_key=" + SUPPORT_AUTHENTICATION_KEY
    if queryString == "":
        authQueryString = "?" + authQueryString
    elif not queryString.endswith("&"):
        authQueryString = "&" + authQueryString
    uri += queryString + authQueryString
    resp = handleHttpGetConnection(SUPPORT_SERVER, uri)
    if isinstance(resp,dict):
        passObjects = resp
    else:
        passObjects = {'cachesupport_error': [
            "Internal error retrieving request (" +  str(resp) + ")"]}
    passObjects['verifyHeaders'] = supporttoolsVerifyHeaders()
    passObjects['filter_form'] = filter_form
    return passObjects

def supporttoolsTestUrlFilter(form):
    class TestUrlFilterForm(forms.Form):
        filter_by_user = forms.CharField(required=False)
        filter_by_customer = forms.CharField(required=False)
        filter_by_url = forms.CharField(required=False)
        filter_by_visible_to_user = forms.NullBooleanField(required=False)
    if form and form.get('action') == 'filter':
        filter_form = TestUrlFilterForm(form)
    else:
        filter_form = TestUrlFilterForm()
    #this is to create the cleaned_data...
    return filter_form

def supporttoolsTestUrlSubmission(url, ticket, sites, prefixName = "test", visible_to_user = False, username="N/A"):
    """Checks the cs version and system date on all of our http servers"""
    uri = "/rest/request/test/?auth_key=" + SUPPORT_AUTHENTICATION_KEY
    urlComponents = supporttoolsParseURL(url)
    try:
        site = sites.get(pad=urlComponents['domain'])
    except ObjectDoesNotExist:
        return {'request_key': "", prefixName + '_error': ["Domain (%s) not configured as a PAD." %(urlComponents['domain'])]}
    postParams = {'create_user': username,
            'visible_to_user': visible_to_user,
            'customername': site.customer.name,
            'submittedUrl': url,
            'domain': site.pad,
            'path': urlComponents['path'],
            'ticket': ticket}
    resp = handleHttpPostConnection(SUPPORT_SERVER, uri, postParams)
    if isinstance(resp,dict) and resp.get("status") == 1 and resp.get("request_key") != "":
        return {'request_key': resp.get("request_key"), prefixName + '_msg': ["Request submitted please have users experiencing the problem go to the following url and submit the form:\nhttp://www.pantherexpress.net/test-file/" + resp.get("request_key") + "/"]}
    return {'request_key': "", prefixName + '_error': ["Error processing test url submission.", resp]}

def supporttoolsTestUrlListRetrieve(params):
    uri = "/rest/get/test-list/"
    filter_form = supporttoolsTestUrlFilter(params)
    queryString = convertFormToQueryString(filter_form)
    authQueryString = "auth_key=" + SUPPORT_AUTHENTICATION_KEY
    if queryString == "":
        authQueryString = "?" + authQueryString
    elif not queryString.endswith("&"):
        authQueryString = "&" + authQueryString
    uri += queryString + authQueryString
    resp = handleHttpGetConnection(SUPPORT_SERVER, uri)
    if isinstance(resp,dict):
        passObjects = resp
    else:
        passObjects = {'testsupport_error': [\
            "Internal error retrieving request (" +  str(resp) + ")"]}
    passObjects['filter_form'] = filter_form
    return passObjects

def supporttoolsTestFileSubmission(url, ticket, request):
    from ci.common.utils import get_allowed_sites
    return supporttoolsTestUrlSubmission(url, ticket, get_allowed_sites(request),
        username = request.user.username,
        visible_to_user = True)

