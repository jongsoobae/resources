import httplib

class TimeoutHTTPConnection(httplib.HTTPConnection):

	def connect(self):
#		httplib.HTTPConnection.set_debuglevel(self,5)
		httplib.HTTPConnection.connect(self)
		self.sock.settimeout(self.timeout)


class TimeoutHTTPSConnection(httplib.HTTPSConnection):

	def connect(self):
		httplib.HTTPSConnection.connect(self)
		self.sock.settimeout(self.timeout)


