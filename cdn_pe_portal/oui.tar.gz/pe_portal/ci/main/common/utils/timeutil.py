"""
util functions for * objects
"""

from datetime import datetime, timedelta, date, time as time2
import time

def in_seconds(tdelta):
	return tdelta.days*86400 + tdelta.seconds + tdelta.microseconds / 1000000.
	
def in_minutes(tdelta):
	return in_seconds(tdelta) / 60.

def datetime_today():
	"""return today as a datetime (date.today() returns a date, which in operation
	is slightly different)"""
	return datetime(*date.today().timetuple()[:3])

def yesterday():
	"""return a pair of datetime objects spanning the last day.
	"""
	end_date = datetime_today()
	start_date = end_date - timedelta(days=1)
	return start_date, end_date
	
def one_day(start_date=None):
	"""given a date or datetime, return a pair of datetimes spanning a range
	of 1 day starting at the given value.
	"""
	return day_range(1, start_date)

def one_week(start_date=None):
	"""given a date or datetime, return a pair of datetimes spanning a range
	of 1 week starting at the given value.
	"""
	return day_range(7, start_date)
	
def day_range(num_days, start_date=None):
	if not start_date:
		end_date = datetime_today()
		start_date = end_date - timedelta(days=num_days)
	else:
		start_date = datetime(*start_date.timetuple()[:3])
		end_date = start_date + timedelta(days=num_days)
	return start_date, end_date
	
def mtd(last_day=None):
	"""return a pair of datetimes from the beginning of the month the given date
	is in to the date itself."""
	if not last_day:
		last_day = datetime_today()
		return (last_day - timedelta(days=1)).replace(day=1), last_day
	else:
		return last_day.replace(day=1), last_day + timedelta(days=1)
	
def date_and_epoch(unix_timestamp):
	epoch = (unix_timestamp % 86400) / 300
	date_ = datetime(*time.gmtime(unix_timestamp)[:3])
	return date_, epoch

def date2dt(d):
	"""
	@param d:	A date
	@return:	A datetime
	"""
	return datetime.combine(d, time2(0))

def previous_month(d):
	"""
	@param d:   A datetime.date instance
	@return:    A datetime.date instance, same day, previous month
	"""
	return date(
		d.year if d.month > 1 else d.year - 1,
		d.month - 1 if d.month > 1 else 12,
		d.day
	)

def next_month(d):
	"""
	@param d:   A datetime.date instance
	@return:    A datetime.date instance, same day, next month
	"""
	return date(
		d.year if d.month < 12 else d.year + 1,
		d.month + 1 if d.month < 12 else 1,
		d.day
	)
