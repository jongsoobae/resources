"""
Refactor this file and I'll buy you lunch for a week. --Lawrence
"""

from ci.common.utils import timeutil
from ci.common.models.site import Site 
from ci.common.models.customer import Customer
from ci.common.models.cdn import Node, Pop
from ci.common.models.traffic import TrafficBytes, TrafficBytesPop, TrafficRequests, TrafficMissRequests, TrafficMissBytes, UrlCount
from ci.common.models.invoice import Invoice, previous_month, SiteRateMonth, TrafficHistory
from math import floor, ceil
from datetime import datetime, timedelta, date, time as datetime_time
from django.utils.datastructures import SortedDict
from django.db import transaction, connection
from ci.common.utils.mathutil import bytes_to_mbps, find_95th
import time
import traceback
import re
import copy

def get_billable_95th_mbps(regions, start_time, end_time, verbose=False):
	customers = Customer.objects.filter(address__country__region__in=regions).distinct()
	total = 0
	for customer in customers:
		sites = Site.objects.filter(customer=customer)
		if not sites:
			continue
		customer_95th = get_grouped_stats(sites, start_time, end_time)[2]
		if verbose:
			print '%s: %.2f' % (customer, customer_95th)
		total += customer_95th
	return total

class fake_transaction():
	enter_transaction_management = leave_transaction_management = rollback = commit = lambda self: None
	managed = lambda self: True

def make_invoices(customers=None, month=None, debug=False, transaction=transaction):
	"""this is run at the beginning of each month, to generate aggregate statistics for
	customers' traffic in the last month for billing purposes. the statistics
	are cached in the traffic_history table, and rows are created in the invoice table
	to note the customer's settings for the month (prebilling, the applicable rate, etc).
	the latter is then used to derive the amount each customer should be charged.
	
	if debug is True, the values of each new traffic_history and invoice row are displayed,
	but the rows are not saved to the database.
	@param customers:	A sequence of Customer objects, or None for all Customers
	@param month:		A datetime, the month for which to generate invoices, or None
						for previous month
	@debug:				If True, don't changed the DB
	@transaction:		If fake_transaction(), caller manages transactions
	"""
	from ci.common.models.adjustment import InvoiceAdjustment
	
	# Use a transaction per customer
	transaction.enter_transaction_management()
	
	# Managed block
	try:
		transaction.managed()
		
		if customers is None:
			customers = Customer.objects.filter(status=True).select_related()
		
		if month is None: # generate for last month by default
			today = datetime(*date.today().timetuple()[:3])
			if today.month > 1:
				start_date = today.replace(month=today.month-1, day=1)
			else:
				start_date = today.replace(year=today.year-1, month=12, day=1)
		else:
			start_date = datetime(*month.timetuple()[:3])
		if start_date.month < 12:
			end_date = start_date.replace(month=start_date.month+1)
		else:
			end_date = start_date.replace(year=start_date.year+1, month=1)
		
		for customer in customers:
			if not customer.address: #Do not make an invoice for a customer without an address
				pass
			stats = get_customer_traffic_stats(customer.id, start_date, end_date)
			total_stats = stats['total']
			aggregate = TrafficHistory(customer=customer, site=None, month=start_date, 
				min_mbps=total_stats['min'], max_mbps=total_stats['max'],
				mbps_95p=total_stats['95th'], gbytes=total_stats['gb'])
			
			if (
				total_stats['gb'] > 0
				or customer.default_rate.minimum
				# customer has a prior invoice with a prebill charge
				or customer.invoice_set.filter(prebill=True, month=previous_month(start_date))
				# customer's sites have special rates applied
				or customer.site_set.filter(default_rate__minimum__gt=0)
				# customer's sites have special rates applied for this month
				or SiteRateMonth.objects.filter(site__customer=customer, month=start_date)
			):
				# For any of the Customer's Sites that have a special default rate,
				# apply that rate to this Invoice, but not if there's already a
				# special rate for just this month.
				site_rate_months = [
					SiteRateMonth(
						site=site, rate=site.default_rate, month=start_date
					)
					for site in customer.site_set.filter(default_rate__isnull=False)
					if not site.site_rate_set.filter(month=start_date)
				]
				invoice = Invoice(customer=customer, month=start_date, 
					rate=customer.default_rate, prebill=customer.prebill)
				
				# Link the Customer's adjustments to this month's Invoice
				invoice_adjustments = [
					InvoiceAdjustment(
						invoice=invoice,
						description=adjustment.description,
						is_percentage=adjustment.is_percentage,
						amount=adjustment.amount
					)
					for adjustment in customer.customer_adjustment_set.all()
				]
				
				for site in [k for k in stats.keys() if k != 'total']:
					site_stats = stats[site]
					if site_stats['95th'] > 0:
						history = TrafficHistory(customer=customer, site=site, month=start_date, 
							min_mbps=site_stats['min'], max_mbps=site_stats['max'],
							mbps_95p=site_stats['95th'], gbytes=site_stats['gb'])
						if not debug:
							history.save()
						else:
							print '%s (%d), %s: min %.1f, max %.1f, 95th %.1f, gb %.1f' % (customer.name, customer.id, site.pad, site_stats['min'], site_stats['max'], site_stats['95th'], site_stats['gb'])
				
				if not debug:
					try:
						# Transaction block
						aggregate.save()
						for site_rate_month in site_rate_months: site_rate_month.save()
						invoice.save()
						for adjustment in invoice_adjustments:
							adjustment.invoice = invoice # Now invoice has an id
							adjustment.save()
						transaction.commit()
					except Exception, e:
						transaction.rollback()
						print 'Could not save invoice for %s:\n%s' % (customer, e)
						continue
				else:
					print '%s (%d) total: min %.1f, max %.1f, 95th %.1f, gb %.1f' % (customer.name, customer.id, total_stats['min'], total_stats['max'], total_stats['95th'], total_stats['gb'])
					print 'invoice: %s' % invoice.make_id()
			else:
				continue
				
	finally:
		transaction.leave_transaction_management()

def dns_load(day=None):
	if day is None: # calculate for yesterday by default
		start_date, end_date = timeutil.yesterday()
	else:
		start_date, end_date = timeutil.one_day(day)
	nodes = dict([(n.id, n) for n in Node.objects.all()]) # cache of all nodes keyed by id
	cursor = connection.cursor()
	cursor.execute("""select node_id, sum(requests), sum(guesses)
		from dns_traffic_service
		where stat_time >= '%s' and stat_time < '%s' 
		group by node_id order by sum(requests) desc""" % (start_date, end_date))
	rows = cursor.fetchall()
	regions = {}
	total = {'dynamic':0, 'guess':0}
	for node_id, dynamic, guess in rows:
		node = nodes[node_id]
		if node.pop.region.name not in regions:
			regions[node.pop.region.name] = {'nodes':SortedDict(), 'dynamic':0, 'guess':0}
		r = regions[node.pop.region.name]
		dynamic, guess = long(dynamic), long(guess)
		r['nodes'][node] = {'dynamic': dynamic, 'guess': guess, 'guess_pct': guess / float(dynamic) * 100}
		r['dynamic'] += dynamic
		r['guess'] += guess
		total['dynamic'] += dynamic
		total['guess'] += guess
		
	for region in regions:
		r = regions[region]
		if r['dynamic'] != 0:
			r['guess_pct'] = r['guess'] / float(r['dynamic']) * 100
		else:
			r['guess_pct'] = 0
		
	if total['dynamic'] != 0:
		total['guess_pct'] = total['guess'] / float(total['dynamic']) * 100
	else:
		total['guess_pct'] = 0
		
	region_names = regions.keys()
	region_names.sort(key=lambda k:-regions[k]['dynamic'])	
	
	sorted_regions = SortedDict()
	for region in region_names:
		sorted_regions[region] = regions[region]
	
	return {'day':start_date, 'regions':sorted_regions, 'total':total}

MAX_URLS = 200

def top_urls(customer, drafts=None, start_date=None):
	"""return a customer's top urls data in a dictionary suitable for templating. only works for 1 day
	because django doesn't do grouping yet.
	"""
	if not drafts:
		requested_sites = customer.site_set.filter(status=1, track_urls=1)
	else:
		requested_sites = [draft.site for draft in drafts]
	if start_date is None:
		end_date = date.today()
		start_date = end_date - timedelta(days=1)
	else:
		end_date = start_date + timedelta(days=1)
	sites = []
	for site in requested_sites:
		top_urls = UrlCount.objects.filter(site_id=site.id, stat_time__gte=start_date, stat_time__lt=end_date).order_by('-hits','-completes')[:MAX_URLS]
		if top_urls:
			sites.append({'name':site.pad,'urls':top_urls})
	return {
		'customer':	customer,
		'startdate': start_date,
		'enddate': end_date,
		'sites': sites
	}

def top_urls_x(site_id, days, code=200):
	cursor = connection.cursor()
	if code == 200:
		cursor.execute("""
			select 
				url, sum(hits), sum(completes) 
			from 
				url_count2 uc, url u 
			where 
				uc.site_id = %d 
				and stat_time >= date_sub(now(), interval %d day)
				and uc.url_id = u.id
			group by hash 
			order by sum(hits) desc 
			limit %d""" % (site_id, days, MAX_URLS))
	else:
		cursor.execute("""
			select 
				url, sum(ucr.hits), 0
			from 
				url u, url_count2 uc, url_count_response_codes2 ucr
			where 
				u.id = uc.url_id
				and uc.id = ucr.url_count_id
				and uc.site_id = %d 
				and uc.stat_time >= date_sub(now(), interval %d day)
				and ucr.code = %d 
			group by u.id 
			order by sum(ucr.hits) desc 
			limit %d""" % (site_id, days, code, MAX_URLS))
	return cursor.fetchall()

def add_series(a, b):
        """
        Pairwise sum of two serieses
        @param a:  A sequence of numbers
        @param b:  A sequence of numbers
        @return:   A sequence of a[i] + b[i]
        """
        assert len(a) == len(b)
        rv = copy.copy(a)
        for i in range(len(rv)):
                rv[i] += b[i]
				
        return rv

def get_grouped_stats(sites, start_time, end_time, hour_offset=0, include_raw_data=False, include_requests=False, max_hits=False):
	"""return the overall (avg mbps, max mbps, 95th mbps, gb) values for a group of sites.
	the values are summed at the database, so the 95th value is for the combined traffic,
	not the sum of the 95th values of the individual sites (the latter would be larger).
	
	Added a bool argument to return the raw data. This argument is passed as tru only by the mtd report 
	to calculate minFee --Silvia
	
	Added a bool argument for whether to return hit data or not. This bool is default to false 
	and is only passed as true in the month-to-date report --Silvia
	
	Added another bool argument to whether return the max number of hits for the site in the time range given.
	This is to be used by the new customer cost report --Silvia
	"""
	bytes = get_traffic_data(TrafficBytes, [s.id for s in sites], start_time, end_time, hour_offset=hour_offset, group=True)
	ret = [
		bytes_to_mbps(sum(bytes) / float(len(bytes))),
		bytes_to_mbps(max(bytes)),
		bytes_to_mbps(find_95th(bytes)),
		float(sum(bytes)) / (1000**3)
	]
	
	if include_raw_data:
		ret.append(bytes)
	if max_hits or include_requests:
		request_stats = get_traffic_data(TrafficRequests, [s.id for s in sites], start_time, end_time, hour_offset=hour_offset, group = True)
	if include_requests:	
		ret.append(sum(request_stats))
	if max_hits:
		ret.append(max(request_stats))
	return ret

def get_sorted_traffic_stats(customer, start_time, end_time, include_misses = True):
	"""given a customer id and a time range, return a pair, the first of which
	is a dict with aggregate stats for all of the customer's traffic, and the 
	second of which is a SortedDict of similar tuples for each of the customer's
	sites, keyed by site id and ordered by GB in descending order.
	"""
	raw_stats = get_customer_traffic_stats(customer, start_time, end_time, include_misses=include_misses)
	totals = raw_stats['total']
	del raw_stats['total']
	keys = raw_stats.keys()
	keys.sort(key=lambda k:-raw_stats[k]['gb'])
	sorted_stats = SortedDict()
	for key in keys:
		sorted_stats[key] = raw_stats[key]
	return totals, sorted_stats

def get_customer_traffic_stats(customer, start_time, end_time, hour_offset=0, nonzero_only=True, all_sites=True, include_misses = True):
	if all_sites:
		sites = Site.objects.filter(customer=customer)
	else:
		sites = Site.objects.filter(customer=customer, status=True)
	return get_traffic_stats(sites, start_time, end_time, hour_offset=hour_offset, nonzero_only=nonzero_only, include_misses=include_misses)

def get_traffic_stats(sites, start_time, end_time, hour_offset=0, nonzero_only=True, include_misses = True):
	"""return aggregate statistics for a group of sites: calculate one dictionary with keys
	('hits', 'gb', 'avg', 'max', '95th', 'min', 'aveObj', 'hit_rate', 'misses', 'miss_mbps') for each site and for the total.
	
	the time range includes start_time and excludes end_time.
	"""
	results = {'total':{'hits':0, 'gb':0.0, 'avg':0.0, 'max':0.0, '95th':0.0, 'min':0.0, 'aveObj':0.0, 'hit_rate':0.0, 'misses':0.0, 'mbps_rate':0.0, 'miss_bytes':0.0, 'bytes':0.0}}
	
	if not sites:
		return results
	
	site_ids = [site.id for site in sites]
	sites_bytes = get_traffic_data(TrafficBytes, site_ids, start_time, end_time, hour_offset=hour_offset)
	sites_requests = get_traffic_data(TrafficRequests, site_ids, start_time, end_time, hour_offset=hour_offset)
	
	if include_misses:
		sites_miss_bytes = get_traffic_data(TrafficMissBytes, site_ids, start_time, end_time, hour_offset=hour_offset, filters=['key_value="direct"'])
		sites_misses = get_traffic_data(TrafficMissRequests, site_ids, start_time, end_time, hour_offset=hour_offset, filters=['key_value="direct"'])
		
	# these contain data for each PAD, which will later be used to produce aggregate values
	sites_data, sites_miss_data = {}, {}
	
	#calculate data for each individual PAD
	for site in sites:
		bytes, requests = (sites_bytes[site.id], sites_requests[site.id])
		sum_requests = sum(requests)
		sum_bytes = sum(bytes)
		if nonzero_only and sum_requests == 0:
			continue
			
		if include_misses:
			sites_miss_data[site] = (sites_miss_bytes[site.id], sites_misses[site.id])
			miss_bytes, misses = sites_miss_data[site]
			sum_misses, sum_miss_bytes = sum(misses), sum(miss_bytes)
		else:
			sum_misses, sum_miss_bytes = 0, 0
		
		try:
			hit_rate = max(0, min((float(sum_requests - sum_misses) / sum_requests) * 100, 100))
			mbps_rate = max(0, min((float(sum_bytes - sum_miss_bytes) / sum_bytes) * 100, 100))
		except ZeroDivisionError:
			hit_rate = 0
			mbps_rate = 0
			
		results[site] = {
			'hits': sum_requests,
			'gb': float(sum(bytes)) / (1000**3),
			'avg': bytes_to_mbps(sum(bytes) / float(len(bytes))),
			'max': bytes_to_mbps(max(bytes)),
			'95th': bytes_to_mbps(find_95th(bytes)),
			'min': bytes_to_mbps(min(bytes)),
			'mbps_rate':mbps_rate,
			'aveObj': (sum(bytes)/ 2**10) / float(sum_requests),
			'hit_rate': hit_rate
		}
		
		results['total']['hits'] += results[site]['hits']
		results['total']['gb'] += results[site]['gb']
		results['total']['misses'] += sum_misses
		results['total']['miss_bytes'] += sum_miss_bytes
		results['total']['bytes'] += sum_bytes
		
		sites_data[site] = bytes, requests
		
	# Calculate aggregate data
	if sites_data:
		combined_bytes = [sum(group) for group in zip(*[d[0] for d in sites_data.values()])]
		results['total']['avg'] = bytes_to_mbps(sum(combined_bytes) / float(len(combined_bytes)))
		results['total']['max'] = bytes_to_mbps(max(combined_bytes))
		results['total']['95th'] = bytes_to_mbps(find_95th(combined_bytes))
		results['total']['min'] = bytes_to_mbps(min(combined_bytes))
		if (results['total']['hits'] < results['total']['misses']) or results['total']['hits']==0.0:
			results['total']['aveObj'] = 0.0
			results['total']['hit_rate'] = 0.0
		else:
			results['total']['aveObj'] = (sum(combined_bytes)/2**10) / float(results['total']['hits'])
			results['total']['hit_rate'] = ((float(results['total']['hits'])-results['total']['misses'])/ float(results['total']['hits']))*100
		if (results['total']['miss_bytes'] > results['total']['bytes']) or results['total']['bytes']==0.0:
			results['total']['mbps_rate']=0
		else:
			results['total']['mbps_rate'] = (float(results['total']['bytes'] - results['total']['miss_bytes'])/results['total']['bytes'])*100
		
	return results

def get_traffic_data(table_class, site_ids, start_time, end_time, hour_offset=0, group=None, filters=[]):
	"""
	start_time and end_time are datetime objects.
	hour_offset is the offset relative to GMT (negative for US, positive for Asia).
	
	returns a dictionary, keyed by site id, of lists of each site's raw data for 
	the specified time range. if group is True, then it returns a single list of
	all the sites' data summed together.
	"""
	assert type(end_time) == datetime and type(start_time) == datetime
	assert end_time > start_time + timedelta(minutes=5), 'end time must be at least 5 minutes after start time'
	assert site_ids, 'list of site ids cannot be empty'
	
	gmt_start_time = start_time - timedelta(hours=hour_offset)
	gmt_start_day = gmt_start_time.replace(hour=0, minute=0, second=0, microsecond=0)
	gmt_end_time = end_time - timedelta(hours=hour_offset)
	if group:
		raw_rows = get_grouped_rows(table_class, site_ids, gmt_start_day, gmt_end_time, extra_filters=filters)
		return make_time_slice(raw_rows, start_time, end_time)
	
	# these rows must be in ascending order by date, but it is not necessary for them to be ordered by site.
	raw_rows = get_grouped_rows(table_class, site_ids, gmt_start_day, gmt_end_time, extra_groups=['customer_site_id'], extra_filters=filters)
	
	# split up the rows into groups. it is necessary to satisfy two conditions:
	# a: each group must have at most 1 row for each day.
	# b: the rows in each group must be ordered by day, ascending.
	row_groups = {}
	for row in raw_rows:
		site_id = row.site_id
		if site_id not in row_groups:
			row_groups[site_id] = []
		assert not row_groups[site_id] or row.stat_time > row_groups[site_id][-1].stat_time, 'rows must be in ascending order by date'
		row_groups[site_id].append(row)
	
	# 3. for each site, slice out the proper portion of data for the requested range,
	# inserting zeroes where data is absent, and store it in "sites_data".
	sites_data = {}
	for site_id in site_ids:
		if site_id in row_groups:
			rows = row_groups[site_id]
		else:
			rows = []
		sites_data[site_id] = make_time_slice(rows, start_time, end_time)
	
	return sites_data

def get_pop_traffic_data(table_class, split, start_time, end_time, hour_offset=0, site_ids=None, pop_ids=None):
	"""get traffic data from a table that has a pop column. like get_traffic_data(), but with different
	parameters: "pop_ids", a list of the pop ids to include, and "split", which must be "pop", "site", or
	None, depending on which attribute should separate the data or if they should be all combined.
	"""
	assert type(end_time) == datetime and type(start_time) == datetime, 'time params must be datetime objects'
	assert end_time > start_time + timedelta(minutes=5), 'end time must be at least 5 minutes after start time'
	
	gmt_start_time = start_time - timedelta(hours=hour_offset)
	gmt_start_day = gmt_start_time.replace(hour=0, minute=0, second=0, microsecond=0)
	gmt_end_time = end_time - timedelta(hours=hour_offset)
	
	if split not in ('pop', 'site', None):
		raise Exception('invalid split type: %s' % split)
	
	raw_rows = get_pop_rows(table_class, split, gmt_start_day, gmt_end_time, site_ids, pop_ids)
	
	if split is None:
		return make_time_slice(raw_rows, start_time, end_time)
	
	if not site_ids:
		site_ids = [site.id for site in Site.objects.all()]
	if not pop_ids:
		pop_ids = [pop.id for pop in Pop.objects.all()]
	
	# split up the rows into groups. it is necessary to satisfy two conditions:
	# a: each group must have at most 1 row for each day.
	# b: the rows in each group must be ordered by day, ascending.
	keyed_rows = {}
	for row in raw_rows:
		key = (row.site_id, row.pop_id)[split=='pop']
		if key not in keyed_rows:
			keyed_rows[key] = []
		keyed_rows[key].append(row)
	
	# 3. for each site, slice out the proper portion of data for the requested range,
	# inserting zeroes where data is absent, and store it in "sites_data".
	keyed_data = {}
	for key in (site_ids, pop_ids)[split=='pop']:
		if key in keyed_rows:
			rows = keyed_rows[key]
		else:
			rows = []
		keyed_data[key] = make_time_slice(rows, start_time, end_time)
	
	return keyed_data

def make_time_slice(rows, start_time, end_time):
	"""given a set of day rows, unique per day, in ascending order, return a list of values
	sliced from those rows representing the data for the time period denoted by start_time and end_time.
	
	if the rows provided do not completely cover the time period, the data returned will be padded with
	zeros in the positions that lack data."""
	time_slice = []
	current_day = start_time.replace(hour=0, minute=0, second=0, microsecond=0)
	start_epoch, end_epoch, epoch_delta = calc_traffic_data_params(start_time, end_time)
	row_index = 0
	# go day by day through the db rows matching the specified time range.
	# if a row is found that matches the day, append its data; otherwise, append
	# zeroes. adjust the amount appended appropriately for the first and last day
	# of the range if the specified times do not fall on day boundaries (and they
	# often won't).
	while current_day < end_time:
		if len(rows) <= row_index or rows[row_index].stat_time > current_day:
			time_slice += get_zeroes(current_day, start_time, end_time, start_epoch, end_epoch)
		elif len(rows) > row_index and rows[row_index].stat_time == current_day:
			time_slice += get_portion(rows[row_index], start_time, end_time, start_epoch, end_epoch)
			row_index += 1
		else:
			assert False, 'all stat_time values must be whole day values, and there must only be one row per day.'
		current_day += timedelta(days=1)
	assert len(time_slice) == epoch_delta, 'length was %d, expected %d' % (len(time_slice), epoch_delta)
	return time_slice

def make_time_slice_from_points(rows, start_time, end_time):
	"""given a set of 5-minute interval time rows, in ascending order, return a list of values
	sliced from those rows representing the data for the time period denoted by start_time and end_time.
	
	if the rows provided do not completely cover the time period, the data returned will be padded with
	zeros in the positions that lack data."""
	
	start_epoch, end_epoch, epoch_delta = calc_traffic_data_params(start_time, end_time)
	time_slice = []
	row_index = 0
	current_slice = start_epoch
	while current_slice < end_time:
		if len(rows) <= row_index or rows[row_index].stat_time > current_slice:
			time_slice.append(0)
		elif rows[row_index].stat_time == current_slice:
			time_slice.append(rows['row_index'].data)
			row_index += 1
		else:
			assert False, 'all stat_time values must be in order and can not be null.'
		current_slice += timedelta(minutes=5)
	assert len(time_slice) == epoch_delta, 'length was %d, expected %d' % (len(time_slice), epoch_delta)
	return time_slice

def get_pop_rows(table_class, split, start_time, end_time, site_ids=None, pop_ids=None):
	"""return day rows from a pop table grouped by site, by pop, or all combined, depending 
	on whether the value of split is 'site', 'pop', or None."""
	cursor = connection.cursor()
	sum_columns = ['sum(e%d)'%i for i in range(288)]
	if site_ids:
		site_clause = 'and customer_site_id in (%s)' % ','.join([str(s) for s in site_ids])
	else:
		site_clause = ''
	if pop_ids:
		pop_clause = 'and pop_id in (%s)' % ','.join([str(p) for p in pop_ids])
	else:
		pop_clause = ''
	if split == 'pop':
		group = ', pop_id'
	elif split == 'site':
		group = ', customer_site_id'
	elif not split:
		group = ''
	q = """select %s, customer_site_id, pop_id, stat_time from %s 
		where stat_time >= '%s' 
		and stat_time < '%s' %s %s 
		group by stat_time%s order by stat_time asc""" % \
			(', '.join(sum_columns), table_class._meta.db_table, 
			start_time, end_time, site_clause, pop_clause, group)
	cursor.execute(q)
	rows = cursor.fetchall()
	ret = []
	for row in rows:
		gr = GroupedRow(row[-1], row[-2], row[-3])
		[setattr(gr, 'e%d'%i, long(row[i])) for i in range(288)]
		ret.append(gr)
	return ret

class GroupedRow:
	def __init__(self, stat_time, pop_id, site_id):
		self.stat_time = stat_time
		self.pop_id = pop_id
		self.site_id = site_id

def get_grouped_rows(table_class, site_ids, start_time, end_time, extra_groups=[], extra_filters=[]):
	db = None
	try:
		import MySQLdb
		from ci.constants import MySQL_CHARTRON_DB
		if MySQL_CHARTRON_DB:
			db = MySQLdb.connect(**MySQL_CHARTRON_DB)
			cursor = db.cursor()
		else:
			cursor = connection.cursor()
	except:
		cursor = connection.cursor()

	table_name = re.sub('_v$', '', table_class._meta.db_table)
	sum_columns = ['sum(e%d)'%i for i in range(288)]
	q = """select %s, stat_time, customer_site_id from %s 
		where stat_time >= '%s' and stat_time < '%s' and customer_site_id in (%s)%s 
		group by stat_time%s order by stat_time asc""" % \
			(','.join(sum_columns), table_name, start_time, end_time, 
			','.join([str(s) for s in site_ids]), 
			(' and %s' % ' and '.join(extra_filters) if extra_filters else ''),
			(',%s' % ','.join(extra_groups) if extra_groups else ''))
	cursor.execute(q)
	rows = cursor.fetchall()
	ret = []
	for row in rows:
		gr = GroupedRow(row[-2], None, row[-1])
		[setattr(gr, 'e%d'%i, long(row[i])) for i in range(288)]
		ret.append(gr)
	return ret

def get_grouped_rows_extra(
		traffic_tables,
		start_time,
		end_time,
		extra_groups=[],
		extra_filters=[],
		factor=1.0,
		value_field = None,
		maximum = False,
		func = '',
	):
	"""
	Like get_grouped_rows(), but allows grouping by region or isp, and allows an extra filter.
	extra_groups is a list of strings like 'table.column' by which to group the results, where
	'table' can be in ('customer_country', 'customer', 'customer_site', 'site_service', 'region',
	'pop_service', 'pop').
	
	NOTE: If the parameters for this function are modified the same modifications MUST be done in get_dns_grouped_rows_extra
	
	Assumption: t0 table always ends in _pop and that if there is no join with .pop_id in it, then it is safe to replace that table with the same name with out the _pop!  This allows for much faster queries, I'd put this at hackish but a major oversight in the original design.
	
	@param traffic_tables:	A sequence of Django model classes like TrafficBytesPop and
							operators like '+', '-', '(', ')'
	@param start_time:   	A datetime
	@param end_time:     	A datetime
	@param extra_groups: 	Sequence of strings like 'table.column' by which to group the results
	@param extra_filters: 	A sequence of SQL substrings, e.g. "key_value like '2%'" or
	                        'customer_site.customer_site_id in (1, 2)'
	@param factor:       	A float, multiply all results by this
	@param maximum:			If not False, the maximum value allowed
	@param func:		A mysql function name to add around the value, allows for round, floor, ceil extra...
	@return:  			 	A sequence of GroupedRow instances, ordered by stat_time
	"""
	class Table:
		def __init__(self, name, alias=None, is_traffic=False):
			self.name 		= name.lower()
			self.alias 		= alias.lower() if alias else self.name
			self.is_traffic = is_traffic
		def __hash__(self):
			return hash(self.name + self.alias)
		def __eq__(self, other):
			return self.name == other.name and self.alias == other.alias
		def __repr__(self):
			return 'Table(%s, %s)' % (repr(self.name), repr(self.alias))
	db = None
	try:
		import MySQLdb
		from ci.constants import MySQL_CHARTRON_DB
		if MySQL_CHARTRON_DB:
			db = MySQLdb.connect(**MySQL_CHARTRON_DB)
			cursor = db.cursor()
		else:
			cursor = connection.cursor()
	except:
		cursor = connection.cursor()
	operations		= []
	# Process traffic_tables, which might be like
	# (TrafficBytesPop, '-', TrafficMissBytesPop)
	class2table = {}
	for s in traffic_tables:
		if hasattr(s, '_meta'):
			if s in class2table:
				table = class2table[s]
			else:
				table = Table(s._meta.db_table, alias='t%d' % len(class2table), is_traffic=True)
				class2table[s] = table
			
			# was: Cast each column as signed to avoid MySQL's behavior when
			# subtracting an unsigned int from a smaller one: it returns
			# 18446744073709551615 == 2 ** 64 -1.
			# but: cast was removed in an attempt to improve performance.
			
			# %s is replaced now, %%(col_index)d is replaced later
			operations.append('sum(%(alias)s.e%%(col_index)d)' % {'alias': table.alias})
			
		else:
			operations.append(s)
	
	tables = set(class2table.values())
	
	# If traffic_tables was like:
	# ('traffic_bytes_pop', '-', 'traffic_miss_requests_pop')
	# construct a string like 'sum(t0.e0 - t1.e0), sum(t0.e1 - t1.e1), ...'
	sum_columns    	= [
		'%s((%s) * %s)' % (func,
			' '.join(op % { 'col_index': i} for op in operations), factor
		) for i in range(288)
	]
	
	# If extra_filter is like 'key_value = 3', then assume it refers to the
	# first traffic table, and update it to 't0.key_value = 3'; otherwise if
	# it already has an alias specified, like 'site_service.cdn_service_id = 42',
	# then leave it alone
	alias_pat = re.compile(r'\s*\w+\.\w+\s*(=|in).+')
	extra_filters = [
		i if alias_pat.match(i) else 't0.%s' % i.strip()
		for i in extra_filters
	]
	
	# Starting with the traffic tables (e.g., traffic_bytes_pop), join to the
	# additional tables necessary for extra_groups and extra_filters
	def join_traffic_table(column, other_table):
		return 't0.%s = %s.%s' % (
			column, other_table, column
		)
	
	joins     		= set()
	for expr in extra_groups + extra_filters:
		table_alias = expr.split('.')[0].lower()
		if table_alias != 't':
			for extra_table, extra_join in {
				# map: table -> additional tables needed to join to it
				'customer_country':	[
					(
						Table('customer_site'),
						join_traffic_table('customer_site_id', 'customer_site')
					),
					(
						Table('customer'),
						'customer_site.customer_id = customer.customer_id'
					),
					(
						Table('address'),
						'customer.address_id = address.address_id'
					),
					(
						Table('country', 'customer_country'),
						'address.country_id = customer_country.country_id'
					)
				],
				'customer': 		[
					(
						Table('customer_site'),
						join_traffic_table('customer_site_id', 'customer_site')
					),
					(
						Table('customer'),
						'customer_site.customer_id = customer.customer_id'
					)
				],
				'customer_site':	[
					(
						Table('customer_site'),
						join_traffic_table('customer_site_id', 'customer_site')
					)
				],
				'site_service' : 	[				
					(
						Table('cdn_service', 'site_service'),
						'customer_site.cdn_service_id = site_service.cdn_service_id'
					),
					(
						Table('customer_site'),
						join_traffic_table('customer_site_id', 'customer_site')
					)
				],
				'region': 			[
					(
						Table('region'),
						'pop.region_id = region.region_id'
					),
					(
						Table('pop'),
						join_traffic_table('pop_id', 'pop')
					)
				],
				'country': 			[
					(
						Table('country'),
						'pop.country_id = country.country_id'
					),
					(
						Table('pop'),
						join_traffic_table('pop_id', 'pop')
					)
				],
				'pop_service': 		[				
					(
						Table('cdn_service', 'pop_service'),
						'pop.pop_id = cdn_service_pops.pop_id'
					),
					(
						Table('cdn_service_pops'),
						'cdn_service_pops.service_id = pop_service.cdn_service_id'
					),
					(
						Table('pop'),
						join_traffic_table('pop_id', 'pop')
					)
				],
				'pop':				[
					(
						Table('pop'),
						join_traffic_table('pop_id', 'pop')
					)
				],
			}.get(table_alias, []):
				if extra_table: tables.add(extra_table)
				if extra_join:  joins.add(extra_join)
				
	#this is code to optimize the table usage...basically if joins has the text ".pop_id" in it assume we need to use the pop table..if not assume we don't....
	require_pop_table = False
	for item in joins:
		if item.find(".pop_id") > 0:
			require_pop_table = True
			break
	if not require_pop_table:
		#woo we can optimize query by avoiding pop tables...
		for table in tables:
			if table.name.endswith("_pop") and table.alias.startswith("t") and len(table.alias) == 2:
				table.name = table.name[:-4]
		joins.update(
			't0.stat_time = %s.stat_time and t0.customer_site_id = %s.customer_site_id' % (
				t.alias, t.alias
			)
			for t in tables if t.is_traffic and t.alias != 't0'
		)
	else:
		joins.update(
			't0.stat_time = %s.stat_time and t0.customer_site_id = %s.customer_site_id and t0.pop_id = %s.pop_id' % (
				t.alias, t.alias, t.alias
			)
			for t in tables if t.is_traffic and t.alias != 't0'
		)
		
	join_filter		= 'and %s' % ('\n       and '.join(joins)) if joins else ' '
	
	q = """
select t0.stat_time, %(pop_id)s, t0.customer_site_id, %(sum_columns)s %(extra_groups)s
  from %(tables)s
 where t0.stat_time >= '%(start_time)s' and t0.stat_time <= '%(end_time)s'
       %(join_filter)s
       %(extra_filters)s
 group by t0.stat_time %(extra_groups)s
 order by t0.stat_time""" % {
			'pop_id': 't0.pop_id' if require_pop_table else '0 pop_id', #this is purely for backward compatibility...if your not splitting by pop this field is random...mysql really is lax with letting you include non-group by columns
			'sum_columns': 	','.join(sum_columns),
			'tables':		','.join('%s %s' % (tab.name, tab.alias) for tab in tables),
			'start_time':   start_time.date(),
			'end_time':     end_time.date(),
			'join_filter':	join_filter,
			'extra_groups':(',%s' % ','.join(extra_groups) if extra_groups else ''),
			# Escape any %'s in extra_filter because the SQL backend will do another
			#   string interpolation on this query
			'extra_filters': 'and ' + ' and '.join(f.replace('%', '%%') for f in extra_filters) if extra_filters else '',
	}
	cursor.execute(q)
	rows = cursor.fetchall()
	if db:
		cursor.close()
		db.close()
	ret = []
	for row in rows:
		import pprint
		gr = GroupedRow(row[0], row[1], row[2])
		# if row[i+3] is NULL (due to e.g. division by zero), we replace it with 0
		if maximum:
			val = lambda v: min(maximum, float(row[i+3]) if row[i+3] else 0)
		else:
			val = lambda v: float(row[i+3]) if row[i+3] else 0
		[setattr(gr, 'e%d'%i, val(i)) for i in range(288)]
		[setattr(gr, extra_group, row[i+3+288]) for i, extra_group in enumerate(extra_groups)]
		ret.append(gr)
	return ret

def get_dns_grouped_rows_extra(
		traffic_tables,
		start_time,
		end_time,
		extra_groups=[],
		extra_filters=[],
		factor=1.0,
		value_field=None,
		maximum = False,
		func = '',
	):
	"""
	This is a dns traffic version of get_grouped_rows_extra.  All comments for that method should apply to this one as well.
	"""
	if value_field == None:
		value_field = "requests"
	db = None
	try:
		import MySQLdb
		from ci.constants import MySQL_CHARTRON_DB
		if MySQL_CHARTRON_DB:
			db = MySQLdb.connect(**MySQL_CHARTRON_DB)
			cursor = db.cursor()	
		else:
			cursor = connection.cursor()
        except:
                cursor = connection.cursor()
	tables = set()
	for s in traffic_tables:
		if hasattr(s, '_meta'):
			tables.add(s._meta.db_table)
	joins = set()
	for expr in extra_groups + extra_filters:
		table_alias = expr.split('.')[0].lower()
		if table_alias != 't':
			for extra_table, extra_join in {
				#map table -> additional tables needed to join to it
				'dns_region': [
					(
						'region dns_region',
						'pop.region_id = dns_region.region_id'
					),
					(
						'pop',
						'node.pop_id = pop.pop_id'
					),
					(
						'node',
						'dns_traffic_service.node_id = node.node_id'
					),
				],
				'dns_node': [
					(
						'node dns_node',
						'dns_traffic_service.node_id = dns_node.node_id'
					),
				],
				'dns_service': [
					(
						'cdn_service dns_service',
						'dns_traffic_service.service_id = dns_service.cdn_service_id'
					),
				],
				'node_service': [
					(
						'cdn_service node_service',
						'cdn_service_pops.service_id = node_service.cdn_service_id'
					),
					(
						'cdn_service_pops',
						'pop.pop_id = cdn_service_pops.pop_id'
					),
					(
						'pop',
						'node.pop_id = pop.pop_id'
					),
					(
						'node',
						'dns_traffic_service.node_id = node.node_id'
					),
				]
			}.get(table_alias, []):
				 if extra_table: tables.add(extra_table)
				 if extra_join:  joins.add(extra_join)
				
	join_filter = 'and %s' % ('\n       and '.join(joins)) if joins else ' '
	q = """
select timestampadd(SECOND,(second(dns_traffic_service.stat_time)+mod(minute(dns_traffic_service.stat_time),5)* 60)*-1,dns_traffic_service.stat_time) stat_time, %(func)s(%(value_field)s * %(factor)s) val %(extra_groups)s
  from %(tables)s
 where dns_traffic_service.stat_time >= '%(start_time)s' and dns_traffic_service.stat_time <= '%(end_time)s 23:59:59'
       %(join_filter)s
       %(extra_filters)s
 group by timestampadd(SECOND,(second(dns_traffic_service.stat_time)+mod(minute(dns_traffic_service.stat_time),5)* 60)*-1 ,dns_traffic_service.stat_time) %(extra_groups)s
 order by null %(extra_groups)s, timestampadd(SECOND,(second(dns_traffic_service.stat_time)+mod(minute(dns_traffic_service.stat_time),5)* 60)*-1,dns_traffic_service.stat_time)""" % {
			'tables':               ', '.join(tab for tab in tables),
			'func': func,
			'value_field':  value_field,
			'factor': factor,
			'start_time':   start_time.date(),
			'end_time':     end_time.date(),
			'join_filter':  join_filter,
			'extra_groups':(',%s' % ','.join(extra_groups) if extra_groups else ''),
			# Escape any %'s in extra_filter because the SQL backend will do another
			#   string interpolation on this query
			'extra_filters': 'and ' + ' and '.join(f.replace('%', '\%') for f in extra_filters) if extra_filters else '',
	}
	cursor.execute(q)
	rows = cursor.fetchall()
	if db:
		cursor.close()
		db.close()
	class RetClass:
		def __init__(self, stat_time):
	                self.stat_time = datetime(stat_time.year, stat_time.month, stat_time.day)
	ret = []
	pos = -1
	for row in rows:
		extra_groups_key = ""
		for i, extra_group in enumerate(extra_groups):
			extra_groups_key +=  ",%s"%row[i+2]
		if pos < 0 or ret[pos].stat_time.date() != row[0].date() or ret[pos].extra_groups_key != extra_groups_key:
			pos += 1
			rc = RetClass(row[0])
			[setattr(rc, 'e%d'%i, 0) for i in range(288)]
			[setattr(rc, extra_group, row[i+2]) for i, extra_group in enumerate(extra_groups)]
			rc.extra_groups_key = extra_groups_key
			ret.append(rc)
		if maximum:
			val =  min(maximum, float(row[1]) )
		else:
		
			val = float(row[1])
			
		setattr(ret[pos], 'e%d' %(row[0].hour*12+row[0].minute/5), val)
	return ret

def get_zeroes(current_day, start_time, end_time, start_epoch, end_epoch):
	if current_day > start_time:
		this_start_epoch = 0
	else:
		this_start_epoch = start_epoch
	if current_day < end_time.replace(hour=0, minute=0, second=0, microsecond=0):
		this_end_epoch = 287
	else:
		this_end_epoch = end_epoch
	return [0] * (this_end_epoch - this_start_epoch + 1)

def get_portion(row, start_time, end_time, start_epoch, end_epoch):
	if row.stat_time >= start_time:
		this_start_epoch = 0
	else:
		this_start_epoch = start_epoch
	if row.stat_time < end_time.replace(hour=0, minute=0, second=0, microsecond=0):
		this_end_epoch = 287
	else:
		this_end_epoch = end_epoch
	return [getattr(row, 'e%d'%i) for i in range(this_start_epoch, this_end_epoch+1)]

def calc_traffic_data_params(start_time, end_time, minute_interval=5, start_inclusive=True, end_inclusive=False):
	"""given a time range, this method returns the starting and ending epoch 
	for the range, as well as the overall size of the range in epochs.
	
	start_time and end_time are assumed to be in GMT.
	By default the start is inclusive and the end exclusive.  
	
	@param start_time:	datetime representing first epoch
	@param end_time:	datetime representing last epoch
	@param minute_interval:	[Optional] integer representing minutes between epoch (default is 5)
	@param start_inclusive: [Optional] boolean if start time is inclusive
	@param end_inclusive:	[Optional] boolean if end time is inclusive.
	
	@return abs (daily) start epoch, abs (daily) end epoch, # of epochs
	"""
	start_abs_epoch = abs_epoch(start_time, minute_interval) + (0 if start_inclusive else 1)
	end_abs_epoch = abs_epoch(end_time, minute_interval) + (0 if end_inclusive else -1)
	epoch_delta = end_abs_epoch - start_abs_epoch + 1
	return start_abs_epoch % (1440 / minute_interval), end_abs_epoch % (1440 / minute_interval), epoch_delta

def count_epochs(start_time, end_time, minute_interval=5, start_inclusive=True, end_inclusive=False):
	"""
	This returns the third parameter of calc_traffic_data_params and takes same input
	"""
	return calc_traffic_data_params(start_time, end_time, minute_interval=minute_interval, \
		 start_inclusive=start_inclusive, end_inclusive=end_inclusive)[2]

def epoch(time_thing):
	if type(time_thing) == datetime:
		timestamp = time.mktime(time_thing.timetuple())
	else:
		timestamp = time_thing
	return int(floor((timestamp % 86400) / 300))

def abs_epoch(time_thing, minute_interval=5):
	"""we define 'abs_epoch' here as a unit of time equal to the number of minute_interval periods
	since the beginning of unix time.
	
	@param minute_interval:	[Optional] integer of how many minutes an epoch is, default is 5
	"""
	if type(time_thing) == datetime:
		timestamp = time.mktime(time_thing.timetuple())
	else:
		timestamp = time_thing
	return int(timestamp / (60 * minute_interval))

def round_time_to_epoch(dt, minute_interval, start_of_time = None):
	"""
	@param dt:  A datetime instance
	@param minute_interval: how many minutes the interval is considered, this must be an integer
	@param start_of_time: [Optional] This is the first epoch, by default the first epoch is considered start of time...
	@return:        A datetime instance rounded down to the nearest interval
	"""
	#remove second and microsecond
	ret = dt.replace(second=0, microsecond=0)
	#start with time zone offset as this affects the timedelta calc.
	first_epoch = time.altzone
	if start_of_time:
		#use this as the beginning of time (since this also has altzone it does not need to worry about offset)
		first_epoch = time.mktime(start_of_time.replace(second = 0, microsecond=0).timetuple())
	#conver to timestamp, reset any timezone offsetget the mod of minute_interval (*60 since its in seconds) and subtract that from the time...
	ret  = ret - timedelta(minutes = (time.mktime(ret.timetuple()) - first_epoch) % (60*minute_interval) / 60)
	if start_of_time:
		#need to set seconds/microseconds equal to start since those are the beginning and we increment by minutes...
		ret = ret.replace(second=start_of_time.second, microsecond=start_of_time.microsecond)
	return ret

def bytes_last_hour(current_epoch):
	columns = ','.join(['sum(e%d)'%epoch for epoch in range(current_epoch-12, current_epoch)])
	cursor = connection.cursor()
	cursor.execute('''select %s
					    from traffic_bytes
					   where stat_time = date(now())
				    group by stat_time''' % columns)
	data = cursor.fetchone()
	if data:
		row = [int(n) for n in data]
		return sum(row)/float(len(row))
	return 0

def bytes_now(current_epoch):
	cursor = connection.cursor()
	cursor.execute('''select sum(e%d)
					  from traffic_bytes
					 where stat_time = date(now())
				  group by stat_time''' % current_epoch)
	data = cursor.fetchone()
	if data:
		return int(data[0])
	return 0

def check_for_drops():
	now = time.time()
	current_epoch = epoch(now)
	test_epoch = epoch(now-1200) 
	if test_epoch >= 12 and current_epoch > test_epoch: # avoid day boundary
		avg = bytes_last_hour(test_epoch)
		now = bytes_now(test_epoch)
		if avg == 0:
			return 0
		pct_diff = (avg - now) / float(avg) * 100
		return pct_diff
	else:
		return 0

class Series:
	"""
	A line of data in a Chart
	"""
	def __init__(self, split_by_key, data, total_factor, color="gray"):
		"""
		A time series of traffic data queried from the DB traffic tables
		@param split_by_key:	A string, the name of this series (e.g., 'Veoh'
						if splitting by customer)
		@param data:		A series of numbers
		@param total_factor:	Multiply self.sum() by this
		@param color:		[Optional] Color description for series, default is gray
		"""
		self.split_by_key	= split_by_key
		self.data		= data
		self.total_factor       = total_factor
		self.color 		= color
		# Lazy
		self._max = self._min = self._95th_percentile = self._sum = None
		
	def min(self):
		if self._min is None:
			self._min = min(self.data)
		return self._min
		
	def max(self):
		if self._max is None:
			self._max = max(self.data)
		return self._max
		
	def p95(self):
		"""
		The largest data value less than 5% of all values
		"""
		if self._95th_percentile is None:
			self._95th_percentile = sorted(self.data)[int(floor(len(self.data) * .95))]
		return self._95th_percentile
		
	def delta(self, past_epochs = 12, min_value = 10):
		"""
		The latest value vs. prior epochs
		"""
		current_epoch = self.data[-1]
		if current_epoch < min_value:
			#if below certain threshold consider to be irrevelant
			return 0
		current_avg = sum(self.data[past_epochs*-1-1:-1])/(past_epochs * 1.0)
		if current_avg == 0:
			return 0 #if no prior history hold off so a blip of 1 dosn't factor it to alert...
		return current_epoch/current_avg
		
	def _sum_uncoverted(self):
		"""
		Sum of the series, not yet multiplied by total_factor
		"""
		if self._sum is None:
			self._sum = sum(self.data)
		return self._sum
		
	def sum(self):
		return self._sum_uncoverted() * self.total_factor
		
	def avg(self):
		return self._sum_uncoverted() / len(self.data)
	def latest(self):
		return self.data[len(self.data)-1]
	def __repr__(self):
		return 'Series(%s)' % repr(self.split_by_key)
		
	def __eq__(self, other):
		return self.data == other.data and self.split_by_key == other.split_by_key
	def epochs(self):
		return len(self.data)
	def getEpoch(self, epoch):
		return self.data[epoch]
	def getEpochRangeSum(self, start_epoch, end_epoch):
		assert start_epoch >= 0 and end_epoch < len(self.data) and start_epoch < end_epoch
		return sum(self.data[start_epoch:end_epoch])


class Serieses:
	"""
	This class holds a set of series identified by a string.
	
	The purpose of this class is to have a way of creating several series from arbtrary data for a time range
	
	To initialize a start time, end time, and how many minutes an interval are.
	Then individual values can be added to the serieses and a list of series can be returned.
	
	Series will be ordered by the order they are created.  Series can be created in 3 ways:
		passing series_names into the init which will loop over this set adding the values
		calling create_series
		calling add_value for a name that does not yet exist
	"""
	def __init__(self, start_time, end_time, minute_interval, total_factor, series_names=None, end_inclusive=False, color_list=None, sumable=True):
		"""
		@param start_time: first epoch (included) 
		@param end_time:   last epoch (included) if not a valid minute_interval from start_time will be lowered to the next epoch
		@minute_interval:  time between each epoch
		@total_factor:     [Optional] value to multiply the total by default is 1
		@param series_names: [Optional]series to add
		@end_inclusive:    [Optional] If end point is included in epochs, default is False
		@color_list:       [OPtional] List of colors to use
		"""
		self.__start_time__ = start_time
		self.__minute_interval__ = minute_interval
		self.__total_factor__ = total_factor
		self.__end_time__ = round_time_to_epoch(end_time, minute_interval, self.__start_time__)
		self.__epochs__ = count_epochs(start_time, self.__end_time__, minute_interval, start_inclusive=True, end_inclusive=end_inclusive)
		self.__end_inclusive__ = end_inclusive
		self.__serieses__ = {}
		self.__sumable__ = sumable
		self.__color_list__ = color_list if color_list <> None else [
			'darkblue','darkred','darkgreen','darkorange','yellow','steelblue',
			'seagreen','slateblue','darkviolet','red','green','blue','cyan',
			'black','magenta']
		if series_names:
			for name in series_names:
				self.create_series(name)
	def get_start_epoch(self):
		return self.__start_time__
	def get_end_epoch(self):
		return self.__end_time__
	def get_epoch_in_minutes(self):
		return self.__minute_interval__
	def create_series(self, name):
		"""
		Add a series, this can be done here or automatically through add_value
		"""
		if not self.__serieses__.has_key(name):
			data = [0]*self.__epochs__
			self.__serieses__[name] = (len(self.__serieses__),Series(name, data, self.__total_factor__, color=self.__color_list__[len(self.__serieses__)%len(self.__color_list__)]))
			return True
		return False
	def add_value(self, series_name, time_of_value, value, add=False, strict_epochs = True):
		"""
		@param series_name: Unique name to identify series
		@param epoch: the datetime of the current epoch
		@param value: the value to set the current epoch
		@param add:   if True when epoch exists already it will add it to current value, if false it overwrites
		@param strict_epochs: if True it will ignore a value if the epoch is not a proper epoch
		
		@return True if it added the value, False if it did not (strict_epoch = True and epoch is invalid)
		"""
		epoch = round_time_to_epoch(time_of_value, self.__minute_interval__, self.__start_time__)
		if strict_epochs and epoch != time_of_value:
			return False
		#since [] is 0 based need to subtract one
		epoch_pos = count_epochs(self.__start_time__, epoch, self.__minute_interval__, start_inclusive = True, end_inclusive = True) -1
		self.create_series(series_name) #good to do blind as it just does if same as I would here
		if add:
			self.__serieses__[series_name][1].data[epoch_pos] += value
		else:
			self.__serieses__[series_name][1].data[epoch_pos] = value
		return True
	def add_from_iterable(self, iterable, split_by_field, date_field, value_field=None, add=False, strict_epochs=True):
		for i in iterable:
			date_value = i[date_field]
			if not isinstance(date_value,datetime) and isinstance(date_value,date):
				date_value = datetime.combine(date_value,datetime_time(0))
			self.add_value(i[split_by_field], date_value, i[value_field] if value_field else 1, add=add, strict_epochs=strict_epochs)
	def get_serieses_list(self):
		"""
		Returns all serieses in a list in the order they were created
		"""
		ret = [None]*len(self.__serieses__)
		for pos, ser in self.__serieses__.values():
			ret[pos] = ser
		return ret
	def __iter__(self):
		return self.get_serieses_list().__iter__()
	def is_sumable(self):
		return self.__sumable__
	def serieses_total(self):
		"""
		Returns the sum of all serieses merged as a list of epochs
		"""
		total = [0]*self.__epochs__
		if not self.is_sumable():
			return Series("Total", total, self.__total_factor__)
		for pos, ser in self.__serieses__.values():
			total = add_series(total, ser.data)
		return Series("Total", total, self.__total_factor__)
	def reorder(self, order_by):
		if order_by == None:
			return False
		order_list = []
		order_by = str(order_by)
		if order_by == 'split by field':
			for name in self.__serieses__.keys():
				order_list.append((name,name))
		elif hasattr(Series,order_by):
			for name, tuple in self.__serieses__.iteritems():
				func = getattr(tuple[1],order_by)
				order_list.append((func(),name))
		else:
			return False
		#now have each item in a sortable list...
		order_list.sort(reverse=True)
		counter = 0
		for value, name in order_list:
			series = self.__serieses__[name][1]
			series.color = self.__color_list__[counter%len(self.__color_list__)]
			self.__serieses__[name] = (counter, series)
			counter += 1
		return True
	def limit_serieses(self, limit_size, include_rest_in_other=False):
		"""
		If we ever have a name called Other we have issues...and will skip creating other series!
		"""
		other = [0]*self.__epochs__
		remove_serieses = []
		for name, tuple in self.__serieses__.iteritems():
			if tuple[0] < limit_size:
				#its good so skip removing it
				continue
			elif include_rest_in_other:
				other = add_series(other, tuple[1].data)
			#remove it...
			remove_serieses.append(name)
		for name in remove_serieses:
			self.__serieses__.pop(name)
		if include_rest_in_other and self.create_series('other') and other:
			self.__serieses__['other'][1].data = other


def processQuery(sql, mysql_params, processRow = lambda x: None, additionalArguments={}, returnRows=False, isFailOver2Default=False):
	"""
	Takes a query, database parameters and a function to handle row processing and execute the mysql query
	
	@param sql:          sql to execute
	@param mysql_params: dictionary of parameters to make MySQL connection
			expected keys: host, user, passwd, db
	@param processRow:   function to call with each row of data which is an array
	@param additionalArguments: dictionary to be passed to processRow as **kwargs 
	@param returnRows: Defaults to False, if True will not call processRow but instead return raw sql results
	"""
	assert callable(processRow)
	import MySQLdb
	isDefault = False

	if isFailOver2Default:
		try:
			db = MySQLdb.connect(**mysql_params)
			cursor = db.cursor()
		except:
			cursor = connection.cursor()
			isDefault = True
	else:
		db = MySQLdb.connect(**mysql_params)
		cursor = db.cursor()

	rows = cursor.execute(sql)
	if returnRows:
		ret = cursor.fetchall()
	else:
		ret = ""
		row = cursor.fetchone()
		while row:
			ret += "\n" + processRow(row, **additionalArguments)
			row = cursor.fetchone()
		ret = ret[1:]
	cursor.close()

	if not isDefault:
		db.close()

	return ret


if __name__ == '__main__':
	import doctest
	doctest.testmod()

