import base64
import sys
import cPickle as pickle
import zlib
from django.core.cache import cache
from httplib import HTTPSConnection
from django.utils import simplejson
from datetime import datetime
from ci.constants import PRISMAPI_SERVER, PRISMAPI_USER, PRISMAPI_PASS, \
                        SPECTRUMAPI_SERVER, SPECTRUMAPI_USER, SPECTRUMAPI_PASS
from ci.common.utils.supporttools import handleHttpGetConnection2

def get_db_operation_error_message(e):
    #TODO: report error to admin
    #https://dev.mysql.com/doc/refman/5.5/en/error-messages-server.html
    error_msg = 'Temporary DB operation error. Please try again. If error continues, please contact support center.'
    try:
        if e[0] == 1205:
            #transaction lock wait timeout
            error_msg = "Unable to comply your request due to timeout issue. Please try again."
        elif e[0] == 1290:
            error_msg = "Maintenance work is in progress. Unable to write."
    except:
        pass

    return error_msg

def get_contract_info(contract_no):
    ret = None
    uri = '/customer/contract/' + contract_no + '?user=' + PRISMAPI_USER  + '&pass=' + PRISMAPI_PASS
    resp = handleHttpGetConnection2(PRISMAPI_SERVER, uri)
    if not isinstance(resp,dict) or resp['status'] != 'OK':
        return ret
    else:
        return resp

def get_prism_cs_contact_list_or_compressed_cache(uri, cache_compressed_key):
    return get_prism_cs_contract_or_compressed_cache(uri,cache_compressed_key)

def get_prism_cs_contract_or_compressed_cache(uri, cache_compressed_key, apply_cache=True):
    is_cached_dict = False
    try:
        if apply_cache:
            compressed_resp = cache.get(cache_compressed_key)
            if compressed_resp:
                is_cached_dict = True
                return is_cached_dict, pickle.loads(zlib.decompress(compressed_resp))
        else:
            compressed_resp = None
        resp = handleHttpGetConnection2(PRISMAPI_SERVER, uri)
        if not isinstance(resp,dict) or resp['status'] != 'OK':
            compressed_resp = cache.get(cache_compressed_key+"_backup")
            if cache_compressed_key is None or compressed_resp is None:
                return is_cached_dict, resp
            else:
                is_cached_dict = True
                return is_cached_dict, pickle.loads(zlib.decompress(compressed_resp))
        else:
            return is_cached_dict, resp
    except Exception, e:
        if cache_compressed_key is None or compressed_resp is None:
            #logging error
            return is_cached_dict, {}
        else:
            is_cached_dict = True
            compressed_resp = cache.get(cache_compressed_key+"_backup")
            return is_cached_dict, pickle.loads(zlib.decompress(compressed_resp))

def get_cs_contract_info(contract_no=None, apply_cache=True):
    """
    cache prism api result, since memcached allow maximun 1 MB size, we need to compress api result
    cache with 2 hour TTL in order to deal with prism api maintenance or failure case, which
    use compression to deal with 1 MB size of cache limit
    {'00xxxxxx-0000xx':{"material_no": "1028","service_type_txt": "Local", "sales_org": "1000", "unit": "GB", 'item_id':'1', 'parent_item_id':'2'},
    '00xxxxxx-0000xx':{"material_no": "1028","service_type_txt": "Local", "sales_org": "1000", "unit": "GB",'item_id':'1', 'parent_item_id':'2'}}
    :param contract_no:
    :return:
    """
    if contract_no is not None:
        cache_key = "oui_contract_%s" % (contract_no)
        cache_compressed_key = None
        uri = '/customer/contract/cs?user=%s&pass=%s&contract_no=%s' % (PRISMAPI_USER, PRISMAPI_PASS, contract_no)
    else:
        cache_key = "oui_contracts_response"
        cache_compressed_key = "oui_contracts_response_compressed"
        uri = '/customer/contract/cs?user=%s&pass=%s' % (PRISMAPI_USER, PRISMAPI_PASS)
    if apply_cache:
        response_dict = cache.get(cache_key)
    else:
        uri = "%s&apply_cache=%s" % (uri, str(apply_cache))
        response_dict = None
    if response_dict is None:
        try:
            is_cached_dict, resp = get_prism_cs_contract_or_compressed_cache(uri, cache_compressed_key, apply_cache)
            if is_cached_dict:
                return resp
            else:
                response_dict = {}
                for response in resp.get('result'):
                    try:
                        cop_product_id = "%s-%s" % (response.get('contract_no').zfill(10), response.get('item_no').zfill(6))
                        response_dict.update({cop_product_id:
                                                  {'material_no':response.get('material_no'),
                                                   'material_desc':response.get('material_desc'),
                                                  'service_type': response.get('service_type'),
                                                  'service_type_txt': response.get('service_type_txt'),
                                                  'unit': response.get('unit'),
                                                  'sales_org': response.get('sales_org'),
                                                  'item_id':response.get('item_id',None),
                                                  'parent_item_id': response.get('parent_item_id', None)}})
                    except Exception,e:
                        pass
                cache.set(cache_key, response_dict, 60 * 60)
                if cache_compressed_key is not None:
                    cache.set(cache_compressed_key, zlib.compress(pickle.dumps(response_dict, pickle.HIGHEST_PROTOCOL),9), 60 * 60)
                    cache.set(cache_compressed_key+"_backup", zlib.compress(pickle.dumps(response_dict, pickle.HIGHEST_PROTOCOL),9), 60 * 180)
                return response_dict
        except:
            response_dict = {}

    return response_dict


def get_cs_contact_list(ckey=None):
    if ckey is not None:
        cache_key = "oui_contact_%s" % (ckey)
        cache_compressed_key = None
        uri = '/customer/cs/contactusers?user=%s&pass=%s&ckey=%s' % (PRISMAPI_USER, PRISMAPI_PASS, ckey)
    else:
        cache_key = "oui_contact_response"
        cache_compressed_key = "oui_contact_response_compressed"
        uri = '/customer/cs/contactusers?user=%s&pass=%s' % (PRISMAPI_USER, PRISMAPI_PASS)
    response_list = cache.get(cache_key)
    if response_list is None:
        is_cached_dict, resp = get_prism_cs_contact_list_or_compressed_cache(uri, cache_compressed_key)
        if is_cached_dict:
            return resp
        else:
            response_list = []
            for response in resp.get('result'):
                try:
                    contact_role = response.get('contact_role')
                    contact_item = {'ckey':response.get('ckey'),
                                              'account_no': response.get('account_no'),
                                              'email': response.get('email'),
                                              'contact_role': contact_role}
                    if contact_role.upper() == 'Z1' and contact_item not in response_list:
                        response_list.append(contact_item)
                except Exception,e:
                    pass
            cache.set(cache_key, response_list, 60 * 60)
            cache.set(cache_compressed_key, zlib.compress(pickle.dumps(response_list, pickle.HIGHEST_PROTOCOL),9), 60 * 120)
            cache.set(cache_compressed_key+"_backup", zlib.compress(pickle.dumps(response_list, pickle.HIGHEST_PROTOCOL),9), 60 * 180)
            return response_list

    return response_list

def log_service_security_cloud(pad_id, state_flag, security_service_id):
    post_param = {}
    post_param["service_id"] = str(security_service_id)
    post_param["state"] = str(state_flag)
    post_param["action_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    post_param["pad_id"] = str(pad_id)
    post_param = simplejson.dumps(post_param)

    base64string = base64.encodestring('%s:%s' % (SPECTRUMAPI_USER, SPECTRUMAPI_PASS)).replace('\n', '')
    headers = {"Authorization": "Basic %s"%base64string,
               "Content-Type": "application/json",
               "Accept-Charset":"utf-8"}

    resp = handleHttpPostConnectionWithHeader(SPECTRUMAPI_SERVER, '/api/csecurity/log_csec_service/', post_param, headers)
    if not isinstance(resp,dict):
        return {}
    else:
        return resp

def handleHttpPostConnectionWithHeader(domain, uri, postParams, headers):
    try:
        conn = HTTPSConnection(domain)
        conn.request("POST", uri, postParams, headers)
    except:
        return 600
    resp = conn.getresponse()
    resp_json = resp.read()
    resp_status = resp.status
    conn.close()
    if resp_status == 200:
        return simplejson.loads(resp_json)
    return resp_status