#-*- coding: utf-8 -*-
import gc
import hashlib
import re
import socket
import struct
import traceback
import urllib
import urllib2
import inspect
from datetime import timedelta
from itertools import izip
from django.conf import settings
from django.core.mail import send_mail
from django.core.serializers import serialize
from django.core.urlresolvers import reverse
from django.db import connection
from django.utils import translation, simplejson
from django.utils.translation import ugettext as _
from django.utils.functional import lazy
from django.utils.encoding import smart_str
from django.db import connections
from django.contrib.auth.models import AnonymousUser
from django.shortcuts import get_object_or_404
from ci.common.utils.misc import dict_diff

def get_current_obj_from_db(obj):
    if obj.pk:
        try:
            return get_object_or_404(obj.__class__, pk=obj.pk)
        except:
            return None
    else:
        return None

def get_current_obj_as_json_from_db(obj):
    """
    if obj contains m2m field, those values are need to evaluated earlier rather than compare time.
    :param obj:
    :return:
    """
    from ci.common.models.common import serialize_obj_to_json
    if obj.pk:
        try:
            obj = get_object_or_404(obj.__class__, pk=obj.pk)
            return serialize_obj_to_json(obj)
        except:
            return None
    else:
        return None


def get_request():
    """Walk up the stack, return the nearest first argument named "request"."""
    import inspect
    frame = None
    try:
        for f in inspect.stack()[1:]:
            frame = f[0]
            code = frame.f_code
            if code.co_varnames:
                if code.co_varnames[0] == "request":
                    return frame.f_locals['request']

                if code.co_varnames[:1] == ("request",):
                    return frame.f_locals["request"]
                elif code.co_varnames[:2] == ("self", "request",):
                    return frame.f_locals["request"]
    finally:
        del frame

def get_user_ip_from_request(request=None):
    user_ip = ''
    try:
        if request is None:
            request = get_request()
        xforwarded_ip = request.META.get('HTTP_X_FORWARDED_IP', None)
        remote_ipaddr = request.META.get('REMOTE_ADDR', None)
        user_ip = xforwarded_ip if xforwarded_ip else remote_ipaddr
    except:
        pass
    return user_ip

def get_username_from_context(user='', request=None):
    username = get_username_from_request(request)
    return username if username else user

def get_username_from_request(request=None):
    try:
        if request is None:
            request = get_request()
        if isinstance(request.user, AnonymousUser):
            return 'Anonymous User'
        return getattr(request.user, 'username', getattr(request.user, 'email', ''))
    except:
        return ''

def get_userinfo_as_tuple_from_context(request=None):
    app_name = settings.PROJECT_NAME if hasattr(settings,'PROJECT_NAME') and settings.PROJECT_NAME else ''
    try:
        if request is None:
            request = get_request()
        if request:
            user_id = getattr(request.user, 'pk', None) #anonymous user has no attribute 'pk'
            username = get_username_from_request(request)
            user_ip = get_user_ip_from_request(request)
            return user_id, username, user_ip, app_name
    except:
        pass
    return None, '', '', app_name

def get_userinfo_from_context(request=None):
    user_info = {}
    try:
        if request is None:
            request = get_request()
        user_id, username, user_ip, app_name = get_userinfo_as_tuple_from_context(request)
        hostname = request.META['HTTP_HOST'] if hasattr(request, 'META') and hasattr(request.META, 'HTTP_HOST') else ''
        pos = hostname.find(":")
        hostname = hostname[:pos] if pos > 0 else hostname
        post_message = get_parameter_info_from_request(request)
        request_path = '%s' % (request.META['PATH_INFO']) if hasattr(request, 'META') else ''
        request_message = '%s' % (request.META['QUERY_STRING']) if hasattr(request, 'META') else ''

        user_info.update({'user_id': user_id,
                          'username': username,
                          'user_ip':user_ip,
                          'app_name': app_name,
                          'host_name': hostname,
                          'post_message': post_message,
                          'request_path': request_path,
                          'request_message': request_message})
    except Exception,e:
        pass
    return user_info

def query_to_dicts(query_string, *query_args):
    """Run a simple query and produce a generator
    that returns the results as a bunch of dictionaries
    with keys for the column values selected.
    """

    cursor = connection.cursor()
    cursor.execute(query_string, query_args)
    col_names = [desc[0] for desc in cursor.description]
    while True:
        row = cursor.fetchone()
        if row is None:
            break
        row_dict = dict(izip(col_names, row))
        yield row_dict
    return

def get_parameter_info_from_request(request):
    """
    return post parameter values only as concatenated string
    :param request:
    :return:
    """
    postquery_parameters = []
    try:
        if request is None:
            request = get_request()
        if request.POST:
            for param, value in request.POST.iteritems():
                if param in ['password','pass']:
                    value = '*******'
                postquery_parameters.append('%s=%s,' % (param, value))
        return ''.join(postquery_parameters)
    except:
        # Fakerequest has no post attribute
        return ''

def get_message_list_from_caller(callerframes):
    message_list = []
    inspect_skipped = False
    for callerframe in callerframes:
        if not inspect_skipped:
            inspect_skipped = True
        else:
            frameobj, filename, line_no, func_name, contextlines, contextindex = callerframe
            message_list.append("%s within %s. line %d" % (filename,func_name,line_no))
            for iline, srcline in enumerate(contextlines or []):
                message_list.append("%3s : %s" % ('>>' if iline==contextindex else '',srcline.replace('\n','')))

    return message_list

def log_debug(message, request=None, context=None, sendemail=False):
    try:
        if not request:
            request = get_request()
    except:
        pass
    return _update_action_event(request, message, e=None, log_level=0, title=None, context=context, sendemail=sendemail)

def log_info(message, request=None):
    try:
        if not request:
            request = get_request()
    except:
        pass
    return _update_action_event(request, message, e=None, log_level=1)

def log_warn(message, request=None, e=None):
    try:
        if not request:
            request = get_request()
    except:
        pass
    return _update_action_event(request, message, e, log_level=2)

def log_error(message, e=None, request=None, title=None, context=None, sendemail=False):
    """
    log error. mail is not sent by default
    :param message: short description of error
    :param e: exception object
    :param request: request context
    :param title: title of email content
    :param context: parameter context
    :param sendemail: mail send flag
    :return:
    """
    try:
        if not request:
            request = get_request()

        if e is None:
            curframe = inspect.currentframe()
            callerframe = inspect.getouterframes(curframe,2)

            message_list = get_message_list_from_caller(callerframe)
            message = "%s \n\n%s\n\n" % (message, "\n".join(message_list))
        else:
            try:
                if hasattr(e, 'code') and e.code == 400: #do not send email when request is invalid
                    sendemail = False
            except:
                pass
    except:
        pass
    return _update_action_event(request, message, e, log_level=3, title=title, context=context, sendemail=sendemail)

def _update_action_event(request, message, e=None, log_level=1, title=None, context=None, sendemail=False):
    from ci.common.models.common import ActionEventLog
    try:
        if not title:
            title = message[:50] if len(message) > 50 else message

        if not request:
            request = get_request()

        if sendemail:
            _send_mail(request, title, message, e)

        error_message = traceback.format_exc(e) if e else ''
        error_message = error_message + getattr(e, 'message', '') if e else error_message

        return ActionEventLog.create_action_event(message=message,
                                                  error_message=error_message,
                                                  request=request,
                                                  context=context,
                                                  log_level=log_level)
    except Exception, e:
        pass
    return None

def _send_mail(request, title, message, e=None):
    pass
    #TODO: implement send mail when critical error occurs