from datetime import datetime
from django.http import HttpResponse, HttpResponseRedirect, HttpResponseForbidden
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.views import login as _login, logout as _logout
from django.contrib.auth.models import AnonymousUser
from django.contrib.auth.forms import AuthenticationForm
from django import forms
from django.utils.translation import ugettext_lazy as _

from ci.common.utils import render_response
from ci.common.utils.duo_web.duo import get_sig_request
from ci.constants import NO_LOGOUT_USERS, DEBUG, DUO_HOST, DUO_TIMEOUT, DUO_OTP_ENABLE
from ci.constants import IP_ACL_FILE, INTERNAL_IPS
from ci.common.utils import shared_constants
from ci.common.utils.util_common import get_userinfo_as_tuple_from_context
from django.core.cache import get_cache
from ci.common.decorators import throttle_classes
from ci.common.utils.throttling import UserRateThrottle, AnonRateThrottle, AnonymousUsernameThrottle
from ci.common.utils.util_common import log_error
from ci.common.models.common import UserActionHistory

redis_cache = get_cache('redis')

class AuthenticationFormLongUsername(AuthenticationForm):
    """
    Overrides django default base class for authenticating users. 
    Adding this allows us to change the max_length of username from 30 to 75 which we have in prod
    """
    username = forms.CharField(label=_("Username"), max_length=75)


def login(request, *args, **kwargs):
    """
    not easy to introspect retval which lazilly evaluated as HttpResponseRedirect object
    lets assume as success since it did not raise exception
    :param request:
    :param args:
    :param kwargs:
    :return:
    """
    retval = _login(request, *args, **kwargs)
    try:
        if isinstance(request.user, AnonymousUser):
            pass
        else:
            UserActionHistory.log_action(action_type=shared_constants.LOGIN, request=request)
    except:
        pass
    return retval

def logout(request, *args, **kwargs):
    try:
        if request.user.is_authenticated():
            UserActionHistory.log_action(action_type=shared_constants.LOGOUT, request=request)
    except:
        pass
    return _logout(request, *args, **kwargs)

@never_cache
@csrf_exempt
def login_with_timezone(request, *args, **kwargs):
    """set timezone offset (int, hours relative to GMT) when someone logs in, for use with traffic charts.
    expects a POST variable 'tzo', probably set from javascript in the login form.
    """
    if request.method == 'POST':
        try:
            request.session['tzo'] = float(request.POST.get('tzo',0))
        except ValueError:
            request.session['tzo'] = 0
        if request.POST['username'] in NO_LOGOUT_USERS:
            request.session.set_expiry(datetime(2030,01,01,0,0,0))

    kwargs['authentication_form'] = AuthenticationFormLongUsername

    return login(request, *args, **kwargs)

@throttle_classes([AnonymousUsernameThrottle])
@never_cache
@csrf_exempt
def login_with_timezone_acl(request, *args, **kwargs):
    """set timezone offset (int, hours relative to GMT) when someone logs in, for use with traffic charts.
    expects a POST variable 'tzo', probably set from javascript in the login form.
    """
    if request.method == 'POST':
        try:
            request.session['tzo'] = float(request.POST.get('tzo',0))
        except ValueError:
            request.session['tzo'] = 0
        if request.POST['username'] in NO_LOGOUT_USERS:
            request.session.set_expiry(datetime(2030,01,01,0,0,0))

    kwargs['authentication_form'] = AuthenticationFormLongUsername

    lines = open(IP_ACL_FILE,'r')

    acl_list = []
    for line in lines:
        stripped = line.strip()
        if not stripped.startswith('#') and not stripped == '':
            acl_list.append(stripped)

    remote_addr = request.META.get('HTTP_X_FORWARDED_FOR', request.META.get('HTTP_X_FORWARDED_IP', request.META.get('REMOTE_ADDR', None))).split(',')
    isFound = False
    for addr in remote_addr:
        addr = addr.strip()
        if is_authenticated_IP(addr,acl_list) or addr in INTERNAL_IPS:
            isFound = True

    if isFound == False:
        return HttpResponseForbidden('403 Error: Access Denied. Enlist your ip address into ACL to access OUI.')
    form = AuthenticationFormLongUsername(data=request.POST)

    if not DUO_OTP_ENABLE:
        return login(request, *args, **kwargs)
    if form.is_valid():
        request.session['duo_user_id'] = request.POST['username']
        request.session['duo_user_password'] = request.POST['password']
        request.session['duo_login_time'] = datetime.now()

        request.session['duo_next'] = request.POST['next']

        return render_response(request, 'duo-login.html', {
            'sig_request': get_sig_request(request.POST['username']),
            'duo_host': DUO_HOST,
            'duo_timeout': DUO_TIMEOUT,
            'duo_next': request.POST['next']
        })
    else:
        return login(request, *args, **kwargs)


def is_authenticated_IP(remote_addr,acl_list):
    from ci.common.utils import ipaddr
    
    for ip in acl_list:
        if ip == remote_addr:
            return True
        if ip.find('/') > 0:
            if ipaddr.IPv4Address(remote_addr) in ipaddr.IPv4Network(ip):
                return True
            #if addressInNetwork(remote_addr,ip): 
            #    return True    
    return False

@never_cache
def whoami(request):
    return HttpResponse(request.META['REMOTE_ADDR'])

@csrf_exempt
def redirect(request, target):
    return HttpResponseRedirect(target + ("?" + request.GET.urlencode() if request.GET else "" ))

def simple(request, template):
    return render_response(request, template)




