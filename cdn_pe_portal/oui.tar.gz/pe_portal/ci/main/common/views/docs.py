from ci.common.utils import render_response
from django.http import Http404
from django.template import TemplateDoesNotExist
from ci.common.models.customer import Customer, Product
from ci.common.models.site import Site

def rest_docs(request, category=None, object=None, action=None, action2=None, instance=None):
    content = None
    title = None
    if category != None and object != None and action != None:
        title = ('%s %s %s %s' %(category, object, action, action2 if action2 else "") ).strip()
        context = {
            'from':'oui',
            'view_private': True,
            'doc_file': 'docs/rest_%s.html' %(
                title.replace(' ','_')),
        }
        object = object.lower() if object else None
        action = action.lower() if action else None
        category = category.lower() if category else None
        if object == 'site':
            from ci.common.forms.site import get_EditPadForm
            context['padform'] = get_EditPadForm()
            context['req_opt'] = set((name if f.required == True and f.initial == None else None) for name,f in context['padform'].__class__.base_fields.items() )
        if object == 'production-site':
            from ci.common.forms.site import SiteForm
            context['siteform'] = SiteForm()
            context['req_opt'] = set((f.name if f.blank == False and f.editable == True and f.get_default() == None else None) for f in Site._meta.fields)
        elif object == 'ticket':
            from ci.common.forms.support import issueTypes
            context['issues'] = issueTypes
        elif object == 'customer':
            from ci.common.forms.customer import CustomerForm
            context['custform'] = CustomerForm()
            context['req_opt'] = set((f.name if f.blank == False and f.editable == True and f.get_default() == None else None) for f in Customer._meta.fields)
        elif object == 'product':
            from django import forms
            class ProductForm(forms.ModelForm):
                class Meta:
                    model = Product
            context['form_obj'] = ProductForm()
            if action == 'add':
                context['req_opt'] = set((f.name if f.blank == False and f.editable == True and f.get_default() in [None,''] else None) for f in Product._meta.fields)
            elif action == 'edit':
                context['skip_opt'] = ['customer']
        elif object == 'contract':
            from django import forms
            class ProductForm(forms.ModelForm):
                class Meta:
                    model = Product
            context['form_obj'] = ProductForm()
            if action == 'add':
                context['req_opt'] = set((f.name if f.blank == False and f.editable == True and f.get_default() in [None,''] else None) for f in Product._meta.fields)
            elif action == 'edit':
                context['skip_opt'] = ['customer']
        elif object == 'user':
            from ci.common.forms.user import UserForm, get_privilege_form
            context['userform'] = UserForm()
            context['privform'] = get_privilege_form(request)()
        try:
            resp = render_response(request, context['doc_file'], context)
            content = resp.content
        except TemplateDoesNotExist:
            raise Http404
    return render_response(request, 'rest_docs.html', {'content': content, 'title': title,'from': instance})

