from django import forms
#from django.contrib.auth.models import User
from ci.common.models import LongUser
from ci.common.utils import render_response
from ci.common.utils.duo_web.duo import duo_login
from ci.common.utils.mail import send_email
from ci.constants import NO_REPLY, NOC

def reset_password(request, template_name, domain):
    class UsernameForm(forms.Form):
        username = forms.CharField()
        def clean_username(self):
            username = self.cleaned_data['username']
            try:
                user = LongUser.objects.get(username=username)
            except LongUser.DoesNotExist:
                raise forms.ValidationError('The username "%s" is not in our system.' % username)
            return username
            
    if request.POST:
        form = UsernameForm(request.POST)
        if form.is_valid():
            long_user = LongUser.objects.get(username=form.cleaned_data['username'])
            if not long_user.is_migrated_to_AD():
                import md5, random
                from ci.constants import NO_REPLY
                random_pw = md5.md5(str(random.random())).hexdigest()[:10]
                long_user.set_password(random_pw)
                long_user.save()
                profile = long_user.get_profile()
                profile.password_reset = True
                profile.save()
                body = 'Your CDNetworks portal account credentials have been reset.\n\nPlease use credentials below.  You must change your password after logging in.\n\n' + \
                        'URL and credentials...\n-URL: %s%s%s\n-Username: %s\n-New Password: %s' % ('https://', domain, '/login/', user.username, random_pw)
                send_email(NO_REPLY, [long_user.email], '[CDNetworks] Password reset for %s' %(domain), body, reply_to=NO_REPLY)
    else:
        form = UsernameForm()
        
    return render_response(request, template_name, {'form':form})


def password_change(request, template_name):
    class ChangePasswordForm(forms.Form):
        old_password = forms.CharField(widget=forms.PasswordInput)
        new_password = forms.CharField(widget=forms.PasswordInput)
        repeat_new_password = forms.CharField(widget=forms.PasswordInput)
        def clean_old_password(self):
            user = LongUser.objects.get(pk=request.user.pk)
            if not user.check_password(self.cleaned_data['old_password']):
                raise forms.ValidationError('The supplied password is incorrect.')
            return self.cleaned_data['old_password']
        def clean(self):
            if 'new_password' not in self.cleaned_data or 'repeat_new_password' not in self.cleaned_data:
                return None
            if self.cleaned_data['new_password'] != self.cleaned_data['repeat_new_password']:
                raise forms.ValidationError('The new password entries do not match each other.')
            return self.cleaned_data

    long_user = LongUser.objects.get(pk=request.user.pk)
    password_form = None
    if request.POST:
        password_form = ChangePasswordForm(request.POST, auto_id='passwordform_%s')
        if password_form.is_valid():
            new_password = password_form.cleaned_data['new_password']
            long_user.set_password(new_password)
            long_user.save()
            profile = request.user.get_profile()
            profile.password_reset = False
            profile.save()
            request.user.message_set.create(message='Your changes have been saved.')
            password_form = None # empty the fields
            
    if not password_form:
        password_form = ChangePasswordForm(auto_id='passwordform_%s')

    is_ad_user = long_user.is_migrated_to_AD()
        
    context = {
        'is_ad_user': is_ad_user,
        'password_form': password_form
    }
    return render_response(request, template_name, context)

def staff_user_change_email(user_form, priv_form, object=None):
    """
        Create an email detailing changes made to a staff-type user. 
        @param user_form: a cleaned user model form, pre-save
        @param priv_form: a cleaned profile model form, pre-save
        @param object: The user object being changed. Optional. Is None is this is a new user created
        @return: None if email was successful. Otherwise a failure flag. 
    """
    email_subject = "[alert] OUI staff account %s" % ('updated' if object else 'created')
    email_body = "Username: %s\n\n" %( user_form.user.username if user_form.user else user_form.cleaned_data.get('username',''))
    info_diff, group_diff, perm_diff = [], [], []
    
    if object:
        for field in user_form.cleaned_data.keys():
            if field in object.__dict__.keys() and object.__dict__[field] != user_form.cleaned_data[field]:
                if field != 'password':
                    info_diff.append("%s was %s and is now %s" % (field, object.__dict__[field], user_form.cleaned_data[field]))  
        for field in priv_form.cleaned_data.keys():
            if field in object.userprofile.__dict__.keys() and object.userprofile.__dict__[field] != priv_form.cleaned_data[field]:
                info_diff.append("%s was %s and is now %s" % (field, object.userprofile.__dict__[field], priv_form.cleaned_data[field])) 
        if user_form.cleaned_data.get('groups'):
            for group in user_form.cleaned_data['groups']:
                if group not in object.groups.all():
                    group_diff.append("Added group  %s" % group.name)
            for group in object.groups.all():
                if group not in user_form.cleaned_data['groups']:
                    group_diff.append("Removed group membership: %s" % group.name)
        if user_form.cleaned_data.get('user_permissions'):
            for perm in user_form.cleaned_data['user_permissions']:
                if perm not in object.user_permissions.all():
                    perm_diff.append("Added permission: %s" % perm.name)
            for perm in object.user_permissions.all():
                if perm not in user_form.cleaned_data['user_permissions']:
                    perm_diff.append("Removed permission: %s" % perm.name)
        if info_diff:
            email_body+="The following user information has been changed: \n %s \n" % ("\n ".join(info_diff))
        if group_diff:
            email_body+="\nThe following group membership changes have been made: \n %s\n" % ("\n ".join(group_diff))
        if perm_diff:
            email_body+="\nThe following specific permissions have been changed: \n %s \n" % ("\n ".join(perm_diff))
        if not (info_diff or group_diff or perm_diff):
            return None
    elif not object:
        info_diff = 'New account super user status: %s' % ('True' if user_form.cleaned_data.get('is_superuser') else 'False')
        group_diff = [group.name for group in user_form.cleaned_data['groups']]
        perm_diff = [perm.name for perm in user_form.cleaned_data.get('user_permissions')] if user_form.cleaned_data.get('user_permissions') else []
        email_body += '\n %s' % info_diff
        email_body += "\n New user's group memberships:\n %s\n" % ("\n ".join(group_diff))
        email_body += "\n New user's individual permissions: \n %s\n" % ("\n ".join(perm_diff))
        
    try:
        send_email(NO_REPLY, NOC, email_subject, email_body)
        return None
    except Exception, e:
        return str(e)


def second_login(request):
    return duo_login(request)