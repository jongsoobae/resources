from subprocess import Popen, PIPE
import sys
import os
import re

# first we set defaults...

DEBUG = False
DJANGO_RUN_DEBUG = False
UI_HOST=''
MEDIA_ROOT = '/home/cdn/ui_upload/'
MEDIA_URL = '/upload/'

# Some local installations can't send email; if this variable is False then
# ci.common.utils.mail won't send email
SEND_EMAIL = True

#this is the cache_backend setting to allow for having prod different from local
CACHE_BACKEND = 'locmem:///'

# BASE_DIR: the directory in which the UI code resides defaults to /opt/cdn/ui/prod/ui,
# but can be overridden in one of the per-environment blocks that follow,
# or can be overridden within a single environment by setting an env variable
# callled DJANGO_BASE_DIR that the web server reads.
# this is really UI_BASE_DIR and not the overall base dir!
BASE_DIR = os.environ.get('DJANGO_BASE_DIR' + '/ui','/opt/cdn/ui/prod/ui')

IP_ACL_FILE = '/opt/cdn/ui/prod/ip_acl.txt'

INTERNAL_IPS = (
    '127.0.0.1',
    '::1',
)

TEMPLATE_DIRS = (os.path.join(BASE_DIR, 'templates'), os.path.join(BASE_DIR, 'ci/commom/templates/'))

NO_LOGOUT_USERS = ['dashboard', 'usnoc']

DATABASE_HOST = os.environ.get('DATABASE_HOST', 'cdb-local.cdnetworks.com')
DATABASE_USER = 'root'
DATABASE_PASSWORD = 'P@ssword!1'

#Specifc _HOST, _USER
REPORT_DATABASE_HOST = DATABASE_HOST
API_DATABASE_USER = 'api'
OUI_DATABASE_USER = 'oui'
CUI_DATABASE_USER = 'cui'
PUI_DATABASE_USER = 'pui'
REPORT_DATABASE_USER = 'report'

#Specific _PASSWORD need to be set per production environment
API_DATABASE_PASSWORD = OUI_DATABASE_PASSWORD = CUI_DATABASE_PASSWORD = PUI_DATABASE_PASSWORD = REPORT_DATABASE_PASSWORD = DATABASE_PASSWORD

DATABASE_PORT = '3306'

MySQL_AGGREGATE_DB = {
    'host':"localhost",
    'user':"bdbu",
    'passwd':"bdbu",
    'db':"backenddb",
    'charset': 'utf8',
    'init_command': "SET storage_engine=INNODB",
}

MySQL_CHARTRON_DB = {
    #'host': 'db2-icn59.panthercdc.com',
    'host': DATABASE_HOST,
    'user': DATABASE_USER,
    'passwd': DATABASE_PASSWORD,
    'db':"centraldb",
    'charset': 'utf8',
    'init_command': "SET storage_engine=INNODB",
}

MySQL_CHARTRON_DB_READONLY = {
    'host': 'cdb.panthercdn.com',
    'user': 'ops-ro',
    'passwd': 'wrap3hot4see!',
    'db':"centraldb",
    'charset': 'utf8',
    'init_command': "SET storage_engine=INNODB",
}

READONLY_DB = {
    'NAME': 'centraldb',
    'ENGINE':'django.db.backends.mysql',
    'HOST': 'localhost',
    'PORT': DATABASE_PORT,
    'USER': OUI_DATABASE_USER,
    'PASSWORD': OUI_DATABASE_PASSWORD
}

ONESTAT_DB = {
    'NAME': 'one_stat',
    'ENGINE':'django.db.backends.mysql',
    'HOST': 'ngp-one-stat-ro.cdngp.net',
    'PORT': DATABASE_PORT,
    'USER': 'engdev-ro',
    'PASSWORD': '3869@l838b6f26@3b#&6'
}

WPOSTAT_DB = {
    'NAME': 'db_wpo_stat',
    'ENGINE':'django.db.backends.mysql',
    'HOST': '61.110.248.102',
    'PORT': DATABASE_PORT,
    'USER': 'eng-dev',
    'PASSWORD': '4b@C0CC0CCl2l459lCCf'
}

FLUSH_DB = {
    'NAME': 'flushdb',
    'ENGINE':'django.db.backends.mysql',
    'HOST': '10.40.196.120',
    'PORT': DATABASE_PORT,
    'USER': 'root',
    'PASSWORD':'root'
}

BACKEND_API_SERVER = '10.40.196.169:8001'

SUPPORT_SERVER = 'localhost:8443'
AUTHENTICATION_KEY_VALUE = SUPPORT_AUTHENTICATION_KEY = 'SUPPORT1SERVER'

PRISMAPI_SERVER = 'prismapi-int.cdnetworks.com'
PRISMAPI_USER = 'ouiuser'
PRISMAPI_PASS = 'cdn!@admin'

SPECTRUMAPI_SERVER = 'spectrumapi-int.cdnetworks.com'
SPECTRUMAPI_USER = 'aurorauser'
SPECTRUMAPI_PASS = 'cdn!@admin'

CONFIG_API_HOST = "https://10.40.210.51:4443/"

AURORAAPI_SERVER = 'auroraapi-qa.cdnetworks.com'
AURORAAPI_USER = 'cop_to_aurora@cdnetworks.com'
AURORAAPI_PASS = 'auroraapi@cdnadmin'

CS_PASSWORD = "p@nther!"
CONFIG_API_HOST = "https://10.40.210.218:4443/"

OCSP_API_SERVERS = {1:'localhost:8890', 2:'localhost:8891',3:'localhost:8892',4:'localhost:8893', 5:'localhost:8890'}
OCSP_USER = 'test'
OCSP_PASS = 'test'

COP_API_SERVER = 'localhost:8895'
COP_USER = 'test'
COP_PASS = 'test'

TELCO_HOST_URL = 'https://telco-dev1.cdnetworks.com'

INTSCP_PUBKEY = 'scpinterface@cuiadmin'
SCPADMIN_PANTHER_ID = 'scpinterface@cuiadmin'
INTTELCO_PUBKEY = 'telcointerface@ouiadmin'
TELCOADMIN_PANTHER_ID = 'scpinterface@cuiadmin'

#used by sui
UI_AUTHENTICATION_KEY = 'restuser:password'

PHP5_EXECUTABLE = 'php'

JIRA_USER = 'support'
JIRA_PASSWORD = 'support'
JIRA_DEFAULT_ASSIGNEE = 'support'
JIRA_SE_PROJECT = 'SSE'
JIRA_SUPPORT_PROJECT = 'STS'
JIRA_SUPPORT_ID = '10093'
JIRA_DEFAULT_ISSUE_TYPE = '(Generic) Support Request'
JIRA_DEFAULT_ISSUE_ID = '17'
JIRA_SERVER_URL = 'http://172.16.0.130:8087/jira/rpc/xmlrpc'
JIRA_BROWSE_URL = 'http://172.16.0.130:8087/jira/browse/'
JIRA_SOAP_URL = 'http://toddlap:8080/rpc/soap/jirasoapservice-v2'
JIRA_TIMEOUT = 10


# this set of defaults works for local development if you have a catch-all address set up,
# and can be modified to suit your environment.
#
# note that if you add one here, you should also add it to EMAIL_ALIASES below so it can
# be automatically changed for different environments.
CONSTANT_EMAIL_FOR_DEBUG = 'jungho.park@cdnetworks.co.kr'

ALERT_ADDR = 'alert'
NOC_ADDR = NOC = CONSTANT_EMAIL_FOR_DEBUG
MAINTAINER = CONSTANT_EMAIL_FOR_DEBUG
PORTAL_INTEGRATION = CONSTANT_EMAIL_FOR_DEBUG
JIRA_MAINTAINER = CONSTANT_EMAIL_FOR_DEBUG
REPORT_ADDR = 'shared-report'
NO_REPLY = '"CDNetworks NOC" <portaladmin@cdnetworks.com>' #CONSTANT_EMAIL_FOR_DEBUG
CS_DEV = CONSTANT_EMAIL_FOR_DEBUG
OUI = CONSTANT_EMAIL_FOR_DEBUG
EXEC_ADDR = 'report-exec'
SALES_ADDR = 'sales-mgmt'
SALES_REP = 'report-sales'
INFO_ADDR = 'info'
BILLING = CONSTANT_EMAIL_FOR_DEBUG
SALES_EMEA = CONSTANT_EMAIL_FOR_DEBUG
BILLING_EMEA = CONSTANT_EMAIL_FOR_DEBUG
SALES_US = CONSTANT_EMAIL_FOR_DEBUG
SUPPORT_ADDR = CONSTANT_EMAIL_FOR_DEBUG
GLOBAL_NOC = CONSTANT_EMAIL_FOR_DEBUG
CONTACT_ADDR = 'contact'
CDNW_IMPL = CONSTANT_EMAIL_FOR_DEBUG
SALES_IMPL = CONSTANT_EMAIL_FOR_DEBUG
PUSHER_ADDR = 'pusher'
MONITOR_ADDR = 'monitor'
PR_ADDR = 'pr'
SJ_NOC = CONSTANT_EMAIL_FOR_DEBUG
KR_NOC = CONSTANT_EMAIL_FOR_DEBUG
APAC_SD = CONSTANT_EMAIL_FOR_DEBUG
US_SD = CONSTANT_EMAIL_FOR_DEBUG
ENG = 'eng'
TC_ADDR = CONSTANT_EMAIL_FOR_DEBUG
ACCT_MGT = CONSTANT_EMAIL_FOR_DEBUG

IMPL_OPS_CS_JP = CONSTANT_EMAIL_FOR_DEBUG
IMPL_OPS_CS_KR = CONSTANT_EMAIL_FOR_DEBUG
IMPL_NOC_JP = CONSTANT_EMAIL_FOR_DEBUG
IMPL_NOC_KR = CONSTANT_EMAIL_FOR_DEBUG
IMPL_SUP_SG = CONSTANT_EMAIL_FOR_DEBUG
IMPL_SUP_CN = CONSTANT_EMAIL_FOR_DEBUG

CUI_ROOT = "localhost/account"
OUI_ROOT = "localhost/oui3"
API_ROOT = "localhost"

# convenience list for changing all the email aliases,
# and shorter name for reference to current module
# example usage:
# for email in EMAIL_ALIASES:
#	 setattr(module, email, transform(getattr(module, email)))
#
EMAIL_ALERTS = ['eng-ui@cdnetworks.com']
EMAIL_DOMAIN = "pantherexpress.net"

EMAIL_ALIASES = ('ALERT_ADDR', 'JIRA_MAINTAINER', 'MONITOR_ADDR',
	'REPORT_ADDR', 'INFO_ADDR', 'CONTACT_ADDR', 'PUSHER_ADDR',
	'EXEC_ADDR', 'PR_ADDR', 'SALES_ADDR', 'ENG', 'SALES_REP')
module = sys.modules[__name__]

# and then we override them below for specific environments.
# we decide which environment-specific constants to use by looking at the hostname.
hostname = Popen('/bin/hostname', stdout=PIPE).stdout.read()

# duo otp settings.
DUO_IKEY = 'DIXR6OKMFOUR85Y18QV0'
DUO_SKEY = 'RquMkcQqYNQXhcUYeRQTB8LBybJBjdGsxY07sazy'
DUO_AKEY = '0161d8a8f3b4e97ad871029ad9cbea37d5d4e60a'
DUO_HOST = 'duosecurity.cdnetworks.com'
DUO_TIMEOUT = 300
DUO_OTP_ENABLE = True

AUTH_CROWD_STAFF_GROUP = 'staff'
AUTH_CROWD_SUPERUSER_GROUP = 'superuser'
AUTH_CROWD_APPLICATION_USER = 'kms-ad'
AUTH_CROWD_APPLICATION_PASSWORD = 'cdnadmin'
AUTH_CROWD_TIMOUT = 10
AUTH_CROWD_SERVER_URI = 'https://prismapi.cdnetworks.com/'

SESSION_TIMEOUT_ENABLED = True
SESSION_TIMEOUT_DELAY = 30 * 60 # sec. minimum value should be at least 60 sec which is health check interval at browser.

PASSWORD_HASHERS = (
    'ci.common.contrib.crypt.hashers.PBKDF2PasswordHasher',
    'ci.common.contrib.crypt.hashers.PBKDF2SHA1PasswordHasher',
    'ci.common.contrib.crypt.hashers.BCryptPasswordHasher',
    'ci.common.contrib.crypt.hashers.SHA1PasswordHasher',
    'ci.common.contrib.crypt.hashers.MD5PasswordHasher',
    'ci.common.contrib.crypt.hashers.CryptPasswordHasher',
)

REDIS_SENTINEL_LOCATIONS =  [
            "mymaster://api1.p59-icn.cdngp.net:26379",
            "mymaster://api2.p59-icn.cdngp.net:26379",
            "mymaster://ui2.p59-icn.cdngp.net:26379",
        ]

CACHE_BACKEND = "django.core.cache.backends.memcached.MemcachedCache"
CACHE_LOCATIONS = [
            '127.0.0.1:11211',
        ]

ALLOW_CUI_URLS = ['pantherportalaurora.cdnetworks.com', 'pantherportalaurora-stage.cdnetworks.com',
                  'pantherportalaurora-dev.cdnetworks.com:8089', 'pantherportalaurora-qa.cdnetworks.com',
                  'pantherportalaurora-ha.cdnetworks.com']

TEST_PADS = ['live_ca_self_edit-test01.cdnetworks.net','live_ca_self_edit-test02.cdnetworks.net',
          'live_ca_request_edit_test01.cdnetworks.net','live_ca_request_edit_test02.cdnetworks.net'] #[AURORAUI-2801]

SUPPORT_CENTER = \
"""(US Toll Free) +1-877-937-4236 support@cdnetworks.com
(UK/EMEA) +44-203-514-7501 support@cdnetworks.com
(KR) +82-2-3441-0456 cdnsupport@cdnetworks.co.kr
(JP) +81-3-5909-3329 custom@cdnetworks.co.jp
(CN) 400-661-9520 cnsupport@txnetworks.cn"""
# production -- cdc
if 'cdc.panthercdn' in hostname or 'jfk-tel-u4' in hostname:
    ENVIRONMENT = 'prod'
    DEBUG = False

    DATABASE_USER = 'cdc'
    DATABASE_HOST = 'cdb.panthercdn.com'
    DATABASE_PASSWORD = 'Naf!+#beBR8MeS=aSeTu'

    API_ROOT = 'pantherapi.cdnetworks.com'
    CUI_ROOT = "pantherportal.cdnetworks.com"
    OUI_ROOT = "pantheroui.cdnetworks.com"
# production -- ui
elif 'ui.panthercdn' in hostname or re.search('^ui.*\.panthercdc.com$', hostname) or re.search('^ui.*\.cdngp.net$',hostname):
    ENVIRONMENT = 'prod'
    UI_HOST = ''
    DEBUG = False
    DJANGO_RUN_DEBUG = False

    #CACHE_BACKEND = 'memcached://127.0.0.1:11211/'

    KEYSTORE_HOST = 'ks.panthercdc.com'
    KEYSTORE_USER = 'ks'
    KEYSTORE_KEY_PRIV = '/var/www/.ssh/ks_prod_rsa1'
    KEYSTORE_PORT = '822'
    KEYSTORE_PATH_PREFIX = ''
    TRUSTED_CERTS_PATH = '/opt/cdn/certs/'

    DATABASE_HOST = 'cdb.panthercdn.com'
    REPORT_DATABASE_HOST = 'db-readonly.panthercdc.com'

    API_DATABASE_PASSWORD = 'Owl}hang40beAks'
    CUI_DATABASE_PASSWORD = 'GOt5mON#DAy'
    OUI_DATABASE_PASSWORD = 'kagu53trIps='
    PUI_DATABASE_PASSWORD = 'tAnKa10odES;'
    REPORT_DATABASE_PASSWORD = 'soCK;ant72lyrEs'


    SUPPORT_SERVER = 'support-tools.panthercdn.com'
    SUPPORT_AUTHENTICATION_KEY = 'P3MZwP1AQLwIrFSIhxfP0YRSqUW9mEX3'

    OCSP_API_SERVERS = {
        1:"openapi.us.cdnetworks.com",
        2:None, #"openapi.kr.cdnetworks.com",
        3:None, #"openapi.txnetworks.cn",
        4:None, #"openapi.jp.cdnetworks.com",
        5:"openapi.us.cdnetworks.com",
    }

    COP_API_SERVER = 'cop2.cdnetworks.com'
    COP_USER = 'panthernoc@cdnetworks.com'
    COP_PASS = 'ofkk238i'

    PRISMAPI_SERVER = 'prismapi.cdnetworks.com'
    PRISMAPI_USER = 'ouiuser'
    PRISMAPI_PASS = 'cdn!@admin'

    SPECTRUMAPI_SERVER = 'spectrumapi.cdnetworks.com'
    SPECTRUMAPI_USER = 'aurorauser'
    SPECTRUMAPI_PASS = 'cdn!@admin'

    AURORAAPI_SERVER = 'auroraapi.cdnetworks.com'
    AURORAAPI_USER = 'cop_to_aurora@cdnetworks.com'
    AURORAAPI_PASS = 'auroraapi@cdnadmin'

    CONFIG_API_HOST = "https://configapi-be.cdngp.net"
    TELCO_HOST_URL = 'https://partner.cdnetworks.com'

    BACKEND_API_SERVER = 'flushapi-be.cdngp.net'

    OCSP_USER = 'panthernoc@cdnetworks.com'
    OCSP_PASS = 'ofkk238i'

    MySQL_AGGREGATE_DB = {
        'host':"agg-db.panthercdn.com",
        'user':"ui",
        'passwd':"stock1photo2world=bad@",
        'db':"aggregatedb",
        'charset': 'utf8',
        'init_command': "SET storage_engine=INNODB",
    }
    MySQL_CHARTRON_DB = {
        'host': 'db-chart.panthercdc.com',
        'user': 'chart',
        'passwd': 'ace32FoxEd*',
        'db':"centraldb",
        'charset': 'utf8',
        'init_command': "SET storage_engine=INNODB",
    }
    READONLY_DB = {
        'NAME': 'centraldb',
        'ENGINE':'django.db.backends.mysql',
        'HOST': 'db-chart.panthercdc.com',
        'PORT': DATABASE_PORT,
        'USER': 'chart',
        'PASSWORD': 'ace32FoxEd*'
    }
    ONESTAT_DB = {
        'NAME': 'one_stat',
        'ENGINE':'django.db.backends.mysql',
        'HOST': 'ngp-one-stat-ro.cdngp.net',
        'PORT': DATABASE_PORT,
        'USER': 'oui-ro',
        'PASSWORD': 'EfDl20&C86#20fD2@C5@'
    }
    WPOSTAT_DB = {
        'NAME': 'db_wpo_stat',
        'ENGINE':'django.db.backends.mysql',
        'HOST': 'ngp-one-stat-ro.cdngp.net',
        'PORT': DATABASE_PORT,
        'USER': 'oui-ro',
        'PASSWORD': 'EfDl20&C86#20fD2@C5@'
    }
    FLUSH_DB = {
        'NAME': 'flushdb',
        'ENGINE':'django.db.backends.mysql',
        'HOST': 'flushdb-be.cdngp.net',
        'PORT': DATABASE_PORT,
        'USER': 'oui-dashboard',
        'PASSWORD':'Yl2@36#l&DllDb2b32#0'
    }

    API_ROOT = 'pantherapi.cdnetworks.com'
    OUI_ROOT = 'pantheroui.cdnetworks.com'
    CUI_ROOT = 'pantherportal.cdnetworks.com'

    ALERT_ADDR = 'alert'
    NOC_ADDR = NOC = '"CDNetworks NOC" <panthernoc@cdnetworks.com>'
    MAINTAINER = 'eng-ui@cdnetworks.com'
    PORTAL_INTEGRATION = 'eng-portal-integration@cdnetworks.com'
    JIRA_MAINTAINER = 'panthernoc@cdnetworks.com'
    REPORT_ADDR = 'shared-report'
    NO_REPLY = '"CDNetworks NOC" <portaladmin@cdnetworks.com>' #("CDNetworks",'noreply')
    CS_DEV = 'eng-cs@cdneteworks.com'
    OUI = '"PantherOUI" <noreply@cdnetworks.com>' #("PantherOUI",'noreply')
    EXEC_ADDR = 'report-exec'
    SALES_ADDR = 'sales-mgmt'
    SALES_REP = 'report-sales'
    INFO_ADDR = 'info'
    BILLING = 'billing@cdnetworks.com'
    SALES_EMEA = 'emea@cdnetworks.com'
    BILLING_EMEA = '"CDNetworks Billing" <emea_billing@cdnetworks.com>'
    SALES_US = 'ussales@cdnetworks.com'
    SUPPORT_ADDR = 'support@cdnetworks.com'
    GLOBAL_NOC = 'alert-net@cdnetworks.com'
    CONTACT_ADDR = 'contact'
    CDNW_IMPL = 'support@cdnetworks.com'
    SALES_IMPL = 'implementation-sales@cdnetworks.com'
    PUSHER_ADDR = 'pusher'
    MONITOR_ADDR = 'monitor'
    PR_ADDR = 'pr'
    SJ_NOC = "noc_staff@cdnetworks.com"
    KR_NOC = "noc@cdnetworks.co.kr"
    APAC_SD = "apac-sd@cdnetworks.co.kr"
    US_SD = "ops-sd@cdnetworks.com"
    ENG = 'eng'
    TC_ADDR = "tc@cdnetworks.com"
    ACCT_MGT = 'csm_internal@cdnetworks.com'

    IMPL_OPS_CS_JP = 'ops-cs-jp@cdnetworks.com'
    IMPL_OPS_CS_KR = 'ops-sd-kr2@cdnetworks.co.kr'
    IMPL_NOC_JP = 'noc-jp@cdnetworks.co.jp'
    IMPL_NOC_KR = 'noc-kr@cdnetworks.com'
    IMPL_SUP_SG = 'tech-support_sg@cdnetworks.com'
    IMPL_SUP_CN = 'cnsupport@txnetworks.cn'

# production -- sui
elif re.search('^sui.*\.panthercdc.com$',hostname) or 'support-tools.panthercdn' in hostname or 'jfk-lv3-u1' in hostname:
    ENVIRONMENT = 'prod'
    DEBUG = False

    DATABASE_PASSWORD = 'wet8cab9cone=nyc^'
    DATABASE_HOST = 'sui-db.panthercdc.com'

    AUTHENTICATION_KEY_VALUE = 'P3MZwP1AQLwIrFSIhxfP0YRSqUW9mEX3'

    UI_AUTHENTICATION_KEY = 'cse@pantherexpress.net:p@nth3r'
    API_ROOT = 'pantherapi.cdnetworks.com'
    OUI_ROOT = 'pantheroui.cdnetworks.com'
    CUI_ROOT = 'pantherportal.cdnetworks.com'

    BASE_DIR = os.environ.get('DJANGO_BASE_DIR','/home/cdn')
    TEMPLATE_DIRS = (os.path.join(BASE_DIR, 'ci/commom/templates/'))
# production monitor nodes
elif re.search('^mon.*\.panthercdc.com$',hostname):
    ENVIRONMENT = 'prod'
    DEBUG = False

    DATABASE_USER = 'nodemon'
    DATABASE_HOST = 'cdb.panthercdn.com'
    DATABASE_PASSWORD = 'DOt95Pub$rays'

    API_ROOT = 'pantherapi.cdnetworks.com'
    CUI_ROOT = "pantherportal.cdnetworks.com"
    OUI_ROOT = "pantheroui.cdnetworks.com"

#nodedata user for url_count_handler
elif re.search('^cdc.*\.panthercdc.com$',hostname):
    ENVIRONMENT='prod'
    DEBUG = False
    DATABASE_HOST = 'cdb.panthercdn.com'
    DATABASE_USER = 'nodedata'
    DATABASE_PASSWORD = 'yid=Furs22pURe'
#qa environment
elif 'pantherqa.com' in hostname:
    EMAIL_ALERTS = ['eng-cloud@cdnetworks.com']
    COP_API_SERVER = 'devcop2.cdnetworks.com'
    COP_USER = 'panthernoc@cdnetworks.com'
    COP_PASS = 'ofkk238i'
    OCSP_API_SERVERS = {
        1:"testapi.us.cdnetworks.com",
        2:None, #"openapi.kr.cdnetworks.com",
        3:None, #"openapi.txnetworks.cn",
        4:None, #"openapi.jp.cdnetworks.com",
        5:"testapi.us.cdnetworks.com",
        }

    ENVIRONMENT = 'qa'
    EMAIL_DOMAIN = "localhost"
    KEYSTORE_HOST = 'ks.pantherqa.com'
    KEYSTORE_PORT = '722'
    KEYSTORE_USER = 'cdn'
    KEYSTORE_PATH_PREFIX = '/var/cdn/ks/'
    TRUSTED_CERTS_PATH = '/opt/cdn/certs/'
    KEYSTORE_KEY_PRIV = '/var/www/.ssh/cdn_qa_rsa5'
# localhost environment for UI developers
    REDIS_SENTINEL_LOCATIONS =  [
            "mymaster://127.0.0.1:26379",
            "mymaster://localhost:26379",
        ]
else:
    EMAIL_ALERTS = ['eng-cloud@cdnetworks.com']
    ENVIRONMENT = 'local'
    EMAIL_DOMAIN = "localhost"
    KEYSTORE_HOST = 'ks.pantherqa.com'
    KEYSTORE_PORT = '722'
    KEYSTORE_USER = 'cdn'
    KEYSTORE_PATH_PREFIX = '/var/cdn/ks/'
    TRUSTED_CERTS_PATH = '/opt/cdn/certs/'
    KEYSTORE_KEY_PRIV = '/Library/WebServer/.ssh/cdn_qa_rsa5'

    COP_API_SERVER = 'devcop2.cdnetworks.com'
    COP_USER = 'panthernoc@cdnetworks.com'
    COP_PASS = 'ofkk238i'

    OCSP_API_SERVERS = ''
    API_DATABASE_USER = OUI_DATABASE_USER = CUI_DATABASE_USER = PUI_DATABASE_USER = REPORT_USER = DATABASE_USER
    REDIS_SENTINEL_LOCATIONS =  [
            "mymaster://localhost:6379",
            "mymaster://127.0.0.1:6379"
        ]


for email in EMAIL_ALIASES:
    attribute = getattr(module, email)
    if isinstance(attribute, tuple):
        setattr(module, email,'"%s" <%s@%s>' %(attribute[0],attribute[1], EMAIL_DOMAIN))
    else:
        setattr(module, email, '%s@%s' %(attribute, EMAIL_DOMAIN))

HTTP_RESPONSE_CODES = {
    100: "Continue",
    101: "Switching Protocols",
    200: "OK",
    201: "Created",
    202: "Accepted",
    203: "Non-Authoritative Information",
    204: "No Content",
    205: "Reset Content",
    206: "Partial Content",
    300: "Multiple Choices",
    301: "Moved Permanently",
    302: "Found",
    303: "See Other",
    304: "Not Modified",
    305: "Use Proxy",
    307: "Temporary Redirect",
    400: "Bad Request",
    401: "Unauthorized",
    402: "Payment Required",
    403: "Forbidden",
    404: "Not Found",
    405: "Method Not Allowed",
    406: "Not Acceptable",
    407: "Proxy Authentication Required",
    408: "Request Timeout",
    409: "Conflict",
    410: "Gone",
    411: "Length Required",
    412: "Precondition Failed",
    413: "Request Entity Too Large",
    414: "Request URI Too Large",
    415: "Unsupported Media Type",
    416: "Requested Range Not Satisfiable",
    417: "Expectation Failed",
    500: "Internal Server Error",
    501: "Not Implemented",
    502: "Bad Gateway",
    503: "Service Unavailable",
    504: "Gateway Timeout",
    505: "HTTP Version Not Supported"
}
OPENSSL_VERIFY_CODES={
    1:' unable to get local issuer certificate',
    2:' unable to get issuer certificate',
    3: 'unable to get certificate CRL',
    4: "unable to decrypt certificate's signature",
    5: "unable to decrypt CRL's signature",
    6: 'unable to decode issuer public key',
    7: 'certificate signature failure',
    8: 'CRL signature failure',
    9: 'certificate is not yet valid',
    10: 'certificate has expired',
    11: 'CRL is not yet valid',
    12: 'CRL has expired',
    13:"format error in certificate's notBefore field",
    14: "format error in certificate's notAfter field",
    15:"format error in CRL's lastUpdate field",
    16: "format error in CRL's nextUpdate field",
    17:" out of memory",
    18:" self signed certificate",
    19:" self signed certificate in certificate chain",
    20:" unable to get local issuer certificate",
    21:" unable to verify the first certificate",
    22:" certificate chain too long",
    23:" certificate revoked",
    24:" invalid CA certificate",
    25:" path length constraint exceeded",
    26:" unsupported certificate purpose",
    27:" certificate not trusted",
    28:"certificate rejected",
    29:" subject issuer mismatch",
    30:" authority and subject key identifier mismatch",
    31:" authority and issuer serial number mismatch",
    32:"key usage does not include certificate signing",
    50:" application verification failure"
}

CA_MATERIAL = [1003, 1006, 1028, 1029, 1133]
CA_SSL_MATERIAL = 1291

CA_CLOUD_SECURITY_MATERIAL = 1294
DWA_MATERIAL = 1115
DWA_SSL_MATERIAL = 1292
DWA_CLOUD_SECURITY_MATERIAL = 1295
DWA_MATERIALS = [DWA_MATERIAL, DWA_SSL_MATERIAL, DWA_CLOUD_SECURITY_MATERIAL]
MA_MATERIALS = [1189, 1195, 1196, 1203, 1204]
MH_MATERIALS = [1180]
MM_MATERIALS = [1104, 1105]
EAS_MATERIALS = [1323, 1324]

SSL_STAGING_EDGE_CLEANUP_INTERVAL = 6  # hour
PE2NGP_SYNC_MINUTES_THRESHOLD = 5 #minutes
