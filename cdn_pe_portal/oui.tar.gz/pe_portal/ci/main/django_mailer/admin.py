from django.contrib import admin
from ci.django_mailer import models


class Message(admin.ModelAdmin):
    list_display = ('id', 'actor', 'to_address', 'subject', 'event_id','parent_id', 'date_created')
    list_filter = ('date_created',)
    search_fields = ('to_address', 'subject', 'from_address', 'event_id', 'encoded_message')
    date_hierarchy = 'date_created'
    ordering = ('-date_created',)



class MessageRelatedModelAdmin(admin.ModelAdmin):
    list_select_related = True

    def message__actor(self, obj):
        return obj.message.actor
    message__actor.admin_order_field = 'message__actor'

    def message__to_address(self, obj):
        return obj.message.to_address
    message__to_address.admin_order_field = 'message__to_address'

    def message__subject(self, obj):
        return obj.message.subject
    message__subject.admin_order_field = 'message__subject'

    def message__parent_id(self, obj):
        return obj.message.parent_id
    message__parent_id.admin_order_field = 'message__parent_id'

    def message__event_id(self, obj):
        return obj.message.event_id
    message__event_id.admin_order_field = 'message__event_id'

    def message__date_created(self, obj):
        return obj.message.date_created
    message__date_created.admin_order_field = 'message__date_created'


class QueuedMessage(MessageRelatedModelAdmin):
    def not_deferred(self, obj):
        return not obj.deferred
    not_deferred.boolean = True
    not_deferred.admin_order_field = 'deferred'

    list_display = ('id', 'message__actor', 'message__to_address', 'message__subject', 'message__parent_id',
                    'message__date_created', 'priority', 'not_deferred')


class Blacklist(admin.ModelAdmin):
    list_display = ('email', 'date_added')

class Subscriber(admin.ModelAdmin):
    list_display = ('event_id','corp_code','email', 'date_added')

class Event(admin.ModelAdmin):
    list_display = ('event_id', 'event_name','description','date_created')

class Log(MessageRelatedModelAdmin):
    list_display = ('id', 'result', 'message__actor', 'message__to_address', 'message__subject','message__event_id',
                    'date')
    search_fields = ('result','message__subject','message__event_id')
    list_filter = ('result',)
    list_display_links = ('id', 'result')


admin.site.register(models.Message, Message)
admin.site.register(models.QueuedMessage, QueuedMessage)
admin.site.register(models.Blacklist, Blacklist)
admin.site.register(models.Log, Log)
admin.site.register(models.Subscriber, Subscriber)
admin.site.register(models.Event, Event)

