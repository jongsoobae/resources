"""
The "engine room" of django mailer.

Methods here actually handle the sending of queued messages.

"""
from django.utils.encoding import smart_str
from ci.django_mailer import constants, models, settings
from ci.django_mailer.management.commands import create_handler
from ci.django_mailer.lockfile import FileLock, AlreadyLocked, LockTimeout
from socket import error as SocketError
import logging
import os
import smtplib
import tempfile
import time

if constants.EMAIL_BACKEND_SUPPORT:
    from django.core.mail import get_connection
else:
    from django.core.mail import SMTPConnection as get_connection

LOCK_PATH = settings.LOCK_PATH or os.path.join(tempfile.gettempdir(),
                                               'send_mail')

logger = logging.getLogger('django_mailer.engine')
handler = create_handler('2')
logger.addHandler(handler)

def _message_queue(block_size):
    """
    A generator which iterates queued messages in blocks so that new
    prioritised messages can be inserted during iteration of a large number of
    queued messages.

    To avoid an infinite loop, yielded messages *must* be deleted or deferred.

    """
    def get_block():
        queue = models.QueuedMessage.objects.non_deferred().select_related()
        if block_size:
            queue = queue[:block_size]
        return queue
    queue = get_block()
    while queue:
        for message in queue:
            yield message
        queue = get_block()

def get_updated_encoded_message(previous_encoded_message, recipients=[]):
    """
    'To:' section of email message need to be replaced by new recipients.
    Message is text encoded and saved to db table already.
    Message example:
    Content-Type: text/plain; charset="utf-8"
    MIME-Version: 1.0
    Content-Transfer-Encoding: quoted-printable
    Subject: PAD implementation request for CDNetworks Cloud Portal Test:
     request_implement.test.cdn.com
    From: "CDNetworks NOC" <portaladmin@cdnetworks.com>
    To: "CDNetworks NOC" <portaladmin@cdnetworks.com>,
        injune.hwang@cdnetworks.co.kr
    Date: Wed, 30 Nov 2016 01:34:02 -0000
    Message-ID: <20161130013402.11362.49302@ui1-icn59.panthercdc.com>

    PAD implementation request for CDNetworks Cloud Portal Test:
    :param previous_encoded_message:
    :param recipients:
    :return:
    """
    replace_message = u'To: %s' % (',\n\t'.join(recipients))
    previous_encoded_message = previous_encoded_message.replace("\r\n","\n")

    message_list = previous_encoded_message.split("\n")
    replaced_message_list = []

    message_started = False
    message_ended = False
    message_replaced = False
    for message in message_list:
        if not message_started and message.startswith('To:'):
            message_started = True

        if not message.startswith('To:') and ':' in message:
            if message_started:
                message_ended = True

        if not message_started:
            replaced_message_list.append(message)
        elif message_started and message_ended:
            if not message_replaced:
                replaced_message_list.append(replace_message)
                message_replaced = True
                if ':' in message:
                    replaced_message_list.append(message)
            else:
                replaced_message_list.append(message)
        else:
            #checking replace message
            pass

    return "\n".join(replaced_message_list)

def add_additional_recipients(block_size=500, backend=None):
    """
    add additional recipients as pre processing before send mail
    :param block_size:
    :param backend:
    :return:
    """
    try:
        count = 0
        queued_list = []
        worked_list = []
        for queued_message in _message_queue(block_size):
            if queued_message.deferred is not None: #deferred message does not need to add recipients again from aurora api
                continue
            if queued_message.pk in queued_list:
                break
            queued_list.append(queued_message.pk)
            if queued_message.message.is_message_for_customer_user():
                recipients = queued_message.message.get_additional_recipients()
            else:
                recipients = None
            if recipients:
                to_email_pending = queued_message.message.to_address
                from_email = queued_message.message.from_address
                previous_encoded_message = queued_message.message.encoded_message
                actor = queued_message.message.actor
                draft_id = queued_message.message.draft_id
                subject = queued_message.message.subject
                event_id = queued_message.message.event_id
                parent_pk = queued_message.message.pk
                if to_email_pending in recipients: #prevents duplicated sending
                    recipients.remove(to_email_pending)

                if not subject.startswith('[Debug_Test]'):
                    for to_email in recipients:
                        try:
                            if (draft_id, event_id, to_email) not in worked_list:
                                message = models.Message.objects.create(
                                    to_address=to_email,
                                    from_address=from_email,
                                    subject=subject,
                                    encoded_message=get_updated_encoded_message(previous_encoded_message, [to_email]),
                                    actor=actor,
                                    draft_id=draft_id,
                                    event_id=event_id,
                                    parent_id=parent_pk)

                                queued_message = models.QueuedMessage(message=message)
                                queued_message.save()
                                count += 1
                                worked_list.append((draft_id,event_id,to_email))
                        except Exception,e:
                            pass
        return count
    except:
        pass

def send_all(block_size=500, backend=None):
    """
    Send all non-deferred messages in the queue.

    A lock file is used to ensure that this process can not be started again
    while it is already running.

    The ``block_size`` argument allows for queued messages to be iterated in
    blocks, allowing new prioritised messages to be inserted during iteration
    of a large number of queued messages.

    """
    lock = FileLock(LOCK_PATH)

    logger.debug("Acquiring lock...")
    try:
        # lockfile has a bug dealing with a negative LOCK_WAIT_TIMEOUT (which
        # is the default if it's not provided) systems which use a LinkFileLock
        # so ensure that it is never a negative number.
        lock.acquire(settings.LOCK_WAIT_TIMEOUT or 0)
        #lock.acquire(settings.LOCK_WAIT_TIMEOUT)
    except AlreadyLocked:
        logger.debug("Lock already in place. Exiting.")
        return
    except LockTimeout:
        logger.debug("Waiting for the lock timed out. Exiting.")
        return

    logger.debug("Lock acquired.")

    start_time = time.time()

    sent = deferred = skipped = 0

    try:
        if constants.EMAIL_BACKEND_SUPPORT:
            connection = get_connection(backend=backend)
        else:
            connection = get_connection()
        blacklist = models.Blacklist.objects.values_list('email', flat=True)
        connection.open()
        for message in _message_queue(block_size):
            result = send_queued_message(message, smtp_connection=connection, blacklist=blacklist)
            if result == constants.RESULT_SENT:
                sent += 1
            elif result == constants.RESULT_FAILED:
                deferred += 1
            elif result == constants.RESULT_SKIPPED:
                skipped += 1
        connection.close()
    finally:
        logger.debug("Releasing lock...")
        lock.release()
        logger.debug("Lock released.")

    logger.debug("")
    if sent or deferred or skipped:
        log = logger.warning
    else:
        log = logger.info
    log("%s sent, %s deferred, %s skipped." % (sent, deferred, skipped))
    logger.debug("Completed in %.2f seconds." % (time.time() - start_time))
    logger.removeHandler(handler)


def send_loop(empty_queue_sleep=None):
    """
    Loop indefinitely, checking queue at intervals and sending and queued
    messages.

    The interval (in seconds) can be provided as the ``empty_queue_sleep``
    argument. The default is attempted to be retrieved from the
    ``MAILER_EMPTY_QUEUE_SLEEP`` setting (or if not set, 30s is used).

    """
    empty_queue_sleep = empty_queue_sleep or settings.EMPTY_QUEUE_SLEEP
    while True:
        while not models.QueuedMessage.objects.all():
            logger.debug("Sleeping for %s seconds before checking queue "
                          "again." % empty_queue_sleep)
            time.sleep(empty_queue_sleep)
        send_all()

def check_test_env(receiver, body_message):
    from ci.constants import ENVIRONMENT, EMAIL_ALERTS
    debug_message = ''
    if ENVIRONMENT in ['local','qa']:
        debug_message = "[TEST MAIL] This email is intended to be sent to user:%s" % receiver
        body_message = "%s\n\n%s" % (debug_message, body_message)
        receiver = EMAIL_ALERTS
    return receiver, body_message

def send_queued_message(queued_message, smtp_connection=None, blacklist=None,
                 log=True):
    """
    Send a queued message, returning a response code as to the action taken.

    The response codes can be found in ``django_mailer.constants``. The
    response will be either ``RESULT_SKIPPED`` for a blacklisted email,
    ``RESULT_FAILED`` for a deferred message or ``RESULT_SENT`` for a
    successful sent message.

    To allow optimizations if multiple messages are to be sent, an SMTP
    connection can be provided and a list of blacklisted email addresses.
    Otherwise an SMTP connection will be opened to send this message and the
    email recipient address checked against the ``Blacklist`` table.

    If the message recipient is blacklisted, the message will be removed from
    the queue without being sent. Otherwise, the message is attempted to be
    sent with an SMTP failure resulting in the message being flagged as
    deferred so it can be tried again later.

    By default, a log is created as to the action. Either way, the original
    message is not deleted.

    """
    message = queued_message.message
    if smtp_connection is None:
        smtp_connection = get_connection()
    opened_connection = False

    if blacklist is None:
        blacklisted = models.Blacklist.objects.filter(email=message.to_address)
    else:
        blacklisted = message.to_address in blacklist

    log_message = ''

    if blacklisted:
        logger.info("Not sending to blacklisted email: %s" %
                     message.to_address.encode("utf-8"))
        queued_message.delete()
        result = constants.RESULT_SKIPPED
    else:
        try:
            logger.info("Sending message to %s: %s" %
                         (message.to_address.encode("utf-8"),
                          message.subject.encode("utf-8")))
            opened_connection = smtp_connection.open()
            receivers, debug_message = check_test_env([message.to_address], message.encoded_message)

            email_message = smart_str(message.encoded_message)
            #import email
            #msg = email.message_from_string(message.encoded_message)
            is_ready_to_be_sent, event_succeed = message.is_ready_to_be_sent()
            if is_ready_to_be_sent:
                if message.is_publish_event():
                    if not event_succeed: #push failed
                        email_message = message.handle_exception_cases_of_publish_event()

                smtp_connection.connection.sendmail(message.from_address, receivers, email_message)
                queued_message.delete()
                result = constants.RESULT_SENT
            else:
                result = constants.RESULT_SKIPPED
        except (SocketError, smtplib.SMTPSenderRefused,
                smtplib.SMTPRecipientsRefused,
                smtplib.SMTPAuthenticationError,
                UnicodeEncodeError), err:
            queued_message.defer()
            logger.warning("Message to %s deferred due to failure: %s" %
                            (message.to_address.encode("utf-8"), err))
            log_message = unicode(err)
            result = constants.RESULT_FAILED
    if log:
        models.Log.objects.create(message=message, result=result,
                                  log_message=log_message)

    if opened_connection:
        smtp_connection.close()
    return result


def send_message(email_message, smtp_connection=None):
    """
    Send an EmailMessage, returning a response code as to the action taken.

    The response codes can be found in ``django_mailer.constants``. The
    response will be either ``RESULT_FAILED`` for a failed send or
    ``RESULT_SENT`` for a successfully sent message.

    To allow optimizations if multiple messages are to be sent, an SMTP
    connection can be provided. Otherwise an SMTP connection will be opened
    to send this message.

    This function does not perform any logging or queueing.

    """
    if smtp_connection is None:
        smtp_connection = get_connection()
    opened_connection = False

    try:
        opened_connection = smtp_connection.open()
        smtp_connection.connection.sendmail(email_message.from_email,
                    email_message.recipients(),
                    email_message.message().as_string())
        result = constants.RESULT_SENT
    except (SocketError, smtplib.SMTPSenderRefused,
            smtplib.SMTPRecipientsRefused,
            smtplib.SMTPAuthenticationError,
            UnicodeEncodeError), err:
        result = constants.RESULT_FAILED
        logger.warning("Message from %s failed due to: %s" %
                            (email_message.from_email, err))

    if opened_connection:
        smtp_connection.close()
    return result
