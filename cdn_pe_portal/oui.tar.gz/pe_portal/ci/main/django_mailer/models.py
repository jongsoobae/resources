from django.db import models
from django.core.cache import cache
from django.utils.encoding import smart_str
from ci.django_mailer import constants, managers
import datetime
now = datetime.datetime.utcnow

DEFAULT = 0
REQUEST_PAD = 1
CANCEL_REQUEST_PAD = 2
APPROVE_REQUEST_PAD = 3
DENY_REQUEST_PAD = 4
PUBLISH_PAD_TO_PRODUCTION = 5
RECOVER_PAD_TO_PRODUCTION = 6
DDOS_ATTACK_ALERTED = 101
DDOS_ATTACK_AUTO_CONVERT_FAILED = 102
RECOVERED_FROM_DDOS_ATTACK = 103

PUBLISH_PAD_TIMEOUT = 300

US = 1
KR = 2
CN = 3
JP = 4
EMEA = 5
SG = 6
UK = 7

MAIL_EVENT = ((DEFAULT, 'DEFAULT'),
              (REQUEST_PAD, 'REQUEST_PAD_IMPLEMENTATION'),
              (CANCEL_REQUEST_PAD, 'CANCEL_REQUEST_PAD_IMPLEMENTATION'),
              (APPROVE_REQUEST_PAD, 'APPROVE_REQUEST_PAD_IMPLEMENTATION'),
              (DENY_REQUEST_PAD, 'DENY_REQUEST_PAD_IMPLEMENTATION'),
              (PUBLISH_PAD_TO_PRODUCTION, 'PUBLISH_PAD_TO_PRODUCTION'),
              (RECOVER_PAD_TO_PRODUCTION, 'RECOVER_PAD_TO_PRODUCTION'),
              (DDOS_ATTACK_ALERTED, 'DDOS_ATTACK_ALERTED'),
              (DDOS_ATTACK_AUTO_CONVERT_FAILED, 'DDOS_ATTACK_AUTO_CONVERT_FAILED'),
              (RECOVERED_FROM_DDOS_ATTACK, 'RECOVERED_FROM_DDOS_ATTACK'),
)

CORP_CODES = ((US,'United States'),
              (KR,'Korea'),
              (CN,'China'),
              (JP,'Japan'),
              (EMEA,'EMEA'),
              (SG,'Singapore'),
              (UK,'United Kingdom'),
)

PRIORITIES = (
    (constants.PRIORITY_HIGH, 'high'),
    (constants.PRIORITY_NORMAL, 'normal'),
    (constants.PRIORITY_LOW, 'low'),
)

RESULT_CODES = (
    (constants.RESULT_SENT, 'success'),
    (constants.RESULT_SKIPPED, 'not sent (blacklisted)'),
    (constants.RESULT_FAILED, 'failure'),
)

class Event(models.Model):
    event_id = models.IntegerField(db_column='id', choices=MAIL_EVENT)
    event_name = models.CharField(max_length=200)
    description = models.CharField(max_length=1024, blank=True)
    date_created = models.DateTimeField(default=now)

    class Meta:
        ordering = ('-date_created',)

    def __unicode__(self):
        return self.event_name

class Message(models.Model):
    """
    An email message.
    
    The ``to_address``, ``from_address`` and ``subject`` fields are merely for
    easy of access for these common values. The ``encoded_message`` field
    contains the entire encoded email message ready to be sent to an SMTP
    connection.
    
    """
    to_address = models.CharField(max_length=200)
    from_address = models.CharField(max_length=200)
    subject = models.CharField(max_length=255)
    actor = models.CharField(max_length=200, blank=True, null=True)
    #draft = models.ForeignKey(SiteDraft, db_column='draft_id')
    parent_id = models.BigIntegerField(blank=True,null=True)
    draft_id = models.IntegerField()
    ckey = models.IntegerField()
    site_id = models.IntegerField(blank=True,null=True)
    event_id = models.SmallIntegerField(choices=MAIL_EVENT, editable=True)
    encoded_message = models.TextField()
    date_created = models.DateTimeField(default=now)

    class Meta:
        ordering = ('date_created',)

    def __unicode__(self):
        return '%s: %s' % (self.to_address, self.subject)

    def get_status(self):
        status = 'Unknown'
        try:
            QueuedMessage.objects.get(message=self)
            status = 'Pending'
        except QueuedMessage.DoesNotExist:
            pass
        try:
            log = Log.objects.get(message=self)
            status = log.get_status()
        except Log.DoesNotExist:
            pass
        return status

    def get_date_sent(self):
        try:
            log = Log.objects.get(message=self)
            return log.date
        except Log.DoesNotExist:
            return None

    def get_event_name(self):
        return MAIL_EVENT[self.event_id][1]

    def pre_process(self):
        #recipients = self.draft.get_pad_change_event_mail_customer_subscribers()
        pass

    def get_draft(self):
        from ci.common.models.site import SiteDraft
        try:
            draft = SiteDraft.objects.get(pk=self.draft_id)
            return draft
        except SiteDraft.DoesNotExist:
            return None

    def is_publish_event(self):
        return self.event_id == PUBLISH_PAD_TO_PRODUCTION

    def is_ready_to_be_sent(self):
        """
        return ready_to_be_sent, is_sucess_event
        """
        if self.event_id != PUBLISH_PAD_TO_PRODUCTION:
            return True, True
        try:
            from ci.common.models.site import SiteDraft
            draft = SiteDraft.objects.get(pk=self.draft_id)
            if draft.is_production_deploy_completed():
                if draft.is_publish_failed():
                    return True, False
                else:
                    return True, True
            else:
                histories = draft._get_latest_production_push_histories(self.date_created)
                count = histories.count()
                if count > 0:
                    history = histories[count-1] #get push history related to mail event queue created
                    result_dict = history.get_valid_push_result_item()
                    if result_dict.get('status') == 'Completed':
                        return True, True
                    if result_dict.get('status') == 'Failed':
                        return True, False

                if self.is_event_timed_out():
                    return True, False
                else:
                    return False, False

        except SiteDraft.DoesNotExist:
            #draft has been deleted. could happen if mail sending is delayed.
            return True, False

    def is_event_timed_out(self):
        """
        if event notification mail needs to be sent asynchronously like 'PUBLISH_PAD_TO_PRODUCTION',
        there needs to be handled exceptional case where mail function is disabled.
        for instance, push status might be changed shortly after pad is published to production.
        """
        if self.event_id == PUBLISH_PAD_TO_PRODUCTION:
            if (datetime.datetime.utcnow() - self.date_created).seconds > PUBLISH_PAD_TIMEOUT:
                return True
            else:
                return False
        else:
            return True

    def handle_exception_cases_of_publish_event(self):
        email_message = smart_str(self.encoded_message)
        try:
            draft = self.get_draft()
            if draft:
                if draft.is_publish_failed():
                    self.subject = self.subject.replace("PAD has been pushed to production for",
                                                                          "PAD push to production has failed for")
                    self.encoded_message = self.encoded_message.replace("PAD has been pushed to production for",
                                                                          "PAD push to production has failed for")
                elif self.is_event_timed_out():
                    self.subject = self.subject.replace("PAD has been pushed to production for",
                                                                          "PAD push to production has timed out for")
                    self.encoded_message = self.encoded_message.replace("PAD has been pushed to production for",
                                                                          "PAD push to production has timed out for")
            else:
                self.subject = self.subject.replace("PAD has been pushed to production for",
                                                    "PAD has been deleted for")
                self.encoded_message = self.encoded_message.replace("PAD has been pushed to production for",
                                                                          "PAD has been deleted for")
            email_message = smart_str(self.encoded_message)
            try:
                self.save()
            except:
                pass
        except:
            pass
        return email_message

    def is_message_for_customer_user(self):
        if self.site_id and self.site_id == 1:
            return False
        else:
            return True
            
    def get_updated_encoded_message(self, recipients=[]):
        replace_message = u'To: %s' % (', '.join(recipients))
        encoded_message = self.encoded_message.replace("\r\n","\n")

        message_list = encoded_message.split("\n")
        replaced_message_list = []
        for message in message_list:
            if message.startswith('To:'):
                message = replace_message
            replaced_message_list.append(message)

        return "\n".join(replaced_message_list)            

    def get_updated_encoded_message(self, recipients=[]):
        replace_message = u'To: %s' % (', '.join(recipients))
        encoded_message = self.encoded_message.replace("\r\n","\n")

        message_list = encoded_message.split("\n")
        replaced_message_list = []
        for message in message_list:
            if message.startswith('To:'):
                message = replace_message
            replaced_message_list.append(message)

        return "\n".join(replaced_message_list)

    def get_additional_recipients(self):
        from ci.common.models.site import SiteDraft
        from ci.common.models.customer import Customer
        recipients = []
        if self.parent_id is not None: #parent id means recipients this message has been fetched from aurora api and added..
            return recipients

        added_messages = Message.objects.filter(parent_id=self.pk) #in case of reset message from deferred
        if added_messages.exists():
            return recipients

        try:
            cache_key = "draft_recipients_%s" % self.draft_id
            recipients = cache.get(cache_key)
            if not recipients:
                draft = SiteDraft.objects.get(pk=self.draft_id)
                recipients = draft.get_pad_change_event_mail_customer_subscribers()
                cache.set(cache_key, recipients, 60)
        except SiteDraft.DoesNotExist:
            #draft has been deleted. use site_id or ckey
            try:
                customer = Customer.objects.get(pk=self.ckey)
                recipients = customer.get_email_recipients(draft=None, site_id=self.site_id)
                cache.set(cache_key, recipients, 60)
            except:
                pass

        return recipients


class QueuedMessage(models.Model):
    """
    A queued message.
    
    Messages in the queue can be prioritised so that the higher priority
    messages are sent first (secondarily sorted by the oldest message).
    
    """
    message = models.OneToOneField(Message, editable=False)
    priority = models.PositiveSmallIntegerField(choices=PRIORITIES,
                                            default=constants.PRIORITY_NORMAL)
    deferred = models.DateTimeField(null=True, blank=True)
    retries = models.PositiveIntegerField(default=0)
    date_queued = models.DateTimeField(default=now)

    objects = managers.QueueManager()

    class Meta:
        ordering = ('priority', 'date_queued')

    def defer(self):
        self.deferred = now()
        self.save()

    def pre_process(self):
        self.message.pre_process()


class Blacklist(models.Model):
    """
    A blacklisted email address.
    
    Messages attempted to be sent to e-mail addresses which appear on this
    blacklist will be skipped entirely.
    
    """
    email = models.EmailField(max_length=200)
    date_added = models.DateTimeField(default=now)

    class Meta:
        ordering = ('-date_added',)
        verbose_name = 'blacklisted e-mail address'
        verbose_name_plural = 'blacklisted e-mail addresses'


class Log(models.Model):
    """
    A log used to record the activity of a queued message.
    
    """
    message = models.ForeignKey(Message, editable=False)
    result = models.PositiveSmallIntegerField(choices=RESULT_CODES)
    date = models.DateTimeField(default=now)
    log_message = models.TextField()

    class Meta:
        ordering = ('-date',)

    def get_status(self):
        return RESULT_CODES[self.result][1]

class Subscriber(models.Model):
    event_id = models.IntegerField(choices=MAIL_EVENT)
    corp_code = models.PositiveSmallIntegerField(choices=CORP_CODES, editable=True)
    email = models.EmailField(max_length=200)
    date_added = models.DateTimeField(default=now)

    class Meta:
        ordering = ('-date_added',)

