from ci.django_mailer.tests.commands import TestCommands
from ci.django_mailer.tests.engine import LockTest #COULD DROP THIS TEST
from ci.django_mailer.tests.backend import TestBackend