import unittest
from selenium.common.exceptions import NoSuchElementException
import time
from selenium.webdriver.common.by import By
from selenium import webdriver


class SeleniumTestCase(unittest.TestCase):
    def __init__(self, methodName=None):
        super(SeleniumTestCase, self).__init__(methodName=methodName)
        self.driver = webdriver.Firefox()
        self.driver.implicitly_wait(5)
        self.base_url = "http://10.40.196.147:8080"

    def is_element_present(self, how, what):
        try:
            self.driver.find_element(by=how, value=what)
        except NoSuchElementException:
            return False
        return True

    def wait_for_element_by_css_selector(self, what, seconds=30):
        self.driver.implicitly_wait(1)
        for i in range(seconds):
            try:
                if self.is_element_present(By.CSS_SELECTOR, what):
                    self.driver.implicitly_wait(5)
                    break
            except:
                pass
            time.sleep(1)
        else:
            self.driver.implicitly_wait(5)
            self.fail('There is no element for "%s"' % what)

    def oui_login(self, oui_url):
        user_info = {'username': 'jungho.park', 'password': 'cdnadmin'}
        self.driver.get(oui_url + "/login/?next=/")
        self.driver.find_element(By.NAME, "username").send_keys(user_info.get('username'))
        self.driver.find_element(By.NAME, "password").send_keys(user_info.get('password'))
        from selenium.webdriver.common.keys import Keys
        self.driver.find_element(By.NAME, "password").send_keys(Keys.RETURN)
        time.sleep(2)
