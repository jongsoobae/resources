import requests
import json
import hashlib
from selenium_test.config_constants import PANTHER_API_URL,PANTHER_MD5_SALT
from selenium_test.config_constants import PANTHER_API_USER, PANTHER_API_PWD
from selenium_test.config_user_constants import PRISM_API_USER, AURORA_USER
from selenium_test.config_constants import PRISM_API_URL


def get_prism_credential():
    return "user=%s&pass=%s" % (PRISM_API_USER.get('username'), PRISM_API_USER.get('password'))

class APIManager(object):
    def __init__(self):
        self.username = PANTHER_API_USER
        self.password = PANTHER_API_PWD
        self.credential = "%s:%s" % (PANTHER_API_USER, PANTHER_API_PWD)
        self.prism_url = PRISM_API_URL
        self.prism_credential = get_prism_credential()

    def _get_default_parameters(self, params):
        """
        pad_list=&ckey=1664&aurora_user_id=injune99@hotmail.com&aurora_user_key=6901&editable=1&admin_flag=1&md5_dig=b0c10fa1a26dfc778d0016dd5dff32a0
        :param params:
        :return:
        """
        #there is no pad_list when add/edit/view draft
        pad_list = ''
        user_email = AURORA_USER.get('email')
        user_pk = AURORA_USER.get('user_pk')
        ckey =  AURORA_USER.get('ckey')
        editable = 1
        admin_flag =1
        parameters = {'pad_list': pad_list,
                      'ckey': ckey,
                      'aurora_user_id': user_email,
                      'aurora_user_key': user_pk,
                      'editable': editable,
                      'admin_flag': admin_flag,
                      'md5dig': self._get_md5_hash_value(user_email, user_pk, pad_list, ckey, editable, admin_flag)}
        if params is not None:
            for k,v in params.iteritems():
                try:
                    parameters.update({k:v})
                except:
                    pass
        return parameters


    def _get_md5_hash_value(self, user_email, aurora_user_pk, pad_list, ckey, editable, admin_flag):
        md5_ori_value = "%s&pad_list=%s&ckey=%s&aurora_user_id=%s&aurora_user_key=%s&editable=%s&admin_flag=%s" \
         % (PANTHER_MD5_SALT, pad_list, str(ckey), str(user_email), str(aurora_user_pk), editable, admin_flag)
        m = hashlib.md5()
        m.update(md5_ori_value)
        md5_dig = m.hexdigest()
        return md5_dig

    def request(self,uri, params, is_internal=True):
        """
        wrap request library. build url and parameters
        :param uri: uri path
        :param params: additional parameters
        :return:
        """
        base_url = "%s%s" % (PANTHER_API_URL, 'cdn')
        if is_internal:
            base_url =  "%s%s" % (PANTHER_API_URL, 'int')
        url = "%s/%s/%s" % (base_url,self.credential, uri)
        print url
        parameters = self._get_default_parameters(params)
        response = requests.get(url, params=parameters)
        print response._content
        return response