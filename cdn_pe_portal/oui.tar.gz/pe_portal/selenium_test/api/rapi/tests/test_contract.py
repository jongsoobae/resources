import os,sys
import json
import pad_input
sys.path.insert(0, '/home/injune/git/panther')
os.environ['DJANGO_SETTINGS_MODULE'] = 'api.settings'
#cwd = os.path.abspath(os.path.dirname(__file__))
#sys.path.insert(0, os.path.dirname(cwd))
from ci.common.utils.api.site import render_form_from_model
from ci.common.forms.site import get_EditPadForm
from ci.common.models.site import SiteDraft
from ci.common.models.customer import Customer, Product
from ci.common.utils.site import get_editable_fields

def add_pad(opts):
    aurora_user_id = 'test_master_priv@gala.cdn.com'
    draft = None
    product = Product.objects.get(pk=7835)
    customer = Customer.objects.get(pk=1446)
    shield_location = None
    form_model = get_EditPadForm(instance=draft, material_no_list=[product.product_cd], editable_fields=get_editable_fields(draft),
                                         customer=customer, product=product, shield_location=shield_location, is_api=True).__class__

    edit_type = 'new draft'
    dup_form = None
    site = False
    site_obj = None
    dup_form_validated = False

    form, dup_form, draft, site_obj = render_form_from_model(customer, aurora_user_id, form_model, dup_form_validated, opts,
                                                               dup_form, site, draft, site_obj, edit_type)
    return form

def test_add_pad_aliases():
    pad_name= "helo005.gala.cdn.com"
    pad_aliases = "\r\n".join(pad_input.pad_alias_list)
    print len(pad_aliases)
    pad_info = {'origin':'helo002.origin.gala.cdn.com', 'product':'40000548-10', 'pad':pad_name, 'pad_aliases': pad_aliases}
    form = add_pad(pad_info)




if __name__ == "__main__":
    test_add_pad_aliases()