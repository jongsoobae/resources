import unittest
import json
from selenium_test.api import APIManager

class TestDDosAttackEvent(unittest.TestCase):

    def setUp(self):
        self.api_manager = APIManager()

    def report_attack_event(self, parameters={}):
        uri = "site/alert/ddos_attack/"
        is_internal_api = True
        response = self.api_manager.request(uri, parameters, is_internal_api)
        return response

    def test_ddos_attack_event_ok(self):
        parameters = {'site_id':111, 'target_name':'hhh-qa.cdnetworks.com'}
        response = self.report_attack_event(parameters)
        assert '200' in response._content

    def test_ddos_attack_event_invalid(self):
        parameters = {'site_id':111}
        response = self.report_attack_event(parameters)
        assert '400' in response._content

if __name__ == "__main__":
    unittest.main()