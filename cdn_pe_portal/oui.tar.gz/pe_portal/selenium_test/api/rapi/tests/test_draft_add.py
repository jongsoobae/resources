import unittest
import json
from selenium_test.api import APIManager

class TestDraftAdd(unittest.TestCase):

    def setUp(self):
        self.api_manager = APIManager()

    def list_contract(self):
        uri = "contract/list/"
        parameters = {}
        is_internal_api = False
        response = self.api_manager.request(uri, parameters, is_internal_api)
        return response

    def test_draft_add(self):
        response = self.list_contract()
        print 'hello'
        assert '200' in response._content


if __name__ == "__main__":
    unittest.main()