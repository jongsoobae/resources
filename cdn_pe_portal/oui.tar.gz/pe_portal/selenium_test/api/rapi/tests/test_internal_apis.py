import os, sys
import unittest
import requests


sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'api.settings'


ID = 'jungho.park'
PW = 'cdnadmin'
#PRE_URL = 'https://pantherapi-qa.cdnetworks.com/rest/int/%s:%s/' % (ID, PW)
PRE_URL = 'http://10.40.196.147:8089/rest/int/%s:%s/' % (ID, PW)


class TestApi(unittest.TestCase):

    def get_url(self, url, params):
        return '%s?%s' % (url, '&'.join(['%s=%s' % (key, value) for key, value in params.items()]))

    def _test_url(self, url, params):
        print self.get_url(url, params)
        res = requests.get(self.get_url(url, params))
        print res.json()
        #if res.status_code != 200:
        #    print res.json()
        self.assertEqual(res.status_code, 200)
        return res


class TestApiAlert(TestApi):
    def setUp(self):
        self.url = '%s%s/' % (PRE_URL, 'alert')
        self.skipTest('Tested')

    def tearDown(self):
        self._test_url(self.req['url'], self.req['params'])
        from ci.common.models.alert import Alert
        Alert.objects.all().delete()

    def test_add(self):
        self.req = {
            'url': '%s%s/' % (self.url, 'add'),
            'params': {
                'code': 'Monitor::Nagios',
                'subject': 'urgent%20issue',
                'body': 'the%20following%20issue%20has%20been%20found',
            }
        }


class TestApiCustomer(TestApi):
    def setUp(self):
        self.url = '%s%s/' % (PRE_URL, 'customer')

    def tearDown(self):
        pass

    def test_add(self):
        self.skipTest('cannot add.')
        self.req = {
            'url': '%s%s/' % (self.url, 'add'),
            'params': {
                'sales_eng': 'sales@cdnetworks.co.kr',
                'sales_rep': 'sales@cdnetworks.co.kr',
                'customer_type': 'standard',
                'name': 'test_js_customer',
            }
        }
        self._test_url(self.req['url'], self.req['params'])

    def test_edit(self):
        self.skipTest('tested.')
        customer_name = 'ADM'
        self.req = {
            'url': '%s%s/%s/' % (self.url, 'edit', customer_name),
            'params': {
                'description': 'jstest',
            }
        }
        self._test_url(self.req['url'], self.req['params'])

    def test_list(self):
        self.skipTest('tested.')
        self.req = {
            'url': '%s%s/' % (self.url, 'list'),
            'params': {
            }
        }
        self._test_url(self.req['url'], self.req['params'])

    def test_view(self):
        self.skipTest('tested.')
        customer_name = 'ADM'
        self.req = {
            'url': '%s%s/%s/' % (self.url, 'view', customer_name),
            'params': {
            }
        }
        self._test_url(self.req['url'], self.req['params'])


class TestApiKeystore(TestApi):
    def setUp(self):
        self.url = '%s%s/' % (PRE_URL, 'keystore')

    def tearDown(self):
        pass

    def test_list(self):
        self.skipTest('tested.')
        self.req = {
            'url': '%s%s/' % (self.url, 'list'),
            'params': {
            }
        }
        self._test_url(self.req['url'], self.req['params'])

    def test_view(self):
        self.skipTest('tested.')
        keystore_id = 2
        self.req = {
            'url': '%s%s/%s/' % (self.url, 'view', str(keystore_id)),
            'params': {
            }
        }
        self._test_url(self.req['url'], self.req['params'])


class TestApiHashpoint(TestApi):
    def setUp(self):
        self.url = '%s%s/' % (PRE_URL, 'hashpoint')

    def tearDown(self):
        pass

    def test_modify(self):
        self.skipTest('tested.')
        self.req = {
            'url': '%s%s/' % (self.url, 'modify'),
            'params': {
                'node': 'h0-s150.p99-icn.cdngp.net',  # id 1
                'first_delay': '2009-02-14%2012:00:00',
                'offset_minutes': '5',
                'target_points': '1'
            }
        }
        self._test_url(self.req['url'], self.req['params'])

    def test_preview(self):
        self.skipTest('tested.')
        self.req = {
            'url': '%s%s/' % (self.url, 'preview'),
            'params': {
                'node': 'h0-s150.p99-icn.cdngp.net',  # id 1
                'first_delay': '2009-02-14%2012:00:00',
                'offset_minutes': '5',
                'target_points': '1'
            }
        }
        self._test_url(self.req['url'], self.req['params'])


class TestApiNode(TestApi):
    def setUp(self):
        self.url = '%s%s/' % (PRE_URL, 'node')

    def tearDown(self):
        pass

    def test_list(self):
        self.skipTest('tested.')
        self.req = {
            'url': '%s%s/' % (self.url, 'list'),
            'params': {
            }
        }
        self._test_url(self.req['url'], self.req['params'])


class TestApiOnCall(TestApi):
    def setUp(self):
        self.url = '%s%s/' % (PRE_URL, 'oncall')

    def tearDown(self):
        pass

    def test_list(self):
        self.skipTest('tested.')
        self.req = {
            'url': '%s%s/' % (self.url, 'list'),
            'params': {
            }
        }
        self._test_url(self.req['url'], self.req['params'])


class TestApiPop(TestApi):
    def setUp(self):
        self.url = '%s%s/' % (PRE_URL, 'pop')

    def tearDown(self):
        pass

    def test_list(self):
        self.skipTest('tested.')
        self.req = {
            'url': '%s%s/' % (self.url, 'list'),
            'params': {
            }
        }
        self._test_url(self.req['url'], self.req['params'])


class TestApiProduct(TestApi):
    def setUp(self):
        self.url = '%s%s/' % (PRE_URL, 'product')

    def tearDown(self):
        from ci.common.models.customer import Product
        try:
            pass
            Product.objects.get(name='js_test').delete()
        except:
            pass

    def test_add(self):
        self.skipTest('tested.')
        customer_name = 'ADM'
        self.req = {
            'url': '%s%s/' % (self.url, 'add'),
            'params': {
                'cop_product_id': '0050000010-000010',
                'name': 'js_test',
                'customer': customer_name,
            }
        }
        self._test_url(self.req['url'], self.req['params'])

    def test_edit(self):
        self.skipTest('tested.')
        from ci.common.models.customer import Product
        test_product = Product.objects.get(name='js_test_for_test')

        self.req = {
            'url': '%s%s/%s/' % (self.url, 'edit', test_product.cop_product_id),
            'params': {
                'count_per_contract': test_product.count_per_contract + 1
            }
        }
        self._test_url(self.req['url'], self.req['params'])
        pass


class TestApiProductSite(TestApi):
    def setUp(self):
        self.url = '%s%s/' % (PRE_URL, 'production-site')

    def tearDown(self):
        from ci.common.models import Site
        try:
            Site.objects.get(pad='testjs.internal.foo.com').delete()
        except:
            pass

    def test_add(self):
        self.skipTest('tested.')
        from ci.common.models.customer import Product
        test_product = Product.objects.get(name='js_test_for_test')
        test_customer_id = 1453
        self.req = {
            'url': '%s%s/' % (self.url, 'add'),
            'params': {
                'pad': 'testjs.internal.foo.com',
                'origin': 'testjs.origin.foo.com',
                'customer_id': test_customer_id,
                'service': 'k1: CS: Korea',
                'shielded_service': 'Test_Shield',
                'pad_aliases': 'testjs.aliases.foo.com',
                'product': test_product.cop_product_id
            }
        }
        self._test_url(self.req['url'], self.req['params'])

    def test_edit(self):
        self.skipTest('tested.')
        pad_name = 'testjs2.internal.foo.com'
        self.req = {
            'url': '%s%s/%s/' % (self.url, 'edit', pad_name),
            'params': {
                'pad': pad_name,
                'pad_aliases': 'testjs2.aliases.foo.com',
            }
        }
        self._test_url(self.req['url'], self.req['params'])


class TestApiSiteProduct(TestApi):
    def setUp(self):
        self.url = '%s%s/' % (PRE_URL, 'site-product')

    def tearDown(self):
        pass

    def test_edit(self):
        self.skipTest('tested.')
        pad_name = 'testjs2.internal.foo.com'
        self.req = {
            'url': '%s%s/%s/' % (self.url, 'edit', pad_name),
            'params': {
                'cop_product_id': '0050000010-000020'
            }
        }
        self._test_url(self.req['url'], self.req['params'])


class TestApiPush(TestApi):
    def setUp(self):
        self.url = '%s%s/' % (PRE_URL, 'push')

    def tearDown(self):
        pass

    def test_add(self):
        self.skipTest('tested.')
        self.req = {
            'url': '%s%s/' % (self.url, 'add'),
            'params': {
                'target': 'h0-s150.p99-icn.cdngp.net',
                'type': 'DNS',
                'description': 'jstest_for_internal'
            }
        }
        self._test_url(self.req['url'], self.req['params'])


class TestApiRegion(TestApi):
    def setUp(self):
        self.url = '%s%s/' % (PRE_URL, 'region')

    def tearDown(self):
        pass

    def test_list(self):
        self.skipTest('tested.')

        self.req = {
            'url': '%s%s/' % (self.url, 'list'),
            'params': {
            }
        }
        self._test_url(self.req['url'], self.req['params'])


class TestApiService(TestApi):
    def setUp(self):
        self.url = '%s%s/' % (PRE_URL, 'region')

    def tearDown(self):
        pass

    def test_list(self):
        self.skipTest('tested.')
        self.req = {
            'url': '%s%s/' % (self.url, 'list'),
            'params': {
            }
        }
        self._test_url(self.req['url'], self.req['params'])


class TestApiInformation(TestApi):
    def setUp(self):
        self.url = PRE_URL

    def tearDown(self):
        pass

    def test_get_response_stat(self):
        self.skipTest('tested.')
        self.req = {
            'url': '%s%s/' % (self.url, 'get_response_stat'),
            'params': {
                'by_pop': 0,
                'stat_time_start': '2012-08-01',
                'stat_time_end': '2012-08-03',
                'cdn_service_id': 10
            }
        }
        self._test_url(self.req['url'], self.req['params'])

    def test_get_service(self):
        self.skipTest('tested.')
        self.req = {
            'url': '%s%s/' % (self.url, 'get_service_info'),
            'params': {
                'type': 'domain',
                'name': 'k1: CS: Korea'
            }
        }
        self._test_url(self.req['url'], self.req['params'])

    def test_get_service_vip(self):
        self.skipTest('tested.')
        self.req = {
            'url': '%s%s/' % (self.url, 'get_service_vip'),
            'params': {
                'dns_prefix': 'k1'
            }
        }
        self._test_url(self.req['url'], self.req['params'])

    def test_get_edge(self):
        self.skipTest('tested.')
        self.req = {
            'url': '%s%s/' % (self.url, 'get_edge_info'),
            'params': {
                'dns_prefix': 'k1'
            }
        }
        self._test_url(self.req['url'], self.req['params'])

    def test_get_shield(self):
        self.skipTest('tested.')
        self.req = {
            'url': '%s%s/' % (self.url, 'get_shield_info'),
            'params': {
            }
        }
        self._test_url(self.req['url'], self.req['params'])

    def test_get_band_vip(self):
        self.skipTest('tested.')
        self.req = {
            'url': '%s%s/' % (self.url, 'get_band_vip'),
            'params': {
                'band_id': 2
            }
        }
        self._test_url(self.req['url'], self.req['params'])

    def test_get_pop_vip(self):
        self.skipTest('tested.')
        self.req = {
            'url': '%s%s/' % (self.url, 'get_pop_vip'),
            'params': {
                'pop_id': 2
            }
        }
        self._test_url(self.req['url'], self.req['params'])


if __name__ == '__main__':
    unittest.main()
