import os, sys
import unittest
import pad_input

sys.path.insert(0, '/home/injune/git/panther')
sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'api.settings'

from ci.common.utils.api.site import render_form_from_model
from ci.common.forms.site import get_EditPadForm
from ci.common.models.site import SiteDraft, Site
from ci.common.models.customer import Customer, Product
from ci.common.utils.site import get_editable_fields


def add_pad(opts):
    aurora_user_id = 'test_master_priv@gala.cdn.com'
    draft = None
    product = Product.objects.get(pk=7835)
    customer = Customer.objects.get(pk=1446)
    shield_location = None
    form_model = get_EditPadForm(instance=draft, material_no_list=[product.product_cd],
                                 editable_fields=get_editable_fields(draft),customer=customer,
                                 product=product, shield_location=shield_location, is_api=True).__class__
    edit_type = 'new draft'
    dup_form = None
    site = False
    site_obj = None
    dup_form_validated = False
    form, dup_form, draft, site_obj = render_form_from_model(customer, aurora_user_id, form_model,
                                                             dup_form_validated, opts, dup_form,
                                                             site, draft, site_obj, edit_type)
    return form


class TestInputValidate(unittest.TestCase):
    def setUp(self):
        self.pad = 'helo005.gala.cdn.com'
        self.origin = 'helo002.origin.gala.cdn.com'
        self.product = '40000548-10'

        self.error_string_check = True
        pass

    def tearDown(self):
        pass

    def test_add_pad_origin_port(self):
        pad_info = {
            'origin': self.origin,
            'product': self.product,
            'pad': self.pad,
            'origin_port': 2222
        }
        form = add_pad(pad_info)
        self.assertTrue(form.is_valid())

        pad_info = {
            'origin': self.origin,
            'product': self.product,
            'pad': self.pad,
            'origin_port': -1
        }
        form = add_pad(pad_info)
        self.assertFalse(form.is_valid())
        if self.error_string_check:
            self.assertTrue(
                'Ensure Custom Origin Port, This value is greater than or equal to 0.' in form.errors['__all__'][0])

        pad_info = {
            'origin': self.origin,
            'product': self.product,
            'pad': self.pad,
            'origin_port': 66666
        }
        form = add_pad(pad_info)
        self.assertFalse(form.is_valid())
        if self.error_string_check:
            self.assertTrue(
                'Ensure Custom Origin Port, This value is less than or equal to 65536.' in form.errors['__all__'][0])

    def test_add_pad_aliases(self):
        pad_aliases = "\r\n".join(pad_input.pad_alias_list)
        non_valid_pad_aliases = 'aaa.cdn.com, bbb.cdn.com'
        pad_info = {
            'origin': self.origin,
            'product': self.product,
            'pad': self.pad,
            'pad_aliases': pad_aliases
        }
        form = add_pad(pad_info)
        self.assertTrue(form.is_valid())
        pad_info = {
            'origin': self.origin,
            'product': self.product,
            'pad': self.pad,
            'pad_aliases': non_valid_pad_aliases
        }
        form = add_pad(pad_info)
        self.assertFalse(form.is_valid())
        if self.error_string_check:
            self.assertTrue(
                'Your pad aliases entry is invalid. Please make sure each pad alias is on a separate line'
                in form.errors['__all__'][0])

    def test_add_mandatory(self):
        for i in range(3):
            pad_info = {
                'origin': '',
                'pad': '',
            }
            factor = bin(i).split('b')[1].rjust(2, '0')  # binary numbers
            if factor[0] == '1':
                pad_info['origin'] = self.origin
            if factor[1] == '1':
                pad_info['pad'] = self.pad
            print pad_info
            form = add_pad(pad_info)
            self.assertFalse(form.is_valid(), form.errors.items())
            if self.error_string_check:
                if not pad_info['origin']:
                    self.assertTrue('This field is required.' in form.errors['origin'][0])
                if not pad_info['pad']:
                    self.assertTrue('This field is required.' in form.errors['pad'][0])

    def test_add_wildcard_pad_not_support_pad_aliases(self):
        pad = '*.gala.cdn.com'
        pad_aliases = 'pa1.gala.cdn.com'
        pad_info = {
            'origin': self.origin,
            'product': self.product,
            'pad': pad,
            'pad_aliases': pad_aliases
        }

        form = add_pad(pad_info)
        self.assertFalse(form.is_valid(), form.errors.items())
        if self.error_string_check:
            self.assertTrue('Wildcard PADs do not support PAD aliases' in form.errors['__all__'][0])

    def test_add_pad_same_origin_need_origin_ip(self):
        pad_aliases = 'pa1.gala.cdn.com'
        pad_info = {
            'origin': self.pad,
            'product': self.product,
            'pad': self.pad,
            'pad_aliases': pad_aliases,
        }

        form = add_pad(pad_info)
        self.assertFalse(form.is_valid(), form.errors.items())
        if self.error_string_check:
            self.assertTrue('The PAD and origin cannot be the same.' in form.errors['__all__'][0])

        pad_info = {
            'origin': self.pad,
            'product': self.product,
            'pad': self.pad,
            'pad_aliases': pad_aliases,
            'origin_ip': '1.1.1.1'
        }

        form = add_pad(pad_info)
        self.assertTrue(form.is_valid(), form.errors.items())

    def test_add_pad_aliases_duplicate(self):
        draft = SiteDraft.objects.exclude(pad_aliases__isnull=True).exclude(pad_aliases__exact='')[0]
        site = Site.objects.exclude(
            pad_aliases__isnull=True).exclude(pad_aliases__exact='').exclude(pad_aliases__exact=draft.pad_aliases)[0]

        pad_info = {
            'origin': self.origin,
            'product': self.product,
            'pad': self.pad,
            'pad_aliases': draft.pad_aliases,
        }

        form = add_pad(pad_info)
        self.assertFalse(form.is_valid(), form.errors.items())
        if self.error_string_check:
            self.assertTrue('A domain with this name already exists' in form.errors['__all__'][0])

        pad_info = {
            'origin': self.origin,
            'product': self.product,
            'pad': self.pad,
            'pad_aliases': site.pad_aliases,
        }

        form = add_pad(pad_info)
        self.assertFalse(form.is_valid(), form.errors.items())
        if self.error_string_check:
            self.assertTrue('A domain with this name already exists' in form.errors['__all__'][0])


if __name__ == "__main__":
    unittest.main()
