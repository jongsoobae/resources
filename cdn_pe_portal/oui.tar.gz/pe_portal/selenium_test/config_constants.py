import os
BASE_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# OUI settings
EMAIL_HOST = 'send.mx.cdnetworks.com'
EMAIL_PORT = 25
PANTHER_API_URL = "https://pantherapi-qa.cdnetworks.com/rest/"
PANTHER_API_USER = "api@cdnetworks.com"
PANTHER_API_PWD = "cd3n3tw0rks"
PANTHER_API_TIMEOUT = 10000
PANTHER_MD5_SALT = 'scpinterface@cuiadmin'
PRISM_API_URL = 'https://prismapi-qa.cdnetworks.com/'
ADMIN_MAIL_ADDRESS = 'portaladmin@cdnetworks.com'
PORTAL_TEAM_MAIL_ADDRESS = 'CDN10001032@cdnetworks.com'
OUI_URL = 'https://pantheroui-qa.cdnetworks.com'
SPECTRUMAPI_URL = 'https://spectrumapi-qa.cdnetworks.com'
CI_SERVER_HOSTNAME = 'ci-slave-portal-ngpos-1'
SELENIUM_REMOTE_SERVER_IP = '10.40.210.210'
SELENIUM_REMOTE_SERVER_PORT = '4444'
IMPLICITLY_WAIT = 10  # Second
USE_REMOTE_SELENIUM_SERVER = False
BLOCK_URL_LIST = (
    'https://pantheroui.cdnetworks.com',
)
AURORA_URL = 'https://control-qa.cdnetworks.com'
# NODEs
SEL_NODEURL1 = 'http://win-node.cdnetworks.com:5555/wd/hub/' # WIN-IE
SEL_NODEURL2 = 'http://linux-node.cdnetworks.com:5555/wd/hub/' # LINUX-FF
SEL_NODEURL3 = 'http://win-node.cdnetworks.com:6666/wd/hub/' # WIN-CHROME
SEL_NODEURL4 = 'http://win-node.cdnetworks.com:7777/wd/hub/' # WIN-SAFARI
SEL_NODEURL5 = 'http://mac-node.cdnetworks.com:7777/wd/hub/'  # MAC-SAFARI
# Drivers
PJ_DRIVER = '/root/phantomjs-2.1.1-linux-x86_64/bin/phantomjs'
# DBs
NGPDB_URL = 'ngpdb-qa.cdngp.net'
NGPDB_USER = 'root'
NGPDB_PASS = 'P@ssword!1'
CDB_URL = 'cdb-qa.cdnetworks.com'
CDB_USER = 'root'
CDB_PASS = 'P@ssword!1'
BE_HOST = '10.40.210.240'
# OPENAPI
OPENAPI_URL = 'https://openapi-qa.cdnetworks.com'
# SVN
SVN_URL = 'http://svn-qa.cdngp.net/svn/'
# SSH KEY
SSH_OPG_KEY = BASE_PATH + '/selenium_test/self_prov/files/ssh/opg-key'