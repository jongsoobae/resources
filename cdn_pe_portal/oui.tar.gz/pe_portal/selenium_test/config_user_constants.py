import os
OUI_INTERNAL_USER = {
    'username': 'jungho.park',
    'password': 'cdnadmin'
}

OUI_SUPER_USER = {
    'username': 'jungho.park',
    'password': 'cdnadmin'
}

OUI_NO_SUPER_USER = {
    'username': 'jongsoo.bae@cdnetworks.com',
    'password': '1qazxc'
}

AURORA_USER = {
    'email': 'injune99@hotmail.com',
    'user_pk': 6901,
    'ckey': 1664,
}

PRISM_API_USER = {
    'username': os.environ.get('PRISM_API_USER_NAME', 'aurorauser'),
    'password': os.environ.get('PRISM_API_USER_PASS', 'cdn!@admin')
}

SELF_PROV_USER = { 
    'USER_WITH_NO_PRIV': 'test_no_priv@gala.cdn.com',
    'USER_WITH_MASTER_PRIV': 'test_master_priv@gala.cdn.com',

    'USER_WITH_CA_VIEW_ONLY_PRIV': 'test_ca_view_only_priv@gala.cdn.com',
    'USER_WITH_CA_EDIT_PRIV': 'test_ca_edit_priv@gala.cdn.com',
    'USER_WITH_CA_ADD_EDIT_PRIV': 'test_ca_add_edit_priv@gala.cdn.com',

    'USER_WITH_CA_SSL_VIEW_ONLY_PRIV': 'test_ca_ssl_view_only_priv@gala.cdn.com',
    'USER_WITH_CA_SSL_EDIT_PRIV': 'test_ca_ssl_edit_priv@gala.cdn.com',
    'USER_WITH_CA_SSL_ADD_EDIT_PRIV': 'test_ca_ssl_add_edit_priv@gala.cdn.com',

    'USER_WITH_DWA_VIEW_ONLY_PRIV': 'test_dwa_view_only_priv@gala.cdn.com',
    'USER_WITH_DWA_EDIT_PRIV': 'test_dwa_edit_priv@gala.cdn.com',
    'USER_WITH_DWA_ADD_EDIT_PRIV': 'test_dwa_add_edit_priv@gala.cdn.com',

    'USER_WITH_DWA_SSL_VIEW_ONLY_PRIV': 'test_dwa_ssl_view_only_priv@gala.cdn.com',
    'USER_WITH_DWA_SSL_EDIT_PRIV': 'test_dwa_ssl_edit_priv@gala.cdn.com',
    'USER_WITH_DWA_SSL_ADD_EDIT_PRIV': 'test_dwa_ssl_add_edit_priv@gala.cdn.com',

    'PASSWORD': 'test!@dmin'
}

NO_SELF_USER = {
    'USER_WITH_NO_PRIV': 'tst_no_piv@jimdo.cdn.com',
    'USER_WITH_MASTER_PRIV': 'tst_master_piv@jimdo.cdn.com',

    'USER_WITH_CA_VIEW_ONLY_PRIV': 'test_ca_view_only_priv@jimdo.cdn.com',
    'USER_WITH_CA_EDIT_PRIV': 'tst_ca_edit_priv@jimdo.cdn.com',
    'USER_WITH_CA_ADD_EDIT_PRIV': 'tst_ca_add_edit_priv@jimdo.cdn.com',

    'USER_WITH_DWA_VIEW_ONLY_PRIV': 'tst_dwa_view_only_priv@jimdo.cdn.com',
    'USER_WITH_DWA_EDIT_PRIV': 'tst_dwa_edit_priv@jimdo.cdn.com',
    'USER_WITH_DWA_ADD_EDIT_PRIV': 'tst_dwa_add_edit_priv@jimdo.cdn.com',

    'USER_WITH_MASTER_PRIV_LEGACY_CETIZEN': 'tst_master_priv@cetizen.cdn.com',
    'USER_WITH_MASTER_PRIV_LEGACY_MEGAFON': 'tst_master_priv@megafon.cdn.com',

    'PASSWORD': 'test!@dmin'
}

ANOTHER_SELF_USER = {
    'USER_WITH_CA_ADD_EDIT_PRIV': 'test_master_priv@pvh.cdn.com',
    'USER_WITH_DWA_ADD_EDIT_PRIV': 'test_master_priv@pvh.cdn.com',

    'PASSWORD': 'test!@dmin'
}

