import os
import sys
import re
import unittest
import logging
selenium_logger = logging.getLogger('selenium.webdriver.remote.remote_connection')
selenium_logger.setLevel(logging.WARNING)
logging.getLogger('django.db.backends').setLevel(logging.WARNING)

sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'ui.oui.settings'

from ci.common.models.cache import Band
from selenium_test import SeleniumTestCase


PK_REGEX = '\d+(?=\/)'
BAND_STATUS_OBJ = {
    '0': {'class': 'band-status-add', 'label': 'Only v4'},
    '1': {'class': 'band-status-synced', 'label': 'Synced'},
    '2': {'class': 'band-status-nsynced', 'label': 'Need to Sync'},
    '3': {'class': 'band-status-v6', 'label': 'v6'}
}


class TestBandV6Status(SeleniumTestCase):
    def setUp(self):
        #  if need, use this.
        #  self.base_url = ''

        #  changeable data  #
        #  end
        self.oui_login(oui_url=self.base_url)

    def tearDown(self):
        self.driver.quit()

    def test_list(self):
        driver = self.driver
        self.go_list_page()

        status_set = set()
        for element in driver.find_elements_by_css_selector('#result_list tr'):
            href = element.find_element_by_css_selector('th > a').get_attribute('href').split('/admin/oui/band/')[1]
            try:
                pk = re.findall(PK_REGEX, href)[0]
            except IndexError:
                continue
            v6_status = Band.objects.get(pk=pk).get_v6_sync_status()
            next_element = element.find_element_by_css_selector('td')
            self.assertEqual(next_element.text, BAND_STATUS_OBJ[str(v6_status)]['label'])
            self.assertNotEqual(next_element.text, 'v6')
            status_set.add(next_element.text)

        driver.find_element_by_css_selector('#param_show_v6').click()
        driver.find_element_by_css_selector('input[type="submit"][value="Search"]').click()

        if 'synced' in status_set or 'Need to Sync' in status_set:
            status_set = set()
            for status_element in driver.find_elements_by_css_selector('#result_list tr td'):
                status_set.add(status_element.text)
            self.assertIn('v6', status_set)

    def test_edit(self):
        driver = self.driver
        self.go_list_page(v6=True)
        #for element in driver.find_elements_by_css_selector('#result_list tr'):

    def go_list_page(self, v6=False):
        self.driver.get(self.base_url + '/admin/oui/band/')
        self.wait_for_element_by_css_selector('input[type=submit]')
        if v6:
            self.driver.find_element_by_css_selector('#param_show_v6').click()
            self.driver.find_element_by_css_selector('input[type="submit"][value="Search"]').click()


if __name__ == '__main__':
    unittest.main()
