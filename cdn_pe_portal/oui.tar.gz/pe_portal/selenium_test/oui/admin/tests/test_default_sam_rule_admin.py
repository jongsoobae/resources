import unittest

from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import OUI_INTERNAL_USER, OUI_NO_SUPER_USER
from selenium_test.shared_components.login import OUILogin
from selenium_test.shared_components.utils import get_web_driver
from selenium_test.config_constants import OUI_URL

class OUIDefaultSAMRuleAdminTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()

    def tearDown(self):
        self.driver.quit()

    def test_edit_default_sam_rule_admin(self):
        # for super user
        OUILogin(self.driver).login_with(OUI_INTERNAL_USER)
        driver = self.driver
        driver.get(OUI_URL + "/admin/oui/samdefaultrule/1/")
        driver.find_element(By.XPATH, ".//input[@type='submit']").click()
        el = driver.find_element_by_class_name('info')
        self.assertIn('was changed successfully', el.text)

    def test_view_history_default_sam_rule_admin(self):
        # for super user
        OUILogin(self.driver).login_with(OUI_INTERNAL_USER)
        driver = self.driver
        driver.get(OUI_URL + "/admin/oui/samdefaultrule/1/history")
        el = driver.find_element_by_class_name('colM')
        self.assertIn('Change history', el.text)

if __name__ == '__main__':
    unittest.main()
