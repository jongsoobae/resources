import unittest

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import OUI_INTERNAL_USER, OUI_NO_SUPER_USER
from selenium_test.shared_components.login import OUILogin
from selenium_test.shared_components.utils import get_web_driver
from selenium_test.config_constants import OUI_URL

class OUIFastMonManageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        self.customer_name = 'CDNet internal system'
        self.service_name = 'n3: CS: Global Premium'
        self.service_name_invalid = 'sts: stage_service'

    def tearDown(self):
        self.driver.quit()

    def test_view_admin_add_delete_fastmon(self):
        # for super user
        OUILogin(self.driver).login_with(OUI_INTERNAL_USER)

        print "test_view_admin_add_delete_fastmon"
        driver = self.driver
        driver.get(OUI_URL + "/admin/oui/fastmoncustomerprefix/")
        driver.find_element_by_xpath("(//a[contains(text(),'Add fastmon customer prefix')])").click()

        Select(driver.find_element(By.ID, "id_customer")).select_by_visible_text(self.customer_name)
        Select(driver.find_element(By.ID, "id_service")).select_by_visible_text(self.service_name)

        driver.find_element(By.XPATH, ".//input[@type='submit']").click()

        obj = driver.find_element(By.XPATH, "//a[contains(text(), '%s')]"%self.service_name)
        obj.click()
        obj = driver.find_element(By.XPATH, "//a[contains(@href, 'delete')]")
        obj.click()
        driver.find_element(By.XPATH, ".//input[@type='submit']").click()

    def test_check_validation_fastmon(self):
        # for super user
        OUILogin(self.driver).login_with(OUI_INTERNAL_USER)

        print "test_check_validation_fastmon"
        driver = self.driver
        driver.get(OUI_URL + "/admin/oui/fastmoncustomerprefix/")
        driver.find_element_by_xpath("(//a[contains(text(),'Add fastmon customer prefix')])").click()

        Select(driver.find_element(By.ID, "id_customer")).select_by_visible_text(self.customer_name)
        Select(driver.find_element(By.ID, "id_service")).select_by_visible_text(self.service_name_invalid)

        driver.find_element(By.XPATH, ".//input[@type='submit']").click()
        el = driver.find_element_by_class_name('errorlist')
        self.assertEqual(el.text, 'This service is not serviced for this customer')

    def test_check_validation_no_superuser_fastmon(self):
        # for super user
        OUILogin(self.driver).login_with(OUI_NO_SUPER_USER)

        print "test_check_validation_no_superuser_fastmon"
        driver = self.driver
        #from nose.tools import set_trace; set_trace()
        driver.get(OUI_URL + "/admin/oui/fastmoncustomerprefix/")

        driver.find_element(By.XPATH, "//h1[contains(text(), 'Permission denied')]")


if __name__ == '__main__':
    unittest.main()
