import os, sys
import unittest

sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'ui.oui.settings'

from ci.common.models import NodeIP
from ui.oui.views.node import get_v6_node_ips_for_node


class TestNode(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_get_v6_node_ips_for_node(self):
        node_ids = NodeIP.objects.filter(is_v6=True).values_list('node_id', flat=True)

        for node_id in node_ids:
            self.assertNotEqual([], get_v6_node_ips_for_node(node_id))

        node_ids_v4 = NodeIP.objects.exclude(node__in=node_ids).values_list('node_id', flat=True)

        for node_id_v4 in node_ids_v4:
            self.assertEqual([], get_v6_node_ips_for_node(node_id_v4))


if __name__ == '__main__':
    unittest.main()
