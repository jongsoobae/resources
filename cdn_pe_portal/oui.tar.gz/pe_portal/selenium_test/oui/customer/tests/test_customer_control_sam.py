import os
import sys
import time

sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'ui.oui.settings'
from selenium_test import SeleniumTestCase


class CustomerControlSam(SeleniumTestCase):
    def setUp(self):
        self.customer_id = 5
        self.oui_login(oui_url=self.base_url)

    def tearDown(self):
        self.deselect_all_ccs()
        self.driver.find_element_by_css_selector('#ccs_btn_save').click()
        self.assertIn('Saved', self.driver.find_element_by_css_selector('.css_status_msg_str').text)
        self.driver.quit()

    def test(self):
        driver = self.driver
        self.go_test_page()

        condition_strs = ['RPC', 'STR', 'INT']
        for _str in condition_strs:
            self.click_condition(_str)

        action_strs = ['URC', 'BYP']
        for _str in action_strs:
            self.click_action(_str)

        driver.find_element_by_css_selector('#ccs_btn_save').click()
        self.assertIn('Saved', self.driver.find_element_by_css_selector('.css_status_msg_str').text)

        time.sleep(3)

        self.go_test_page()

        for _str in condition_strs:
            self.assertTrue(self.is_selected_item(_str))
        for _str in action_strs:
            self.assertTrue(self.is_selected_item(_str))

        time.sleep(1)
        self.deselect_all_ccs()

        for _str in condition_strs:
            self.assertFalse(self.is_selected_item(_str))
        for _str in action_strs:
            self.assertFalse(self.is_selected_item(_str))

        time.sleep(1)
        driver.find_element_by_css_selector('#ccs_btn_reset').click()
        for _str in condition_strs:
            self.assertTrue(self.is_selected_item(_str))
        for _str in action_strs:
            self.assertTrue(self.is_selected_item(_str))

    def deselect_all_ccs(self):
        for close_btn in self.driver.find_elements_by_css_selector('.search-choice-close'):
            close_btn.click()

    def click_condition(self, rule_item_str_id):
        self.driver.find_element_by_css_selector('#id_sam_conditions_chosen').click()
        for res in self.driver.find_elements_by_css_selector('li.active-result'):
            if str(res.text) == str(rule_item_str_id):
                res.click()

    def is_selected_item(self, rule_item_str_id):
        for selected in self.driver.find_elements_by_css_selector('ul.chosen-choices > li.search-choice > span'):
            if str(rule_item_str_id) == str(selected.text):
                return True
        return False

    def click_action(self, rule_item_str_id):
        self.driver.find_element_by_css_selector('#id_sam_actions_chosen').click()
        for res in self.driver.find_elements_by_css_selector('li.active-result'):
            if str(res.text) == str(rule_item_str_id):
                res.click()

    def go_test_page(self):
        self.driver.get('%s/customer/%s/' % (self.base_url, str(self.customer_id)))

    def go_UIP_admin(self):
        self.driver.get('%s/sam/admin/#/edit/11/' % self.base_url)

if __name__ == '__main__':
    import unittest
    unittest.main()
