__author__ = 'junghopark'

import os, sys
import unittest

sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'api.settings'

from ci.common.models.site import SiteDraft, Site
from ci.common.utils.flush_api import list_flush_by_pad,flush_detail_by_req_id, flush_detail_by_repo_id


def set_pad_optimal_ratio(optimal_ratio, site_obj):
    site_obj.optimal_ratio = optimal_ratio
    site_obj.save()


def set_pad_use_fast_flush(use_fast_flush, site_obj):
    site_obj.use_fast_flush = use_fast_flush
    site_obj.save()


class TestInputValidate(unittest.TestCase):
    def setUp(self):
        self.pad_id = 80
        self.request_id = 11
        self.optimal_ratio = 10
        self.site = Site.objects.get(pk=self.pad_id)
        pass

    def tearDown(self):
        pass

    def test_list_flush_by_pad_with_not_use_fast_flush(self):
        #from nose.tools import set_trace; set_trace()
        set_pad_optimal_ratio(self.optimal_ratio, self.site)
        set_pad_use_fast_flush(False, self.site)

        not_cnt_optimal = 0
        flush_list = list_flush_by_pad(self.site)
        for obj in flush_list:
            if float(obj['percent']) >= self.optimal_ratio:
                not_cnt_optimal = not_cnt_optimal + 1

        set_pad_optimal_ratio(self.optimal_ratio, self.site)
        set_pad_use_fast_flush(True, self.site)

        cnt_optimal = 0
        flush_list = list_flush_by_pad(self.site)
        for obj in flush_list:
            if float(obj['percent']) >= 100.0:
                cnt_optimal = cnt_optimal + 1

        self.assertEqual(cnt_optimal,not_cnt_optimal)

    def test1_list_flush_by_pad_with_use_fast_flush_and_optimal_ratio_95(self):
        #from nose.tools import set_trace; set_trace()
        set_pad_optimal_ratio(self.optimal_ratio, self.site)
        set_pad_use_fast_flush(False, self.site)

        flush_obj = flush_detail_by_req_id(self.request_id)
        flag_apply = False
        if float(flush_obj['percent']) >= self.optimal_ratio:
            flag_apply = True

        set_pad_optimal_ratio(self.optimal_ratio, self.site)
        set_pad_use_fast_flush(True, self.site)

        flush_obj = flush_detail_by_req_id(self.request_id)
        if flag_apply == True and float(flush_obj['percent']) < 100.0:
            assert False


if __name__ == '__main__':
    unittest.main()
