import os
import sys

sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'ui.oui.settings'
from selenium_test import SeleniumTestCase
from selenium.common.exceptions import NoAlertPresentException


class SiteEditPageTest(SeleniumTestCase):

    def setUp(self):
        #  if need, use this.
        #  self.base_url = ''

        #  later, if we have CI, change this.
        self.site_id = 15553

        self.field_detail = {
            'max_age_rules': ('Caching', 'Cache Controller max-age rules'),
            'content_variation_rules': ('Caching', 'Content Variation Rules'),
            'custom_headers': ('Rules for Requests to Origin', 'Custom Headers to Origin'),
            'pass_thru_headers_to_origin': ('Rules for Requests From Users', 'Pass through headers to origin'),
            'pass_thru_headers_to_user': ('Rules for Response to Users', 'Pass through headers to user'),
            'rewrite_rules': ('Rewrite Rules', 'Regex Rewrite Rules (URI)'),
            'rewrite_rules_post_validation': ('Rewrite Rules', 'Regex Rewrite Rules after validation'),
            'full_url_rewrite_rules': ('Rewrite Rules', 'Regex Rewrite Rules (Full URL)'),
            'referrer_list': ('Referrer Rules', 'Referrer list'),
            'validation_custom_headers': ('Validation Scheme', 'Validation Custom Headers'),
            'tag_skip_patterns': ('URL Tag Validation', 'URI pattern to skip tag validation')
        }

        self.login()

    def tearDown(self):
        self.driver.quit()

    def test_show_linefeed_in_detail(self):
        driver = self.driver
        self.go_edit_page()

        map(lambda (elem): elem.click(), driver.find_elements_by_css_selector('.separator'))

        for key in self.field_detail.keys():
            element = driver.find_element_by_css_selector('#id_' + key)
            element.clear()
            element.send_keys('\nnewline\nnewline test')

        driver.find_element_by_css_selector('input[type=submit][value=save]').click()

        alert = driver.switch_to.alert
        for k, (tab, field_name) in self.field_detail.items():
            self.assertIn(field_name, alert.text)
        self.assertIn('Above fields have blank character.', alert.text)
        driver.switch_to.alert.accept()
        self.wait_for_element_by_css_selector('#pad_group_Validation')

        for k, (tab, field_name) in self.field_detail.items():
            value = driver.find_element_by_xpath(
                "//th[contains(text(), '%s')]" % field_name
            ).find_element_by_xpath('../td').text
            self.assertIn('newline\nnewline test', value)

    def test_show_alert_when_edit_with_blank(self):
        driver = self.driver
        self.go_edit_page()

        map(lambda (elem): elem.click(), driver.find_elements_by_css_selector('.separator'))
        for key in self.field_detail.keys():
            element = driver.find_element_by_css_selector('#id_' + key)
            element.send_keys(' aaa bbb')

        driver.find_element_by_css_selector('input[type=submit][value=save]').click()
        try:
            driver.switch_to.alert.dismiss()
        except NoAlertPresentException:
            self.assertTrue(False, 'Field have blank character, but no alert.')

    def go_edit_page(self):
        self.driver.get(self.base_url + '/site/%s/edit/' % str(self.site_id))
        self.wait_for_element_by_css_selector('form[name=site_edit_form]')

    def login(self):
        self.login_done = False
        if not self.login_done:
            self.oui_login(oui_url=self.base_url)
            self.login_done = True


if __name__ == '__main__':
    import unittest
    unittest.main()
