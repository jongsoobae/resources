import unittest
import requests


BASE_URL = 'http://10.40.196.147:8089'
ID = 'jungho.park'
PW = 'cdnadmin'
API_URL = '%s/rest/int/%s:%s/get' % (BASE_URL, ID, PW)


class TestSiteAPI(unittest.TestCase):
    def setUp(self):
        self.api_url = '%s/%s/?page_size=10' % (API_URL, 'site')

    def tearDown(self):
        pass

    def test_get_site_api(self):
        res = requests.get(self.api_url)
        self.assertEqual(res.status_code, 200)
        self.assertIn('total_count', res.json()['data'])
        self.assertIn('object_list', res.json()['data'])
        self.assertIn('filtered_fields', res.json()['data'])
        self.assertIn('is_paginated', res.json()['data'])
        self.assertIn('page_obj', res.json()['data'])

        self.assertEqual(type(res.json()['data']['total_count']), int)
        self.assertEqual(type(res.json()['data']['object_list']), list)
        self.assertEqual(type(res.json()['data']['filtered_fields']), dict)
        self.assertEqual(type(res.json()['data']['is_paginated']), bool)
        self.assertEqual(type(res.json()['data']['page_obj']), unicode)

        if len(res.json()['data']['object_list']) >= 1:
            self.assertIn('cname_prefix', res.json()['data']['object_list'][0])
            self.assertIn('pad', res.json()['data']['object_list'][0])
            self.assertIn('product_id', res.json()['data']['object_list'][0])
            self.assertIn('upstream_ssl', res.json()['data']['object_list'][0])
            self.assertIn('dns_entry_existing_time_limit', res.json()['data']['object_list'][0])
            self.assertIn('drop_params_post_validation', res.json()['data']['object_list'][0])
            self.assertIn('pass_thru_headers_to_origin', res.json()['data']['object_list'][0])

    def test_get_site_api_with_param(self):
        api_url = '%s&product=3' % self.api_url
        res = requests.get(api_url)
        self.assertEqual(res.status_code, 200)
        self.assertIn('product', res.json()['data']['filtered_fields'])

    def test_get_site_api_with_wrong_param(self):
        api_url = '%s&product_id=3' % self.api_url
        res = requests.get(api_url)
        self.assertEqual(res.status_code, 200)
        self.assertNotIn('product_id', res.json()['data']['filtered_fields'])


class TestServiceAPI(unittest.TestCase):
    def setUp(self):
        self.api_url = '%s/%s/?page_size=10' % (API_URL, 'service')

    def tearDown(self):
        pass

    def test_get_service_api(self):
        res = requests.get(self.api_url)
        self.assertEqual(res.status_code, 200)
        self.assertIn('total_count', res.json()['data'])
        self.assertIn('object_list', res.json()['data'])
        self.assertIn('filtered_fields', res.json()['data'])
        self.assertIn('is_paginated', res.json()['data'])
        self.assertIn('page_obj', res.json()['data'])

        self.assertEqual(type(res.json()['data']['total_count']), int)
        self.assertEqual(type(res.json()['data']['object_list']), list)
        self.assertEqual(type(res.json()['data']['filtered_fields']), dict)
        self.assertEqual(type(res.json()['data']['is_paginated']), bool)
        self.assertEqual(type(res.json()['data']['page_obj']), unicode)

        if len(res.json()['data']['object_list']) >= 1:
            self.assertIn('dns_prefix', res.json()['data']['object_list'][0])
            self.assertIn('ssl_server_protocols', res.json()['data']['object_list'][0])
            self.assertIn('allow_nonmatching_domains', res.json()['data']['object_list'][0])
            self.assertIn('ssl_cert_id', res.json()['data']['object_list'][0])

    def test_get_service_api_with_param(self):
        api_url = '%s&customer=3' % self.api_url
        res = requests.get(api_url)
        self.assertEqual(res.status_code, 200)
        self.assertIn('customer', res.json()['data']['filtered_fields'])

    def test_get_service_api_with_wrong_param(self):
        api_url = '%s&customer_id=3' % self.api_url
        res = requests.get(api_url)
        self.assertEqual(res.status_code, 200)
        self.assertNotIn('customer_id', res.json()['data']['filtered_fields'])


class TestProductAPI(unittest.TestCase):
    def setUp(self):
        self.api_url = '%s/%s/?page_size=10' % (API_URL, 'product')

    def tearDown(self):
        pass

    def test_get_product_api(self):
        res = requests.get(self.api_url)
        self.assertEqual(res.status_code, 200)
        self.assertIn('total_count', res.json()['data'])
        self.assertIn('object_list', res.json()['data'])
        self.assertIn('filtered_fields', res.json()['data'])
        self.assertIn('is_paginated', res.json()['data'])
        self.assertIn('page_obj', res.json()['data'])

        self.assertEqual(type(res.json()['data']['total_count']), int)
        self.assertEqual(type(res.json()['data']['object_list']), list)
        self.assertEqual(type(res.json()['data']['filtered_fields']), dict)
        self.assertEqual(type(res.json()['data']['is_paginated']), bool)
        self.assertEqual(type(res.json()['data']['page_obj']), unicode)

        if len(res.json()['data']['object_list']) >= 1:
            self.assertIn('cop_product_id', res.json()['data']['object_list'][0])
            self.assertIn('customer_id', res.json()['data']['object_list'][0])
            self.assertIn('product_id', res.json()['data']['object_list'][0])
            self.assertIn('default', res.json()['data']['object_list'][0])

    def test_get_product_api_with_param(self):
        api_url = '%s&customer=3' % self.api_url
        res = requests.get(api_url)
        self.assertEqual(res.status_code, 200)
        self.assertIn('customer', res.json()['data']['filtered_fields'])

    def test_get_product_api_with_wrong_param(self):
        api_url = '%s&customer_id=3' % self.api_url
        res = requests.get(api_url)
        self.assertEqual(res.status_code, 200)
        self.assertNotIn('customer_id', res.json()['data']['filtered_fields'])


class TestCustomerAPI(unittest.TestCase):
    def setUp(self):
        self.api_url = '%s/%s/?page_size=10' % (API_URL, 'customer')

    def tearDown(self):
        pass

    def test_get_customer_api(self):
        res = requests.get(self.api_url)
        self.assertEqual(res.status_code, 200)
        self.assertIn('total_count', res.json()['data'])
        self.assertIn('object_list', res.json()['data'])
        self.assertIn('filtered_fields', res.json()['data'])
        self.assertIn('is_paginated', res.json()['data'])
        self.assertIn('page_obj', res.json()['data'])

        self.assertEqual(type(res.json()['data']['total_count']), int)
        self.assertEqual(type(res.json()['data']['object_list']), list)
        self.assertEqual(type(res.json()['data']['filtered_fields']), dict)
        self.assertEqual(type(res.json()['data']['is_paginated']), bool)
        self.assertEqual(type(res.json()['data']['page_obj']), unicode)

        if len(res.json()['data']['object_list']) >= 1:
            self.assertIn('customer_portal_flag', res.json()['data']['object_list'][0])
            self.assertIn('english_name', res.json()['data']['object_list'][0])
            self.assertIn('china_lic', res.json()['data']['object_list'][0])
            self.assertIn('corp_code', res.json()['data']['object_list'][0])
            self.assertIn('sales_rep_id', res.json()['data']['object_list'][0])

    def test_get_product_api_with_param(self):
        api_url = '%s&sales_rep=3' % self.api_url
        res = requests.get(api_url)
        self.assertEqual(res.status_code, 200)
        self.assertIn('sales_rep', res.json()['data']['filtered_fields'])

    def test_get_product_api_with_wrong_param(self):
        api_url = '%s&sales_rep_id=3' % self.api_url
        res = requests.get(api_url)
        self.assertEqual(res.status_code, 200)
        self.assertNotIn('sales_rep_id', res.json()['data']['filtered_fields'])


if __name__ == '__main__':
    unittest.main()
