__author__ = 'junghopark'

import os, sys
import unittest

sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'ui.oui.settings'

from ci.common.utils.onestat_chart import get_conditions

class TestInputValidate(unittest.TestCase):
    def setUp(self):
        self.stat_id_null = ['2']
        self.stat_id_not_null = ['1','3']
        self.stat_id_conditions = self.stat_id_null + self.stat_id_not_null
        pass

    def tearDown(self):
        pass

    def test_get_conditions_onestat(self):
        data = {'customer': [], 'site_service': [], 'pop': [], 'site': self.stat_id_conditions, 'pop_region': []}
        conditions = get_conditions(data)
        self.assertEqual(conditions['stat_id'], self.stat_id_not_null)

if __name__ == '__main__':
    unittest.main()