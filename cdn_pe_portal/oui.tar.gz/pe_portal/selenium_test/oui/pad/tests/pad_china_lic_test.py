import os
import sys
import time
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.select import Select

sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'ui.oui.settings'
from selenium_test import SeleniumTestCase


class TestPadCNLic(SeleniumTestCase):

    def setUp(self):
        #  if need, use this.
        #  self.base_url = ''

        self.test_pad_id = 5
        self.china_service_id = 15
        self.none_china_service_id = 6
        self.none_china_shield_id = 25
        self.login()

    def tearDown(self):
        self.driver.quit()

    def test(self):
        self.set_china_service_and_test_license()
        self.set_none_china_service_and_test_license()

    def go_test_page(self):
        self.driver.get('%s/site/%s/edit/?section=Basic' % (self.base_url, str(self.test_pad_id)))

    def set_china_service_and_test_license(self):
        driver = self.driver
        self.go_test_page()
        service_select = Select(driver.find_element_by_css_selector('#id_service'))
        service_select.select_by_value(str(self.china_service_id))
        time.sleep(1)
        driver.find_element_by_css_selector('#id_china_lic').clear()
        driver.find_element_by_css_selector('input[type=submit][value=save]').click()
        time.sleep(3)
        self.assertIn('The edge service chosen requires a chinese license', driver.find_element_by_css_selector('ul.errorlist > li').text)

        driver.find_element_by_css_selector('#id_china_lic').send_keys('ICP test')
        driver.find_element_by_css_selector('input[type=submit][value=save]').click()
        time.sleep(3)
        self.assertEqual("ICP test", driver.find_element_by_xpath("//tbody[@id='pad_group_Basic']/tr[20]/td").text)
        time.sleep(1)

    def set_none_china_service_and_test_license(self):
        driver = self.driver
        self.go_test_page()
        service_select = Select(self.driver.find_element_by_css_selector('#id_service'))
        service_select.select_by_value(str(self.none_china_service_id))
        time.sleep(1)
        shield_select = Select(self.driver.find_element_by_css_selector('#id_shielded_service'))
        shield_select.select_by_value(str(self.none_china_shield_id))
        time.sleep(1)
        driver.find_element_by_css_selector('#id_china_lic').clear()
        driver.find_element_by_css_selector('#id_china_lic').send_keys('ICP_test2')
        driver.find_element_by_css_selector('input[type=submit][value=save]').click()
        time.sleep(3)
        self.assertEqual("ICP_test2", driver.find_element_by_xpath("//tbody[@id='pad_group_Basic']/tr[20]/td").text)
        time.sleep(3)

        self.go_test_page()
        service_select = Select(self.driver.find_element_by_css_selector('#id_service'))
        service_select.select_by_value(str(self.none_china_service_id))
        time.sleep(1)
        shield_select = Select(self.driver.find_element_by_css_selector('#id_shielded_service'))
        shield_select.select_by_value(str(self.none_china_shield_id))
        time.sleep(1)
        driver.find_element_by_css_selector('#id_china_lic').clear()
        driver.find_element_by_css_selector('input[type=submit][value=save]').click()
        time.sleep(3)
        self.assertEqual("", driver.find_element_by_xpath("//tbody[@id='pad_group_Basic']/tr[20]/td").text)

    def login(self):
        self.login_done = False
        if not self.login_done:
            self.oui_login(oui_url=self.base_url)
            self.login_done = True


if __name__ == '__main__':
    import unittest
    unittest.main()
