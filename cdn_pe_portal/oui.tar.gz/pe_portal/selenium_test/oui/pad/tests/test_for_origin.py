import os
import sys
import time

from selenium.webdriver.common.keys import Keys

sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'ui.oui.settings'
from selenium_test import SeleniumTestCase
from ci.common.models import Site


class TestSamOrder(SeleniumTestCase):

    def setUp(self):
        #  if need, use this.
        #  self.base_url = ''
        self.test_pad_id = 5
        self.login()

    def tearDown(self):
        self.driver.quit()

    def test_origin_field_ok(self):
        driver = self.driver
        self.go_edit_page()
        driver.find_element_by_css_selector('#header2').click()
        driver.find_element_by_css_selector('#header16').click()

        origin_field = driver.find_element_by_css_selector('#id_origin')
        PAD_ID_field = driver.find_element_by_css_selector('#id_cache_id')
        sam_field = driver.find_element_by_css_selector('#id_server_action_rules_div > textarea')

        # if origin is not ip ok.

        origin_field.clear()
        origin_field.send_keys('origin.cdnetworks.com')
        driver.find_element_by_css_selector('input[type=submit][value=save]').click()

        try:
            driver.find_element_by_css_selector('ul.errorlist > li')
            self.assertTrue(False)
        except:
            self.assertTrue(True)

    def test_origin_field_origin_ip(self):
        site = Site.objects.get(pk=self.test_pad_id)
        site.server_action_rules = ''
        site.save()
        driver = self.driver
        self.go_edit_page()
        time.sleep(2)
        driver.find_element_by_css_selector('#header2').click()

        origin_field = driver.find_element_by_css_selector('#id_origin')
        PAD_ID_field = driver.find_element_by_css_selector('#id_cache_id')

        origin_field.clear()
        origin_field.send_keys('10.10.10.10')
        PAD_ID_field.clear()

        driver.find_element_by_css_selector('input[type=submit][value=save]').click()
        self.assertIn('Input "pad ID" or Use RHO SAM rule for "HOST" on SRQ', driver.find_element_by_css_selector('ul.errorlist > li').text)

    def test_origin_field_origin_ip_and_PAD_ID(self):
        site = Site.objects.get(pk=self.test_pad_id)
        site.server_action_rules = ''
        site.save()
        driver = self.driver
        self.go_edit_page()
        time.sleep(2)
        driver.find_element_by_css_selector('#header2').click()

        origin_field = driver.find_element_by_css_selector('#id_origin')
        PAD_ID_field = driver.find_element_by_css_selector('#id_cache_id')
        origin_field.clear()
        origin_field.send_keys('10.10.10.10')
        PAD_ID_field.clear()
        PAD_ID_field.send_keys('pad_id_test')
        driver.find_element_by_css_selector('input[type=submit][value=save]').click()

        try:
            driver.find_element_by_css_selector('ul.errorlist > li')
            self.assertTrue(False)
        except:
            self.assertTrue(True)

    def test_origin_field_origin_ip_and_SAM(self):
        site = Site.objects.get(pk=self.test_pad_id)
        site.server_action_rules = '[{"proc":"1","name":"Pass through Host header","do":[{"id":"RHO","on":"SRQ","h":"Host","mode":"1","value":"fixed custom host header"}]}]'
        site.save()
        driver = self.driver
        self.go_edit_page()
        time.sleep(2)
        driver.find_element_by_css_selector('#header2').click()

        origin_field = driver.find_element_by_css_selector('#id_origin')
        PAD_ID_field = driver.find_element_by_css_selector('#id_cache_id')
        origin_field.clear()
        origin_field.send_keys('10.10.10.10')
        PAD_ID_field.clear()
        driver.find_element_by_css_selector('input[type=submit][value=save]').click()

        try:
            driver.find_element_by_css_selector('ul.errorlist > li')
            self.assertTrue(False)
        except:
            self.assertTrue(True)

    def go_edit_page(self):
        self.driver.get('%s/site/%s/edit/?section=Basic' % (self.base_url, str(self.test_pad_id)))
        time.sleep(2)

    def login(self):
        self.login_done = False
        if not self.login_done:
            self.oui_login(oui_url=self.base_url)
            self.login_done = True


if __name__ == '__main__':
    import unittest
    unittest.main()
