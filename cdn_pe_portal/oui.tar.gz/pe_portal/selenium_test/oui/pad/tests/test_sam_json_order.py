import os
import sys
import time
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys

sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'ui.oui.settings'
from selenium_test import SeleniumTestCase


class TestSamOrder(SeleniumTestCase):

    def setUp(self):
        #  if need, use this.
        #  self.base_url = ''

        self.test_pad_id = 5
        self.test_data = '[{"if": {"id": "RPC"},"do": [{"id": "OHO"}, {"id": "RFR","on": "URQ","type": "0"}],"proc": "0","name": "test"}]'

        self.login()

    def tearDown(self):
        for delete_link in self.driver.find_elements_by_css_selector('a.btn_delete'):
            delete_link.click()
            self.driver.switch_to.alert.accept()

        self.driver.quit()

    def test_sam_order(self):
        driver = self.driver
        self.go_test_page()
        server_action_rules = driver.find_element_by_css_selector('#id_server_action_rules_div > textarea')
        server_action_rules.clear()
        server_action_rules.send_keys(Keys.CONTROL + "a")
        server_action_rules.send_keys(Keys.BACK_SPACE)
        server_action_rules.send_keys(self.test_data)
        driver.find_element_by_css_selector('input[type=submit][value=save]').click()
        time.sleep(4)
        driver.find_element_by_css_selector('input[type=submit][name=revert_sandbox]').click()
        time.sleep(2)
        driver.find_element_by_css_selector('a.btn_edit').click()
        driver.find_element_by_xpath("(//a[contains(text(),'Save')])[3]").click()
        time.sleep(1)
        driver.find_element_by_link_text('Back to list').click()

        try:
            driver.find_element_by_css_selector('input[type=submit][name=revert_sandbox]')
            self.fail('test failed.')
        except NoSuchElementException:
            self.assertTrue(True)

    def go_test_page(self):
        self.driver.get('%s/site/%s/edit/?section=Misc' % (self.base_url, str(self.test_pad_id)))

    def login(self):
        self.login_done = False
        if not self.login_done:
            self.oui_login(oui_url=self.base_url)
            self.login_done = True


if __name__ == '__main__':
    import unittest
    unittest.main()
