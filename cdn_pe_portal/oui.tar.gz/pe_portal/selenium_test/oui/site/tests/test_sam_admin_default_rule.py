import unittest
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from selenium_test.config_user_constants import OUI_INTERNAL_USER
from selenium_test.shared_components.login import OUILogin
from selenium_test.shared_components.utils import get_web_driver
from selenium_test.config_constants import OUI_URL
import time

SAMPLE_SAM_RULE = """{
    "do": [
        {
            "id": "OHO",
            "on": "URQ",
            "h": "Set-Cookie",
            "mode": "1",
            "value": "SPEEDCDN=%{_RANDOM_}"
        },
        {
            "id": "RFR",
            "on": "URQ",
            "type": "2",
            "redirect": "%{_INITIAL_URL_}"
        }
    ],
    "proc": "1",
    "name": "Add Set-Cooke and 302 Redirect to Initial URL",
    "if": {
        "c": [
            {
                "c": "SPEEDCDN",
                "caseSens": "false",
                "m": ".*",
                "not": "true",
                "x": "true",
                "nullOk": "false",
                "id": "RQC"
            },
            {
                "m": "^.*\\.(ico|js|css|txt|png|jpeg|jpg|gif|swf|xml|zip).*",
                "mode": "0",
                "not": "true",
                "x": "true",
                "nullOk": "false",
                "id": "URL"
            }
        ],
        "id": "AND"
    }
}"""

class OUISiteSAMDefaultRuleTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()

    def tearDown(self):
        self.driver.quit()

    def test_edit_default_sam_rule_ok(self):
        OUILogin(self.driver).login_with(OUI_INTERNAL_USER)
        driver = self.driver
        driver.get("%s/admin/oui/samdefaultrule/1/" % (OUI_URL))
        el1 = driver.find_element(By.ID, "id_rule_name")
        el1.clear()
        el1.send_keys("rule name test by script")

        el = driver.find_element(By.ID, "id_server_action_rule")
        el.clear()
        el.send_keys(SAMPLE_SAM_RULE)
        #el.submit()
        driver.find_element(By.XPATH, ".//input[@value='Save and continue editing']").click()

        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, '//div/ul/li'))
        )

        el = driver.find_element_by_xpath('//div/ul/li')
        print el.text
        #self.assertIn('The SAM Default 302', el.text)




if __name__ == '__main__':
    unittest.main()