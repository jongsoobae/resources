import unittest
import time
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from selenium_test.config_user_constants import OUI_INTERNAL_USER
from selenium_test.shared_components.login import OUILogin
from selenium_test.shared_components.utils import get_web_driver
from selenium_test.config_constants import OUI_URL

class OUISiteDDosRuleConvertTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        self.site_id = '111'
        self.max_wait_seconds = 10

    def tearDown(self):
        self.driver.quit()

    def test_convert_site_ddos_rule(self):
        OUILogin(self.driver).login_with(OUI_INTERNAL_USER)
        driver = self.driver
        driver.get("%s/sites/ddos-rule/" % (OUI_URL))
        el = driver.find_element(By.ID, "convert-"+self.site_id)
        previous_value = el.get_attribute('value')
        #
        el.click()
        alert = driver.switch_to_alert()
        alert.accept()
        total_wait_seconds = 0
        while (not self.is_convert_done(el.get_attribute('value'))):
            time.sleep(1)
            total_wait_seconds += 1
            if total_wait_seconds > self.max_wait_seconds:
                break

        assert(previous_value != el.get_attribute('value'))

    def test_convert_site_302_sam_rule(self):
        OUILogin(self.driver).login_with(OUI_INTERNAL_USER)
        driver = self.driver
        driver.get("%s/sites/ddos-rule/" % (OUI_URL))
        el = driver.find_element(By.ID, "sam_convert-"+self.site_id)
        previous_value = el.get_attribute('value')
        #
        el.click()
        alert = driver.switch_to_alert()
        alert.accept()
        total_wait_seconds = 0
        while (not self.is_convert_done(el.get_attribute('value'))):
            time.sleep(1)
            total_wait_seconds += 1
            if total_wait_seconds > self.max_wait_seconds:
                break

        assert(previous_value != el.get_attribute('value'))

    def is_convert_done(self, value):
        return 'waiting' != value