import unittest
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from selenium_test.config_user_constants import OUI_INTERNAL_USER
from selenium_test.shared_components.login import OUILogin
from selenium_test.shared_components.utils import get_web_driver
from selenium_test.config_constants import OUI_URL

class OUISiteDDosRuleAddDeleteTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        self.site_id = '58786'

    def tearDown(self):
        self.driver.quit()

    def test_delete_site_ddos_rule(self):
        """
        should be run after test_add_site_ddos_rule test run
        :return:
        """
        OUILogin(self.driver).login_with(OUI_INTERNAL_USER)
        driver = self.driver
        driver.get("%s/site/%s/" % (OUI_URL, self.site_id))
        driver.find_element(By.XPATH, ".//input[@id='id_delete_ddos_rule']").click()
        alert = driver.switch_to_alert()
        alert.accept()

        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, './/input[@value="Add rule and Save"]'))
        )
        el = driver.find_element_by_xpath('.//input[@value="Add rule and Save"]')

    def test_add_site_ddos_rule(self):
        OUILogin(self.driver).login_with(OUI_INTERNAL_USER)
        driver = self.driver
        driver.get("%s/site/%s/" % (OUI_URL, self.site_id))
        el = driver.find_element(By.ID, "id_description")
        el.clear()
        el.send_keys('add test')
        driver.find_element(By.XPATH, ".//input[@value='Add rule and Save']").click()
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, '//div[@id="messages"]'))
        )
        el = driver.find_element_by_xpath('//div[@id="messages"]')
        self.assertIn('The convert rule set has been saved to this domain', el.text)


if __name__ == '__main__':
    unittest.main()
