import unittest
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from selenium_test.config_user_constants import OUI_INTERNAL_USER
from selenium_test.shared_components.login import OUILogin
from selenium_test.shared_components.utils import get_web_driver
from selenium_test.config_constants import OUI_URL


class OUISiteDDosRuleEditTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        self.site_id = '111'

    def tearDown(self):
        self.driver.quit()

    def test_edit_site_ddos_rule_with_shield_selection(self):
        OUILogin(self.driver).login_with(OUI_INTERNAL_USER)
        driver = self.driver
        driver.get("%s/site/%s/" % (OUI_URL, self.site_id))
        select = Select(driver.find_element_by_xpath('//select[@id="id_edge_prefix_on_ddos"]'))
        select.select_by_index(2)
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, '//select[@id="id_shielded_prefix_on_ddos"]/option[@value=""]'))
        )
        select = Select(driver.find_element_by_xpath('//select[@id="id_shielded_prefix_on_ddos"]'))
        select.select_by_index(1)
        el = driver.find_element(By.ID, "id_description")
        el.clear()
        el.send_keys('change edge shield prefix')
        driver.find_element(By.XPATH, ".//input[@value='Edit rule and Save']").click()
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, '//div[@id="messages"]'))
        )
        el = driver.find_element_by_xpath('//div[@id="messages"]')
        self.assertIn('The convert rule set has been saved to this domain', el.text)

    def test_edit_site_ddos_rule_with_prefix_validate_failed(self):
        OUILogin(self.driver).login_with(OUI_INTERNAL_USER)
        driver = self.driver
        driver.get("%s/site/%s/" % (OUI_URL, self.site_id))

        el = driver.find_element(By.ID, "id_automated_service_prefix_change")
        el.click()

        select = Select(driver.find_element_by_xpath('//select[@id="id_edge_prefix_on_ddos"]'))
        #selected_value = select.all_selected_options[0].get_attribute('value')
        #print selected_value
        #selected_index = 0;
        #for option in select.options:
        #    value = option.get_attribute('value')
        #    if value == selected_value:
        #        break
        #    selected_index += 1
        select.select_by_index(0)
        #from nose.tools import set_trace; set_trace()
        driver.find_element(By.XPATH, ".//input[@value='Edit rule and Save']").click()
        try:
            WebDriverWait(driver, 20).until(
                EC.presence_of_element_located((By.XPATH, '//div/form/ul/li'))
            )
        except:
            try:
                alert = driver.switch_to_alert()
                alert.accept()
            except:
                pass

        el = driver.find_element_by_xpath('//div/form/ul/li')
        self.assertIn('Validation failed', el.text)


if __name__ == '__main__':
    unittest.main()