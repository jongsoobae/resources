#!/usr/bin/python
# -*- coding: utf-8 -*-
import unittest, time, os, sys
import datetime
sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'ui.oui.settings'

from ci.common.models.cdn import Service
from ci.common.models.customer import SSLKeystore
from ci.common.models.sni import SNIGroup
from ui.oui.views.sni_group import get_sni_group_detail, get_sni_group_list, get_sni_cert_list, get_sni_service_list, \
    save_sni_group, delete_sni_group


class SNITest(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_get_sni_group_detail(self):
        sni_groups = SNIGroup.objects.all()
        if not sni_groups.exists():
            # don't need test
            return
        res = get_sni_group_detail(sni_groups[0].pk, get_detail=True)
        self.assertIsNotNone(res)
        self.assertIn('sni_group_id', res)
        self.assertIn('description', res)
        self.assertIn('service_count', res)
        self.assertIn('services', res)
        self.assertIn('cert_count', res)
        self.assertIn('certs', res)

        res = get_sni_group_detail(sni_groups[0].pk, get_detail=False)
        self.assertIsNotNone(res)
        self.assertIn('sni_group_id', res)
        self.assertIn('sni_group_name', res)
        self.assertIn('description', res)
        self.assertNotIn('service_count', res)
        self.assertNotIn('services', res)
        self.assertNotIn('cert_count', res)
        self.assertNotIn('certs', res)

    def test_get_sni_group_list(self):
        sni_groups = SNIGroup.objects.all()
        sni_groups_count = sni_groups.count()

        res = get_sni_group_list(get_count=True)
        self.assertEqual(list, type(res))
        self.assertEqual(sni_groups_count, len(res))
        if sni_groups_count >= 1:
            self.assertIn('sni_group_id', res[0])
            self.assertIn('sni_group_name', res[0])
            self.assertIn('description', res[0])
            self.assertIn('service_count', res[0])
            self.assertIn('cert_count', res[0])

        res = get_sni_group_list(get_count=False)
        self.assertEqual(list, type(res))
        self.assertEqual(sni_groups_count, len(res))
        if sni_groups_count >= 1:
            self.assertIn('sni_group_id', res[0])
            self.assertIn('sni_group_name', res[0])
            self.assertIn('description', res[0])
            self.assertNotIn('service_count', res[0])
            self.assertNotIn('cert_count', res[0])

        if sni_groups_count > 1:
            res = get_sni_group_list(exclude_id_list=[sni_groups[0].pk])
            self.assertEqual(sni_groups_count, (len(res) + 1))

    def test_get_all_certs(self):
        res = get_sni_cert_list(exclude=False, expired=False)
        cert_count = SSLKeystore.objects.filter(expiration_date__gte=datetime.datetime.now()).count()
        self.assertEqual(list, type(res))
        self.assertEqual(cert_count, len(res))
        if len(res) >= 1:
            self.assertIn('keystore_id', res[0])
            self.assertIn('sni_group_id', res[0])
            self.assertIn('domain', res[0])
            self.assertIn('_name', res[0])

        res = get_sni_cert_list(exclude=False, expired=True)
        cert_count = SSLKeystore.objects.all().count()
        self.assertEqual(cert_count, len(res))

        res = get_sni_cert_list(exclude=True, expired=False)
        cert_count = SSLKeystore.objects.filter(sni_group__isnull=True, expiration_date__gte=datetime.datetime.now()).count()
        self.assertEqual(cert_count, len(res))

        res = get_sni_cert_list(exclude=True, expired=True)
        cert_count = SSLKeystore.objects.filter(sni_group__isnull=True).count()
        self.assertEqual(cert_count, len(res))

    def test_get_all_services(self):
        res = get_sni_service_list(exclude=False)
        service_count = Service.objects.filter(ssl_cert__isnull=False).count()
        self.assertEqual(list, type(res))
        self.assertEqual(service_count, len(res))
        if len(res) >= 1:
            self.assertIn('id', res[0])
            self.assertIn('sni_group_id', res[0])
            self.assertIn('dns_prefix', res[0])
            self.assertIn('_name', res[0])

    def test_save_sni_group(self):
        add_data_1 = {
            'sni_group_id': None,
            'sni_group_name': 'test_jongsoo_sni_group_1',
            'description': 'test_jongsoo_sni_group_1_description',
            'certs': [4927],
            'services': [584, 585],
            'request_user': 'test'
        }
        try:
            res = save_sni_group(add_data_1)
        except Exception, e:
            assert False, e.message or e.message_dict

        try:
            sni = SNIGroup.objects.get(sni_group_name=add_data_1['sni_group_name'])

            assert add_data_1['sni_group_name'] == sni.sni_group_name
            assert add_data_1['description'] == sni.description
            assert add_data_1['certs'] == [c for c in sni.sslkeystore_set.all().values_list('pk', flat=True)]
            assert add_data_1['services'] == [c for c in sni.service_set.all().values_list('pk', flat=True)]
            delete_sni_group(sni.pk)
        except SNIGroup.DoesNotExist:
            pass
        pass

if __name__ == "__main__":
    unittest.main()
