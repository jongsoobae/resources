#!/usr/bin/python
# -*- coding: utf-8 -*-
import unittest
import os
import sys
import time
from selenium.webdriver.support.ui import Select

sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'ui.oui.settings'
from selenium_test import SeleniumTestCase
from ci.common.models.cdn import Service
from ci.common.models import Site


# if changed DB, edit here.  current setting is old openstack ipv6.
BASE_URL = 'http://10.40.196.147:8087'

CUSTOMER_ID = 2645  # CDNet ENG
SERVICE_WITH_NO_SNI = 14  # *.cdn.com
SERVICE_WITH_SNI = 15  # *.cdn.com || *.cdn.com , *.foo.com  # sni 157
SERVICE_WITH_OTHER_SNI = 16  # *.cdn.com || *.bar.com  # sni 158
#

TEST_PAD_NAME_VALID_SERVICE_NO_SNI = 'js_sni_test1.cdn.com'
TEST_PAD_NAME_VALID_SERVICE_VALID_SNI = 'js_sni_test2.cdn.com'
TEST_PAD_NAME_VALID_SERVICE_INVALID_SNI = 'js_sni_test3.cdn.com'

TEST_PAD_NAME_INVALID_SERVICE_NO_SNI = 'js_sni_test4.foo.com'
TEST_PAD_NAME_INVALID_SERVICE_VALID_SNI = 'js_sni_test5.foo.com'
TEST_PAD_NAME_INVALID_SERVICE_INVALID_SNI = 'js_sni_test6.foo.com'


CASE1 = {
    'pad_name': TEST_PAD_NAME_VALID_SERVICE_NO_SNI,
    'service': SERVICE_WITH_NO_SNI
}

CASE2 = {
    'pad_name': TEST_PAD_NAME_VALID_SERVICE_VALID_SNI,
    'service': SERVICE_WITH_SNI
}

CASE3 = {
    'pad_name': TEST_PAD_NAME_VALID_SERVICE_INVALID_SNI,
    'service': SERVICE_WITH_OTHER_SNI
}

CASE4 = {
    'pad_name': TEST_PAD_NAME_INVALID_SERVICE_NO_SNI,
    'service': SERVICE_WITH_NO_SNI
}

CASE5 = {
    'pad_name': TEST_PAD_NAME_INVALID_SERVICE_VALID_SNI,
    'service': SERVICE_WITH_SNI
}

CASE6 = {
    'pad_name': TEST_PAD_NAME_INVALID_SERVICE_INVALID_SNI,
    'service': SERVICE_WITH_OTHER_SNI
}


class SNIPadTest(SeleniumTestCase):
    def setUp(self):
        # if changed DB, edit here.
        self.customer_id = 4364  # add a pad for this customer.
        self.valid_service_no_sni = 91  # is3
        self.valid_service_valid_sni = 147  # is2cs
        self.valid_service_invalid_sni = 90  # is2
        self.invalid_service_no_sni = 496  # I31
        self.invalid_service_valid_sni = 636  # I30
        self.invalid_service_invalid_sni = 212  # i28
        #
        self.base_url = BASE_URL
        self.oui_login(oui_url=self.base_url)

    def tearDown(self):
        driver = self.driver
        try:
            Site.objects.get(pad=self.case['pad_name']).delete()
        except Site.DoesNotExist:
            pass
        driver.quit()

    def test_valid_service_no_sni(self):
        driver = self.driver
        self.case = CASE1
        self.go_add_page()
        driver.find_element_by_css_selector('#id_pad').send_keys(self.case['pad_name'])
        self.set_value_of_service(self.case['service'])
        self.click_save(expect='success')

    def test_valid_service_valid_sni(self):
        driver = self.driver
        self.case = CASE2
        self.go_add_page()
        driver.find_element_by_css_selector('#id_pad').send_keys(self.case['pad_name'])
        self.set_value_of_service(self.case['service'])
        self.click_save(expect='success')

    def test_valid_service_invalid_sni(self):
        driver = self.driver
        self.case = CASE3
        self.go_add_page()
        driver.find_element_by_css_selector('#id_pad').send_keys(self.case['pad_name'])
        self.set_value_of_service(self.case['service'])
        self.click_save(expect='success')

    def test_invalid_service_no_sni(self):
        driver = self.driver
        self.case = CASE4
        self.go_add_page()
        driver.find_element_by_css_selector('#id_pad').send_keys(self.case['pad_name'])
        self.set_value_of_service(self.case['service'])
        self.click_save(expect='failed')

    def test_invalid_service_valid_sni(self):
        driver = self.driver
        self.case = CASE5
        self.go_add_page()
        driver.find_element_by_css_selector('#id_pad').send_keys(self.case['pad_name'])
        self.set_value_of_service(self.case['service'])
        self.click_save(expect='success')

    def test_invalid_service_invalid_sni(self):
        driver = self.driver
        self.case = CASE6
        self.go_add_page()
        driver.find_element_by_css_selector('#id_pad').send_keys(self.case['pad_name'])
        self.set_value_of_service(self.case['service'])
        self.click_save(expect='failed')

    def go_add_page(self):
        driver = self.driver
        driver.get(self.base_url + "/customer/%s/add-site/" % CUSTOMER_ID)
        driver.find_element_by_css_selector('#header4').click()
        driver.find_element_by_css_selector('#id_origin').send_keys('sni_origin.testpad.com')
        driver.find_element_by_css_selector('#id_enable_ssl').click()

    def set_value_of_service(self, service_id):
        driver = self.driver
        Select(driver.find_element_by_css_selector('#id_service')).select_by_value(str(service_id))
        time.sleep(1)

    def click_save(self, expect='success'):
        self.driver.find_element_by_css_selector('input[type=submit][value=save]').click()
        if expect == 'success':
            # expect success, and go detail page.
            self.wait_for_element_by_css_selector("#pad_group_Basic.sub_group th.separator")
        else:
            self.assertIn('Your PAD name does not match the domain', self.driver.find_element_by_css_selector("ul.errorlist > li").text)


if __name__ == "__main__":
    unittest.main()
