#!/usr/bin/python
# -*- coding: utf-8 -*-
import requests
from selenium.webdriver.common.by import By
import unittest, time, os, sys
from selenium.webdriver.common.keys import Keys

sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'ui.oui.settings'

from selenium_test import SeleniumTestCase
from ui.oui.views.sni_group import save_sni_group


class SNIAddPageTest(SeleniumTestCase):

    def setUp(self):
        self.cert_id_1 = 3793
        self.cert_id_2 = 4377
        self.service_id_1 = 665
        self.service_id_2 = 222
        self.expired_cert_id = 439
        self.sni_test_info = {
            'sni_group_name': 'SNI_SELENIUM_TEST_1',
            'description': 'SNI_SELENIUM_TEST_1_DESCRIPTION',
            'certs': [self.cert_id_1],
            'services': [self.service_id_1],
            'request_user': 'selenium_test_user'
        }
        self.verificationErrors = []
        self.login_done = False
        if not self.login_done:
            self.oui_login(oui_url=self.base_url)
            self.login_done = True
        self.go_add_page()

    def tearDown(self):
        try:
            print 'delete'
            get_url = '%s/sni/ajax/sni_group/list/?sni_group_name=%s' % (self.base_url, self.sni_test_info['sni_group_name'])
            res = requests.get(get_url)
            sni_group_id = res.json()['data'][0]['sni_group_id']
            delete_url = '%s/sni/ajax/sni_group/%s/delete/' % (self.base_url, str(sni_group_id))
            self.driver.get(delete_url)
            print 'delete ok'
        except (Exception, ):
            pass
        self.driver.quit()

    def test_sni_add(self):
        print 'sni_add'
        driver = self.driver
        self.select_one_keystore(self.cert_id_1)
        self.assertTrue(self.is_element_present(By.CSS_SELECTOR, "#service_div option[value='%s']" % str(self.service_id_1)))

        self.select_one_service(self.service_id_1)
        self.fill_name_description()

        driver.find_element_by_css_selector("a.button.sni_btn_save").click()
        self.assertIn('SNI Group saved successfully.', driver.find_element_by_css_selector('#alert-div').text)

    def test_sni_check_group_name(self):
        print 'test_sni_check_group_name'
        driver = self.driver
        self.do_sni_add()
        self.go_add_page()

        driver.find_element_by_css_selector("input[name='sni_group_name']").clear()
        time.sleep(1)
        driver.find_element_by_css_selector("a.button.sni_btn_save").click()
        self.assertIn('SNI Group cannot saved.', driver.find_element_by_css_selector('#alert-div').text)
        self.assertIn('This field cannot be blank.', driver.find_element_by_css_selector('small.error li').text)
        self.assertIn('This field cannot be blank.', driver.find_element_by_css_selector('#cert_div small.error li').text)
        self.assertIn('must have at least1 service.', driver.find_element_by_css_selector('#service_div small.error li').text)

        driver.find_element_by_css_selector("input[name='sni_group_name']").send_keys(self.sni_test_info['sni_group_name'])
        time.sleep(1)
        driver.find_element_by_css_selector("a.button.sni_btn_save").click()
        self.assertIn('There are some errors.', driver.find_element_by_css_selector('#alert-div').text)
        self.assertIn('Duplicated.', driver.find_element_by_css_selector('small.error li').text)
        self.assertIn('This field cannot be blank.', driver.find_element_by_css_selector('#cert_div small.error li').text)
        self.assertIn('must have at least1 service.', driver.find_element_by_css_selector('#service_div small.error li').text)

    def test_search_for_cert_and_service(self):
        print 'test_search_for_cert_and_service'
        driver = self.driver

        cert_test_data = {
            'keyword': 'kimberly-clark',
            'result_cert_id_1': 4881,
            'result_cert_id_2': 4680,
            'result_for_empty': 3966
        }

        service_test_data = {
            'keyword': 'axa'
        }
        driver.find_element_by_css_selector('#cert_div input').clear()
        driver.find_element_by_css_selector('#cert_div input').send_keys(cert_test_data['keyword'])
        driver.find_element_by_css_selector('#cert_div input').send_keys(Keys.ENTER)

        self.wait_for_element_by_css_selector('#cert_div option[value="%s"]' % str(cert_test_data['result_cert_id_1']))
        self.assertIn(cert_test_data['keyword'], driver.find_element_by_css_selector('#cert_div option[value="%s"]' % cert_test_data['result_cert_id_1']).text)
        self.assertIn(cert_test_data['keyword'], driver.find_element_by_css_selector('#cert_div option[value="%s"]' % cert_test_data['result_cert_id_2']).text)
        driver.find_element_by_css_selector('#cert_div input').clear()
        driver.find_element_by_css_selector('#cert_div input').send_keys(Keys.ENTER)
        self.wait_for_element_by_css_selector('#cert_div option[value="%s"]' % str(cert_test_data['result_for_empty']))

        driver.find_element_by_css_selector('#service_div input').send_keys(service_test_data['keyword'])
        self.wait_for_element_by_css_selector('#ui-id-1 li.ui-menu-item')
        temp_text = driver.find_element_by_css_selector("#ui-id-1 li.ui-menu-item").text
        self.assertIn(service_test_data['keyword'], temp_text)
        temp_count = len(driver.find_elements_by_css_selector('#service_div option'))
        driver.find_element_by_css_selector("#ui-id-1 li.ui-menu-item").click()
        self.assertEqual(temp_count + 1, len(driver.find_elements_by_css_selector('#service_div option')))

        driver.find_element_by_css_selector('#cert_div div.available option[value="%s"]' % str(self.cert_id_1)).click()
        self.click_cert_add_btn()
        driver.find_element_by_css_selector('#cert_div div.chosen option[value="%s"]' % str(self.cert_id_1)).click()
        self.click_cert_remove_btn()

        self.click_cert_add_all_btn()
        driver.find_element_by_css_selector('#cert_div div.chosen option[value="%s"]' % str(self.cert_id_1))
        self.click_cert_remove_all_btn()

        self.click_service_add_all_btn()
        driver.find_element_by_css_selector('#service_div div.chosen option[value="%s"]' % str(self.service_id_1))
        self.click_service_remove_all_btn()

        try:
            driver.find_element_by_css_selector('#load_cert_expired').click()
        except:
            driver.find_element_by_css_selector('label[for="load_cert_expired"]').click()
        self.wait_for_element_by_css_selector('#cert_div div.available option[value="%s"]' % str(self.expired_cert_id))
        self.assertFalse(self.is_element_present(By.CSS_SELECTOR, '#cert_div div.chosen option'))

    def test_cert_service(self):
        print 'test_cert_service'
        driver = self.driver
        self.fill_name_description()
        self.select_one_keystore(self.cert_id_1)
        self.assertTrue(self.is_element_present(By.CSS_SELECTOR, "#service_div option[value='%s']" % str(self.service_id_1)))
        self.select_one_keystore(self.cert_id_2)
        self.assertTrue(self.is_element_present(By.CSS_SELECTOR, "#service_div option[value='%s']" % str(self.service_id_2)))

        self.assertIn('Selected certs has different algorithm.', driver.find_element_by_css_selector('#cert_div small.error').text)

        self.select_one_service(self.service_id_1)
        self.select_one_service(self.service_id_2)

        self.assertIn('Selected services has different [ssl_server_ciphers,ssl_client_ciphers]', driver.find_element_by_css_selector('#service_div small.error').text)

    def do_sni_add(self):
        save_sni_group(self.sni_test_info)

    def go_add_page(self):
        driver = self.driver
        driver.get(self.base_url + "/")
        driver.find_element_by_xpath("//div[@id='header']/table/tbody/tr[2]/td[11]/a").click()
        for i in range(60):
            try:
                if self.is_element_present(By.LINK_TEXT, "Add a new SNI Group"):
                    break
            except:
                pass
            time.sleep(1)
        else:
            self.fail("time out")
        driver.find_element_by_link_text("Add a new SNI Group").click()
        self.wait_for_element_by_css_selector("#cert_div option")

    def select_one_keystore(self, keystore_id):
        self.driver.find_element_by_css_selector("#cert_div option[value='%s']" % str(keystore_id)).click()
        time.sleep(1)
        self.click_cert_add_btn()

    def select_one_service(self, service_id):
        self.driver.find_element_by_css_selector("#service_div option[value='%s']" % str(service_id)).click()
        time.sleep(1)
        self.click_service_add_btn()

    def click_cert_add_btn(self):
        self.driver.find_element_by_css_selector("#cert_div a.button.add.one").click()

    def click_cert_add_all_btn(self):
        map(self.option_select_function, self.driver.find_elements_by_css_selector("#cert_div .available option"))
        self.driver.find_element_by_css_selector("#cert_div a.button.add.one").click()

    def click_service_add_btn(self):
        self.driver.find_element_by_css_selector("#service_div a.button.add.one").click()

    def click_service_add_all_btn(self):
        map(self.option_select_function, self.driver.find_elements_by_css_selector("#service_div .available option"))
        self.driver.find_element_by_css_selector("#service_div a.button.add.one").click()

    def click_cert_remove_btn(self):
        self.driver.find_element_by_css_selector("#cert_div a.button.remove.one").click()

    def click_cert_remove_all_btn(self):
        map(self.option_select_function, self.driver.find_elements_by_css_selector("#cert_div .chosen option"))
        self.driver.find_element_by_css_selector("#cert_div a.button.remove.one").click()

    def click_service_remove_btn(self):
        self.driver.find_element_by_css_selector("#service_div a.button.remove.one").click()

    def click_service_remove_all_btn(self):
        map(self.option_select_function, self.driver.find_elements_by_css_selector("#service_div .chosen option"))
        self.driver.find_element_by_css_selector("#service_div a.button.remove.one").click()

    def option_select_function(self, elem):
        if not elem.is_selected():
            elem.click()

    def fill_name_description(self):
        sni_group_name = self.driver.find_element_by_css_selector("input[name='sni_group_name']")
        sni_group_name.clear()
        sni_group_name.send_keys(self.sni_test_info['sni_group_name'])

        description = self.driver.find_element_by_css_selector("input[name='description']")
        description.clear()
        description.send_keys(self.sni_test_info['description'])


if __name__ == "__main__":
    unittest.main()
