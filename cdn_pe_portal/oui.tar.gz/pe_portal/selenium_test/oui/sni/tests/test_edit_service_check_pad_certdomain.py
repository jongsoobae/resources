#!/usr/bin/python
# -*- coding: utf-8 -*-
import unittest
import os
import sys
import time
import requests

sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'ui.oui.settings'
from selenium_test import SeleniumTestCase
from selenium.webdriver.support.ui import Select
from ci.common.models.customer import Customer
from ci.common.models.cdn import Service
from ci.common.models import Site
from ci.common.models.sni import SNIGroup
from ui.oui.views.sni_group import save_sni_group, delete_sni_group


# if changed DB, edit here.
INTERNAL_PAD_ADD_API_URL = 'http://10.40.196.147:8089/rest/int/jungho.park:cdnadmin/production-site/add/'
CUSTOMER_ID = 2645  # CDNet ENG
SNI_TEST_BAND_ID = 14
TEST_SERVICE_ID = 18
TEST_SERVICE_FULL_NAME = 'JS_SNI_T: SNI_CDN_TEST_SERVICE1'
SERVICE_CDN_NAME = 'SNI_CDN_TEST_SERVICE1'
TEST_DNS_PREFIX = 'JS_SNI_T'
TEST_SHIELD_FULL_NAME = 'JS_SNI_T :: NoShield'
CDN_COM_CERT_ID = 20
FOO_COM_CERT_ID = 11
CDN_NET_CERT_ID = 18
BAR_COM_CERT_ID = 13
#


PAD_NAME = 'js_sni_test_for_service.cdn.com'
PAD_NAME2 = 'js_sni_test.foo.com'

CASE1 = {
    # SERVICE_CDN, CERT_CDN, NO SNI
    'cert': CDN_COM_CERT_ID,
}

CASE2 = {
    # SERVICE_CDN, CERT_CDN, CDN SNI
    'dns_prefix': 'JS_SNIT',
    'cert': CDN_COM_CERT_ID
}

CASE3 = {
    # SERVICE_CDN, CERT_CDN, FOO SNI
    # Need to Create SNI.
    'cert': CDN_COM_CERT_ID,
    'sni_group_name': 'TEMP_TEST_SNI_FOR_INVALID_CASE'
}

CASE4 = {
    # SERVICE_CDN, CERT_FOO, NO SNI
    'cert': FOO_COM_CERT_ID,
}

CASE5 = {
    # SERVICE_CDN, CERT_FOO, CDN SNI
    'cert': FOO_COM_CERT_ID,
}

CASE6 = {
    # SERVICE_CDN, CERT_FOO, FOO SNI
    'cert': BAR_COM_CERT_ID,
}


class SNIServiceEditTest(SeleniumTestCase):
    def __init__(self, *args, **kwargs):
        super(SNIServiceEditTest, self).__init__(*args, **kwargs)
        self.test_count = 0

    def setUp(self):
        self.base_url = "http://10.40.196.147:8087"
        self.oui_login(oui_url=self.base_url)

        if self.test_count == 0:
            customer = Customer.objects.get(pk=CUSTOMER_ID)

            Service.objects.get(dns_prefix=TEST_DNS_PREFIX)
            try:
                Site.objects.get(pad=PAD_NAME)
            except Site.DoesNotExist:
                self.create_pad({
                    'pad': PAD_NAME,
                    'origin': 'testjs_sni.origin.cdn.com',
                    'customer_id': CUSTOMER_ID,
                    'service': TEST_SERVICE_FULL_NAME,
                    'shielded_service': TEST_SHIELD_FULL_NAME,
                    'pad_aliases': 'testjs_sni.aliases.cdn.com',
                    'enable_ssl': True,
                    'product': customer.product_set.all()[0].cop_product_id
                })

        self.test_count += 1

    def tearDown(self):
        driver = self.driver
        time.sleep(1)
        self.use_sni_group(False)
        self.set_cert(str(CDN_COM_CERT_ID))
        self.click_save(expect='skip')
        driver.quit()

    def test_valid_cert_no_sni(self):
        self.go_service_edit_page(TEST_SERVICE_ID)
        self.set_cert(CASE1['cert'])
        self.use_sni_group(False)
        self.click_save(expect='success')

    def test_valid_cert_valid_sni(self):
        self.go_service_edit_page(TEST_SERVICE_ID)
        self.set_cert(CASE2['cert'])
        self.use_sni_group(True)
        self.click_save(expect='success')

    def test_valid_cert_invalid_sni(self):
        self.create_sni_for_case3()
        self.go_service_edit_page(TEST_SERVICE_ID)
        self.click_save(expect='success')
        self.delete_sni_for_case3()

    def test_invalid_cert_no_sni(self):
        self.go_service_edit_page(TEST_SERVICE_ID)
        self.set_cert(CASE4['cert'])
        self.use_sni_group(False)
        self.click_save(expect='failed')

    def test_invalid_cert_valid_sni(self):
        self.go_service_edit_page(TEST_SERVICE_ID)
        self.set_cert(CASE5['cert'])
        time.sleep(1)
        self.use_sni_group(True)
        self.click_save(expect='success')

    def test_invalid_cert_invalid_sni(self):
        self.go_service_edit_page(TEST_SERVICE_ID)
        self.set_cert(CASE6['cert'])
        time.sleep(1)
        self.use_sni_group(True)
        self.click_save(expect='failed')

    def create_sni_for_case3(self):
        try:
            save_sni_group(post_params={
                'services': [str(TEST_SERVICE_ID)],
                'sni_group_name': CASE3['sni_group_name'],
                'request_user': 'jungho.park',
                'certs': [str(CDN_NET_CERT_ID)]
            })
        except Exception, e:
            self.fail(e.message)

    def delete_sni_for_case3(self):
        sni_group_id = SNIGroup.objects.get(sni_group_name=CASE3['sni_group_name']).pk
        delete_sni_group(sni_group_id)

    def create_service(self):
        driver = self.driver
        driver.get('%s/admin/oui/service/add/' % self.base_url)
        driver.find_element_by_css_selector('#id_name').send_keys(SERVICE_CDN_NAME)
        driver.find_element_by_css_selector('#id_dns_prefix').send_keys(TEST_DNS_PREFIX)
        Select(driver.find_element_by_css_selector('#id_dns_zone')).select_by_index(1)
        driver.find_element_by_css_selector('#id_bands_from > option[value="%s"]' % SNI_TEST_BAND_ID).click()
        driver.find_element_by_css_selector('.selector-chooser .selector-add').click()
        self.click_save(expect='success')

    def create_pad(self, params):
        api_url = self.get_url(INTERNAL_PAD_ADD_API_URL, params)
        res = requests.get(api_url)
        self.assertEqual(res.status_code, 200)
        return res.json()

    def get_url(self, url, params):
        return '%s?%s' % (url, '&'.join(['%s=%s' % (key, value) for key, value in params.items()]))

    def set_cert(self, cert_id):
        sel = Select(self.driver.find_element_by_css_selector('#id_ssl_cert'))
        sel.select_by_value(str(cert_id))

    def set_sni_group(self, sni_id):
        sel = Select(self.driver.find_element_by_css_selector('#id_sni_group'))
        sel.select_by_value(str(sni_id))

    def use_sni_group(self, use=True):
        sel = Select(self.driver.find_element_by_css_selector('#id_sni_group'))
        if use:
            sel.select_by_index(1)
        else:
            sel.select_by_index(0)

    def go_service_edit_page(self, service_id):
        driver = self.driver
        driver.get(self.base_url + "/admin/oui/service/%s/" % service_id)
        self.wait_for_element_by_css_selector("#content h1")
        self.wait_for_element_by_css_selector("#id_dns_prefix")

    def click_save(self, expect='success'):
        driver = self.driver
        if driver.find_element_by_css_selector('input[name=push_check_flag]').is_selected():
            driver.find_element_by_css_selector('input[name=push_check_flag]').click()
        driver.find_element_by_css_selector('input[name="_continue"]').click()
        if expect == 'skip':
            pass
        elif expect == 'success':
            # expect success, and go detail page.
            self.wait_for_element_by_css_selector('ul.messagelist li.info')
            try:
                self.assertIn('was changed successfully.', driver.find_element_by_css_selector('ul.messagelist li.info').text)
            except AssertionError:
                self.assertIn('was added successfully.', driver.find_element_by_css_selector('ul.messagelist li.info').text)
        else:
            self.wait_for_element_by_css_selector('p.errornote')
            try:
                self.assertIn('Please correct the errors below.', self.driver.find_element_by_css_selector('p.errornote').text)
            except AssertionError:
                self.assertIn('Please correct the error below.', self.driver.find_element_by_css_selector('p.errornote').text)
            self.wait_for_element_by_css_selector('ul.errorlist > li')
            self.assertIn('not compatible with this new certificate', self.driver.find_element_by_css_selector('ul.errorlist > li').text)

if __name__ == "__main__":
    unittest.main()
