#!/usr/bin/python
# -*- coding: utf-8 -*-
import unittest
import os
import sys
import time
import requests

sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'ui.oui.settings'
from selenium_test import SeleniumTestCase
from ci.common.models import Site


# if changed DB, edit here.
TEST_CDN_NET_SERVICE = {
    'id': 19,
    'name': 'test_sni_cdn_net',
    'dns_prefix': 'TSCN'
}

TEST_FOO_NET_SERVICE = {
    'id': 20,
    'name': 'test_sni_foo_net',
    'dns_prefix': 'TSFN'
}

CDN_NET_CERT_ID = 18
FOO_NET_CERT_ID = 14
BAR_NET_CERT_ID = 16

BAR_NET_PAD_ID = 5828
#

TEST_SNI_NAME = 'TEMP_JS_TEST_FOR_SNI'

CASE1 = {
    'services': [TEST_CDN_NET_SERVICE],
    'cert_id_list': [CDN_NET_CERT_ID]
}

CASE2 = {
    'services': [TEST_CDN_NET_SERVICE],
    'cert_id_list': [CDN_NET_CERT_ID, FOO_NET_CERT_ID]
}

CASE3 = {
    'services': [TEST_CDN_NET_SERVICE, TEST_FOO_NET_SERVICE],
    'cert_id_list': [CDN_NET_CERT_ID, FOO_NET_CERT_ID, BAR_NET_CERT_ID]
}


class SNIServiceEditTest(SeleniumTestCase):
    def setUp(self):
        # if changed DB, edit here.
        self.base_url = "http://10.40.196.147:8087"

        self.oui_login(oui_url=self.base_url)

    def tearDown(self):
        try:
            print 'delete'
            get_url = '%s/sni/ajax/sni_group/list/?sni_group_name=%s' % (self.base_url, TEST_SNI_NAME)
            res = requests.get(get_url)
            sni_group_id = res.json()['data'][0]['sni_group_id']
            delete_url = '%s/sni/ajax/sni_group/%s/delete/' % (self.base_url, str(sni_group_id))
            self.driver.get(delete_url)
            print 'delete ok'
        except (Exception, ):
            pass
        self.driver.quit()

    def _test1(self):
        self.case = CASE1
        self.go_add()
        time.sleep(5)
        map((lambda service_info: self.search_service(service_info['name'])), self.case['services'])
        map(lambda service_info: self.select_one_service(service_info['id']), self.case['services'])
        map(lambda cert_id: self.select_one_keystore(cert_id), self.case['cert_id_list'])
        self.fill_name_description(param_name=TEST_SNI_NAME, param_description='')
        self.sni_group_save(expect='success')

    def _test2(self):
        self.case = CASE2
        self.go_add()
        time.sleep(5)
        map((lambda service_info: self.search_service(service_info['name'])), self.case['services'])
        map(lambda service_info: self.select_one_service(service_info['id']), self.case['services'])
        map(lambda cert_id: self.select_one_keystore(cert_id), self.case['cert_id_list'])
        self.fill_name_description(param_name=TEST_SNI_NAME, param_description='')
        self.sni_group_save(expect='success')

    def test3(self):
        self.case = CASE3
        self.go_add()
        time.sleep(5)
        map((lambda service_info: self.search_service(service_info['name'])), self.case['services'])
        map(lambda service_info: self.select_one_service(service_info['id']), self.case['services'])
        map(lambda cert_id: self.select_one_keystore(cert_id), self.case['cert_id_list'])
        self.fill_name_description(param_name=TEST_SNI_NAME, param_description='')
        self.sni_group_save(expect='success')

        site = Site.objects.get(pk=BAR_NET_PAD_ID)
        site.enable_ssl = True
        site.save()

        time.sleep(3)
        self.deselect_one_service(TEST_FOO_NET_SERVICE['id'])
        self.sni_group_save(expect='failed')

        site.enable_ssl = False
        site.save()

        time.sleep(3)
        self.select_one_service(TEST_FOO_NET_SERVICE['id'])
        self.deselect_one_service(TEST_FOO_NET_SERVICE['id'])
        self.sni_group_save(expect='success')

    def go_add(self):
        driver = self.driver
        driver.get(self.base_url + "/sni_group/#/add/")

    def sni_group_save(self, expect='success'):
        driver = self.driver
        driver.find_element_by_css_selector("a.button.sni_btn_save").click()
        if expect == 'success':
            self.assertIn('SNI Group saved successfully.', driver.find_element_by_css_selector('#alert-div').text)
        else:
            self.assertIn('SNI Group cannot saved.', driver.find_element_by_css_selector('#alert-div').text)
        self.wait_for_element_by_css_selector('#cert_div div.available')
        self.wait_for_element_by_css_selector('#service_div div.chosen')

    def fill_name_description(self, param_name, param_description):
        sni_group_name = self.driver.find_element_by_css_selector("input[name='sni_group_name']")
        sni_group_name.clear()
        sni_group_name.send_keys(param_name)

        description = self.driver.find_element_by_css_selector("input[name='description']")
        description.clear()
        description.send_keys(param_description)

    def click_expired(self):
        self.wait_for_element_by_css_selector('#cert_div div.available')
        self.wait_for_element_by_css_selector('#service_div div.chosen')
        time.sleep(5)
        self.wait_for_element_by_css_selector('label[for="load_cert_expired"]')
        self.driver.find_element_by_css_selector('label[for="load_cert_expired"]').click()
        time.sleep(5)
        self.wait_for_element_by_css_selector('#cert_div div.available')
        self.wait_for_element_by_css_selector('#service_div div.chosen')

    def search_service(self, keyword):
        driver = self.driver
        driver.find_element_by_css_selector('#service_div input').clear()
        driver.find_element_by_css_selector('#service_div input').send_keys(keyword)
        time.sleep(1)
        self.wait_for_element_by_css_selector('#ui-id-1 li.ui-menu-item')
        driver.find_element_by_css_selector("#ui-id-1 li.ui-menu-item").click()

    def select_one_keystore(self, keystore_id):
        obj = self.driver.find_element_by_css_selector("#cert_div option[value='%s']" % str(keystore_id))
        if not obj.is_selected():
            obj.click()
        time.sleep(1)
        self.click_cert_add_btn()

    def select_one_service(self, service_id):
        self.wait_for_element_by_css_selector("#service_div option[value='%s']" % str(service_id))
        obj = self.driver.find_element_by_css_selector("#service_div option[value='%s']" % str(service_id))
        if not obj.is_selected():
            obj.click()
        time.sleep(1)
        self.click_service_add_btn()

    def deselect_one_keystore(self, keystore_id):
        obj = self.driver.find_element_by_css_selector("#cert_div option[value='%s']" % str(keystore_id))
        if not obj.is_selected():
            obj.click()
        time.sleep(1)
        self.click_cert_remove_btn()

    def deselect_one_service(self, service_id):
        obj = self.driver.find_element_by_css_selector("#service_div option[value='%s']" % str(service_id))
        if not obj.is_selected():
            obj.click()
        time.sleep(1)
        self.click_service_remove_btn()

    def click_cert_add_btn(self):
        self.driver.find_element_by_css_selector("#cert_div a.button.add.one").click()

    def click_service_add_btn(self):
        self.driver.find_element_by_css_selector("#service_div a.button.add.one").click()

    def click_cert_remove_btn(self):
        self.driver.find_element_by_css_selector("#cert_div a.button.remove.one").click()

    def click_service_remove_btn(self):
        self.driver.find_element_by_css_selector("#service_div a.button.remove.one").click()


if __name__ == "__main__":
    unittest.main()
