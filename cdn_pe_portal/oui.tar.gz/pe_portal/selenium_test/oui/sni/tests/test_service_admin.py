#!/usr/bin/python
# -*- coding: utf-8 -*-
import unittest
import os
import sys

sys.path.insert(0, '/opt/cdn/ui/prod')
os.environ['DJANGO_SETTINGS_MODULE'] = 'ui.oui.settings'

from ci.common.models.customer import SSLKeystore
from selenium_test import SeleniumTestCase


class SNIAdminAddPageTest(SeleniumTestCase):

    def setUp(self):
        self.cert_id_1 = 3793
        self.cert_id_2 = 4377
        self.service_id_1 = 665
        self.service_id_2 = 222
        self.expired_cert_id = 439
        self.sni_test_info = {
            'sni_group_name': 'SNI_SELENIUM_TEST_1',
            'description': 'SNI_SELENIUM_TEST_1_DESCRIPTION',
            'certs': [self.cert_id_1],
            'services': [self.service_id_1],
            'request_user': 'selenium_test_user'
        }
        self.service_test_info = {
            'service_name': 'test_jongsoo_service_1',
            'description': 'test_jongsoo_service_1',
            'dns_prefix': 'tjs1',
            'dns_zone': '20',
            'cert': '4927',
            'band': '5186',
            'sni_group': '0'
        }
        self.base_url = "http://10.40.196.147:8087"
        self.verificationErrors = []
        self.oui_login(oui_url=self.base_url)
        self.go_add_page()

    def tearDown(self):
        driver = self.driver
        self.assertEqual([], self.verificationErrors)
        try:
            print 'delete'
            driver.find_element_by_css_selector('a.deletelink').click()
            driver.find_element_by_css_selector('input[type="submit"]').click()
            self.assertIn('was deleted successfully.', driver.find_element_by_css_selector('ul.messagelist li.info').text)
            print 'delete ok'
        except (Exception, ):
            pass
        self.driver.quit()

    def __test_service_add(self):
        driver = self.driver
        driver.find_element_by_css_selector('#id_name').send_keys(self.service_test_info['service_name'])
        driver.find_element_by_css_selector('#id_description').send_keys(self.service_test_info['description'])
        driver.find_element_by_css_selector('#id_dns_prefix').send_keys(self.service_test_info['dns_prefix'])
        driver.find_element_by_css_selector(
            '#id_dns_zone option[value="' + self.service_test_info['dns_zone'] + '"]'
        ).click()
        if driver.find_element_by_css_selector('input[name=push_check_flag]').is_selected():
            driver.find_element_by_css_selector('input[name=push_check_flag]').click()
        driver.find_element_by_css_selector(
            '#id_ssl_cert option[value="' + self.service_test_info['cert'] + '"]'
        ).click()
        driver.find_element_by_css_selector(
            '#id_bands_from option[value="' + self.service_test_info['band'] + '"]'
        ).click()
        driver.find_element_by_css_selector('a.selector-add').click()

        driver.find_element_by_css_selector('input[name="_continue"]').click()

        self.wait_for_element_by_css_selector('ul.messagelist li.info')
        self.assertIn('was added successfully.', driver.find_element_by_css_selector('ul.messagelist li.info').text)

    def test_service_add_with_sni(self):
        self.do_add_with_sni()

    def go_add_page(self):
        driver = self.driver
        driver.get(self.base_url + "/admin/oui/service/")
        driver.find_element_by_css_selector('a.addlink').click()
        self.wait_for_element_by_css_selector("#id_ssl_cert")

    def do_add_with_sni(self):
        driver = self.driver
        driver.find_element_by_css_selector('#id_name').send_keys(self.service_test_info['service_name'])
        driver.find_element_by_css_selector('#id_description').send_keys(self.service_test_info['description'])
        driver.find_element_by_css_selector('#id_dns_prefix').send_keys(self.service_test_info['dns_prefix'])
        driver.find_element_by_css_selector(
            '#id_dns_zone option[value="' + self.service_test_info['dns_zone'] + '"]'
        ).click()
        if driver.find_element_by_css_selector('input[name=push_check_flag]').is_selected():
            driver.find_element_by_css_selector('input[name=push_check_flag]').click()
        driver.find_element_by_css_selector(
            '#id_ssl_cert option[value="' + self.service_test_info['cert'] + '"]'
        ).click()
        driver.find_element_by_css_selector(
            '#id_bands_from option[value="' + self.service_test_info['band'] + '"]'
        ).click()
        driver.find_element_by_css_selector('a.selector-add').click()

        try:
            db_ssl_cert = SSLKeystore.objects.get(pk=self.service_test_info['cert'])
            self.wait_for_element_by_css_selector('#id_sni_group option[value="' + str(db_ssl_cert.sni_group.pk) + '"]')
            driver.find_element_by_css_selector('#id_sni_group option[value="' + str(db_ssl_cert.sni_group.pk) + '"]').click()
        except SSLKeystore.DoesNotExist:
            assert False, 'bad test data.'

        driver.find_element_by_css_selector('input[name="_continue"]').click()

        self.wait_for_element_by_css_selector('ul.messagelist li.info')
        self.assertIn('was added successfully.', driver.find_element_by_css_selector('ul.messagelist li.info').text)


if __name__ == "__main__":
    unittest.main()
