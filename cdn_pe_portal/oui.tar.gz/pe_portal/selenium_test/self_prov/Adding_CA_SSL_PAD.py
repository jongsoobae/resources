#!/usr/bin/python
#-*-encoding: utf-8-*-

## PATH
import time, unittest, sys, os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)

## CONFIGURATIONS
from selenium_test.config_constants import *
from selenium_test.shared_components.login import *
from selenium_test.shared_components.utils import *
from selenium_test.shared_components.decorator import *
from selenium_test.shared_components.api_handler import *
from selenium_test.shared_components.common_action import *
from selenium_test.config_user_constants import SELF_PROV_USER

## SELENIUM MODUES
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException

rc = SeleniumRC()
@logclass
class CustomerCATest(unittest.TestCase):
    @logmethod
    def setUp(self):
        ## webdriver according to browser
        if len(g_args_list) == 1:
            g_args_list['BROWSER'] = 'firefox'
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-" + g_args_list['BROWSER'] + ".cdnetworks.com"
        elif len(g_args_list) == 2:
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-firefox.cdnetworks.com"
        elif len(g_args_list) == 5:
            self.driver = rc.get_driver(g_args_list['NODE'], g_args_list['BROWSER'], g_args_list['OS'], g_args_list['PORT'])
            if g_args_list['BROWSER'] == 'internet explorer':
                self.pad_name = "selenium-ie.cdnetworks.com"
            else:
                self.pad_name = "selenium-" + g_args_list['BROWSER'] + ".cdnetworks.com"
        else:
            raise Exception("The number of arguments is wrong.")
        clear_db(self.pad_name)
        common_login_action(self.driver, g_args_list['USER'], SELF_PROV_USER['PASSWORD'])

    @logmethod
    def tearDown(self):
        # Destroying DB (jongsoo.bae) aurora.deactivate()
        driver = self.driver
        driver.close()

    @logmethod
    def test1_ca_ssl_add_pad(self):
        driver = self.driver
        if g_args_list['USER'] == 'test_ca_ssl_add_edit_priv@gala.cdn.com' or g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
            """Cases.
                push to production by a customer during being pushed to production by same customer.
            """
            create_a_pad_with_all_items(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            """Assertions.
                Asserting data in both.
            """
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
            time.sleep(1)
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            driver.find_element_by_link_text(self.pad_name).click()
            time.sleep(3)
            self.assertEqual("Push status : New", driver.find_element_by_css_selector("h2").text)
            self.assertEqual("Production Site Settings", driver.find_element_by_xpath("//h2[2]").text)
            self.assertEqual(self.pad_name, driver.find_element_by_css_selector("td").text)
            self.assertEqual("alias."+self.pad_name, driver.find_element_by_css_selector("tr.row2 > td").text)
            self.assertEqual("default-origin.cdnetworks.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[5]/td").text)
            self.assertEqual("failover."+self.pad_name, driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[6]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[7]/td").text)
            self.assertEqual("40000548-30: CA SSL - Global Premium (Self Implementation)", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[8]/td").text)
            self.assertEqual("selenium test", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[9]/td").text)
            driver.find_element_by_link_text("Caching").click()
            self.assertEqual("True", driver.find_element_by_css_selector("#pad_group_local_site_Caching > tr.row2 > td").text)
            self.assertEqual("60", driver.find_element_by_css_selector("#pad_group_local_site_Caching > tr.row1 > td").text)
            self.assertEqual("2015-12-25", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[5]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[6]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[7]/td").text)
            self.assertEqual("60", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[8]/td").text)
            #self.assertTrue(self.is_element_present(By.XPATH, "//tbody[@id='pad_group_local_site_Caching']/tr[9]/td"))
            #self.assertTrue(self.is_element_present(By.XPATH, "//tbody[@id='pad_group_local_site_Caching']/tr[10]/td"))
            driver.find_element_by_link_text("Request & Response").click()
            self.assertEqual("10.10.10.1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[3]/td").text)
            self.assertEqual("777", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[4]/td").text)
            self.assertEqual("test.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[5]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[6]/td").text)
            self.assertEqual("X-Foo: bar", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[7]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[8]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[9]/td").text)
            self.assertEqual("None", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[10]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[11]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[12]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[15]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[16]/td").text)
            self.assertEqual("50", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[17]/td").text)
            self.assertEqual("X-Test: selenium", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[18]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[19]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[20]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[21]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[24]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[25]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[26]/td").text)
            self.assertEqual("X-Test: selenium", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[27]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[28]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[31]/td").text)
            driver.find_element_by_link_text("Rewrite Rules").click()
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[3]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[4]/td").text)
            #self.assertTrue(self.is_element_present(By.XPATH, "//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[5]/td"))
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[6]/td").text)
            #self.assertTrue(self.is_element_present(By.XPATH, "//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[7]/td"))
            self.assertEqual("string", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[8]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[9]/td").text)
            self.assertEqual("test", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[10]/td").text)
            #self.assertTrue(self.is_element_present(By.XPATH, "//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[11]/td"))
            driver.find_element_by_link_text("Validation").click()
            #self.assertTrue(self.is_element_present(By.CSS_SELECTOR, "#pad_group_local_site_Validation > tr.row2 > td"))
            self.assertEqual("Whitelist", driver.find_element_by_css_selector("#pad_group_local_site_Validation > tr.row1 > td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[5]/td").text)
            self.assertEqual("test.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[6]/td").text)
            self.assertEqual("Origin Logic Control", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[9]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[10]/td").text)
            self.assertEqual("test.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[11]/td").text)
            self.assertEqual("X-Foo: Bar", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[12]/td").text)
            self.assertEqual("test.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[13]/td").text)
            self.assertEqual("hhh1@gala.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[14]/td").text)
            self.assertEqual("cdnadmin", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[15]/td").text)
            self.assertEqual("Basic", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[16]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[19]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[20]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[21]/td").text)
            self.assertEqual("px-hash", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[22]/td").text)
            self.assertEqual("1234", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[23]/td").text)
            self.assertEqual("px-time", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[24]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[25]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[26]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[27]/td").text)
            self.assertEqual("^/cross-domain\\.xml", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[28]/td").text)
            driver.find_element_by_id("tab_local_site_Video/Large File Delivery").click()
            driver.find_element_by_link_text("Video/Large File Delivery").click()
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[3]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[6]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[7]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[10]/td").text)
            self.assertEqual("start", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[11]/td").text)
            self.assertEqual("h264", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[12]/td").text)
            self.assertEqual("flv", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[13]/td").text)
            self.assertEqual("mp4,m4v", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[14]/td").text)
            if g_args_list['USER'] == 'test_ca_ssl_add_edit_priv@gala.cdn.com':
                self.assertEqual("test_ca_ssl_add_edit_priv@gala.cdn.com", driver.find_element_by_xpath("//table[@id='change_history']/tbody/tr/td[2]").text)
            elif g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
                self.assertEqual("test_master_priv@gala.cdn.com", driver.find_element_by_xpath("//table[@id='change_history']/tbody/tr/td[2]").text)

        elif g_args_list['USER']=='test_ca_ssl_edit_priv@gala.cdn.com' or g_args_list['USER']=='test_ca_ssl_view_only_priv@gala.cdn.com' or g_args_list['USER']=='test_no_priv@gala.cdn.com':
            ## CA SSL menu
            driver = self.driver
            driver.get(AURORA_URL + "/cui/int/pads/add/?m=190")
            time.sleep(3)
            ## Access Denied
            for i in range(60):
                try:
                    if "Error 403" == driver.find_element_by_css_selector("h1.pa-title").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")
            try:
                if "Add new PAD" ==  driver.find_element_by_link_text("Add new PAD").text: self.fail("Exist Add new PAD menu")
            except: pass
        else: raise Exception("No matched account.")

        """TearDown.
            clearing all tested data.
        """
        clear_db(self.pad_name)
    
if __name__ == '__main__':
    global g_args_list
    g_args_list = handle_args(sys.argv)
    unittest.main()
