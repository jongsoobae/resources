#!/usr/bin/python
#-*-encoding: utf-8-*-

## PATH
import time, unittest, sys, os, subprocess
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)

## CONFIGURATIONS
from selenium_test.config_constants import *
from selenium_test.shared_components.login import *
from selenium_test.shared_components.utils import *
from selenium_test.shared_components.decorator import *
from selenium_test.shared_components.api_handler import *
from selenium_test.shared_components.common_action import *
from selenium_test.config_user_constants import SELF_PROV_USER

## SELENIUM MODUES
from selenium import webdriver
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys

rc = SeleniumRC()
@logclass
class CustomerCATest(unittest.TestCase):
    print ""
    print "##################################################  PREPARATION  ##################################################"
    print "###                                                                                                             ###"
    print "### Register domains in your hosts, '10.40.211.8   " + OPENAPI_URL + "                   ###"
    print "###                                                                                                             ###"
    print "###################################################################################################################"
    print ""

    def setUp(self):
        ## webdriver according to browser
        if len(g_args_list) == 1:
            g_args_list['BROWSER'] = 'firefox'
            self.driver = webdriver.Firefox()
        elif len(g_args_list) == 2:
            self.driver = webdriver.Firefox()
        elif len(g_args_list) == 5:
            self.driver = rc.get_driver(g_args_list['NODE'], g_args_list['BROWSER'], g_args_list['OS'], g_args_list['PORT'])
        else: raise Exception("The number of arguments is wrong.")
        self.pad_name = "selenium-perf-.cdnetworks.com"

        # for another customer
        self.customer_driver_1 = webdriver.Firefox()
        self.customer_pad_name_1 = 'selenium-another1-.cdnetworks.com'
        common_login_action(self.driver, g_args_list['USER'], SELF_PROV_USER['PASSWORD'])
        common_login_action(self.customer_driver_1, ANOTHER_SELF_USER['USER_WITH_CA_ADD_EDIT_PRIV'], SELF_PROV_USER['PASSWORD'])
        clear_db(self.pad_name, 'selenium-another1-%.cdnetworks.com')

    def tearDown(self):
        self.driver.quit()
        self.customer_driver_1.quit()

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test_01_val_race_conditions(self):
        # making pads by UI
        run_threads(perf_create_pads, [self.driver, self.pad_name, 30, g_args_list['USER'], g_args_list['BROWSER'], __file__],
                    perf_create_pads, [self.customer_driver_1, self.customer_pad_name_1, 30, ANOTHER_SELF_USER['USER_WITH_CA_ADD_EDIT_PRIV'], g_args_list['BROWSER'], __file__])
        val_all_pads()
        # push to staging
        run_threades(perf_push_to_stag, [driver, self.pad_name, 30, g_args_list['USER'], g_args_list['BROWSER'], __file__],
                     perf_push_to_stag, [self.customer_driver_1, self.customer_pad_name_1, 30, ANOTHER_SELF_USER['USER_WITH_CA_ADD_EDIT_PRIV'], g_args_list['BROWSER'], __file__])
        # push to production
        run_threades(perf_push_to_prod, [driver, self.pad_name, 30, g_args_list['USER'], g_args_list['BROWSER'], __file__],
                     perf_push_to_prod, [self.customer_driver_1, self.customer_pad_name_1, 30, ANOTHER_SELF_USER['USER_WITH_CA_ADD_EDIT_PRIV'], g_args_list['BROWSER'], __file__])

if __name__ == '__main__':
    global g_args_list
    g_args_list = handle_args(sys.argv)
    unittest.main()
