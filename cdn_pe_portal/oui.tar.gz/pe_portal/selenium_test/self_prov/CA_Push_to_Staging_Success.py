#!/usr/bin/python
#-*-encoding: utf-8-*-

## PATH
import time, unittest, sys, os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)

## CONFIGURATIONS
from selenium_test.shared_components.login import SeleniumRC
from selenium_test.shared_components.utils import *
from selenium_test.shared_components.decorator import *
from selenium_test.shared_components.common_action import *
from selenium_test.config_user_constants import SELF_PROV_USER
from selenium_test.config_constants import *

## SELENIUM MODUES
from selenium.webdriver.support.ui import Select
from selenium import webdriver

rc = SeleniumRC()
@logclass
class CustomerCATest(unittest.TestCase):
    @logmethod
    def setUp(self):
        # Loading DB dump by script (jongsoo.bae) aurora.activate()
        ## webdriver according to browser
        if len(g_args_list) == 1:
            g_args_list['BROWSER'] = 'firefox'
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        elif len(g_args_list) == 2:
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-firefox.cdnetworks.com"
        elif len(g_args_list) == 5:
            self.driver = rc.get_driver(g_args_list['NODE'],g_args_list['BROWSER'],g_args_list['OS'],g_args_list['PORT'])
            if g_args_list['BROWSER'] == 'internet explorer':
                self.pad_name = "selenium-ie.cdnetworks.com"
            else:
                self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        else:
            raise Exception("The number of arguments is wrong.")

        driver = self.driver
        clear_db(self.pad_name)
        driver.get(AURORA_URL + "/accounts/login/")
        driver.maximize_window()
        driver.find_element_by_id("id_username").clear()
        driver.find_element_by_id("id_username").send_keys(g_args_list['USER'])
        driver.find_element_by_id("id_password").clear()
        driver.find_element_by_id("id_password").send_keys(SELF_PROV_USER['PASSWORD'])
        driver.find_element_by_id("id_login").click()
        time.sleep(3)

    @logmethod
    def tearDown(self):
        # Destroying DB (jongsoo.bae) aurora.deactivate()
        driver = self.driver
        driver.close()

    def createPAD(self):
        driver = self.driver
        driver.get(AURORA_URL + "/cui/int/pads/add/?m=190")
        time.sleep(3)
        driver.find_element_by_link_text("Add new PAD").click()
        time.sleep(3)
        
        ### CUI frame
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        for i in range(60):
            try:
                if "Input PAD settings manually" == driver.find_element_by_link_text("Input PAD settings manually").text: break
            except: pass
            time.sleep(1)
        else: self.fail("time out")
        driver.find_element_by_link_text("Input PAD settings manually").click()
        for i in range(60):
            try:
                if "PAD Set Up - 3 Steps" == driver.find_element_by_css_selector("#pad_edit > h2").text: break
            except: pass
            time.sleep(1)
        else: self.fail("time out")

        ### Step 1
        driver.find_element_by_id("id_pad").clear()
        driver.find_element_by_id("id_pad").send_keys(self.pad_name)
        driver.find_element_by_id("id_pad_aliases").clear()
        driver.find_element_by_id("id_pad_aliases").send_keys("alias."+self.pad_name)
        driver.find_element_by_id("id_origin").clear()
        driver.find_element_by_id("id_origin").send_keys("origin.cdnetworks.com")
        driver.find_element_by_id("id_backup_origin").clear()
        driver.find_element_by_id("id_backup_origin").send_keys("failover."+self.pad_name)
        Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-10: CA - Global Standard (Self Implementation)")
        driver.find_element_by_id("id_description").clear()
        driver.find_element_by_id("id_description").send_keys("selenium test")
        time.sleep(1)
        driver.find_element_by_link_text("Caching").click()
        driver.find_element_by_link_text("Request & Response").click()
        driver.find_element_by_link_text("Rewrite Rules").click()
        driver.find_element_by_id("id_full_url_rewrite_rules").clear()
        #driver.find_element_by_id("id_full_url_rewrite_rules").send_keys("^http://qatest.selenium.com/(.html*)")
        driver.find_element_by_link_text("Validation").click()
        driver.find_element_by_link_text("Video/Large File Delivery").click()
        driver.find_element_by_link_text("Misc").click()
        driver.find_element_by_name("submit").click()
        for i in range(80):
            try:
                if "Your settings for "+self.pad_name+" have been saved." == driver.find_element_by_css_selector("li").text: break
            except: pass
            time.sleep(1)
        else: self.fail("time out")
    

    @logmethod
    def test_ca_push_to_staging(self):
        driver = self.driver
        ## Self Provisioning : Push to Staging 
        if g_args_list['USER'] == 'test_ca_add_edit_priv@gala.cdn.com' or g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
            ### Asserts
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
            time.sleep(1)
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            try:
                print driver.find_element_by_link_text(self.pad_name).text
            except:
                self.createPAD()
                driver.get(AURORA_URL + "/cui/int/pads/?m=202")
                for i in range(60):
                    try:
                        if "Customer" == driver.find_element_by_css_selector("h2.se-title > span").text: break
                    except: pass
                    time.sleep(1)
                else: raise Exception("time out")
                driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            driver.find_element_by_link_text(self.pad_name).click()
            for i in range(60):
                try:
                    if "Push status : New" ==  driver.find_element_by_css_selector("h2").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")
            self.assertEqual("Production Site Settings", driver.find_element_by_xpath("//h2[2]").text)
            self.assertEqual(self.pad_name, driver.find_element_by_css_selector("td").text)
            self.assertEqual("alias."+self.pad_name, driver.find_element_by_css_selector("tr.row2 > td").text)
            self.assertEqual("origin.cdnetworks.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[5]/td").text)
            self.assertEqual("failover."+self.pad_name, driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[6]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[7]/td").text)
            self.assertEqual("40000548-10: CA - Global Standard (Self Implementation)", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[8]/td").text)
            self.assertEqual("selenium test", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[9]/td").text)
            driver.find_element_by_link_text("Caching").click()
            self.assertEqual("False", driver.find_element_by_css_selector("#pad_group_local_site_Caching > tr.row2 > td").text)
            self.assertEqual("Not Set", driver.find_element_by_css_selector("#pad_group_local_site_Caching > tr.row1 > td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[5]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[6]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[7]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[8]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[9]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[10]/td").text)
            driver.find_element_by_link_text("Request & Response").click()
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[3]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[4]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[5]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[6]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[7]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[8]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[9]/td").text)
            self.assertEqual("None", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[10]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[11]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[12]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[15]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[16]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[17]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[18]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[19]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[20]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[21]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[24]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[25]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[26]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[27]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[28]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[31]/td").text)
            driver.find_element_by_link_text("Rewrite Rules").click()
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[3]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[4]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[5]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[6]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[7]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[8]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[9]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[10]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[11]/td").text)
            driver.find_element_by_link_text("Validation").click()
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[3]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[4]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[5]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[6]/td").text)
            self.assertEqual("None", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[9]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[10]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[11]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[12]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[13]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[14]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[15]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[16]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[19]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[20]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[21]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[22]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[23]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[24]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[25]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[26]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[27]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[28]/td").text)
            driver.find_element_by_link_text("Video/Large File Delivery").click()
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[3]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[6]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[7]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[10]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[11]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[12]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[13]/td").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[14]/td").text)
            driver.find_element_by_link_text("Misc").click()
            if g_args_list['USER'] == 'test_ca_add_edit_priv@gala.cdn.com':
                self.assertEqual("test_ca_add_edit_priv@gala.cdn.com", driver.find_element_by_xpath("//table[@id='change_history']/tbody/tr/td[2]").text)
            elif g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
                self.assertEqual("test_master_priv@gala.cdn.com", driver.find_element_by_xpath("//table[@id='change_history']/tbody/tr/td[2]").text)
                
            ### Push to Staging
            driver.find_element_by_xpath("//input[@value='Push to Staging']").click()
            time.sleep(1)
            for i in range(60):
                try:
                    if "Submit Request" == driver.find_element_by_css_selector("h3").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")
            #driver.find_element_by_name("stats").click()
            driver.find_element_by_name("checklist").click()
            driver.find_element_by_name("comments").clear()
            driver.find_element_by_name("comments").send_keys("test")
            driver.find_element_by_name("submit").click()
            for i in range(60):
                try:
                    if "You have requested to push the pad [" + self.pad_name + "] to our staging servers." == driver.find_element_by_css_selector("h3").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")

            ### On Staging
            for i in range(120):
                try:
                    if "Push status : On Staging" == driver.find_element_by_css_selector("h2").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")
            ### Push history
            self.assertEqual("Staging", driver.find_element_by_xpath("//table[@id='push_history']/tbody/tr/td[1]").text)
            self.assertEqual(g_args_list['USER'], driver.find_element_by_xpath("//table[@id='push_history']/tbody/tr/td[3]").text)

        elif g_args_list['USER']=='test_ca_edit_priv@gala.cdn.com' or g_args_list['USER']=='test_ca_view_only_priv@gala.cdn.com' or g_args_list['USER']=='test_no_priv@gala.cdn.com':
            ## DWA menu
            driver = self.driver
            driver.get(AURORA_URL + "/cui/int/pads/add/?m=202")
            time.sleep(3)
            ## Access Denied
            for i in range(60):
                try:
                    if "Error 403" == driver.find_element_by_css_selector("h1.pa-title").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")

            try:
                if "Add new PAD" ==  driver.find_element_by_link_text("Add new PAD").text:
                    self.fail("Exist Add new PAD menu")
            except: pass

        """deleted for CA_PAD_checklist.
        ### Clear
        if g_args_list['USER'] == 'test_ca_add_edit_priv@gala.cdn.com' or g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
            import MySQLdb as mdb
            db = mdb.connect(CDB_URL, CDB_USER, CDB_PASS, 'centraldb')
            cursor = db.cursor()
            cursor.execute("UPDATE customer_site_cui SET push_status =0 WHERE serve_domain = '%s'" %(self.pad_name))
            # it needs to show delete link
            driver.refresh()
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))

            if g_args_list['BROWSER'] == 'safari' or g_args_list['BROWSER'] == 'chrome':
                driver.execute_script("window.confirm = function() { return true; }")
                driver.find_element_by_css_selector("a[data-delete='"+self.pad_name+"']").click()
            else:
                time.sleep(3)
                driver.find_element_by_link_text("delete").click()
                driver.switch_to_alert().accept()
            db.close()"""

        driver.save_screenshot('img/result/'+g_args_list['BROWSER']+'_'+g_args_list['USER']+'_'+ __file__.strip('.py')+'-add-result.png')
    
if __name__ == '__main__':
    global g_args_list
    g_args_list = handle_args(sys.argv)
    unittest.main()
