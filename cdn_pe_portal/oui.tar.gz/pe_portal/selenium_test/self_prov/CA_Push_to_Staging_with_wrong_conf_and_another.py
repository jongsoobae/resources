#!/usr/bin/python
#-*-encoding: utf-8-*-

## PATH
import time, unittest, sys, os, subprocess
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)

## CONFIGURATIONS
from selenium_test.config_constants import *
from selenium_test.shared_components.login import *
from selenium_test.shared_components.utils import *
from selenium_test.shared_components.decorator import *
from selenium_test.shared_components.api_handler import *
from selenium_test.shared_components.common_action import *
from selenium_test.config_user_constants import SELF_PROV_USER

## SELENIUM MODUES
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException

rc = SeleniumRC()
@logclass
class CustomerCATest(unittest.TestCase):
    j2_path = "./files/texts/"+__file__.strip('.py')
    @logmethod
    def setUp(self):
        ## webdriver according to browser
        if len(g_args_list) == 1:
            g_args_list['BROWSER'] = 'firefox'
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        elif len(g_args_list) == 2:
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-firefox.cdnetworks.com"
        elif len(g_args_list) == 5:
            self.driver = rc.get_driver(g_args_list['NODE'],g_args_list['BROWSER'],g_args_list['OS'],g_args_list['PORT'])
            if g_args_list['BROWSER'] == 'internet explorer':
                self.pad_name = "selenium-ie.cdnetworks.com"
            else:
                self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        else:
            raise Exception("The number of arguments is wrong.")
        common_login_action(self.driver, g_args_list['USER'], SELF_PROV_USER['PASSWORD'])

        # for another customer
        self.customer_driver = webdriver.Firefox()
        self.customer_driver.maximize_window()
        self.customer_pad_name = 'selenium-customer.cdnetworks.com'
        clear_db(self.pad_name, self.customer_pad_name)

    @logmethod
    def tearDown(self):
        driver = self.driver
        driver.quit()
        self.customer_driver.quit()

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test_push_to_staging_with_wrong_conf_and_another(self):
        print ""
        print "##################################################  PREPARATION  ##################################################"
        print "###                                                                                                             ###"
        print "### Register domains in your hosts, '10.40.210.239   " + SPECTRUMAPI_URL + "                   ###"
        print "###                                                                                                             ###"
        print "###################################################################################################################"
        print ""
        driver = self.driver
        stop_push_requester()
        clear_db(self.pad_name, self.customer_pad_name)
        if g_args_list['USER'] == 'test_ca_add_edit_priv@gala.cdn.com' or g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
            """Cases.
                add a PAD with wrong configuration (A,B) > Push to Staging with wrong A, B at one time
            """
            # another customer log-in
            common_login_action(self.customer_driver, ANOTHER_SELF_USER['USER_WITH_CA_ADD_EDIT_PRIV'], ANOTHER_SELF_USER['PASSWORD'])
            # stop push requester and be_config
            ## stop_push_requester()
            # make a pad with wrong configuration
            add_pad_with_wrong_conf(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            # (another customer) make a pad with wrong configuration
            add_pad_with_wrong_conf(self.customer_driver, self.customer_pad_name, ANOTHER_SELF_USER['USER_WITH_CA_ADD_EDIT_PRIV'], ANOTHER_SELF_USER['PASSWORD'], __file__)
            # push to staging at one time
            run_threads(push_to_stag_without_val, [self.customer_driver, self.customer_pad_name, ANOTHER_SELF_USER['USER_WITH_CA_ADD_EDIT_PRIV'], ANOTHER_SELF_USER['PASSWORD'], __file__],
                        push_to_stag_without_val, [driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__])
            ## push_to_stag_without_val(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            # (another customer) push to staging
            ## push_to_stag_without_val(self.customer_driver, self.customer_pad_name, ANOTHER_SELF_USER['USER_WITH_CA_ADD_EDIT_PRIV'], ANOTHER_SELF_USER['PASSWORD'], __file__)
            # start push requester and be_config
            start_push_requester()
            # wait for when threads are ended
            import pdb; pdb.set_trace()
            # check pushed result in Prism and Aurora
            for i in range(120):
                try:
                    if db_query('CDB', 'select', "select push_status from customer_site_cui where serve_domain like '"+ self.customer_pad_name +"'") == -4: break
                except: pass
                time.sleep(1)
            else: raise Exception("Check your push status of " + self.customer_pad_name)
            """Assertions.
                2 PAD errors in one cloumn of PRISM
                Only your PAD error in each CUI
            """
            # prism (we need a CDN account in LDAP)
            #val_errors_in_prism(err_msg, g_args_list['BROWSER'], __file__)
            # aurora cui
            val_errors_in_cui(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__, err_msg)
            val_errors_in_cui(self.customer_driver, self.customer_pad_name, ANOTHER_SELF_USER['USER_WITH_CA_ADD_EDIT_PRIV'], ANOTHER_SELF_USER['PASSWORD'], __file__, err_msg)


            """TearDown.
                clearing all tested data.
            """
            clear_db(self.pad_name, self.customer_pad_name)


if __name__ == '__main__':
    global g_args_list
    g_args_list = handle_args(sys.argv)
    unittest.main()
