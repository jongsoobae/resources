#!/usr/bin/python
#-*-encoding: utf-8-*-

## PATH
import time, unittest, sys, os, subprocess
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)

## CONFIGURATIONS
from selenium_test.shared_components.login import *
from selenium_test.shared_components.utils import *
from selenium_test.shared_components.decorator import *
from selenium_test.shared_components.common_action import *
from selenium_test.config_user_constants import SELF_PROV_USER
from selenium_test.config_constants import *

## SELENIUM MODUES
from selenium import webdriver
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys

rc = SeleniumRC()
@logclass
class CustomerCATest(unittest.TestCase):
    customer_name = "GALA NETWORKS"
    active_img_name = __file__.strip('.py') + '_active_pad.png'
    inactive_img_name = __file__.strip('.py') + '_inactive_pad.png'
    deleted_img_name = __file__.strip('.py') + '_deleted_pad.png'

    @logmethod
    def setUp(self):
        ## webdriver according to browser
        if len(g_args_list) == 1:
            g_args_list['BROWSER'] = 'firefox'
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        elif len(g_args_list) == 2:
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-firefox.cdnetworks.com"
        elif len(g_args_list) == 5:
            self.driver = rc.get_driver(g_args_list['NODE'],g_args_list['BROWSER'],g_args_list['OS'],g_args_list['PORT'])
            if g_args_list['BROWSER'] == 'internet explorer':
                self.pad_name = "selenium-ie.cdnetworks.com"
            else:
                self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        else:
            raise Exception("The number of arguments is wrong.")
        clear_db(self.pad_name)
        common_login_action(self.driver, g_args_list['USER'], SELF_PROV_USER['PASSWORD'])

    @logmethod
    def tearDown(self):
        driver = self.driver
        driver.quit()

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test1_ca_ssl_delete_push_prod_pad(self):
        driver = self.driver
        if g_args_list['USER'] == 'test_ca_ssl_add_edit_priv@gala.cdn.com' or g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
            ## Cases
            add_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            delete_pushed_prod_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Assertion
            val_no_such_element_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            val_modified_pad_in_OUI(self.customer_name, self.pad_name, __file__, 'after', self.deleted_img_name)

            ## Clear
            clear_db(self.pad_name)

        elif g_args_list['USER'] == 'test_ca_ssl_edit_priv@gala.cdn.com':
            ## Cases
            add_action = "add_pad(driver, '" + self.pad_name + "','test_ca_ssl_add_edit_priv@gala.cdn.com','" + g_args_list['BROWSER'] + "','" + __file__ + "')"
            push_stag_action = "push_to_stag(driver, '" + self.pad_name + "','test_ca_ssl_add_edit_priv@gala.cdn.com','" + g_args_list['BROWSER'] + "','" + __file__ + "')"
            push_prod_action = "push_to_prod(driver, '" + self.pad_name + "','test_ca_ssl_add_edit_priv@gala.cdn.com','" + g_args_list['BROWSER'] + "','" + __file__ + "')"
            change_user_action('test_ca_ssl_add_edit_priv@gala.cdn.com', SELF_PROV_USER['PASSWORD'], add_action, push_stag_action, push_prod_action)
            val_modified_pad_in_OUI(self.customer_name, self.pad_name, __file__, 'after', self.active_img_name)
            edit_ca_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            delete_pushed_prod_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Assertion
            val_no_such_element_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            val_modified_pad_in_OUI(self.customer_name, self.pad_name, __file__, 'after', self.deleted_img_name)

            ## Clear
            clear_db(self.pad_name)

        elif g_args_list['USER'] == 'test_ca_ssl_view_only_priv@gala.cdn.com':
            val_no_such_element_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

        elif g_args_list['USER'] == 'test_no_priv@gala.cdn.com':
            val_access_denied(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test2_ca_ssl_delete_push_stag_pad(self):
        driver = self.driver
        if g_args_list['USER'] == 'test_ca_ssl_add_edit_priv@gala.cdn.com' or g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
            ## Cases
            add_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            push_to_stag(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            edit_ca_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Assertion
            val_pad_status(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__, "New")

            ## Clear
            clear_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            val_no_such_element_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

        elif g_args_list['USER'] == 'test_ca_ssl_edit_priv@gala.cdn.com':
            ## Cases
            add_action = "add_pad(driver, '" + self.pad_name + "','test_ca_ssl_add_edit_priv@gala.cdn.com','" + g_args_list['BROWSER'] + "','" + __file__ + "')"
            push_stag_action = "push_to_stag(driver, '" + self.pad_name + "','test_ca_ssl_add_edit_priv@gala.cdn.com','" + g_args_list['BROWSER'] + "','" + __file__ + "')"
            change_user_action('test_ca_ssl_add_edit_priv@gala.cdn.com', SELF_PROV_USER['PASSWORD'], add_action, push_stag_action)

            ## Assertion
            val_no_such_element_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Clear
            clear_db(self.pad_name)

        elif g_args_list['USER'] == 'test_ca_ssl_view_only_priv@gala.cdn.com':
            val_no_such_element_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

        elif g_args_list['USER'] == 'test_no_priv@gala.cdn.com':
            val_access_denied(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test3_ca_ssl_delete_not_push_pad(self):
        driver = self.driver
        if g_args_list['USER'] == 'test_ca_ssl_add_edit_priv@gala.cdn.com' or g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
            ## Cases
            add_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            clear_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Assertion
            val_no_such_element_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

        elif g_args_list['USER']=='test_ca_ssl_edit_priv@gala.cdn.com':
            ## Cases
            add_action = "add_pad(driver, '" + self.pad_name + "','test_ca_ssl_add_edit_priv@gala.cdn.com','" + g_args_list['BROWSER'] + "','" + __file__ + "')"
            change_user_action('test_ca_ssl_add_edit_priv@gala.cdn.com', SELF_PROV_USER['PASSWORD'], add_action)

            ## Assertion
            val_no_such_element_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Clear
            clear_db(self.pad_name)

        elif g_args_list['USER']=='test_ca_ssl_view_only_priv@gala.cdn.com':
            val_no_such_element_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

        elif g_args_list['USER']=='test_no_priv@gala.cdn.com':
            val_access_denied(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

if __name__ == '__main__':
    global g_args_list
    g_args_list = handle_args(sys.argv)
    unittest.main()