#!/usr/bin/python
#-*-encoding: utf-8-*-

## PATH
import time, unittest, sys, os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)

## CONFIGURATIONS
from selenium_test.shared_components.login import SeleniumRC
from selenium_test.shared_components.utils import *
from selenium_test.shared_components.decorator import *
from selenium_test.config_user_constants import SELF_PROV_USER
from selenium_test.config_constants import *

## SELENIUM MODUES
from selenium.webdriver.support.ui import Select
from selenium import webdriver

rc = SeleniumRC()
@logclass
class CustomerCATest(unittest.TestCase):
    @logmethod
    def setUp(self):
        # Loading DB dump by script (jongsoo.bae) aurora.activate()
        ## webdriver according to browser
        if len(g_args_list) == 1:
            g_args_list['BROWSER'] = 'firefox'
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        elif len(g_args_list) == 2:
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-firefox.cdnetworks.com"
        elif len(g_args_list) == 5:
            self.driver = rc.get_driver(g_args_list['NODE'],g_args_list['BROWSER'],g_args_list['OS'],g_args_list['PORT'])
            if g_args_list['BROWSER'] == 'internet explorer':
                self.pad_name = "selenium-ie.cdnetworks.com"
            else:
                self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        else:
            raise Exception("The number of arguments is wrong.")

        clear_db(self.pad_name)
        # For testfile
        print ""
        print "######################################################################"
        print "##             Please locate a testfile in below path               ##"
        print "##        Windows, C:\\testfile            LINUX, /testfile          ##"
        print "######################################################################"
        print ""
        # Check the status of PAD (if not, created a PAD and implemented push to staging)
        import subprocess
        import MySQLdb as mdb
        prev_file = 'DWA_SSL_Push_to_Staging_Success.py'
        cdb = mdb.connect(CDB_URL, CDB_USER, CDB_PASS, 'centraldb')
        cursor = cdb.cursor()
        if cursor.execute("select push_status from customer_site_cui WHERE serve_domain = '%s'" %(self.pad_name)) == 0L:
            if os.path.isfile(BASE_DIR + '/selenium_test/self_prov/' + prev_file):
                proc = subprocess.Popen('python '+prev_file+' test_dwa_add_edit_priv@gala.cdn.com',shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,)
                stdout_val, stderr_val = proc.communicate()
                print repr(stdout_val)
            else:
                raise Exception("You dont' have a %s file" %prev_file)
        cdb.close()

        driver = self.driver
        driver.get(AURORA_URL + "/accounts/login/")
        driver.find_element_by_id("id_username").clear()
        driver.find_element_by_id("id_username").send_keys(g_args_list['USER'])
        driver.find_element_by_id("id_password").clear()
        driver.find_element_by_id("id_password").send_keys(SELF_PROV_USER['PASSWORD'])
        driver.find_element_by_id("id_login").click()
        time.sleep(3)

    @logmethod
    def tearDown(self):
        # Destroying DB (jongsoo.bae) aurora.deactivate()
        driver = self.driver
        driver.close()

    @logmethod
    def test_dwa_ssl_pad_checklist(self):
        driver = self.driver
        ## Self Provisioning : Push to Staging 
        if g_args_list['USER'] == 'test_dwa_add_edit_priv@gala.cdn.com' or g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
            ## DWA SSL PAD checklist
            ### GET method
            driver = self.driver
            driver.get(AURORA_URL + "/cui/int/pad-checklist/?m=213")
            driver.find_element_by_link_text("PAD checklist").click()
            time.sleep(1)
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            time.sleep(1)
            self.assertEqual("Check the PAD Configuration on the Staging", driver.find_element_by_xpath("//h2[3]").text)
            #Select(driver.find_element_by_xpath("//span")).select_by_visible_text("selenium-firefox.cdnetworks.com")
            ## No ways to use Select in span tag. It needs id (By Dev) OUI-1880
            driver.find_element_by_xpath("//span").click()
            count = 1
            while True:
                try:
                    if driver.find_element_by_xpath("//div[@id='id_PAD_name_chosen']/div/ul/li["+str(count)+"]").text == self.pad_name:
                        driver.find_element_by_xpath("//div[@id='id_PAD_name_chosen']/div/ul/li["+str(count)+"]").click()
                        break
                    count = count + 1
                except Exception as e:
                    raise Exception("We can NOT find out http://%s" (self.pad_name))
            time.sleep(1)
            Select(driver.find_element_by_id("id_node_ip")).select_by_visible_text("Random selected.")
            driver.find_element_by_id("id_url_name").clear()
            driver.find_element_by_id("id_url_name").send_keys("http://"+self.pad_name+"/test")
            driver.find_element_by_id("id_additionals").clear()
            driver.find_element_by_id("id_additionals").send_keys("User-Agent: test\\r\\nRefer: test")
            driver.find_element_by_css_selector("input[type=\"submit\"]").click()
            for i in range(60):
                try:
                    if "Trace Result" == driver.find_element_by_css_selector("ol > p").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")
            if driver.find_element_by_css_selector("pre").text.rfind('HTTP/1.1 200 OK') is not -1:
                pass
            else:
                raise Exception("Check your PAD. Its result is NOT okay.")

            ### POST method
            driver = self.driver
            driver.get(AURORA_URL + "/cui/int/pad-checklist/?m=213")
            driver.find_element_by_link_text("PAD checklist").click()
            time.sleep(1)
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            time.sleep(1)
            self.assertEqual("Check the PAD Configuration on the Staging", driver.find_element_by_xpath("//h2[3]").text)
            # Select(driver.find_element_by_xpath("//span")).select_by_visible_text("selenium-firefox.cdnetworks.com")
            ## No ways to use Select in span tag. It needs id (By Dev) OUI-1880
            driver.find_element_by_xpath("//span").click()
            while True:
                try:
                    if driver.find_element_by_xpath("//div[@id='id_PAD_name_chosen']/div/ul/li["+str(count)+"]").text == self.pad_name:
                        driver.find_element_by_xpath("//div[@id='id_PAD_name_chosen']/div/ul/li["+str(count)+"]").click()
                        break
                    count = count + 1
                except Exception as e:
                    raise Exception("We can NOT find out http://%s" (self.pad_name))
            time.sleep(1)
            Select(driver.find_element_by_id("id_node_ip")).select_by_visible_text("Random selected.")
            driver.find_element_by_id("id_url_name").clear()
            driver.find_element_by_id("id_url_name").send_keys("http://"+self.pad_name+"/test")
            driver.find_element_by_id("id_additionals").clear()
            driver.find_element_by_id("id_additionals").send_keys("User-Agent: test\\r\\nRefer: test")
            driver.find_element_by_id("id_file").clear()
            # Uploading a file to remote site
            if len(g_args_list) == 5 and g_args_list['OS'] == 'WINDOWS':
                print("Please update test file in C:\\testfile")
                driver.find_element_by_id("id_file").send_keys("C:\\testfile")
            elif len(g_args_list) == 5 and g_args_list['OS'] == 'LINUX':
                print("Please update test file in /testfile")
                driver.find_element_by_id("id_file").send_keys("/testfile")
            else:
                driver.find_element_by_id("id_file").send_keys(os.getcwd()+"/img/testfile")
            time.sleep(1)
            driver.find_element_by_css_selector("input[type=\"submit\"]").click()
            for i in range(60):
                try:
                    if "Trace Result" == driver.find_element_by_css_selector("ol > p").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")
            if driver.find_element_by_css_selector("pre").text.rfind('HTTP/1.1 200 OK') is not -1:
                pass
            else:
                raise Exception("Check your PAD. Its result is NOT okay.")

            ### SSL
            driver = self.driver
            driver.get(AURORA_URL + "/cui/int/pad-checklist/?m=213")
            driver.find_element_by_link_text("PAD checklist").click()
            time.sleep(1)
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            time.sleep(1)
            self.assertEqual("Check the PAD Configuration on the Staging", driver.find_element_by_xpath("//h2[3]").text)
            driver.find_element_by_xpath("//span").click()
            count = 1
            while True:
                try:
                    if driver.find_element_by_xpath("//div[@id='id_PAD_name_chosen']/div/ul/li["+str(count)+"]").text == self.pad_name:
                        driver.find_element_by_xpath("//div[@id='id_PAD_name_chosen']/div/ul/li["+str(count)+"]").click()
                        break
                    count = count + 1
                except Exception as e:
                    raise Exception("We can NOT find out http://%s" (self.pad_name))
            time.sleep(1)
            Select(driver.find_element_by_id("id_node_ip")).select_by_visible_text("Random selected.")
            driver.find_element_by_id("id_url_name").clear()
            driver.find_element_by_id("id_url_name").send_keys("https://"+self.pad_name+"/test")
            driver.find_element_by_id("id_additionals").clear()
            driver.find_element_by_id("id_additionals").send_keys("User-Agent: test\\r\\nRefer: test")
            driver.find_element_by_css_selector("input[type=\"submit\"]").click()
            for i in range(60):
                try:
                    if "Trace Result" == driver.find_element_by_css_selector("ol > p").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")
            time.sleep(1)
            if driver.find_element_by_css_selector("pre").text.rfind('HTTP/1.1 200 OK') is not -1:
                pass
            else:
                raise Exception("Check your PAD. Its result is NOT okay.")

            ## Clear
            import MySQLdb as mdb
            db = mdb.connect(CDB_URL, CDB_USER, CDB_PASS, 'centraldb')
            cursor = db.cursor()
            cursor.execute("UPDATE customer_site_cui SET push_status = 0 WHERE serve_domain = '%s'" %(self.pad_name))
            # it needs to show delete link
            db.commit()
            db.close()
            driver.get(AURORA_URL + "/cui/int/pads/?m=217")
            driver.refresh()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))

            if g_args_list['BROWSER'] == 'safari' or g_args_list['BROWSER'] == 'chrome':
                driver.execute_script("window.confirm = function() { return true; }")
                driver.find_element_by_css_selector("a[data-delete='"+self.pad_name+"']").click()
            else:
                time.sleep(3)
                driver.find_element_by_link_text("delete").click()
                driver.switch_to_alert().accept()

        elif g_args_list['USER']=='test_no_priv@gala.cdn.com':
            ## DWA SSL PAD checklist
            driver = self.driver
            driver.get(AURORA_URL + "/cui/int/pad-checklist/?m=213")
            time.sleep(3)
            ## Access Denied
            for i in range(60):
                try:
                    if "Error 403" == driver.find_element_by_css_selector("h1.pa-title").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")

            try:
                if "Add new PAD" ==  driver.find_element_by_link_text("Add new PAD").text:
                    self.fail("Exist Add new PAD menu")
            except: pass

        elif g_args_list['USER']=='test_dwa_edit_priv@gala.cdn.com' or g_args_list['USER']=='test_dwa_view_only_priv@gala.cdn.com':
            ## DWA SSL PAD checklist
            driver = self.driver
            driver.get(AURORA_URL + "/cui/int/pad-checklist/?m=213")
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            time.sleep(3)
            for i in range(60):
                try:
                    if "General" == driver.find_element_by_css_selector("h2").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")
            self.assertEqual("Cache-Control Headers", driver.find_element_by_xpath("//h2[2]").text)
            self.assertEqual("Check the PAD Configuration on the Staging", driver.find_element_by_xpath("//h2[3]").text)
        driver.save_screenshot('img/result/'+g_args_list['BROWSER']+'_'+g_args_list['USER']+'_'+ __file__.strip('.py')+'-add-result.png')
    
if __name__ == '__main__':
    global g_args_list
    g_args_list = handle_args(sys.argv)
    unittest.main()
