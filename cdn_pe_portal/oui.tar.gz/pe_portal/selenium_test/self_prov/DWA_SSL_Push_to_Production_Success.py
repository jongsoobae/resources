#!/usr/bin/python
#-*-encoding: utf-8-*-

## PATH
import time, unittest, sys, os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)
import MySQLdb as mdb
import subprocess

## CONFIGURATIONS
from selenium_test.shared_components.login import SeleniumRC
from selenium_test.shared_components.utils import *
from selenium_test.shared_components.decorator import *
from selenium_test.shared_components.common_action import *
from selenium_test.config_user_constants import SELF_PROV_USER
from selenium_test.config_constants import *

## SELENIUM MODUES
from selenium import webdriver
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys

rc = SeleniumRC()
@logclass
class CustomerCATest(unittest.TestCase):
    # global variables
    CDB = mdb.connect(CDB_URL, CDB_USER, CDB_PASS, 'centraldb')
    CURSOR = CDB.cursor()
    PREV_FILE = 'DWA_SSL_Push_to_Staging_Success.py'

    @logmethod
    def setUp(self):
        print ""
        print "##################################################  PREPARATION  ##################################################"
        print "###                                                                                                             ###"
        print "### Register domains in your hosts, '10.40.210.250   h0-s107.qa-tst.cdngp.net' (CLIENT)                         ###"
        print "### Locate 'DWA_SSL_Push_to_Staging_Success.py' in same directory                                               ###"
        print "###                                                                                                             ###"
        print "###################################################################################################################"
        print ""

        ## webdriver according to browser
        if len(g_args_list) == 1:
            g_args_list['BROWSER'] = 'firefox'
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        elif len(g_args_list) == 2:
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-firefox.cdnetworks.com"
        elif len(g_args_list) == 5:
            self.driver = rc.get_driver(g_args_list['NODE'],g_args_list['BROWSER'],g_args_list['OS'],g_args_list['PORT'])
            if g_args_list['BROWSER'] == 'internet explorer':
                #self.pad_name = "selenium-ie.cdnetworks.com"
                self.pad_name = "selenium-firefox.cdnetworks.com"
            else:
                #self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
                self.pad_name = "selenium-firefox.cdnetworks.com"
        else:
            raise Exception("The number of arguments is wrong.")
        driver = self.driver
        clear_db(self.pad_name)
        driver.get(AURORA_URL + "/accounts/login/")
        driver.find_element_by_id("id_username").clear()
        driver.find_element_by_id("id_username").send_keys(g_args_list['USER'])
        driver.find_element_by_id("id_password").clear()
        driver.find_element_by_id("id_password").send_keys(SELF_PROV_USER['PASSWORD'])
        driver.find_element_by_id("id_login").click()
        time.sleep(3)

    @logmethod
    def createPAD(self):
        # Check the status of PAD (if not, created a PAD and implemented push to staging)
        if self.CURSOR.execute("select push_status from customer_site_cui WHERE serve_domain='%s'" %(self.pad_name)) == 0L:
            if os.path.isfile(BASE_DIR + '/selenium_test/self_prov/' + self.PREV_FILE):
                proc = subprocess.Popen('python '+self.PREV_FILE+' test_dwa_ssl_add_edit_priv@gala.cdn.com',shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                stdout_val, stderr_val = proc.communicate()
                print repr(stdout_val)
            else:
                raise Exception("You dont' have a %s file" %(self.PREV_FILE))
        elif self.CURSOR.execute("select push_status from customer_site_cui WHERE serve_domain='%s' and push_status!=2" %(self.pad_name)) != 0L:
            raise Exception("Please remove your '%s' firstly" %(self.pad_name))

    @logmethod
    def clearPAD(self):
        driver = self.driver
        # CDB
        self.CURSOR.execute("UPDATE customer_site SET status = 0 WHERE serve_domain = '%s'" %(self.pad_name))
        self.CURSOR.execute("UPDATE customer_site_cui SET push_status = 0 WHERE serve_domain = '%s'" %(self.pad_name))
        self.CDB.commit()
        # AURORAUI
        driver.refresh()
        driver.get(AURORA_URL + "/cui/int/pads/?m=217")
        time.sleep(1)
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        if g_args_list['BROWSER'] == 'safari' or g_args_list['BROWSER'] == 'chrome':
            driver.execute_script("window.confirm = function() { return true; }")
            driver.find_element_by_css_selector("a[data-delete='"+self.pad_name+"']").click()
        else:
            time.sleep(3)
            driver.find_element_by_css_selector("a[data-delete='"+self.pad_name+"']").click()
            driver.switch_to_alert().accept()
            time.sleep(1)
        # CDB
        self.CURSOR.execute("DELETE FROM customer_site WHERE serve_domain = '%s'" %(self.pad_name))
        self.CDB.commit()

    @logmethod
    def pad_validation(self):
        # Curl test
        print "Register the 'h0-s107.qa-tst.cdngp.net' in your hosts"
        import paramiko
        CLIENT_HOST = 'h0-s107.qa-tst.cdngp.net'
        CS_HOST = 'h0-s170.p99-sjc.cdngp.net'
        CURL_CMD = "curl -v -k -H'Host: "+ self.pad_name +"' 'https://" + CS_HOST + "/test'"
        KEY = paramiko.RSAKey.from_private_key_file(SSH_OPG_KEY)

        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(CLIENT_HOST, username='cloud-user', port=2113, pkey=KEY)
            stdin, stdout, stderr = client.exec_command(CURL_CMD)
            curl_result = stderr.read()
            print curl_result
            if curl_result.find("HTTP/1.1 200 OK") and curl_result.find("SSL certificate verify result: self signed certificate"):
                pass
            else:
                raise Exception("Check your domains, CLIENT_HOST: %s and CS_HOST: %s" (CLIENT_HOST, CS_HOST))
        except Exception as e:
            print "Error: %s" (e)

    @logmethod
    def tearDown(self):
        driver = self.driver
        self.CDB.close()
        driver.quit()

    @logmethod
    def test_dwa_ssl_push_to_production(self):
        driver = self.driver
        clear_db(self.pad_name)
        ## Self Provisioning : Push to Production
        if g_args_list['USER'] == 'test_dwa_ssl_add_edit_priv@gala.cdn.com' or g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
            self.createPAD()
            ### Push to Production
            driver.get(AURORA_URL + "/cui/int/pads/?m=217")
            time.sleep(1)
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            time.sleep(1)
            # The click method doesn't work in not firefox
            if g_args_list['BROWSER'] == 'firefox':
                driver.find_element_by_link_text(self.pad_name).click()
            else: driver.find_element_by_link_text(self.pad_name).send_keys(Keys.ENTER)
            for i in range(60):
                try:
                    if "Push status : On Staging" == driver.find_element_by_css_selector("h2").text: break
                except: pass
                time.sleep(1)
                driver.switch_to.parent_frame()
                driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            else: self.fail("time out")
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            driver.find_element_by_xpath("//input[@value='Push to Production']").click()
            #driver.find_element_by_name("stats").click()
            driver.find_element_by_name("checklist").click()
            driver.find_element_by_name("comments").clear()
            driver.find_element_by_name("comments").send_keys("push to production test")
            driver.find_element_by_name("submit").click()
            for i in range(60):
                try:
                    if "You have requested to push the pad ["+self.pad_name+"] to our production servers." == driver.find_element_by_css_selector("h3").text: break
                except: pass
                time.sleep(1)
                driver.switch_to.parent_frame()
                driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            else: self.fail("time out")
            for i in range(80):
                try:
                    if "Push status : On Production" == driver.find_element_by_css_selector("h2").text: break
                except: pass
                time.sleep(1)
                driver.switch_to.parent_frame()
                driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            else: self.fail("time out")
            for i in range(60):
                try:
                    if "100.00" == driver.find_element_by_xpath("//table[@id='push_history']/tbody/tr/td[4]").text:
                        print driver.find_element_by_xpath("//table[@id='push_history']/tbody/tr/td[4]").text + '%'
                        break
                    print driver.find_element_by_xpath("//table[@id='push_history']/tbody/tr/td[4]").text + '%'
                except: pass
                time.sleep(1)
                driver.get(AURORA_URL + "/cui/int/pads/?m=217")
                driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
                if g_args_list['BROWSER'] is not 'firefox':
                    time.sleep(10)
                else: time.sleep(1)
                driver.find_element_by_link_text(self.pad_name).click()
            else: self.fail("time out")

            ### Change History
            #self.assertEqual("New Added!", driver.find_element_by_css_selector("#change_history > tbody > tr > td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//table[@id='change_history']/tbody/tr/td[4]").text)
            # The PAD created by "test_ca_add_edit_priv@gala.cdn.com"
            self.assertEqual("test_dwa_ssl_add_edit_priv@gala.cdn.com", driver.find_element_by_xpath("//table[@id='change_history']/tbody/tr/td[2]").text)

            ### Push history
            self.assertEqual("Production", driver.find_element_by_xpath("//table[@id='push_history']/tbody/tr/td[1]").text)
            self.assertEqual(g_args_list['USER'], driver.find_element_by_xpath("//table[@id='push_history']/tbody/tr/td[3]").text)
            driver.save_screenshot('img/result/'+g_args_list['BROWSER']+'_'+g_args_list['USER']+'_'+ __file__.strip('.py')+'-add-result.png')
            self.pad_validation()

            ## Clear
            clear_db(self.pad_name)
            """
            # NGPDB (Related to PE2NGP sync module)
            ngpdb = mdb.connect(NGPDB_URL, NGPDB_USER, NGPDB_PASS, 'spectrum')
            ngp_cursor = ngpdb.cursor()
            ngp_cursor.excute("DELETE FROM stat_api_key WHERE stat_id=(SELECT statmaster_id from cs_stat_master WHERE domain = '%s'" %(self.pad_name))
            ngp_cursor.execute("DELETE FROM stat_master WHERE stat_id = (SELECT statmaster_id from cs_stat_master WHERE domain = '%s'" %(self.pad_name))
            ngp_cursor.execute("DELETE FROM cs_stat_master WHERE domain = '%s'" %(self.pad_name))
            ngp_cusrsor.commit()
            ngpdb.close()"""

        elif g_args_list['USER']=='test_dwa_edit_priv@gala.cdn.com' or g_args_list['USER']=='test_dwa_view_only_priv@gala.cdn.com':

            if self.CURSOR.execute("select push_status from customer_site_cui WHERE serve_domain = '%s'" %(self.pad_name)) == 0L:
                self.createPAD()
            driver = self.driver
            driver.get(AURORA_URL + "/cui/int/pads/?m=217")
            time.sleep(1)
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            for i in range(60):
                try:
                    if "Note: - Pad diff viewer" == driver.find_element_by_css_selector("h2").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")
            try:
                driver.find_element_by_link_text(self.pad_name).text
            except NoSuchElementException as e:
                pass

        elif g_args_list['USER']=='test_no_priv@gala.cdn.com':
            driver = self.driver
            driver.get(AURORA_URL + "/cui/int/pads/?m=217")
            time.sleep(3)
            ## Access Denied
            for i in range(60):
                try:
                    if "Error 403" == driver.find_element_by_css_selector("h1.pa-title").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")
    
if __name__ == '__main__':
    global g_args_list
    g_args_list = handle_args(sys.argv)
    unittest.main()
