#!/usr/bin/python
#-*-encoding: utf-8-*-

## PATH
import time, unittest, sys, os, subprocess
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)

## CONFIGURATIONS
from selenium_test.shared_components.login import *
from selenium_test.shared_components.utils import *
from selenium_test.shared_components.decorator import *
from selenium_test.shared_components.common_action import *
from selenium_test.config_user_constants import SELF_PROV_USER
from selenium_test.config_constants import *

## SELENIUM MODUES
from selenium import webdriver
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys

rc = SeleniumRC()
@logclass
class CustomerCATest(unittest.TestCase):
    customer_name = "GALA NETWORKS"
    modified_img_name = __file__.strip('.py') + '_modified_pad.png'

    @logmethod
    def setUp(self):
        ## webdriver according to browser
        if len(g_args_list) == 1:
            g_args_list['BROWSER'] = 'firefox'
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        elif len(g_args_list) == 2:
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-firefox.cdnetworks.com"
        elif len(g_args_list) == 5:
            self.driver = rc.get_driver(g_args_list['NODE'],g_args_list['BROWSER'],g_args_list['OS'],g_args_list['PORT'])
            if g_args_list['BROWSER'] == 'internet explorer':
                self.pad_name = "selenium-ie.cdnetworks.com"
            else:
                self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        else:
            raise Exception("The number of arguments is wrong.")
        clear_db(self.pad_name)
        common_login_action(self.driver, g_args_list['USER'], SELF_PROV_USER['PASSWORD'])

    @logmethod
    def tearDown(self):
        driver = self.driver
        driver.close()

    @logmethod
    def val_restored_pad(self):
        driver = self.driver
        time.sleep(2)
        self.assertEqual(self.pad_name, driver.find_element_by_css_selector("tr.row2 > td").text)
        self.assertEqual("alias." + self.pad_name, driver.find_element_by_xpath("//tbody[@id='pad_group_prod_site_Basic']/tr[5]/td").text)
        self.assertEqual("selenium test", driver.find_element_by_xpath("//tbody[@id='pad_group_prod_site_Basic']/tr[10]/td").text)
        driver.find_element_by_link_text("Request & Response").click()
        self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_prod_site_Request & Response']/tr[29]/td").text)
        self.assertEqual("Restore", driver.find_element_by_css_selector("#change_history > tbody > tr > td").text)
        self.assertEqual("3", driver.find_element_by_xpath("//table[@id='change_history']/tbody/tr/td[4]").text)

    def val_restored_pad_stag(self):
        driver = self.driver
        time.sleep(2)
        self.assertEqual("selenium test", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[9]/td").text)
        self.assertEqual("alias." + self.pad_name, driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[4]/td").text)
        self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[7]/td").text)
        driver.find_element_by_link_text("Request & Response").click()
        self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[24]/td").text)
        self.assertEqual("Restore", driver.find_element_by_css_selector("#change_history > tbody > tr > td").text)
        self.assertEqual("3", driver.find_element_by_xpath("//table[@id='change_history']/tbody/tr/td[4]").text)

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test1_dwa_ssl_add_edit_restore(self):
        driver = self.driver
        if g_args_list['USER'] == 'test_dwa_ssl_add_edit_priv@gala.cdn.com' or g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
            ## Cases
            add_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Assertion
            val_no_such_element_svndiff(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Clear
            clear_pad_prod(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

        elif g_args_list['USER'] == 'test_dwa_ssl_view_only_priv@gala.cdn.com' or g_args_list['USER'] == 'test_dwa_ssl_edit_priv@gala.cdn.com':
            val_no_such_element_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

        elif g_args_list['USER'] == 'test_no_priv@gala.cdn.com':
            val_access_denied(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test2_dwa_ssl_add_stage_edit_restore(self):
        driver = self.driver
        if g_args_list['USER'] == 'test_dwa_ssl_add_edit_priv@gala.cdn.com' or g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
            ## Cases
            add_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            push_to_stag(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            edit_ca_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            restore_from_this_version(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Assertion
            self.val_restored_pad_stag()

            ## Clear
            clear_pad_prod(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

        elif g_args_list['USER'] == 'test_dwa_ssl_edit_priv@gala.cdn.com':
            ## Cases
            add_action = "add_pad(driver, '" + self.pad_name + "','test_dwa_ssl_add_edit_priv@gala.cdn.com','" + g_args_list['BROWSER'] + "','" + __file__ + "')"
            push_stag_action = "push_to_stag(driver, '" + self.pad_name + "','test_master_priv@gala.cdn.com','" + g_args_list['BROWSER'] + "','" + __file__ + "')"
            change_user_action('test_master_priv@gala.cdn.com', SELF_PROV_USER['PASSWORD'], add_action, push_stag_action)

            ## Assertion
            val_no_such_element_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Clear
            del_action = "clear_pad_prod(driver, '" + self.pad_name + "','test_master_priv@gala.cdn.com','" + g_args_list['BROWSER'] + "','" + __file__ + "')"
            change_user_action('test_master_priv@gala.cdn.com', SELF_PROV_USER['PASSWORD'], del_action)

        elif g_args_list['USER'] == 'test_dwa_ssl_view_only_priv@gala.cdn.com':
            val_no_such_element_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

        elif g_args_list['USER'] == 'test_no_priv@gala.cdn.com':
            val_access_denied(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test3_dwa_ssl_add_stag_prod_edit_restore(self):
        driver = self.driver
        if g_args_list['USER'] == 'test_dwa_ssl_add_edit_priv@gala.cdn.com' or g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
            ## Cases
            add_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            push_to_stag(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            push_to_prod(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            edit_ca_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            val_modified_pad_in_OUI(self.customer_name, self.pad_name, __file__, 'after', self.modified_img_name)
            restore_from_this_version(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Assertion
            self.val_restored_pad()

            ## Clear
            clear_db(self.pad_name)

        elif g_args_list['USER']=='test_dwa_ssl_edit_priv@gala.cdn.com':
            ## Cases
            add_action = "add_pad(driver, '" + self.pad_name + "','test_dwa_ssl_add_edit_priv@gala.cdn.com','" + g_args_list['BROWSER'] + "','" + __file__ + "')"
            push_stag_action = "push_to_stag(driver, '"+self.pad_name+"','test_master_priv@gala.cdn.com','"+g_args_list['BROWSER']+"','"+__file__+"')"
            push_prod_action = "push_to_prod(driver, '"+self.pad_name+"','test_master_priv@gala.cdn.com','"+g_args_list['BROWSER']+"','"+__file__+"')"
            change_user_action('test_master_priv@gala.cdn.com', SELF_PROV_USER['PASSWORD'], add_action, push_stag_action, push_prod_action)
            edit_ca_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            val_modified_pad_in_OUI(self.customer_name, self.pad_name, __file__, 'after', self.modified_img_name)
            restore_from_this_version(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Assertion
            self.val_restored_pad()

            ## Clear
            clear_db(self.pad_name)

        elif g_args_list['USER']=='test_dwa_ssl_view_only_priv@gala.cdn.com':
            val_no_such_element_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

        elif g_args_list['USER']=='test_no_priv@gala.cdn.com':
            val_access_denied(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test4_dwa_ssl_add_stag_prod_edit_restore_push(self):
        driver = self.driver
        if g_args_list['USER'] == 'test_dwa_ssl_add_edit_priv@gala.cdn.com' or g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
            ## Cases
            add_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            push_to_stag(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            push_to_prod(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            edit_ca_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            val_modified_pad_in_OUI(self.customer_name, self.pad_name, __file__, 'after', self.modified_img_name)
            restore_and_push_to_staging(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Assertion
            time.sleep(2)
            self.assertEqual("Push status : On Staging", driver.find_element_by_css_selector("h2").text)
            self.val_restored_pad()

            ## Clear
            clear_db(self.pad_name)

        elif g_args_list['USER'] == 'test_dwa_ssl_edit_priv@gala.cdn.com':
            ## Cases
            add_action = "add_pad(driver, '" + self.pad_name + "','test_dwa_ssl_add_edit_priv@gala.cdn.com','" + g_args_list['BROWSER'] + "','" + __file__ + "')"
            push_stag_action = "push_to_stag(driver, '" + self.pad_name + "','test_dwa_ssl_add_edit_priv@gala.cdn.com','" + g_args_list['BROWSER'] + "','" + __file__ + "')"
            push_prod_action = "push_to_prod(driver, '" + self.pad_name + "','test_dwa_ssl_add_edit_priv@gala.cdn.com','" + g_args_list['BROWSER'] + "','" + __file__ + "')"
            change_user_action('test_dwa_ssl_add_edit_priv@gala.cdn.com', SELF_PROV_USER['PASSWORD'], add_action, push_stag_action, push_prod_action)
            edit_ca_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            val_modified_pad_in_OUI(self.customer_name, self.pad_name, __file__, 'after', self.modified_img_name)
            restore_and_push_to_staging(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Assertion
            time.sleep(2)
            self.assertEqual("Push status : On Staging", driver.find_element_by_css_selector("h2").text)
            self.val_restored_pad()

            ## Clear
            clear_db(self.pad_name)

        elif g_args_list['USER'] == 'test_dwa_ssl_view_only_priv@gala.cdn.com':
            val_no_such_element_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

        elif g_args_list['USER'] == 'test_no_priv@gala.cdn.com':
            val_access_denied(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
    
if __name__ == '__main__':
    global g_args_list
    g_args_list = handle_args(sys.argv)
    unittest.main()