#!/usr/bin/python
#-*-encoding: utf-8-*-

## PATH
import time, unittest, sys, os, subprocess
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)

## CONFIGURATIONS
from selenium_test.shared_components.login import *
from selenium_test.shared_components.utils import *
from selenium_test.shared_components.decorator import *
from selenium_test.shared_components.common_action import *
from selenium_test.config_user_constants import SELF_PROV_USER
from selenium_test.config_constants import *

## SELENIUM MODUES
from selenium import webdriver
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys

rc = SeleniumRC()
@logclass
class CustomerCATest(unittest.TestCase):
    cop_product_id = '0040000548-000020'

    @logmethod
    def setUp(self):
        ## webdriver according to browser
        if len(g_args_list) == 1:
            g_args_list['BROWSER'] = 'firefox'
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        elif len(g_args_list) == 2:
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-firefox.cdnetworks.com"
        elif len(g_args_list) == 5:
            self.driver = rc.get_driver(g_args_list['NODE'],g_args_list['BROWSER'],g_args_list['OS'],g_args_list['PORT'])
            if g_args_list['BROWSER'] == 'internet explorer':
                self.pad_name = "selenium-ie.cdnetworks.com"
            else:
                self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        else:
            raise Exception("The number of arguments is wrong.")
        clear_db(self.pad_name)
        common_login_action(self.driver, g_args_list['USER'], SELF_PROV_USER['PASSWORD'])

    @logmethod
    def tearDown(self):
        driver = self.driver
        driver.close()

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test1_dwa_expire_contract_and_add_a_pad(self):
        driver = self.driver
        if g_args_list['USER'] == 'test_dwa_add_edit_priv@gala.cdn.com' or g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
            ## Cases
            expire_or_activate_contract_item_cdb(self.cop_product_id, 0) # expire

            ## Assertion
            add_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Clear
            expire_or_activate_contract_item_cdb(self.cop_product_id, 1)  # activate

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test2_dwa_expire_contract_and_edit_a_pushed_prod_pad(self):
        driver = self.driver
        if g_args_list['USER'] == 'test_dwa_add_edit_priv@gala.cdn.com' or g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
            ## Cases
            add_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], 'DWA_add_PAD')
            push_to_stag(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], 'DWA_push_to_staging_PAD')
            push_to_prod(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], 'DWA_push_to_production_PAD')
            expire_or_activate_contract_item_cdb(self.cop_product_id, 0)  # expire

            ## Assertion
            edit_ca_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Clear
            expire_or_activate_contract_item_cdb(self.cop_product_id, 1)  # activate
            clear_db(self.pad_name)

        elif g_args_list['USER'] == 'test_dwa_edit_priv@gala.cdn.com':
            ## Cases
            add_action = "add_pad(driver, '" + self.pad_name + "','test_dwa_add_edit_priv@gala.cdn.com','" + g_args_list['BROWSER'] + "','DWA_add_PAD')"
            push_stag_action = "push_to_stag(driver, '" + self.pad_name + "','test_dwa_add_edit_priv@gala.cdn.com','" + g_args_list['BROWSER'] + "','DWA_push_staging_PAD')"
            push_prod_action = "push_to_prod(driver, '" + self.pad_name + "','test_dwa_add_edit_priv@gala.cdn.com','" + g_args_list['BROWSER'] + "','DWA_push_production_PAD')"
            change_user_action('test_dwa_add_edit_priv@gala.cdn.com', SELF_PROV_USER['PASSWORD'], add_action, push_stag_action, push_prod_action)
            expire_or_activate_contract_item_cdb(self.cop_product_id, 0)  # expire

            ## Assertion
            edit_ca_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Clear
            expire_or_activate_contract_item_cdb(self.cop_product_id, 1)  # activate
            clear_db(self.pad_name)

        elif g_args_list['USER'] == 'test_dwa_view_only_priv@gala.cdn.com':
            val_no_such_element_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

        elif g_args_list['USER'] == 'test_no_priv@gala.cdn.com':
            val_access_denied(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test3_dwa_expire_contract_and_edit_a_pushed_staging_pad(self):
        driver = self.driver
        if g_args_list['USER'] == 'test_dwa_add_edit_priv@gala.cdn.com' or g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
            ## Cases
            add_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], 'DWA_add_PAD')
            push_to_stag(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], 'DWA_push_to_staging_PAD')
            expire_or_activate_contract_item_cdb(self.cop_product_id, 0)  # expire

            ## Assertion
            edit_ca_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            val_button_name(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__, 'request implementation')

            ## Clear
            expire_or_activate_contract_item_cdb(self.cop_product_id, 1)  # activate
            clear_db(self.pad_name)

        elif g_args_list['USER'] == 'test_dwa_edit_priv@gala.cdn.com':
            ## Cases
            add_action = "add_pad(driver, '" + self.pad_name + "','test_dwa_add_edit_priv@gala.cdn.com','" + g_args_list['BROWSER'] + "','DWA_add_PAD')"
            push_stag_action = "push_to_stag(driver, '" + self.pad_name + "','test_dwa_add_edit_priv@gala.cdn.com','" + g_args_list['BROWSER'] + "','DWA_push_staging_PAD')"
            change_user_action('test_dwa_add_edit_priv@gala.cdn.com', SELF_PROV_USER['PASSWORD'], add_action, push_stag_action)
            expire_or_activate_contract_item_cdb(self.cop_product_id, 0)  # expire

            ## Assertion
            val_no_such_element_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Clear
            expire_or_activate_contract_item_cdb(self.cop_product_id, 1)  # activate
            clear_db(self.pad_name)

        elif g_args_list['USER'] == 'test_dwa_view_only_priv@gala.cdn.com':
            val_no_such_element_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

        elif g_args_list['USER'] == 'test_no_priv@gala.cdn.com':
            val_access_denied(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test4_dwa_expire_contract_and_no_its_product_in_oui_pad_list(self):
        driver = self.driver
        customer_name = 'GALA NETWORKS'
        if g_args_list['USER'] == 'test_dwa_add_edit_priv@gala.cdn.com' or g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
            ## Cases
            expire_or_activate_contract_item_cdb(self.cop_product_id, 0)  # expire

            ## Assertion
            val_add_a_PAD_for_this_customer_and_no_product_list_in_oui(customer_name, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

            ## Clear
            expire_or_activate_contract_item_cdb(self.cop_product_id, 1)  # activate

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test5_dwa_expire_contract_and_editting_is_impossible_but_inactive_in_oui(self):
        driver = self.driver
        customer_name = 'GALA NETWORKS'
        ## Cases
        add_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], 'DWA_add_PAD')
        push_to_stag(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], 'DWA_push_to_staging_PAD')
        push_to_prod(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], 'DWA_push_to_production_PAD')
        expire_or_activate_contract_item_cdb(self.cop_product_id, 0)  # expire

        ## Assertion
        expire_contract_and_then_eidt_a_pad_in_oui(customer_name, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)

        ## Clear
        expire_or_activate_contract_item_cdb(self.cop_product_id, 1)  # activate
        clear_db(self.pad_name)

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def ca_expire_contract_and_a_editting_self_PAD_settings_is_impossible_in_oui(self):
        driver = self.driver
        # OUI-1951 issue

if __name__ == '__main__':
    global g_args_list
    g_args_list = handle_args(sys.argv)
    unittest.main()
