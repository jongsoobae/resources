#!/usr/bin/python
#-*-encoding: utf-8-*-

## PATH
import time, unittest, sys, os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)

## CONFIGURATIONS
from selenium_test.shared_components.login import *
from selenium_test.shared_components.utils import *
from selenium_test.shared_components.decorator import *
from selenium_test.shared_components.common_action import *
from selenium_test.config_user_constants import SELF_PROV_USER
from selenium_test.config_constants import *

## SELENIUM MODUES
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException

rc = SeleniumRC()
@logclass
class CustomerDWATest(unittest.TestCase):
    @logmethod
    def setUp(self):
        print ""
        print "##################################################  PREPARATION  ##################################################"
        print "###                                                                                                             ###"
        print "### Register domains in your hosts, '10.40.210.250   h0-s107.qa-tst.cdngp.net' (CLIENT)                         ###"
        print "###                                                                                                             ###"
        print "###################################################################################################################"
        print ""
        if len(g_args_list) == 1:
            g_args_list['BROWSER'] = 'firefox'
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        elif len(g_args_list) == 2:
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-firefox.cdnetworks.com"
        elif len(g_args_list) == 5:
            self.driver = rc.get_driver(g_args_list['NODE'],g_args_list['BROWSER'],g_args_list['OS'],g_args_list['PORT'])
            if g_args_list['BROWSER'] == 'internet explorer': self.pad_name = "selenium-ie.cdnetworks.com"
            else: self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        else: raise Exception("The number of arguments is wrong.")
        clear_db(self.pad_name)
        common_login_action(self.driver, g_args_list['USER'], SELF_PROV_USER['PASSWORD'])

    @logmethod
    def tearDown(self):
        driver = self.driver
        driver.close()

    @logmethod
    def test1_dwa_push_and_accept_requested_pad_megafon(self):
        driver = self.driver
        customer_name = "megafon"
        if g_args_list['USER'] == 'tst_master_priv@megafon.cdn.com':
            #create_request_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            #self.validation_requested_pad(driver)
            oui_driver = find_customer_and_view_his_pad_oui(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__, customer_name, 'edit_and_approve')
            self.validation_requested_pad_oui(oui_driver, g_args_list['USER'])
            push_and_accept_requested_pad(oui_driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__, customer_name)
            val_pad_status(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__, 4)
            curl_pad_validation(self.pad_name, 'false')

            # Clear
            oui_driver.close()
            clear_db(self.pad_name)

    def test2_dwa_push_and_deny_requested_pad_megafon(self):
        driver = self.driver
        customer_name = "megafon"
        if g_args_list['USER'] == 'tst_master_priv@megafon.cdn.com':
            create_request_pad(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__)
            self.validation_requested_pad(driver)
            oui_driver = find_customer_and_view_his_pad_oui(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__, customer_name, 'deny')
            push_and_deny_requested_pad(oui_driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__, customer_name)
            val_pad_status(driver, self.pad_name, g_args_list['USER'], g_args_list['BROWSER'], __file__, 0)

            # Clear
            oui_driver.close()
            clear_db(self.pad_name)

    @logmethod
    def push_to_staging_oui(self, driver):
        # approving the PAD.
        driver.find_element_by_css_selector("input[type=\"submit\"]").click()
        for i in range(60):
            try:
                if "implement site draft request: " + self.pad_name == driver.find_element_by_css_selector("h1").text: break
            except:
                pass
            time.sleep(1)
        else:
            self.fail("time out")
        driver.find_element_by_id("id_send_email").click()
        driver.find_element_by_css_selector("input[type=\"submit\"]").click()

    @logmethod
    def validation_requested_pad_oui(self, driver, user):
        self.assertEqual(self.pad_name, driver.find_element_by_id("id_pad").get_attribute("value"))
        self.assertEqual("", driver.find_element_by_id("id_hide_customer").text)
        self.assertEqual("0", driver.find_element_by_id("id_type_flag").get_attribute("value"))
        self.assertEqual("60", driver.find_element_by_id("id_nonwildcard_hour").get_attribute("value"))
        self.assertEqual("1000", driver.find_element_by_id("id_items_per_request").get_attribute("value"))
        self.assertEqual("1", driver.find_element_by_id("id_all_per_hour").get_attribute("value"))
        self.assertEqual("10", driver.find_element_by_id("id_wildcards_per_hour").get_attribute("value"))
        self.assertEqual("10", driver.find_element_by_id("id_wildcards_per_request").get_attribute("value"))
        self.assertEqual("alias." + self.pad_name, driver.find_element_by_id("id_pad_aliases").get_attribute("value"))
        self.assertEqual("origin.cdnetworks.com", driver.find_element_by_id("id_origin").get_attribute("value"))
        self.assertEqual("failover." + self.pad_name,driver.find_element_by_id("id_backup_origin").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_status").get_attribute("value"))
        if user.find('cetizen') >= 0:
            Select(driver.find_element_by_id("id_product")).select_by_visible_text("[0040000105-Cetizen] Web Acceleration-Standard")
        elif user.find('megafon') >= 0:
            Select(driver.find_element_by_id("id_product")).select_by_visible_text("[0040007879-Megafon-ResellerAgrement][30] Web Acceleration-Content Acceleration")
        self.assertEqual("on", driver.find_element_by_id("id_use_edns_client_subnet").get_attribute("value"))
        Select(driver.find_element_by_id("id_service")).select_by_visible_text("k1: CS: Korea")
        Select(driver.find_element_by_id("id_shielded_service")).select_by_visible_text("CS: (Generic) :: K1 :: APAC ICN51/ICN5")
        self.assertEqual(u'cdnga.net\ncdngc.net\ncdngd.net\ncdngl.net\ncdngm.net\ncdngs.net\ngccdn.cn\ngccdn.net\npanthercdn.com',driver.find_element_by_id("id_cname_dns_zone_record").text)
        self.assertEqual("selenium test", driver.find_element_by_id("id_description").get_attribute("value"))
        self.assertEqual("Asychronous\nSynchronous\nBackground", driver.find_element_by_id("id_dns_refresh_type").text)
        self.assertEqual("0", driver.find_element_by_id("id_dns_entry_existing_time_limit").get_attribute("value"))
        self.assertEqual("0", driver.find_element_by_id("id_tag_hash_format_preset").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_tag_time_in_hex").get_attribute("value"))
        self.assertEqual("0", driver.find_element_by_id("id_tag_time_allowed_sec").get_attribute("value"))
        self.assertEqual("0", driver.find_element_by_id("id_tag_time_offset_sec").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_use_sub_files").get_attribute("value"))
        self.assertEqual("0", driver.find_element_by_id("id_large_file_redirect_size").get_attribute("value"))
        self.assertEqual("0", driver.find_element_by_id("id_bps_streaming_limit").get_attribute("value"))
        self.assertEqual("0", driver.find_element_by_id("id_max_master_retries").get_attribute("value"))

    @logmethod
    def validation_requested_pad(self, driver):
        self.assertEqual(self.pad_name, driver.find_element_by_css_selector("td").text)
        self.assertEqual("alias." + self.pad_name, driver.find_element_by_css_selector("tr.row2 > td").text)
        self.assertEqual("origin.cdnetworks.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[5]/td").text)
        self.assertEqual("failover." + self.pad_name, driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[6]/td").text)
        self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[7]/td").text)
        self.assertEqual("selenium test", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[9]/td").text)
        driver.find_element_by_link_text("Caching").click()
        self.assertEqual("False", driver.find_element_by_css_selector("#pad_group_local_site_Caching > tr.row2 > td").text)
        self.assertEqual("Not Set", driver.find_element_by_css_selector("#pad_group_local_site_Caching > tr.row1 > td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[5]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[6]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[7]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[8]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[9]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[10]/td").text)
        driver.find_element_by_link_text("Request & Response").click()
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[3]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[4]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[5]/td").text)
        self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[6]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[7]/td").text)
        self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[8]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[9]/td").text)
        self.assertEqual("None", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[10]/td").text)
        self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[11]/td").text)
        self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[12]/td").text)
        self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[15]/td").text)
        self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[16]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[17]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[18]/td").text)
        self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[19]/td").text)
        self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[20]/td").text)
        self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[21]/td").text)
        self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[24]/td").text)
        self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[25]/td").text)
        self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[26]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[27]/td").text)
        self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[28]/td").text)
        self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[31]/td").text)
        driver.find_element_by_link_text("Rewrite Rules").click()
        self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[3]/td").text)
        self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[4]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[5]/td").text)
        self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[6]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[7]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[8]/td").text)
        self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[9]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[10]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[11]/td").text)
        driver.find_element_by_link_text("Validation").click()
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[3]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[4]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[5]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[6]/td").text)
        self.assertEqual("None", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[9]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[10]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[11]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[12]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[13]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[14]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[15]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[16]/td").text)
        self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[19]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[20]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[21]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[22]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[23]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[24]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[25]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[26]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[27]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[28]/td").text)
        driver.find_element_by_link_text("Video/Large File Delivery").click()
        self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[3]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[6]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[7]/td").text)
        self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[10]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[11]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[12]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[13]/td").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[14]/td").text)
        driver.find_element_by_link_text("Misc").click()
        self.assertEqual("http://origin.cdnetworks.com/index.html", driver.find_element_by_css_selector("#pad_group_site_stat_Basic > tr.row1 > td").text)
        self.assertEqual("1-20 Mbps", driver.find_element_by_css_selector("#pad_group_site_stat_Basic > tr.row2 > td").text)
        self.assertEqual("1-20 Mbps", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Basic']/tr[4]/td").text)
        self.assertEqual("1 - 2,500", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Basic']/tr[5]/td").text)
        self.assertEqual("1 - 2,500", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Basic']/tr[6]/td").text)
        driver.find_element_by_link_text("Files").click()
        self.assertEqual("1000", driver.find_element_by_css_selector("#pad_group_site_stat_Files > tr.row1 > td").text)
        self.assertEqual("12400", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Files']/tr[4]/td").text)
        self.assertEqual("0-1 MB", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Files']/tr[5]/td").text)
        driver.find_element_by_link_text("Usage").click()
        self.assertEqual("Not Set", driver.find_element_by_css_selector("#pad_group_site_stat_Usage > tr.row2 > td").text)
        self.assertEqual("", driver.find_element_by_css_selector("tr.row1 > td > i").text)
        self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Usage']/tr[4]/td/i").text)
        driver.find_element_by_link_text("Comments").click()
        self.assertEqual("by selenium test", driver.find_element_by_css_selector("#pad_group_site_stat_Comments > tr.row1 > td").text)
        if g_args_list['USER'] == 'test_dwa_add_edit_priv@gala.cdn.com':
            self.assertEqual("test_dwa_add_edit_priv@gala.cdn.com", driver.find_element_by_xpath("//table[@id='change_history']/tbody/tr/td[2]").text)
        elif g_args_list['USER'] == 'test_master_priv@gala.cdn.com':
            self.assertEqual("test_master_priv@gala.cdn.com", driver.find_element_by_xpath("//table[@id='change_history']/tbody/tr/td[2]").text)
        driver.find_element_by_xpath("//input[@value='request implementation']").click()
        time.sleep(1)
        driver.find_element_by_name("stats").click()
        driver.find_element_by_name("checklist").click()
        driver.find_element_by_name("comments").clear()
        driver.find_element_by_name("comments").send_keys("test")
        driver.find_element_by_name("submit").click()

        # Request PAD implementation
        if g_args_list['BROWSER'] == 'firefox':
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        time.sleep(10)
        for i in range(60):
            try:
                if u'Your PAD implementation request has been submitted.\nIf the PAD must be implemented immediately, please click the Request support link (at left) and submit an urgent Support Request, which will notify an on-call engineer who can process the PAD implementation.\nOtherwise, your request will be processed by the end of the current business day (during the week), or next business day (if submitted during weekday evenings or weekends. Typically PAD implementation requests are filled within 2 hours during business hours.' == driver.find_element_by_xpath(
                        "//div[@id='messages']/ul/li").text: break
            except:
                pass
            time.sleep(1)
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        else:
            self.fail("time out")
    
if __name__ == '__main__':
    global g_args_list
    g_args_list = handle_args(sys.argv)
    unittest.main()
