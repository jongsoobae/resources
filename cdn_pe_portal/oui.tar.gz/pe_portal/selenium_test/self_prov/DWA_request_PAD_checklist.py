#!/usr/bin/python
#-*-encoding: utf-8-*-

## PATH
import time, unittest, sys, os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)

## CONFIGURATIONS
from selenium_test.shared_components.login import SeleniumRC
from selenium_test.shared_components.utils import *
from selenium_test.shared_components.decorator import *
from selenium_test.config_user_constants import SELF_PROV_USER
from selenium_test.config_constants import *

## SELENIUM MODUES
from selenium.webdriver.support.ui import Select
from selenium import webdriver

rc = SeleniumRC()
@logclass
class CustomerCATest(unittest.TestCase):
    @logmethod
    def setUp(self):
        # Loading DB dump by script (jongsoo.bae) aurora.activate()
        ## webdriver according to browser
        if len(g_args_list) == 1:
            g_args_list['BROWSER'] = 'firefox'
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        elif len(g_args_list) == 2:
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-firefox.cdnetworks.com"
        elif len(g_args_list) == 5:
            self.driver = rc.get_driver(g_args_list['NODE'],g_args_list['BROWSER'],g_args_list['OS'],g_args_list['PORT'])
            if g_args_list['BROWSER'] == 'internet explorer':
                self.pad_name = "selenium-ie.cdnetworks.com"
            else:
                self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        else:
            raise Exception("The number of arguments is wrong.")

        driver = self.driver
        clear_db(self.pad_name)
        driver.get(AURORA_URL + "/accounts/login/")
        driver.find_element_by_id("id_username").clear()
        driver.find_element_by_id("id_username").send_keys(g_args_list['USER'])
        driver.find_element_by_id("id_password").clear()
        driver.find_element_by_id("id_password").send_keys(SELF_PROV_USER['PASSWORD'])
        driver.find_element_by_id("id_login").click()
        time.sleep(3)

    @logmethod
    def tearDown(self):
        # Destroying DB (jongsoo.bae) aurora.deactivate()
        driver = self.driver
        driver.close()

    @logmethod
    def test_ca_request_pad_checklist(self):
        driver = self.driver
        if g_args_list['USER']=='tst_master_piv@jimdo.cdn.com' or g_args_list['USER']=='tst_dwa_add_edit_priv@jimdo.cdn.com' or g_args_list['USER']=='tst_dwa_edit_priv@jimdo.cdn.com' or g_args_list['USER']=='tst_dwa_view_only_priv@jimdo.cdn.com':
            ## CA pad checklist
            driver = self.driver
            driver.get(AURORA_URL + "/cui/int/pad-checklist/?m=213")
            time.sleep(1)
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            time.sleep(1)
            for i in range(60):
                try:
                    if "General" == driver.find_element_by_css_selector("h2").text: break
                except: pass
                time.sleep(1)
                driver.switch_to.parent_frame()
                driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            else: self.fail("time out")
            self.assertEqual("Please be sure that CDNetworks caches are not blocked from the origin server. The traffic can be identified by the User-Agent, User-Agent: Mozilla/5.0 (compatible; Panther).", driver.find_element_by_css_selector("li").text)
            self.assertEqual("Make sure the origin domain returns Last-Modified and ETag HTTP headers for content on the PAD. Also, make sure that your origin web server is able to return \"304 not modified\" in response to If-Modified-Since queries if content has not changed.", driver.find_element_by_xpath("//li[5]").text)

        elif g_args_list['USER']=='tst_no_piv@jimdo.cdn.com':
            ## CA pad checklist
            driver = self.driver
            driver.get(AURORA_URL + "/cui/int/pad-checklist/?m=213")
            time.sleep(3)
            ## Access Denied
            for i in range(60):
                try:
                    if "Error 403" == driver.find_element_by_css_selector("h1.pa-title").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")

            try:
                if "Add new PAD" ==  driver.find_element_by_link_text("Add new PAD").text:
                    self.fail("Exist Add new PAD menu")
            except: pass
        driver.save_screenshot('img/result/'+g_args_list['BROWSER']+'_'+g_args_list['USER']+'_'+ __file__.strip('.py')+'-add-result.png')
    
if __name__ == '__main__':
    global g_args_list
    g_args_list = handle_args(sys.argv)
    unittest.main()
