## ** Testing Environment**

1. Your local PC must be **Ubuntu**
2. Must use **DM (self provisioning) project** in OpenStack

## **Documentations for BOBP**

1. [Selenium with Python](http://selenium-python.readthedocs.org/)
2. [Selenium Grid](https://wiki.cdnetworks.com/confluence/display/QATeam/Selenium+Grid)
3. [The Best of the Best Practices Guide for Python](https://gist.github.com/sloria/7001839#file-bobp-python-md)

## **Documentations for Selenium IDE tutorial**

1. [Selenium IDE for Python Users (Simple Tutorial)](https://wiki.cdnetworks.com/confluence/pages/viewpage.action?pageId=145033212)

## **Test Suite Naming Convention(class)**

Basically, **TestSuite** name must be **CamelCase**.
And, name format must be like this below.

> {**Product**}({**SSL**}|{**Feature**})

**[Examples](#test-suite-naming-examples)**

## **Test Case Naming Convention(function)**

Basically, **TestCase** name must be **snake_case**.
And, name format must be like this below.

**[Examples](#CA_SSL_Push_to_Staging)**

#### **Test Suite Naming Examples**

> AddUserTest
>
> ViewCATrafficPageTest
> 
> DeleteCLBDomainTest
>
> ImportDNSZoneTest
>
> VerifyLDSInformationTest
>
> EditCustomizedControlGroupTest
>
> PushConfigurationTest


#### **Test Case Naming Examples**

> CA_SSL_Push_to_Staging


#### **Preparations**
sudo apt-get install python-skimage
sudo apt-get install python-opencv
pip install cv2
>>>>>>> 810e155e848b112e3a0332a7a1450357766d0b9e
