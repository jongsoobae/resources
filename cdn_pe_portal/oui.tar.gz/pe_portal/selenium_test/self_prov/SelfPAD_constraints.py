#!/usr/bin/python
#-*-encoding: utf-8-*-

"""References:
    https://wiki.cdnetworks.com/confluence/display/engportal/self+implementable+pad+condition+Test
"""

## PATH
import time, unittest, sys, os, subprocess
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)

## CONFIGURATIONS
from selenium_test.config_constants import *
from selenium_test.shared_components.login import *
from selenium_test.shared_components.utils import *
from selenium_test.shared_components.decorator import *
from selenium_test.shared_components.constraints_handler import *
from selenium_test.shared_components.common_action import *
from selenium_test.config_user_constants import SELF_PROV_USER

## SELENIUM MODUES
from selenium import webdriver
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys

@logclass
class CustomerCATest(unittest.TestCase):
    ## TEST DATA
    gala_customer_id='1446' # GALA NETWORKS
    ca_contract_no='40000548';    ca_meterial_no='1028';    ca_item_no='10'
    ca_ssl_contract_no='40000548';  ca_ssl_meterial_no='1291';  ca_ssl_item_no='30'
    dwa_contract_no = '40000548';   dwa_meterial_no = '1115';   dwa_item_no = '20'
    dwa_ssl_contract_no = '40000548';    dwa_ssl_meterial_no = '1292';    dwa_ssl_item_no = '40'

    ## NOTICE
    print "\n"
    print "================================================================================================================"
    print "===                           Your hosts: 10.40.210.94   "+PANTHER_API_URL.rstrip("/rest/").lstrip("https:").lstrip("//")+"                       ===="
    print "===                           Your hosts: 10.40.210.239  "+SPECTRUMAPI_URL.lstrip("https:").lstrip("//")+"                      ===="
    print "================================================================================================================"
    print "\n"

    @logmethod
    def setUp(self):
        if is_material_no_selfPAD(self.ca_contract_no, self.ca_item_no) == True:
            pass
        else:
            raise Exception("Your contract(" + self.ca_contract_no + "-" + self.ca_item_no + ") is NOT Self Implementation !!")
        self.driver = webdriver.Firefox()
        self.pad_name = 'selenium-firefox.cdnetworks.com'

    @logmethod
    def tearDown(self):
        self.driver.close()

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test1_ca_material_no(self):
        ## Cases
        add_new_pad(self.driver, self.pad_name, SELF_PROV_USER['USER_WITH_CA_ADD_EDIT_PRIV'], 'firefox', 'CA')
        set_meterial_no(self.ca_contract_no, self.ca_item_no, '1317')
        restart_memcached_in_spectrumapi_oui()

        ## Validation
        if is_material_no_selfPAD(self.ca_contract_no, self.ca_item_no) == False:
            pass
        else: raise Exception("Your contract("+self.ca_contract_no+"-"+self.ca_item_no+") is Self Implementation !!")
        val_pad_editable_then_clear(self.driver, self.pad_name, SELF_PROV_USER['USER_WITH_CA_ADD_EDIT_PRIV'], 'firefox', 'CA')

        ## Clear
        set_meterial_no(self.ca_contract_no, self.ca_item_no, self.ca_meterial_no)
        restart_memcached_in_spectrumapi_oui()

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test2_ca_is_china_zone_R5(self): #R5, R7, R8: China zone
        service_type = 'R5'
        ## Cases
        add_new_pad(self.driver, self.pad_name, SELF_PROV_USER['USER_WITH_CA_ADD_EDIT_PRIV'], 'firefox', 'CA')
        set_service_type(self.ca_contract_no, self.ca_item_no, service_type)
        restart_memcached_in_spectrumapi_oui()

        ## Validation
        if is_chinazone_on(self.ca_contract_no, self.ca_item_no, service_type) == True:
            pass
        else: raise Exception("Your contract("+self.ca_contract_no+"-"+self.ca_item_no+") is Self Implementation !!")
        val_pad_editable_then_clear(self.driver, self.pad_name, SELF_PROV_USER['USER_WITH_CA_ADD_EDIT_PRIV'], 'firefox', 'CA')

        ## Clear
        set_service_type(self.ca_contract_no, self.ca_item_no, 'R3')
        restart_memcached_in_spectrumapi_oui()

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test3_ca_is_china_zone_R5(self): #R5, R7, R8: China zone
        service_type = 'R7'
        ## Cases
        add_new_pad(self.driver, self.pad_name, SELF_PROV_USER['USER_WITH_CA_ADD_EDIT_PRIV'], 'firefox', 'CA')
        set_service_type(self.ca_contract_no, self.ca_item_no, service_type)
        restart_memcached_in_spectrumapi_oui()

        ## Validation
        if is_chinazone_on(self.ca_contract_no, self.ca_item_no, service_type) == True:
            pass
        else: raise Exception("Your contract("+self.ca_contract_no+"-"+self.ca_item_no+") is Self Implementation !!")
        val_pad_editable_then_clear(self.driver, self.pad_name, SELF_PROV_USER['USER_WITH_CA_ADD_EDIT_PRIV'], 'firefox', 'CA')

        ## Clear
        set_service_type(self.ca_contract_no, self.ca_item_no, 'R3')
        restart_memcached_in_spectrumapi_oui()

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test4_ca_is_china_zone_R5(self): #R5, R7, R8: China zone
        service_type = 'R8'
        ## Cases
        add_new_pad(self.driver, self.pad_name, SELF_PROV_USER['USER_WITH_CA_ADD_EDIT_PRIV'], 'firefox', 'CA')
        set_service_type(self.ca_contract_no, self.ca_item_no, service_type)
        restart_memcached_in_spectrumapi_oui()

        ## Validation
        if is_chinazone_on(self.ca_contract_no, self.ca_item_no, service_type) == True:
            pass
        else: raise Exception("Your contract("+self.ca_contract_no+"-"+self.ca_item_no+") is Self Implementation !!")
        val_pad_editable_then_clear(self.driver, self.pad_name, SELF_PROV_USER['USER_WITH_CA_ADD_EDIT_PRIV'], 'firefox', 'CA')

        ## Clear
        set_service_type(self.ca_contract_no, self.ca_item_no, 'R3')
        restart_memcached_in_spectrumapi_oui()

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test5_ca_allow_add_flag(self):
        cop_product_id = '00'+self.ca_contract_no+'-0000'+self.ca_item_no
        ## Cases
        add_new_pad(self.driver, self.pad_name, SELF_PROV_USER['USER_WITH_CA_ADD_EDIT_PRIV'], 'firefox', 'CA')
        set_allow_add_pad_flag(0, cop_product_id)
        restart_memcached_in_spectrumapi_oui()

        ## Validation
        if is_ca_allow_add_flag_on(self.ca_contract_no, self.ca_item_no) == False:
            pass
        else: raise Exception("Your contract(" + self.ca_contract_no + "-" + self.ca_item_no + ") is Self Implementation !!")
        val_pad_editable_then_clear(self.driver, self.pad_name, SELF_PROV_USER['USER_WITH_CA_ADD_EDIT_PRIV'], 'firefox', 'CA')

        ## Clear
        set_allow_add_pad_flag(1, cop_product_id)
        restart_memcached_in_spectrumapi_oui()

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test6_dwa_per_app_billing_method(self):
        unit = 'APP'
        ## Cases
        add_new_pad(self.driver, self.pad_name, SELF_PROV_USER['USER_WITH_DWA_ADD_EDIT_PRIV'], 'firefox', 'DWA')
        set_per_app_billing_method(self.dwa_contract_no, self.dwa_item_no, unit)
        restart_memcached_in_spectrumapi_oui()

        ## Validation
        if is_per_app_billing_method_unit_app_on(self.dwa_contract_no, self.dwa_item_no) == True:
            pass
        else: raise Exception("Your contract(" + self.ca_contract_no + "-" + self.ca_item_no + ") is Self Implementation !!")
        val_pad_editable_then_clear(self.driver, self.pad_name, SELF_PROV_USER['USER_WITH_DWA_ADD_EDIT_PRIV'], 'firefox', 'DWA')

        ## Clear
        set_per_app_billing_method(self.dwa_contract_no, self.dwa_item_no, 'EA')
        restart_memcached_in_spectrumapi_oui()

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test7_dwa_ssl_preset_edge(self):
        ## Cases
        add_new_pad(self.driver, self.pad_name, SELF_PROV_USER['USER_WITH_DWA_SSL_ADD_EDIT_PRIV'], 'firefox', 'DWA_SSL')
        set_preset_edge(0, self.gala_customer_id)
        restart_memcached_in_spectrumapi_oui()

        ## Validation
        if is_preset_edge_off(self.dwa_ssl_contract_no, self.dwa_ssl_item_no) == True:
            pass
        else: raise Exception("Your contract(" + self.dwa_ssl_contract_no + "-" + self.dwa_ssl_item_no + ") is Self Implementation !!")
        val_pad_editable_then_clear(self.driver, self.pad_name, SELF_PROV_USER['USER_WITH_DWA_SSL_ADD_EDIT_PRIV'], 'firefox', 'DWA_SSL')

        ## Clear
        set_preset_edge(1, self.gala_customer_id)
        restart_memcached_in_spectrumapi_oui()

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def test8_dwa_ssl_customer_product_edge(self):
        pass

    @logmethod
    @catch_exception(author="hyunhwa.hong")
    def oui_limit_of_total_number_pad(self):
        pass # select * from customer_product.count_per_contract where customer_id=1446;

if __name__ == '__main__':
    unittest.main()
    clear_db()
