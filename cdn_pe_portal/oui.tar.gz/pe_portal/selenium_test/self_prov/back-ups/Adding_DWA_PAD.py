#!/usr/bin/python
#-*-encoding: utf-8-*-

## PATH
import time, unittest, sys, os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)

## CONFIGURATIONS
from selenium_test.shared_components.login import SeleniumRC
from selenium_test.shared_components.utils import *
from selenium_test.shared_components.decorator import *
from selenium_test.config_user_constants import SELF_PROV_USER
from selenium_test.config_constants import AURORA_URL, SEL_NODEURL2

## SELENIUM MODUES
from selenium.webdriver.support.ui import Select
from selenium import webdriver

rc = SeleniumRC()
@logclass
class CustomerCATest(unittest.TestCase):
    # For arguments
    ## according to browser
    if len(sys.argv) == 6:
        NODE = 'http://linux-node.cdnetworks.com:5555/wd/hub/'
        BROWSER = 'firefox'
        OS = 'LINUX'
        PORT = '5555'
        USER = 'test_dwa_add_edit_priv@gala.cdn.com'
    ## according to account
    elif len(sys.argv) == 2:
        BROWSER = 'firefox'
        USER = 'test_dwa_add_edit_priv@gala.cdn.com'
    ## firefox in local
    else:
        USER = None
        BROWSER = 'firefox'

    @logmethod
    def setUp(self):
        # Loading DB dump by script (jongsoo.bae) aurora.activate()
        ## pad name according to browser
        if len(sys.argv) > 1:
            if self.BROWSER == 'firefox':
                self.pad_name = 'selenium-dwa-ff.com'
            elif self.BROWSER == 'chrome':
                self.pad_name = 'selenium-dwa-cr.com'
            elif self.BROWSER == 'internet explorer':
                self.pad_name = 'selenium-dwa-ie.com'
            elif self.BROWSER == 'safari':
                self.pad_name = 'selenium-dwa-sf.com'
        else:
            self.pad_name = 'selenium-dwa-ff.com'

        ## webdriver according to browser
        if self.BROWSER == 'firefox' or None:
            self.driver = webdriver.Firefox()
        else:
            self.driver = rc.get_driver(self.NODE,self.BROWSER,self.OS,self.PORT)

        driver = self.driver
        driver.get(AURORA_URL + "/accounts/login/")
        driver.find_element_by_id("id_username").clear()

        ## for local firefox
        if self.USER is not None:
            driver.find_element_by_id("id_username").send_keys(self.USER)
        else:
            driver.find_element_by_id("id_username").send_keys('test_dwa_add_edit_priv@gala.cdn.com')

        driver.find_element_by_id("id_password").clear()
        driver.find_element_by_id("id_password").send_keys(SELF_PROV_USER['PASSWORD'])
        driver.find_element_by_id("id_login").click()
        time.sleep(3)

    @logmethod
    def tearDown(self):
        # Destroying DB (jongsoo.bae) aurora.deactivate()
        driver = self.driver
        driver.close()

    @logmethod
    def test1_dwa_add_pad(self):
        if self.USER == 'test_dwa_add_edit_priv@gala.cdn.com' or self.USER == 'test_master_priv@gala.cdn.com':
            ## DWA menu
            driver = self.driver
            driver.get(AURORA_URL + "/cui/int/pads/add/?m=205")
            time.sleep(3)
            driver.find_element_by_link_text("Add new PAD").click()
            time.sleep(3)

            ### CUI frame
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            for i in range(60):
                try:
                    if "Input PAD settings manually" == driver.find_element_by_link_text("Input PAD settings manually").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")
            driver.find_element_by_link_text("Input PAD settings manually").click()
            for i in range(60):
                try:
                    if "PAD Set Up - 3 Steps" == driver.find_element_by_css_selector("#pad_edit > h2").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")

            ### Step 1
            Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-20: DWA - Global Premium (Self Implementation)")
            time.sleep(5)
            driver.find_element_by_id("id_pad").clear()
            driver.find_element_by_id("id_pad").send_keys(self.pad_name)
            driver.find_element_by_id("id_pad_aliases").clear()
            driver.find_element_by_id("id_pad_aliases").send_keys("alias.selenium-dwa-ff.com")
            driver.find_element_by_id("id_origin").clear()
            driver.find_element_by_id("id_origin").send_keys("default-origin.cdnetworks.com")
            Select(driver.find_element_by_id("id_shield_location")).select_by_visible_text("Seoul, Korea Republic of")
            driver.find_element_by_id("id_backup_origin").clear()
            driver.find_element_by_id("id_backup_origin").send_keys("failover.selenium-ff.com")
            #Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-60: DWA - Global Standard (Self Implementation)")
            driver.find_element_by_id("id_description").clear()
            driver.find_element_by_id("id_description").send_keys("selenium test")
            time.sleep(1)
            driver.find_element_by_link_text("Caching").click()
            driver.find_element_by_id("id_strict_nocache_support").click()
            driver.find_element_by_id("id_min_age").clear()
            driver.find_element_by_id("id_min_age").send_keys("60")
            driver.find_element_by_id("id_default_last_modified_date").clear()
            driver.find_element_by_id("id_default_last_modified_date").send_keys("2015-12-25")
            driver.find_element_by_id("id_force_not_modified_on_ims").clear()
            driver.find_element_by_id("id_force_not_modified_on_ims").send_keys("1")
            driver.find_element_by_id("id_force_maxage_on_40x").clear()
            driver.find_element_by_id("id_force_maxage_on_40x").send_keys("1")
            driver.find_element_by_id("id_default_max_age").clear()
            driver.find_element_by_id("id_default_max_age").send_keys("60")
            driver.find_element_by_id("id_max_age_rules").clear()
            driver.find_element_by_id("id_max_age_rules").send_keys("^/.*\\.jpg 86400")
            driver.find_element_by_id("id_content_variation_rules").clear()
            driver.find_element_by_id("id_content_variation_rules").send_keys("^/.*\\.html %cgender")
            driver.find_element_by_link_text("Request & Response").click()
            driver.find_element_by_id("id_origin_ip").clear()
            driver.find_element_by_id("id_origin_ip").send_keys("10.10.10.1")
            driver.find_element_by_id("id_origin_port").clear()
            driver.find_element_by_id("id_origin_port").send_keys("777")
            driver.find_element_by_id("id_origin_host_header").clear()
            driver.find_element_by_id("id_origin_host_header").send_keys("test.com")
            driver.find_element_by_id("id_use_pad_as_host_header").click()
            driver.find_element_by_id("id_custom_headers").clear()
            driver.find_element_by_id("id_custom_headers").send_keys("X-Foo: bar")
            driver.find_element_by_id("id_origin_failure_redirect_url").clear()
            driver.find_element_by_id("id_origin_failure_redirect_url").send_keys("1")
            driver.find_element_by_id("id_use_origin_multiple_dns_record").click()
            driver.find_element_by_id("id_use_origin_sticky").click()
            driver.find_element_by_id("id_honor_multi_byte_range").click()
            driver.find_element_by_id("id_max_requests_per_keep_alive").clear()
            driver.find_element_by_id("id_max_requests_per_keep_alive").send_keys("50")
            driver.find_element_by_id("id_pass_thru_headers_to_origin").clear()
            driver.find_element_by_id("id_pass_thru_headers_to_origin").send_keys("X-Test: selenium")
            driver.find_element_by_id("id_accept_setting_from_query_string").click()
            driver.find_element_by_id("id_honor_path_range").click()
            driver.find_element_by_id("id_reverse_proxy_redirect").click()
            driver.find_element_by_id("id_follow_redirect").click()
            driver.find_element_by_id("id_pass_thru_headers_to_user").clear()
            driver.find_element_by_id("id_pass_thru_headers_to_user").send_keys("X-Test: selenium")
            driver.find_element_by_id("id_deny_direct_user_request").click()
            driver.find_element_by_id("id_cookie_exchange").click()
            driver.find_element_by_link_text("Rewrite Rules").click()
            driver.find_element_by_id("id_case_insensitive_urls").click()
            driver.find_element_by_id("id_drop_params").click()
            driver.find_element_by_id("id_rewrite_rules").clear()
            driver.find_element_by_id("id_rewrite_rules").send_keys("^/(.*\\.html)/rewritten?=url=$1")
            driver.find_element_by_id("id_drop_params_post_validation").click()
            driver.find_element_by_id("id_rewrite_rules_post_validation").clear()
            driver.find_element_by_id("id_rewrite_rules_post_validation").send_keys("^/(.*\\.html)/rewritten?=url=$1")
            driver.find_element_by_id("id_drop_precise_params_post_validation").clear()
            driver.find_element_by_id("id_drop_precise_params_post_validation").send_keys("string")
            driver.find_element_by_id("id_drop_params_in_cache_url").click()
            driver.find_element_by_id("id_drop_precise_params_in_cache_url").clear()
            driver.find_element_by_id("id_drop_precise_params_in_cache_url").send_keys("test")
            driver.find_element_by_id("id_full_url_rewrite_rules").clear()
            driver.find_element_by_id("id_full_url_rewrite_rules").send_keys("^http://qatest.selenium-ff.com/(.html*)")
            driver.find_element_by_link_text("Validation").click()
            driver.find_element_by_id("id_referrer_list").clear()
            driver.find_element_by_id("id_referrer_list").send_keys("^https?://[a-zA-Z0-9._-]*\\.panthercustomer\\.com/.*")
            Select(driver.find_element_by_id("id_referrer_list_type")).select_by_visible_text("Whitelist")
            driver.find_element_by_id("id_failed_referrer_check_redirect_url").clear()
            driver.find_element_by_id("id_failed_referrer_check_redirect_url").send_keys("test.com")
            Select(driver.find_element_by_id("id_validation_scheme")).select_by_visible_text("Origin Logic Control")
            driver.find_element_by_id("id_bypass_validation_on_failure").click()
            driver.find_element_by_id("id_validation_default_redirect_url").clear()
            driver.find_element_by_id("id_validation_default_redirect_url").send_keys("test.com")
            driver.find_element_by_id("id_validation_custom_headers").clear()
            driver.find_element_by_id("id_validation_custom_headers").send_keys("X-Foo: Bar")
            driver.find_element_by_id("id_validation_nobypass_redirect_url").clear()
            driver.find_element_by_id("id_validation_nobypass_redirect_url").send_keys("test.com")
            driver.find_element_by_id("id_http_auth_user").clear()
            driver.find_element_by_id("id_http_auth_user").send_keys("hhh1@gala.com")
            driver.find_element_by_id("id_http_auth_password").clear()
            driver.find_element_by_id("id_http_auth_password").send_keys("cdnadmin")
            driver.find_element_by_id("id_tag_check_enabled").click()
            driver.find_element_by_id("id_tag_hash_format_preset").clear()
            driver.find_element_by_id("id_tag_hash_format_preset").send_keys("1")
            driver.find_element_by_id("id_tag_hash_format").clear()
            driver.find_element_by_id("id_tag_hash_format").send_keys("1")
            driver.find_element_by_id("id_tag_hash_param").clear()
            driver.find_element_by_id("id_tag_hash_param").send_keys("px-hash")
            driver.find_element_by_id("id_tag_secret").clear()
            driver.find_element_by_id("id_tag_secret").send_keys("1234")
            driver.find_element_by_id("id_tag_time_param").clear()
            driver.find_element_by_id("id_tag_time_param").send_keys("px-time")
            driver.find_element_by_id("id_tag_time_allowed_sec").clear()
            driver.find_element_by_id("id_tag_time_allowed_sec").send_keys("1")
            driver.find_element_by_id("id_tag_time_offset_sec").clear()
            driver.find_element_by_id("id_tag_time_offset_sec").send_keys("1")
            driver.find_element_by_id("id_tag_skip_patterns").clear()
            driver.find_element_by_id("id_tag_skip_patterns").send_keys("^/cross-domain\\.xml")
            driver.find_element_by_link_text("Video/Large File Delivery").click()
            driver.find_element_by_id("id_bps_streaming_limit").clear()
            driver.find_element_by_id("id_bps_streaming_limit").send_keys("1")
            driver.find_element_by_id("id_buffer_secs").clear()
            driver.find_element_by_id("id_buffer_secs").send_keys("1")
            driver.find_element_by_id("id_progressive_dl").click()
            driver.find_element_by_id("id_progressive_dl_param").clear()
            driver.find_element_by_id("id_progressive_dl_param").send_keys("start")
            Select(driver.find_element_by_id("id_pdseek_default_type")).select_by_visible_text("h264")
            driver.find_element_by_id("id_pdseek_flv_extensions").clear()
            driver.find_element_by_id("id_pdseek_flv_extensions").send_keys("flv")
            driver.find_element_by_id("id_pdseek_h264_extensions").clear()
            driver.find_element_by_id("id_pdseek_h264_extensions").send_keys("mp4,m4v")
            driver.find_element_by_link_text("Misc").click()

            ### Step 2
            driver.find_element_by_id("id_url_test").clear()
            driver.find_element_by_id("id_url_test").send_keys("default-origin.cdnetworks.com")
            Select(driver.find_element_by_id("id_mbps_avg")).select_by_visible_text("1-20 Mbps")
            Select(driver.find_element_by_id("id_mbps_peak")).select_by_visible_text("1-20 Mbps")
            Select(driver.find_element_by_id("id_rps_avg")).select_by_visible_text("1 - 2,500")
            Select(driver.find_element_by_id("id_rps_peak")).select_by_visible_text("1 - 2,500")
            driver.find_element_by_link_text("Files").click()
            driver.find_element_by_id("id_files_type").clear()
            driver.find_element_by_id("id_files_type").send_keys("*.jpg")
            driver.find_element_by_id("id_files_count").clear()
            driver.find_element_by_id("id_files_count").send_keys("1000")
            driver.find_element_by_id("id_files_size_avg").clear()
            driver.find_element_by_id("id_files_size_avg").send_keys("12400")
            Select(driver.find_element_by_id("id_files_size_max")).select_by_visible_text("0-1 MB")
            driver.find_element_by_link_text("Usage").click()
            driver.find_element_by_link_text("Comments").click()
            driver.find_element_by_id("id_misc_comment").clear()
            driver.find_element_by_id("id_misc_comment").send_keys("by selenium test")
            driver.find_element_by_name("submit").click()
            for i in range(60):
                try:
                    if "Your settings for selenium-dwa-ff.com have been saved." == driver.find_element_by_css_selector("li").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")

            ### Asserts
            driver.get(AURORA_URL + "/cui/int/pads/?m=217")
            time.sleep(1)
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            driver.find_element_by_link_text(self.pad_name).click()
            self.assertEqual("Push status : New", driver.find_element_by_css_selector("h2").text)
            self.assertEqual("Production Site Settings", driver.find_element_by_xpath("//h2[2]").text)
            self.assertEqual(self.pad_name, driver.find_element_by_css_selector("td").text)
            self.assertEqual("alias.selenium-dwa-ff.com", driver.find_element_by_css_selector("tr.row2 > td").text)
            self.assertEqual("default-origin.cdnetworks.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[5]/td").text)
            self.assertEqual("failover.selenium-ff.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[6]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[7]/td").text)
            self.assertEqual("40000548-20: DWA - Global Premium (Self Implementation)", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[8]/td").text)
            self.assertEqual("selenium test", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[9]/td").text)
            driver.find_element_by_link_text("Caching").click()
            self.assertEqual("True", driver.find_element_by_css_selector("#pad_group_local_site_Caching > tr.row2 > td").text)
            self.assertEqual("60", driver.find_element_by_css_selector("#pad_group_local_site_Caching > tr.row1 > td").text)
            self.assertEqual("2015-12-25", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[5]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[6]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[7]/td").text)
            self.assertEqual("60", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[8]/td").text)
            #self.assertTrue(self.is_element_present(By.XPATH, "//tbody[@id='pad_group_local_site_Caching']/tr[9]/td"))
            #self.assertTrue(self.is_element_present(By.XPATH, "//tbody[@id='pad_group_local_site_Caching']/tr[10]/td"))
            driver.find_element_by_link_text("Request & Response").click()
            self.assertEqual("10.10.10.1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[3]/td").text)
            self.assertEqual("777", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[4]/td").text)
            self.assertEqual("test.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[5]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[6]/td").text)
            self.assertEqual("X-Foo: bar", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[7]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[8]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[9]/td").text)
            self.assertEqual("None", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[10]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[11]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[12]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[15]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[16]/td").text)
            self.assertEqual("50", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[17]/td").text)
            self.assertEqual("X-Test: selenium", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[18]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[19]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[20]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[21]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[24]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[25]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[26]/td").text)
            self.assertEqual("X-Test: selenium", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[27]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[28]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[31]/td").text)
            driver.find_element_by_link_text("Rewrite Rules").click()
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[3]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[4]/td").text)
            #self.assertTrue(self.is_element_present(By.XPATH, "//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[5]/td"))
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[6]/td").text)
             #self.assertTrue(self.is_element_present(By.XPATH, "//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[7]/td"))
            self.assertEqual("string", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[8]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[9]/td").text)
            self.assertEqual("test", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[10]/td").text)
            #self.assertTrue(self.is_element_present(By.XPATH, "//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[11]/td"))
            driver.find_element_by_link_text("Validation").click()
            #self.assertTrue(self.is_element_present(By.CSS_SELECTOR, "#pad_group_local_site_Validation > tr.row2 > td"))
            self.assertEqual("Whitelist", driver.find_element_by_css_selector("#pad_group_local_site_Validation > tr.row1 > td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[5]/td").text)
            self.assertEqual("test.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[6]/td").text)
            self.assertEqual("Origin Logic Control", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[9]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[10]/td").text)
            self.assertEqual("test.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[11]/td").text)
            self.assertEqual("X-Foo: Bar", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[12]/td").text)
            self.assertEqual("test.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[13]/td").text)
            self.assertEqual("hhh1@gala.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[14]/td").text)
            self.assertEqual("cdnadmin", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[15]/td").text)
            self.assertEqual("Basic", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[16]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[19]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[20]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[21]/td").text)
            self.assertEqual("px-hash", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[22]/td").text)
            self.assertEqual("1234", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[23]/td").text)
            self.assertEqual("px-time", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[24]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[25]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[26]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[27]/td").text)
            self.assertEqual("^/cross-domain\\.xml", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[28]/td").text)
            driver.find_element_by_id("tab_local_site_Video/Large File Delivery").click()
            driver.find_element_by_link_text("Video/Large File Delivery").click()
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[3]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[6]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[7]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[10]/td").text)
            self.assertEqual("start", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[11]/td").text)
            self.assertEqual("h264", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[12]/td").text)
            self.assertEqual("flv", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[13]/td").text)
            self.assertEqual("mp4,m4v", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[14]/td").text)
            driver.find_element_by_id("tab_local_site_Misc").click()
            self.assertEqual("http://default-origin.cdnetworks.com/", driver.find_element_by_css_selector("#pad_group_site_stat_Basic > tr.row1 > td").text)
            self.assertEqual("1-20 Mbps", driver.find_element_by_css_selector("#pad_group_site_stat_Basic > tr.row2 > td").text)
            self.assertEqual("1-20 Mbps", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Basic']/tr[4]/td").text)
            self.assertEqual("1 - 2,500", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Basic']/tr[5]/td").text)
            self.assertEqual("1 - 2,500", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Basic']/tr[6]/td").text)
            driver.find_element_by_link_text("Files").click()
            #self.assertTrue(self.is_element_present(By.CSS_SELECTOR, "#pad_group_site_stat_Files > tr.row2 > td"))
            self.assertEqual("1000", driver.find_element_by_css_selector("#pad_group_site_stat_Files > tr.row1 > td").text)
            self.assertEqual("12400", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Files']/tr[4]/td").text)
            self.assertEqual("0-1 MB", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Files']/tr[5]/td").text)
            driver.find_element_by_link_text("Usage").click()
            self.assertEqual("Not Set", driver.find_element_by_css_selector("#pad_group_site_stat_Usage > tr.row2 > td").text)
            self.assertEqual("Not Set", driver.find_element_by_css_selector("tr.row1 > td > i").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Usage']/tr[4]/td/i").text)
            driver.find_element_by_link_text("Comments").click()
            self.assertEqual("by selenium test", driver.find_element_by_css_selector("#pad_group_site_stat_Comments > tr.row1 > td").text)

            if self.USER == 'test_dwa_add_edit_priv@gala.cdn.com':
                self.assertEqual("test_dwa_add_edit_priv@gala.cd", driver.find_element_by_xpath("//table[@id='change_history']/tbody/tr/td[2]").text)
            elif self.USER == 'test_master_priv@gala.cdn.com':
                self.assertEqual("test_master_priv@gala.cdn.com", driver.find_element_by_xpath("//table[@id='change_history']/tbody/tr/td[2]").text)

        elif self.USER=='test_dwa_edit_priv@gala.cdn.com' or self.USER=='test_dwa_view_only_priv@gala.cdn.com' or self.USER=='test_no_priv@gala.cdn.com':
            ## DWA menu
            driver = self.driver
            driver.get(AURORA_URL + "/cui/int/pads/add/?m=190")
            time.sleep(3)
            ## Access Denied
            for i in range(60):
                try:
                    if "Error 403" == driver.find_element_by_css_selector("h1.pa-title").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")

            try:
                if "Add new PAD" ==  driver.find_element_by_link_text("Add new PAD").text:
                    self.fail("Exist Add new PAD menu")
            except: pass

        elif self.USER == 'tst_dwa_add_edit_priv@jimdo.cdn.com' or self.USER == 'tst_master_piv@jimdo.cdn.com':
            self.pad_name = 'selenium-dwa-ff-draft.com'
            ## CA menu
            driver = self.driver
            driver.get(AURORA_URL + "/cui/int/pads/add/?m=205")
            time.sleep(3)
            driver.find_element_by_link_text("Add new PAD").click()
            time.sleep(3)

            ### CUI frame
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            for i in range(60):
                try:
                    if "Input PAD settings manually" == driver.find_element_by_link_text("Input PAD settings manually").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")
            driver.find_element_by_link_text("Input PAD settings manually").click()
            for i in range(60):
                try:
                    if "PAD Set Up - 3 Steps" == driver.find_element_by_css_selector("#pad_edit > h2").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")

            ### Step 1
            driver.find_element_by_id("id_pad").clear()
            driver.find_element_by_id("id_pad").send_keys(self.pad_name)
            driver.find_element_by_id("id_pad_aliases").clear()
            driver.find_element_by_id("id_pad_aliases").send_keys("alias.selenium-dwa-ff-draft.com")
            driver.find_element_by_id("id_origin").clear()
            driver.find_element_by_id("id_origin").send_keys("default-origin.cdnetworks.com")
            driver.find_element_by_id("id_backup_origin").clear()
            driver.find_element_by_id("id_backup_origin").send_keys("failover.selenium-ff.com")
            driver.find_element_by_id("id_description").clear()
            driver.find_element_by_id("id_description").send_keys("selenium test")
            time.sleep(1)
            driver.find_element_by_link_text("Caching").click()
            driver.find_element_by_id("id_strict_nocache_support").click()
            driver.find_element_by_id("id_min_age").clear()
            driver.find_element_by_id("id_min_age").send_keys("60")
            driver.find_element_by_id("id_default_last_modified_date").clear()
            driver.find_element_by_id("id_default_last_modified_date").send_keys("2015-12-25")
            driver.find_element_by_id("id_force_not_modified_on_ims").clear()
            driver.find_element_by_id("id_force_not_modified_on_ims").send_keys("1")
            driver.find_element_by_id("id_force_maxage_on_40x").clear()
            driver.find_element_by_id("id_force_maxage_on_40x").send_keys("1")
            driver.find_element_by_id("id_default_max_age").clear()
            driver.find_element_by_id("id_default_max_age").send_keys("60")
            driver.find_element_by_id("id_max_age_rules").clear()
            driver.find_element_by_id("id_max_age_rules").send_keys("^/.*\\.jpg 86400")
            driver.find_element_by_id("id_content_variation_rules").clear()
            driver.find_element_by_id("id_content_variation_rules").send_keys("^/.*\\.html %cgender")
            driver.find_element_by_link_text("Request & Response").click()
            driver.find_element_by_id("id_origin_ip").clear()
            driver.find_element_by_id("id_origin_ip").send_keys("10.10.10.1")
            driver.find_element_by_id("id_origin_port").clear()
            driver.find_element_by_id("id_origin_port").send_keys("777")
            driver.find_element_by_id("id_origin_host_header").clear()
            driver.find_element_by_id("id_origin_host_header").send_keys("test.com")
            driver.find_element_by_id("id_use_pad_as_host_header").click()
            driver.find_element_by_id("id_custom_headers").clear()
            driver.find_element_by_id("id_custom_headers").send_keys("X-Foo: bar")
            driver.find_element_by_id("id_origin_failure_redirect_url").clear()
            driver.find_element_by_id("id_origin_failure_redirect_url").send_keys("1")
            Select(driver.find_element_by_id("id_upstream_ssl")).select_by_visible_text("None")
            driver.find_element_by_id("id_use_origin_multiple_dns_record").click()
            driver.find_element_by_id("id_use_origin_sticky").click()
            driver.find_element_by_id("id_honor_multi_byte_range").click()
            driver.find_element_by_id("id_max_requests_per_keep_alive").clear()
            driver.find_element_by_id("id_max_requests_per_keep_alive").send_keys("50")
            driver.find_element_by_id("id_pass_thru_headers_to_origin").clear()
            driver.find_element_by_id("id_pass_thru_headers_to_origin").send_keys("X-Test: selenium")
            driver.find_element_by_id("id_accept_setting_from_query_string").click()
            driver.find_element_by_id("id_enable_ssl").click()
            driver.find_element_by_id("id_honor_path_range").click()
            driver.find_element_by_id("id_reverse_proxy_redirect").click()
            driver.find_element_by_id("id_follow_redirect").click()
            driver.find_element_by_id("id_pass_thru_headers_to_user").clear()
            driver.find_element_by_id("id_pass_thru_headers_to_user").send_keys("X-Test: selenium")
            driver.find_element_by_id("id_deny_direct_user_request").click()
            driver.find_element_by_id("id_cookie_exchange").click()
            driver.find_element_by_link_text("Rewrite Rules").click()
            driver.find_element_by_id("id_case_insensitive_urls").click()
            driver.find_element_by_id("id_drop_params").click()
            driver.find_element_by_id("id_rewrite_rules").clear()
            driver.find_element_by_id("id_rewrite_rules").send_keys("^/(.*\\.html)/rewritten?=url=$1")
            driver.find_element_by_id("id_drop_params_post_validation").click()
            driver.find_element_by_id("id_rewrite_rules_post_validation").clear()
            driver.find_element_by_id("id_rewrite_rules_post_validation").send_keys("^/(.*\\.html)/rewritten?=url=$1")
            driver.find_element_by_id("id_drop_precise_params_post_validation").clear()
            driver.find_element_by_id("id_drop_precise_params_post_validation").send_keys("string")
            driver.find_element_by_id("id_drop_params_in_cache_url").click()
            driver.find_element_by_id("id_drop_precise_params_in_cache_url").clear()
            driver.find_element_by_id("id_drop_precise_params_in_cache_url").send_keys("test")
            driver.find_element_by_id("id_full_url_rewrite_rules").clear()
            driver.find_element_by_id("id_full_url_rewrite_rules").send_keys("^http://qatest.selenium-ff.com/(.html*)")
            driver.find_element_by_link_text("Validation").click()
            driver.find_element_by_id("id_referrer_list").clear()
            driver.find_element_by_id("id_referrer_list").send_keys("^https?://[a-zA-Z0-9._-]*\\.panthercustomer\\.com/.*")
            Select(driver.find_element_by_id("id_referrer_list_type")).select_by_visible_text("Whitelist")
            driver.find_element_by_id("id_failed_referrer_check_redirect_url").clear()
            driver.find_element_by_id("id_failed_referrer_check_redirect_url").send_keys("test.com")
            Select(driver.find_element_by_id("id_validation_scheme")).select_by_visible_text("Origin Logic Control")
            driver.find_element_by_id("id_bypass_validation_on_failure").click()
            driver.find_element_by_id("id_validation_default_redirect_url").clear()
            driver.find_element_by_id("id_validation_default_redirect_url").send_keys("test.com")
            driver.find_element_by_id("id_validation_custom_headers").clear()
            driver.find_element_by_id("id_validation_custom_headers").send_keys("X-Foo: Bar")
            driver.find_element_by_id("id_validation_nobypass_redirect_url").clear()
            driver.find_element_by_id("id_validation_nobypass_redirect_url").send_keys("test.com")
            driver.find_element_by_id("id_http_auth_user").clear()
            driver.find_element_by_id("id_http_auth_user").send_keys("hhh1@gala.com")
            driver.find_element_by_id("id_http_auth_password").clear()
            driver.find_element_by_id("id_http_auth_password").send_keys("cdnadmin")
            driver.find_element_by_id("id_tag_check_enabled").click()
            driver.find_element_by_id("id_tag_hash_format_preset").clear()
            driver.find_element_by_id("id_tag_hash_format_preset").send_keys("1")
            driver.find_element_by_id("id_tag_hash_format").clear()
            driver.find_element_by_id("id_tag_hash_format").send_keys("1")
            driver.find_element_by_id("id_tag_hash_param").clear()
            driver.find_element_by_id("id_tag_hash_param").send_keys("px-hash")
            driver.find_element_by_id("id_tag_secret").clear()
            driver.find_element_by_id("id_tag_secret").send_keys("1234")
            driver.find_element_by_id("id_tag_time_param").clear()
            driver.find_element_by_id("id_tag_time_param").send_keys("px-time")
            driver.find_element_by_id("id_tag_time_allowed_sec").clear()
            driver.find_element_by_id("id_tag_time_allowed_sec").send_keys("1")
            driver.find_element_by_id("id_tag_time_offset_sec").clear()
            driver.find_element_by_id("id_tag_time_offset_sec").send_keys("1")
            driver.find_element_by_id("id_tag_skip_patterns").clear()
            driver.find_element_by_id("id_tag_skip_patterns").send_keys("^/cross-domain\\.xml")
            driver.find_element_by_link_text("Video/Large File Delivery").click()
            driver.find_element_by_id("id_bps_streaming_limit").clear()
            driver.find_element_by_id("id_bps_streaming_limit").send_keys("1")
            driver.find_element_by_id("id_buffer_secs").clear()
            driver.find_element_by_id("id_buffer_secs").send_keys("1")
            driver.find_element_by_id("id_progressive_dl").click()
            driver.find_element_by_id("id_progressive_dl_param").clear()
            driver.find_element_by_id("id_progressive_dl_param").send_keys("start")
            Select(driver.find_element_by_id("id_pdseek_default_type")).select_by_visible_text("h264")
            driver.find_element_by_id("id_pdseek_flv_extensions").clear()
            driver.find_element_by_id("id_pdseek_flv_extensions").send_keys("flv")
            driver.find_element_by_id("id_pdseek_h264_extensions").clear()
            driver.find_element_by_id("id_pdseek_h264_extensions").send_keys("mp4,m4v")
            driver.find_element_by_link_text("Misc").click()

            ### Step 2
            driver.find_element_by_id("id_url_test").clear()
            driver.find_element_by_id("id_url_test").send_keys("default-origin.cdnetworks.com")
            Select(driver.find_element_by_id("id_mbps_avg")).select_by_visible_text("1-20 Mbps")
            Select(driver.find_element_by_id("id_mbps_peak")).select_by_visible_text("1-20 Mbps")
            Select(driver.find_element_by_id("id_rps_avg")).select_by_visible_text("1 - 2,500")
            Select(driver.find_element_by_id("id_rps_peak")).select_by_visible_text("1 - 2,500")
            driver.find_element_by_link_text("Files").click()
            driver.find_element_by_id("id_files_type").clear()
            driver.find_element_by_id("id_files_type").send_keys("*.jpg")
            driver.find_element_by_id("id_files_count").clear()
            driver.find_element_by_id("id_files_count").send_keys("1000")
            driver.find_element_by_id("id_files_size_avg").clear()
            driver.find_element_by_id("id_files_size_avg").send_keys("12400")
            Select(driver.find_element_by_id("id_files_size_max")).select_by_visible_text("0-1 MB")
            driver.find_element_by_link_text("Usage").click()
            driver.find_element_by_link_text("Comments").click()
            driver.find_element_by_id("id_misc_comment").clear()
            driver.find_element_by_id("id_misc_comment").send_keys("by selenium test")
            driver.find_element_by_name("submit").click()
            for i in range(60):
                try:
                    if "Your settings for selenium-dwa-ff-draft.com have been saved." == driver.find_element_by_css_selector("li").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")

            ### Asserts
            driver.get(AURORA_URL + "/cui/int/pads/?m=217")
            time.sleep(1)
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            driver.find_element_by_link_text(self.pad_name).click()
            self.assertEqual("Production Site Settings", driver.find_element_by_css_selector("h2").text)
            self.assertEqual(self.pad_name, driver.find_element_by_css_selector("td").text)
            self.assertEqual("alias.selenium-dwa-ff-draft.com", driver.find_element_by_css_selector("tr.row2 > td").text)
            self.assertEqual("default-origin.cdnetworks.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[5]/td").text)
            self.assertEqual("failover.selenium-ff.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[6]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[7]/td").text)
            self.assertEqual("selenium test", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[9]/td").text)
            driver.find_element_by_link_text("Caching").click()
            self.assertEqual("True", driver.find_element_by_css_selector("#pad_group_local_site_Caching > tr.row2 > td").text)
            self.assertEqual("60", driver.find_element_by_css_selector("#pad_group_local_site_Caching > tr.row1 > td").text)
            self.assertEqual("2015-12-25", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[5]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[6]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[7]/td").text)
            self.assertEqual("60", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[8]/td").text)
            #self.assertTrue(self.is_element_present(By.XPATH, "//tbody[@id='pad_group_local_site_Caching']/tr[9]/td"))
            #self.assertTrue(self.is_element_present(By.XPATH, "//tbody[@id='pad_group_local_site_Caching']/tr[10]/td"))
            driver.find_element_by_link_text("Request & Response").click()
            self.assertEqual("10.10.10.1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[3]/td").text)
            self.assertEqual("777", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[4]/td").text)
            self.assertEqual("test.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[5]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[6]/td").text)
            self.assertEqual("X-Foo: bar", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[7]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[8]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[9]/td").text)
            self.assertEqual("None", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[10]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[11]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[12]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[15]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[16]/td").text)
            self.assertEqual("50", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[17]/td").text)
            self.assertEqual("X-Test: selenium", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[18]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[19]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[20]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[21]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[24]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[25]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[26]/td").text)
            self.assertEqual("X-Test: selenium", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[27]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[28]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[31]/td").text)
            driver.find_element_by_link_text("Rewrite Rules").click()
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[3]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[4]/td").text)
            #self.assertTrue(self.is_element_present(By.XPATH, "//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[5]/td"))
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[6]/td").text)
            #self.assertTrue(self.is_element_present(By.XPATH, "//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[7]/td"))
            self.assertEqual("string", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[8]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[9]/td").text)
            self.assertEqual("test", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[10]/td").text)
            #self.assertTrue(self.is_element_present(By.XPATH, "//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[11]/td"))
            driver.find_element_by_link_text("Validation").click()
            #self.assertTrue(self.is_element_present(By.CSS_SELECTOR, "#pad_group_local_site_Validation > tr.row2 > td"))
            self.assertEqual("Whitelist", driver.find_element_by_css_selector("#pad_group_local_site_Validation > tr.row1 > td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[5]/td").text)
            self.assertEqual("test.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[6]/td").text)
            self.assertEqual("Origin Logic Control", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[9]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[10]/td").text)
            self.assertEqual("test.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[11]/td").text)
            self.assertEqual("X-Foo: Bar", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[12]/td").text)
            self.assertEqual("test.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[13]/td").text)
            self.assertEqual("hhh1@gala.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[14]/td").text)
            self.assertEqual("cdnadmin", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[15]/td").text)
            self.assertEqual("Basic", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[16]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[19]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[20]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[21]/td").text)
            self.assertEqual("px-hash", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[22]/td").text)
            self.assertEqual("1234", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[23]/td").text)
            self.assertEqual("px-time", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[24]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[25]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[26]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[27]/td").text)
            self.assertEqual("^/cross-domain\\.xml", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[28]/td").text)
            driver.find_element_by_id("tab_local_site_Video/Large File Delivery").click()
            driver.find_element_by_link_text("Video/Large File Delivery").click()
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[3]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[6]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[7]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[10]/td").text)
            self.assertEqual("start", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[11]/td").text)
            self.assertEqual("h264", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[12]/td").text)
            self.assertEqual("flv", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[13]/td").text)
            self.assertEqual("mp4,m4v", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[14]/td").text)
            driver.find_element_by_id("tab_local_site_Misc").click()
            self.assertEqual("http://default-origin.cdnetworks.com/", driver.find_element_by_css_selector("#pad_group_site_stat_Basic > tr.row1 > td").text)
            self.assertEqual("1-20 Mbps", driver.find_element_by_css_selector("#pad_group_site_stat_Basic > tr.row2 > td").text)
            self.assertEqual("1-20 Mbps", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Basic']/tr[4]/td").text)
            self.assertEqual("1 - 2,500", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Basic']/tr[5]/td").text)
            self.assertEqual("1 - 2,500", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Basic']/tr[6]/td").text)
            driver.find_element_by_link_text("Files").click()
            #self.assertTrue(self.is_element_present(By.CSS_SELECTOR, "#pad_group_site_stat_Files > tr.row2 > td"))
            self.assertEqual("1000", driver.find_element_by_css_selector("#pad_group_site_stat_Files > tr.row1 > td").text)
            self.assertEqual("12400", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Files']/tr[4]/td").text)
            self.assertEqual("0-1 MB", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Files']/tr[5]/td").text)
            driver.find_element_by_link_text("Usage").click()
            self.assertEqual("Not Set", driver.find_element_by_css_selector("#pad_group_site_stat_Usage > tr.row2 > td").text)
            self.assertEqual("Not Set", driver.find_element_by_css_selector("tr.row1 > td > i").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Usage']/tr[4]/td/i").text)
            driver.find_element_by_link_text("Comments").click()
            self.assertEqual("by selenium test", driver.find_element_by_css_selector("#pad_group_site_stat_Comments > tr.row1 > td").text)
            if self.USER == 'tst_dwa_add_edit_priv@jimdo.cdn.com':
                self.assertEqual("tst_dwa_add_edit_priv@jimdo.cd", driver.find_element_by_xpath("//table[@id='change_history']/tbody/tr/td[2]").text)
            elif self.USER == 'tst_master_piv@jimdo.cdn.com':
                self.assertEqual("tst_master_piv@jimdo.cdn.com", driver.find_element_by_xpath("//table[@id='change_history']/tbody/tr/td[2]").text)

        elif self.USER == 'tst_dwa_edit_priv@jimdo.cdn.com' or self.USER == 'tst_dwa_view_only_priv@jimdo.cdn.com' or self.USER == 'tst_no_piv@jimdo.cdn.com':
            ## CA menu
            driver = self.driver
            driver.get(AURORA_URL + "/cui/int/pads/add/?m=205")
            time.sleep(3)
            ## Access Denied
            #import pdb; pdb.set_trace()
            for i in range(60):
                try:
                    if "Error 403" == driver.find_element_by_css_selector("h1.pa-title").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")

            try:
                if "Add new PAD" ==  driver.find_element_by_link_text("Add new PAD").text:
                    self.fail("Exist Add new PAD menu")
            except: pass

        else: raise Exception("No matched account.")

        ### Clear
        """driver.get(AURORA_URL + "/cui/int/pads/?m=202")
        time.sleep(3)
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))

        if self.BROWSER == 'safari' or 'chrome':
            driver.execute_script("window.confirm = function() { return true; }")
            driver.find_element_by_css_selector("a[data-delete='"+self.pad_name+"']").click()
        else:
            driver.find_element_by_css_selector("a[data-delete='"+self.pad_name+"']").click()
            driver.switch_to_alert().accept()
        """
        driver.save_screenshot('img/result/'+self.BROWSER+'_'+ __file__.strip('.py')+'-add-result.png')
    
if __name__ == '__main__':
    # For hub-node
    if len(sys.argv) == 6:
        if len(sys.argv) != 6:
            raise Exception("Please remember usage: python {FILE} {NODE} {BROWSER} {OS} {PORT} {USER}")
        print ""
        print "usage: python {FILE} {NODE} {BROWSER} {OS} {PORT} {USER}"
        print "example: python Adding_CA_PAD.py 'http://linux-node.cdnetworks.com:5555/wd/hub/' 'firefox' 'LINUX' 5555 'test_dwa_add_edit_priv@gala.cdn.com'"
        print ""
        # Arguments
        CustomerCATest.USER = sys.argv.pop()
        CustomerCATest.PORT = sys.argv.pop()
        CustomerCATest.OS = sys.argv.pop()
        CustomerCATest.BROWSER = sys.argv.pop()
        CustomerCATest.NODE = sys.argv.pop()
    # For only account
    elif len(sys.argv) == 2:
        print ""
        print "usage: python {FILE} {USER}"
        print "example: python Adding_CA_PAD.py 'test_dwa_add_edit_priv@gala.cdn.com'"
        print ""
        # Arguements
        CustomerCATest.USER = sys.argv.pop()
    # For argument number
    elif 2 < len(sys.argv) < 5 or len(sys.argv) > 7:
        print ""
        print "usage: python {FILE} {NODE} {BROWSER} {OS} {PORT} {USER}"
        print "OR"
        print "usage: python {FILE} {USER}"
        raise Exception("The number of arguments is wrong.")
    unittest.main()
