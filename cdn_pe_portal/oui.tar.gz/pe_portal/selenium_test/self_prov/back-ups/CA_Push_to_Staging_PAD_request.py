#!/usr/bin/python
#-*-encoding: utf-8-*-

## PATH
import time, unittest, sys, os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)

## CONFIGURATIONS
from selenium_test.shared_components.login import SeleniumRC
from selenium_test.shared_components.utils import *
from selenium_test.shared_components.decorator import *
from selenium_test.config_user_constants import SELF_PROV_USER
from selenium_test.config_constants import AURORA_URL, OUI_URL

## SELENIUM MODUES
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select

rc = SeleniumRC()
@logclass
class CustomerCATest(unittest.TestCase):
    @logmethod
    def setUp(self):
        # Loading DB dump by script (jongsoo.bae) aurora.activate()
        ## webdriver according to browser
        if len(g_args_list) == 1:
            g_args_list['BROWSER'] = 'firefox'
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        elif len(g_args_list) == 2:
            self.driver = webdriver.Firefox()
            self.pad_name = "selenium-firefox.cdnetworks.com"
        elif len(g_args_list) == 5:
            self.driver = rc.get_driver(g_args_list['NODE'],g_args_list['BROWSER'],g_args_list['OS'],g_args_list['PORT'])
            if g_args_list['BROWSER'] == 'internet explorer':
                self.pad_name = "selenium-ie.cdnetworks.com"
            else:
                self.pad_name = "selenium-"+g_args_list['BROWSER']+".cdnetworks.com"
        else:
            raise Exception("The number of arguments is wrong.")

        driver = self.driver
        driver.get(AURORA_URL + "/accounts/login/")
        driver.find_element_by_id("id_username").clear()
        driver.find_element_by_id("id_username").send_keys(g_args_list['USER'])
        driver.find_element_by_id("id_password").clear()
        driver.find_element_by_id("id_password").send_keys(SELF_PROV_USER['PASSWORD'])
        driver.find_element_by_id("id_login").click()
        time.sleep(3)

    @logmethod
    def tearDown(self):
        # Destroying DB (jongsoo.bae) aurora.deactivate()
        driver = self.driver
        driver.close()

    @logmethod
    def push_to_staging_oui(self, driver):
        # OUI doesn't work in IE
        if g_args_list['BROWSER'] == 'internet explorer' or g_args_list['BROWSER'] == 'safari':
            # Closed your before browser
            driver.close()
            # Let's bring it on FireFox
            self.driver = webdriver.Firefox()
            driver = self.driver

        driver.get(OUI_URL + "/login/?next=/")
        driver.find_element_by_id("id_password").clear()
        driver.find_element_by_id("id_password").send_keys("cdnadmin")
        driver.find_element_by_id("id_username").clear()
        driver.find_element_by_id("id_username").send_keys("jungho.park")
        driver.find_element_by_id("submit").click()
        driver.find_element_by_id("search_input").click()
        driver.find_element_by_id("search_input").send_keys("jimdo")
        driver.find_element_by_id("search_input").send_keys(Keys.ENTER)
        for i in range(60):
            try:
                if "local CDNetworks OUI: Search: jimdo" == driver.title: break
            except: pass
            time.sleep(1)
        else: self.fail("time out")
        driver.find_element_by_link_text("Jimdo").click()
        self.assertEqual("selenium-noself.com", driver.find_element_by_css_selector("p > strong").text)
        self.assertEqual("Pending implementation requests", driver.find_element_by_css_selector("div.dash_module.dash_module_lg > h2.title").text)
        driver.find_element_by_link_text("edit and approve").click()
        for i in range(60):
            try:
                if "local CDNetworks OUI: Edit Site:" == driver.title: break
            except: pass
            time.sleep(1)
        else: self.fail("time out")
        self.assertEqual(self.pad_name, driver.find_element_by_id("id_pad").get_attribute("value"))
        self.assertEqual("0", driver.find_element_by_id("id_type_flag").get_attribute("value"))
        self.assertEqual("60", driver.find_element_by_id("id_nonwildcard_hour").get_attribute("value"))
        self.assertEqual("1000", driver.find_element_by_id("id_items_per_request").get_attribute("value"))
        self.assertEqual("1", driver.find_element_by_id("id_all_per_hour").get_attribute("value"))
        self.assertEqual("10", driver.find_element_by_id("id_wildcards_per_hour").get_attribute("value"))
        self.assertEqual("10", driver.find_element_by_id("id_wildcards_per_request").get_attribute("value"))
        self.assertEqual("alias."+self.pad_name, driver.find_element_by_id("id_pad_aliases").get_attribute("value"))
        self.assertEqual("origin.cdnetworks.com", driver.find_element_by_id("id_origin").get_attribute("value"))
        self.assertEqual("failover.selenium-noself.com", driver.find_element_by_id("id_backup_origin").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_status").get_attribute("value"))
        self.assertEqual("", driver.find_element_by_id("id_cname_prefix").get_attribute("value"))
        self.assertEqual("cdngc.net", driver.find_element_by_id("id_cname_dns_zone_record").text)
        self.assertEqual("selenium test", driver.find_element_by_id("id_description").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_pass_all_headers").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_strict_nocache_support").get_attribute("value"))
        self.assertEqual("60", driver.find_element_by_id("id_min_age").get_attribute("value"))
        self.assertEqual("2015-12-25", driver.find_element_by_id("id_default_last_modified_date").get_attribute("value"))
        self.assertEqual("1", driver.find_element_by_id("id_force_not_modified_on_ims").get_attribute("value"))
        self.assertEqual("1", driver.find_element_by_id("id_force_maxage_on_40x").get_attribute("value"))
        self.assertEqual("60", driver.find_element_by_id("id_default_max_age").get_attribute("value"))
        self.assertEqual(u'^/.*\\.jpg 86400', driver.find_element_by_id("id_max_age_rules").get_attribute("value"))
        self.assertEqual(u'^/.*\\.html %cgender',driver.find_element_by_id("id_content_variation_rules").get_attribute("value"))
        self.assertEqual("10.10.10.1", driver.find_element_by_id("id_origin_ip").get_attribute("value"))
        self.assertEqual("777", driver.find_element_by_id("id_origin_port").get_attribute("value"))
        self.assertEqual("test.com", driver.find_element_by_id("id_origin_host_header").get_attribute("value"))
        self.assertEqual("X-Foo: bar", driver.find_element_by_id("id_custom_headers").get_attribute("value"))
        self.assertEqual("1", driver.find_element_by_id("id_origin_failure_redirect_url").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_use_origin_multiple_dns_record").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_use_origin_sticky").get_attribute("value"))
        self.assertEqual( u'Asychronous\nSynchronous\nBackground', driver.find_element_by_id("id_dns_refresh_type").text)
        self.assertEqual("0", driver.find_element_by_id("id_dns_entry_existing_time_limit").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_honor_multi_byte_range").get_attribute("value"))
        self.assertEqual("50", driver.find_element_by_id("id_max_requests_per_keep_alive").get_attribute("value"))
        self.assertEqual("X-Test: selenium", driver.find_element_by_id("id_pass_thru_headers_to_origin").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_accept_setting_from_query_string").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_enable_ssl").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_honor_path_range").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_reverse_proxy_redirect").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_follow_redirect").get_attribute("value"))
        self.assertEqual("X-Test: selenium", driver.find_element_by_id("id_pass_thru_headers_to_user").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_deny_direct_user_request").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_cookie_exchange").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_case_insensitive_urls").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_drop_params").get_attribute("value"))
        self.assertEqual( u'^/(.*\\.html)/rewritten?=url=$1', driver.find_element_by_id("id_rewrite_rules").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_drop_params_post_validation").get_attribute("value"))
        self.assertEqual( u'^/(.*\\.html)/rewritten?=url=$1', driver.find_element_by_id("id_rewrite_rules_post_validation").get_attribute("value"))
        self.assertEqual("string", driver.find_element_by_id("id_drop_precise_params_post_validation").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_drop_params_in_cache_url").get_attribute("value"))
        self.assertEqual("test", driver.find_element_by_id("id_drop_precise_params_in_cache_url").get_attribute("value"))
        self.assertEqual(u'^http://qatest.selenium-ff.com/(.html*)', driver.find_element_by_id("id_full_url_rewrite_rules").get_attribute("value"))
        self.assertEqual(u'^https?://[a-zA-Z0-9._-]*\\.panthercustomer\\.com/.*', driver.find_element_by_id("id_referrer_list").get_attribute("value"))
        self.assertEqual(u'Blacklist\nWhitelist', driver.find_element_by_id("id_referrer_list_type").text)
        self.assertEqual("test.com", driver.find_element_by_id("id_failed_referrer_check_redirect_url").get_attribute("value"))
        self.assertEqual( u'None\nOrigin Logic Control\nBasic Authentication', driver.find_element_by_id("id_validation_scheme").text)
        self.assertEqual("on", driver.find_element_by_id("id_bypass_validation_on_failure").get_attribute("value"))
        self.assertEqual("test.com", driver.find_element_by_id("id_validation_default_redirect_url").get_attribute("value"))
        self.assertEqual("X-Foo: Bar", driver.find_element_by_id("id_validation_custom_headers").get_attribute("value"))
        self.assertEqual("test.com", driver.find_element_by_id("id_validation_nobypass_redirect_url").get_attribute("value"))
        self.assertEqual("hhh1@gala.com", driver.find_element_by_id("id_http_auth_user").get_attribute("value"))
        self.assertEqual("cdnadmin", driver.find_element_by_id("id_http_auth_password").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_tag_check_enabled").get_attribute("value"))
        self.assertEqual("1", driver.find_element_by_id("id_tag_hash_format_preset").get_attribute("value"))
        self.assertEqual("1", driver.find_element_by_id("id_tag_hash_format").get_attribute("value"))
        self.assertEqual("px-hash", driver.find_element_by_id("id_tag_hash_param").get_attribute("value"))
        self.assertEqual("1234", driver.find_element_by_id("id_tag_secret").get_attribute("value"))
        self.assertEqual("px-time", driver.find_element_by_id("id_tag_time_param").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_tag_time_in_hex").get_attribute("value"))
        self.assertEqual("1", driver.find_element_by_id("id_tag_time_allowed_sec").get_attribute("value"))
        self.assertEqual("1", driver.find_element_by_id("id_tag_time_offset_sec").get_attribute("value"))
        self.assertEqual("^/cross-domain\\.xml", driver.find_element_by_id("id_tag_skip_patterns").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_use_sub_files").get_attribute("value"))
        self.assertEqual("0", driver.find_element_by_id("id_large_file_redirect_size").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_use_circular_buffer").get_attribute("value"))
        self.assertEqual("1", driver.find_element_by_id("id_bps_streaming_limit").get_attribute("value"))
        self.assertEqual("1", driver.find_element_by_id("id_buffer_secs").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_progressive_dl").get_attribute("value"))
        self.assertEqual("start", driver.find_element_by_id("id_progressive_dl_param").get_attribute("value"))
        self.assertEqual(u'flv\nh264', driver.find_element_by_id("id_pdseek_default_type").text)
        self.assertEqual("flv", driver.find_element_by_id("id_pdseek_flv_extensions").get_attribute("value"))
        self.assertEqual("mp4,m4v", driver.find_element_by_id("id_pdseek_h264_extensions").get_attribute("value"))
        self.assertEqual("", driver.find_element_by_id("id_request_log_msg_format").get_attribute("value"))
        self.assertEqual("on", driver.find_element_by_id("id_track_urls").get_attribute("value"))
        self.assertEqual("", driver.find_element_by_id("id_track_codes").get_attribute("value"))
        self.assertEqual("", driver.find_element_by_id("id_auth_key").get_attribute("value"))
        self.assertEqual("", driver.find_element_by_id("id_custom_param").get_attribute("value"))
        self.assertEqual("", driver.find_element_by_id("id_stat_paths").get_attribute("value"))
        self.assertEqual("0", driver.find_element_by_id("id_max_master_retries").get_attribute("value"))
        self.assertEqual("", driver.find_element_by_id("id_change_comment").get_attribute("value"))
        self.assertEqual("1", driver.find_element_by_id("push_sites").get_attribute("value"))

    @logmethod
    def test1_push_to_staging_aurora(self):
        driver = self.driver
        ## reqeust PAD implementation
        if g_args_list['USER'] == 'tst_ca_add_edit_priv@jimdo.cdn.com' or g_args_list['USER'] == 'tst_master_piv@jimdo.cdn.com':
            self.pad_name = 'selenium-noself.com'
            driver = self.driver
            driver.get(AURORA_URL + "/cui/int/pads/add/?m=190")
            time.sleep(3)
            driver.find_element_by_link_text("Add new PAD").click()
            time.sleep(3)

            ### CUI frame
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            for i in range(60):
                try:
                    if "Input PAD settings manually" == driver.find_element_by_link_text("Input PAD settings manually").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")
            driver.find_element_by_link_text("Input PAD settings manually").click()
            for i in range(60):
                try:
                    if "PAD Set Up - 3 Steps" == driver.find_element_by_css_selector("#pad_edit > h2").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")

            ### Step 1
            driver.find_element_by_id("id_pad").clear()
            driver.find_element_by_id("id_pad").send_keys(self.pad_name)
            driver.find_element_by_id("id_pad_aliases").clear()
            driver.find_element_by_id("id_pad_aliases").send_keys("alias."+self.pad_name)
            driver.find_element_by_id("id_origin").clear()
            driver.find_element_by_id("id_origin").send_keys("origin.cdnetworks.com")
            driver.find_element_by_id("id_backup_origin").clear()
            driver.find_element_by_id("id_backup_origin").send_keys("failover."+self.pad_name)
            driver.find_element_by_id("id_description").clear()
            driver.find_element_by_id("id_description").send_keys("selenium test")
            time.sleep(1)
            driver.find_element_by_link_text("Caching").click()
            driver.find_element_by_id("id_strict_nocache_support").click()
            driver.find_element_by_id("id_min_age").clear()
            driver.find_element_by_id("id_min_age").send_keys("60")
            driver.find_element_by_id("id_default_last_modified_date").clear()
            driver.find_element_by_id("id_default_last_modified_date").send_keys("2015-12-25")
            driver.find_element_by_id("id_force_not_modified_on_ims").clear()
            driver.find_element_by_id("id_force_not_modified_on_ims").send_keys("1")
            driver.find_element_by_id("id_force_maxage_on_40x").clear()
            driver.find_element_by_id("id_force_maxage_on_40x").send_keys("1")
            driver.find_element_by_id("id_default_max_age").clear()
            driver.find_element_by_id("id_default_max_age").send_keys("60")
            driver.find_element_by_id("id_max_age_rules").clear()
            driver.find_element_by_id("id_max_age_rules").send_keys("^/.*\\.jpg 86400")
            driver.find_element_by_id("id_content_variation_rules").clear()
            driver.find_element_by_id("id_content_variation_rules").send_keys("^/.*\\.html %cgender")
            driver.find_element_by_link_text("Request & Response").click()
            driver.find_element_by_id("id_origin_ip").clear()
            driver.find_element_by_id("id_origin_ip").send_keys("10.10.10.1")
            driver.find_element_by_id("id_origin_port").clear()
            driver.find_element_by_id("id_origin_port").send_keys("777")
            driver.find_element_by_id("id_origin_host_header").clear()
            driver.find_element_by_id("id_origin_host_header").send_keys("test.com")
            driver.find_element_by_id("id_use_pad_as_host_header").click()
            driver.find_element_by_id("id_custom_headers").clear()
            driver.find_element_by_id("id_custom_headers").send_keys("X-Foo: bar")
            driver.find_element_by_id("id_origin_failure_redirect_url").clear()
            driver.find_element_by_id("id_origin_failure_redirect_url").send_keys("1")
            Select(driver.find_element_by_id("id_upstream_ssl")).select_by_visible_text("None")
            driver.find_element_by_id("id_use_origin_multiple_dns_record").click()
            driver.find_element_by_id("id_use_origin_sticky").click()
            driver.find_element_by_id("id_honor_multi_byte_range").click()
            driver.find_element_by_id("id_max_requests_per_keep_alive").clear()
            driver.find_element_by_id("id_max_requests_per_keep_alive").send_keys("50")
            driver.find_element_by_id("id_pass_thru_headers_to_origin").clear()
            driver.find_element_by_id("id_pass_thru_headers_to_origin").send_keys("X-Test: selenium")
            driver.find_element_by_id("id_accept_setting_from_query_string").click()
            driver.find_element_by_id("id_enable_ssl").click()
            driver.find_element_by_id("id_honor_path_range").click()
            driver.find_element_by_id("id_reverse_proxy_redirect").click()
            driver.find_element_by_id("id_follow_redirect").click()
            driver.find_element_by_id("id_pass_thru_headers_to_user").clear()
            driver.find_element_by_id("id_pass_thru_headers_to_user").send_keys("X-Test: selenium")
            driver.find_element_by_id("id_deny_direct_user_request").click()
            driver.find_element_by_id("id_cookie_exchange").click()
            driver.find_element_by_link_text("Rewrite Rules").click()
            driver.find_element_by_id("id_case_insensitive_urls").click()
            driver.find_element_by_id("id_drop_params").click()
            driver.find_element_by_id("id_rewrite_rules").clear()
            driver.find_element_by_id("id_rewrite_rules").send_keys("^/(.*\\.html)/rewritten?=url=$1")
            driver.find_element_by_id("id_drop_params_post_validation").click()
            driver.find_element_by_id("id_rewrite_rules_post_validation").clear()
            driver.find_element_by_id("id_rewrite_rules_post_validation").send_keys("^/(.*\\.html)/rewritten?=url=$1")
            driver.find_element_by_id("id_drop_precise_params_post_validation").clear()
            driver.find_element_by_id("id_drop_precise_params_post_validation").send_keys("string")
            driver.find_element_by_id("id_drop_params_in_cache_url").click()
            driver.find_element_by_id("id_drop_precise_params_in_cache_url").clear()
            driver.find_element_by_id("id_drop_precise_params_in_cache_url").send_keys("test")
            driver.find_element_by_id("id_full_url_rewrite_rules").clear()
            driver.find_element_by_id("id_full_url_rewrite_rules").send_keys("^http://qatest.selenium-ff.com/(.html*)")
            driver.find_element_by_link_text("Validation").click()
            driver.find_element_by_id("id_referrer_list").clear()
            driver.find_element_by_id("id_referrer_list").send_keys("^https?://[a-zA-Z0-9._-]*\\.panthercustomer\\.com/.*")
            Select(driver.find_element_by_id("id_referrer_list_type")).select_by_visible_text("Whitelist")
            driver.find_element_by_id("id_failed_referrer_check_redirect_url").clear()
            driver.find_element_by_id("id_failed_referrer_check_redirect_url").send_keys("test.com")
            Select(driver.find_element_by_id("id_validation_scheme")).select_by_visible_text("Origin Logic Control")
            driver.find_element_by_id("id_bypass_validation_on_failure").click()
            driver.find_element_by_id("id_validation_default_redirect_url").clear()
            driver.find_element_by_id("id_validation_default_redirect_url").send_keys("test.com")
            driver.find_element_by_id("id_validation_custom_headers").clear()
            driver.find_element_by_id("id_validation_custom_headers").send_keys("X-Foo: Bar")
            driver.find_element_by_id("id_validation_nobypass_redirect_url").clear()
            driver.find_element_by_id("id_validation_nobypass_redirect_url").send_keys("test.com")
            driver.find_element_by_id("id_http_auth_user").clear()
            driver.find_element_by_id("id_http_auth_user").send_keys("hhh1@gala.com")
            driver.find_element_by_id("id_http_auth_password").clear()
            driver.find_element_by_id("id_http_auth_password").send_keys("cdnadmin")
            driver.find_element_by_id("id_tag_check_enabled").click()
            driver.find_element_by_id("id_tag_hash_format_preset").clear()
            driver.find_element_by_id("id_tag_hash_format_preset").send_keys("1")
            driver.find_element_by_id("id_tag_hash_format").clear()
            driver.find_element_by_id("id_tag_hash_format").send_keys("1")
            driver.find_element_by_id("id_tag_hash_param").clear()
            driver.find_element_by_id("id_tag_hash_param").send_keys("px-hash")
            driver.find_element_by_id("id_tag_secret").clear()
            driver.find_element_by_id("id_tag_secret").send_keys("1234")
            driver.find_element_by_id("id_tag_time_param").clear()
            driver.find_element_by_id("id_tag_time_param").send_keys("px-time")
            driver.find_element_by_id("id_tag_time_allowed_sec").clear()
            driver.find_element_by_id("id_tag_time_allowed_sec").send_keys("1")
            driver.find_element_by_id("id_tag_time_offset_sec").clear()
            driver.find_element_by_id("id_tag_time_offset_sec").send_keys("1")
            driver.find_element_by_id("id_tag_skip_patterns").clear()
            driver.find_element_by_id("id_tag_skip_patterns").send_keys("^/cross-domain\\.xml")
            driver.find_element_by_link_text("Video/Large File Delivery").click()
            driver.find_element_by_id("id_bps_streaming_limit").clear()
            driver.find_element_by_id("id_bps_streaming_limit").send_keys("1")
            driver.find_element_by_id("id_buffer_secs").clear()
            driver.find_element_by_id("id_buffer_secs").send_keys("1")
            driver.find_element_by_id("id_progressive_dl").click()
            driver.find_element_by_id("id_progressive_dl_param").clear()
            driver.find_element_by_id("id_progressive_dl_param").send_keys("start")
            Select(driver.find_element_by_id("id_pdseek_default_type")).select_by_visible_text("h264")
            driver.find_element_by_id("id_pdseek_flv_extensions").clear()
            driver.find_element_by_id("id_pdseek_flv_extensions").send_keys("flv")
            driver.find_element_by_id("id_pdseek_h264_extensions").clear()
            driver.find_element_by_id("id_pdseek_h264_extensions").send_keys("mp4,m4v")
            driver.find_element_by_link_text("Misc").click()

            ### Step 2
            driver.find_element_by_id("id_url_test").clear()
            driver.find_element_by_id("id_url_test").send_keys("default-origin.cdnetworks.com")
            Select(driver.find_element_by_id("id_mbps_avg")).select_by_visible_text("1-20 Mbps")
            Select(driver.find_element_by_id("id_mbps_peak")).select_by_visible_text("1-20 Mbps")
            Select(driver.find_element_by_id("id_rps_avg")).select_by_visible_text("1 - 2,500")
            Select(driver.find_element_by_id("id_rps_peak")).select_by_visible_text("1 - 2,500")
            driver.find_element_by_link_text("Files").click()
            driver.find_element_by_id("id_files_type").clear()
            driver.find_element_by_id("id_files_type").send_keys("*.jpg")
            driver.find_element_by_id("id_files_count").clear()
            driver.find_element_by_id("id_files_count").send_keys("1000")
            driver.find_element_by_id("id_files_size_avg").clear()
            driver.find_element_by_id("id_files_size_avg").send_keys("12400")
            Select(driver.find_element_by_id("id_files_size_max")).select_by_visible_text("0-1 MB")
            driver.find_element_by_link_text("Usage").click()
            driver.find_element_by_link_text("Comments").click()
            driver.find_element_by_id("id_misc_comment").clear()
            driver.find_element_by_id("id_misc_comment").send_keys("by selenium test")
            driver.find_element_by_name("submit").click()
            for i in range(60):
                try:
                    if "Your settings for "+self.pad_name+" have been saved." == driver.find_element_by_css_selector("li").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")

            ### Asserts
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
            time.sleep(1)
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            driver.find_element_by_link_text(self.pad_name).click()
            for i in range(60):
                try:
                    if "" == driver.find_element_by_xpath("//input[@value='request implementation']").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")
            self.assertEqual("Production Site Settings", driver.find_element_by_css_selector("h2").text)
            self.assertEqual(self.pad_name, driver.find_element_by_css_selector("td").text)
            self.assertEqual("alias."+self.pad_name, driver.find_element_by_css_selector("tr.row2 > td").text)
            self.assertEqual("default-origin.cdnetworks.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[5]/td").text)
            self.assertEqual("failover."+self.pad_name, driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[6]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[7]/td").text)
            self.assertEqual("selenium test", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Basic']/tr[9]/td").text)
            driver.find_element_by_link_text("Caching").click()
            self.assertEqual("True", driver.find_element_by_css_selector("#pad_group_local_site_Caching > tr.row2 > td").text)
            self.assertEqual("60", driver.find_element_by_css_selector("#pad_group_local_site_Caching > tr.row1 > td").text)
            self.assertEqual("2015-12-25", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[5]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[6]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[7]/td").text)
            self.assertEqual("60", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[8]/td").text)
            self.assertEqual(u'^/.*\\.jpg 86400', driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[9]/td").text)
            self.assertEqual(u'^/.*\\.html %cgender', driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Caching']/tr[10]/td").text)
            driver.find_element_by_link_text("Request & Response").click()
            self.assertEqual("10.10.10.1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[3]/td").text)
            self.assertEqual("777", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[4]/td").text)
            self.assertEqual("test.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[5]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[6]/td").text)
            self.assertEqual("X-Foo: bar", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[7]/td").text)
            self.assertEqual("False", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[8]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[9]/td").text)
            self.assertEqual("None", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[10]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[11]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[12]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[15]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[16]/td").text)
            self.assertEqual("50", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[17]/td").text)
            self.assertEqual("X-Test: selenium", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[18]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[19]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[20]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[21]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[24]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[25]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[26]/td").text)
            self.assertEqual("X-Test: selenium", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[27]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[28]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Request & Response']/tr[31]/td").text)
            driver.find_element_by_link_text("Rewrite Rules").click()
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[3]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[4]/td").text)
            self.assertEqual( u'^/(.*\\.html)/rewritten?=url=$1', driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[5]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[6]/td").text)
            self.assertEqual( u'^/(.*\\.html)/rewritten?=url=$1', driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[5]/td").text)
            self.assertEqual("string", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[8]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[9]/td").text)
            self.assertEqual("test", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[10]/td").text)
            self.assertEqual(u'^http://qatest.selenium-ff.com/(.html*)', driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Rewrite Rules']/tr[11]/td").text)
            driver.find_element_by_link_text("Validation").click()
            self.assertEqual(u'^https?://[a-zA-Z0-9._-]*\\.panthercustomer\\.com/.*', driver.find_element_by_css_selector("#pad_group_local_site_Validation > tr.row2 > td").text)
            self.assertEqual("Whitelist", driver.find_element_by_css_selector("#pad_group_local_site_Validation > tr.row1 > td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[5]/td").text)
            self.assertEqual("test.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[6]/td").text)
            self.assertEqual("Origin Logic Control", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[9]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[10]/td").text)
            self.assertEqual("test.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[11]/td").text)
            self.assertEqual("X-Foo: Bar", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[12]/td").text)
            self.assertEqual("test.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[13]/td").text)
            self.assertEqual("hhh1@gala.com", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[14]/td").text)
            self.assertEqual("cdnadmin", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[15]/td").text)
            self.assertEqual("Basic", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[16]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[19]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[20]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[21]/td").text)
            self.assertEqual("px-hash", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[22]/td").text)
            self.assertEqual("1234", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[23]/td").text)
            self.assertEqual("px-time", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[24]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[25]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[26]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[27]/td").text)
            self.assertEqual("^/cross-domain\\.xml", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Validation']/tr[28]/td").text)
            driver.find_element_by_id("tab_local_site_Video/Large File Delivery").click()
            driver.find_element_by_link_text("Video/Large File Delivery").click()
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[3]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[6]/td").text)
            self.assertEqual("1", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[7]/td").text)
            self.assertEqual("True", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[10]/td").text)
            self.assertEqual("start", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[11]/td").text)
            self.assertEqual("h264", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[12]/td").text)
            self.assertEqual("flv", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[13]/td").text)
            self.assertEqual("mp4,m4v", driver.find_element_by_xpath("//tbody[@id='pad_group_local_site_Video/Large File Delivery']/tr[14]/td").text)
            driver.find_element_by_id("tab_local_site_Misc").click()
            self.assertEqual("http://default-origin.cdnetworks.com/", driver.find_element_by_css_selector("#pad_group_site_stat_Basic > tr.row1 > td").text)
            self.assertEqual("1-20 Mbps", driver.find_element_by_css_selector("#pad_group_site_stat_Basic > tr.row2 > td").text)
            self.assertEqual("1-20 Mbps", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Basic']/tr[4]/td").text)
            self.assertEqual("1 - 2,500", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Basic']/tr[5]/td").text)
            self.assertEqual("1 - 2,500", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Basic']/tr[6]/td").text)
            driver.find_element_by_link_text("Files").click()
            self.assertEqual(u'*.jpg', driver.find_element_by_css_selector("#pad_group_site_stat_Files > tr.row2 > td").text)
            self.assertEqual("1000", driver.find_element_by_css_selector("#pad_group_site_stat_Files > tr.row1 > td").text)
            self.assertEqual("12400", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Files']/tr[4]/td").text)
            self.assertEqual("0-1 MB", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Files']/tr[5]/td").text)
            driver.find_element_by_link_text("Usage").click()
            self.assertEqual("Not Set", driver.find_element_by_css_selector("#pad_group_site_stat_Usage > tr.row2 > td").text)
            self.assertEqual("Not Set", driver.find_element_by_css_selector("tr.row1 > td > i").text)
            self.assertEqual("Not Set", driver.find_element_by_xpath("//tbody[@id='pad_group_site_stat_Usage']/tr[4]/td/i").text)
            driver.find_element_by_link_text("Comments").click()
            self.assertEqual("by selenium test", driver.find_element_by_css_selector("#pad_group_site_stat_Comments > tr.row1 > td").text)
            if g_args_list['USER'] == 'tst_ca_add_edit_priv@jimdo.cdn.com':
                self.assertEqual("tst_ca_add_edit_priv@jimdo.cdn.com", driver.find_element_by_xpath("//table[@id='change_history']/tbody/tr/td[2]").text)
            elif g_args_list['USER'] == 'tst_master_piv@jimdo.cdn.com':
                self.assertEqual("tst_master_piv@jimdo.cdn.com", driver.find_element_by_xpath("//table[@id='change_history']/tbody/tr/td[2]").text)
            # Request PAD implementation
            driver.find_element_by_xpath("//input[@value='request implementation']").click()
            time.sleep(1)
            driver.find_element_by_name("stats").click()
            driver.find_element_by_name("checklist").click()
            driver.find_element_by_name("comments").clear()
            driver.find_element_by_name("comments").send_keys("test")
            driver.find_element_by_name("submit").click()
            if g_args_list['BROWSER'] == 'firefox':
                driver.switch_to.parent_frame()
                driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            for i in range(60):
                try:
                    if u"cancel request" == driver.find_element_by_xpath("//input[@value='cancel request']").get_attribute("value"): break
                except: pass
                time.sleep(1)
                driver.switch_to.parent_frame()
                driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            else: self.fail("time out")
            time.sleep(10)
            for i in range(60):
                try:
                    if u'Your PAD implementation request has been submitted.\nIf the PAD must be implemented immediately, please click the Request support link (at left) and submit an urgent Support Request, which will notify an on-call engineer who can process the PAD implementation.\nOtherwise, your request will be processed by the end of the current business day (during the week), or next business day (if submitted during weekday evenings or weekends. Typically PAD implementation requests are filled within 2 hours during business hours.' == driver.find_element_by_xpath("//div[@id='messages']/ul/li").text: break
                except: pass
                time.sleep(1)
                driver.switch_to.parent_frame()
                driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            else: self.fail("time out")
            # validation in OUI
            self.push_to_staging_oui(driver)
            self.clear_aurora(driver)

        # Access denied
        elif g_args_list['USER']=='tst_no_piv@jimdo.cdn.com' or g_args_list['USER']=='test_ca_view_only_priv@jimdo.cdn.com' or g_args_list['USER']=='tst_ca_edit_priv@jimdo.cdn.com':
            ## DWA menu
            driver = self.driver
            driver.get(AURORA_URL + "/cui/int/pads/add/?m=202")
            time.sleep(3)
            ## Access Denied
            for i in range(60):
                try:
                    if "Error 403" == driver.find_element_by_css_selector("h1.pa-title").text: break
                except: pass
                time.sleep(1)
            else: self.fail("time out")
            try:
                if "Add new PAD" ==  driver.find_element_by_link_text("Add new PAD").text:
                    self.fail("Exist Add new PAD menu")
            except: pass

        else: raise Exception("No matched account.")

    @logmethod
    def clear_aurora(self, driver):
        ### Clear
        self.pad_name = 'selenium-noself.com'
        driver.get(AURORA_URL + "/cui/int/pads/?m=202")
        time.sleep(1)
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        driver.find_element_by_link_text(self.pad_name).click()
        for i in range(60):
            try:
                if "cancel request" == driver.find_element_by_css_selector("input[type=\"submit\"]").get_attribute("value"): break
            except: pass
            time.sleep(1)
        else: self.fail("time out")
        driver.find_element_by_css_selector("input[type=\"submit\"]").click()
        time.sleep(3)
        driver.find_element_by_name("comments").clear()
        time.sleep(1)
        driver.find_element_by_name("comments").send_keys("cancelled")
        driver.find_element_by_name("submit").click()
        if g_args_list['BROWSER'] == 'firefox':
            time.sleep(25)
        else: time.sleep(35)
        # it needs to show delete link
        driver.refresh()
        driver.get(AURORA_URL + "/cui/int/pads/?m=202")
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))

        if g_args_list['BROWSER'] == 'safari' or g_args_list['BROWSER'] == 'chrome':
            driver.execute_script("window.confirm = function() { return true; }")
            driver.find_element_by_css_selector("a[data-delete='"+self.pad_name+"']").click()
        else:
            time.sleep(3)
            driver.find_element_by_link_text("delete").click()
            driver.switch_to_alert().accept()
        driver.save_screenshot('img/result/'+g_args_list['BROWSER']+'_'+g_args_list['USER']+'_'+ __file__.strip('.py')+'-add-result.png')
    
if __name__ == '__main__':
    global g_args_list
    g_args_list = handle_args(sys.argv)
    unittest.main()
