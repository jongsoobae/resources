#!/usr/bin/python
#-*-encoding: utf-8-*-

## SELENIUM MODUES
from selenium.webdriver.support.ui import Select
from selenium import webdriver
from sikuli import *

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IMAGE_PATH = BASE_DIR + '/img/org'

PRV_IMAGE = 'ff_basic.png'
ERR_IMAGE = 'ff_basic-error.png'


exists(PRV_IMAGE)
exists(ERR_IMAGE)
