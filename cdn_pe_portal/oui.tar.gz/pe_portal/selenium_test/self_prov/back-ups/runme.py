#!/bin/env python

import os
import glob
import logging
from subprocess import PIPE, Popen

files = glob.glob('./*.py')
# set logging env
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s',
                    datefmt='%Y-%m-%d %H:%M',
                    filename='%s'%("/tmp/validate_config.log"),
                    filemode='w'
                    )

formatter = logging.Formatter('%(message)s')
importlogger = logging.getLogger(__name__)
importlogger.setLevel(logging.INFO)
__DEF_WIDTH__ = 80

def getTerminalSize():
   import platform
   current_os = platform.system()
   tuple_xy = None
   if current_os == 'Windows':
       tuple_xy = _getTerminalSize_windows()
       if tuple_xy is None:
          tuple_xy = _getTerminalSize_tput()
          # needed for window's python in cygwin's xterm!
   if current_os == 'Linux' or current_os == 'Darwin' or  current_os.startswith('CYGWIN'):
       tuple_xy = _getTerminalSize_linux()
   if tuple_xy is None:
       print "default"
       tuple_xy = (80, 25)      # default value
   return tuple_xy

def _getTerminalSize_windows():
    res = None
    try:
        from ctypes import windll, create_string_buffer

        # stdin handle is -10
        # stdout handle is -11
        # stderr handle is -12

        h = windll.kernel32.GetStdHandle(-12)
        csbi = create_string_buffer(22)
        res = windll.kernel32.GetConsoleScreenBufferInfo(h, csbi)
    except:
        return None
    if res:
        import struct
        (bufx, bufy, curx, cury, wattr,
         left, top, right, bottom, maxx, maxy) = struct.unpack("hhhhHhhhhhh", csbi.raw)
        sizex = right - left + 1
        sizey = bottom - top + 1
        return sizex, sizey
    else:
        return None

def _getTerminalSize_tput():
    # get terminal width
    # src: http://stackoverflow.com/questions/263890/how-do-i-find-the-width-height-of-a-terminal-window
    try:
       import subprocess
       proc = subprocess.Popen(["tput", "cols"], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
       output = proc.communicate(input=None)
       cols = int(output[0])
       proc = subprocess.Popen(["tput", "lines"], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
       output = proc.communicate(input=None)
       rows = int(output[0])
       return (cols, rows)
    except:
       return None

def _getTerminalSize_linux():
    def ioctl_GWINSZ(fd):
        try:
            import fcntl, termios, struct, os
            cr = struct.unpack('hh', fcntl.ioctl(fd, termios.TIOCGWINSZ,'1234'))
        except:
            return None
        return cr
    cr = ioctl_GWINSZ(0) or ioctl_GWINSZ(1) or ioctl_GWINSZ(2)
    if not cr:
        try:
            fd = os.open(os.ctermid(), os.O_RDONLY)
            cr = ioctl_GWINSZ(fd)
            os.close(fd)
        except:
            pass
    if not cr:
        try:
            cr = (env['LINES'], env['COLUMNS'])
        except:
            return None
    return int(cr[1]), int(cr[0])

def _get_border(sp='='):
    (width, height) = getTerminalSize()
    if width > __DEF_WIDTH__:
        width = __DEF_WIDTH__
    return '{message:{fill}{align}{width}}'.format(message="",fill=sp,align=">",width=width)

def validate_scripts():
    for scriptName in files:
	sp = _get_border('-')
	scriptName = scriptName.strip('./')
	str_len = len(scriptName)*2
	importlogger.info(sp)
	importlogger.info("[%s] validating......"%(scriptName))
        result = Popen(['python', scriptName], stdin=PIPE, stdout=PIPE).communicate()[0]
	try:
	    result.index('not ok')
            msg = '{message:{fill}{align}{width}}'.format(message="[ \033[1;31mCHECK\033[0m ]", fill='', align=">", width=str_len)
            importlogger.info("%s%s"%(scriptName, msg))
        except:
	    msg = '{message:{fill}{align}{width}}'.format(message="[ \033[1;32mPASSED\033[0m ]",fill='', align=">", width=str_len)
            importlogger.info("%s%s"%(scriptName, msg))

if __name__=="__main__":
	importlogger.info("Start validation SpectrumAPI...")
	console = logging.StreamHandler()
	console.setFormatter(formatter)
	console.setLevel(logging.INFO)
	importlogger.addHandler(console)
	validate_scripts()
	importlogger.info("Testing done...")
		
