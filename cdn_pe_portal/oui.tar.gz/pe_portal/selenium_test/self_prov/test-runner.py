#!/usr/bin/python
#-*-encoding: utf-8-*-

import os
import subprocess as sub

files = [f for f in os.listdir('.') if os.path.isfile(f)]
result = 'test_result'
block_lists = ['CA_PERF_lots_of_PADs.py','CA_Push_interference.py-X_SVN','CA_Push_interference_with_another_customer.py-X_SVN','CA_Push_interference_with_OUI.py-X_SVN']

for f in files:
    if f in block_lists: continue # go back to for loop
    elif f.find('CA') >= 0 and f.find('SSL') < 0:
        cmd = 'python ' + str(f) + ' >> ' + result + ' 2>&1'
        os.system('echo ==================================== [%s] ==================================== >> %s' %(f, result))
        fd = sub.Popen(cmd, shell=True, stdin=sub.PIPE, stdout=sub.PIPE, stderr=sub.PIPE)
        stdout_val, stderr_val = fd.communicate()
    elif f.find('CA') >= 0 and f.find('SSL') >= 0:
        cmd = 'python ' + str(f) + ' test_ca_ssl_add_edit_priv@gala.cdn.com >> ' + result + ' 2>&1'
        os.system('echo ==================================== [%s] ==================================== >> %s' %(f, result))
        fd = sub.Popen(cmd, shell=True, stdin=sub.PIPE, stdout=sub.PIPE, stderr=sub.PIPE)
        stdout_val, stderr_val = fd.communicate()
    elif f.find('DWA') >= 0 and f.find('SSL') < 0:
        cmd = 'python ' + str(f) + ' test_dwa_add_edit_priv@gala.cdn.com >> ' + result + ' 2>&1'
        os.system('echo ==================================== [%s] ==================================== >> %s' %(f, result))
        fd = sub.Popen(cmd, shell=True, stdin=sub.PIPE, stdout=sub.PIPE, stderr=sub.PIPE)
        stdout_val, stderr_val = fd.communicate()
    elif f.find('DWA') >= 0 and f.find('SSL') >= 0:
        cmd = 'python ' + str(f) + ' test_dwa_ssl_add_edit_priv@gala.cdn.com >> ' + result + ' 2>&1'
        os.system('echo ==================================== [%s] ==================================== >> %s' %(f, result))
        fd = sub.Popen(cmd, shell=True, stdin=sub.PIPE, stdout=sub.PIPE, stderr=sub.PIPE)
        stdout_val, stderr_val = fd.communicate()
