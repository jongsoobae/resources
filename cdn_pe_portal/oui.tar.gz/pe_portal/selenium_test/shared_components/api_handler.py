#!/usr/bin/python
#-*-encoding: utf-8-*-

## Path
import time, requests, os, sys, ssl
import json, urllib, urllib2
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)

from selenium_test.config_constants import *
from selenium_test.config_user_constants import *

## Variables
USER = SELF_PROV_USER['USER_WITH_CA_ADD_EDIT_PRIV']
PASS = SELF_PROV_USER['PASSWORD']
global g_session_token
### got a g_session_token
try:
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    request = urllib2.Request(OPENAPI_URL+'/api/rest/login?user='+USER+'&pass='+PASS+'&output=json')
    response = urllib2.urlopen(request, context=ctx)
    result = response.read()
    json_result = json.loads(result)
    g_session_token = json_result['loginResponse']['session']['sessionToken']
except Exception, e:
    raise Exception('Getting global session_token is failed')

def api_login():
    try:
        request = urllib2.Request(OPENAPI_URL+'/api/rest/login?user='+USER+'&pass='+PASS+'&output=json')
        response = urllib2.urlopen(request)
        if response.code != 200: raise Exception('Check your log-in: ' + str(response.code))
        result = response.read()
        json_result = json.loads(result)
        session_token = json_result['loginResponse']['session'][0]['sessionToken']
        return str(session_token)
    except Exception as e:
        raise Exception(str(e))

def api_call(uri, session_token, contents=''):
    try:
        if contents is not '':
            request = urllib2.Request(OPENAPI_URL + uri + '?sessionToken=' + session_token + '&' + contents)
        else:
            request = urllib2.Request(OPENAPI_URL + uri + '?sessionToken=' + session_token)
        response = urllib2.urlopen(request)
        result = response.read()
        return result
    except Exception as e: raise Exception('Calling API is failed: ' + str(e))

def viewing_info_pad(pad_name, api_key, view_uri):
    session_token = g_session_token
    add_pad = dict(apiKey=api_key, pad=pad_name, origin='origin-' + pad_name)
    contents = urllib.urlencode(dict(apiKey=add_pad['apiKey'], pad=pad_name))
    try:
        view_pad_info = api_call(view_uri, session_token, contents)
        view_pad_json = json.loads(view_pad_info)
        return view_pad_json
    except Exception as e:
        raise Exception('Viewing info of a PAD is failed: ' + str(e))

def adding_pad_by_openapi(pad_name, api_key, count, add_uri, product='40000548-10'):
    session_token = g_session_token
    for num in range(1, count):
        add_pad = dict(apiKey=api_key, pad=pad_name+'-'+str(num)+'.cdnetworks.com', origin='origin-'+pad_name+'.cdnetworks.com', product=product)
        contents = urllib.urlencode(add_pad)
        # adding a pad
        try:
            adding_pad_rst = api_call(add_uri, session_token, contents)
            json_result = json.loads(adding_pad_rst)
            add_pad_json = viewing_info_pad(add_pad['pad'], api_key, '/stat/rest/pan/site/view')
            if add_pad_json['PadConfigResponse']['resultCode'] == 200: pass
        except Exception as e:
            raise Exception('Adding a pad is failed: ' + str(e))

# adding_pad_by_pantherapi('test',1446,'k1: CS: Korea','k1: CS: Korea&shielded_service=CS: (Generic) :: n1:: NoShield',product='40000548-10')
def adding_pushed_production_pad_by_pantherapi(pad_name, customer_id, service, shielded_service, product='40000548-10'):
    session_token = g_session_token
    add_pad = dict(pad=pad_name+'-'+str(num)+'.cdnetworks.com',origin='origin-'+pad_name+'.cdnetworks.com',pad_aliases='alias-'+pad_name+'.cdnetworks.com',
                   service=service, shielded_service=shielded_service, customer_id=customer_id, product=product)
    contents = urllib.urlencode(add_pad)
    # adding a pad
    try:
        adding_pad_rst = api_call(add_uri, session_token, contents)
        json_result = json.loads(adding_pad_rst)
        if json_result['status_code'] == 200: pass
    except Exception as e:
        raise Exception('Adding a pad is failed: ' + str(e))

def adding_pad_then_push(pad_name, api_key, count, add_uri):
    session_token = g_session_token
    for num in range(1, count):
        add_pad = dict(apiKey=api_key, pad=pad_name+'-'+str(num)+'.cdnetworks.com', origin='origin-'+pad_name+'.cdnetworks.com', product='40000548-10')
        contents = urllib.urlencode(add_pad)
        # adding a pad
        try:
            adding_pad_rst = api_call(add_uri, session_token, contents)
            json_result = json.loads(adding_pad_rst)
            add_pad_json = viewing_info_pad(add_pad['pad'], api_key, '/stat/rest/pan/site/view')
            if add_pad_json['PadConfigResponse']['resultCode'] == 200: pass
        except Exception as e:
            raise Exception('Adding a pad is failed: ' + str(e))
        # push to staging
        try:
            push_pad_http_sites(add_pad['pad'], api_key, '/stat/rest/pan/site/pushStaging')
        except Exception as e:
            raise Exception('Pushing a pad to staging is failed: ' + str(e))
        # push to production
        try:
            push_pad_http_sites(add_pad['pad'], api_key, '/stat/rest/pan/site/pushProduction')
        except Exception as e:
            raise Exception('Pushing a pad to production is failed: ' + str(e))

def lookup_pad_list(page_uri, api_key):
    session_token = g_session_token
    pad_list = dict(apiKey=api_key)
    contents = urllib.urlencode(pad_list)
    try:
        pad_list_rst = api_call(page_uri, session_token, contents)
        pad_list_json = json.loads(pad_list_rst)
        return pad_list_json
    except Exception as e:
        raise Exception('Lookup pad list is failed: ' + str(e))

def push_pad_http_sites(pad_name, api_key, push_uri):
    session_token = g_session_token
    push_pad_dict = dict(apiKey=api_key, pad=pad_name)
    contents = urllib.urlencode(push_pad_dict)
    try:
        push_pad_rst = api_call(push_uri, session_token, contents)
        json_result = json.loads(push_pad_rst)
        push_pad_json = viewing_info_pad(pad_name, api_key, '/stat/rest/pan/site/view')
        if push_pad_json['PadConfigResponse']['resultCode'] == 200: pass
    except Exception as e:
        raise Exception('Pushing a pad is failed: ' + str(e))

def push_by_prism_api(group, type):
    push_status = dict(user=PRISM_API_USER['username'], config_group=group, config_type=type)
    # for predefined pass
    push_status['pass'] = PRISM_API_USER['password']
    contents = urllib.urlencode(push_status)
    try:
        # get revision from prismapi
        request = urllib2.Request(PRISM_API_URL + 'config/push?' + contents)
        response = urllib2.urlopen(request)
        result = response.read()
        result = json.loads(result)
        if result['status'] == 'OK': pass
        else: raise Exception("Check your PRISM API !!!")
    except Exception as e:
        raise Exception(str(e))

def get_deploy_status(pad_name, api_key):
    try:
        get_deploy_status_json = viewing_info_pad(pad_name, api_key, '/stat/rest/pan/site/view')
        return get_deploy_status_json['PadConfigResponse']['data']['data']['deploy_status']
    except Exception as e:
        raise Exception('Getting a deploy status is failed: ' + str(e))

def status_by_prism_api(group, type):
    version_status = dict(user=PRISM_API_USER['username'], config_group=group, config_type=type)
    # for predefined pass
    version_status['pass'] = PRISM_API_USER['password']
    contents = urllib.urlencode(version_status)
    try:
        # get revision from prismapi
        request = urllib2.Request(PRISM_API_URL + 'config/status?' + contents)
        response = urllib2.urlopen(request)
        result = response.read()
        result = json.loads(result)
        if result['status'] == 'ok': return result
        else: raise Exception("Check your PRISM API !!!")
    except Exception as e:
        raise Exception(str(e))