#!/usr/bin/python
#-*-encoding: utf-8-*-

## Path
import time, sys, os, cv2, json
import urllib2, numpy, threading
from subprocess import Popen, PIPE
from jinja2 import Environment, FileSystemLoader
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)

## Modules
#import unittest, paramiko
#from PIL import Image
#from selenium import webdriver
import urllib
from selenium_test.config_constants import AURORA_URL,SVN_URL,NGPDB_URL, NGPDB_PASS, NGPDB_USER, \
    CDB_URL, CDB_PASS, CDB_USER, PRISM_API_URL, SPECTRUMAPI_URL, SSH_OPG_KEY
from selenium_test.shared_components.decorator import logmethod,catch_exception
from selenium_test.shared_components.api_handler import status_by_prism_api
from selenium_test.shared_components.image_similarity import Image, image_similarity_vectors_via_numpy
from selenium_test.config_user_constants import PRISM_API_USER, SELF_PROV_USER
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys

## DB
import MySQLdb as mdb

## Global variables
PATH = './img/result'
### Push types
class struct(object):
 	    def __init__(self, *args, **kwargs):
	        for k, v in kwargs.items():
 	            setattr(self, k, v)

CONFIG_GROUP_TYPE_FULL_LIST = [
            struct(group='BASE', type='CFGT'),
            struct(group='BASE', type='CFG'),
 	        struct(group='GSLB', type='CFGT'),
 	        struct(group='GSLB', type='CFG'),
            struct(group='CDNS', type='CFGT'),
            struct(group='CDNS', type='CFG'),
 	        struct(group='PROBE', type='CFG'),
 	        struct(group='MPROXY', type='CFG'),
 	        struct(group='STARFS', type='CFG'),
 	        struct(group='CONTENT_DISTRIBUTION', type='CFGT'),
            struct(group='CONTENT_DISTRIBUTION', type='CFG'),
            struct(group='HTTP_SITES', type='CFGT'),
            struct(group='HTTP_SITES', type='CFG'),
            struct(group='DNS', type='CFGT'),
            struct(group='DNS', type='CFGT'),
            struct(group='SYSTEM_LOAD_LIMIT', type='CFGT'),
            struct(group='SYSTEM_LOAD_LIMIT', type='CFG'),
]

############################################     ADD/EDIT     ##########################################################
def add_pad_in_oui(driver, customer_name, pad_name, usr, browser, file):
    for i in range(60):
        try:
            if "local CDNetworks OUI: home" == driver.title: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.find_element_by_id("search_input").click()
    driver.find_element_by_id("search_input").send_keys(customer_name)
    driver.find_element_by_id("search_input").send_keys(Keys.ENTER)
    for i in range(60):
        try:
            if customer_name == driver.find_element_by_link_text(customer_name).text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.find_element_by_link_text(customer_name).click()
    for i in range(60):
        try:
            if "local CDNetworks OUI: customer: " + customer_name == driver.title: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.find_element_by_link_text("Add a PAD for this customer").click()
    for i in range(60):
        try:
            if "Add Site for " + customer_name == driver.find_element_by_css_selector("h1").text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.find_element_by_id("id_pad").clear()
    driver.find_element_by_id("id_pad").send_keys(pad_name)
    driver.find_element_by_id("id_origin").clear()
    driver.find_element_by_id("id_origin").send_keys("origin.cdnetworks.com")
    if file.find('CA') >= 0 and file.find('SSL') < 0:
        Select(driver.find_element_by_id("id_product")).select_by_visible_text("[0040000548-Gala net_GCA] CA REQ")
        Select(driver.find_element_by_id("id_service")).select_by_visible_text("k1: CS: Korea")
        time.sleep(0.5)
        Select(driver.find_element_by_id("id_shielded_service")).select_by_visible_text("CS: (Generic) :: k1:: NoShield - not shielded")
    driver.find_element_by_css_selector("input[type=\"submit\"]").click()
    for i in range(120):
        try:
            if "local CDNetworks OUI: site: " + pad_name == driver.title: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")

def add_pad_with_wrong_conf(driver, pad_name, user, browser, file):
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/add/?m=190")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/add/?m=205")
    time.sleep(3)
    driver.find_element_by_link_text("Add new PAD").click()
    time.sleep(3)
    ### CUI frame
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    for i in range(60):
        try:
            if "Input PAD settings manually" == driver.find_element_by_link_text("Input PAD settings manually").text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.find_element_by_link_text("Input PAD settings manually").click()
    for i in range(60):
        try:
            if "PAD Set Up - 3 Steps" == driver.find_element_by_css_selector("#pad_edit > h2").text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")

    ### Step 1
    driver.find_element_by_id("id_pad").clear()
    driver.find_element_by_id("id_pad").send_keys(pad_name)
    driver.find_element_by_id("id_pad_aliases").clear()
    driver.find_element_by_id("id_pad_aliases").send_keys("alias." + pad_name)
    driver.find_element_by_id("id_origin").clear()
    driver.find_element_by_id("id_origin").send_keys("origin.cdnetworks.com")
    driver.find_element_by_id("id_backup_origin").clear()
    driver.find_element_by_id("id_backup_origin").send_keys("failover." + pad_name)
    if file.find('CA') >= 0 and user.find('gala') >= 0:
        if file.find('SSL') >= 0 and user.find('gala') >= 0:
            Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-30: CA SSL - Global Premium (Self Implementation)")
        else: Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-10: CA - Global Standard (Self Implementation)")
    elif file.find('CA') >= 0 and user.find('pvh') >= 0: Select(driver.find_element_by_id("id_product")).select_by_visible_text("40008969-30: CA - Global Premium (Self Implementation)")
    elif file.find('DWA') >= 0 and user.find('gala') >= 0:
        if file.find('SSL') >= 0 and user.find('gala') >= 0:
           Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-40: DWA SSL - Global Premium (Self Implementation)")
           for i in range(60):
                try:
                    if "Shield location:" == driver.find_element_by_xpath("//tbody[@id='pad_group_edit_pad_Basic']/tr[6]/th").text: break
                except: pass
                time.sleep(1)
           else: raise Exception("time out")
           Select(driver.find_element_by_id("id_shield_location")).select_by_visible_text("Seoul, Korea Republic of")
        else:
            Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-20: DWA - Global Premium (Self Implementation)")
            for i in range(60):
                try:
                    if "Shield location:" == driver.find_element_by_xpath("//tbody[@id='pad_group_edit_pad_Basic']/tr[6]/th").text: break
                except: pass
                time.sleep(1)
            else: raise Exception("time out")
            Select(driver.find_element_by_id("id_shield_location")).select_by_visible_text("Seoul, Korea Republic of")
    driver.find_element_by_id("id_description").clear()
    driver.find_element_by_id("id_description").send_keys("selenium test")
    time.sleep(1)
    driver.find_element_by_link_text("Caching").click()
    driver.find_element_by_link_text("Request & Response").click()
    try:
        if file.find('SSL') >= 0 and file.find('expire_contract') < 0:
            driver.find_element_by_id("id_enable_ssl").click()
    except ValueError: pass
    driver.find_element_by_link_text("Rewrite Rules").click()
    driver.find_element_by_id("id_full_url_rewrite_rules").clear()
    # wrong rewrite rules
    driver.find_element_by_id("id_full_url_rewrite_rules").send_keys("^http://" + pad_name + "/(.html*)")
    driver.find_element_by_link_text("Validation").click()
    driver.find_element_by_link_text("Video/Large File Delivery").click()
    driver.find_element_by_link_text("Misc").click()
    driver.find_element_by_name("submit").click()
    for i in range(80):
        try:
            if "Your settings for " + pad_name + " have been saved." == driver.find_element_by_css_selector("li").text: break
        except: pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else: raise Exception("time out")


@logmethod
def create_a_pad_with_all_items(driver, pad_name, user, browser, file):
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/add/?m=190")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/add/?m=205")
    time.sleep(3)
    driver.find_element_by_link_text("Add new PAD").click()
    time.sleep(3)
    ### CUI frame
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    for i in range(60):
        try:
            if "Input PAD settings manually" == driver.find_element_by_link_text("Input PAD settings manually").text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.find_element_by_link_text("Input PAD settings manually").click()
    for i in range(60):
        try:
            if "PAD Set Up - 3 Steps" == driver.find_element_by_css_selector("#pad_edit > h2").text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")

    ## CA menu
    driver.get(AURORA_URL + "/cui/int/pads/add/?m=190")
    time.sleep(3)
    driver.find_element_by_link_text("Add new PAD").click()
    time.sleep(3)

    ### CUI frame
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    for i in range(60):
        try:
            if "Input PAD settings manually" == driver.find_element_by_link_text("Input PAD settings manually").text: break
        except:
            pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.find_element_by_link_text("Input PAD settings manually").click()
    for i in range(60):
        try:
            if "PAD Set Up - 3 Steps" == driver.find_element_by_css_selector("#pad_edit > h2").text: break
        except:
            pass
        time.sleep(1)
    else: raise Exception("time out")
    ### Step 1
    driver.find_element_by_id("id_pad").clear()
    driver.find_element_by_id("id_pad").send_keys(pad_name)
    driver.find_element_by_id("id_pad_aliases").clear()
    driver.find_element_by_id("id_pad_aliases").send_keys("alias." + pad_name)
    driver.find_element_by_id("id_origin").clear()
    driver.find_element_by_id("id_origin").send_keys("default-origin.cdnetworks.com")
    driver.find_element_by_id("id_backup_origin").clear()
    driver.find_element_by_id("id_backup_origin").send_keys("failover." + pad_name)
    if file.find('CA') >= 0:
        if file.find('SSL') >= 0:
            if file.find('expire_contract') >= 0:
                Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-30: CA SSL - Global Premium (Request Implementation) expired")
            else: Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-30: CA SSL - Global Premium (Self Implementation)")
        elif file.find('expire_contract') >= 0:
            Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-10: CA - Global Standard (Request Implementation) expired")
        elif file.find('another_customer') >= 0:
            Select(driver.find_element_by_id("id_product")).select_by_visible_text("40008969-30: CA - Global Standard (Self Implementation)")
        else: Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-10: CA - Global Standard (Self Implementation)")
    elif file.find('DWA') >= 0:
        if file.find('SSL') >= 0:
            if file.find('expire_contract') >= 0:
                Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-40: DWA SSL - Global Premium (Request Implementation) expired")
            else:
                Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-40: DWA SSL - Global Premium (Self Implementation)")
                for i in range(60):
                    try:
                        if "Shield location:" == driver.find_element_by_xpath("//tbody[@id='pad_group_edit_pad_Basic']/tr[6]/th").text: break
                    except: pass
                    time.sleep(1)
                else: raise Exception("time out")
                Select(driver.find_element_by_id("id_shield_location")).select_by_visible_text("Seoul, Korea Republic of")
        elif file.find('expire_contract') >= 0:
            Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-20: DWA - Global Premium (Request Implementation) expired")
        else:
            Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-20: DWA - Global Premium (Self Implementation)")
            for i in range(60):
                try:
                    if "Shield location:" == driver.find_element_by_xpath("//tbody[@id='pad_group_edit_pad_Basic']/tr[6]/th").text: break
                except: pass
                time.sleep(1)
            else: raise Exception("time out")
            Select(driver.find_element_by_id("id_shield_location")).select_by_visible_text("Seoul, Korea Republic of")
    driver.find_element_by_id("id_description").clear()
    driver.find_element_by_id("id_description").send_keys("selenium test")
    time.sleep(1)
    driver.find_element_by_link_text("Caching").click()
    driver.find_element_by_id("id_strict_nocache_support").click()
    driver.find_element_by_id("id_min_age").clear()
    driver.find_element_by_id("id_min_age").send_keys("60")
    driver.find_element_by_id("id_default_last_modified_date").clear()
    driver.find_element_by_id("id_default_last_modified_date").send_keys("2015-12-25")
    driver.find_element_by_id("id_force_not_modified_on_ims").clear()
    driver.find_element_by_id("id_force_not_modified_on_ims").send_keys("1")
    driver.find_element_by_id("id_force_maxage_on_40x").clear()
    driver.find_element_by_id("id_force_maxage_on_40x").send_keys("1")
    driver.find_element_by_id("id_default_max_age").clear()
    driver.find_element_by_id("id_default_max_age").send_keys("60")
    driver.find_element_by_id("id_max_age_rules").clear()
    driver.find_element_by_id("id_max_age_rules").send_keys("^/.*\\.jpg 86400")
    driver.find_element_by_id("id_content_variation_rules").clear()
    driver.find_element_by_id("id_content_variation_rules").send_keys("^/.*\\.html %cgender")
    driver.find_element_by_link_text("Request & Response").click()
    driver.find_element_by_id("id_origin_ip").clear()
    driver.find_element_by_id("id_origin_ip").send_keys("10.10.10.1")
    driver.find_element_by_id("id_origin_port").clear()
    driver.find_element_by_id("id_origin_port").send_keys("777")
    driver.find_element_by_id("id_origin_host_header").clear()
    driver.find_element_by_id("id_origin_host_header").send_keys("test.com")
    driver.find_element_by_id("id_use_pad_as_host_header").click()
    driver.find_element_by_id("id_custom_headers").clear()
    driver.find_element_by_id("id_custom_headers").send_keys("X-Foo: bar")
    driver.find_element_by_id("id_origin_failure_redirect_url").clear()
    driver.find_element_by_id("id_origin_failure_redirect_url").send_keys("1")
    driver.find_element_by_id("id_use_origin_multiple_dns_record").click()
    driver.find_element_by_id("id_use_origin_sticky").click()
    driver.find_element_by_id("id_honor_multi_byte_range").click()
    driver.find_element_by_id("id_max_requests_per_keep_alive").clear()
    driver.find_element_by_id("id_max_requests_per_keep_alive").send_keys("50")
    driver.find_element_by_id("id_pass_thru_headers_to_origin").clear()
    driver.find_element_by_id("id_pass_thru_headers_to_origin").send_keys("X-Test: selenium")
    driver.find_element_by_id("id_accept_setting_from_query_string").click()
    driver.find_element_by_id("id_honor_path_range").click()
    driver.find_element_by_id("id_reverse_proxy_redirect").click()
    driver.find_element_by_id("id_follow_redirect").click()
    driver.find_element_by_id("id_pass_thru_headers_to_user").clear()
    driver.find_element_by_id("id_pass_thru_headers_to_user").send_keys("X-Test: selenium")
    driver.find_element_by_id("id_deny_direct_user_request").click()
    driver.find_element_by_id("id_cookie_exchange").click()
    driver.find_element_by_link_text("Rewrite Rules").click()
    driver.find_element_by_id("id_case_insensitive_urls").click()
    driver.find_element_by_id("id_drop_params").click()
    driver.find_element_by_id("id_rewrite_rules").clear()
    driver.find_element_by_id("id_rewrite_rules").send_keys("^/(.*\\.html)/rewritten?=url=$1")
    driver.find_element_by_id("id_drop_params_post_validation").click()
    driver.find_element_by_id("id_rewrite_rules_post_validation").clear()
    driver.find_element_by_id("id_rewrite_rules_post_validation").send_keys("^/(.*\\.html)/rewritten?=url=$1")
    driver.find_element_by_id("id_drop_precise_params_post_validation").clear()
    driver.find_element_by_id("id_drop_precise_params_post_validation").send_keys("string")
    driver.find_element_by_id("id_drop_params_in_cache_url").click()
    driver.find_element_by_id("id_drop_precise_params_in_cache_url").clear()
    driver.find_element_by_id("id_drop_precise_params_in_cache_url").send_keys("test")
    driver.find_element_by_id("id_full_url_rewrite_rules").clear()
    driver.find_element_by_id("id_full_url_rewrite_rules").send_keys("^http://qatest.selenium.com/(.html*)")
    driver.find_element_by_link_text("Validation").click()
    driver.find_element_by_id("id_referrer_list").clear()
    driver.find_element_by_id("id_referrer_list").send_keys("^https?://[a-zA-Z0-9._-]*\\.panthercustomer\\.com/.*")
    Select(driver.find_element_by_id("id_referrer_list_type")).select_by_visible_text("Whitelist")
    driver.find_element_by_id("id_failed_referrer_check_redirect_url").clear()
    driver.find_element_by_id("id_failed_referrer_check_redirect_url").send_keys("test.com")
    Select(driver.find_element_by_id("id_validation_scheme")).select_by_visible_text("Origin Logic Control")
    driver.find_element_by_id("id_bypass_validation_on_failure").click()
    driver.find_element_by_id("id_validation_default_redirect_url").clear()
    driver.find_element_by_id("id_validation_default_redirect_url").send_keys("test.com")
    driver.find_element_by_id("id_validation_custom_headers").clear()
    driver.find_element_by_id("id_validation_custom_headers").send_keys("X-Foo: Bar")
    driver.find_element_by_id("id_validation_nobypass_redirect_url").clear()
    driver.find_element_by_id("id_validation_nobypass_redirect_url").send_keys("test.com")
    driver.find_element_by_id("id_http_auth_user").clear()
    driver.find_element_by_id("id_http_auth_user").send_keys("hhh1@gala.com")
    driver.find_element_by_id("id_http_auth_password").clear()
    driver.find_element_by_id("id_http_auth_password").send_keys("cdnadmin")
    driver.find_element_by_id("id_tag_check_enabled").click()
    driver.find_element_by_id("id_tag_hash_format_preset").clear()
    driver.find_element_by_id("id_tag_hash_format_preset").send_keys("1")
    driver.find_element_by_id("id_tag_hash_format").clear()
    driver.find_element_by_id("id_tag_hash_format").send_keys("1")
    driver.find_element_by_id("id_tag_hash_param").clear()
    driver.find_element_by_id("id_tag_hash_param").send_keys("px-hash")
    driver.find_element_by_id("id_tag_secret").clear()
    driver.find_element_by_id("id_tag_secret").send_keys("1234")
    driver.find_element_by_id("id_tag_time_param").clear()
    driver.find_element_by_id("id_tag_time_param").send_keys("px-time")
    driver.find_element_by_id("id_tag_time_allowed_sec").clear()
    driver.find_element_by_id("id_tag_time_allowed_sec").send_keys("1")
    driver.find_element_by_id("id_tag_time_offset_sec").clear()
    driver.find_element_by_id("id_tag_time_offset_sec").send_keys("1")
    driver.find_element_by_id("id_tag_skip_patterns").clear()
    driver.find_element_by_id("id_tag_skip_patterns").send_keys("^/cross-domain\\.xml")
    driver.find_element_by_link_text("Video/Large File Delivery").click()
    driver.find_element_by_id("id_bps_streaming_limit").clear()
    driver.find_element_by_id("id_bps_streaming_limit").send_keys("1")
    driver.find_element_by_id("id_buffer_secs").clear()
    driver.find_element_by_id("id_buffer_secs").send_keys("1")
    driver.find_element_by_id("id_progressive_dl").click()
    driver.find_element_by_id("id_progressive_dl_param").clear()
    driver.find_element_by_id("id_progressive_dl_param").send_keys("start")
    Select(driver.find_element_by_id("id_pdseek_default_type")).select_by_visible_text("h264")
    driver.find_element_by_id("id_pdseek_flv_extensions").clear()
    driver.find_element_by_id("id_pdseek_flv_extensions").send_keys("flv")
    driver.find_element_by_id("id_pdseek_h264_extensions").clear()
    driver.find_element_by_id("id_pdseek_h264_extensions").send_keys("mp4,m4v")
    driver.find_element_by_link_text("Misc").click()
    driver.find_element_by_name("submit").click()
    for i in range(60):
        try:
            if "Your settings for " + pad_name + " have been saved." == driver.find_element_by_css_selector("li").text: break
        except:
            pass
        time.sleep(1)
    else: raise Exception("time out")

def create_ca_pad(driver, pad_name, user, browser, file):
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/add/?m=190")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/add/?m=205")
    time.sleep(3)
    driver.find_element_by_link_text("Add new PAD").click()
    time.sleep(3)
    ### CUI frame
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    for i in range(60):
        try:
            if "Input PAD settings manually" == driver.find_element_by_link_text("Input PAD settings manually").text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.find_element_by_link_text("Input PAD settings manually").click()
    for i in range(60):
        try:
            if "PAD Set Up - 3 Steps" == driver.find_element_by_css_selector("#pad_edit > h2").text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")

    ### Step 1
    driver.find_element_by_id("id_pad").clear()
    driver.find_element_by_id("id_pad").send_keys(pad_name)
    driver.find_element_by_id("id_pad_aliases").clear()
    driver.find_element_by_id("id_pad_aliases").send_keys("alias." + pad_name)
    driver.find_element_by_id("id_origin").clear()
    driver.find_element_by_id("id_origin").send_keys("origin.cdnetworks.com")
    driver.find_element_by_id("id_backup_origin").clear()
    driver.find_element_by_id("id_backup_origin").send_keys("failover." + pad_name)
    if file.find('CA') >= 0:
        time.sleep(0.5)
        if file.find('SSL') >= 0:
            if file.find('expire_contract') >= 0:
                Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-30: CA SSL - Global Premium (Request Implementation) expired")
            else: Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-30: CA SSL - Global Premium (Self Implementation)")
        elif file.find('expire_contract') >= 0:
            Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-10: CA - Global Standard (Request Implementation) expired")
        elif file.find('another_customer') >= 0 or file.find('PERF') >= 0:
            Select(driver.find_element_by_id("id_product")).select_by_visible_text("40008969-30: CA - Global Premium (Self Implementation)")
        else: Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-10: CA - Global Standard (Self Implementation)")
    elif file.find('DWA') >= 0:
        time.sleep(0.5)
        if file.find('SSL') >= 0:
            if file.find('expire_contract') >= 0:
                Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-40: DWA SSL - Global Premium (Request Implementation) expired")
            else:
                Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-40: DWA SSL - Global Premium (Self Implementation)")
                for i in range(60):
                    try:
                        if "Shield location:" == driver.find_element_by_xpath("//tbody[@id='pad_group_edit_pad_Basic']/tr[6]/th").text: break
                    except: pass
                    time.sleep(1)
                else: raise Exception("time out")
                Select(driver.find_element_by_id("id_shield_location")).select_by_visible_text("Seoul, Korea Republic of")
        elif file.find('expire_contract') >= 0:
            Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-20: DWA - Global Premium (Request Implementation) expired")
        else:
            Select(driver.find_element_by_id("id_product")).select_by_visible_text("40000548-20: DWA - Global Premium (Self Implementation)")
            for i in range(60):
                try:
                    if "Shield location:" == driver.find_element_by_xpath("//tbody[@id='pad_group_edit_pad_Basic']/tr[6]/th").text: break
                except: pass
                time.sleep(1)
            else: raise Exception("time out")
            Select(driver.find_element_by_id("id_shield_location")).select_by_visible_text("Seoul, Korea Republic of")
    driver.find_element_by_id("id_description").clear()
    driver.find_element_by_id("id_description").send_keys("selenium test")
    time.sleep(1)
    driver.find_element_by_link_text("Caching").click()
    driver.find_element_by_link_text("Request & Response").click()
    try:
        if file.find('SSL') >= 0 and file.find('expire_contract') < 0:
            driver.find_element_by_id("id_enable_ssl").click()
    except ValueError: pass
    driver.find_element_by_link_text("Rewrite Rules").click()
    driver.find_element_by_id("id_full_url_rewrite_rules").clear()
    driver.find_element_by_link_text("Validation").click()
    driver.find_element_by_link_text("Video/Large File Delivery").click()
    driver.find_element_by_link_text("Misc").click()
    """ deleted on bc185780b1af5d7f050564831c1dc7aed3bd5494
    ### Step 2
    driver.find_element_by_id("id_url_test").clear()
    driver.find_element_by_id("id_url_test").send_keys("origin.cdnetworks.com/index.html")
    Select(driver.find_element_by_id("id_mbps_avg")).select_by_visible_text("1-20 Mbps")
    Select(driver.find_element_by_id("id_mbps_peak")).select_by_visible_text("1-20 Mbps")
    Select(driver.find_element_by_id("id_rps_avg")).select_by_visible_text("1 - 2,500")
    Select(driver.find_element_by_id("id_rps_peak")).select_by_visible_text("1 - 2,500")
    driver.find_element_by_link_text("Files").click()
    driver.find_element_by_id("id_files_type").clear()
    driver.find_element_by_id("id_files_type").send_keys("jpg")
    driver.find_element_by_id("id_files_count").clear()
    driver.find_element_by_id("id_files_count").send_keys("1000")
    driver.find_element_by_id("id_files_size_avg").clear()
    driver.find_element_by_id("id_files_size_avg").send_keys("12400")
    Select(driver.find_element_by_id("id_files_size_max")).select_by_visible_text("0-1 MB")
    driver.find_element_by_link_text("Usage").click()
    driver.find_element_by_link_text("Comments").click()
    driver.find_element_by_id("id_misc_comment").clear()
    driver.find_element_by_id("id_misc_comment").send_keys("by selenium test")"""
    driver.find_element_by_name("submit").click()
    if file.find('CA') >= 0:
        if file.find('expire_contract') >= 0:
            for i in range(60):
                try:
                    if "Product is expired. If you want to proceed, please contact support center." == driver.find_element_by_css_selector("tr.row2 > td > ul.errorlist > li").text: break
                except: pass
                time.sleep(1)
                driver.switch_to.parent_frame()
                driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            else: raise Exception("time out")
        else:
            for i in range(80):
                try:
                    if "Your settings for " + pad_name + " have been saved." == driver.find_element_by_css_selector("li").text: break
                except: pass
                time.sleep(1)
            else: raise Exception("time out")
    elif file.find('DWA') >= 0:
        if file.find('expire_contract') >= 0:
            for i in range(60):
                try:
                    if "Product is expired. If you want to proceed, please contact support center." == driver.find_element_by_css_selector("tr.row1 > td > ul.errorlist > li").text: break
                except: pass
                time.sleep(1)
                driver.switch_to.parent_frame()
                driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
            else: raise Exception("time out")
        else:
            for i in range(80):
                try:
                    if "Your settings for " + pad_name + " have been saved." == driver.find_element_by_css_selector("li").text: break
                except: pass
                time.sleep(1)
            else: raise Exception("time out")

@logmethod
@catch_exception(author="hyunhwa.hong")
def create_request_pad(driver, pad_name, user, browser, file):
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/add/?m=190")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/add/?m=205")
    time.sleep(3)
    driver.find_element_by_link_text("Add new PAD").click()
    time.sleep(3)

    ### CUI frame
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    for i in range(60):
        try:
            if "Input PAD settings manually" == driver.find_element_by_link_text("Input PAD settings manually").text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.find_element_by_link_text("Input PAD settings manually").click()
    for i in range(60):
        try:
            if "PAD Set Up - 3 Steps" == driver.find_element_by_css_selector("#pad_edit > h2").text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")

    ### Step 1
    driver.find_element_by_id("id_pad").clear()
    driver.find_element_by_id("id_pad").send_keys(pad_name)
    driver.find_element_by_id("id_pad_aliases").clear()
    driver.find_element_by_id("id_pad_aliases").send_keys("alias." + pad_name)
    driver.find_element_by_id("id_origin").clear()
    driver.find_element_by_id("id_origin").send_keys("origin.cdnetworks.com")
    driver.find_element_by_id("id_backup_origin").clear()
    driver.find_element_by_id("id_backup_origin").send_keys("failover." + pad_name)
    driver.find_element_by_id("id_description").clear()
    driver.find_element_by_id("id_description").send_keys("selenium test")
    time.sleep(1)
    driver.find_element_by_link_text("Caching").click()
    driver.find_element_by_link_text("Request & Response").click()
    driver.find_element_by_link_text("Rewrite Rules").click()
    driver.find_element_by_id("id_full_url_rewrite_rules").clear()
    driver.find_element_by_link_text("Validation").click()
    driver.find_element_by_link_text("Video/Large File Delivery").click()
    driver.find_element_by_link_text("Misc").click()

    ### Step 2
    driver.find_element_by_id("id_url_test").clear()
    driver.find_element_by_id("id_url_test").send_keys("origin.cdnetworks.com/index.html")
    Select(driver.find_element_by_id("id_mbps_avg")).select_by_visible_text("1-20 Mbps")
    Select(driver.find_element_by_id("id_mbps_peak")).select_by_visible_text("1-20 Mbps")
    Select(driver.find_element_by_id("id_rps_avg")).select_by_visible_text("1 - 2,500")
    Select(driver.find_element_by_id("id_rps_peak")).select_by_visible_text("1 - 2,500")
    driver.find_element_by_link_text("Files").click()
    driver.find_element_by_id("id_files_type").clear()
    driver.find_element_by_id("id_files_type").send_keys("jpg")
    driver.find_element_by_id("id_files_count").clear()
    driver.find_element_by_id("id_files_count").send_keys("1000")
    driver.find_element_by_id("id_files_size_avg").clear()
    driver.find_element_by_id("id_files_size_avg").send_keys("12400")
    Select(driver.find_element_by_id("id_files_size_max")).select_by_visible_text("0-1 MB")
    driver.find_element_by_link_text("Usage").click()
    driver.find_element_by_link_text("Comments").click()
    driver.find_element_by_id("id_misc_comment").clear()
    driver.find_element_by_id("id_misc_comment").send_keys("by selenium test")
    driver.find_element_by_name("submit").click()
    for i in range(80):
        try:
            if "Your settings for " + pad_name + " have been saved." == driver.find_element_by_css_selector("li").text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")

@logmethod
def db_query(db, type, *argv):
    try:
        if db == 'NGPDB':
            db_handler = mdb.connect(NGPDB_URL, NGPDB_USER, NGPDB_PASS, 'spectrum')
        elif db == 'CDB':
            db_handler =  mdb.connect(CDB_URL, CDB_USER, CDB_PASS, 'centraldb')
        db_cursor = db_handler.cursor()
        if type == 'select':
            for query in argv:
                db_cursor.execute(query)
            db_result = db_cursor.fetchone()
            if isinstance(db_result[0], int): return int(db_result[0])
            else: return db_result[0]
        elif type == 'update':
            for query in argv:
                db_cursor.execute(query)
                db_handler.commit()
        db_cursor.close()
        db_handler.close()
    except Exception as e:
        raise Exception(str(e))

def edit_ca_pad(driver, pad_name, user, browser, file):
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/?m=217")
    for i in range(60):
        try:
            if "Customer" == driver.find_element_by_css_selector("h2.se-title > span").text: break
        except:
            pass
        time.sleep(1)
    else: raise Exception("time out")
    if browser != 'firefox': time.sleep(1)
    driver.switch_to.parent_frame()
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    driver.find_element_by_link_text(pad_name).click()
    for i in range(60):
        try:
            if "Change history" == driver.find_element_by_xpath("//h2[4]").text or \
                "Change history" == driver.find_element_by_xpath("//h2[5]").text: break # when push to staging and then edit
        except: pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else: raise Exception("time out")
    for i in range(60):
        try:
            if "Push history" == driver.find_element_by_xpath("//h2[5]").text or \
                "Push history" == driver.find_element_by_xpath("//h2[6]").text: break # when push to staging and then edit
        except: pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else: raise Exception("time out")
    driver.find_element_by_css_selector("input[type=\"submit\"]").click()
    # wait for editable mode
    for i in range(60):
        try:
            if "Leave comment in request if required" == driver.find_element_by_css_selector("i").text: break
        except: pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else: raise Exception("time out")
    # no ways to stop the loading
    if browser == 'firefox':
        time.sleep(10)
    else: time.sleep(15)
    for i in range(60):
        try:
            driver.find_element_by_id("id_pad_aliases").clear()
            # except means id_pad_aliases is NOT editable
        except: pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        # if not exception? it's okay.
        break
    else: raise Exception("time out")
    driver.switch_to.parent_frame()
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    driver.find_element_by_id("id_pad_aliases").clear()
    driver.find_element_by_id("id_pad_aliases").send_keys("restore." + pad_name)
    driver.find_element_by_id("id_backup_origin").clear()
    driver.find_element_by_id("id_backup_origin").send_keys("restore." + pad_name)
    time.sleep(0.5)
    driver.find_element_by_id("id_status").click()
    time.sleep(0.5)
    driver.find_element_by_id("id_description").clear()
    driver.find_element_by_id("id_description").send_keys("selenium restore test")
    driver.find_element_by_link_text("Request & Response").click()
    driver.find_element_by_id("id_gzip_compression").click()
    driver.find_element_by_name("submit").click()
    if file.find('expire_contract') >= 0:
        for i in range(60):
            try:
                try:
                    if "Product is expired. If you want to proceed, please contact support center." == driver.find_element_by_css_selector("tr.row1 > td > ul.errorlist > li").text: break
                except NoSuchElementException:
                    if "Product is expired. If you want to proceed, please contact support center." == driver.find_element_by_css_selector("tr.row2 > td > ul.errorlist > li").text: break
            except: pass
            time.sleep(1)
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        else: raise Exception("time out")
    else:
        for i in range(60):
            try:
                if "Your settings for " + pad_name + " have been saved." == driver.find_element_by_css_selector("li").text: break
            except: pass
            time.sleep(1)
        else: raise Exception("time out")

@logmethod
@catch_exception(author="hyunhwa.hong")
def expire_contract_and_then_eidt_a_pad_in_oui(customer_name, pad_name, user, browser, file):
    from selenium_test.shared_components.login import *
    driver = webdriver.Firefox()
    oui_login(driver)
    for i in range(60):
        try:
            if "local CDNetworks OUI: home" == driver.title: break
        except:
            pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.find_element_by_id("search_input").click()
    driver.find_element_by_id("search_input").send_keys(customer_name)
    driver.find_element_by_id("search_input").send_keys(Keys.ENTER)
    for i in range(60):
        try:
            if customer_name == driver.find_element_by_link_text(customer_name).text: break
        except:
            pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.find_element_by_link_text(customer_name).click()
    for i in range(60):
        try:
            if "local CDNetworks OUI: customer: " + customer_name == driver.title: break
        except:
            pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.find_element_by_link_text(pad_name).click()
    for i in range(60):
        try:
            if "local CDNetworks OUI: site: " + pad_name == driver.title: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    ## editting is NOT successful
    driver.find_element_by_css_selector("th.separator > a").click()
    time.sleep(1)
    Select(driver.find_element_by_id("id_service")).select_by_visible_text("n1: CS: Global Business")
    time.sleep(0.5)
    Select(driver.find_element_by_id("id_shielded_service")).select_by_visible_text("CS: (Generic) :: n1:: NoShield - not shielded")
    driver.find_element_by_id("id_backup_origin").clear()
    driver.find_element_by_id("id_backup_origin").send_keys("failover-changed."+pad_name)
    if file.find('SSL') >= 0:
        driver.find_element_by_id("expand_all").click()
        driver.find_element_by_id("id_enable_ssl").click()
    driver.find_element_by_css_selector("input[type=\"submit\"]").click()
    for i in range(60):
        try:
            if "this product is inactive." == driver.find_element_by_css_selector("ul.errorlist > li").text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    ## inactive is successful
    driver.find_element_by_id("id_status").click()
    Select(driver.find_element_by_id("id_shielded_service")).select_by_visible_text("CS: (Generic) :: n1:: NoShield - not shielded")
    driver.find_element_by_css_selector("input[type=\"submit\"]").click()
    for i in range(60):
        try:
            if "local CDNetworks OUI: site: " + pad_name == driver.title: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    ## inactive and editting is successful
    driver.find_element_by_css_selector("th.separator > a").click()
    driver.find_element_by_id("id_backup_origin").clear()
    driver.find_element_by_id("id_backup_origin").send_keys("failover-changed."+pad_name)
    driver.find_element_by_css_selector("input[type=\"submit\"]").click()
    for i in range(60):
        try:
            if "local CDNetworks OUI: site: " + pad_name == driver.title: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    ## active is NOT successful
    driver.find_element_by_css_selector("th.separator > a").click()
    time.sleep(1)
    driver.find_element_by_id("id_status").click()
    driver.find_element_by_css_selector("input[type=\"submit\"]").click()
    for i in range(60):
        try:
            if "this product is inactive." == driver.find_element_by_css_selector("ul.errorlist > li").text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.quit()

def get_revision_from_svn_by_prismapi(group, type):
    push_status = dict(user=PRISM_API_USER['username'],config_group=group,config_type=type)
    # for predefined pass
    push_status['pass'] = PRISM_API_USER['password']
    contents = urllib.urlencode(push_status)
    try:
        # get revision from prismapi
        request = urllib2.Request(PRISM_API_URL + 'config/status?' + contents)
        response = urllib2.urlopen(request)
        result = response.read()
        result = json.loads(result)
        if result['status'] == 'ok': return result['data'][1]['config_revision']
        else: raise Exception("Check your PRISM API")
    except Exception as e: raise Exception(str(e))

@logmethod
def get_svn_diff_data(group, type, old_rev, new_rev):
    try:
        # check your local svn
        svn_check = Popen(['svn', 'help'],stdout=PIPE,stderr=PIPE,shell=True)
        (stdout, stderr) = svn_check.communicate()
        if stderr.find('svn') > 0: pass
        else: raise Exception("Please install svn")
        # get svn diff data
        svn_diff = Popen(['svn', 'diff', '-r', str(old_rev)+':'+str(new_rev), SVN_URL+group+'_'+type],stdout=PIPE,stderr=PIPE)
        (stdout, stderr) = svn_diff.communicate()
        return stdout
    except Exception as e:
        raise Exception(str(e))

def get_svn_version(group, type):
    try:
        svn_check = Popen(['svn', 'help'], stdout=PIPE, stderr=PIPE, shell=True)
        (stdout, stderr) = svn_check.communicate()
        if stderr.find('svn') > 0: pass
        else: raise Exception("Please install svn")
        # get svn version
        cmd = "svn info " + SVN_URL + group + '_' + type + "| grep Revision"
        svn_versions = Popen(cmd, shell=True, stdout=PIPE, stderr=PIPE)
        output = svn_versions.communicate()[0]
        output = output.strip('\n').split(': ')[1]
        return output
    except Exception as e:
        raise Exception(str(e))

def get_svn_all_versions():
    version_list = {} # dict
    group_type_list = CONFIG_GROUP_TYPE_FULL_LIST
    try:
        for group_type in group_type_list:
            group = group_type.group
            type = group_type.type
            # check your local svn
            svn_check = Popen(['svn', 'help'],stdout=PIPE,stderr=PIPE,shell=True)
            (stdout, stderr) = svn_check.communicate()
            if stderr.find('svn') > 0: pass
            else: raise Exception("Please install svn")
            # get svn version
            cmd = "svn info "+SVN_URL+group+'_'+type+"| grep Revision"
            svn_versions = Popen(cmd, shell=True, stdout=PIPE,stderr=PIPE)
            output = svn_versions.communicate()[0]
            output = output.strip('\n').split(': ')[1]
            version_list[group+'_'+type] = output
        return version_list
    except Exception as e:
        raise Exception(str(e))

"""argv:
    Others must be NOT changed except for this
"""
def diff_svn_all_versions(old_svn_all_versions, new_svn_all_versions, *argv):
    group_type_list = CONFIG_GROUP_TYPE_FULL_LIST
    try:
        for excepted_arg in argv:
            del old_svn_all_versions[excepted_arg]
            del new_svn_all_versions[excepted_arg]
        if old_svn_all_versions == new_svn_all_versions: pass
        else: raise Exception('old_svn_all_versions=\n'+old_svn_all_versions+'\nnew_svn_all_versions=\n'+new_svn_all_versions)
    except Exception as e:
        raise Exception(str(e))

def get_svn_all_versions_by_prismapi():
    version_list = {} # dict
    group_type_list = CONFIG_GROUP_TYPE_FULL_LIST
    for group_type in group_type_list:
        group = group_type.group
        type = group_type.type
        result = status_by_prism_api(group, type)
        if result['data'][0]['config_revision'] is None: version_list[group+'_'+type] = 0 # Never pushed? It returns null
        else:
            version_list[group + '_' + type] = result['data'][0]['config_revision']
    return version_list

def get_customer_site_id_from_cdb(*argv):
    site_id_list = []
    try:
        CDB = mdb.connect(CDB_URL, CDB_USER, CDB_PASS, 'centraldb')
        get_cursor = CDB.cursor()
        for pad_name in argv:
            get_cursor.execute("SELECT customer_site_id FROM customer_site WHERE serve_domain = '%s'" % (pad_name))
            get_result = get_cursor.fetchone()
            site_id_list.append(int(get_result[0]))
        get_cursor.close()
        CDB.close()
        return site_id_list
    except Exception as e:
        raise Exception(str(e))

def get_customer_site_stage_id_from_cdb(*argv):
    site_id_list = []
    try:
        CDB = mdb.connect(CDB_URL, CDB_USER, CDB_PASS, 'centraldb')
        get_cursor = CDB.cursor()
        for pad_name in argv:
            get_cursor.execute("SELECT customer_site_stage_id FROM customer_site_stage WHERE serve_domain = '%s'" % (pad_name))
            get_result = get_cursor.fetchone()
            site_id_list.append(int(get_result[0]))
        get_cursor.close()
        CDB.close()
        return site_id_list
    except Exception as e:
        raise Exception(str(e))

def perf_create_pads(driver, pad_name, count, user, browser, file):
    for num in range(1, count):
        pad_name = pad_name.strip('.cdnetworks.com')
        try:
            create_ca_pad(driver, pad_name + str(num) +'.cdnetworks.com', user, browser, file)
            driver.quit()
        except Exception as e:
            raise Exception('adding pads for performance is failed: %s' %str(e) )

def perf_push_to_stag(driver, pad_name, count, user, browser, file):
    for num in range(1, count):
        pad_name = pad_name.strip('.cdnetworks.com') + str(num) +'.cdnetworks.com'
        try:
            if file.split('_').index('CA') >= 0:
                driver.get(AURORA_URL + "/cui/int/pads/?m=202")
        except ValueError:
            driver.get(AURORA_URL + "/cui/int/pads/?m=217")
        time.sleep(1)
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        if browser == 'firefox':
            driver.find_element_by_link_text(pad_name).click()
        else:
            driver.find_element_by_link_text(pad_name).send_keys(Keys.ENTER)
        for i in range(60):
            try:
                if "Change history" == driver.find_element_by_xpath("//h2[4]").text or \
                                "Change history" == driver.find_element_by_xpath("//h2[5]").text: break  # when push to staging and then edit
            except: pass
            time.sleep(1)
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        else: raise Exception("time out")
        if browser != 'firefox': time.sleep(1)
        driver.find_element_by_xpath("//input[@value='Push to Staging']").click()
        time.sleep(1)
        for i in range(60):
            try:
                if "Submit Request" == driver.find_element_by_css_selector("h3").text: break
            except: pass
            time.sleep(1)
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        else: raise Exception("time out")
        if browser != 'firefox': time.sleep(1)
        driver.find_element_by_name("checklist").click()
        driver.find_element_by_name("comments").clear()
        driver.find_element_by_name("comments").send_keys("test")
        driver.find_element_by_name("submit").click()
        for i in range(60):
            try:
                if "You have requested to push the pad [" + pad_name + "] to our staging servers." == driver.find_element_by_css_selector("h3").text: break
            except: pass
            time.sleep(1)
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        else: raise Exception("time out")
        ### On Staging
        for i in range(240):
            try:
                if "Push status : On Staging" == driver.find_element_by_css_selector("h2").text: break
            except: pass
            time.sleep(1)
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        else: raise Exception("time out")

def perf_push_to_prod(driver, count, pad_name, user, browser, file):
    for num in range(1, count):
        pad_name = pad_name.strip('.cdnetworks.com') + str(num) + '.cdnetworks.com'
        ### Push to Production
        try:
            if file.split('_').index('CA') >= 0:
                driver.get(AURORA_URL + "/cui/int/pads/?m=202")
        except ValueError:
            driver.get(AURORA_URL + "/cui/int/pads/?m=217")
        time.sleep(1)
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        if browser == 'firefox':
            driver.find_element_by_link_text(pad_name).click()
        else:
            driver.find_element_by_link_text(pad_name).send_keys(Keys.ENTER)
        for i in range(60):
            try:
                if "Push status : On Staging" == driver.find_element_by_css_selector("h2").text: break
            except:
                pass
            time.sleep(1)
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        else:
            raise Exception("time out")
        if browser != 'firefox': time.sleep(1)
        driver.find_element_by_xpath("//input[@value='Push to Production']").click()
        time.sleep(2)
        driver.find_element_by_name("checklist").click()
        driver.find_element_by_name("comments").clear()
        driver.find_element_by_name("comments").send_keys("push to production test")
        driver.find_element_by_name("submit").click()
        for i in range(60):
            try:
                if "You have requested to push the pad [" + pad_name + "] to our production servers." == driver.find_element_by_css_selector("h3").text: break
            except: pass
            time.sleep(1)
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        else: raise Exception("time out")
        for i in range(120):
            try:

                if "Push status : On Production" == driver.find_element_by_css_selector("h2").text: break
            except: pass
            time.sleep(1)
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        else: raise Exception("time out")
        time.sleep(2)

################################################   PUSH   ##############################################################
def push_by_oui(driver, type, user, browser, file):
    driver.find_element_by_link_text("Push").click()
    for i in range(60):
        try:
            if "Pusher" == driver.find_element_by_css_selector("h1").text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.find_element_by_id("pushform_description").clear()
    driver.find_element_by_id("pushform_description").send_keys("push test")
    if type=='http_sites':
        Select(driver.find_element_by_id("pushform_types")).select_by_visible_text("Http Sites")
    elif type=='content_distribution':
        Select(driver.find_element_by_id("pushform_types")).select_by_visible_text("Content Distribution")
    elif type == 'system_load_limit':
        Select(driver.find_element_by_id("pushform_types")).select_by_visible_text("System Load Limit")
    elif type == 'dns':
        Select(driver.find_element_by_id("pushform_types")).select_by_visible_text("DNS")
    else: raise Exception("Check your OUI push type !!!")
    driver.find_element_by_css_selector("input[type=\"submit\"]").click()
    for i in range(60):
        try:
            if "Your push request has been received. This page will refresh in 15 seconds; your push(es) will show up in the table below within a few minutes." == driver.find_element_by_css_selector("div.notice").text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")

@logmethod
@catch_exception(author="hyunhwa.hong")
def push_to_stag(driver, pad_name, user, browser, file):
    ### Push to Staging
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/?m=217")
    time.sleep(1)
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    if browser == 'firefox':
        driver.find_element_by_link_text(pad_name).click()
    else:
        driver.find_element_by_link_text(pad_name).send_keys(Keys.ENTER)
    for i in range(60):
        try:
            if "Change history" == driver.find_element_by_xpath("//h2[4]").text or \
                            "Change history" == driver.find_element_by_xpath("//h2[5]").text: break  # when push to staging and then edit
        except: pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else: raise Exception("time out")
    if browser != 'firefox': time.sleep(1)
    driver.find_element_by_xpath("//input[@value='Push to Staging']").click()
    time.sleep(1)
    for i in range(60):
        try:
            if "Submit Request" == driver.find_element_by_css_selector("h3").text: break
        except:
            pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else:
        raise Exception("time out")
    if browser != 'firefox': time.sleep(1)
    driver.find_element_by_name("checklist").click()
    driver.find_element_by_name("comments").clear()
    driver.find_element_by_name("comments").send_keys("test")
    driver.find_element_by_name("submit").click()
    for i in range(60):
        try:
            if "You have requested to push the pad [" + pad_name + "] to our staging servers." == driver.find_element_by_css_selector("h3").text: break
        except: pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else:
        raise Exception("time out")

    ### On Staging
    for i in range(240):
        try:
            if "Push status : On Staging" == driver.find_element_by_css_selector("h2").text: break
        except:
            pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else:
        raise Exception("time out")

def push_to_stag_without_val(driver, pad_name, user, browser, file):
    ### Push to Staging
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/?m=217")
    time.sleep(1)
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    if browser == 'firefox':
        driver.find_element_by_link_text(pad_name).click()
    else:
        driver.find_element_by_link_text(pad_name).send_keys(Keys.ENTER)
    for i in range(60):
        try:
            if "Change history" == driver.find_element_by_xpath("//h2[4]").text or \
                            "Change history" == driver.find_element_by_xpath("//h2[5]").text: break  # when push to staging and then edit
        except: pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else: raise Exception("time out")
    if browser != 'firefox': time.sleep(1)
    driver.find_element_by_xpath("//input[@value='Push to Staging']").click()
    time.sleep(1)
    for i in range(60):
        try:
            if "Submit Request" == driver.find_element_by_css_selector("h3").text: break
        except:
            pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else:
        raise Exception("time out")
    if browser != 'firefox': time.sleep(1)
    driver.find_element_by_name("checklist").click()
    driver.find_element_by_name("comments").clear()
    driver.find_element_by_name("comments").send_keys("test")
    driver.find_element_by_name("submit").click()
    for i in range(60):
        try:
            if "You have requested to push the pad [" + pad_name + "] to our staging servers." == driver.find_element_by_css_selector("h3").text: break
        except: pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else:
        raise Exception("time out")

@logmethod
@catch_exception(author="hyunhwa.hong")
def push_to_stag_failed(driver, pad_name, user, browser, file):
    ### Push to Staging
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/?m=217")
    time.sleep(1)
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    if browser == 'firefox':
        driver.find_element_by_link_text(pad_name).click()
    else:
        driver.find_element_by_link_text(pad_name).send_keys(Keys.ENTER)
    for i in range(60):
        try:
            if "Change history" == driver.find_element_by_xpath("//h2[4]").text or \
                            "Change history" == driver.find_element_by_xpath("//h2[5]").text: break  # when push to staging and then edit
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    if browser != 'firefox': time.sleep(1)
    driver.find_element_by_xpath("//input[@value='Push to Staging']").click()
    time.sleep(1)
    for i in range(60):
        try:
            if "Submit Request" == driver.find_element_by_css_selector("h3").text: break
        except: pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else: raise Exception("time out")
    if browser != 'firefox': time.sleep(1)
    driver.find_element_by_name("checklist").click()
    driver.find_element_by_name("comments").clear()
    driver.find_element_by_name("comments").send_keys("test")
    driver.find_element_by_name("submit").click()
    for i in range(60):
        try:
            if "Product is expired. If you want to proceed, please contact support center." == driver.find_element_by_css_selector("li").text: break
        except: pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else: raise Exception("time out")

@logmethod
def push_to_prod(driver, pad_name, user, browser, file):
    ### Push to Production
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/?m=217")
    time.sleep(1)
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    if browser == 'firefox':
        driver.find_element_by_link_text(pad_name).click()
    else:
        driver.find_element_by_link_text(pad_name).send_keys(Keys.ENTER)
    for i in range(60):
        try:
            if "Push status : On Staging" == driver.find_element_by_css_selector("h2").text: break
        except:
            pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else:
        raise Exception("time out")
    if browser != 'firefox': time.sleep(1)
    driver.find_element_by_xpath("//input[@value='Push to Production']").click()
    time.sleep(2)
    driver.find_element_by_name("checklist").click()
    driver.find_element_by_name("comments").clear()
    driver.find_element_by_name("comments").send_keys("push to production test")
    driver.find_element_by_name("submit").click()
    for i in range(60):
        try:
            if "You have requested to push the pad [" + pad_name + "] to our production servers." == driver.find_element_by_css_selector("h3").text: break
        except: pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else: raise Exception("time out")
    for i in range(120):
        try:

            if "Push status : On Production" == driver.find_element_by_css_selector("h2").text: break
        except: pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else: raise Exception("time out")
    """ Deprecated for pushed rate.
    for i in range(60):
        try:
            if "100.00" == driver.find_element_by_xpath("//table[@id='push_history']/tbody/tr/td[4]").text:
                print driver.find_element_by_xpath("//table[@id='push_history']/tbody/tr/td[4]").text + '%'
                break
            print driver.find_element_by_xpath("//table[@id='push_history']/tbody/tr/td[4]").text + '%'
        except:
            pass
        try:
            if file.split('_').index('CA') >= 0:
                driver.get(AURORA_URL + "/cui/int/pads/?m=202")
        except ValueError:
            driver.get(AURORA_URL + "/cui/int/pads/?m=217")
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        if browser is not 'firefox':
            time.sleep(10)
        else:
            time.sleep(1)
        driver.find_element_by_link_text(pad_name).click()
    else:
        raise Exception("time out")"""
    time.sleep(2)

@logmethod
def push_to_prod_with_status_is_disabled(driver, pad_name, user, browser, file):
    ### Push to Production
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/?m=217")
    time.sleep(1)
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    if browser == 'firefox':
        driver.find_element_by_link_text(pad_name).click()
    else:
        driver.find_element_by_link_text(pad_name).send_keys(Keys.ENTER)
    for i in range(60):
        try:
            if "Push status : On Staging" == driver.find_element_by_css_selector("h2").text: break
        except: pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else: raise Exception("time out")
    if browser != 'firefox': time.sleep(1)
    driver.find_element_by_xpath("//input[@value='Push to Production']").click()
    time.sleep(2)
    driver.find_element_by_name("checklist").click()
    driver.find_element_by_name("comments").clear()
    driver.find_element_by_name("comments").send_keys("push to production test")
    driver.find_element_by_name("submit").click()
    for i in range(60):
        try:
            if "You have requested to push the pad [" + pad_name + "] to our production servers." == driver.find_element_by_css_selector("h3").text: break
        except: pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else: raise Exception("time out")
    for i in range(120):
        try:
            if "Push status : Disabled" == driver.find_element_by_css_selector("h2").text: break
        except: pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else: raise Exception("time out")

def push_and_accept_requested_pad(driver, pad_name, user, browser, file, customer_name):
    #find_customer_and_view_his_pad_oui(driver, pad_name, user, browser, __file__, customer_name)
    if user.find('jimdo') >= 0 and file.find('CA') >= 0:
        Select(driver.find_element_by_id("id_product")).select_by_visible_text("[0040007321-Jimdo_AA_2100][30] Web Acceleration-Content Acceleration")
    elif user.find('cetizen') >= 0 and file.find('CA') >= 0:
        Select(driver.find_element_by_id("id_product")).select_by_visible_text("[0040000105-Cetizen] Web Acceleration-Standard")
    elif user.find('megafon') >= 0 and file.find('CA') >= 0:
        Select(driver.find_element_by_id("id_product")).select_by_visible_text("[0040007879-Megafon-ResellerAgrement][30] Web Acceleration-Content Acceleration")
    elif user.find('megafon') >= 0 and file.find('DWA') >= 0:
        Select(driver.find_element_by_id("id_product")).select_by_visible_text("[0040007879-Megafon-ResellerAgrement-][20] Application Acceleration-Dynamic Web Acceleration")
    else: raise Exception("Please check your account: %s" %(user))
    Select(driver.find_element_by_id("id_service")).select_by_visible_text("n1: CS: Global Business")
    driver.find_element_by_id("push_sites").click()
    driver.find_element_by_css_selector("input[type=\"submit\"]").click()
    for i in range(60):
        try:
            if "implement site draft request: " + pad_name == driver.find_element_by_css_selector("h1").text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    if driver.find_element_by_css_selector("h1").text == "implement site draft request: " + pad_name: pass
    else: raise Exception("Check your requested pad.")
    driver.find_element_by_id("id_send_email").click()
    driver.find_element_by_css_selector("input[type=\"submit\"]").click()
    for i in range(60):
        try:
            if "Site Draft Implementation Requests" == driver.find_element_by_css_selector("h1").text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")

@logmethod
def push_and_deny_requested_pad(driver, pad_name, user, browser, file, customer_name):
    driver.find_element_by_id("id_send_email").click()
    driver.find_element_by_css_selector("input[type=\"submit\"]").click()
    for i in range(60):
        try:
            if "Site Draft Implementation Requests" == driver.find_element_by_css_selector("h1").text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")

###############################################   ACTION   #############################################################
@logmethod
@catch_exception(author="hyunhwa.hong")
def add_pad(driver, pad_name, user, browser, file):
    # Check the status of PAD (if not, created a PAD and implemented push to staging)
    CDB = mdb.connect(CDB_URL, CDB_USER, CDB_PASS, 'centraldb')
    add_cursor = CDB.cursor()
    if add_cursor.execute("select push_status from customer_site_cui WHERE serve_domain='%s'" % (pad_name)) == 0L:
        create_ca_pad(driver, pad_name, user, browser, file)
    else:
        raise Exception("Please remove your '%s' firstly" % (pad_name))
    add_cursor.close()
    CDB.close()

@logmethod
@catch_exception(author="hyunhwa.hong")
def restore_from_this_version(driver, pad_name, user, browser, file):
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/?m=217")
    driver.switch_to.parent_frame()
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    driver.find_element_by_link_text(pad_name).click()
    for i in range(60):
        try:
            if "Change history" == driver.find_element_by_xpath("//h2[5]").text: break
        except:
            pass
        time.sleep(1)
    else:
        raise Exception("time out")
    if browser != 'firefox': time.sleep(1)
    driver.find_element_by_link_text("view diff").click()
    time.sleep(2)
    if browser == 'safari' or browser == 'chrome':
        time.sleep(0.5)
        driver.execute_script("window.confirm = function() { return true; }")
        driver.find_element_by_xpath("//input[@value='Restore from this version']").click()
    else:
        driver.find_element_by_xpath("//input[@value='Restore from this version']").click()
        time.sleep(0.5)
        driver.switch_to_alert().accept()
    for i in range(60):
        try:
            if "PAD configuration has been restored to version: 1." == driver.find_element_by_css_selector("li").text: break
        except: pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else: raise Exception("time out")

@logmethod
@catch_exception(author="hyunhwa.hong")
def restore_and_push_to_staging(driver, pad_name, user, browser, file):
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/?m=217")
    driver.switch_to.parent_frame()
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    driver.find_element_by_link_text(pad_name).click()
    for i in range(60):
        try:
            if "Change history" == driver.find_element_by_xpath("//h2[5]").text: break
        except:
            pass
        time.sleep(1)
    else:
        raise Exception("time out")
    if browser != 'firefox': time.sleep(1)
    driver.find_element_by_link_text("view diff").click()
    time.sleep(2)
    if browser == 'safari' or browser == 'chrome':
        time.sleep(0.5)
        driver.execute_script("window.confirm = function() { return true; }")
        driver.find_element_by_xpath("//input[@value='Restore and push to staging']").click()
    else:
        driver.find_element_by_xpath("//input[@value='Restore and push to staging']").click()
        time.sleep(0.5)
        driver.switch_to_alert().accept()
    for i in range(60):
        try:
            if "PAD configuration has been restored to version: 1." == driver.find_element_by_css_selector("li").text: break
        except:
            pass
        time.sleep(1)
    else:
        raise Exception("time out")
    driver.find_element_by_name("checklist").click()
    driver.find_element_by_name("comments").clear()
    driver.find_element_by_name("comments").send_keys("restore test")
    driver.find_element_by_name("submit").click()
    ### On Staging
    for i in range(120):
        try:
            if "Push status : On Staging" == driver.find_element_by_css_selector("h2").text: break
        except:
            pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else:
        raise Exception("time out")

@logmethod
@catch_exception(author="hyunhwa.hong")
def delete_pushed_prod_pad(driver, pad_name, user, browser, file):
    customer_name = "GALA NETWORKS"
    active_img_name = file.strip('.py') + '_active_pad.png'
    inactive_img_name = file.strip('.py') + '_inactive_pad.png'
    deleted_img_name = file.strip('.py') + '_deleted_pad.png'
    if user==SELF_PROV_USER['USER_WITH_CA_EDIT_PRIV'] or user==SELF_PROV_USER['USER_WITH_CA_SSL_EDIT_PRIV'] or \
                        user==SELF_PROV_USER['USER_WITH_DWA_EDIT_PRIV'] or user==SELF_PROV_USER['USER_WITH_DWA_SSL_EDIT_PRIV']:
        push_to_stag(driver, pad_name, user, browser, file)
        push_to_prod_with_status_is_disabled(driver, pad_name, user, browser, file)
        val_modified_pad_in_OUI(customer_name, pad_name, file, 'after', inactive_img_name)
        clear_pad(driver, pad_name, user, browser, file)
        val_modified_pad_in_OUI(customer_name, pad_name, file, 'after', deleted_img_name)
    else:
        push_to_stag(driver, pad_name, user, browser, file)
        push_to_prod(driver, pad_name, user, browser, file)
        val_modified_pad_in_OUI(customer_name, pad_name, file, 'after', active_img_name)
        edit_ca_pad(driver, pad_name, user, browser, file)
        push_to_stag(driver, pad_name, user, browser, file)
        push_to_prod_with_status_is_disabled(driver, pad_name, user, browser, file)
        val_modified_pad_in_OUI(customer_name, pad_name, file, 'after', inactive_img_name)
        clear_pad(driver, pad_name, user, browser, file)
        val_modified_pad_in_OUI(customer_name, pad_name, file, 'after', deleted_img_name)

#########################################     IMAGE HANDLING     #######################################################
@logmethod
@catch_exception(author="hyunhwa.hong")
def save_and_crop_img(driver, type, item, name, handler='before'):
    # before or after image path
    if handler == 'before':
        img_path = PATH + '/org/'
    elif handler == 'after':
        img_path = PATH + '/'
    else: raise Exception("Must use 'before' or 'after'")
    # what is your type? css? id? link_text?
    if type == 'id':
        element = driver.find_element_by_id(item)
    elif type == 'link_text':
        element = driver.find_element_by_link_text(item)
    else: raise Exception("We can NOT find out your type: link_text, id, css, ...")
    location = element.location
    size = element.size
    driver.save_screenshot(img_path+name)
    try:
        im = Image.open(img_path+name)
        # what the hell on scroll bar !!!
        left = int(location['x']); top = int(location['y']); right = driver.get_window_size()['width']-15; bottom = int(location['y']+size['height'])
        im = im.crop((left, top, right, bottom))
        im.save(img_path+name)
    except Exception as e:
        raise Exception(str(e))

@logmethod
@catch_exception(author="hyunhwa.hong")
def save_and_crop_img_with_width_and_height(driver, type, item, name, handler='before', height='', width=''):
    # before or after image path
    if handler == 'before':
        img_path = PATH + '/org/'
    elif handler == 'after':
        img_path = PATH + '/'
    else:
        raise Exception("Must use 'before' or 'after'")
    # what is your type? css? id? link_text?
    if type == 'id':
        element = driver.find_element_by_id(item)
    elif type == 'link_text':
        element = driver.find_element_by_link_text(item)
    elif type == 'xpath':
        element = driver.find_element_by_xpath(item)
    else:
        raise Exception("We can NOT find out your type: link_text, id, css, ...")
    location = element.location
    size = element.size
    # width and height
    if width is '': width = location['x'] + size['width']
    else: width = location['x'] + width
    if height is '': height = location['y'] + size['height']
    else: height = location['y'] + height
    driver.save_screenshot(img_path + name)
    try:
        im = Image.open(img_path + name)
        # what the hell on scroll bar !!!
        left = location['x']; top = location['y']; right = width; bottom = height
        im = im.crop((left, top, right, bottom))
        im.save(img_path + name)
    except Exception as e:
        raise Exception(str(e))

def set_vars_in_jinja2(template_path, file, site_id_list):
    try:
        template_env = Environment(loader=FileSystemLoader(template_path), extensions=['jinja2.ext.do'])
        template = template_env.get_template(file)
        for arg in site_id_list:
            output_from_parsed_template = template.render(site_id_list=site_id_list)
        return output_from_parsed_template
    except Exception as e:
        raise Exception(str(e))

def start_push_requester():
    try:
        print "Register the 'spectrumapi-qa.cdnetworsk.com' in your hosts"
        import paramiko
        CLIENT_HOST = SPECTRUMAPI_URL.replace('https://','')
        START_CMD = "sudo /etc/init.d/push_requester start"
        KEY = paramiko.RSAKey.from_private_key_file(SSH_OPG_KEY)

        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(CLIENT_HOST, username='cloud-user', port=2113, pkey=KEY)
            stdin, stdout, stderr = client.exec_command(START_CMD)
            cmd_result = stdout.read()
            if cmd_result.find("Starting push_requester") >= 0:
                pass
            else:
                raise Exception("Check your domain, CLIENT_HOST: %s" (CLIENT_HOST))
        except Exception as e:
            raise Exception(str(e))
    except Exception as e:
        raise Exception(str(e))

def stop_push_requester():
    try:
        print "Register the 'spectrumapi-qa.cdnetworsk.com' in your hosts"
        import paramiko
        CLIENT_HOST = SPECTRUMAPI_URL.replace('https://', '')
        STOP_CMD = "sudo /etc/init.d/push_requester stop"
        KEY = paramiko.RSAKey.from_private_key_file(SSH_OPG_KEY)

        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(CLIENT_HOST, username='cloud-user', port=2113, pkey=KEY)
            stdin, stdout, stderr = client.exec_command(STOP_CMD)
            cmd_result = stdout.read()
            if cmd_result.find("Stopping push_requester") >= 0:
                pass
            else:
                raise Exception("Check your domain, CLIENT_HOST: %s" (CLIENT_HOST))
        except Exception as e:
            raise Exception(str(e))
    except Exception as e:
        raise Exception(str(e))

def run_threads(*argv): # func_name, args(list type)
    count = 0;
    try:
        while count < argv.__len__() - 1:
            threading.Thread(name=argv[count], target=argv[count], args=(argv[count+1])).start()
            count = count + 2
    except Exception as e:
        raise Exception(str(e))

@logmethod
@catch_exception(author="hyunhwa.hong")
def return_img_comparison(driver, sub_img, img):
    img1 = img
    img2 = sub_img
    #driver.save_screenshot(PATH+'/'+img1)
    #save_and_crop_img(driver, 'link_text', 'Manage My Profile', sub_img, 'after')
    #save_and_crop_img_with_width_and_height(driver, 'link_text', 'Manage My Profile', sub_img, 'after')
    img_rgb = cv2.imread(PATH+'/'+img1)
    img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
    template = cv2.imread(PATH+'/'+img2,0)
    w, h = template.shape[::-1]

    res = cv2.matchTemplate(img_gray,template,cv2.TM_CCOEFF_NORMED)
    threshold = 0.8
    loc = numpy.where( res >= threshold)
    for pt in zip(*loc[::-1]):
        cv2.rectangle(img_rgb, pt, (pt[0] + w, pt[1] + h), (0,0,255), 2)
    cv2.imwrite(PATH+'/res.png',img_rgb)

@logmethod
def image_exists(driver, sub_img, img):
    """How to crop a image?
        driver.save_screenshot('img/result/org/CA_Push_to_Staging_PAD_request_edit_and_approve_sub.png')
        im = Image.open('img/result/org/CA_Push_to_Staging_PAD_request_edit_and_approve_sub.png')
        im = im.crop((632, 800, 1000, 850))
        im.save('img/result/org/CA_Push_to_Staging_PAD_request_edit_and_approve_sub.png')

        im = Image.open('img/result/org/CA_Push_to_Staging_PAD_request_edit_and_approve_sub.png')
        im = im.crop((90, 29, 197, 50))
        im.save('img/result/org/CA_Push_to_Staging_PAD_request_edit_and_approve_sub_edit_and_approve.png')
    """
    driver.maximize_window()
    img1 = Image.open(PATH+'/'+sub_img)
    img2 = Image.open(PATH+'/'+img)
    img1=numpy.asarray(img1)
    img2=numpy.asarray(img2)

    img1y=img1.shape[0]
    img1x=img1.shape[1]

    img2y=img2.shape[0]
    img2x=img2.shape[1]

    stopy=img2y-img1y+1
    stopx=img2x-img1x+1

    for x1 in range(0,stopx):
        for y1 in range(0,stopy):
            x2=x1+img1x
            y2=y1+img1y

            pic=img2[y1:y2,x1:x2]
            test=pic==img1
            if test.all():
                return_img_comparison(driver, sub_img, img)
                """if os.path.isfile(PATH+'/'+img):
                    os.remove(PATH+'/'+img)
                else: print("Error: %s file not found: " %(img2))"""
                return x1, y1
    return False

@logmethod
@catch_exception(author="hyunhwa.hong")
def find_image_and_then_click_it(driver, file, x=None, y=None, width=None, height=None, *argv): # argv: big -> medium -> small
    """ How to move and click its link?

        1. Let's crop your screenshot: driver.save_screenshot('test.png')
        2. Crop your screenshot: save_and_crop_img(driver, 'xpath', "//div[@id='content-right']/div[3]/p[7]/strong", 'test_sub.png', 'before')
        3. Crop your image in cropped image again: save_and_crop_img_with_width_and_height(driver, 'link_text', 'delete', 'test_sub_delete.png', 'before', width=105)
        4. Got 2's position(x1, y1):  image_exists(driver, 'test_sub.png', 'test.png')
        5. got 3's position(x2, y2): image_exists(driver, 'test_sub_delete.png', 'test_sub.png')
        6. Your click position is "x1+x2, y1+y2" and its middle is (x1+x2+test_sub_delete.png width/2, y1+y2+test_sub_delete.png width/2)

        Summary: Let's have 3 downloaded images (whole, sub, sub_sub) -> get positions(x,y) of 'whole-sub' and 'sub-sub_sub' -> caculate it

        Example) image must be downloaded only by webdriver !!
        1. image_exists(driver, 'org/CA_Push_to_Staging_PAD_request_edit_and_approve_sub.png', 'org/CA_Push_to_Staging_PAD_request_edit_and_approve.png') -> (630,1232)
        2. image_exists(driver, 'org/CA_Push_to_Staging_PAD_request_edit_and_approve_sub_edit_and_approve.png', 'org/CA_Push_to_Staging_PAD_request_edit_and_approve_sub.png') -> (95,30)
        3. im = Image.open('./img/result/org/CA_Push_to_Staging_PAD_request_edit_and_approve_sub_edit_and_approve.png')
        4. w, h = im.size -> (105,15)
        5. x=630+95+(105/2); y=1232+30+(15/2)
        6. action = ActionChains(driver); action.move_by_offset(x, y).click().perform();
    """
    driver.maximize_window()
    x = y = index = count = 0;
    try:
        ## image comparison
        while count < argv.__len__()-1:
            ### replace func is just for image path
            x1, y1 = image_exists(driver, argv[count+1].replace(argv[count+1],'org/'+argv[count+1]), argv[count].replace(argv[count],'org/'+argv[count]))
            x = x1 + x; y = y1 + y; count = count + 1
        im = Image.open(PATH + argv[-1].replace(argv[-1], '/org/'+argv[-1]))  # arg[-1] is the last image
        width, height = im.size
        pos_x = x + width / 2; pos_y = y + height / 2
    except Exception as e: raise Exception(str(e))
    action = ActionChains(driver)
    #driver.find_element_by_xpath("(//a[contains(text(),'edit and approve')])[8]").location
    #action.move_by_offset(726,719).click().perform() # el.location = 725, 718 (edit and approve position)
    action.move_by_offset(pos_x, pos_y).click().perform()

@logmethod
def find_customer_and_view_his_pad_oui(driver, pad_name, user, browser, file, customer_name, link_text):
    from selenium_test.shared_components.login import *
    # OUI doesn't work in IE
    driver = webdriver.Firefox()
    oui_login(driver)
    for i in range(60):
        try:
            if "local CDNetworks OUI: home" == driver.title: break
        except: pass
        time.sleep(1)
    else:
        raise Exception("time out")
    driver.find_element_by_id("search_input").click()
    driver.find_element_by_id("search_input").send_keys(customer_name)
    driver.find_element_by_id("search_input").send_keys(Keys.ENTER)
    if user.find('cetizen') >= 0:
        for i in range(60):
            try:
                if user.find('cetizen') >= 0:
                    if u'(\uc8fc)\uc138\ud2f0\uc98c\ub2f7\ucef4' == driver.find_element_by_link_text('(주)세티즌닷컴').text: break
            except: pass
            time.sleep(1)
        else: raise Exception("time out")
    else:
        for i in range(60):
            try:
                if customer_name == driver.find_element_by_link_text(customer_name).text: break
            except: pass
            time.sleep(1)
        else: raise Exception("time out")
    if user.find('cetizen') >= 0:
        driver.find_element_by_link_text('(주)세티즌닷컴').click()
    elif user.find('megafon') >= 0:
        driver.find_element_by_link_text('[Megafon] Own-usage').click()
    else: driver.find_element_by_link_text(customer_name).click()
    for i in range(60):
        try:
            if driver.page_source.rfind(pad_name) != -1: break
        except: pass
        time.sleep(1)
        driver.refresh()
    else: raise Exception("time out")
    if driver.find_element_by_css_selector("div.dash_module.dash_module_lg > h2.title").text == "Pending implementation requests": pass
    ## We can get main image in
    driver.save_screenshot(PATH + '/org/MAIN_SCREENSHOT.png')
    if link_text == 'edit_and_approve':
        find_image_and_then_click_it(driver, __file__, '', '', '', '', 'MAIN_SCREENSHOT.png',
                                     'CA_Push_to_Staging_PAD_request_edit_and_approve_sub.png',
                                     'CA_Push_to_Staging_PAD_request_edit_and_approve_sub_edit_and_approve.png')
        for i in range(60):
            try:
                if "local CDNetworks OUI: Edit Site:" == driver.title: return driver  # OUI driver
            except: pass
            time.sleep(1)
        else: raise Exception("time out")
    elif link_text == 'deny':
        find_image_and_then_click_it(driver, __file__, '', '', '', '', 'MAIN_SCREENSHOT.png',
                                     'CA_Push_to_Staging_PAD_request_edit_and_approve_sub.png',
                                     'CA_request_PAD_deny.png')
        for i in range(60):
            try:
                if "local CDNetworks OUI: cancel site draft request" == driver.title: return driver  # OUI driver
            except: pass
            time.sleep(1)
        else: raise Exception("time out")

def curl_pad_validation(pad_name, prod):
    # Curl test
        print "Register the 'h0-s107.qa-tst.cdngp.net' in your hosts"
        import paramiko
        CLIENT_HOST = 'h0-s107.qa-tst.cdngp.net'
        if prod == 'false':
            CS_HOST = 'h0-s175.p99-sjc.cdngp.net' # production CS
        else: CS_HOST = 'h0-s170.p99-sjc.cdngp.net' # staging CS
        CURL_CMD = "curl -v -H'Host: "+ pad_name +"' 'http://" + CS_HOST + "/test'"
        KEY = paramiko.RSAKey.from_private_key_file("./ssh/opg-key")

        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(CLIENT_HOST, username='cloud-user', port=2113, pkey=KEY)
            stdin, stdout, stderr = client.exec_command(CURL_CMD)
            curl_result = stderr.read()
            print curl_result
            if curl_result.find("HTTP/1.1 200 OK"):
                pass
            else:
                raise Exception("Check your domains, CLIENT_HOST: %s and CS_HOST: %s" (CLIENT_HOST, CS_HOST))
        except Exception as e:
            print "Error: %s" (e)

def expire_or_activate_contract_item_cdb(cop_product_id, active_value):
    try:
        CDB = mdb.connect(CDB_URL, CDB_USER, CDB_PASS, 'centraldb')
        expire_cursor = CDB.cursor()
        expire_cursor.execute("UPDATE customer_product SET active = %s WHERE cop_product_id = '%s'" % (active_value, cop_product_id))
        CDB.commit()
        expire_cursor.close()
        CDB.close()
    except Exception as e:
        raise Exception(str(e))

###########################################     VALIDATION     #########################################################
def val_no_such_element_pad(driver, pad_name, user, browser, file):
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/?m=217")
    time.sleep(2)
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    for i in range(60):
        try:
            if "Note: - Pad diff viewer" == driver.find_element_by_css_selector("h2").text: break
        except:
            pass
        time.sleep(1)
    else:
        raise Exception("time out")
    try:
        driver.find_element_by_link_text(pad_name).text
    except NoSuchElementException as e:
        pass

def val_no_such_element_svndiff(driver, pad_name, user, browser, file):
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/?m=217")
    time.sleep(2)
    driver.switch_to.parent_frame()
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    driver.find_element_by_link_text(pad_name).click()
    for i in range(60):
        try:
            if "Change history" == driver.find_element_by_xpath("//h2[5]").text: break
        except:
            pass
        time.sleep(1)
    else:
        raise Exception("time out")
    try:
        driver.find_element_by_link_text("view diff").text
    except NoSuchElementException as e:
        pass

def val_access_denied(driver, pad_name, user, browser, file):
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/?m=217")
    time.sleep(2)
    ## Access Denied
    for i in range(60):
        try:
            if "Error 403" == driver.find_element_by_css_selector("h1.pa-title").text: break
        except: pass
        time.sleep(1)
    else:
        raise Exception("time out")

@logmethod
def val_pad_status(driver, pad_name, user, browser, file, status):
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/?m=217")
    for i in range(60):
        try:
            if "Customer" == driver.find_element_by_css_selector("h2.se-title > span").text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    time.sleep(1)
    driver.switch_to.parent_frame()
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    driver.find_element_by_link_text(pad_name).click()
    ## request PAD
    if file.find('request') >= 0:
        for i in range(60):
            try:
                if "Change history" == driver.find_element_by_xpath("//h2[4]").text: break
            except: pass
            time.sleep(1)
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        else: raise Exception("time out")
        for i in range(60):
            try:
                if "Push history" == driver.find_element_by_xpath("//h2[5]").text: break
            except: pass
            time.sleep(1)
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        else: raise Exception("time out")
        for i in range(60):
            try:
                if driver.find_element_by_css_selector("h2").text == "Production Site Settings": break
            except: pass
            time.sleep(1)
        else: raise Exception(driver.find_element_by_css_selector("h2").text + " does NOT exist")
    ## self PAD
    else:
        for i in range(60):
            try:
                if "Change history" == driver.find_element_by_xpath("//h2[5]").text: break
            except: pass
            time.sleep(1)
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        else:raise Exception("time out")
        for i in range(60):
            try:
                if "Push history" == driver.find_element_by_xpath("//h2[6]").text: break
            except:pass
            time.sleep(1)
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        else:
            raise Exception("time out")
        for i in range(60):
            try:
                if driver.find_element_by_css_selector("h2").text == "Push status : " + status: break
            except: pass
            time.sleep(1)
            driver.switch_to.parent_frame()
            driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
        else: raise Exception(driver.find_element_by_css_selector("h2").text + " does NOT exist")
    CDB = mdb.connect(CDB_URL, CDB_USER, CDB_PASS, 'centraldb')
    status_cursor = CDB.cursor()
    status_cursor.execute("select push_status from customer_site_cui where serve_domain = '%s'" % (pad_name))
    status_result = status_cursor.fetchone()
    if status_result[0] >= 0:
        CDB.close(); status_cursor.close(); pass
    else: raise Exception("Your pad status is just %s" %(status))


@logmethod
def val_modified_pad_in_OUI(customer_name, pad_name, file, img_handle, img_name):
    """Usage: val_modified_pad_in_OUI(customer_name, pad_name, __file__, 'after', active_img_name)
    """
    from selenium_test.shared_components.login import *
    driver = webdriver.Firefox()
    oui_login(driver)
    for i in range(60):
        try:
            if "local CDNetworks OUI: home" == driver.title: break
        except:
            pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.find_element_by_id("search_input").click()
    driver.find_element_by_id("search_input").send_keys(customer_name)
    driver.find_element_by_id("search_input").send_keys(Keys.ENTER)
    for i in range(60):
        try:
            if customer_name == driver.find_element_by_link_text(customer_name).text: break
        except:
            pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.find_element_by_link_text(customer_name).click()
    for i in range(60):
        try:
            if "local CDNetworks OUI: customer: " + customer_name == driver.title: break
        except:
            pass
        time.sleep(1)
    else: raise Exception("time out")
    save_and_crop_img(driver, 'link_text', pad_name, img_name, img_handle)
    if image_similarity_vectors_via_numpy(PATH+'/'+img_name, PATH+'/org/'+img_name) > 0.98: pass
    else: raise Exception("Images are NOT identical! Check your two images.")
    driver.find_element_by_link_text(pad_name).click()
    for i in range(60):
        try:
            if "local CDNetworks OUI: site: " + pad_name == driver.title: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.quit()

def val_button_name(driver, pad_name, user, browser, file, button_name):
    ### Push to Staging
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/?m=217")
    time.sleep(1)
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    if browser == 'firefox':
        driver.find_element_by_link_text(pad_name).click()
    else:
        driver.find_element_by_link_text(pad_name).send_keys(Keys.ENTER)
    for i in range(60):
        try:
            if "request implementation" == driver.find_element_by_xpath("//input[@value='"+button_name+"']").get_attribute("value"): break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")

def val_add_a_PAD_for_this_customer_and_no_product_list_in_oui(customer_name, pad_name, user, browser, file):
    from selenium_test.shared_components.login import *
    driver = webdriver.Firefox()
    oui_login(driver)
    for i in range(60):
        try:
            if "local CDNetworks OUI: home" == driver.title: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.find_element_by_id("search_input").click()
    driver.find_element_by_id("search_input").send_keys(customer_name)
    driver.find_element_by_id("search_input").send_keys(Keys.ENTER)
    for i in range(60):
        try:
            if customer_name == driver.find_element_by_link_text(customer_name).text: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.find_element_by_link_text(customer_name).click()
    for i in range(60):
        try:
            if "local CDNetworks OUI: customer: " + customer_name == driver.title: break
        except: pass
        time.sleep(1)
    else: raise Exception("time out")
    driver.find_element_by_link_text("Add a PAD for this customer").click()
    if file.find('CA') >= 0:
        for i in range(60):
            try:
                if "Add Site for GALA NETWORKS" == driver.find_element_by_css_selector("h1").text: break
            except: pass
            time.sleep(1)
        else: raise Exception("time out")
    product_lists = driver.find_element_by_id("id_product").text.split('\n[')
    if file.find('DWA') >= 0 and file.find('SSL') < 0:
        for list in product_lists:
            if list == '0040000548-Gala net_GCA] DWA': raise Exception("'%s' exists even if its contract was expired !!" % (list))
    elif file.find('DWA') >= 0 and file.find('SSL') >= 0:
        for list in product_lists:
            if list == '0040000548-Gala net_GCA] DWA SSL': raise Exception("'%s' exists even if its contract was expired !!" % (list))
    elif file.find('CA') >= 0and file.find('SSL') < 0:
        for list in product_lists:
            if list == '0040000548-Gala net_GCA] Web Acceleration-Web Acceleration': raise Exception("'%s' exists even if its contract was expired !!" %(list))
    elif file.find('CA') >= 0 and file.find('SSL') >= 0:
        for list in product_lists:
            if list == '0040000548-Gala net_GCA] CA SSL': raise Exception("'%s' exists even if its contract was expired !!" % (list))
    driver.quit()

################################################   CLEAR   #############################################################
@logmethod
@catch_exception(author="hyunhwa.hong")
def clear_pad(driver, pad_name, user, browser, file):
    ### Clear
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/?m=217")
    time.sleep(3)
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    if browser == 'safari' or 'chrome':
        driver.execute_script("window.confirm = function() { return true; }")
        driver.find_element_by_css_selector("a[data-delete='"+pad_name+"']").click()
    else:
        driver.find_element_by_css_selector("a[data-delete='"+pad_name+"']").click()
        time.sleep(0.5)
        driver.switch_to_alert().accept()

@logmethod
@catch_exception(author="hyunhwa.hong")
def clear_pad_prod(driver, pad_name, user, browser, file):
    CDB = mdb.connect(CDB_URL, CDB_USER, CDB_PASS, 'centraldb')
    clear_cursor = CDB.cursor()
    clear_cursor.execute("UPDATE customer_site SET status = 0 WHERE serve_domain = '%s'" % (pad_name))
    clear_cursor.execute("UPDATE customer_site_cui SET push_status = 0 WHERE serve_domain = '%s'" % (pad_name))
    CDB.commit()
    # AURORAUI
    driver.refresh()
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/?m=217")
    time.sleep(1)
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    if browser == 'safari' or browser == 'chrome':
        driver.execute_script("window.confirm = function() { return true; }")
        driver.find_element_by_css_selector("a[data-delete='" + pad_name + "']").click()
    else:
        time.sleep(3)
        driver.find_element_by_css_selector("a[data-delete='" + pad_name + "']").click()
        driver.switch_to_alert().accept()
        time.sleep(1)
    # CDB
    clear_cursor.execute("SET FOREIGN_KEY_CHECKS=0")
    clear_cursor.execute("DELETE FROM customer_site WHERE serve_domain = '%s'" % (pad_name))
    clear_cursor.execute("SET FOREIGN_KEY_CHECKS=1")
    CDB.commit()
    clear_cursor.close()
    CDB.close()
    """ For pe2ngp sync module.
    # NGPDB (Related to PE2NGP sync module)
    ngpdb = mdb.connect(NGPDB_URL, NGPDB_USER, NGPDB_PASS, 'spectrum')
    ngp_cursor = ngpdb.cursor()
    ngp_cursor.execute("DELETE FROM stat_api_key WHERE stat_id=(SELECT statmaster_id from cs_stat_master WHERE domain = '%s'" %(pad_name))
    ngp_cursor.execute("DELETE FROM stat_master WHERE stat_id = (SELECT statmaster_id from cs_stat_master WHERE domain = '%s'" %(pad_name))
    ngp_cursor.execute("DELETE FROM cs_stat_master WHERE domain = '%s'" %(pad_name))
    ngp_cusrsor.commit()
    ngpdb.close()"""

@logmethod
def clear_db(*argv):
    try:
        CDB = mdb.connect(CDB_URL, CDB_USER, CDB_PASS, 'centraldb')
        clear_cursor = CDB.cursor()
        for pad_name in argv:
            clear_cursor.execute("SET FOREIGN_KEY_CHECKS=0")
            clear_cursor.execute("DELETE FROM customer_site_cui WHERE serve_domain = '%s'" % (pad_name))
            clear_cursor.execute("DELETE FROM customer_site_stage WHERE serve_domain = '%s'" % (pad_name))
            clear_cursor.execute("DELETE FROM customer_site WHERE serve_domain = '%s'" % (pad_name))
            clear_cursor.execute("SET FOREIGN_KEY_CHECKS=1")
            CDB.commit()
        clear_cursor.close()
        CDB.close()
    except Exception as e:
        raise Exception(str(e))

