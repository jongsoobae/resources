#!/usr/bin/python
#-*-encoding: utf-8-*-

## Path
import time, requests, os, sys
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)

## Modules
from selenium import webdriver
from selenium_test.config_constants import *
from selenium_test.shared_components.login import *
from selenium_test.shared_components.decorator import *
from selenium_test.shared_components.common_action import *

## DB
import MySQLdb as mdb
import subprocess

## Global variables
CDB = mdb.connect(CDB_URL, CDB_USER, CDB_PASS, 'centraldb')
NGPDB = mdb.connect(NGPDB_URL, NGPDB_USER, NGPDB_PASS, 'spectrum')

#################################################   DBs   ##############################################################
@logmethod
def set_meterial_no(prv_contract_no, prv_item_no, material_no):
    # CA: 1028,1003,1006,1029,1133  DWA: 1115    CA SSL: 1291   DWA SSL:1292
    ngp_cursor = NGPDB.cursor()
    ngp_cursor.execute("UPDATE customer_item SET material_no=%s WHERE contract_no=%s AND item_no=%s" % (material_no, prv_contract_no, prv_item_no))
    NGPDB.commit()
    ngp_cursor.close()

@logmethod
def set_service_type(prv_contract_no, prv_item_no, service_type):
    # R5, R7, R8: China zone
    ngp_cursor = NGPDB.cursor()
    ngp_cursor.execute("UPDATE customer_item SET service_type='%s' WHERE contract_no=%s AND item_no=%s" % (service_type, prv_contract_no, prv_item_no))
    NGPDB.commit()
    ngp_cursor.close()

@logmethod
def set_allow_add_pad_flag(flag, cop_product_id):
    cdb_cursor = CDB.cursor()
    cdb_cursor.execute("UPDATE customer_product SET allow_add_pad_flag=%s WHERE cop_product_id='%s'" % (flag, cop_product_id))
    CDB.commit()
    cdb_cursor.close()

@logmethod
def set_per_app_billing_method(prv_contract_no, prv_item_no, unit):
    ngp_cursor = NGPDB.cursor()
    ngp_cursor.execute("UPDATE customer_item SET unit='%s' WHERE contract_no=%s AND item_no=%s" % (unit, prv_contract_no, prv_item_no))
    NGPDB.commit()
    ngp_cursor.close()

@logmethod
def set_preset_edge(using_private_certs_value, customer_id):
    cdb_cursor = CDB.cursor()
    cdb_cursor.execute("UPDATE customer SET using_private_certs=%s WHERE customer_id='%s'" % (using_private_certs_value, customer_id))
    CDB.commit()
    cdb_cursor.close()

def clear_db():
    CDB.close()
    NGPDB.close()

################################################   Actions   ###########################################################
def restart_memcached_in_spectrumapi_oui():
    restart_memcached(SPECTRUMAPI_URL.strip('https:').lstrip("//"))
    restart_memcached(PANTHER_API_URL.rstrip("/rest/").lstrip("https:").lstrip("//"))

def return_value_by_pantherapi(contract_no, item_no):
    try:
        PAD_API = PANTHER_API_URL+'int/'+PANTHER_API_USER+':'+PANTHER_API_PWD+'/product/view/'+contract_no+'-'+item_no+'/?apply_cache=False'
        resp = requests.get(PAD_API)
        api_result = resp.json()
        return api_result
    except Exception as e:
        raise Exception(e)
@logmethod
def add_new_pad(driver, pad_name, user, browser, file):
    common_login_action(driver, user, SELF_PROV_USER['PASSWORD'])
    create_ca_pad(driver, pad_name, user, browser, file)

def val_request_pad(driver, pad_name, user, browser, file):
    try:
        if file.split('_').index('CA') >= 0:
            driver.get(AURORA_URL + "/cui/int/pads/?m=202")
    except ValueError:
        driver.get(AURORA_URL + "/cui/int/pads/?m=217")
    for i in range(60):
        try:
            if "Customer" == driver.find_element_by_css_selector("h2.se-title > span").text: break
        except:
            pass
        time.sleep(1)
    else:
        raise Exception("time out")
    if browser != 'firefox': time.sleep(1)
    driver.switch_to.parent_frame()
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    driver.find_element_by_link_text(pad_name).click()
    for i in range(60):
        try:
            if "Change history" == driver.find_element_by_xpath("//h2[4]").text: break
        except:
            pass
        time.sleep(1)
    else: raise Exception("time out")
    for i in range(60):
        try:
            if "Push history" == driver.find_element_by_xpath("//h2[5]").text: break
        except:
            pass
        time.sleep(1)
    else: raise Exception("time out")
    if driver.find_element_by_xpath("//input[@value='request implementation']").get_attribute("value")=="request implementation": pass
    else: raise Exception("Finding a 'request implementation' button is failed")
    driver.find_element_by_xpath("//input[@value='request implementation']").get_attribute("value")
    driver.switch_to.parent_frame()
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    driver.find_element_by_css_selector("input[type=\"submit\"]").click()
    # wait for editable mode
    for i in range(60):
        try:
            if "Leave comment in request if required" == driver.find_element_by_css_selector("i").text: break
        except:
            pass
        time.sleep(1)
        driver.switch_to.parent_frame()
        driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    else:
        raise Exception("time out")
    # no ways to stop the loading
    if browser == 'firefox':
        time.sleep(5)
    else:
        time.sleep(10)
    driver.switch_to.parent_frame()
    driver.switch_to_frame(driver.find_element_by_id("cui_integrationIframe"))
    driver.find_element_by_id("id_pad_aliases").clear()
    driver.find_element_by_id("id_pad_aliases").send_keys("request."+pad_name)
    driver.find_element_by_id("id_backup_origin").clear()
    driver.find_element_by_id("id_backup_origin").send_keys("request."+pad_name)
    driver.find_element_by_id("id_description").clear()
    driver.find_element_by_id("id_description").send_keys("selenium request test")
    if driver.find_element_by_id("button_request_impl").get_attribute("value") == "Save and Request Implementation": pass
    else: raise Exception("Finding a 'Save and Request Implementation' button is failed")
    driver.find_element_by_name("submit").click()
    for i in range(60):
        try:
            if "Your settings for "+pad_name+" have been saved." == driver.find_element_by_css_selector("li").text: break
        except:
            pass
        time.sleep(1)
    else:
        raise Exception("time out")

def val_pad_editable_then_clear(driver, pad_name, user, browser, file):
    val_request_pad(driver, pad_name, user, browser, file)
    clear_pad(driver, pad_name, user, browser, file)

@logmethod
def restart_memcached(host):
    import paramiko
    DOWN_CMD = "sudo -S /etc/init.d/memcached restart"
    KEY = paramiko.RSAKey.from_private_key_file("./ssh/opg-key")
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(host, username='cloud-user', port=2113, pkey=KEY)
        stdin, stdout, stderr = client.exec_command(DOWN_CMD)
        shutdown_result = stdout.read()
        if shutdown_result.find("Stopping memcached: [  OK  ]\r\nStarting memcached: [  OK  ]\r\n")==0:
            pass
        else:
            raise Exception("Check your domains, HOST: %s "(host))
    except Exception as e:
        print "Error: %s"(e)

@logmethod
def is_material_no_selfPAD(contract_no, item_no):
    api_result = return_value_by_pantherapi(contract_no, item_no)
    if api_result['status_code'] == 200:
        if api_result['data']['display_name'].rfind('Self Implementation') != -1:
            return True
        else: return False
    else: return False

@logmethod
def is_chinazone_on(contract_no, item_no, service_type):
    api_result = return_value_by_pantherapi(contract_no, item_no)
    if api_result['status_code'] == 200:
        if api_result['data']['service_type'].rfind(service_type) == 0:
            return True
        else: return False
    else: return False

@logmethod
def is_ca_allow_add_flag_on(contract_no, item_no):
    api_result = return_value_by_pantherapi(contract_no, item_no)
    if api_result['status_code'] == 200:
        if api_result['data']['product_info'][0]['allow_add_pad_flag'] == 'true':
            return True
        else: return False
    else: return False

@logmethod
def is_per_app_billing_method_unit_app_on(contract_no, item_no):
    api_result = return_value_by_pantherapi(contract_no, item_no)
    if api_result['status_code'] == 200:
        if api_result['data']['unit'] == 'APP':
            return True
        else: return False
    else: return False

@logmethod
def is_preset_edge_off(contract_no, item_no):
    api_result = return_value_by_pantherapi(contract_no, item_no)
    if api_result['status_code'] == 200:
        if api_result['data']['customer_using_private_certs'] == False:
            return True
        else: return False
    else: return False