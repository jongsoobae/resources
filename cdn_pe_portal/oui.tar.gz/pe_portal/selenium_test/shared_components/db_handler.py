#!/usr/bin/python
#-*-encoding: utf-8-*-

## Path
import time, requests, os, sys
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)

## Modules
from selenium_test.config_constants import *
from selenium_test.shared_components.decorator import *

## DB
import MySQLdb as mdb
import subprocess

## Global variables
CDB = mdb.connect(CDB_URL, CDB_USER, CDB_PASS, 'centraldb')
NGPDB = mdb.connect(NGPDB_URL, NGPDB_USER, NGPDB_PASS, 'spectrum')

#################################################   DBs   ##############################################################
@logmethod
def set_meterial_no(prv_contract_no, prv_item_no, material_no):
    # CA: 1028,1003,1006,1029,1133  DWA: 1115    CA SSL: 1291   DWA SSL:1292
    ngp_cursor = NGPDB.cursor()
    ngp_cursor.execute("UPDATE customer_item SET material_no=%s WHERE contract_no=%s AND item_no=%s" % (material_no, prv_contract_no, prv_item_no))
    NGPDB.commit()
    ngp_cursor.close()

@logmethod
def set_service_type(prv_contract_no, prv_item_no, service_type):
    # R5, R7, R8: China zone
    ngp_cursor = NGPDB.cursor()
    ngp_cursor.execute("UPDATE customer_item SET service_type='%s' WHERE contract_no=%s AND item_no=%s" % (service_type, prv_contract_no, prv_item_no))
    NGPDB.commit()
    ngp_cursor.close()

@logmethod
def set_allow_add_pad_flag(flag, cop_product_id):
    cdb_cursor = CDB.cursor()
    cdb_cursor.execute("UPDATE customer_product SET allow_add_pad_flag='%s' WHERE cop_product_id='%s' AND item_no=%s" % (flag, cop_product_id))
    CDB.commit()
    cdb_cursor.close()

@logmethod
def get_customer_item_unit():
    pass

@logmethod
def set_customer_item_unit():
    pass

@logmethod
def get_using_private_certs():
    pass

@logmethod
def set_using_private_certs():
    pass

@logmethod
def get_preset_edge_service():
    pass

@logmethod
def clear_db():
    CDB.close()
    NGPDB.close()

################################################   Actions   ###########################################################
def restart_memcached_in_spectrumapi_oui():
    restart_memcached(SPECTRUMAPI_URL.strip('https:').lstrip("//"))
    restart_memcached(PANTHER_API_URL.rstrip("/rest/").lstrip("https:").lstrip("//"))

@logmethod
def restart_memcached(host):
    import paramiko
    DOWN_CMD = "sudo -S /etc/init.d/memcached restart"
    KEY = paramiko.RSAKey.from_private_key_file("./ssh/opg-key")
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(host, username='cloud-user', port=2113, pkey=KEY)
        stdin, stdout, stderr = client.exec_command(DOWN_CMD)
        shutdown_result = stdout.read()
        if shutdown_result.find("Stopping memcached: [  OK  ]\r\nStarting memcached: [  OK  ]\r\n")==0:
            pass
        else:
            raise Exception("Check your domains, HOST: %s "(host))
    except Exception as e:
        print "Error: %s"(e)

@logmethod
def is_it_selfPAD(contract_no, item_no):
    PAD_API = PANTHER_API_URL + 'int/' + PANTHER_API_USER + ':' + PANTHER_API_PWD + '/product/view/' + contract_no + '-' + item_no + '/?apply_cache=False'
    resp = requests.get(PAD_API)
    api_result = resp.json()
    if resp.status_code == 200:
        if api_result['data']['display_name'].rfind('Self Implementation') != -1:
            return True
        else: return False
    else: return False

@logmethod
def is_it_chinazone(contract_no, item_no, service_type):
    PAD_API = PANTHER_API_URL + 'int/' + PANTHER_API_USER + ':' + PANTHER_API_PWD + '/product/view/' + contract_no + '-' + item_no + '/?apply_cache=False'
    resp = requests.get(PAD_API)
    api_result = resp.json()
    if resp.status_code == 200:
        if api_result['data']['service_type'].rfind(service_type) == 0:
            return True
        else: return False
    else: return False