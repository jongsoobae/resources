#!/usr/local/cdnet/shared/python/python2.6/bin/python
# -*- coding: utf-8 -*-

##############################################################################
#
# Date: 2015.11.2
# Author: hyunhwa.hong
# Description: for logging
#
##############################################################################

import os
import logging, logging.handlers

ROOT_DIR = os.path.dirname(__file__) + '/../logs/'
LOGFILE = ROOT_DIR + "self_provisioning.log"

class PubLog:
    log_handler = logging.handlers.RotatingFileHandler(LOGFILE, maxBytes=2**25, backupCount=5)
    log_handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s: %(message)s'))
    pub_log = logging.getLogger('PublicLog')
    pub_log.setLevel(logging.DEBUG)
    pub_log.addHandler(log_handler)

    def __init__(self):
        return self.pub_log

##############################################################################
#
# Usage:
#	import log_handler as log
#	log.PubLog.pub_log.error('ERROR')
#
##############################################################################