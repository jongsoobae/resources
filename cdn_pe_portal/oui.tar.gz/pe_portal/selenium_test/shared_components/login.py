#-*-encoding: utf-8-*-

import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium_test.config_constants import AURORA_URL, OUI_URL, BLOCK_URL_LIST
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium_test.shared_components.utils import chk_javascript_error_occurred, close_driver
from selenium_test.config_user_constants import SELF_PROV_USER,OUI_SUPER_USER
from selenium_test.shared_components.common_action import *

class OUILogin:
    def __init__(self, driver):
        """
        Notes:
          Load web driver to login
        Args:
          driver (WebDriver):
        Returns:
          Nothing.
        """
        self.driver = driver

    def login_with(self, user_info, oui_url=None):
        """
        Notes:
          Login with username and password.
        Args:
          username (string):
          password (string):
        Returns:
          Nothing.
        """

        if not oui_url:
            oui_url = OUI_URL
        if oui_url in BLOCK_URL_LIST:
            close_driver(self.driver)
            raise ValueError('%s can\'t be used for OUI_URL' % oui_url)

        self.driver.get(oui_url + "/login/?next=/")
        self.driver.find_element(By.NAME, "username").send_keys(user_info.get('username'))
        self.driver.find_element(By.NAME, "password").send_keys(user_info.get('password'))
        self.driver.find_element(By.NAME, "password").send_keys(Keys.RETURN)
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//h1[text() = 'Home']"))
        )
        chk_javascript_error_occurred(self.driver)

class SeleniumRC:
       LOGIN_URL = AURORA_URL + '/acounts/login/'
       DEFAULT_GUI_TIMEOUT = 5 # in second

       def get_driver(self, nodeurl, browserName, platform, node):
           self.nodeurl = nodeurl
           self.driver = webdriver.Remote(command_executor=self.nodeurl,desired_capabilities={ # rc
               "browserName": browserName, # 'internet explorer'
               "platform": platform,
               "node": node,
           })
           self.driver.maximize_window()
           return self.driver

def common_login_action(driver, user, password):
    driver.get(AURORA_URL + "/accounts/login/")
    driver.maximize_window()
    driver.find_element_by_id("id_username").clear()
    driver.find_element_by_id("id_username").send_keys(user)
    driver.find_element_by_id("id_password").clear()
    driver.find_element_by_id("id_password").send_keys(password)
    driver.find_element_by_id("id_login").click()
    if user.find('jimdo') >= 0 or user.find('megafon') or user.find('pvh') >= 0:
        for i in range(60):
            try:
                if u"Customer Support Center (CSC) : support@cdnetworks.com (US Toll Free) +1-877-937-4236 (UK/EMEA) +44-203-514-7501" == driver.find_element_by_css_selector("div.footer-text > p").text: break
            except: pass
            time.sleep(1)
    else:
        for i in range(60):
            try:
                if u"서비스 안내 및 가입 02-3441-0400 서비스 기술 및 운영 02-3441-0456" == driver.find_element_by_css_selector("div.footer-text > p").text: break
            except: pass
            time.sleep(1)
        else:
            raise Exception("time out")

def oui_login(driver):
    driver.get(OUI_URL + "/login/?next=/")
    driver.maximize_window()
    driver.find_element(By.NAME, "username").send_keys(OUI_SUPER_USER['username'])
    driver.find_element(By.NAME, "password").send_keys(OUI_SUPER_USER['password'])
    driver.find_element(By.NAME, "password").send_keys(Keys.RETURN)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "//h1[text() = 'Home']")))
    chk_javascript_error_occurred(driver)

def change_user_action(*argv):
    user = argv[0]
    password = argv[1]
    driver = webdriver.Firefox()
    driver.maximize_window()
    driver.get(AURORA_URL + "/accounts/login/")
    driver.find_element_by_id("id_username").clear()
    driver.find_element_by_id("id_username").send_keys(user)
    driver.find_element_by_id("id_password").clear()
    driver.find_element_by_id("id_password").send_keys(password)
    driver.find_element_by_id("id_login").click()
    if user.find('jimdo') >= 0 or user.find('megafon') or user.find('pvh') >= 0:
        for i in range(60):
            try:
                if u"Customer Support Center (CSC) : support@cdnetworks.com (US Toll Free) +1-877-937-4236 (UK/EMEA) +44-203-514-7501" == driver.find_element_by_css_selector("div.footer-text > p").text: break
            except: pass
            time.sleep(1)
    else:
        for i in range(60):
            try:
                if u"서비스 안내 및 가입 02-3441-0400 서비스 기술 및 운영 02-3441-0456" == driver.find_element_by_css_selector("div.footer-text > p").text: break
            except: pass
            time.sleep(1)
        else: raise Exception("time out")
    for arg in argv[2:]:
        exec arg
    driver.close()