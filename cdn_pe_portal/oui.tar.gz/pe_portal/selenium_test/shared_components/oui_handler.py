#!/usr/bin/python
#-*-encoding: utf-8-*-

## Path
import time, requests, os, sys
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__+'/..')))
sys.path.append(BASE_DIR)

###############################################   ACTION   #############################################################
@logmethod
@catch_exception(author="hyunhwa.hong")