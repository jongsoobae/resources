import smtplib
from email.mime.text import MIMEText
import os, sys

from selenium import webdriver
from selenium.webdriver import DesiredCapabilities

from selenium_test.config_constants import EMAIL_HOST, EMAIL_PORT, ADMIN_MAIL_ADDRESS,\
    SELENIUM_REMOTE_SERVER_IP, SELENIUM_REMOTE_SERVER_PORT, CI_SERVER_HOSTNAME, IMPLICITLY_WAIT, USE_REMOTE_SELENIUM_SERVER


def send_mail(sender=ADMIN_MAIL_ADDRESS, receiver='', title='', msg=''):
    s = smtplib.SMTP(host=EMAIL_HOST, port=EMAIL_PORT)
    msg = MIMEText(msg)
    msg['From'] = sender
    msg['To'] = receiver
    msg['Subject'] = title
    s.sendmail(sender, receiver, msg.as_string())


def get_web_driver(use_remote_selenium_server=None):
    if isinstance(use_remote_selenium_server, bool):
        use_remote_selenium_server = use_remote_selenium_server
    else:
        use_remote_selenium_server = USE_REMOTE_SELENIUM_SERVER

    if os.environ.get('HOSTNAME') == CI_SERVER_HOSTNAME or use_remote_selenium_server is True:
        driver = webdriver.Remote(
            command_executor="http://" + SELENIUM_REMOTE_SERVER_IP + ":" + SELENIUM_REMOTE_SERVER_PORT + "/wd/hub",
            desired_capabilities=DesiredCapabilities.FIREFOX
        )
        driver.implicitly_wait(IMPLICITLY_WAIT)
    else:
        driver = webdriver.Firefox()
        driver.implicitly_wait(IMPLICITLY_WAIT)

    return driver


def chk_javascript_error_occurred(driver):
    """
    Notes:
      Load web driver to login
    Args:
      driver (WebDriver):
    Returns:
      Nothing or raise Exception
    """
    js_error = driver.execute_script("return document.getElementsByTagName('body')[0].getAttribute('JSError');")
    if js_error is not None:
        close_driver(driver)
        raise Exception('JavaScript error occurred: "%s"' % str(js_error))


def close_driver(driver):
    """
    Notes:
      Close web driver
    Args:
      driver (WebDriver):
    Returns:
      Nothing
    """
    if driver.window_handles:
        driver.close()

def find(driver, string):
    if (driver.page_source).encode('utf-8').rfind(string) == -1:
        raise Exception("Can't find that string: " + string)

def handle_args(argv):
    args_list = {}
    # For grid
    if len(sys.argv) == 6:
        if len(sys.argv) != 6:
            raise Exception("Please remember usage: python {FILE} {NODE} {BROWSER} {OS} {PORT} {USER}")
        print ""
        print "usage: python {FILE} {NODE} {BROWSER} {OS} {PORT} {USER}"
        print "example: python Adding_CA_PAD.py 'http://linux-node.cdnetworks.com:5555/wd/hub/' 'firefox' 'LINUX' 5555 'test_ca_add_edit_priv@gala.cdn.com'"
        print ""
        # Arguments
        args_list['USER'] = sys.argv.pop()
        args_list['PORT'] = sys.argv.pop()
        args_list['OS'] = sys.argv.pop()
        args_list['BROWSER'] = sys.argv.pop()
        args_list['NODE'] = sys.argv.pop()
        return args_list
    # For only account
    elif len(sys.argv) == 2:
        print ""
        print "usage: python {FILE} {USER}"
        print "example: python Adding_CA_PAD.py 'test_ca_add_edit_priv@gala.cdn.com'"
        print ""
        # Arguements
        args_list['USER'] = sys.argv.pop()
        return args_list
    # For argument number
    else:
        args_list['USER'] = 'test_ca_add_edit_priv@gala.cdn.com'
        args_list['BROWSER'] = 'firefox'
        return args_list