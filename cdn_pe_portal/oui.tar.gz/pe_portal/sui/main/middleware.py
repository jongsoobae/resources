###
# Copyright (c) 2006-2007, Jared Kuolt
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without 
# modification, are permitted provided that the following conditions are met:
# 
#	 * Redistributions of source code must retain the above copyright notice, 
#	   this list of conditions and the following disclaimer.
#	 * Redistributions in binary form must reproduce the above copyright 
#	   notice, this list of conditions and the following disclaimer in the 
#	   documentation and/or other materials provided with the distribution.
#	 * Neither the name of the SuperJared.com nor the names of its 
#	   contributors may be used to endorse or promote products derived from 
#	   this software without specific prior written permission.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
###

from django.conf import settings
from django.contrib.auth.views import login
from django.http import HttpResponseRedirect, HttpResponseForbidden
import re

AUTHENTICATION_KEY_REQUIRED = [re.compile(r) for r in getattr(settings, 'AUTHENTICATION_KEY_REQUIRED', [])]
AUTHENTICATION_KEY_NOT_REQUIRED = [re.compile(r) for r in getattr(settings, 'AUTHENTICATION_KEY_NOT_REQUIRED', [])]

def matches_any(patterns, path):
	path = re.sub(r'^/','',path) # trim leading slash
	for pattern in patterns:
		if pattern.match(path):
			return True
	return False
	
class RequireAuthenticationKeyMiddleware(object):
	"""
	Based on Jared Kuolt's Require Login middleware.
	Restricts access to certain directories based on a static key passed in the query string (get variables).
	This is not ideal authentication but simple to use for scripts accessing data via rest.
	Reads three constants from settings.py:
	AUTHENTICATION_KEY_REQUIRED, AUTHENTICATION_KEY_NOT_REQUIRED, AUTHENTICATION_KEY_VALUE
	"""
	def process_request(self, request):
		AUTHENTICATION_KEY_VALUE = getattr(settings, 'AUTHENTICATION_KEY_VALUE', "")
		if (not request.GET or AUTHENTICATION_KEY_VALUE == ""
			or request.GET.get('auth_key') != AUTHENTICATION_KEY_VALUE) \
		and matches_any(AUTHENTICATION_KEY_REQUIRED, request.path) \
		and not matches_any(AUTHENTICATION_KEY_NOT_REQUIRED, request.path):
			return HttpResponseForbidden('403 Forbidden: Authorized access only')
