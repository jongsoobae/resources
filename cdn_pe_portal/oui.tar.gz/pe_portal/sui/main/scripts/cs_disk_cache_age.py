from datetime import timedelta
import time
from django.utils import simplejson
from django.db import transaction
from ci.constants import NO_REPLY, NOC, MAINTAINER
from ci.common.utils.mail import send_email
from sui.support.models import PollingSystemNode, PollingSystem, NodeInfo

min_acceptable_age = timedelta(hours=5)

lookup = {'h': 'hours', 's': 'seconds', 'm': 'minutes', 'd': 'days'}

#setup polling system for all nodes that were successful...
ps = PollingSystem(app=3, uri='/diskcache?path=/cache0/', response_type=2, response_modifier='.*: ([0-9]*), reallyOldDist|<td>.*data\.([0-9]*)&nbsp;&nbsp;</td><td align=center><nobr>.*&nbsp;&nbsp;</nobr></td><td><nobr>(.*)&nbsp;&nbsp;</nobr></td><td align=right>[0-9]+&nbsp;&nbsp;</td>')
ps.save()
for node in NodeInfo.objects.filter(offline=0,broken=0):
	PollingSystemNode(node=node,pollsystem=ps).save()

ps.state = 0
ps.save()

#wait till polling system completes...
ps_id = ps.id
start = time.time()
while PollingSystem.objects.get(id=ps_id).state < 2 and time.time() - start < 600:
	transaction.commit_unless_managed() # this lets new nodes/pops get noticed
	time.sleep(10)

PollingSystemNode()
objs=PollingSystemNode.objects.filter(pollsystem = ps_id, outcome=1)
pops = {}

skipped_nodes = []
below_min_acceptable = []
for obj in objs:
	try:
		rows=simplejson.loads(obj.response)
		worstTime = None
		lastTime = None
		prevLastTime = None
		maxFileFound = -1
		totalFiles = -1
		for row_double in rows:
			row = row_double[0]
			timedel = {}
			if row[0] and int(row[0]) > totalFiles:
				totalFiles = int(row[0])
			if row[1] and int(row[1]) > maxFileFound:
				maxFileFound = int(row[1])
			if row[2] != "":
				for val in row[2].split(","):
					timedel[lookup[val[-1:]]] = int(val[:-1])
				thisTime = timedelta(**timedel)
				if not worstTime or thisTime > worstTime:
					worstTime = thisTime
				if not lastTime or thisTime < lastTime:
					prevLastTime = lastTime
					lastTime = thisTime
				elif not prevLastTime or thisTime < prevLastTime:
					prevLastTime = thisTime #rollover could cause this to be hit
		if not pops.has_key(obj.node.pop):
			pops[obj.node.pop] = {'minOldest': timedelta(days=9999), 'maxOldest': timedelta(days=0), 'sumOldest': timedelta(days=0), 'minLatest': timedelta(days=9999), 'maxLatest': timedelta(days=0), 'sumLatest': timedelta(days=0), 'fullNodes': 0, 'unfullNodes': 0, 'emptyNodes': 0, 'nodes': 0}
		pops[obj.node.pop]['nodes'] += 1
		if maxFileFound +1 != totalFiles or worstTime == None:
			pops[obj.node.pop]['unfullNodes'] += 1
		elif worstTime != None:
			pops[obj.node.pop]['sumOldest'] += worstTime
			pops[obj.node.pop]['fullNodes'] += 1
			if pops[obj.node.pop]['minOldest'] > worstTime:
				pops[obj.node.pop]['minOldest'] = worstTime
			if pops[obj.node.pop]['maxOldest'] < worstTime:
				pops[obj.node.pop]['maxOldest'] = worstTime
			if worstTime < min_acceptable_age:
				below_min_acceptable.append( (obj.node.hostname, worstTime) )
		if prevLastTime == None or lastTime == None:
			pops[obj.node.pop]['emptyNodes'] += 1
		else:
			latest = prevLastTime - lastTime #how long last file was used for
			pops[obj.node.pop]['sumLatest'] += latest
			if pops[obj.node.pop]['minLatest'] > latest:
				pops[obj.node.pop]['minLatest'] = latest
			if pops[obj.node.pop]['maxLatest'] < latest:
				pops[obj.node.pop]['maxLatest'] = latest
	except:
		try:
			skipped_nodes.append(obj.node.name)
		except:
			pass

def oldestAvg(item):
	return item['sumOldest']/item['fullNodes'] if item['fullNodes'] > 0 else timedelta(0)

def latestAvg(item):
	return item['sumLatest']/(item['nodes']-item['emptyNodes']) if item['nodes']-item['emptyNodes'] > 0 else timedelta(0)

def convertTimeDeltaToSeconds(item):
	return item.days*24*60*60 + item.seconds

def move0ToEnd(val):
	return val if val > 0 else 999999999999

body = "The following is the age of the  oldest file on disk.\n\n"
body += "-----------------------------------------------------------------------------------------\n"
body += "PoP                        Avg                       Min                       Max\n"
body += "-----------------------------------------------------------------------------------------\n"
items=pops.items()
items.sort(lambda x,y:cmp(move0ToEnd(convertTimeDeltaToSeconds(oldestAvg(x[1]))), move0ToEnd(convertTimeDeltaToSeconds(oldestAvg(y[1])))))
for key, value in items:
	if value['fullNodes'] == 0:
		body +="%-20s*No nodes have full cache*\n" %(key.shortname)
		continue
	avg = oldestAvg(value)
	body += "%-20s%3d days, %2d hours        %3d days, %2d hours       %3d days, %2d hours\n" %(key.shortname, avg.days, avg.seconds/3600, value['minOldest'].days, value['minOldest'].seconds/3600, value['maxOldest'].days, value['maxOldest'].seconds/3600)

body += "\n\nThe following is how long it took to fill the last 2gig file\n\n"
body += "-----------------------------------------------------------------------------------------\n"
body += "PoP                        Avg                       Min                       Max\n"
body += "-----------------------------------------------------------------------------------------\n"
items.sort(lambda x,y:cmp(move0ToEnd(convertTimeDeltaToSeconds(latestAvg(x[1]))),move0ToEnd(convertTimeDeltaToSeconds(latestAvg(y[1])))))
for key, value in items:
        if value['nodes'] - value['emptyNodes'] <= 0:
                body +="%-20s*No nodes have filled a file*\n" %(key.shortname)
                continue
        avg = latestAvg(value)
        body += "%-20s%3d hours, %2d minutes     %3d hours, %2d minutes    %3d hours, %2d minutes\n" %(key.shortname, avg.days*24 + avg.seconds/3600, avg.seconds%3600/60, value['minLatest'].days *24 + value['minLatest'].seconds/3600, value['minLatest'].seconds%3600/60, value['maxLatest'].days*24 + value['maxLatest'].seconds/3600,value['maxLatest'].seconds%3600/60)

body += "\n\n-- End --"

if len(below_min_acceptable) > 0:
	message = "The following nodes are below acceptable cache disk churn time:\n\n"
        message += "-----------------------------------------------------------------------------------------\n"
        message += "Hostname                                  Oldest\n"
	message += "-----------------------------------------------------------------------------------------\n"
	for name, worst in below_min_acceptable:
		message += "%-40s%3d days, %2d hours, %2d minutes\n" %(name, worst.days, worst.seconds/3600, worst.seconds%3600/60)
	body = message + "\n\n" + body

send_email(NO_REPLY, [NOC], "[report] CS disk cache age",body)
