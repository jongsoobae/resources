from datetime import datetime
import time
from django.utils import simplejson
from django.db import transaction
from ci.constants import NO_REPLY, NOC, MAINTAINER
from ci.common.utils.mail import send_email
from sui.support.models import NodeInfo, PollingSystem, PollingSystemNode

backlog = 5

#logxfer directories that must be present
required_files = set([('/var/log/cdn/dns/stats','dns-service-stats-(.*).dat(\\.gz)?')])

#setup polling system for all nodes that were successful...
ps = PollingSystem(app=4,uri='/logsize?format=json&type=dns')
ps.save()
for node in NodeInfo.objects.filter(dns=True,broken=0):
	PollingSystemNode(node=node,pollsystem=ps).save()
ps.state = 0
ps.save()

#wait till polling system completes...
ps_id = ps.id
start = time.time()
while PollingSystem.objects.get(id=ps_id).state < 2 and time.time() - start < 600:
	transaction.commit_unless_managed() # this lets new nodes/pops get noticed
	time.sleep(10)

#reload ps...
ps = PollingSystem.objects.get(id=ps_id)
if ps.state != 2:
	#errror send email and quit!
	send_email(NO_REPLY, [MAINTAINER,"support@cdnetworks.com"],"[error] logxfer dns check failed", "Check support tools")
	import sys
	sys.exit()

message = ""

prob_nodes = 0
for n in ps.getUnreachableNodes():
	try:
		prev = PollingSystemNode.objects.filter(node = n.node, pollsystem__uri = ps.uri).exclude(pollsystem = ps).latest('id')
	except:
		prev = None
	if prev and prev.outcome == n.outcome:
		prob_nodes += 1
		message += "%s (%d): logxfer was unreachable\r\n\r\n" %(n.node.hostname, n.node.id)

for n in ps.getReachedNodes():
	issue = False
	try:
		try:
			prev = PollingSystemNode.objects.filter(node = n.node).exclude(pollsystem = ps).latest('id')
		except:
			prev = None
		required_found = 0
		folders = []
		resp = simplejson.loads(n.response)
		for rec in resp:
			folders.append((rec[0],rec[1]))
			if int(rec[2]) >= backlog or (int(rec[2]) < 0 and required_files.issuperset([rec[0]])):
				issue = True
				message += "%s (%d): Folder %s has %s files\r\n\r\n" %(n.node.hostname, n.node.id, rec[0], rec[2])
				n.outcome = 4
				n.save()
		if not required_files.issubset(folders):
			issue = True
			message += "%s (%d): Check config - missing required folder/search pattern\r\n\r\n" %(n.node.hostname, n.node.id)
			n.outcome = 4
			n.save()
	except:
		issue = True
		message += "%s (%d): Error in parsing response\r\n\r\n" %(n.node.hostname, n.node.id)
		n.outcome = 4
		n.save()
	if issue:
		prob_nodes += 1

if prob_nodes > 0:
	send_email(NO_REPLY, ["support@cdnetworks.com"], "[alert] logxfer: issues on %d dns nodes" %(prob_nodes), message)
