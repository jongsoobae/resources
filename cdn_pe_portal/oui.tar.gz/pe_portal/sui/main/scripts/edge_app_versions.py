from datetime import timedelta, datetime
import time
from django.utils import simplejson
from django.db import transaction
from ci.constants import NO_REPLY, NOC
from ci.common.utils.mail import send_email
from sui.support.models import PollingSystemNode, PollingSystem, NodeInfo

#apps to test, these should match the app numbers in support/models.py
apps = [0,1,2,4]
app_names = dict(PollingSystem.app_choices)
#setup polling system for all nodes that were successful...
ps = {}
for i in apps:
	ps[i] = PollingSystem(app=i, uri='/version?format=json', response_type=0)
	ps[i].save()
	for node in NodeInfo.objects.filter(broken=0):
		PollingSystemNode(node=node,pollsystem=ps[i]).save()
	ps[i].state = 0
	ps[i].save()

body = ""

#wait till polling system completes...
for i in apps:
	ps_id = ps[i].id
	start = time.time()
	while PollingSystem.objects.get(id=ps_id).state < 2 and time.time() - start < 600:
		transaction.commit_unless_managed() # this lets new nodes/pops get noticed
		time.sleep(10)
	objs=PollingSystemNode.objects.filter(pollsystem = ps_id, outcome=1)
	versions = {}
	for obj in objs:
		try:
			version=simplejson.loads(obj.response)[0]
		except:
			continue #no value found
		if not versions.has_key(version):
			versions[version] = 0
		versions[version] += 1
        body += "%s versions found in production:\n" %(app_names[i])
        body += "-----------------------------------------------------------------------------------------\n"
        body += "Version                                                                        Node Count\n"
        body += "-----------------------------------------------------------------------------------------\n"
	for version, count in sorted(versions.items()):
		body += "%-79s%9d\n" %(version,count)
	body += "\n\n"

body += "-- END --"
send_email(NO_REPLY, [NOC], "[report] edge application versions (%s)" %(datetime.now().strftime('%Y-%m-%d')),body)
