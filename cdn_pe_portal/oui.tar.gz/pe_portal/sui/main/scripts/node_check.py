from datetime import datetime
import time
from django.utils import simplejson
from django.db import transaction
from ci.constants import NO_REPLY, NOC, MAINTAINER
from ci.common.utils.mail import send_email
from sui.support.models import HttpChecker, PollingSystem, PollingSystemNode

STAT = "stat@cdnetworks.co.kr"
backlog = 5

#logxfer directories that must be present
required_files = set([(u'/var/log/cdn/http/request', u'request_\\d\\d\\d\\d\\d\\d\\d\\d_\\d\\d_(.*)_m.log(.\\d*)?(.gz)?'), (u'/var/log/cdn/http/cdnw', u'perhit_\\d\\d\\d\\d\\d\\d\\d\\d_\\d\\d_(.*)_m.log(.\\d*)?(.gz)?'), (u'/var/log/cdn/http/stats', u'http-stat(.*).dat(\\.gz)?'), (u"/var/log/cdn/http/stats-oui",u"http-stat(.*).dat(\\.gz)?"), (u'/var/log/cdn/http/stats-cdnw', u'http-stat(.*).dat(\\.gz)?')])

#determine if first of day...
first = HttpChecker.objects.filter(create_time__gt = datetime.now().replace(hour=0,minute=0,second=0,microsecond=0), email=True).count() == 0

#run http checker which sends out email if in bad state and a status email if email=True
HttpChecker(email=first).save()

#now use http checker to determine what logxfer boxes need to be up
hc_id=HttpChecker.objects.latest('id').id
start = time.time()
while HttpChecker.objects.get(id=hc_id).state < 2 and time.time() - start < 600:
	transaction.commit_unless_managed() # this lets new nodes/pops get noticed
	time.sleep(10)
hc = HttpChecker.objects.get(id=hc_id)
if hc.state != 2:
	#error send email and quit!
	send_email(NO_REPLY, [MAINTAINER,"support@cdnetworks.com"],"[error] logxfer check failed", "Check support tools")
	import sys
	sys.exit()

#setup polling system for all nodes that were successful...
ps = PollingSystem(app=4,uri='/logsize?format=json')
ps.save()
for httpnode in hc.getReachedNodes().filter(offline=0,broken=0,dead=0):
	PollingSystemNode(node=httpnode.node,pollsystem=ps).save()
ps.state = 0
ps.save()

#wait till polling system completes...
ps_id = ps.id
start = time.time()
while PollingSystem.objects.get(id=ps_id).state < 2 and time.time() - start < 600:
	transaction.commit_unless_managed() # this lets new nodes/pops get noticed
	time.sleep(10)

#reload ps...
ps = PollingSystem.objects.get(id=ps_id)
if ps.state != 2:
	#errror send email and quit!
	send_email(NO_REPLY, [MAINTAINER,"support@cdnetworks.com"],"[error] logxfer check failed", "Check support tools")
	import sys
	sys.exit()

message = ""

prob_nodes = 0
for n in ps.getUnreachableNodes():
	try:
		prev = PollingSystemNode.objects.filter(node = n.node, pollsystem__uri = ps.uri).exclude(pollsystem = ps).latest('id')
	except:
		prev = None
	if first or (prev and prev.outcome == n.outcome):
		prob_nodes += 1
		message += "%s (%d): logxfer was unreachable while CS appears to be online\r\n\r\n" %(n.node.hostname, n.node.id)

for n in ps.getReachedNodes():
	skip_prob = False
	issue = False
	try:
		try:
			prev = PollingSystemNode.objects.filter(node = n.node).exclude(pollsystem = ps).latest('id')
		except:
			prev = None
		if not first and prev and prev.outcome == 4:
			#node alerted last time so skip...
			skip_prob = True
		required_found = 0
		folders = []
		resp = simplejson.loads(n.response)
		for rec in resp:
			folders.append((rec[0],rec[1]))
			if int(rec[2]) >= backlog or (int(rec[2]) < 0 and required_files.issuperset([rec[0]])):
				if not skip_prob:
					issue = True
					message += "%s (%d): Folder %s has %s files\r\n\r\n" %(n.node.hostname, n.node.id, rec[0], rec[2])
				n.outcome = 4
				n.save()
		if not required_files.issubset(folders):
			if not skip_prob:
				issue = True
				message += "%s (%d): Check config - missing required folder/search pattern\r\n\r\n" %(n.node.hostname, n.node.id)
			n.outcome = 4
			n.save()
	except:
		if not skip_prob:
			issue = True
			message += "%s (%d): Error in parsing response\r\n\r\n" %(n.node.hostname, n.node.id)
		n.outcome = 4
		n.save()
	if issue:
		prob_nodes += 1

if prob_nodes > 0:
	send_email(NO_REPLY, [NOC, STAT], "[alert] logxfer: %s issues on %d nodes" %("all" if first else "new", prob_nodes), message)
elif first:
	send_email(NO_REPLY, [NOC], "[report] logxfer: no issues","No issues found")
