from datetime import timedelta, datetime
import time
from django.utils import simplejson
from django.db import transaction
from ci.constants import NO_REPLY, NOC, MAINTAINER
from ci.common.utils.mail import send_email
from sui.support.models import PollingSystemNode, PollingSystem, NodeInfo

min_lag = 10000

now = datetime.now()
today=datetime(now.year, now.month, now.day)
yesterday=today-timedelta(days=1)

ps_set = PollingSystem.objects.filter(app=3, uri='/history', response_type=2, response_modifier='lag\s+([0-9]+)ms.*<a[^>]*>([^<]*:[^<]*)<', state=2, create_time__gte=yesterday, create_time__lt=today)


objs=PollingSystemNode.objects.filter(pollsystem__in = ps_set, outcome=1, response__gt = '')

def cmp_length_max(x,y):
	res = cmp(len(x[1]),len(y[1]))
	if res == 0:
		res = cmp(max(x[1]),max(y[1]))
	return res
 
found_nodes = {}
for obj in objs:
	try:
		lag_times=simplejson.loads(obj.response)
		greater_times = list(found_nodes.get(obj.node.hostname,[]))
		for lag in lag_times:
			if int(lag[0][0]) > min_lag:
				greater_times.append( (int(lag[0][0]), lag[0][1]) )
		if greater_times:
			found_nodes[obj.node.hostname]= set(greater_times)
	except:
		continue #no value found

found_nodes=found_nodes.items()
found_nodes.sort(cmp=cmp_length_max, reverse=True)
subject = "[report] daily total CS nodes with lag (%s nodes)" %(str(len(found_nodes)))
if found_nodes:
	message = "Following nodes showed lag greater than %s milliseconds over entire day...\r\n\r\n" %(str(min_lag))
	for node in found_nodes:
		message += "%s lag for %s %s\r\n" %(str(len(node[1])), node[0], str(list(node[1])))
	message += "\r\n-- END --"
else:
	message = "No nodes found with lag over %s milliseconds for entire day.\r\n\r\nThis is either a really good day or a problem with the script!" %(str(min_lag))

send_email(NO_REPLY, ["eng-cs@cdnetworks.com", "ops-sd@cdnetworks.com"], subject, message)

