"""
handle support utilities that take processing power.
This does http requests and then records/analyzes results
Currently this handles the work for:
Preheat - preheat requested file
CacheChecker - check cache state across all online nodes
HttpChecker - check version/timestamp on all cs nodes
LookingGlass - get information over http from different apps on nodes

The functions in this script fall into 2 categories:
helper functions -  names begin with 'supporttools'
core script functions - two  - processRequests and main

For each request type a class which is a subclass of CurlHandler needs to be created.  The class has several methods will be called at different times to accomplish the request.
See that class definition below for further explanation about the functions there.

Each call to processRequests needs 1 parameter of a list of CurlHandlers.  
These lists are being created by the various Initialize methods.

To add a new task the main() function should be modified to add the task to the list passed into
processRequests.
"""


import urllib
import re
import gzip
import hashlib
from os import popen
import pycurl
from StringIO import StringIO
import logging
import time
import logging.handlers
from httplib import HTTPSConnection
from datetime import datetime, timedelta
from django.db import connection
from django.utils import simplejson
from django.core.exceptions import ObjectDoesNotExist
from sui.support.models import Preheat, \
    CacheChecker, \
    PreheatPopInfo, \
    CacheCheckerPopInfo, \
    CacheCheckerNodeFailures, \
    HttpChecker, \
    HttpCheckerNode, \
    HttpCheckerLastSeenNode, \
    HttpCheckerVersion,  \
    PollingSystem, \
    PollingSystemNode, \
    NodeInfo, \
    PopInfo
import socket
from ci.common.utils.mail import send_email
from sui.support.views.json import getHttpVersionsWithCount, getBadTimeStampNodes
from ci.constants import UI_AUTHENTICATION_KEY, API_ROOT, OUI_ROOT, NO_REPLY, NOC, MAINTAINER

#other constants for runtime settings
log_file = "/home/cdn/sui/scripts/logs/support_tools_long_running.log"
sleepOnAction = 0
sleepOnInactivity = 1
preheatMinimumFileLength = 1048576
chunkSize = 4194304 #4megs - 4 * 1024 * 1024
updateInfoTableInMinutes = 30
cleanupDBTableInMinutes = 1440 #once a day
deletePreheatAfterXMinutes = 10080 #once a week
deletePollingSystemAfterXMinutes = 10080 #once a week
deleteCacheCheckerAfterXMinutes = 10080 #once a week
deleteHttpCheckerAfterXMinutes = 10080 #once a week
socket.setdefaulttimeout(15) #this is for the httpconnections...

#Cache check uses cs_port, HttpChecker use cs_frontend_port
cs_port = 4040 #make None to use standard port (80), if numeric will try this port if fails then standard for cs page
cs_frontend_port = None #make None to use standard port (80), if numeric will try this port if fails then try standard port (80)
cs_password = "p@nther!"

#logging initialization
log_handler = logging.handlers.RotatingFileHandler(log_file, maxBytes=2**20, backupCount=5)
log_handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s: %(message)s'))
logging.getLogger('').setLevel(logging.INFO)
logging.getLogger('').addHandler(log_handler)

#this is a global variable to store authentications in
#the key should be (hostname,port) and value a string of cookies
#defaults should stored in "",port 
stored_auth = {("",80): "mecs=jjjeueufghsdfgalkjeeewqizzu", ("",4040): "mecs=jjjeueufghsdfgalkjeeewqizzu"}

def authGenerator(hostname):
    authTime=int(time.time())+10000
    auth=hashlib.sha1("p@nther!%s%s%s" %(hostname,authTime,socket.gethostbyname(socket.gethostname()))).hexdigest()
    return "authTime=%d;auth=%s" %(authTime,auth)


class CurlHandler():
    """
    This is an abstract  class that handles running a curl and parsing the response.

    There are 4 required functions to override:
        getOptions
        getUnsetOptions
        handleResponse
        handleError
    There are 2 optional function to override:
        finished
        handle302
    """
    def __init__(self, *args, **kwargs):
        """feel free to write a custom init for any advanced creation techniques.
        This one is just here to handle conversion from older uglier code.
        """
        self.authTried = False
        self.taskDict = kwargs.pop('taskDict',{})
        if self.taskDict == {} and len(args) == 1:
            self.taskDict = args[0]
    def getOptions(self):
        """per task sets curl option for request

        Needs to return a dictionary of all the curl options
        in order to successfully make the desired request`"""
        raise Exception("getOptions definition must be overriden")
    def getUnsetOptions(self):
        """this needs to back out getOptions settings 

        In order to restore the curl object to original state
        as they are recycled for speed"""
        raise Exception("handleError definition must be overriden")
    def handleResponse(self, responseText):
        """called on successful curl request
        
        This should handle parsing/storing the result
        as well returning a list of more CurlHandler objects
        if there are more curl's to run after this"""
        raise Exception("handleRespone definition must be overriden")
    def handleError(self, responseText, errorNumber, errorMessage):
        """called on failed curl request

        This should handle storing the failed result
        as well returning a list of more CurlHandler objects
        if there are more curl's to run after this"""
        raise Exception("handleError definition must be overriden")
    def finished(self):
        """Called after the appropiate handle function is called
        
        **Optional**
        The point of this is to do any final work before this object
        is no longer used.  Good spot to do any cleanup or response type
        independent work."""
        pass
    def handle302(self):
        """Called if response is 302, this is to handle any queries that require authorization

        **OPtional**
        The of this is to detect a redirect and try to reauthenticate. 
        """
        return None
    def getAuth(self,hostname, port):
        return authGenerator(hostname)
    def setAuth(self,hostname, port, value):
        if hostname not in ("",None):
            stored_auth[(hostname,port)] = value
    
class Auth(CurlHandler):
    def __init__(self, handler, hostname, port, url, data):
        self.handler = handler
        self.hostname = hostname
        self.port = port
        self.url = url
        self.data = data
    def getOptions(self):
        return {pycurl.URL: self.url,
            pycurl.POST: 1,
            pycurl.POSTFIELDS: urllib.urlencode(self.data.items()),
            pycurl.HTTPHEADER: [str("Host: " + self.hostname)],
        }
    def getUnsetOptions(self):
        return {pycurl.URL: "", pycurl.POST: 0, pycurl.POSTFIELDS: "", pycurl.HTTPHEADER: ["Host: "]}
    def handleResponse(self, responseText):
        #get the cookies and set them...
        cookies=re.compile("Set-Cookie:\s*([^;]+);").findall(responseText)
        if cookies:
            self.setAuth(self.hostname, self.port, "; ".join(cookies))
            return [self.handler] #add it back to stack to try again...
        return self.handleError("", 0, "")
    def handleError(self, responseText, errorNumber, errorMessage):
        self.handler.handleError("", 0, "")
        self.handler.finished()
        return None
def mergeDictionaries(dict1, dict2):
    """Merges dict2 and dict1, if both have same key keeps value from dict1"""
    ret = dict1.copy()
    for key in dict2:
        if not ret.has_key(key):
            ret[key] = dict2[key]
    return ret    

def convertJsonDateToDate(val):
    if (isinstance(val, str) or isinstance(val,unicode)) and \
            val[0] == "@" and \
            re.compile('^[@][0-9]{4}-[0-1][0-9]-[0-3][0-9]T[0-2][0-9]:[0-6][0-9]:[0-6][0-9]([+-][0-2][0-9]:[0-6][0-9])?[@]$').search(val) != None:
        return datetime.strptime(val[1:20],"%Y-%m-%dT%H:%M:%S")
    return None

def handleHttpConnection(domain, uri):
    try:
        conn = HTTPSConnection(domain)
        conn.request("GET", uri)
        resp = conn.getresponse()
        if resp.status == 200:
            val = simplejson.loads(resp.read())
            conn.close()
            return val
        logging.error("Failure retrieving " + domain + uri + ", response code: " + str(resp.status))
        conn.close()
        return resp.status
    except Exception, e:
        logging.error("Exception retrieving " + domain + uri + ", error message: " + e.message)
    return -1

def rewriteUri(rewrite_rules, uri):
    if not isinstance(rewrite_rules,str) or not isinstance(uri,str):
        return uri
    for rule in rewrite_rules.split("\n"):
        ruleParts = rule.split(" ",1)
        if len(ruleParts) != 2:
            continue
        recomp = re.compile(ruleParts[0])
        result = recomp.search(uri)
        if result == None:
            continue
        #if here this is the finalUri
        parts = ruleParts[1].split("$")
        finalUri = parts[0]
        for part in parts[1:]:
            if finalUri.endswith("\\") \
            and (len(finalUri) - len(finalUri.rstrip("\\"))) % 2 == 1:
                finalUri += "$" + part
            elif part[0].isdigit():
                finalUri += result.groups()[int(part[0])-1] + part[1:]
            else:
                finalUri += "$" + part
        return finalUri
    #if here no rewrite rules enforced!
    return uri

def modifyUri(path, drop_params, drop_precise_params_post_validation, case_insensitive_urls):
    retPath = path
    if drop_params == True:
        pos = retPath.find("?")
        if pos > 0:
                retPath = retPath[:pos]
    elif len(drop_precise_params_post_validation) >0:
        params_dropped = drop_precise_params_post_validation.split(",")
        for pos in range(len(params_dropped)*-1+1,1):
            #trim all elements of params dropped
            if params_dropped[pos*-1] != params_dropped[pos*-1].strip():
                params_dropped.append(params_dropped[pos*-1].strip())
                params_dropped.pop(pos*-1)
        pos = retPath.find("?")
        params_found = retPath[pos+1:]
        retPath = retPath[:pos]
        final_params = ""
        for param in params_found.split("&"):
            pos = param.find("=")
            if pos <= 0 or not param[:pos] in params_dropped:
                print "Pos: " + str(pos) + ", Param: " + param + ", Key: " + param[:pos]
                final_params += "&" + param
        if len(final_params) > 0:
            retPath += "?" + final_params[1:]
    if case_insensitive_urls == True:
        retPath = retPath.lower()
    return retPath

def customHeaders(custom_headers, unset=False, skip_headers = []):
    """Creates array of headers from string with each header on seperate line
    if unset=True then it will only take up to the : from each line to remove headers
    if skip_headers has any elements will not add any headers that  have a header equal (part of string before : matches)
    """
    ret = []
    if not isinstance(skip_headers,list):
        if skip_headers != None:
            skip_headers = [skip_headers]
        else:
            skip_headers = []
    if custom_headers != None and custom_headers != "":
        for line in custom_headers.split("\n"):
            pos = line.find(":")
            if pos > 0:
                if len(skip_headers) > 0:
                    skip = False
                    for head in skip_headers:
                        if str(line).lower().startswith(head.lower() + ":"):
                            skip = True
                    if skip:
                        continue
                if unset:
                    ret.append(str(line[:pos+1]))
                else:
                    ret.append(str(line))
    return ret

def updateInfoTables(fullLoad = False):

    if fullLoad == True:
        logging.info("Full NodeInfo/PopInfo update start")

    #update PopInfo
    url = "/rest/int/" + UI_AUTHENTICATION_KEY + "/pop/list/?info=1"
    if fullLoad != True:
        try:
            url += "&min_modify_date=" + \
                PopInfo.objects.order_by('-modify_time')[0].modify_time.isoformat()
        except:
            pass
    resp = handleHttpConnection(API_ROOT,url)
    if isinstance(resp, dict) and resp.has_key('data'):
        for pop in resp['data']:
            PopInfo(id = pop['id'], create_time = convertJsonDateToDate(pop['create_time']), modify_time = convertJsonDateToDate(pop['modify_time']), offline = pop['offline'], shortname = pop['short_name']).save()
    else:
        logging.error("Error retrieving PopInfo from " + API_ROOT + ", response: " + str(resp))

    #update NodeInfo
    url = "/rest/int/" + UI_AUTHENTICATION_KEY + "/node/list/?info=1"
    if fullLoad != True:
        try:
            url += "&min_modify_date=" + \
                NodeInfo.objects.order_by('-modify_time')[0].modify_time.isoformat()
        except:
            pass
    resp = handleHttpConnection(API_ROOT,url)

    if isinstance(resp, dict) and resp.has_key('data'):
        pop = None
        for node in resp['data']:
            if pop == None or pop.id != node['pop_id']:
                try:
                    pop = PopInfo.objects.get(id = node['pop_id'])
                except:
                    logging.error("UNKNOWN POP BAD STATE: " + str(node['pop_id']))
                    continue
            NodeInfo(id = node['id'], create_time = convertJsonDateToDate(node['create_time']), modify_time = convertJsonDateToDate(node['modify_time']), hostname = node['hostname'], ipv4_address = node['ipv4_address'], pop=pop, offline = node['offline'], broken = node['broken'], shield = False, dns = node['dns'], http = node['http'], buckets = node['buckets'], name = node['name']).save()    
    else:
        logging.error("Error retrieving NodeInfo from " + API_ROOT + ", response: " + str(resp))

    if fullLoad == True:
        logging.info("Full NodeInfo/PopInfo update end")

def cleanupDB():
    logging.info("Begin database cleanup")
    p = Preheat.objects.filter(modify_time__lt = datetime.now() - timedelta(minutes=deletePreheatAfterXMinutes))
    logging.info("Deleting " + str(p.count()) + " preheat results")
    for item in p:
        logging.info("Deleting item with id:" + str(item.id))
        item.delete()
        l = PollingSystem.objects.filter(modify_time__lt = datetime.now() - timedelta(minutes=deletePollingSystemAfterXMinutes))
    logging.info("Deleting " + str(l.count()) + " polling system results")
    for item in l:
        logging.info("Deleting item with id:" + str(item.id))
        item.delete()
    c = CacheChecker.objects.filter(modify_time__lt = datetime.now() - timedelta(minutes=deleteCacheCheckerAfterXMinutes))
    logging.info("Deleting " + str(c.count()) + " cache checker results")
    for item in c:
        logging.info("Deleting item with id:" + str(item.id))
        item.delete()
    h = HttpChecker.objects.filter(modify_time__lt = datetime.now() - timedelta(minutes=deleteHttpCheckerAfterXMinutes))
    logging.info("Deleting " + str(h.count()) + " http checker results")
    for item in h:
        logging.info("Deleting item with id:" + str(item.id))
        item.delete()
    logging.info("End database cleanup")

def supporttoolsParseHeader(returnedHeaders, verifyHeaders):
    """Takes a header and parses out the import headers for analysis
    based on the comma seperated list provided in verifyheaders"""
    dictHeaders = {}
    verifiedHeaders = verifyHeaders.split(",")
    for index in range(len(verifiedHeaders)):
        verifiedHeaders[index] = verifiedHeaders[index].strip()
    if returnedHeaders == "":
        return dictHeaders
    rawHeaders = returnedHeaders.split("\n")
    for loop in range(len(rawHeaders)):
        pos = rawHeaders[loop].find(":")
        if pos != -1:
            header = rawHeaders[loop][:pos].strip().lower()
            if header in verifiedHeaders:
                dictHeaders[header] = rawHeaders[loop][pos+1:].rstrip("\r").strip()
        else:
            #maybe response code...
            regex = re.compile('^HTTP/[0-9]+\.[0-9]+\s([0-9]{3})\s.*').search(rawHeaders[loop])
            if regex != None:
                #this is response code, due to redirect could be 2nd header
                dictHeaders = {}
                dictHeaders['response code'] = regex.groups()[0]
    dictHeaders['returned:header'] = returnedHeaders
    return dictHeaders

def supporttoolsCompareHeaders(dictHeader1, dictHeader2, verifiedHeaders, failIfMissing = False, caseInsensitive = True):
    """Compare two dictionaries based on the values in a set that are the keys that need to be compared"""
    
    if caseInsensitive:
        dict1 = {}
        for head in dictHeader1:
            dict1[head.lower()] = dictHeader1[head]
        dict2 = {}
        for head in dictHeader2:
            dict2[head.lower()] = dictHeader2[head]
    else:
        dict1 = dictHeader1
        dict2 = dictHeader2
    failedHeaders = ""
    for header_raw in verifiedHeaders.split(","):
        if caseInsensitive:
            header = header_raw.lower()
        else:
            header = header_raw
        if header.strip() == "":
            continue
        if not dict1.has_key(header.strip()) and not dict2.has_key(header.strip()):
            #neither has it so okay unless failIfMissing is on
            if failIfMissing == True:
                failedHeaders += header.strip() + "\n"
        elif not dict1.has_key(header.strip()) or not dict2.has_key(header.strip()):
            #one has it one doesn't, so failure
            failedHeaders += header.strip() + "\n"
        elif dict1[header.strip()].strip() == dict2[header.strip()].strip():
            pass
        else:
            #doesn't match
            failedHeaders += header.strip() + "\n"
    return failedHeaders.strip("\n")

def supporttoolsRemoveBody(responseText, addWarning=True, secondBody = False):
    pos = supporttoolsGetHeaderSeperator(responseText)
    if pos == -1:
        return ""
    if secondBody:
        pos2 = supporttoolsGetHeaderSeperator(responseText, pos)
        if pos2 > pos:
            pos = pos2
    ret = responseText[:pos].strip()
    #hacky way of notifying that body failed...
    if addWarning:
        ret += "\r\nWARNING: Head Request Failed"
    return ret

def supporttoolsRemoveHeader(responseText):
    pos = supporttoolsGetHeaderSeperator(responseText)
    if pos == -1:
        return responseText
    return responseText[pos+1:]

def supporttoolsGetHeaderSeperator(responseText, startPos = 0):
    sepLength = 4
    pos = responseText.find("\r\n\r\n", startPos)
    if pos == -1:
        pos = responseText.find("\n\n", startPos)
        sepLength = 2
    if pos != -1:
        pos += sepLength
    return pos

def preheatInitialize(preheat):
    preheatQueue = []
    for preheatRequest in preheat:
        preheatQueue.append(PreheatOrigin(taskDict={
            'preheat': preheatRequest,
            'minimumFileLength': preheat.minimumFileLength if not preheatRequest.override_file_size else 0,
            }))
        preheatRequest.state = 1
        preheatRequest.save()
    return preheatQueue

class PreheatOrigin(CurlHandler):
    def getOptions(self):
        try:
            path = rewriteUri(self.taskDict['preheat'].rewrite_rules, self.taskDict['preheat'].path)
            path = rewriteUri(self.taskDict['preheat'].rewrite_rules_post_validation, path)
            path = modifyUri(path, 
                self.taskDict['preheat'].drop_params, 
                self.taskDict['preheat'].drop_precise_params_post_validation, 
                self.taskDict['preheat'].case_insensitive_urls)
            ret = {pycurl.URL: str(self.taskDict['preheat'].protocol + \
                self.taskDict['preheat'].origin + path),
                pycurl.HTTPHEADER: customHeaders(self.taskDict['preheat'].custom_origin_headers)}
            ret[pycurl.HTTPHEADER].extend(customHeaders(self.taskDict['preheat'].custom_node_headers,skip_headers=['user-agent','host']))
            if ret[pycurl.HTTPHEADER] == None:
                ret.pop(pycurl.HTTPHEADER)
            if self.taskDict['preheat'].follow_redirect:
                ret[pycurl.FOLLOWLOCATION] = 1
            return ret
        except ObjectDoesNotExist:
            self.taskDict['preheat'].state = 5
            self.taskDict['preheat'].save()
            return None
    def getUnsetOptions(self):
        ret = {pycurl.URL: "",
            pycurl.FOLLOWLOCATION: 0,
            pycurl.HTTPHEADER: customHeaders(self.taskDict['preheat'].custom_origin_headers, unset = True)}
        ret[pycurl.HTTPHEADER].extend(customHeaders(self.taskDict['preheat'].custom_node_headers, unset= True, skip_headers=['user-agent','host']))
        if ret[pycurl.HTTPHEADER] == None:
            ret.pop(pycurl.HTTPHEADER)
        return ret
    def handleResponse(self, responseText):
        #parse header
        self.taskDict['preheat'].originHeader = responseText
        verifiedHeaders = self.taskDict['preheat'].verifyHeaders
        originDictHeaders = supporttoolsParseHeader(self.taskDict['preheat'].originHeader, verifiedHeaders)

        if type(self) == PreheatOrigin and \
            ( \
                not originDictHeaders.has_key('response code') or \
                originDictHeaders['response code'] == "" or \
                originDictHeaders['response code'][0] == "5" \
            ):
            #this is a head request now try a body to recover...
            return [PreheatOriginBody(self.taskDict)]

        #check that origin returned a response code
        if not originDictHeaders.has_key('response code') \
                or originDictHeaders['response code'] == "":
            self.taskDict['preheat'].state = 6
            self.taskDict['preheat'].save()
            return []
        try:
            if self.taskDict['minimumFileLength'] > 0:
                if not originDictHeaders.has_key('content-length'):
                    self.taskDict['preheat'].state = 6
                    self.taskDict['preheat'].save()
                    return []
                if int(originDictHeaders['content-length']) < \
                        self.taskDict['minimumFileLength']:
                    self.taskDict['preheat'].state = 11
                    self.taskDict['preheat'].save()
                    return []
        except ValueError:
            self.taskDict['preheat'].state = 6
            self.taskDict['preheat'].save()
            return []

        popQueue = []
        #get pops for pad...
        pops = PopInfo.objects.select_related()
        if pops.count() == 0:
            self.taskDict['preheat'].state = 7
            self.taskDict['preheat'].save()
            return []

        #if here no state change just save header...
        self.taskDict['preheat'].save()

        #per pop create pop info
        popQueue = []
        for pop in pops:
            preheatPopInfo = PreheatPopInfo(preheat = self.taskDict['preheat'],
                pop = pop)
            if pop.offline:
                preheatPopInfo.outcome = 1
                preheatPopInfo.save()
                continue

            #per pop add a random node to the list...
            try:
                #should I filter out failing here even? more complicated...
                preheatPopInfo.node = pop.nodeinfo_set.filter(offline=False).order_by('?')[0]
                preheatPopInfo.save()
                popQueue.append(PreheatPop({
                    'preheat': self.taskDict['preheat'],
                    'preheatPopInfo': preheatPopInfo,
                    'nodesTried': [preheatPopInfo.node.hostname] \
                    }))
            except IndexError:
                preheatPopInfo.outcome = 2
                preheatPopInfo.save()
        return popQueue
    def handleError(self, responseText, errorNumber, errorMessage):
        self.taskDict['preheat'].state = 8
        self.taskDict['preheat'].save()
        return []

class PreheatOriginBody(PreheatOrigin):
    def getOptions(self):
        resp = PreheatOrigin.getOptions(self)
        if resp != None:
            resp[pycurl.HTTPGET] = 1
        return resp
    def getUnsetOptions(self):
        resp = PreheatOrigin.getUnsetOptions(self)
        resp[pycurl.HTTPGET] = 0
        return resp
    def handleResponse(self, responseText):
        if self.taskDict['preheat'].follow_redirect:
            secondBody = True
        else:
            secondBody = False
        return PreheatOrigin.handleResponse(self,
            supporttoolsRemoveBody(responseText, secondBody = secondBody))
    def handleError(self, responseText, errorNumber, errorMessage):
        if self.taskDict['preheat'].follow_redirect:
            secondBody = True
        else:
            secondBody = False
        header = supporttoolsRemoveBody(responseText, secondBody = secondBody)
        if len(header) > 0:
            return PreheatOrigin.handleResponse(self, header)
        return PreheatOrigin.handleError(self,
            responseText,
            errorNumber,
            errorMessage)

class PreheatPop(CurlHandler):
    def getOptions(self):
        try:
            user_agent = "Mozilla/5.0 (compatible; Panther Cache Checker)"
            if self.taskDict['preheat'].custom_node_headers != None:
                regResp = re.compile("user-agent:([^\n]*)").search(self.taskDict['preheat'].custom_node_headers.lower())
                if regResp != None and regResp.groups()[0] != None:
                    user_agent = regResp.groups()[0].strip()
            ret = {pycurl.URL: str(self.taskDict['preheat'].protocol + \
                    self.taskDict['preheatPopInfo'].node.ipv4_address + \
                    self.taskDict['preheat'].path),
                pycurl.HTTPHEADER: [str("Host: " + self.taskDict['preheat'].pad)],
                pycurl.USERAGENT: user_agent 
                }
            ret[pycurl.HTTPHEADER].extend(customHeaders(self.taskDict['preheat'].custom_node_headers,skip_headers=['user-agent','host']))
            return ret
        except ObjectDoesNotExist:
            self.taskDict['preheatPopInfo'].outcome = 7
            self.taskDict['preheatPopInfo'].save()
            return None
    def getUnsetOptions(self):
        ret = {pycurl.URL: "",
            pycurl.HTTPHEADER: ["Host:"],
            pycurl.USERAGENT: "DEFAULT USER AGENT"}
        ret[pycurl.HTTPHEADER].extend(customHeaders(self.taskDict['preheat'].custom_node_headers,unset = True, skip_headers=['user-agent','host']))
        return ret
    def handleResponse(self, responseText):
        self.taskDict['preheatPopInfo'].header = responseText
        verifiedHeaders = self.taskDict['preheat'].verifyHeaders
        nodeDictHeaders = supporttoolsParseHeader(responseText, verifiedHeaders)

        if not nodeDictHeaders.has_key('response code') \
                or nodeDictHeaders['response code'] == "":
            #want to cycle to next one if possible so sending to handleError...
            return self.handleError(responseText, 0, "")
        else:
            #got a response...
            originDictHeaders = supporttoolsParseHeader(self.taskDict['preheat'].originHeader, verifiedHeaders)
            self.taskDict['preheatPopInfo'].failedHeaders = supporttoolsCompareHeaders( \
                originDictHeaders,
                nodeDictHeaders,
                verifiedHeaders)

            if self.taskDict['preheatPopInfo'].failedHeaders != "":
                self.taskDict['preheatPopInfo'].outcome = 4
            elif self.taskDict['preheat'].use_sub_files and nodeDictHeaders.has_key('content-length') \
                    and nodeDictHeaders['content-length'].isdigit() \
                    and int(nodeDictHeaders['content-length']) >= chunkSize:
                self.taskDict['chunk_file'] = 1
                self.taskDict['chunk_total'] = int(nodeDictHeaders['content-length']) / chunkSize
                if re.compile('X-Px:[^\n]*[(]origin[)]').search(self.taskDict['preheatPopInfo'].header) != None:
                    self.taskDict['from_origin'] = True
                else:
                    self.taskDict['from_origin'] = False
                return [PreheatPopChunk(self.taskDict)]
            elif re.compile('X-Px:[^\n]*[(]origin[)]').search(self.taskDict['preheatPopInfo'].header) != None:
                self.taskDict['preheatPopInfo'].outcome = 9
            else:
                self.taskDict['preheatPopInfo'].outcome = 5
        self.taskDict['preheatPopInfo'].save()
        return []
    def handleError(self, responseText, errorNumber, errorMessage):
        maximumTriesPerPop = 3

        #had an error connecting to a node...
        #will just try next node (until all nodes have been tried) assuming connection failed...
        popQueue = []
        if self.taskDict['preheatPopInfo'].pop.nodeinfo_set.filter(offline=False).count() <= \
                min(len(self.taskDict['nodesTried']),maximumTriesPerPop):
            #tried all nodes in pop fail...
            self.taskDict['preheatPopInfo'].outcome = 6
            self.taskDict['preheatPopInfo'].outcomeText = errorMessage
            self.taskDict['preheatPopInfo'].save()
            logging.info("Nodes attempted that were unreachable: " + str(self.taskDict['nodesTried']))

        else:
            #pick a new random node from pop...
            try:
                nodeGroup = self.taskDict['preheatPopInfo'].pop.nodeinfo_set.filter(offline=False). \
                    exclude(hostname__in=self.taskDict['nodesTried']).order_by('?')
                if nodeGroup == None or nodeGroup.count() == 0:
                        nodeGroup = self.taskDict['preheatPopInfo'].pop.nodeinfo_set.filter(broken=False). \
                            exclude(hostname__in=self.taskDict['nodesTried']).order_by('?')
                self.taskDict['preheatPopInfo'].node = nodeGroup[0]
                self.taskDict['preheatPopInfo'].save()
                self.taskDict['nodesTried'].append(self.taskDict['preheatPopInfo'].node.hostname)
                popQueue.append(self)
            except Exception:
                self.taskDict['preheatPopInfo'].outcome = 6
                logging.info("[Exception]Nodes attempted that were unreachable: " + str(self.taskDict['nodesTried']))
                self.taskDict['preheatPopInfo'].outcomeText = errorMessage
                self.taskDict['preheatPopInfo'].save()

        return popQueue
    def finished(self):
        preheat = self.taskDict['preheat']
        if PopInfo.objects.count() == \
                preheat.preheatpopinfo_set.exclude(outcome = 0).count() \
                and preheat.state in [0,1]:
            if preheat.preheatpopinfo_set.exclude(outcome__in = [1,2,9]).count() == 0:
                preheat.state = 2
            elif preheat.preheatpopinfo_set.exclude(outcome__in = [1,2,9,5]).count() == 0:
                preheat.state = 12
            elif preheat.preheatpopinfo_set.exclude(outcome__in = [1,2,9,5,4]).count() == 0:
                preheat.state = 13
            else:
                preheat.state = 9
            preheat.save()
            
class PreheatPopChunk(PreheatPop):
    def getOptions(self):
        try:
            ret = PreheatPop.getOptions(self)
            if not ret.has_key(pycurl.HTTPHEADER):
                ret[pycurl.HTTPHEADER] = []
            ret[pycurl.HTTPHEADER].append("Range: bytes=" + \
                str(chunkSize * self.taskDict['chunk_file']) + "-" + \
                str(chunkSize * self.taskDict['chunk_file']+1))
            ret[pycurl.NOBODY] = 0
            ret[pycurl.HTTPGET] = 1
            return ret
        except ObjectDoesNotExist:
            self.taskDict['preheatPopInfo'].outcome = 7
            self.taskDict['preheatPopInfo'].save()
            return None
    def getUnsetOptions(self):
        ret = PreheatPop.getUnsetOptions(self)
        if not ret.has_key(pycurl.HTTPHEADER):
            ret[pycurl.HTTPHEADER] = []
        ret[pycurl.HTTPHEADER].append("Range:")
        ret[pycurl.NOBODY] = 1
        ret[pycurl.HTTPGET] = 0
        return ret
    def handleResponse(self, responseText):
        #find end of header
        body = supporttoolsRemoveHeader(responseText)
        nodeDictHeaders = supporttoolsParseHeader(supporttoolsRemoveBody(responseText, False), "response code")
        if not nodeDictHeaders.has_key('response code') or nodeDictHeaders['response code'] != "206" or len(body) != 1:
            return self.handleError(responseText, 0, "")
        if self.taskDict['chunk_file'] < self.taskDict['chunk_total']:
            self.taskDict['chunk_file'] += 1
            return [self]
        if self.taskDict.get('from_origin') == True:
            self.taskDict['preheatPopInfo'].outcome = 9
        else:
            self.taskDict['preheatPopInfo'].outcome = 5
        self.taskDict['preheatPopInfo'].save()
        return []
    def handleError(self, responseText, errorNumber, errorMessage):
        #had an error with response, know node is good cause chunk 0 pulled...
        self.taskDict['preheatPopInfo'].outcome = 8
        self.taskDict['preheatPopInfo'].outcomeText = errorMessage
        self.taskDict['preheatPopInfo'].save()
        return []

def cacheInitialize(cache):
    cacheQueue = []
    for cacheRequest in cache:
        cacheQueue.append(CacheOrigin({
            'cs_port': cs_port,
            'cache': cacheRequest,
            }))
        cacheRequest.state = 1
        cacheRequest.save()
    return cacheQueue

class CacheOrigin(CurlHandler):
    def getOptions(self):
        try:
            path = rewriteUri(self.taskDict['cache'].rewrite_rules, self.taskDict['cache'].path)
            path = rewriteUri(self.taskDict['cache'].rewrite_rules_post_validation, path)
            path = modifyUri(path, 
                self.taskDict['cache'].drop_params, 
                self.taskDict['cache'].drop_precise_params_post_validation, 
                self.taskDict['cache'].case_insensitive_urls)
            resp = {pycurl.URL: str(self.taskDict['cache'].protocol + \
                self.taskDict['cache'].origin + path),
                pycurl.HTTPHEADER: customHeaders(self.taskDict['cache'].custom_origin_headers)}
            resp[pycurl.HTTPHEADER].extend(customHeaders(self.taskDict['cache'].custom_node_headers,skip_headers=['user-agent','host']))
            if resp[pycurl.HTTPHEADER] == None:
                resp.pop(pycurl.HTTPHEADER)
            if self.taskDict['cache'].follow_redirect:
                resp[pycurl.FOLLOWLOCATION] = 1
            return resp
        except ObjectDoesNotExist:
            self.taskDict['cache'].state = 5
            self.taskDict['cache'].save()
            return None
    def getUnsetOptions(self):
        ret = {pycurl.URL: "",
            pycurl.HTTPGET: 0,
            pycurl.FOLLOWLOCATION: 0,
            pycurl.HTTPHEADER: customHeaders(self.taskDict['cache'].custom_origin_headers, unset = True)}
        ret[pycurl.HTTPHEADER].extend(customHeaders(self.taskDict['cache'].custom_node_headers,unset = True, skip_headers=['user-agent','host']))
        if ret[pycurl.HTTPHEADER] == None:
            ret.pop(pycurl.HTTPHEADER)
        return ret
    def handleResponse(self, responseText):
        verifiedHeaders = self.taskDict['cache'].verifyHeaders
        self.taskDict['cache'].originHeader = responseText
        originDictHeaders = supporttoolsParseHeader(responseText, verifiedHeaders)

        if type(self) == CacheOrigin and \
            ( \
                not originDictHeaders.has_key('response code') or \
                originDictHeaders['response code'] == "" or \
                originDictHeaders['response code'][0] == "5" \
            ):
            #this is a head request now try a body to recover...
            return [CacheOriginBody(self.taskDict)]

        if not originDictHeaders.has_key('response code') \
                or originDictHeaders['response code'] == "":
            #error getting origin response...
            self.taskDict['cache'].state = 6
            self.taskDict['cache'].save()
            return []


        nodes = NodeInfo.objects.select_related()
            #filter(pop__serviceinfo__dns_prefix=self.taskDict['cache'].service.dns_prefix). \
            #select_related()
        self.taskDict['cache'].totalNodes = nodes.count()
        self.taskDict['cache'].activeNodes = nodes.filter(offline=False).filter(pop__offline=False).count()

        #for each pop make cacheCheckerPopInfo object for nodes to use...
        popDict = {}
        for pop in PopInfo.objects.select_related():
            popDict[pop.id] = CacheCheckerPopInfo(cachechecker = self.taskDict['cache'],
                pop = pop)
            if pop.offline:
                popDict[pop.id].outcome = 1
            elif pop.nodeinfo_set.filter(offline=False).count() == 0:
                popDict[pop.id].outcome = 2
            popDict[pop.id].save()

        if len(popDict) == 0:
            self.taskDict['cache'].state = 7
            self.taskDict['cache'].save()
            return []

        #for each node add to queue
        nodeQueue = []
        for node in nodes:
            nodeQueue.append(CacheNode({
                'cs_port': self.taskDict['cs_port'],
                'cache': self.taskDict['cache'],
                'node': node,
                'cachePopInfo': popDict[node.pop.id],
                }))
        return nodeQueue
    def handleError(self, responseText, errorNumber, errorMessage):
        self.taskDict['cache'].state = 8
        self.taskDict['cache'].save()
        #do not record on pop level because
        #pop will go to next affinity if it can not reach the higher step affinity
        #pop  unreachable only really occurs if
        #none of the 5 affinity nodes are reachable
        return []

class CacheOriginBody(CacheOrigin):
    def getOptions(self):
        resp = CacheOrigin.getOptions(self)
        if resp != None:
            resp[pycurl.HTTPGET] = 1
        return resp
    def getUnsetOptions(self):
        resp = CacheOrigin.getUnsetOptions(self)
        resp[pycurl.HTTPGET] = 0
        return resp
    def handleResponse(self, responseText):
        if self.taskDict['cache'].follow_redirect:
            secondBody = True
        else:
            secondBody = False
        return CacheOrigin.handleResponse(self,
            supporttoolsRemoveBody(responseText, secondBody = secondBody))
    def handleError(self, responseText, errorNumber, errorMessage):
        if self.taskDict['cache'].follow_redirect:
            secondBody = True
        else:
            secondBody = False
        header = supporttoolsRemoveBody(responseText, secondBody = secondBody)
        if len(header) > 0:
            return CacheOrigin.handleResponse(self,header)
        return CacheOrigin.handleError(self,
            responseText,
            errorNumber,
            errorMessage)

class CacheNode(CurlHandler):
    def getOptions(self):
        try:
            user_agent = "Mozilla/5.0 (compatible; Panther Cache Checker)"
            if self.taskDict['cache'].custom_node_headers != None:
                regResp = re.compile("user-agent:([^\n]*)").search(self.taskDict['cache'].custom_node_headers.lower())
                if regResp != None and regResp.groups()[0] != None:
                    user_agent = regResp.groups()[0].strip()
            ret = {pycurl.URL: str("http://" + \
                self.taskDict['node'].ipv4_address + \
                ":"+ str(self.taskDict.get("cs_port") if self.taskDict.get("cs_port") else 80) + \
                "/lookuppad?" + \
                urllib.urlencode({"url":self.taskDict['cache'].submittedUrl})),
                pycurl.HTTPHEADER: [str("Host: " + self.taskDict['node'].hostname),
                    "Connection: Keep-Alive"],
                pycurl.NOBODY: 0,
                pycurl.HEADER: 0,
                pycurl.HTTPGET: 1,
                pycurl.COOKIE: self.getAuth(self.taskDict['node'].hostname,self.taskDict.get("cs_port") if self.taskDict.get("cs_port") else 80),
                pycurl.USERAGENT: user_agent,
            }
            ret[pycurl.HTTPHEADER].extend(customHeaders(self.taskDict['cache'].custom_node_headers,skip_headers=['user-agent','host']))
            return ret
        except ObjectDoesNotExist:
            CacheCheckerNodeFailures(cachechecker = self.taskDict['cache'],
                node = self.taskDict['node'],
                offline = self.taskDict['node'].offline,
                outcome = 7).save()
            return None
    def getUnsetOptions(self):
        ret = {pycurl.URL: "",
            pycurl.HTTPHEADER: ["Connection:","Host:"],
            pycurl.NOBODY: 1,
            pycurl.HTTPGET: 0,
            pycurl.HEADER: 1,
            pycurl.COOKIE: "",
            pycurl.USERAGENT: "DEFAULT USER AGENT"}
        ret[pycurl.HTTPHEADER].extend(customHeaders(self.taskDict['cache'].custom_node_headers, unset=True, skip_headers=['user-agent','host']))
        return ret
    def handleResponse(self, responseText):
        self.taskDict['parseOutcome'] = self.parseResponse(responseText)
        if self.taskDict['parseOutcome'] < 0:
            #node level failure record it
            self.taskDict['nodeFailure'] = CacheCheckerNodeFailures(cachechecker = self.taskDict['cache'],
                node = self.taskDict['node'],
                offline = self.taskDict['node'].offline,
                outcome = abs(self.taskDict['parseOutcome']))
            if self.taskDict.has_key('nodeHeaders'):
                self.taskDict['nodeFailure'].header = self.taskDict['nodeHeaders']
            if self.taskDict.has_key('outcomeText'):
                self.taskDict['nodeFailure'].outcomeText = self.taskDict['outcomeText']
            if self.taskDict.has_key('failedHeaders'):
                self.taskDict['nodeFailure'].failedHeaders = self.taskDict['failedHeaders']
            if self.taskDict.has_key('fetchTime'):
                self.taskDict['nodeFailure'].fetchTime = self.taskDict['fetchTime']

        if self.taskDict['cache'].use_sub_files and self.taskDict.has_key('nodeDictHeaders') \
                and self.taskDict['nodeDictHeaders'].has_key('content-length') \
                and self.taskDict['nodeDictHeaders']['content-length'].isdigit() \
                and int(self.taskDict['nodeDictHeaders']['content-length']) >= chunkSize \
                and self.taskDict['parseOutcome'] in (-5, -6, -7, -4, -8, -9, -10, 1):
            self.taskDict['chunk_file'] = 1
            self.taskDict['chunk_total'] = int(self.taskDict['nodeDictHeaders']['content-length']) / chunkSize
            return [CacheNodeChunk(self.taskDict)]

        return self.recordResponse()
    def handleError(self, responseText, errorNumber, errorMessage):
        if isinstance(self.taskDict.get("cs_port"),int):
            #cs port failed try standard port (80)
            self.taskDict['cs_port'] = None
            return [self]
        CacheCheckerNodeFailures(cachechecker = self.taskDict['cache'],
            node = self.taskDict['node'],
            offline = self.taskDict['node'].offline,
            outcome = 3,
            outcomeText = errorMessage
        ).save()

        return []
    def handle302(self):
        if not self.authTried:
            self.authTried = True
            url = str("http://%s:%d%s" %(self.taskDict['node'].hostname, self.taskDict.get("cs_port") if self.taskDict.get("cs_port") else 80, "/login"))
            return [Auth(self, self.taskDict['node'].hostname, self.taskDict.get("cs_port") if self.taskDict.get("cs_port") else 80, url, {"password": cs_password})]
        return None
    def parseResponse(self, responseText):
        #this is a little sloppy to allow node and nodeChunk to both process same page
        # response <0 response is a node failure response, otherwise it is a cache checker level response
        # 1 = upto date online
        # 2 = not cached
        # 0 = unknown state?!?
        verifiedHeaders = self.taskDict['cache'].verifyHeaders
        if responseText == "":
            return -3
            #do not record on pop level because
            #pop will go to next affinity if it can not reach the higher step affinity
            #pop  unreachable only really occurs if
            #none of the 5 affinity nodes are reachable

        #make sure machine is reporting correct node name...
        nodeName = re.compile('<html><head><title>[[]([^]]*)[]].*</title>').search(responseText)
        if nodeName == None or nodeName.groups()[0] != self.taskDict['node'].name:
            self.taskDict['outcomeText'] = "Node is redirecting traffic"
            return -3
        #find affinity hash level for this node
        affinityStep = re.compile('<tr[^>]*><TD[^>]*>[0-9]*</TD><TD[^>]*>[0-9]*</TD><TD[^>]*>([0-9])</TD><TD[^>]*>[^<]*</TD><TD[^>]*>[^<]*</TD><TD[^>]*>[^<]*</TD><TD[^>]*><a[^>]*>'  + self.taskDict['node'].hostname + '</a>').search(responseText)
        if affinityStep == None:
            #shield is a hack cause at this time you can not determine
            #cache groups and affinity node can be wrong in a shield
            affinityStep = 5 #out of bounds
        else:
            try:
                affinityStep = int(affinityStep.groups()[0])
                #step so we can see furthest step found
                if affinityStep == \
                        self.taskDict['cachePopInfo'].affinityStep \
                        and self.taskDict['cachePopInfo'].node != self.taskDict['node']:
                    logging.error("Affinity step (" + \
                        str(affinityStep) + ") for node " + \
                        self.taskDict['node'].hostname + \
                        " is second occurance of" \
                        " this affinity step for the pop")
            except ValueError:
                affinityStep = 5
        if affinityStep < self.taskDict['cachePopInfo'].affinityStep:
            #sets affinity step node, outcome still needs to be set
            self.taskDict['cachePopInfo'].affinityStep = affinityStep
            self.taskDict['cachePopInfo'].node = self.taskDict['node']
            self.taskDict['cachePopInfo'].save()
        #get headers from html...
        fetchHeaders = {}

        #find received headers section from http response
        regResp = re.compile("received-headers:\s*[{](.*)[}]").search(responseText)
        lastKey = ""
        nodeHeaders = ""
        if regResp != None:
            for val in regResp.groups()[0].split(","):
                pos = val.find("=")
                if  pos == -1 and lastKey != "":
                    fetchHeaders[lastKey] += "," + val
                    nodeHeaders += "," + val
                else:
                    lastKey = val[:pos].strip()
                    fetchHeaders[lastKey] = val[pos+1:]
                    if lastKey != "" or fetchHeaders[lastKey] != "":
                        nodeHeaders += "\n" + lastKey + ": " + fetchHeaders[lastKey]
        #get contentLengthTotal for chunked files...
        regResp = re.compile("contentLengthTotal:([^\n]*)",re.S + re.I).search(responseText)
        if regResp != None:
            fetchHeaders['content-length'] = regResp.groups()[0].strip()
            nodeHeaders += "\ncontent-length: " + fetchHeaders['content-length']
        else:
            regResp = re.compile("decompressed content length:\s*([0-9]+)",re.S + re.I).search(responseText)
            if regResp != None:
                fetchHeaders['content-length'] = regResp.groups()[0].strip()
                nodeHeaders += "\ncontent-length: " + fetchHeaders['content-length']

        #search for headers on their own line...
        for header in verifiedHeaders.split(","):
            if fetchHeaders.has_key(header):
                #already found key from received headers section
                continue
            regResp = re.compile(header.strip() + ":([^\n]*)",re.S + re.I).search(responseText)
            if regResp != None:
                fetchHeaders[header.strip()] = regResp.groups()[0].strip()
                nodeHeaders += "\n" + header.strip() + ": " + fetchHeaders[header.strip()]

        if len(fetchHeaders) == 0:
            #not cached
            return 2

        #remove leading \n
        nodeHeaders = nodeHeaders[1:]
        self.taskDict['nodeHeaders'] = nodeHeaders

        #find fetch time...
        try:
            fetchTime = re.compile("fetchTime:\s*([0-9]{4}-[0-1][0-9]-[0-3][0-9]\s[0-2][0-9]:[0-6][0-9]:[0-6][0-9])\s[+][0-2][0-9]:[0-6][0-9]\s*[(]",re.S + re.I).search(responseText)
            if fetchTime != None:
                fetchTime = datetime.strptime(fetchTime.groups()[0],"%Y-%m-%d %H:%M:%S")
            if fetchTime == None:
                #try second date format, 1.2.3 and 1.2.2 have different formats
                fetchTime = re.compile("fetchTime:\s*([0-3][0-9][A-Z][a-z]{2}[0-9]{2}\s[0-2][0-9]:[0-6][0-9]:[0-6][0-9])\s*[(]",re.S + re.I).search(responseText)
                if fetchTime != None:
                    fetchTime = datetime.strptime(fetchTime.groups()[0],"%d%b%y %H:%M:%S")
            if fetchTime != None:
                if fetchTime == datetime(1970,1,1):
                    #this is start of time,
                    #error found in production on a cs 1.2.28 node
                    self.taskDict['outcomeText'] = "Fetch time set to epoch 1970/01/01 00:00:00"
                    return -11
                elif self.taskDict['cache'].oldestFetchTime == None or \
                        fetchTime < self.taskDict['cache'].oldestFetchTime:
                    self.taskDict['cache'].oldestFetchTime = fetchTime
                    self.taskDict['cache'].oldestFetchNode = self.taskDict['node']
                    self.taskDict['cache'].save()
                self.taskDict['fetchTime'] = fetchTime
            else:
                return -11
        except ValueError:
            return -11

        #find if expired...
        expired = False
        if re.compile('expired:\s*true').search(responseText) != None:
            expired = True

        #find if flushed...
        flushed = False
        try:
            flushTime = re.compile("Flush time:\s*([0-9]{4}-[0-1][0-9]-[0-3][0-9]\s[0-2][0-9]:[0-6][0-9]:[0-6][0-9])\s[+][0-2][0-9]:[0-6][0-9]\s*[<]",re.S + re.I).search(responseText)
            if flushTime != None:
                flushTime = datetime.strptime(flushTime.groups()[0],"%Y-%m-%d %H:%M:%S")
                if fetchTime != None and flushTime >= fetchTime:
                    flushed = True
        except ValueError:
            pass

        originDictHeaders = supporttoolsParseHeader(self.taskDict['cache'].originHeader, verifiedHeaders)
        failedHeaders = \
            supporttoolsCompareHeaders(originDictHeaders, fetchHeaders, verifiedHeaders)
        self.taskDict['failedHeaders'] = failedHeaders
        self.taskDict['nodeDictHeaders'] = fetchHeaders

        if failedHeaders != "":
            if flushed and expired:
                return -5
            elif flushed:
                return -6
            elif expired:
                return -7
            else:
                return -4
        elif flushed or expired:
            if flushed and expired:
                return -8
            elif flushed:
                return -9
            elif expired:
                return -10
        else:
            return 1
        return 0
    def recordResponse(self):
        #does saving final result so that chunk/non-chunk always consistent values
        if self.taskDict.has_key('nodeFailure'):
            if self.taskDict['parseOutcome'] == 4:
                self.taskDict['nodeFailure'].partialCache = True
            self.taskDict['nodeFailure'].save()
            if self.taskDict['node'] == self.taskDict['cachePopInfo'].node and \
                    not self.taskDict['cachePopInfo'].outcome in [1,2]:
                self.taskDict['cachePopInfo'].nodefailure = self.taskDict['nodeFailure']
                self.taskDict['cachePopInfo'].partialCache = self.taskDict['nodeFailure'].partialCache
                if self.taskDict.has_key('failedHeaders'):
                    self.taskDict['cachePopInfo'].failedHeaders = self.taskDict['failedHeaders']
                if self.taskDict['nodeFailure'].outcome == 5:
                    self.taskDict['cachePopInfo'].outcome = 9
                if self.taskDict['nodeFailure'].outcome == 6:
                    self.taskDict['cachePopInfo'].outcome = 10
                if self.taskDict['nodeFailure'].outcome == 7:
                    self.taskDict['cachePopInfo'].outcome = 11
                if self.taskDict['nodeFailure'].outcome == 4:
                    self.taskDict['cachePopInfo'].outcome = 4
                if self.taskDict['nodeFailure'].outcome in [8, 9, 10]:
                    self.taskDict['cachePopInfo'].outcome = 5
                self.taskDict['cachePopInfo'].save()
        elif self.taskDict['parseOutcome'] == 1:
            #upto date cached
            if self.taskDict['node'].offline:
                self.taskDict['cache'].uptoDateOfflineNodes += 1
            else:
                self.taskDict['cache'].uptoDateActiveNodes += 1
            self.taskDict['cache'].save()
            if self.taskDict['node'] == self.taskDict['cachePopInfo'].node and \
                    not self.taskDict['cachePopInfo'].outcome in [1,2]:
                self.taskDict['cachePopInfo'].outcome = 5
                self.taskDict['cachePopInfo'].partialCache = False
                self.taskDict['cachePopInfo'].save()
        elif self.taskDict['parseOutcome'] == 2:
            #not cached
            if self.taskDict['node'].offline:
                self.taskDict['cache'].notCachedOfflineNodes += 1
            else:
                   self.taskDict['cache'].notCachedActiveNodes += 1
            self.taskDict['cache'].save()
            if self.taskDict['node'] == self.taskDict['cachePopInfo'].node and \
                    not self.taskDict['cachePopInfo'].outcome in [1,2]:
                self.taskDict['cachePopInfo'].outcome = 8
                self.taskDict['cachePopInfo'].partialCache = False
                self.taskDict['cachePopInfo'].save()
        elif self.taskDict['parseOutcome'] == 3:
            #partial cached..
            if self.taskDict['node'].offline:
                self.taskDict['cache'].partialCachedOfflineNodes += 1
            else:
                self.taskDict['cache'].partialCachedActiveNodes += 1
            self.taskDict['cache'].save()
            if self.taskDict['node'] == self.taskDict['cachePopInfo'].node and \
                    not self.taskDict['cachePopInfo'].outcome in [1,2]:
                self.taskDict['cachePopInfo'].outcome = 5
                self.taskDict['cachePopInfo'].partialCache = True
                self.taskDict['cachePopInfo'].save()
        else:
            #bad state...
            self.taskDict['nodeFailure'] = CacheCheckerNodeFailures(cachechecker = self.taskDict['cache'],
                node = self.taskDict['node'],
                offline = self.taskDict['node'].offline,
                outcome = 12)
            self.taskDict['nodeFailure'].save()
        return []
    def finished(self):
        cache = self.taskDict['cache']
        if cache.totalNodes == \
                                cache.cachecheckernodefailures_set.count() + \
                                cache.uptoDateNodes() + \
                                cache.partialCachedNodes() + \
                                cache.notCachedNodes():
                        #done processing all nodes for request...
            #first check that all pads are correct...
            for cachePopInfo in cache.cachecheckerpopinfo_set.filter(outcome = 0):
                cachePopInfo.outcome = 12
                cachePopInfo.save()

            if cache.state == 0 or cache.state == 1:
                cache.state = 2
                cache.save()
    
class CacheNodeChunk(CacheNode):
    def getOptions(self):
        try:
            ret = CacheNode.getOptions(self)
            pos =ret[pycurl.URL].find("/lookuppad/")
            if pos < 0:
                #force failure is fine...
                ret[pycurl.URL]  = "garb"
            else:
                if ret[pycurl.URL][pos+11:pos+18] == "http://":
                    pos += 18
                else:
                    pos += 11
                ret[pycurl.URL] = str(ret[pycurl.URL][:pos] + "~" + str(self.taskDict['chunk_file']) + "~" + ret[pycurl.URL][pos:])
            return ret
        except ObjectDoesNotExist:
            CacheCheckerNodeFailures(cachechecker = self.taskDict['cache'], 
                node = self.taskDict['node'], 
                offline = self.taskDict['node'].offline, 
                outcome = 7).save()
    #parent getUnsetOptions() is fine so not implementing here...
    def handleResponse(self, responseText):
        chunkOutcome = self.parseResponse(responseText)
        if chunkOutcome  == 2:
            #then this chunk is not cached flag as partial and move on...
            if self.taskDict['parseOutcome'] == 1:
                self.taskDict['parseOutcome'] = 3
            else:
                self.taskDict['parseOutcome'] = 4
            return self.recordResponse()

        if self.taskDict.has_key('nodeFailure') and chunkOutcome < self.taskDict['nodeFailure'].outcome * -1:
            self.taskDict['nodeFailure'].outcome = abs(chunkOutcome)

        if self.taskDict['chunk_file'] < self.taskDict['chunk_total']:
            #do next chunk...
            self.taskDict['chunk_file'] += 1
            return [self]
        #all chunks handled!
        return self.recordResponse()
    def handleError(self, responseText, errorNumber, errorMessage):
        if self.taskDict['parseOutcome'] == 1:
            self.taskDict['parseOutcome'] = 3
        else:
            self.taskDict['parseOutcome'] = 4
        return self.recordResponse()

def httpCheckerInitialize(httpChecker):
    verifyHeaders = "date,server"
    httpQueue = []
    if httpChecker.count() > 1:
        for httpRequest in httpChecker[1:httpChecker.count()]:
            httpRequest.state = 3
            httpRequest.save()
    elif httpChecker.count() < 1:
        return httpQueue
    http = httpChecker[0]
    http.state = 1
    nodes = NodeInfo.objects.exclude(pop__shortname = 'prg-try')
    http.totalNodes = nodes.count()
    http.save()
    for node in nodes:
        try:
            #does not use cs port or it may miss redirection of http...
            httpQueue.append(HttpNode({
                'node': node,
                'cs_port': cs_frontend_port,
                'httpChecker': http,
                'verifyHeaders': verifyHeaders \
                }))
        except ObjectDoesNotExist:
            httpChecker[0].state = 10
            httpChecker[0].save()
    return httpQueue

class HttpNode(CurlHandler):
    def getOptions(self):
        try:
            return {pycurl.URL: str("http://" + \
                self.taskDict['node'].ipv4_address + \
                ":"+ str(self.taskDict.get("cs_port") if self.taskDict.get("cs_port") else 80) + \
                "/menu"),
                pycurl.NOBODY: 0,
                pycurl.HTTPGET: 1,
                pycurl.COOKIE: self.getAuth(self.taskDict['node'].hostname,self.taskDict.get("cs_port") if self.taskDict.get("cs_port") else 80),
                pycurl.USERAGENT: "Mozilla/5.0 (compatible; Panther Cache Checker)",
                pycurl.HTTPHEADER: [str("Host: " + self.taskDict['node'].hostname)],
            }
        except ObjectDoesNotExist:
            self.taskDict['httpChecker'].save()
            httpCheckerNode = HttpCheckerNode(node = self.taskDict['node'],
                httpchecker = self.taskDict['httpChecker'],
                lookup_time = datetime.now(),
                outcome = 2,
                shield = False,
                offline = self.taskDict['node'].offline,
                broken = self.taskDict['node'].broken,
                name = self.taskDict['node'].name,
                dns = self.taskDict['node'].dns,
                http = self.taskDict['node'].http,
                buckets = self.taskDict['node'].buckets)
            if self.taskDict['node'].pop.offline:
                httpCheckerNode.offline = True
            httpCheckerNode.save()
            try:
                lastSeenNode = HttpCheckerLastSeenNode.objects. \
                    get_or_create(node = self.taskDict['node'])
                if lastSeenNode:
                    httpCheckerNode.httpcheckerlastseennode = lastSeenNode
                    httpCheckerNode.save()
            except ObjectDoesNotExist:
                logging.info("Could not add link for " + str(httpCheckerNode.id) + ", node: " + str(httpCheckerNode.node.id))
                pass
        return None
    def getUnsetOptions(self):
        return {pycurl.URL: "",
            pycurl.NOBODY: 1,
            pycurl.HTTPGET: 0,
            pycurl.COOKIE: "",
            pycurl.USERAGENT: "DEFAULT USER AGENT"}
    def handle302(self):
        if not self.authTried:
            self.authTried = True
            url = str("http://%s:%d%s" %(self.taskDict['node'].hostname, self.taskDict.get("cs_port") if self.taskDict.get("cs_port") else 80, "/login"))
            return [Auth(self, self.taskDict['node'].hostname, self.taskDict.get("cs_port") if self.taskDict.get("cs_port") else 80, url, {"password": cs_password})]
        return None
    def handleResponse(self, responseText):
        if responseText == "":
            return self.handleError(responseText, 0, "")
        dictHeaders = supporttoolsParseHeader(supporttoolsRemoveBody(responseText),self.taskDict['verifyHeaders'])
        httpCheckerNode = HttpCheckerNode(node = self.taskDict['node'],
            httpchecker = self.taskDict['httpChecker'],
            lookup_time = datetime.now(),
            outcome = 1,
            shield = False,
            offline = self.taskDict['node'].offline,
            broken = self.taskDict['node'].broken,
            name = self.taskDict['node'].name,
            dns = self.taskDict['node'].dns,
            http = self.taskDict['node'].http,
            buckets = self.taskDict['node'].buckets)
        responseBody = responseText #supporttoolsRemoveHeader(responseText)
        regResp = re.compile('Host: </td><td>[^>]*</td><td>([^<]*)</td>').search(responseBody)
        if (regResp != None
                and regResp.groups()[0].strip() != self.taskDict['node'].hostname):
            httpCheckerNode.redirecting = True
        regResp = re.compile("HttpSites\swas\sloaded\sat:\s*<code>([^<]*)</code>").search(responseBody)
        if regResp != None:
            try:
                httpCheckerNode.http_sites_time = datetime.strptime(regResp.groups()[0].strip(),"%Y-%m-%d %H:%M:%S +00:00")
            except:
                pass
        regResp = re.compile("Cache Configure\swas\sloaded\sat:\s*<code>([^<]*)</code>").search(responseBody)
        if regResp != None:
            try:
                httpCheckerNode.cache_config_time = datetime.strptime(regResp.groups()[0].strip(),"%Y-%m-%d %H:%M:%S +00:00")
            except:
                pass
        #treat content dist as cacheconfig...in true 1.5 world we can rename variable.
        regResp = re.compile("ContentDistribution\swas\sloaded\sat:\s*<code>([^<]*)</code>").search(responseBody)
        if regResp != None:
            try:
                httpCheckerNode.cache_config_time = datetime.strptime(regResp.groups()[0].strip(),"%Y-%m-%d %H:%M:%S +00:00")
            except:
                pass
        regResp = re.compile("Last\sflush\swas\sreceived\sat:\s*<code>([^<]*)</code>").search(responseBody)
        if regResp != None:
            try:
                httpCheckerNode.last_flush_time = datetime.strptime(regResp.groups()[0].strip(),"%Y-%m-%d %H:%M:%S +00:00")
            except:
                pass 
        regResp = re.compile("Last\sflush-ID\sreceived:\s*<code>([0-9]*)</code>").search(responseBody)
        if regResp != None:
            try:
                httpCheckerNode.last_flush_id = regResp.groups()[0].strip()
            except:
                pass
        regResp = re.compile("dead:\s*([^<]*)").search(responseBody)
        if regResp != None and regResp.groups()[0].strip() != "null" and \
                not regResp.groups()[0].strip().endswith("] null"):
            httpCheckerNode.dead = True
        httpCheckerNode.save()
        if dictHeaders.has_key('server') and dictHeaders['server'] != '':
            #see if version is recored as of now...
            try:
                version = HttpCheckerVersion.objects.get(name =  dictHeaders['server'])
            except ObjectDoesNotExist:
                version = HttpCheckerVersion(name = dictHeaders['server'])
                version.save()
            httpCheckerNode.version = version
        if dictHeaders.has_key('date'):
            try:
                httpCheckerNode.node_time = datetime.strptime(dictHeaders['date'],"%a, %d %b %Y %H:%M:%S %Z")
            except ValueError:
                pass    
        httpCheckerNode.save()
        #now update last seen...
        if httpCheckerNode.version != None:
            try:
                lastSeen = HttpCheckerLastSeenNode.objects.get(node = httpCheckerNode.node)
                lastSeen.version = httpCheckerNode.version
                lastSeen.save()
            except:
                #doesn't exist yet so make it..
                HttpCheckerLastSeenNode(node = httpCheckerNode.node,
                    version = httpCheckerNode.version).save()
        return []
    def handleError(self, responseText, errorNumber, errorMessage):
        if isinstance(self.taskDict.get("cs_port"),int):
            #cs port failed try standard port (80)
            self.taskDict['cs_port'] = None
            return [self]
        httpCheckerNode = HttpCheckerNode(node = self.taskDict['node'],
            httpchecker = self.taskDict['httpChecker'],
            lookup_time = datetime.now(),
            outcome = 3,
            outcomeText = errorMessage,
            shield = False,
            offline = self.taskDict['node'].offline,
            broken = self.taskDict['node'].broken,
            name = self.taskDict['node'].name,
            dns = self.taskDict['node'].dns,
            http = self.taskDict['node'].http,
            buckets = self.taskDict['node'].buckets)
        httpCheckerNode.save()
        try:
            lastSeenNode = HttpCheckerLastSeenNode.objects. \
                    get(node = self.taskDict['node'])
            if lastSeenNode:
                httpCheckerNode.httpcheckerlastseennode = lastSeenNode
                httpCheckerNode.save()
        except ObjectDoesNotExist:
            logging.info("Could not add link for " + str(httpCheckerNode.id) + ", node: " + str(httpCheckerNode.node.id))
            pass
        return []
    def finished(self):
        if self.taskDict['httpChecker'].totalNodes == \
                self.taskDict['httpChecker'].httpcheckernode_set.all().count():
            #done processing all nodes for http check request...
            self.taskDict['httpChecker'].state = 2
            self.taskDict['httpChecker'].save()
            self.sendEmail(self.taskDict['httpChecker'], sendNonUrgentEmails=self.taskDict['httpChecker'].email)
    def sendEmail(self, httpChecker, sendNonUrgentEmails=False):
        displayPerError = 20 
        versions = getHttpVersionsWithCount(httpChecker.httpcheckernode_set)
        msg = "For more information please visit the following link:" + \
            "\r\nhttps://" + OUI_ROOT + "/supporttools/servercheck/" + str(httpChecker.id) + "/" + \
            "\r\n\r\nCS Versions In Production:"
        for v in versions:
            msg += "\r\n" + v['name'] + ": " + str(v['nodes']) + " nodes"
        badTimeNodes = getBadTimeStampNodes(httpChecker.httpcheckernode_set, time_diff='00:00:30')
        if len(badTimeNodes) > 0:
            msg += "\r\n\r\n" + str(len(badTimeNodes)) + " nodes have incorrect timestamps" 
            if displayPerError < len(badTimeNodes):
                msg += "\r\nNote: only displaying first " + str(displayPerError) + " results"
            for n in badTimeNodes[:displayPerError]:
                msg += "\r\n" + n['name']
        redirecting = httpChecker.getRedirectingNodes()
        if redirecting.count() > 0:
            msg += "\r\n\r\n" + str(redirecting.count()) + " nodes appear to be redirecting"
            if displayPerError < redirecting.count():
                msg += "\r\nNote: only displaying first " + str(displayPerError) + " results"
            for n in redirecting[:displayPerError]:
                msg += "\r\n" + n.name
        dead = httpChecker.getDeadNodes()
        if dead.count() > 0:
            msg += "\r\n\r\n" + str(dead.count()) + " nodes appear to be dead"
            if displayPerError < dead.count():
                msg += "\r\nNote: only displaying first " + str(displayPerError) + " results"
            for n in dead[:displayPerError]:
                msg += "\r\n" + n.name
        bucketless = httpChecker.getBucketlessNodesServingHttp()
        if bucketless.count() > 0:
            msg += "\r\n\r\n" + str(bucketless.count()) + " bucketless nodes appear to have cs running"
            if displayPerError < bucketless.count():
                msg += "\r\nNote: only displaying first " + str(displayPerError) + " results"
            for n in bucketless[:displayPerError]:
                msg += "\r\n" + n.name
        nonhttp = httpChecker.getNonHttpNodesServingHttp()
        if nonhttp.count() > 0:
            msg += "\r\n\r\n" + str(nonhttp.count()) + " non-http serving nodes appear to have cs running"
            if displayPerError < nonhttp.count():
                msg += "\r\nNote: only displaying first " + str(displayPerError) + " results"
            for n in nonhttp[:displayPerError]:
                msg += "\r\n" + n.name
        broken = httpChecker.getBrokenNodesServingHttp()
        if broken.count() > 0:
            msg += "\r\n\r\n" + str(broken.count()) + " broken nodes appear to have cs running"
            if displayPerError < broken.count():
                msg += "\r\nNote: only displaying first " + str(displayPerError) + " results"
            for n in broken[:displayPerError]:
                msg += "\r\n" + n.name
        oldFlush = httpChecker.getBehindFlushNodes()
        if oldFlush and oldFlush.count() > 0:
            msg += "\r\n\r\n" + str(oldFlush.count()) + " nodes appear to be behind in flushes"
            if displayPerError < oldFlush.count():
                msg += "\r\nNote: only displaying first " + str(displayPerError) + " results"
            for n in oldFlush[:displayPerError]:
                msg += "\r\n" + n.name
        oldHttpSites = httpChecker.getBehindHttpSitesNodes()
        if oldHttpSites and oldHttpSites.count() > 0:
            msg += "\r\n\r\n" + str(oldHttpSites.count()) + " nodes appear to have an old copy of http-sites-ng.xml"
            if displayPerError < oldHttpSites.count():
                msg += "\r\nNote: only displaying first " + str(displayPerError) + " results"
            for n in oldHttpSites[:displayPerError]:
                msg += "\r\n" + n.name
        oldCacheConfig = httpChecker.getBehindCacheConfigNodes(behind_seconds = 600)
        if oldCacheConfig and oldCacheConfig.count() > 0:
            msg += "\r\n\r\n" + str(oldCacheConfig.count()) + " nodes appear to have an old copy of csconfig.xml"
            if displayPerError < oldCacheConfig.count():
                msg += "\r\nNote: only displaying first " + str(displayPerError) + " results"
            for n in oldCacheConfig[:displayPerError]:
                msg += "\r\n" + n.name
        unreach_over_week = httpChecker.getUnreachableNodes(datetime.now() - timedelta(days = 7)).filter(http=True)
        if unreach_over_week and unreach_over_week.count() > 0:
            msg += "\r\n\r\n" + str(unreach_over_week.count()) + " nodes not reached in over 1 week"
            for n in unreach_over_week:
                msg += "\r\n" + n.name + " - " + (str(n.httpcheckerlastseennode.modify_time) if n.httpcheckerlastseennode else 'Never Reached')
        additional_emails = []
        all_nodes = httpChecker.getReachedNodes()
        mean_time = all_nodes.order_by('cache_config_time')[all_nodes.count()/2].cache_config_time
        old_cacheconfig_active = httpChecker.getBehindCacheConfigNodes(behind_seconds = 600,base_time=mean_time).filter(offline = False, redirecting = False).exclude(id__in = httpChecker.getDeadNodes().values_list('id',flat=True))
        if old_cacheconfig_active and old_cacheconfig_active.count() > 0:
            email = {'to': [NOC],
                'subject': '[alert] old content distribution found on alive nodes',
                'message': "%d online nodes with old content distribution:\r\n" %(old_cacheconfig_active.count())
            }
            for n in old_cacheconfig_active:
                email['message'] += "\r\n" + n.name
            additional_emails.append(email)
        mean_time = all_nodes.order_by('http_sites_time')[all_nodes.count()/2].http_sites_time
        old_httpsites_active = httpChecker.getBehindHttpSitesNodes(base_time=mean_time).filter(offline = False, redirecting = False).exclude(id__in = httpChecker.getDeadNodes().values_list('id',flat=True))
        if old_httpsites_active and old_httpsites_active.count() > 0:
            email = {'to': [NOC],
                'subject': '[alert] old http sites found on alive nodes',
                'message': "%d online nodes with old http sites:\r\n" %(old_httpsites_active.count())
            }
            for n in old_httpsites_active:
                email['message'] += "\r\n" + n.name
            additional_emails.append(email)
        dead_not_broken = broken.exclude(redirecting=False, id__in = httpChecker.getDeadNodes().values_list('id',flat=True))
        if dead_not_broken and dead_not_broken.count() > 0:
            email = {'to': [NOC],
                'subject': "[alert] %d broken nodes alive" %(dead_not_broken.count()), 
                'message': "%d broken nodes running HTTP not in dead mode:\r\n" %(dead_not_broken.count())
            }
            for n in dead_not_broken:
                email['message'] += "\r\n" + n.name
            additional_emails.append(email)
        bucketless_active = bucketless.filter(offline = False, redirecting=False).exclude(id__in = httpChecker.getDeadNodes().values_list('id',flat=True))
        if bucketless_active and bucketless_active.count() > 0:
            email = {'to': [NOC],
                'subject': "[alert] %d bucketless cache nodes running" %(bucketless_active.count()),
                'message': "%d bucketless cache nodes running HTTP not in dead mode:\r\n" %(bucketless_active.count())
            }
            for n in bucketless_active:
                email['message'] += "\r\n" + n.name
            additional_emails.append(email)
        bad_time = getBadTimeStampNodes(httpChecker.httpcheckernode_set, time_diff = "00:05:00")
        if len(badTimeNodes) > 0:
            email = {'to': [NOC],
                'subject': "[alert] incorrect timestamp found on alive nodes",
                'message': " online nodes with incorrect timestamps:"
            }
            bads = 0
            for n in bad_time:
                if (n['offline'] and not n['dns']) or n['broken']:
                    continue #don't care about these nodes...
                email['message'] += "\r\n" + n['name']
                bads += 1
            if bads > 0:
                email['message'] = str(bads) + email['message']
                additional_emails.append(email)
        try:
            if sendNonUrgentEmails:
                send_email(NO_REPLY,
                    [NOC],
                    "[report] cache server status (" + datetime.now().strftime('%Y-%m-%d') + ")",  
                    msg)
                httpChecker.email_time = datetime.now()
        except:
            pass #nothing I can do really if email fails...
        for mail in additional_emails:
            try:
                send_email(NO_REPLY,mail['to'],mail['subject'],mail['message'])
            except:
                pass #nothing I can do really if email fails...
        httpChecker.save()

def pollingSystemInitialize(pollingSystem):
    pollQueue = []
    for pollingRequest in pollingSystem:
        for pollNode in pollingRequest.pollingsystemnode_set.filter(outcome=0):
            pollQueue.append(PollingNode(pollingSystemNode=pollNode))
        pollingRequest.state = 1
        pollingRequest.save()
    return pollQueue

class PollingNode(CurlHandler):
    def __init__(self, *args, **kwargs):
        self.pollNode = kwargs.pop('pollingSystemNode',None)
        assert isinstance(self.pollNode,PollingSystemNode)
        self.node = self.pollNode.node #for easier reference
        self.pollSys = self.pollNode.pollsystem
        self.authTried = False
    def getOptions(self):
        return {
            pycurl.URL: str("http://%s:%d%s" %(self.node.ipv4_address, 
                self.pollSys.getPort(), 
                self.pollSys.uri)),
            pycurl.NOBODY: 0,
            pycurl.HEADER: 0,
            pycurl.HTTPGET: 1,
            pycurl.USERAGENT: "Mozilla/5.0 (compatible; Panther Looking Glass Checker)",
            pycurl.HTTPHEADER: [str("Host: " + self.node.hostname)],
            pycurl.COOKIE: self.getAuth(self.node.hostname,self.pollSys.getPort()),
        }
    def getUnsetOptions(self):
        return {
            pycurl.URL: "",
            pycurl.NOBODY: 1,
            pycurl.HTTPGET: 0,
            pycurl.USERAGENT: "DEFAULT USER AGENT",
            pycurl.COOKIE: "",
        }
    def handleResponse(self, responseText):
        if responseText == "":
            return self.handleError(responseText, 0, "")
        parsed_resp = [[""]]
        if self.pollSys.response_type == 0:
            #this is json - assumes dictionary with 1 item
            #first list item is header, and rest are values...
            try:
                d=simplejson.loads(responseText)
                
                if len(d) != 1:
                    raise Exception("Response not in expected json format")
            except Exception, e:
                return self.handleError(responseText, 0, e.message + "(Response received upto 100chars):" + responseText[0:100] + ")")
            key, val = d.popitem() #we don't care about key
            if isinstance(val,list):
                self.pollSys.response_modifier = simplejson.dumps(val[0])
                self.pollSys.save()
                parsed_resp = val[1:]
            else:
                self.pollSys.response_modifier = simplejson.dumps([key])
                self.pollSys.save()
                parsed_resp = [val]
        elif self.pollSys.response_type == 1:
            #this is full response
            parsed_resp = [[str(responseText)]]
        elif self.pollSys.response_type == 2:
            #this is regex
            parsed_resp = []
            res = re.compile(self.pollSys.response_modifier).findall(responseText)
            for item in res:
                parsed_resp.append([item])
        elif self.pollSys.response_type == 3:
            #this is matching line
            parsed_resp = []
            for line in responseText.split("\n"):
                try:
                    if line.find(self.pollSys.response_modifier)>=0:
                        parsed_resp.append([line])
                except:
                    pass
            if len(parsed_resp) == 0:
                parsed_resp.append([""])
        self.pollNode.response = simplejson.dumps(parsed_resp)
        self.pollNode.outcome = 1
        self.pollNode.save()
        return []
    def handleError(self, responseText, errorNumber, errorMessage):
        self.pollNode.outcome = 3
        self.pollNode.outcomeText =errorMessage
        self.pollNode.save()
    def finished(self):
        if self.pollSys.pollingsystemnode_set.filter(outcome=0).count()==0:
            #no more pending so can finish up....
            self.pollSys.state = 2
            self.pollSys.save()
    def handle302(self):
        if self.pollSys.app == 3 and not self.authTried: #cs...
            self.authTried = True
            url = str("http://%s:%d%s" %(self.node.hostname, self.pollSys.getPort(), "/login"))
            return [Auth(self, self.node.hostname, self.pollSys.getPort(), url, {"password": cs_password})]
        return None

def processRequests(list_CurlHandler):
    numConnections = 200 #concurrent http processes
    maxTimeExceeded = 600 #seconds to consider the script in invalid state
    logTimeInterval = 60 #how often should log warning of progress time
    #these are used for all connections (a type of connection could override in their getOptions function
    defaultCurlOptions = { \
        pycurl.CONNECTTIMEOUT: 10,
        pycurl.TIMEOUT: 20,
        pycurl.NOBODY: 1,
        pycurl.HEADER: 1,
        pycurl.FOLLOWLOCATION: 0,
        pycurl.HTTPHEADER: ["Via: 1.1 support.panthercdn.com PWS/0.0.0"],
        pycurl.USERAGENT: "Mozilla/5.0 (compatible; Panther)",
        }
    if not isinstance(list_CurlHandler,list):
        logging.error("processRequests accepts only a list")
        raise TypeError("Invalid list_CurlHandler argument")

    #the queue to process...
    queue = list_CurlHandler

    #Below is implementation using pycurl (libcurl extension for python)
    #This was built off of an example on the pycurl site which can be found at:
    #http://pycurl.cvs.sourceforge.net/pycurl/pycurl/examples/retriever-multi.py?revision=1.29&view=markup

    #Create curl worker objects...
    multiCurl = pycurl.CurlMulti()
    multiCurl.handles = []
    for loop in range(numConnections):
        #static headers to always use
        #when executing each object will add specific headers
        curlObject = pycurl.Curl()
        for key in defaultCurlOptions:
            curlObject.setopt(key, defaultCurlOptions[key])
        curlObject.handler = None
        curlObject.stringOutput = None
        curlObject.stringHeader = None
        multiCurl.handles.append(curlObject)

    #do concurrent requests using worker curl objects...
    availableCurlObjects = multiCurl.handles[:]

    startTime = datetime.now()
    lastLogTime = startTime = datetime.now()
    while len(queue) > 0 or len(availableCurlObjects) < numConnections:
        #keep going until all work is complete...
        currentTime = datetime.now()
        if (currentTime - startTime).seconds > maxTimeExceeded:
            logging.error("Max process time exceeded, started: " + \
                str(startTime) + ", now: " + str(currentTime))
            break
        elif (currentTime - lastLogTime).seconds > logTimeInterval:
            logging.info("Process execution has been running for " + str(currentTime - startTime))
            lastLogTime = currentTime
        while len(queue) > 0 and len(availableCurlObjects) > 0:
            #if there is a queue object to process and a free curl object add to multi stack...
            curlObject = availableCurlObjects.pop(0)
            if curlObject.stringOutput != None and not curlObject.stringOutput.closed:
                curlObject.stringOutput.close()
            curlObject.stringOutput = None
            if curlObject.stringHeader != None and not curlObject.stringHeader.closed:
                curlObject.stringHeader.close()
            curlObject.stringHeader = None
            curlObject.handler = queue.pop(0) #get work item
            if not isinstance(curlObject.handler,CurlHandler):
                #something went wrong, add back to available workers queue
                #we did get item out of task queue atleast
                curlObject.handler = None
                logging.error("Queue item not a CurlHandler child which is a requirement")
                availableCurlObjects.append(curlObject)
                continue
                
            for opt, value in curlObject.handler.getOptions().items():
                try:
                    curlObject.setopt(opt,value)
                except Exception, e:
                    logging.info("error for option: %s and value %s of type %s" %(str(opt), str(value), str(type(value))))
                    raise e
            curlObject.stringOutput = StringIO()
            curlObject.setopt(pycurl.WRITEFUNCTION, curlObject.stringOutput.write)
            curlObject.stringHeader = StringIO()
            curlObject.setopt(pycurl.HEADERFUNCTION, curlObject.stringHeader.write)
            multiCurl.add_handle(curlObject)

        #run the internal curl state machine for the multi stack
        while 1:
            ret, numHandles = multiCurl.perform()
            if ret != pycurl.E_CALL_MULTI_PERFORM:
                break

        #check for curl objects which have terminated and process/put them back in queue
        while 1:
            numQ, okList, errorList = multiCurl.info_read()
            for curlObject in okList:
                multiCurl.remove_handle(curlObject)
                #process result....
                #if 302 and handle auth try that function, that function can return a [] (response) or 
                #None meaning continue as if function doesn't exist
                if curlObject.getinfo(pycurl.RESPONSE_CODE) == 302:
                    resp = curlObject.handler.handle302()
                else:
                    resp = None
                if resp == None:
                    header = curlObject.stringHeader.getvalue()
                    if re.search("Content-Encoding:\s*gzip", header):
                        data = curlObject.stringOutput.getvalue()
                        respTxt = gzip.GzipFile(fileobj=StringIO(data)).read()
                        #respTxt = gzip.GzipFile(fileobj=curlObject.stringOutput).read()
                        logging.info("response..." + str(respTxt))
                    else:
                        respTxt = curlObject.stringOutput.getvalue()
                        
                    resp = curlObject.handler.handleResponse(respTxt)
                    curlObject.handler.finished()
                if resp != None:
                    for handler in resp:
                        if not isinstance(handler,CurlHandler):
                            logging.error("Potential queue item is not a subclass of CurlHandler")
                        queue.append(handler)
                for opt, value in curlObject.handler.getUnsetOptions().items():
                    if defaultCurlOptions.has_key(opt):
                        curlObject.setopt(opt,defaultCurlOptions[opt])
                    else:
                            curlObject.setopt(opt,value)

                curlObject.handler = None
                if curlObject.stringOutput != None and not curlObject.stringOutput.closed:
                    curlObject.stringOutput.close()
                curlObject.stringOutput = None
                if curlObject.stringHeader != None and not curlObject.stringHeader.closed:
                    curlObject.stringHeader.close()
                curlObject.stringHeader = None
                #done processing result...
                availableCurlObjects.append(curlObject)
            for curlObject, errorNumber, errorMessage in errorList:
                multiCurl.remove_handle(curlObject)
                #process failure...
                resp = curlObject.handler.handleError(curlObject.stringOutput.getvalue(), errorNumber, errorMessage)
                curlObject.handler.finished()
                if resp != None:
                    for handler in resp:
                        if not isinstance(handler,CurlHandler):
                            logging.error("Potential queue item is not a subclass of CurlHandler")
                            queue.append(handler)
                for opt, value in curlObject.handler.getUnsetOptions().items():
                    if defaultCurlOptions.has_key(opt):
                        curlObject.setopt(opt,defaultCurlOptions[opt])
                    else:
                        curlObject.setopt(opt,value)
                curlObject.handler = None
                if curlObject.stringOutput != None and not curlObject.stringOutput.closed:
                    curlObject.stringOutput.close()
                curlObject.stringOutput = None
                if curlObject.stringHeader != None and not curlObject.stringHeader.closed:
                    curlObject.stringHeader.close()
                curlObject.stringHeader = None
                #done processing result...
                availableCurlObjects.append(curlObject)
            if numQ == 0:
                break
        multiCurl.select(1.0)

    #cleanup...should just have to close curlObject and multiCurl but check to make sure...
    for curlObject in multiCurl.handles:
        if curlObject.handler != None and not curlObject.stringOutput == None and not curlObject.stringOutput.closed: 
            curlObject.handler.handleResponse(curlObject.stringOutput.getvalue())
        elif curlObject.handler != None:
            curlObject.handler.handleError(curlObject.stringOutput.getvalue(),-1,'')
            curlObject.handler.finished()
        if not curlObject.stringOutput == None and not curlObject.stringOutput.closed:
            curlObject.stringOutput.close()
        if not curlObject.stringHeader == None and not curlObject.stringHeader.closed:
            curlObject.stringHeader.close()
        curlObject.close()
    multiCurl.close()

def main():
    """Look for tasks to run (cache checking and preheating,
    then execute those tasks"""

    lastCdnUpdate = None
    lastCleanup = None
    logging.info("starting")
    
    try:    
        #long running script so just let it keep going
        while True:
            #first see if you need to update CDN information (Pop, Node)
            now = datetime.now()
            if lastCdnUpdate == None or \
            ( \
                (now-lastCdnUpdate).days >= updateInfoTableInMinutes/1440 \
                and (now-lastCdnUpdate).seconds >= updateInfoTableInMinutes%1440*60 \
            ):
                updateInfoTables(True)
                lastCdnUpdate = now
            if lastCleanup == None or \
            ( \
                (now-lastCleanup).days >= cleanupDBTableInMinutes/1440 \
                and (now-lastCleanup).seconds >= cleanupDBTableInMinutes%1440*60 \
            ):    
                cleanupDB()
                lastCleanup = now
            #make sure no files are in a processing state
            preheat = Preheat.objects.all().filter(state=1)
            if preheat != None and preheat.count() > 0:
                logging.error("found " + str(preheat.count()) + \
                    " preheat requests stuck in processing")
                for req in preheat:
                    req.state = 10
                    req.save()
            cache = CacheChecker.objects.all().filter(state=1)
            if cache != None and cache.count() > 0:
                logging.error("found " + str(cache.count()) + \
                    " cache check requests stuck in processing")
                for req in cache:
                    req.state = 10
                    req.save()
            http = HttpChecker.objects.all().filter(state=1)
            if http != None and http.count() > 0:
                logging.error("found " + str(http.count()) + \
                    " http check requests stuck in processing")
                for req in http:
                    req.state = 10
                    req.save()
            polling = PollingSystem.objects.all().filter(state=1)
            if polling != None and polling.count() > 0:
                logging.error("found " + str(polling.count()) + \
                    " polling system requests stuck in processing")
                for req in polling:
                    req.state = 10
                    req.save()
            #done checking for hanging processes...
                
            #see if there are any tasks to do    
            preheat = Preheat.objects.all().select_related().filter(state=0)
            cache = CacheChecker.objects.all().select_related().filter(state=0)
            http = HttpChecker.objects.all().select_related().filter(state=0)
            polling = PollingSystem.objects.all().select_related().filter(state=0)
            if (preheat != None and preheat.count() > 0) or \
                    (cache != None and cache.count() > 0):
                logging.info("Processing cache/preheat request(s)")
                if preheat != None:
                    preheat.minimumFileLength = preheatMinimumFileLength
                processRequests(preheatInitialize(preheat) + cacheInitialize(cache))
                if sleepOnAction:
                    logging.debug('sleeping for %d minutes preheat/cache check' % sleepOnAction)
                    time.sleep(sleepOnAction)
            elif (http != None and http.count() > 0) or \
                    (polling != None and polling.count() > 0):
                #only want to do http check requests if there are no 
                #higher priority tasks.
                logging.info("Processing server (http) request(s)")
                #preheat/cache pending...
                processRequests(httpCheckerInitialize(http) + pollingSystemInitialize(polling))
                if sleepOnAction:
                    logging.debug('sleeping for %d minutes after http check' % sleepOnAction)
            elif sleepOnInactivity:
                logging.debug('sleeping for %d minutes' % sleepOnInactivity)
                time.sleep(sleepOnInactivity)

            #clear any caching by closing database connection
            connection.close()
    except KeyboardInterrupt:
        logging.info('received keyboard interrupt')
    except Exception, e:
        logging.error('emailing unexpected exception (' + str(e) + ')!')
        import traceback
        try:
            send_email('root@support-tools.panthercdn.com',[MAINTAINER],'support tools runner: %s' %(str(e)), traceback.format_exc())
        except:
            logging.error('Error encountered sending email.')
    logging.info('stopping')

if __name__ == '__main__':
    #Launch yourself
    main()
