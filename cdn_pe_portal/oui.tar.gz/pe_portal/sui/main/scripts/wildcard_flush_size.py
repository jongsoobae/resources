from datetime import timedelta
import time
from django.utils import simplejson
from django.db import transaction
from ci.constants import NO_REPLY, NOC, MAINTAINER
from ci.common.utils.mail import send_email
from sui.support.models import PollingSystemNode, PollingSystem, NodeInfo

max_rules = 100000

#setup polling system for all nodes that were successful...
ps = PollingSystem(app=3, uri='/flushinfo', response_type=2, response_modifier='Number of effective rules [(]being used[)] in FSM: ([0-9]*)<br>')
ps.save()
for node in NodeInfo.objects.filter(offline=0,broken=0):
	PollingSystemNode(node=node,pollsystem=ps).save()

ps.state = 0
ps.save()

#wait till polling system completes...
ps_id = ps.id
start = time.time()
while PollingSystem.objects.get(id=ps_id).state < 2 and time.time() - start < 600:
	transaction.commit_unless_managed() # this lets new nodes/pops get noticed
	time.sleep(10)

PollingSystemNode()
objs=PollingSystemNode.objects.filter(pollsystem = ps_id, outcome=1)
pops = {}

rule_sizes = []
found_nodes = ""
for obj in objs:
	try:
		rules=int(simplejson.loads(obj.response)[0][0])
	except:
		continue #no value found
	if rules > max_rules:
		found_nodes += "%s has %d rules\n" %(obj.node.hostname, rules)
	else:
		rule_sizes.append(rules)

if found_nodes !=  "":
	found_nodes +="\nInstructions for handling this alert:"
	found_nodes += "\nhttp://wiki.cdnetworks.com/confluence/display/CDNUS/Responding+to+Alerts#RespondingtoAlerts-otherwildcard"
	found_nodes += "-- END --"
	send_email(NO_REPLY, [NOC], "[urgent] CS nodes with over %d wildcard effective rules" %(max_rules),found_nodes)

