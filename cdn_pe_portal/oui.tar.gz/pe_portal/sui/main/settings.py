# Django settings for oui project.

from ci.constants import DATABASE_USER, DATABASE_HOST, DATABASE_PORT, DATABASE_PASSWORD, TEMPLATE_DIRS, DEBUG, \
    BASE_DIR, AUTHENTICATION_KEY_VALUE, CACHE_BACKEND, CACHE_LOCATIONS, REDIS_SENTINEL_LOCATIONS
import os

TEMPLATE_DEBUG = DEBUG
PROJECT_NAME = "SUI"
ADMINS = (
    # ('Your Name', 'your_email@domain.com'),
)

MANAGERS = ADMINS

DATABASE_ENGINE = 'mysql'           # 'postgresql', 'mysql', 'sqlite3' or 'ado_mssql'.
DATABASE_NAME = 'supportdb'             # Or path to database file if using sqlite3.

DATABASE_OPTIONS = { 'charset': 'utf8' }

# Local time zone for this installation. All choices can be found here:
# http://www.postgresql.org/docs/8.1/static/datetime-keywords.html#DATETIME-TIMEZONE-SET-TABLE
# If running in a Windows environment this must be set to the same as your
# system time zone.
TIME_ZONE = 'GMT'

# Language code for this installation. All choices can be found here:
# http://www.w3.org/TR/REC-html40/struct/dirlang.html#langcodes
# http://blogs.law.harvard.edu/tech/stories/storyReader$15
LANGUAGE_CODE = 'en-us'

SITE_ID = 1

# If you set this to False, Django will make some optimizations so as not
# to load the internationalization machinery.
USE_I18N = False

MIDDLEWARE_CLASSES = (
    'django.middleware.common.CommonMiddleware',
	'sui.middleware.RequireAuthenticationKeyMiddleware',
	'django.middleware.gzip.GZipMiddleware',
    'django.middleware.doc.XViewMiddleware',
	'django.middleware.transaction.TransactionMiddleware',
)


ROOT_URLCONF = 'sui.urls'

INSTALLED_APPS = (
    'django.contrib.contenttypes',
    'django.contrib.sites',
    'sui.support',
)

AUTHENTICATION_BACKENDS = (
	'django.contrib.auth.backends.ModelBackend',
)

INTERNAL_IPS = (
	'127.0.0.1',
)


TEMPLATE_CONTEXT_PROCESSORS = (
	"django.core.context_processors.auth",
	"django.core.context_processors.debug",
	"django.core.context_processors.i18n",
	"django.core.context_processors.media",
	"django.core.context_processors.request",
)

TEMPLATE_DIRS = (
   	os.path.join(BASE_DIR, 'templates'),
)

AUTHENTICATION_KEY_NOT_REQUIRED = ()

AUTHENTICATION_KEY_REQUIRED = (
	r'^.*',
)

# Everyone in this list gets emailed when there's a 500 and DEBUG=False.
ADMINS = (('Eric Ceres','eceres@pantherexpress.net'),)
EMAIL_SUBJECT_PREFIX = '[Django Support] '
SERVER_EMAIL = 'ui@pantherexpress.net'

REDIS_DEFAULT_TIMEOUT = 60
REDIS_CACHE_BACKEND = "ci.common.contrib.django_redis.cache.RedisCache"
REDIS_SENTINEL_OPTIONS = {
    "CLIENT_CLASS": "ci.common.utils.sentinel.SentinelClient"
}

CACHES = {
    'default': {
        'BACKEND': CACHE_BACKEND,
        'LOCATION': CACHE_LOCATIONS,
    },
    'redis': {
        'BACKEND': REDIS_CACHE_BACKEND,
        'LOCATION': REDIS_SENTINEL_LOCATIONS,
        'OPTIONS': REDIS_SENTINEL_OPTIONS,
    }
}

DEFAULT_THROTTLE_RATES = {
        'anon': '200/hour',
        'user': '1000/day'
}
