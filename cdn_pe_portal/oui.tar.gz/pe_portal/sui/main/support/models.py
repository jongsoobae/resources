from django.db import models
from datetime import datetime, timedelta
from django.core.exceptions import ObjectDoesNotExist
import pycurl
import urllib

class PopInfo(models.Model):
	id = models.AutoField(primary_key=True, db_column='pop_id')
	create_time = models.DateTimeField(null=False)
	modify_time = models.DateTimeField(null=False)
	offline = models.BooleanField(default=True)
	shortname = models.CharField(max_length=50)
	importance = models.IntegerField(help_text="Valid values for this field:\n (0) a 'regular' pop. \n (1) a very important PoP like a shield for a major customer. \n (-1) a retired PoP, this value will make the PoP invisible in the OUI")
	class Meta:
		db_table = 'pop_info'
		app_label = 'support'

class NodeInfo(models.Model):
	id = models.AutoField(primary_key=True, db_column='node_id')
	create_time = models.DateTimeField(null=False)
	modify_time = models.DateTimeField(null=False)
	hostname = models.CharField(max_length=100, unique=True)
	ipv4_address = models.IPAddressField(unique=True)
	pop = models.ForeignKey(PopInfo)
	offline = models.BooleanField(default=True)
	broken = models.BooleanField(default=False, help_text='If this is checked, the node will not receive pushes, and "Offline" will also be checked.')
	shield = models.BooleanField(default=False)
	dns = models.BooleanField(default=False)
	http = models.BooleanField(default=True)
	buckets = models.BooleanField(default=True)
	name = models.CharField(max_length=100, unique=True)
	class Meta:
		db_table = 'node_info'
		app_label = 'support'

class ServiceInfo(models.Model):
	id = models.AutoField(primary_key=True, db_column='cdn_service_id')
	create_time = models.DateTimeField(null=False)
	modify_time = models.DateTimeField(null=False)
	dns_prefix = models.CharField(unique=True, max_length=6)
	pops = models.ManyToManyField(PopInfo)
	class Meta:
		db_table = 'service_info'
		app_label = 'support'

class Preheat(models.Model):
	create_user = models.CharField(max_length=10, null=False)
	create_time = models.DateTimeField(null=False)
	modify_time = models.DateTimeField(null=False)
	visible_to_user = models.BooleanField(default=False)
	submittedUrl = models.CharField(max_length=2000, null=False)
	protocol = models.CharField(max_length=10, null=False)
	path = models.CharField(max_length=2000, null=False)
	all_nodes = models.BooleanField('Preheat all nodes instead of 1 per pop', default = False)
	follow_redirect = models.BooleanField('Follows 1 redirect if true, OLC support', default=False)
	use_sub_files = models.BooleanField('chunking', default=False)
	rewrite_rules = models.TextField('Rewrite Rules pre-validation', blank=True, help_text="Applied before validation, post-validation is preferred.")
	rewrite_rules_post_validation =  models.TextField('Rewrite Rules post-validation', blank=True, help_text='These rules are applied after any validation is done.')
	custom_origin_headers =  models.TextField('custom headers to origin', blank=True, help_text='List of custom headers, one per line, e.g.: "X-Foo: bar"')
	custom_node_headers =  models.TextField('custom headers to each node', blank=True, help_text='List of custom headers, one per line, e.g.: "X-Foo: bar"')
	case_insensitive_urls =  models.BooleanField('Case-insensitive Urls', default=False, help_text="If on, all urls will be lower-cased upon entering the CS.")
	drop_params = models.BooleanField('Drop query string pre-validation', default=False, help_text="Should Panther's cache ignore the query string in URLs when caching? (see Implementation Guide for details)")
	drop_precise_params_post_validation = models.CharField('Drop specific params from query string', blank=True, max_length=255, help_text='Comma-separated list of parameters to drop from query string post validation.')
	override_file_size = models.BooleanField(default=False)
	service = models.ForeignKey(ServiceInfo, null=True)
	customername = models.CharField(max_length=150)
	origin = models.CharField(max_length=270, db_column='domain', help_text='This is the domain for the Panther cache to get content from on cache misses or refreshes (e.g. origin.example.com)')
	pad = models.CharField('PAD', max_length=255, db_column='serve_domain', help_text='Panther Accelerated Domain: the domain that Panther is serving content for (e.g. cache.example.com)')
	verifyHeaders = models.CharField(max_length=2000, null=False)
	originHeader = models.TextField()
	state = models.PositiveSmallIntegerField(default=0)
	class Meta:
		db_table = 'preheat'
		app_label = 'support'
	def save(self):
		if not self.id:
			self.create_time = datetime.now()
		self.modify_time = datetime.now()
		super(Preheat, self).save()
	def toDictionary(self):
		dict = {} 
		dict['origin'] = self.origin
		dict['protocol'] = self.protocol
		dict['verifyHeaders'] = self.verifyHeaders
		dict['state'] = self.state
		dict['create_user'] = self.create_user
		dict['visible_to_user'] = self.visible_to_user
		dict['create_time'] = self.create_time
		dict['pad'] = self.pad
		dict['modify_time'] = self.modify_time
		dict['submittedUrl'] = self.submittedUrl
		dict['service_id'] = self.service_id
		dict['path'] = self.path
		dict['id'] = self.id
		dict['customername'] = self.customername
		dict['stateDescription'] = self.stateDescription()
		return dict
	def stateDescription(self):
		if self.state == 0:
			return "In Queue"
		elif self.state == 1:
			return "In Progress"
		elif self.state == 2:
			return "Preheat Successful"
		elif self.state == 3:
			return "Duplicate entry skipping processing"
		elif self.state == 4:
			return "Domain not configured as a PAD"
		elif self.state == 5:
			return "PAD not configured properly"
		elif self.state == 6:
			return "Invalid response from origin"
		elif self.state == 7:
			return "No pops associated with PAD"
		elif self.state == 8:
			return "Error retrieving file from origin"
		elif self.state == 9:
			return "Preheating not successful on all pops (see results)"
		elif self.state == 10:
			return "Error processing request"
		elif self.state == 11:
			return "File is too small to meet preheat criteria"
		elif self.state == 12:
			return "Preheat successful (note: correct file was already cached on some PoPs)"
		elif self.state == 13:
			return "Preheating not successful on all pops (outdated file already cached)"
		return "Unknown"
	def totalPops(self):
		try:
			return self.preheatpopinfo_set.count()
		except ObjectDoesNotExist:
			return 0
	def offlinePops(self):
		try:
			return self.preheatpopinfo_set.filter(outcome__in = [1,2]).count()
		except ObjectDoesNotExist:
			return 0
	def activePops(self):
		try:
			return self.preheatpopinfo_set.exclude(outcome__in = [1,2]).count()
		except ObjectDoesNotExist:
			return 0
	def successfulPops(self):
		try:
			return self.preheatpopinfo_set.filter(outcome__in = [5,9]).count()
		except ObjectDoesNotExist:
			return 0
	def heatedPops(self):
		try:
			return self.preheatpopinfo_set.filter(outcome = 9).count()
		except ObjectDoesNotExist:
			return 0
	def alreadyCachedPops(self):
		try:
			return self.preheatpopinfo_set.filter(outcome = 5).count()
		except ObjectDoesNotExist:
			return 0
	def successfulPartialPops(self):
		try:
			return self.preheatpopinfo_set.filter(outcome = 8).count()
		except ObjectDoesNotExist:
			return 0
	def unreachablePops(self):
		try:
			return self.preheatpopinfo_set.filter(outcome = 6).count()
		except ObjectDoesNotExist:
			return 0
	def outDatedPops(self):
		try:
			return self.preheatpopinfo_set.filter(outcome = 4).count()
		except ObjectDoesNotExist:
			return 0
	def unexpectedOutcomePops(self):
		try:
			return self.preheatpopinfo_set.exclude(outcome__in = [1,2,4,5,6,9]).count()
		except ObjectDoestNotExist:
			return 0
	def getUnsuccessfulPops(self):
		try:
			return self.preheatpopinfo_set.exclude(outcome__in = [5,9]).order_by('-outcome')
		except Exception:
			return None
	def getOutDatedPops(self):
		try:
			return self.preheatpopinfo_set.filter(outcome = 4).order_by('-outcome')
		except Exception:
			return None
	def getPops(self):
		try:
			return self.preheatpopinfo_set.order_by('-outcome')
		except Exception:
			return None

class PreheatPopInfo(models.Model):
	preheat = models.ForeignKey(Preheat)
	pop = models.ForeignKey(PopInfo)
	node = models.ForeignKey(NodeInfo, null=True)
	outcome = models.PositiveSmallIntegerField(default=0)
	outcomeText = models.CharField(max_length=200)
	header = models.TextField()
	failedHeaders = models.CharField(max_length=255)
	class Meta:
		db_table = 'preheat_pop_info'
		app_label = 'support'
	def outcomeDescription(self):
		#if self.outcomeText != "":
		#	return self.outcomeText
		if self.outcome == 1:
			return "PoP offline"
		if self.outcome == 2:
			return "All nodes offline"
		if self.outcome == 3:
			return "Invalid response from node"
		if self.outcome == 4:
			return "Incorrect file already cached"
		if self.outcome == 5:
			return "Correct file already cached"
		if self.outcome == 6:
			return "Every node attempted was unreachable"
		if self.outcome == 7:
			return "PAD or Node configuration error"
		if self.outcome == 8:
			return "Cache matches origin, but only some chunks cached"
		if self.outcome == 9:
			return "File heated from origin"
		return "Unknown"

class CacheChecker(models.Model):
	create_user = models.CharField(max_length=10, null=False)
	create_time = models.DateTimeField(null = False)
	modify_time = models.DateTimeField(null = False)
	visible_to_user = models.BooleanField(default=False)
	submittedUrl = models.CharField(max_length=2000, null=False)
	protocol = models.CharField(max_length=10, null=False)
	path = models.CharField(max_length=2000, null=False)
	follow_redirect = models.BooleanField('Follows 1 redirect if true, OLC support', default=False)
	use_sub_files = models.BooleanField('chunking', default=False)
	rewrite_rules = models.TextField('Rewrite Rules pre-validation', blank=True, help_text="Applied before validation, post-validation is preferred.")
	rewrite_rules_post_validation =  models.TextField('Rewrite Rules post-validation', blank=True, help_text='These rules are applied after any validation is done.')
	custom_origin_headers =  models.TextField('custom headers to origin', blank=True, help_text='List of custom headers, one per line, e.g.: "X-Foo: bar"')
	custom_node_headers =  models.TextField('custom headers to each node', blank=True, help_text='List of custom headers, one per line, e.g.: "X-Foo: bar"')
	case_insensitive_urls =  models.BooleanField('Case-insensitive Urls', default=False, help_text="If on, all urls will be lower-cased upon entering the CS.")
	drop_params = models.BooleanField('Drop query string pre-validation', default=False, help_text="Should Panther's cache ignore the query string in URLs when caching? (see Implementation Guide for details)")
	drop_precise_params_post_validation = models.CharField('Drop specific params from query string', blank=True, max_length=255, help_text='Comma-separated list of parameters to drop from query string post validation.')
	service = models.ForeignKey(ServiceInfo, null=True)
	customername = models.CharField(max_length=150)
	origin = models.CharField(max_length=270, db_column='domain', help_text='This is the domain for the Panther cache to get content from on cache misses or refreshes (e.g. origin.example.com)')
	pad = models.CharField('PAD', max_length=255, db_column='serve_domain', help_text='Panther Accelerated Domain: the domain that Panther is serving content for (e.g. cache.example.com)')
	verifyHeaders = models.CharField(max_length=2000, null=False)
	originHeader = models.TextField()
	state = models.PositiveSmallIntegerField(default=0)
	totalNodes = models.PositiveIntegerField(default=0)
	activeNodes = models.PositiveIntegerField(default=0)
	uptoDateActiveNodes = models.PositiveIntegerField(default=0)
	uptoDateOfflineNodes = models.PositiveIntegerField(default=0)
	partialCachedActiveNodes = models.PositiveIntegerField(default=0)
	partialCachedOfflineNodes = models.PositiveIntegerField(default=0)
	notCachedActiveNodes = models.PositiveIntegerField(default=0)
	notCachedOfflineNodes = models.PositiveIntegerField(default=0)
	oldestFetchTime = models.DateTimeField(null = True)
	oldestFetchNode = models.ForeignKey(NodeInfo, null = True)
	class Meta:
		db_table = 'cache_checker'
		app_label = 'support'
	def save(self):
		if not self.id:
			self.create_time = datetime.now()
		self.modify_time = datetime.now()
		super(CacheChecker, self).save()
	def toDictionary(self):
		dict = {}
		dict['id'] = self.id
		dict['submittedUrl'] = self.submittedUrl
		dict['customername'] = self.customername
		dict['create_user'] = self.create_user
		dict['create_time'] = self.create_time
		dict['state'] = self.state
		dict['stateDescription'] = self.stateDescription()
		dict['detailedNodeDescription'] = self.detailedNodeDescription()
		dict ['detailedPopDescription'] = self.detailedPopDescription()
		return dict
	def stateDescription(self):
		if self.state == 0:
			return "In Queue"
		elif self.state == 1:
			return "In Progress"
		elif self.state == 2:
			return "See Results"
		elif self.state == 3:
			return "Duplicate entry skipping processing"
		elif self.state == 4:
			return "Domain not configured as a PAD"
		elif self.state == 5:
			return "PAD not configured properly"
		elif self.state == 6:
			return "Invalid response from origin"
		elif self.state == 7:
			return "No pops associated with PAD"
		elif self.state == 8:
			return "Error retrieving file from origin"
		elif self.state == 9:
			return "Cache checking not successful on all pops"
		elif self.state == 10:
			return "Error processing request"
		return "Unknown"
	def detailedNodeDescription(self):
		if self.state != 2:
			return ""
		elif self.totalNodes == 0 or self.activeNodes == 0:
			return "Error trying to check cache status, please contact support"
		elif self.activeNodes == self.uptoDateNodes():
			return "Proper file cached across all nodes"
		elif self.activeNodes == self.notCachedNodes():
			return "File not cached on any nodes"
		if self.uptoDateNodes() == 0:
			resp = "No nodes with cache matching origin."
		else:
			resp = str(round(float(self.uptoDateNodes())/float(self.activeNodes)*100,1)) + \
				"% of nodes have cache matching origin."
		if self.outDatedNodes() == 0:
			resp += "\nNo nodes with out dated cache."
		else:
			resp += "\n" + str(round(float(self.outDatedNodes())/float(self.activeNodes)*100,1)) + \
				"% of nodes have out dated cache."
		return resp
	def detailedPopDescription(self):
		if self.state != 2:
			return ""
		elif self.totalPops() == 0 or self.activePops() == 0:
			return "Error checking PoP level cache status, please contact support"
		elif self.activePops() == self.uptoDatePops():
			return "Proper file cached across all PoPs"
		elif self.activePops() == self.notCachedPops():
			return "File not cached on any PoPs"
		if self.uptoDatePops() == 0:
			resp = "No PoPs with cache matching origin."
		else:
			resp = str(round(float(self.uptoDatePops())/float(self.activePops())*100,1)) + \
				"% of PoPs have cache matching origin."
		if self.outDatedPops() == 0:
			resp += "\nNo PoPs with out dated cache."
		else:
			resp += "\n" + str(round(float(self.outDatedPops())/float(self.activePops())*100,1)) + \
				"% of PoPs have out dated cache."

		return resp
	def offlineNodes(self):
		return self.totalNodes - self.activeNodes
	def uptoDateNodes(self):
		return self.uptoDateActiveNodes + self.uptoDateOfflineNodes
	def partialCachedNodes(self):
		return self.partialCachedActiveNodes + self.partialCachedOfflineNodes
	def notCachedNodes(self):
		return self.notCachedActiveNodes + self.notCachedOfflineNodes
	def getUnreachableNodes(self):
		try:
			return self.cachecheckernodefailures_set.filter(outcome = 3)
		except ObjectDoesNotExist:
			return None
	def getUnreachableActiveNodes(self):
		try:
			return self.cachecheckernodefailures_set.filter(outcome = 3).filter(offline = False)
		except ObjectDoesNotExist:
			return None
	def getUnreachableOfflineNodes(self):
		try:
			return self.cachecheckernodefailures_set.filter(outcome = 3).filter(offline = True)
		except ObjectDoesNotExist:
			return None
	def unreachableNodes(self):
		unreach = self.getUnreachableNodes()
		if unreach == None:
			return 0
		return unreach.count()
	def unreachableActiveNodes(self):
		unreach = self.getUnreachableActiveNodes()
		if unreach == None:
			return 0
		return unreach.count()
	def unreachableOfflineNodes(self):
		unreach = self.getUnreachableOfflineNodes()
		if unreach == None:
			return 0
		return unreach.count()
	def getOutDatedNodes(self):
		try:
			return self.cachecheckernodefailures_set.filter(outcome = 4)
		except ObjectDoesNotExist:
			return None
	def getOutDatedActiveNodes(self):
		try:
			return self.cachecheckernodefailures_set.filter(outcome = 4).filter(offline = False)
		except ObjectDoesNotExist:
			return None
	def getOutDatedOfflineNodes(self):
		try:
			return self.cachecheckernodefailures_set.filter(outcome = 4).filter(offline = True)
		except objectDoestNotExist:
			return None
	def outDatedNodes(self):
		outdated = self.getOutDatedNodes()
		if outdated == None:
			return 0
		return outdated.count()
	def outDatedActiveNodes(self):
		outdated = self.getOutDatedActiveNodes()
		if outdated == None:
			return 0
		return outdated.count()
	def outDatedOfflineNodes(self):
		outdated = self.getOutDatedOfflineNodes()
		if outdated == None:
			return 0
		return outdated.count()
	def outDatedFlushedAndExpiredNodes(self):
		try:
			return self.cachecheckernodefailures_set.filter(outcome = 5).count()
		except ObjectDoesNotExist:
			return 0
	def outDatedFlushedNodes(self):
		try:
			return self.cachecheckernodefailures_set.filter(outcome = 6).count()
		except ObjectDoesNotExist:
			return 0
	def outDatedExpiredNodes(self):
		try:
			return self.cachecheckernodefailures_set.filter(outcome = 7).count()
		except ObjectDoesNotExist:
			return 0
	def uptoDateFlushedAndExpiredNodes(self):
		try:
			return self.cachecheckernodefailures_set.filter(outcome = 8).count()
		except ObjectDoesNotExist:
			return 0
	def uptoDateFlushedNodes(self):
		try:
			return self.cachecheckernodefailures_set.filter(outcome = 9).count()
		except ObjectDoesNotExist:
			return 0
	def uptoDateExpiredNodes(self):
		try:
			return self.cachecheckernodefailures_set.filter(outcome = 10).count()
		except ObjectDoesNotExist:
			return 0
	def allNotCachedNodes(self):
		try:
			return self.notCachedNodes() + \
				self.cachecheckernodefailures_set.filter(outcome__in = [5,6,7,8,9]).count()
		except ObjectDoesNotExist:
			return 0
	def allNotCachedActiveNodes(self):
		try:
			return self.notCachedActiveNodes + \
				self.cachecheckernodefailures_set.filter(outcome__in = [5,6,7,8,9]). \
				filter(offline = False).count()
		except ObjectDoesNotExist:
			return 0
	def allNotCachedOfflineNodes(self):
		try:
			return self.notCachedOfflineNodes + \
				self.cachecheckernodefailures_set.filter(outcome__in = [5,6,7,8,9]). \
				filter(offline = True).count()
		except ObjectDoesNotExist:
			return 0
	def reachedNodes(self):
		return self.totalNodes - self.unreachabbleNodes()
	def getFetchTimeErrorNodes(self):
		try:
			return self.cachecheckernodefailures_set.filter(outcome = 11)
		except ObjectDoesNotExist:
			return None
	def fetchTimeErrors(self):
		errors = self.getFetchTimeErrorNodes()
		if errors == None:
			return 0
		return errors.count()
	def totalPops(self):
		try:
			return self.cachecheckerpopinfo_set.count()
		except ObjectDoesNotExist:
			return 0
	def uptoDatePops(self):
		try:
			return self.cachecheckerpopinfo_set.filter(outcome = 5).count()
		except ObjectDoestNotExist:
			return 0
	def outDatedPops(self):
		try:
			return self.cachecheckerpopinfo_set.filter(outcome = 4).count()
		except ObjectDoesNotExist:
			return 0
	def notCachedPops(self):
		try:
			return self.cachecheckerpopinfo_set.filter(outcome =  8).count()
		except ObjectDoesNotExist:
			return 0
	def unreachablePops(self):
		try:
			return self.cachecheckerpopinfo_set.filter(outcome = 12).count()
		except ObjectDoesNotExist:
			return 0
	def getActivePops(self):
		try:
			return self.cachecheckerpopinfo_set.exclude(outcome__in = [1,2]).order_by('-outcome')
		except ObjectDoesNotExist:
			return None
	def getNotUptoDatePops(self):
		try:
			return self.cachecheckerpopinfo_set.exclude(outcome__in = [1,2,5]).order_by('-outcome')
		except ObjectDoesNotExist:
			return None
	def offlinePops(self):
		try:
			return self.cachecheckerpopinfo_set.filter(outcome__in = [1,2]).count()
		except ObjectDoesNotExist:
			return 0
	def activePops(self):
		try:
			return self.cachecheckerpopinfo_set.exclude(outcome__in = [1,2]).count()
		except ObjectDoesNotExist:
			return 0

class CacheCheckerPopInfo(models.Model):
	cachechecker = models.ForeignKey(CacheChecker)
	pop = models.ForeignKey(PopInfo)
	node = models.ForeignKey(NodeInfo, null=True)
	affinityStep = models.PositiveSmallIntegerField(default = 5)
	outcome = models.PositiveSmallIntegerField(default=0)
	outcomeText = models.CharField(max_length=200)
	header = models.TextField()
	partialCache = models.BooleanField(default=False)
	failedHeaders = models.CommaSeparatedIntegerField(max_length=255)
	nodeFailures = models.ForeignKey('CacheCheckerNodeFailures', null=True)
	class Meta:
		db_table = 'cache_checker_pop_info'
		app_label = 'support'
	def outcomeDescription(self):
		if self.outcomeText != "":
			return self.outcomeText
		if self.outcome == 1:
			return "PoP offline"
		if self.outcome == 2:
			return "All nodes offline"
		if self.outcome == 3:
			return "Invalid response from node"
		if self.outcome == 4:
			return "Cache does not match origin"
		if self.outcome == 5:
			return "Cache matches origin"
		if self.outcome == 6:
			return "Request failed on every node"
		if self.outcome == 7:
			return "PAD or Node configuration error"
		if self.outcome == 8:
			return "File not cached"
		if self.outcome == 9:
			return "Cache does not match origin but is expired and flushed"
		if self.outcome == 10:
			return "Cache does not match origin but is flushed"
		if self.outcome == 11:
			return "Cache does not match origin but is expired"
		if self.outcome == 12:
			return "Could not reach any affinity nodes"
		return "Unknown"

class CacheCheckerNodeFailures(models.Model):
	cachechecker = models.ForeignKey(CacheChecker, null=True)
	node = models.ForeignKey(NodeInfo)
	outcome = models.PositiveSmallIntegerField(default=0)
	outcomeText = models.CharField(max_length=200)
	header = models.TextField()
	partialCache = models.BooleanField(default=False)
	offline = models.BooleanField(default=True)
	failedHeaders = models.CommaSeparatedIntegerField(max_length=255)
	fetchTime = models.DateTimeField(null = True)
	class Meta:
		db_table = 'cache_checker_node_failures'
		app_label = 'support'
	def outcomeDescription(self):
		if self.outcomeText != "":
			return self.outcomeText
		if self.outcome == 3:
			return "Node Unreachable"
		if self.outcome == 4:
			return "Cache does not match origin"
		if self.outcome == 5:
			return "Cache does not match origin but is expired and flushed"
		if self.outcome == 6:
			return "Cache does not match origin but is flushed"
		if self.outcome == 7:
			return "Cache does not match origin but is expired"
		if self.outcome == 8:
			return "Cache matches origin but is expired and flushed"
		if self.outcome == 9:
			return "Cache matches origin but is flushed"
		if self.outcome == 10:
			return "Cache matches origin but is expired"
		if self.outcome == 11:
			return "Invalid fetch time"
		if self.outcome == 12:
			return "Error processing"
		return "Unknown"

class HttpChecker(models.Model):
	create_time = models.DateTimeField(null=False)
	modify_time = models.DateTimeField(null=False)
	state = models.PositiveSmallIntegerField(default=0)
	email = models.BooleanField(default=False)
	email_time = models.DateTimeField(null=True)
	totalNodes = models.PositiveIntegerField(default=0)
	class Meta:
		db_table = 'http_checker'
		app_label = 'support'
	def save(self):
		if not self.id:
			self.create_time = datetime.now()
		self.modify_time = datetime.now()
		super(HttpChecker, self).save()
	def toDictionary(self):
		dict = {}
		dict['id'] = self.id
		dict['create_time'] = self.create_time
		dict['modify_time'] = self.modify_time
		dict['state'] = self.state
		dict['stateDescription'] = self.stateDescription()
		dict['email'] = self.email
		dict['email_time'] = self.email_time
		dict['totalNodes'] = self.totalNodes
		dict['misconfiguredNodes'] = self.httpcheckernode_set.filter(outcome = 2).count()
		return dict
	def stateDescription(self):
		if self.state == 0:
			return "In Queue"
		elif self.state == 1:
			return "In Progress"
		elif self.state == 2:
			return "See Results"
		elif self.state == 3:
			return "Will only run one http checker at a time"
		elif self.state == 10:
			return "Error processing request"
	def getReachedNodes(self):
		try:
			return self.httpcheckernode_set.filter(outcome = 1). \
				order_by('version__name', 'name')
		except ObjectDoesNotExist:
			return None
	def getUnreachableNodes(self, unreached_since = None, filter_http = False):
		try:
			unreach = self.httpcheckernode_set.exclude(outcome=1).filter(node__pop__importance__gte=0).order_by('-httpcheckerlastseennode__modify_time')
			if filter_http:
				unreach = unreach.filter(http = True)
			if unreached_since != None:
				unreach = unreach.exclude(httpcheckerlastseennode__modify_time__gte = unreached_since)
			return unreach
		except ObjectDoesNotExist:
			return None
	def getRedirectingNodes(self):
		try:
			return self.httpcheckernode_set.filter(redirecting = True)
		except ObjectDoesNotExist:
			return None
	def getDeadNodes(self):
		try:
			return self.httpcheckernode_set.filter(dead = True)
		except ObjectDoesNotExist:
			return None
	def getNonHttpNodesServingHttp(self):
		try:
			return self.getReachedNodes().filter(http = False)
		except ObjectDoesNotExist:
			return None
	def getBrokenNodesServingHttp(self):
		try:
			return self.getReachedNodes().filter(broken = True, redirecting = True)
		except ObjectDoesNotExist:
			return None
	def getBucketlessNodesServingHttp(self):
		try:
			return self.getReachedNodes().filter(buckets = False)
		except ObjectDoesNotExist:
			return None
	def getBehindFlushNodes(self, lagging_by = 1000):
		try:
			acceptable = self.getReachedNodes().latest('last_flush_id').last_flush_id - lagging_by
			return self.getReachedNodes().filter(last_flush_id__lte =acceptable)
		except ObjectDoesNotExist:
			return None
		except TypeError:
			return self.httpcheckernode_set.filter(id=None)
	def getBehindHttpSitesNodes(self, behind_seconds = 300, base_time=None):
		try:
			if base_time == None or not isinstance(base_time,datetime):	
				base_time = self.getReachedNodes().latest('http_sites_time').http_sites_time
			acceptable = base_time - timedelta(seconds=behind_seconds)
			return self.getReachedNodes().filter(http_sites_time__lte = acceptable)
		except ObjectDoesNotExist:
			return None
		except TypeError:
			return self.httpcheckernode_set.filter(id=None)
	def getBehindCacheConfigNodes(self, behind_seconds = 600, base_time=None):
		try:
			if base_time == None or not isinstance(base_time,datetime):	
				base_time = self.getReachedNodes().latest('cache_config_time').cache_config_time
			acceptable =  base_time - timedelta(seconds=behind_seconds)
			return self.getReachedNodes().filter(cache_config_time__lte = acceptable)
		except ObjectDoesNotExist:
			return None
		except TypeError:
			return self.httpcheckernode_set.filter(id=None)
class HttpCheckerVersion(models.Model):
	create_time = models.DateTimeField(null=False)
	name = models.CharField(max_length=200, unique=True)
	class Meta:
		db_table = 'http_checker_version'
		app_label = 'support'
	def save(self):
		if not self.id:
			self.create_time = datetime.now()
		super(HttpCheckerVersion, self).save()
	
class HttpCheckerLastSeenNode(models.Model):
	node = models.ForeignKey(NodeInfo, null=False, unique=True)
	version = models.ForeignKey(HttpCheckerVersion, null=True)
	create_time = models.DateTimeField(null=False)
	modify_time = models.DateTimeField(null=False)
	class Meta:
		db_table = 'http_checker_last_seen_node'
		app_label = 'support'
	def save(self):
		if not self.id:
			self.create_time = datetime.now()
		self.modify_time = datetime.now()
		super(HttpCheckerLastSeenNode, self).save()

class HttpCheckerNode(models.Model):
	node = models.ForeignKey(NodeInfo, null=False)
	httpchecker = models.ForeignKey(HttpChecker, null=False)
	httpcheckerlastseennode = models.ForeignKey('HttpCheckerLastSeenNode', null=True)
	create_time = models.DateTimeField(null=False)
	modify_time = models.DateTimeField(null=False)
	node_time = models.DateTimeField(null=True)
	lookup_time = models.DateTimeField(null=False)
	version = models.ForeignKey(HttpCheckerVersion, null=True)
	outcome = models.PositiveSmallIntegerField(default=0)
	outcomeText = models.CharField(max_length=200)
	offline = models.BooleanField(default=True)
	broken = models.BooleanField(default=False)
	dns = models.BooleanField(default=False)
	http = models.BooleanField(default=True)
	buckets = models.BooleanField(default=False)
	shield = models.BooleanField(default=False)
	name = models.CharField(max_length=100)
	redirecting = models.BooleanField(default=False)
	dead = models.BooleanField(default=False)
	http_sites_time = models.DateTimeField(null=True)
	cache_config_time = models.DateTimeField(null=True)
	last_flush_time = models.DateTimeField(null=True)
	last_flush_id = models.PositiveIntegerField(default=0)
	class Meta:
		db_table = 'http_checker_node'
		app_label = 'support'
	def save(self):
		if not self.id:
			self.create_time = datetime.now()
		self.modify_time = datetime.now()
		super(HttpCheckerNode,self).save()
	def outcomeDescription(self):
		if self.outcomeText != "":
			return self.outcomeText
		if self.outcome == 1:
			return "Reached Node"
		if self.outcome == 2:
			return "Error processing"
		if self.outcome == 3:
			return "Node Unreachable"
	def timeDiff(self):
		if self.lookup_time == None or self.node_time == None:
			return None
		return abs(self.lookup_time - self.node_time)

class TestUrl(models.Model):
	create_user = models.CharField(max_length=10, null=False)
	create_time = models.DateTimeField(null=False)
	modify_time = models.DateTimeField(null=False)
	visible_to_user = models.BooleanField(default=False)
	customername = models.CharField(max_length=150)
	submittedUrl = models.CharField(max_length=2000, null=False)
	domain = models.CharField(max_length=270, null=False)
	path = models.CharField(max_length=2000, null=False)
	key = models.CharField(max_length=8, null=False)
	jira_ticket = models.CharField(max_length=100)
	class Meta:
		db_table = 'test_url'
		app_label = 'support'
	def save(self):
		if not self.id:
			self.create_time = datetime.now()
		self.modify_time = datetime.now()
		super(TestUrl, self).save()
	def toDictionary(self):
		dict = {}
		dict['id'] = self.id
		dict['auth_key'] = self.key + str(self.id)
		dict['create_user'] = self.create_user
		dict['create_time'] = self.create_time
		dict['customername'] = self.customername
		dict['submittedUrl'] = self.submittedUrl
		dict['ticket'] = self.jira_ticket
		dict['submissions'] = self.testurlsubmission_set.count()
		return dict

class TestUrlSubmission(models.Model):
	testurl = models.ForeignKey(TestUrl, null=False)
	create_time = models.DateTimeField(null=False)
	received_from_ip = models.CharField(max_length=20)
	submitter_name = models.CharField(max_length=200)
	submitter_email = models.CharField(max_length=200)
	operating_system = models.CharField(max_length=200)
	browser = models.CharField(max_length=200)
	user_ip = models.CharField(max_length=50)
	domain_ip = models.CharField(max_length=50)
	a_record = models.TextField()
	txt_record = models.TextField()
	cname_record = models.TextField()
	ping = models.TextField()
	traceroute = models.TextField()
	test_download = models.TextField()
	class Meta:
		db_table = 'test_url_submission'
		app_label = 'support'
	def save(self):
		if not self.id:
			self.create_time = datetime.now()
		super(TestUrlSubmission, self).save()

class PollingSystem(models.Model):
	state_choices = ((0,"In Queue"),(1,"In Progress"),(2,"See Results"),(10,"Error processing request"),(99,"Loading"))
	app_choices = ((0, 'nmon'),(1, 'dns'),(2,'ping'),(3,'cs'),(4,'logxfer'))
	app_ports = {0: 8410, 1:8402, 2: 8499, 3: 80,4:8412}
	response_choices = ((0, 'json'),(1, 'all'),(2,'regex'),(3,'matching line'))
	create_user = models.CharField(max_length=10, null=False)
	create_time = models.DateTimeField(null=False)
	modify_time = models.DateTimeField(null=False)
	state = models.PositiveSmallIntegerField(default=99, choices=state_choices)
	app = models.PositiveSmallIntegerField(choices=app_choices)
	uri = models.CharField(max_length=2000, null=False)
	response_type = models.PositiveSmallIntegerField(choices=response_choices, default=0)
	response_modifier = models.CharField(max_length=2000, null=True, 
		help_text="This is how to parse the response and doubles as the header in the response")
	additional_headers = models.CharField(max_length=2000,null=True)
	class Meta:
		db_table = 'poll_system'
		app_label = 'support'
	def save(self):
		if not self.id:
			self.create_time = datetime.now()
		self.modify_time = datetime.now()
		super(PollingSystem, self).save()
	def toDictionary(self):
		dict = {}
		dict['id'] = self.id
		dict['create_user'] = self.create_user
		dict['create_time'] = self.create_time
		dict['modify_time'] = self.modify_time
		dict['state'] = self.state
		dict['stateDescription'] = self.get_state_display()
		dict['app'] = self.get_app_display()
		dict['uri'] = self.uri
		dict['response_modifier'] = self.response_modifier
		dict['create_user'] = self.create_user
		return dict
	def getPort(self):
		return self.app_ports.get(self.app)
	def getSpecialParams(self):
		return {}
	def getUnsetSpecialParams(self):
		if self.app == 3:
			return {pycurl.COOKIE: "",}
		return {}
	def getReachedNodes(self):
		try:
			return self.pollingsystemnode_set.filter(outcome__in = [1,4]). \
				order_by('node')
		except ObjectDoesNotExist:
			return None
	def getUnreachableNodes(self):
		try:
			return self.pollingsystemnode_set.exclude(outcome__in = [1,4]). \
				order_by('node')
		except ObjectDoesNotExist:
			return None

class PollingSystemNode(models.Model):
	outcome_options = ((0,'Pending'),(1,'Reached Node'),(2,'Error processing'),(3,'Node Unreachable'),(4,'Issue Detected'))
	node = models.ForeignKey(NodeInfo, null=False)
	pollsystem = models.ForeignKey(PollingSystem, null=False)
	outcome = models.PositiveSmallIntegerField(default=0, choices=outcome_options)
	outcomeText = models.CharField(max_length=200)
	response = models.TextField(null=True)
	class Meta:
		db_table = 'poll_system_node'
		app_label = 'support'
