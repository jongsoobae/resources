# required for all views in other files or subdirectories
# that you want to access in the 'ui.oui.views' urlpattern
# of urls.py
from json import *
