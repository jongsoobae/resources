import re
from os import popen
from datetime import datetime
from random import randint
from array import array
from sui.support.models import Preheat, CacheChecker, \
	HttpChecker, HttpCheckerVersion, TestUrl, TestUrlSubmission, \
	NodeInfo, PopInfo, ServiceInfo, PollingSystem, PollingSystemNode
from django import forms
from django.core.cache import cache
from django.core.exceptions import ObjectDoesNotExist
from django.http import Http404, HttpResponse
from django.utils import simplejson
from django.template.loader import get_template
from django.template import Context
from django.db.models import query, manager

class queryAndDateEncoder(simplejson.JSONEncoder):
	def default(self, obj):
		if isinstance(obj, datetime):
			return '@' + obj.isoformat() + '@'
		if isinstance(obj, query.ValuesQuerySet):
			return list(obj)
		if isinstance(obj, manager.Manager) or \
				isinstance(obj, query.QuerySet):
			return list(obj.values())
		return simplejson.JSONEncoder.default(self, obj)

def createKey():
	"""Returns 8 numeric/lower case character sequence"""
	key = []
	while len(key) < 8:
		val = randint(48,83)
		if val > 57:
			val += 39
		key.append(val)
	return array('B', key).tostring()

def getHttpVersionsWithCount(httpCheckerNodeSet, byPoP=False):
	verList = []
	try:
		nodes = httpCheckerNodeSet.filter(version__isnull = False)
		if byPoP:
			nodes = nodes.order_by('node__pop__shortname','version')
		else:
			nodes = nodes.order_by('version')
		lastVersion = ""
		lastPoP = ""
		count = 0
		for n in nodes:
			if lastVersion != n.version.name or (byPoP and lastPoP != n.node.pop.shortname):
				if count != 0:
					ver = {'name': lastVersion, 'nodes':count}
					if byPoP:
						ver['pop'] = lastPoP
					verList.append(ver)
				lastVersion = n.version.name
				lastPoP = n.node.pop.shortname
				count = 0
			count += 1
		ver = {'name': lastVersion, 'nodes':count}
		if byPoP:
			ver['pop'] = lastPoP
		verList.append(ver)
	except:
		pass
	return verList

def getBadTimeStampNodes(httpCheckerNodeSet, time_diff='00:02:00'):
	"""time_diff needs to be in format HH:MI:SS

	WARNING: time_diff is added directly to the sql and could be used for injection SQL
	NEVER EVER allow this to be passed from user input of a website/external call!"""
	badTimeNodes = []
	for n in httpCheckerNodeSet.extra(where= ["(timediff(lookup_time, node_time) > '%s' or timediff(node_time, lookup_time) > '%s')" %(time_diff, time_diff)]):
		badTimeNodes.append({'name':n.name,
			'id': n.node.id,
			'timeDiff': str(n.timeDiff()),
			'dns': n.dns,
			'offline': n.offline,
			'broken': n.broken,
			'shield': n.shield})
	return badTimeNodes

def oldestUpdateId(model_obj):
	if model_obj != None:
		try:
			return model_obj.filter(state__in = [1,2,99]). \
				order_by('-create_time')[0].id
		except:
			try:
				return model_obj.model.objects. \
					order_by('-id')[0].id + 1
			except:
				return 0

def commonFilter(form, obj):
	class PreheatFilterForm(forms.Form):
		filter_by_user = forms.CharField(required=False)
		filter_by_visible_to_user = forms.NullBooleanField(required=False)
		filter_by_customer = forms.CharField(required=False)
		filter_by_url = forms.CharField(required=False)
		filter_by_min_id = forms.IntegerField(required=False)
	if form:
		filter_form = PreheatFilterForm(form)
		if filter_form.is_valid():
			if filter_form.cleaned_data['filter_by_visible_to_user'] != None:
				obj = obj. \
					filter(visible_to_user=filter_form.cleaned_data['filter_by_visible_to_user'])
			if filter_form.cleaned_data['filter_by_user']:
				obj = obj. \
					filter(create_user=filter_form.cleaned_data['filter_by_user'])
			if filter_form.cleaned_data['filter_by_customer']:
				obj = obj. \
					filter(customername__icontains = \
					filter_form.cleaned_data['filter_by_customer'])
			if filter_form.cleaned_data['filter_by_url']:
				obj = obj. \
					filter(submittedUrl__icontains = \
					filter_form.cleaned_data['filter_by_url'])
			if filter_form.cleaned_data['filter_by_min_id']:
				obj = obj. \
					filter(id__gte = filter_form. \
					cleaned_data['filter_by_min_id'])
			obj = obj.distinct()
	else:
		filter_form = PreheatFilterForm()
	obj = obj.order_by('-create_time')
	return obj

def preheatList(pRequest):
	passObjects = {'preheat':[]}
	preheat = commonFilter(pRequest.GET,Preheat.objects.select_related())
	for p in preheat:
		passObjects['preheat'].append(p.toDictionary())
	passObjects['oldestUpdateNeeded'] = \
		oldestUpdateId(passObjects['preheat'])
	return HttpResponse(simplejson.dumps(passObjects, cls=queryAndDateEncoder, ensure_ascii=False), mimetype='text/plain; charset=utf-8')

def preheatRequest(pRequest):
	preheat_form = pRequest.POST
	resp = {}
	try:
		if preheat_form['visible_to_user'] == "True":
			visible = True
		else:
			visible = False
		if preheat_form['override_size'] == "True":
			override = True
		else:
			override = False
		preheat = Preheat(create_user = preheat_form['create_user'],
			visible_to_user = visible,
			submittedUrl = preheat_form['submittedUrl'],
			protocol = preheat_form['protocol'],
			path = preheat_form['path'],
			follow_redirect = preheat_form['follow_redirect'] in ["1",1,u"1"],
			use_sub_files = preheat_form['use_sub_files'] in ["1",1,u"1"],
			rewrite_rules = preheat_form['rewrite_rules'],
			rewrite_rules_post_validation = preheat_form['rewrite_rules_post_validation'],
			custom_origin_headers = preheat_form['custom_origin_headers'],
			custom_node_headers = preheat_form['custom_node_headers'],
			case_insensitive_urls = preheat_form['case_insensitive_urls'] in ["1",1,u"1"],
			drop_params = preheat_form['drop_params'] in ["1",1,u"1"],
			drop_precise_params_post_validation = preheat_form['drop_precise_params_post_validation'],
			#service = ServiceInfo.objects.get(dns_prefix = preheat_form['service_dns_prefix']),
			customername = preheat_form['customername'],
			origin = preheat_form['origin'],
			pad = preheat_form['pad'],
			verifyHeaders = preheat_form['verifyHeaders'],
			override_file_size = override)
		preheat.save()
	except Exception, e:
		resp['status'] = -1
		resp['error'] = e.message
	else:
		resp['status'] = 1
	return HttpResponse(simplejson.dumps(resp, cls=queryAndDateEncoder, ensure_ascii=False), mimetype='text/plain; charset=utf-8')

def preheatInfo(pRequest, object_id):
	passObjects = {} #{'preheat': Preheat.objects.select_related().order_by('-create_time')}
	ccId = int(object_id)
	try:
		preheatItem = Preheat.objects.get(id=ccId)
	except ObjectDoesNotExist:
		raise Http404
	if preheatItem.state < 2:
		raise Http404

	passObjects['preheatStatus'] = {}
	passObjects['preheatStatus']['submittedUrl'] = preheatItem.submittedUrl
	#passObjects['preheatStatus']['service'] = preheatItem.service.dns_prefix
	passObjects['preheatStatus']['verifyHeaders'] = preheatItem.verifyHeaders
        passObjects['preheatStatus']['originHeader'] = preheatItem.originHeader
	passObjects['preheatStatus']['stateDescription'] = preheatItem.stateDescription()
	passObjects['preheatStatus']['totalPops'] = preheatItem.totalPops()
	passObjects['preheatStatus']['activePops'] = preheatItem.activePops()
	passObjects['preheatStatus']['successfulPops'] = preheatItem.successfulPops()
	passObjects['preheatStatus']['succcessfulPartialPops'] = preheatItem.successfulPartialPops()
	passObjects['preheatStatus']['successfulPartialPops'] = preheatItem.successfulPartialPops()
	passObjects['preheatStatus']['offlinePops'] = preheatItem.offlinePops()
	passObjects['preheatStatus']['outDatedPops'] = preheatItem.outDatedPops()
	passObjects['preheatStatus']['unreachablePops'] = preheatItem.unreachablePops()
	passObjects['preheatStatus']['unexpectedOutcomePops'] = preheatItem.unexpectedOutcomePops()
	if passObjects['preheatStatus']['originHeader'].find("\r\nWARNING:") >= 0:
                #need to move warning text to error...
		pos = passObjects['preheatStatus']['originHeader'].find("\r\nWARNING:")
		passObjects['origin_head_error'] = [passObjects['preheatStatus']['originHeader'][pos+10:]]
		passObjects['preheatStatus']['originHeader'] = passObjects['preheatStatus']['originHeader'][:pos]
	passObjects['preheatStatus']['getPops'] = []
	for popinfo in preheatItem.getPops():
		popDict = {
			'shortname': popinfo.pop.shortname,
			'popid': popinfo.pop.id,
			'outcomeDescription': popinfo.outcomeDescription()}
		if popinfo.node != None:
			popDict['nodename'] = popinfo.node.name
			popDict['nodeid'] = popinfo.node.id
		passObjects['preheatStatus']['getPops'].append(popDict)
	passObjects['preheatStatus']['getOutDatedPops'] = []
	for popinfo in preheatItem.getOutDatedPops():
		passObjects['preheatStatus']['getOutDatedPops'].append({ \
			'failedHeaders': popinfo.failedHeaders,
			'header': popinfo.header,
			'nodename': popinfo.node.name,
			'nodeid': popinfo.node.id})
	return HttpResponse(simplejson.dumps(passObjects, cls=queryAndDateEncoder, ensure_ascii=False), mimetype='text/plain; charset=utf-8')

def cacheStatusList(pRequest):
	passObjects = {'cache': []}
	cache = commonFilter(pRequest.GET, CacheChecker.objects.select_related())
	for c in cache:
		passObjects['cache'].append(c.toDictionary())
	passObjects['oldestUpdateNeeded'] = \
		oldestUpdateId(CacheChecker.objects.all())
	return HttpResponse(simplejson.dumps(passObjects, cls=queryAndDateEncoder, ensure_ascii=False), mimetype='text/plain; charset=utf-8')

def cacheStatusInfo(pRequest, object_id):
	passObjects = {} #{'cacheChecker': CacheChecker.objects.select_related().order_by('-create_time')}
	ccId = int(object_id)
	try:
		cacheItem = CacheChecker.objects.get(id=ccId) #passObjects['cacheChecker'].get(id=ccId)
	except ObjectDoesNotExist:
		raise Http404
	if cacheItem.state < 2:
		raise Http404
	passObjects['cacheStatus'] = {}
	passObjects['cacheStatus']['submittedUrl'] = cacheItem.submittedUrl
	#passObjects['cacheStatus']['service_dns_prefix'] = cacheItem.service.dns_prefix
	passObjects['cacheStatus']['verifyHeaders'] = cacheItem.verifyHeaders
	passObjects['cacheStatus']['stateDescription'] = cacheItem.stateDescription()
	passObjects['cacheStatus']['detailedPopDescription'] = cacheItem.detailedPopDescription()
	passObjects['cacheStatus']['detailedNodeDescription'] = cacheItem.detailedNodeDescription()
	passObjects['cacheStatus']['originHeader'] = cacheItem.originHeader
	passObjects['cacheStatus']['oldestFetchTime'] = cacheItem.oldestFetchTime
	passObjects['cacheStatus']['oldestFetchNodeName'] = cacheItem.oldestFetchNode.name if cacheItem.oldestFetchNode else "N/A"
	passObjects['cacheStatus']['fetchTimeErrors'] = cacheItem.fetchTimeErrors()
	passObjects['cacheStatus']['use_sub_files'] = cacheItem.use_sub_files
	passObjects['cacheStatus']['totalNodes'] = cacheItem.totalNodes
	passObjects['cacheStatus']['activeNodes'] = cacheItem.activeNodes
	passObjects['cacheStatus']['uptoDateNodes'] = cacheItem.uptoDateNodes()
	passObjects['cacheStatus']['partialCachedNodes'] = cacheItem.partialCachedNodes()
	passObjects['cacheStatus']['notCachedNodes'] = cacheItem.notCachedNodes()
	passObjects['cacheStatus']['offlineNodes'] = cacheItem.offlineNodes()
	passObjects['cacheStatus']['unreachableNodes'] = cacheItem.unreachableNodes()
	passObjects['cacheStatus']['unreachableActiveNodes'] = cacheItem.unreachableActiveNodes()
	passObjects['cacheStatus']['unreachableOfflineNodes'] = cacheItem.unreachableOfflineNodes()
	passObjects['cacheStatus']['uptoDateActiveNodes'] = cacheItem.uptoDateActiveNodes
	passObjects['cacheStatus']['uptoDateOfflineNodes'] = cacheItem.uptoDateOfflineNodes
	passObjects['cacheStatus']['partialCachedActiveNodes'] = cacheItem.partialCachedActiveNodes
	passObjects['cacheStatus']['partialCachedOfflineNodes'] = cacheItem.partialCachedOfflineNodes
	passObjects['cacheStatus']['outDatedNodes'] = cacheItem.outDatedNodes()
	passObjects['cacheStatus']['outDatedActiveNodes'] = cacheItem.outDatedActiveNodes()
	passObjects['cacheStatus']['outDatedOfflineNodes'] = cacheItem.outDatedOfflineNodes()
	passObjects['cacheStatus']['allNotCachedNodes'] = cacheItem.allNotCachedNodes()
	passObjects['cacheStatus']['allNotCachedActiveNodes'] = cacheItem.allNotCachedActiveNodes()
	passObjects['cacheStatus']['allNotCachedOfflineNodes'] = cacheItem.allNotCachedOfflineNodes()
	passObjects['cacheStatus']['notCachedNodes'] = cacheItem.notCachedNodes()
	passObjects['cacheStatus']['outDatedFlushedAndExpiredNodes'] = cacheItem.outDatedFlushedAndExpiredNodes()
	passObjects['cacheStatus']['outDatedFlushedNodes'] = cacheItem.outDatedFlushedNodes()
	passObjects['cacheStatus']['outDatedExpiredNodes'] = cacheItem.outDatedExpiredNodes()
	passObjects['cacheStatus']['uptoDateFlushedAndExpiredNodes'] = cacheItem.uptoDateFlushedAndExpiredNodes()
	passObjects['cacheStatus']['uptoDateFlushedNodes'] = cacheItem.uptoDateFlushedNodes()
	passObjects['cacheStatus']['uptoDateExpiredNodes'] = cacheItem.uptoDateExpiredNodes()
	passObjects['cacheStatus']['totalPops'] = cacheItem.totalPops()
	passObjects['cacheStatus']['uptoDatePops'] = cacheItem.uptoDatePops()
	passObjects['cacheStatus']['notCachedPops'] = cacheItem.notCachedPops()
	passObjects['cacheStatus']['activePops'] = cacheItem.activePops()
	passObjects['cacheStatus']['offlinePops'] = cacheItem.offlinePops()
	passObjects['cacheStatus']['outDatedPops'] = cacheItem.outDatedPops()
	passObjects['cacheStatus']['notCachedPops'] = cacheItem.notCachedPops()
	passObjects['cacheStatus']['unreachablePops'] = cacheItem.unreachablePops()
	passObjects['cacheStatus']['getOutDatedNodes'] = []
	for cacheNode in cacheItem.getOutDatedNodes():
		passObjects['cacheStatus']['getOutDatedNodes'].append({ \
			'nodename': cacheNode.node.name,
			'nodeid': cacheNode.node.id,
			'failedHeaders': cacheNode.failedHeaders,
			'partialCache': cacheNode.partialCache,
			'header': cacheNode.header,
			'fetch': cacheNode.fetchTime})
	passObjects['cacheStatus']['getFetchTimeErrorNodes'] = []
	for cacheNode in cacheItem.getFetchTimeErrorNodes():
		passObjects['cacheStatus']['getFetchTimeErrorNodes'].append({ \
			'nodename': cacheNode.node.name,
			'nodeid': cacheNode.node.id,
			'outcomeDescription': cacheNode.outcomeDescription()})
	passObjects['cacheStatus']['getUnreachableActiveNodes'] = []
	for cacheNode in cacheItem.getUnreachableActiveNodes():
		passObjects['cacheStatus']['getUnreachableActiveNodes'].append({
			'nodename': cacheNode.node.name,
			'nodeid': cacheNode.node.id,
			'outcomeDescription': cacheNode.outcomeDescription()})
	passObjects['cacheStatus']['getActivePops'] = []
	for cachePop in cacheItem.getActivePops():
		popDict = { \
			'shortname': cachePop.pop.shortname,
			'popid': cachePop.pop.id,
			'outcomeDescription': cachePop.outcomeDescription()}
		if cachePop.node != None:
			popDict['nodename'] = cachePop.node.name
			popDict['nodeid'] = cachePop.node.id
		passObjects['cacheStatus']['getActivePops'].append(popDict)
	if passObjects['cacheStatus']['originHeader'].find("\r\nWARNING:") >= 0:
		#need to move warning text to error...
		pos = passObjects['cacheStatus']['originHeader'].find("\r\nWARNING:")
		passObjects['origin_head_error'] = [passObjects['cacheStatus']['originHeader'][pos+10:]]
		passObjects['cacheStatus']['originHeader'] = passObjects['cacheStatus']['originHeader'][:pos]
	return HttpResponse(simplejson.dumps(passObjects, cls=queryAndDateEncoder, ensure_ascii=False), mimetype='text/plain; charset=utf-8')

def cacheStatusHide(pRequest, object_id):
	ccId = int(object_id)
	resp = {}
	try:
		cacheItem = CacheChecker.objects.get(id=ccId)
	except ObjectDoesNotExist:
		raise Http404
	if not pRequest.GET or not pRequest.GET.has_key('auth_user'):
		resp['status'] = -1
		resp['error'] = "Requires create user for athentication"
	if cacheItem.create_user != pRequest.GET.get('auth_user'):
		resp['status'] = -1
		resp['error'] = "Authentication failed"
	else:
		cacheItem.visible_to_user = False
		cacheItem.save()
		resp['status'] = 1
	return HttpResponse(simplejson.dumps(resp,
			cls=queryAndDateEncoder, ensure_ascii=False), mimetype='text/plain; charset=utf-8')

def cacheStatusRequest(pRequest):
	"""Checks how many nodes have correct, outdate, and do not have the desired object (url) in memory/disk"""
	cache_form = pRequest.POST
	resp = {}
	try:
		if cache_form['visible_to_user'] == "True":
			visible = True
		else:
			visible = False

		cache = CacheChecker(create_user = cache_form['create_user'],
			visible_to_user = visible,
			submittedUrl = cache_form['submittedUrl'],
			protocol = cache_form['protocol'],
			path = cache_form['path'],
			follow_redirect = cache_form['follow_redirect'] in ["1",1,u"1"],
			use_sub_files = cache_form['use_sub_files'] in ["1",1,u"1"],
			rewrite_rules = cache_form['rewrite_rules'],
			rewrite_rules_post_validation = cache_form['rewrite_rules_post_validation'],
			custom_origin_headers = cache_form['custom_origin_headers'],
			custom_node_headers = cache_form['custom_node_headers'],
			case_insensitive_urls = cache_form['case_insensitive_urls'] in ["1",1,u"1"],
			drop_params = cache_form['drop_params'] in ["1",1,u"1"],
			drop_precise_params_post_validation = cache_form['drop_precise_params_post_validation'],
			#service = ServiceInfo.objects.get(dns_prefix = cache_form['service_dns_prefix']),
			customername = cache_form['customername'],
			origin = cache_form['origin'],
			pad = cache_form['pad'],
			verifyHeaders = cache_form['verifyHeaders'])
		cache.save()
	except Exception, e:
		resp['status'] = -1
		resp['error'] = e.message
	else:
		resp['status'] = 1
	return HttpResponse(simplejson.dumps(resp, cls=queryAndDateEncoder, ensure_ascii=False),
		mimetype='text/plain; charset=utf-8')

def serverCheckList(pRequest):
	passObjects = {'server': []}
	passObjects['oldestUpdateNeeded'] = \
		oldestUpdateId(HttpChecker.objects.all())
	server = HttpChecker.objects.select_related().order_by('-create_time')
	for s in server:
		passObjects['server'].append(s.toDictionary())
	return HttpResponse(simplejson.dumps(passObjects, cls=queryAndDateEncoder, ensure_ascii=False),
		mimetype='text/plain; charset=utf-8')

def serverCheckInfoFilterNodes(pRequest, nodes):
	"""This applies the filters for serverCheckInfo to ensure consistent filtering"""
	class ServerStatusFilterForm(forms.Form):
                filter_by_dns = forms.NullBooleanField(required=False)
                filter_by_offline = forms.NullBooleanField(required=False)
                filter_by_broken = forms.NullBooleanField(required=False)
                filter_by_shield = forms.NullBooleanField(required=False)
                popTuple = []
                for pop in PopInfo.objects.select_related():
                        popTuple.append((pop.id, pop.shortname))
                filter_by_pop = forms.MultipleChoiceField(choices=popTuple, required=False)
                nodeTuple = []
                for node in NodeInfo.objects.select_related():
                        nodeTuple.append((node.id, node.name))
                filter_by_node = forms.MultipleChoiceField(choices=nodeTuple, required=False)
                serviceTuple = []
                for service in ServiceInfo.objects.select_related():
                        serviceTuple.append((service.id, service.dns_prefix))
                filter_by_service = forms.MultipleChoiceField(choices=serviceTuple, required=False)

        if pRequest.GET and nodes != None:
                filter_form = ServerStatusFilterForm(pRequest.GET)
                if filter_form.is_valid():
                        if filter_form.cleaned_data['filter_by_dns'] != None:
                                nodes = \
                                        nodes. \
                                        filter(dns=filter_form.cleaned_data['filter_by_dns'])
                        if filter_form.cleaned_data['filter_by_offline']!= None:
                                nodes = \
                                        nodes. \
                                        filter(offline=filter_form.cleaned_data['filter_by_offline'])
                        if filter_form.cleaned_data['filter_by_broken'] != None:
                                nodes = \
                                        nodes. \
                                        filter(broken=filter_form.cleaned_data['filter_by_broken'])
                        if filter_form.cleaned_data['filter_by_shield']:
                                nodes = \
                                        nodes. \
                                        filter(shield=filter_form.cleaned_data['filter_by_shield'])
                        if filter_form.cleaned_data['filter_by_pop']:
                                nodes = \
                                        nodes. \
                                        filter(node__pop__id__in = filter_form.cleaned_data['filter_by_pop'])
                        if filter_form.cleaned_data['filter_by_node']:
                                nodes = \
                                        nodes. \
                                        filter(node__id__in = filter_form.cleaned_data['filter_by_node'])
                        if filter_form.cleaned_data['filter_by_service']:
                                nodes = \
                                        nodes. \
                                        filter(node__pop__serviceinfo__id__in = filter_form.cleaned_data['filter_by_service'])
                        nodes = nodes.distinct()
	return nodes

def serverCheckInfo(pRequest, object_id):
	passObjects = {} #{'httpChecker': HttpChecker.objects.all().order_by('-create_time')}
	ccId = int(object_id)
	try:
		serverStatus = HttpChecker.objects.get(id=ccId) #passObjects['httpChecker'].get(id=ccId)
	except ObjectDoesNotExist:
		raise Http404
	if serverStatus.state < 2:
		raise Http404
	passObjects['serverStatus'] = serverStatus.toDictionary()
	passObjects['unreachable'] = serverStatus.httpcheckernode_set.exclude(outcome = 2).filter(version__isnull = True).count()
	nodes = serverCheckInfoFilterNodes(pRequest,serverStatus.httpcheckernode_set)
	passObjects['versions'] = getHttpVersionsWithCount(nodes)
	passObjects['pop_versions'] = getHttpVersionsWithCount(nodes,byPoP=True)
	passObjects['reachedNodes'] = []
	for n in serverCheckInfoFilterNodes(pRequest, serverStatus.getReachedNodes()):
		passObjects['reachedNodes'].append({'name':n.name,
			'id': n.node.id,
			'versionname': n.version.name if n.version else 'Unknown',
			'dns': n.dns,
			'offline': n.offline,
			'broken': n.broken,
			'shield': n.shield,
		})
	passObjects['unreachableNodes'] = []
	for n in serverCheckInfoFilterNodes(pRequest, serverStatus.getUnreachableNodes()):
		dict = {'name':n.name,
			'id': n.node.id,
			'outcomeDescription': n.outcomeDescription(),
			'dns': n.dns,
			'offline': n.offline,
			'broken': n.broken,
			'shield': n.shield}
		if n.httpcheckerlastseennode != None:
			#should have always been modify time was a defect...so to require least change this is it...
			dict['lastsuccessful_create_time'] = n.httpcheckerlastseennode.modify_time
			dict['lastsuccessful_versionname'] = n.httpcheckerlastseennode.version.name
		passObjects['unreachableNodes'].append(dict)
	passObjects['redirectingNodes'] = []
	for n in serverCheckInfoFilterNodes(pRequest, serverStatus.getRedirectingNodes()):
		passObjects['redirectingNodes'].append({'name': n.name,
			'id': n.node.id,
			'dns': n.dns,
			'offline': n.offline,
			'broken': n.broken,
			'shield': n.shield})
	passObjects['deadNodes'] = []
	for n in serverCheckInfoFilterNodes(pRequest, serverStatus.getDeadNodes()):
		passObjects['deadNodes'].append({'name': n.name,
			'id': n.node.id,
			'dns': n.dns,
			'offline': n.offline,
			'broken': n.broken,
			'shield': n.shield})
	passObjects['nonHttpNodes'] = []
	for n in serverCheckInfoFilterNodes(pRequest, serverStatus.getNonHttpNodesServingHttp()):
		passObjects['nonHttpNodes'].append({'name': n.name,
			'id': n.node.id,
			'dns': n.dns,
			'offline': n.offline,
			'broken': n.broken,
			'shield': n.shield})
	passObjects['bucketlessNodes'] = []
	for n in serverCheckInfoFilterNodes(pRequest, serverStatus.getBucketlessNodesServingHttp()):
		passObjects['bucketlessNodes'].append({'name': n.name,
			'id': n.node.id,
			'dns': n.dns,
			'offline': n.offline,
			'broken': n.broken,
			'shield': n.shield})
	passObjects['behindFlushNodes'] = []
	passObjects['maxFlush'] = serverStatus.getReachedNodes().latest('last_flush_id').last_flush_id
	for n in serverCheckInfoFilterNodes(pRequest, serverStatus.getBehindFlushNodes()):
		passObjects['behindFlushNodes'].append({'name': n.name,
			'id': n.node.id,
			'flush_id': n.last_flush_id,
			'flush_time': n.last_flush_time,
			'dns': n.dns,
			'offline': n.offline,
			'broken': n.broken,
			'shield': n.shield})
	passObjects['behindHttpSitesNodes'] = []
	passObjects['maxHttpSites'] = serverStatus.getReachedNodes().latest('http_sites_time').http_sites_time
	for n in serverCheckInfoFilterNodes(pRequest, serverStatus.getBehindHttpSitesNodes()):
		passObjects['behindHttpSitesNodes'].append({'name': n.name,
			'id': n.node.id,
			'http_sites_time': n.http_sites_time,
			'dns': n.dns,
			'offline': n.offline,
			'broken': n.broken,
			'shield': n.shield})
	passObjects['behindCacheConfigNodes'] = []
	passObjects['maxCacheConfig'] = serverStatus.getReachedNodes().latest('cache_config_time').cache_config_time
	for n in serverCheckInfoFilterNodes(pRequest, serverStatus.getBehindCacheConfigNodes()):
		passObjects['behindCacheConfigNodes'].append({'name': n.name,
			'id': n.node.id,
			'cache_config_time': n.cache_config_time,
			'dns': n.dns,
			'offline': n.offline,
			'broken': n.broken,
			'shield': n.shield})
	passObjects['badTimeNodes'] = getBadTimeStampNodes(nodes, time_diff='00:00:30')
	return HttpResponse(simplejson.dumps(passObjects, cls=queryAndDateEncoder, ensure_ascii=False), mimetype='text/plain; charset=utf-8')

def serverCheckRequest(pRequest):
	"""Checks the cs version and system date on all of our http servers"""
	HttpChecker().save()
	resp = {'status': 1}
	return HttpResponse(simplejson.dumps(resp, cls=queryAndDateEncoder, ensure_ascii=False),
		mimetype='text/plain; charset=utf-8')

def pollingSystemList(pRequest):
	passObjects = {'poll': []}
	poll = commonFilter(pRequest.GET,PollingSystem.objects.select_related())
	for p in poll:
		passObjects['poll'].append(p.toDictionary())
	passObjects['oldestUpdateNeeded'] = oldestUpdateId(PollingSystem.objects.all())
	return HttpResponse(simplejson.dumps(passObjects, cls=queryAndDateEncoder, ensure_ascii=False),
		mimetype='text/plain; charset=utf-8')

def pollingSystemInfo(pRequest, object_id):
	passObjects = {}
	ccId = int(object_id)
	try:
		pollingSys = PollingSystem.objects.get(id=ccId)
	except ObjectDoesNotExist:
		raise Http404
	if pollingSys.state < 2 or pollingSys.state == 99:
		raise Http404
	passObjects['poll'] = pollingSys.toDictionary()
	try:
		passObjects['header'] = simplejson.loads(pollingSys.response_modifier)
	except:
		passObjects['header'] = pollingSys.response_modifier if pollingSys.response_modifier else "Result"
	passObjects['reachedNodes'] = []
	for n in pollingSys.getReachedNodes():
		res = {'name':n.node.hostname, 'id': n.node.id}
		try:
			res['response'] = simplejson.loads(n.response)
		except:
			res['response'] = [n.response]
		passObjects['reachedNodes'].append(res)
	passObjects['unreachedNodes'] = []
	for n in pollingSys.getUnreachableNodes():
		passObjects['unreachedNodes'].append({
			'name': n.node.hostname,
			'id': n.node.id,
			'outcomeDescription': n.outcomeText if n.outcomeText else n.get_outcome_display()
		})
	return HttpResponse(simplejson.dumps(passObjects, cls=queryAndDateEncoder, ensure_ascii=False), mimetype='text/plain; charset=utf-8')

def pollingSystemRequest(pRequest):
	polling_form = pRequest.POST
	resp = {}
	pollSys = None
	try:
		app_num = -1
		app_name = unicode(polling_form.get('app')) if polling_form.has_key('app') else u""
		for num,app in PollingSystem.app_choices:
			if app == app_name:
				app_num = num
				break
		if app_num == -1:
			raise Exception("Invalid application in request (%s)" %(app_name))
		node_ids = simplejson.loads(polling_form.get('nodes_json'))
		if len(node_ids) < 1:
			raise Exception("Must select atleast 1 node" + str(polling_form.get('nodes')))
		node_refs = []
		for node in node_ids:
			node_refs.append(NodeInfo.objects.get(id=node))
		pollSys = PollingSystem(app=app_num, uri=polling_form.get('command'), 
			create_user=polling_form.get('create_user'))
		if polling_form.has_key('response_type'):
			pollSys.response_type = polling_form.get('response_type')
		if polling_form.has_key('response_modifier'):
			pollSys.response_modifier = polling_form.get('response_modifier')
		pollSys.save()
		for node in node_refs:
			PollingSystemNode(node=node,
				pollsystem = pollSys).save()
		pollSys.state = 0
		pollSys.save()
	except Exception, e:
		if pollSys:
			pollSys.delete() #clean up a failed request...
		resp['status'] = -1
		import traceback
		resp['error'] = e.message
	else:
		resp['status'] = 1
	return HttpResponse(simplejson.dumps(resp, cls=queryAndDateEncoder, ensure_ascii=False),
		mimetype='text/plain; charset=utf-8')


def testUrlList(pRequest):
	passObjects = {'test':[]}
	test = commonFilter(pRequest.GET,TestUrl.objects.select_related())
	for t in test:
		passObjects['test'].append(t.toDictionary())
	return HttpResponse(simplejson.dumps(passObjects, cls=queryAndDateEncoder, ensure_ascii=False), mimetype='text/plain; charset=utf-8')

def testUrlRequest(pRequest):
	test_form = pRequest.POST
	resp = {}
	try:
		if test_form['visible_to_user'] == "True":
			visible = True
		else:
			visible = False
		test =TestUrl(create_user = test_form['create_user'],
			visible_to_user = visible,
			customername = test_form['customername'],
			submittedUrl = test_form['submittedUrl'],
			domain = test_form['domain'],
			path = test_form['path'],
			jira_ticket = test_form['ticket'])
		test.key = createKey()
		test.save()
	except Exception, e:
		resp['status'] = -1
		resp['error'] = e.message
	else:
		resp['status'] = 1
		resp['request_key'] = test.key + str(test.id)
	return HttpResponse(simplejson.dumps(resp, cls=queryAndDateEncoder, ensure_ascii=False), mimetype='text/plain; charset=utf-8')

def testUrlUrl(pRequest, auth_key, object_id):
	ccId = int(object_id)
	try:
		testItem = TestUrl.objects.get(id=ccId)
	except ObjectDoesNotExist:
		raise Http404
	if testItem.key != auth_key.lower():
		raise Http404
	return HttpResponse(simplejson.dumps({'domain': testItem.domain, 'path': testItem.path},
		cls=queryAndDateEncoder, ensure_ascii=False), mimetype='text/plain; charset=utf-8')

def testUrlInfo(pRequest, object_id):
	passObjects = {} #{'test': TestUrl.objects.select_related().order_by('-create_time')}
	ccId = int(object_id)
	try:
		testItem = TestUrl.objects.get(id=ccId)
	except ObjectDoesNotExist:
		raise Http404
	#need to do verification for cui
	if pRequest.GET and pRequest.GET.has_key('filter_by_user') and testItem.create_user != pRequest.GET.get('filter_by_user'):
		return HttpResponse(simplejson.dumps( \
			{'status': -1, 'error': "Requires create user for athentication"},
			cls=queryAndDateEncoder, ensure_ascii=False), mimetype='text/plain; charset=utf-8')
	if pRequest.GET and pRequest.GET.has_key('filter_by_visible_to_user') and not testItem.visible_to_user:
		return HttpResponse(simplejson.dumps( \
			{'status': -1, 'error': "Authentication failed"},
			cls=queryAndDateEncoder, ensure_ascii=False), mimetype='text/plain; charset=utf-8')
	passObjects['testStatus'] = testItem.toDictionary()
	#passObjects['testStatus']['create_time'] = testItem.create_time
	#passObjects['testStatus']['submittedUrl'] = testItem.submittedUrl
	#passObjects['testStatus']['auth_key'] = testItem.key + str(testItem.id)
	#passObjects['testStatus']['ticket'] = testItem.jira_ticket
	#passObjects['testStatus']['submissions'] = testItem.testurlsubmission_set.count()
	passObjects['testStatus']['getSubmissions'] = []
	for submission in testItem.testurlsubmission_set.get_query_set():
		passObjects['testStatus']['getSubmissions'].append({
			'id': submission.id, 
			'create_time': submission.create_time,
			'received_from_ip': submission.received_from_ip,
			'submitter_name': submission.submitter_name,
			'submitter_email': submission.submitter_email,
			'operating_system': submission.operating_system,
			'browser': submission.browser,
			'user_ip': submission.user_ip,
			'domain_ip': submission.domain_ip,
			'a_record': submission.a_record,
			'txt_record': submission.txt_record,
			'cname_record': submission.cname_record,
			'ping': submission.ping,
			'traceroute': submission.traceroute,
			'test_download': submission.test_download})
	return HttpResponse(simplejson.dumps(passObjects, cls=queryAndDateEncoder, ensure_ascii=False), mimetype='text/plain; charset=utf-8')

def testUrlSetSubmission(pRequest, auth_key, object_id):
	submission_form = pRequest.POST
	resp = {}
	ccId = int(object_id)
	try:
		testItem = TestUrl.objects.get(id=ccId)
	except ObjectDoesNotExist:
		raise Http404
	if testItem.key != auth_key.lower():
		raise Http404
	try:
		t = TestUrlSubmission(testurl = testItem,
			received_from_ip = submission_form['received_from_ip'],
			submitter_name = submission_form['name'],
			submitter_email = submission_form['email'],
			operating_system = submission_form['os'],
			browser = submission_form['browser'],
			user_ip = submission_form['userip'],
			domain_ip = submission_form['domainip'],
			a_record = submission_form['arecord'],
			txt_record = submission_form['txtrecord'],
			cname_record = submission_form['cname'],
			ping = submission_form['ping'],
			traceroute = submission_form['traceroute'],
			test_download = submission_form['testdownload'])
		t.save()
	except Exception, e:
		resp['status'] = -1
		resp['error'] = e.message
	else:
		resp['status'] = 1
		resp['id'] = t.id
		resp['parent'] = testItem.id
		resp['ticket'] = testItem.jira_ticket
	return HttpResponse(simplejson.dumps(resp, cls=queryAndDateEncoder, ensure_ascii=False), mimetype='text/plain; charset=utf-8')

def testUrlHide(pRequest, object_id):
	ccId = int(object_id)
	resp = {}
	try:
		cacheItem = TestUrl.objects.get(id=ccId)
	except ObjectDoesNotExist:
		raise Http404
	if not pRequest.GET or not pRequest.GET.has_key('auth_user'):
		resp['status'] = -1
		resp['error'] = "Requires create user for athentication"
	if cacheItem.create_user != pRequest.GET.get('auth_user'):
		resp['status'] = -1
		resp['error'] = "Authentication failed"
	else:
		cacheItem.visible_to_user = False
		cacheItem.save()
		resp['status'] = 1
	return HttpResponse(simplejson.dumps(resp,
			cls=queryAndDateEncoder, ensure_ascii=False), mimetype='text/plain; charset=utf-8')
