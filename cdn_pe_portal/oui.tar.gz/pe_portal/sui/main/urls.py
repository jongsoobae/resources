from django.conf.urls.defaults import *
from ci.constants import DEBUG, BASE_DIR
import os

urlpatterns = patterns('',
        (r'^rest/', include('sui.support.urls')),
)

