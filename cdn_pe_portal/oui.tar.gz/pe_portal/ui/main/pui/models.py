import types
from django.db import models
from datetime import datetime
from ci.constants import MEDIA_ROOT

class News(models.Model):
	title = models.TextField()
	subtitle = models.TextField()
	body = models.TextField(help_text='Linebreaks are preserved; double linebreaks make new paragraphs. HTML is allowed.')
	slug = models.TextField(help_text='Full html tags should be used for links here e.g.: &lt;a href="www.foo.com"&gt;Foo&lt;/a&gt;', default='', blank=True)
	timestamp = models.DateTimeField(default=datetime.now(), help_text='If this date is in the future, the news post will not appear until then.')
	class Admin:
		list_display = ('timestamp','title')
	class Meta:
		db_table = 'cui_news'
		ordering = ['-timestamp']
		verbose_name_plural = 'News'
	def __unicode__(self):
		return '%s: %s' % (self.timestamp, self.title)

class Event(models.Model):
	title = models.CharField(max_length=80)
	date = models.CharField(max_length=80)
	location = models.CharField(max_length=80)
	link = models.URLField()
	description = models.TextField(help_text='Linebreaks are preserved; double linebreaks make new paragraphs. HTML is allowed.')
	order = models.IntegerField(help_text='Any integer. Partners will be displayed in order based on this value, largest first.')
	class Admin:
		list_display = ('date','title','location','order')
	class Meta:
		db_table = 'cui_event'
		ordering = ['-order']
	def __unicode__(self):
		return self.title

class Partner(models.Model):
	name = models.CharField(max_length=80)
	description = models.TextField()
	logo = models.FileField(upload_to='./')
	website = models.URLField()
	order = models.IntegerField(help_text='Any integer. Partners will be displayed in order based on this value, smallest first.')
	class Admin:
		list_display = ('name','order')
	class Meta:
		db_table = 'cui_partner'
		ordering = ['order']
	def __unicode__(self):
		return self.name
	def get_logo_url(self):
		return "/upload/" + str(self.logo)
		
class Campaign(models.Model):
	tag = models.CharField(unique=True, max_length=8, help_text='This is the portion of the URL used to pick this campaign. If the tag is "foo", the campaign\'s form will be accessible via /referral/foo/.')
	name = models.CharField(max_length=40, help_text='This is the campaign\'s full name, which shows up in the email.')
	custom_text = models.TextField('Custom text', blank=True)
	custom_list = models.TextField('Custom list', blank=True)
	
	class Admin:
		pass
	class Meta:
		db_table = 'cui_campaign'
	def __unicode__(self):
		return '%s (%s)' % (self.name, self.tag)
