from django import template

register = template.Library()

@register.filter(name="startswith")
def startswith(val, prefix):
	return str(val).startswith(prefix)