from datetime import datetime
from django.conf.urls.defaults import *
from ui.pui.models import News, Event, Partner
from ci.common.models.site import SiteDraft
from ci.constants import DEBUG, BASE_DIR, CUI_ROOT, OUI_ROOT
import os

news_posts = News.objects.filter(timestamp__lte=datetime.now())
events = Event.objects.all()
sites = SiteDraft.objects.all()
partners = Partner.objects.all()

urlpatterns = patterns('',
	# troubleshooting utils (including legacy url support)
	(r'^whoami(?:/|\.php)$', 'ci.common.views.whoami'),
	(r'^(?:tools/me\.php|diagnostics/)$', 'ui.pui.views.simple', {'template': 'diagnostics.html'}),
	(r'^soap/', include('ui.soap.urls')),
)

urlpatterns += patterns('ui.pui.views',
	
	url(r'^$', 'home', {}, 'home'),
	
	# static
	# url(r'^careers/$', 'simple', {'template': 'careers.html'}, name='careers'),
	url(r'^network/$', 'simple', {'template': 'network.html'}, name='network'),
	url(r'^support/$', 'simple', {'template': 'support.html'}, name='support'),

	# about section
	url(r'^about/$', 'simple', {'template': 'about/common.html'}, name='about'),
	url(r'^advantage/$', 'simple', {'template': 'about/advantage.html'}, name='advantage'),
	url(r'^leadership/$', 'simple', {'template': 'about/leadership.html'}, name='leadership'),
	url(r'^news/$', 'object_list', {'queryset':news_posts, 'template_name':'about/news.html'}, name='news'),
	url(r'^news/(?P<object_id>\d+)/$', 'object_detail', {'queryset':news_posts, 'template_name':'about/news_post.html'}, name='news_post'),
	url(r'^events/$', 'object_list', {'queryset':events, 'template_name':'about/events.html'}, name='events'),
	url(r'^partners/$', 'object_list', {'queryset':partners, 'template_name':'about/partners.html'}, name='partners'),

	# solutions section
	url(r'^solutions/$', 'simple', {'template': 'solutions/main.html'}, name='solutions'),
	url(r'^solutions/(?P<page>[^/]+)/$', 'category_page', {'category': 'solutions'}, name='solutions_page'), # catch-all for static pages
	url(r'^s3/$', 'simple', {'template': 'solutions/s3.html'}, 's3'),

	# technology section
	url(r'^technology/$', 'simple', {'template': 'technology/main.html'}, name='technology'),
	url(r'^technology/(?P<page>[^/]+)/$', 'category_page', {'category':'technology'}, name='technology_page'), # catch-all for static pages

	# contact forms
	url(r'^contact/$', 'simple', {'template': 'contact.html'}, name='contact-intro'),
	(r'^contact/general/$', 'contact'),
	(r'^contact/media/$', 'media_form'),
	url(r'^contact/sales/$', 'sfdc_form', {'type_': 'sales_lead'}, name='sales_lead'),
	url(r'^contact/trial/$', 'sfdc_form', {'type_': 'trial'}, name='trial'),
	url(r'^contact/video-guide/$', 'sfdc_form', {'type_': 'video_guide'}, name='video_guide'),
	url(r'^contact/video-whitepaper/$', 'sfdc_form', {'type_': 'video_guide'}, name='video_guide_alt'),

	# landing page after submitting a salesforce.com form
	url(r'^sfdc/$', 'simple', {'template': 'form-landing.html'}, name='sfdc'),

	(r'^referral/(?P<campaign_tag>[^/]+)/$', 'ad_landing'),
	# the 2 below are legacy links -- use the /referral/<tag>/ format going forward
	(r'^sai/', 'ad_landing', {'campaign_tag':'sai'}),
	(r'^tc/', 'ad_landing', {'campaign_tag':'tc'}),

)

#Everything below here is really cui/oui stuff that previously did not use the /account or /oui3 namespace 
#Redirecting it in case there are old references
urlpatterns += patterns('ci.common.views',
	(r'^login/$', 'redirect', {'target': 'https://' + CUI_ROOT + '/login/'}),
	(r'^logout/$', 'redirect', {'target': 'https://' + CUI_ROOT + '/logout'}),	
	(r'^reset-password/$', 'redirect', {'target': 'https://' + CUI_ROOT + '/reset-password/'}),
	(r'^not-allowed/$','redirect', {'target': 'https://' + CUI_ROOT + '/not-allowed/'}),
	(r'^account$','redirect', {'target': 'https://' + CUI_ROOT + '/'}),
	(r'^oui3$','redirect', {'target': 'https://' + OUI_ROOT + '/'}),
	(r'^not-permitted/$','redirect', {'target': 'https://' + OUI_ROOT + '/not-permitted/'}),
)

if DEBUG:
	urlpatterns += patterns('',
		# this only applies to the development server. with apache, /static/ should never go to django in the first place
		(r'^static/(?P<path>.*)$', 'django.views.static.serve', {'document_root': os.path.join(BASE_DIR, 'static')}),
	)

