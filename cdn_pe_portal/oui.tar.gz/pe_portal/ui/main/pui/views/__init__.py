from datetime import datetime
from django import forms
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect, Http404
from django.template import TemplateDoesNotExist
from django.views.generic.list_detail import object_detail, object_list
from ci.constants import PR_ADDR, CONTACT_ADDR, INFO_ADDR, NO_REPLY
from ui.pui.models import News, Event, Campaign
from ci.common.utils import render_response
from ci.common.utils.mail import send_email
from ci.common.views import simple

from media import media_form

def category_page(request, page, category):
	try:
		return render_response(request, '%s/%s.html' % (category, page))
	except TemplateDoesNotExist:
		raise Http404 # FIXME this overreaches -- e.g. you could get TDNE from a template tag

def redirect(request, target):
	return HttpResponseRedirect(target)

def home(request):
	context = {
		'news': News.objects.filter(timestamp__lte=datetime.now())[:3],
		'events': Event.objects.all()[:3]
	}
	return render_response(request, 'home.html', context)


def sfdc_form(request, type_):
	if type_ == 'trial':
		context = {
			'title': 'Request your free trial',
			'blurb': "Fill out the form below to get started experiencing Panther's top-notch performance, reliability, and support.",
			'trial_fields': True
		}
	elif type_ == 'sales_lead':
		context = {
			'title': 'Sales inquiry',
			'blurb': "Need more information? Fill out the form and we'll get back to you ASAP."
		}
	elif type_ == 'video_guide':
		error = None
		if request.POST:
			try:
				email_contents = []
				for key in ('first_name','last_name','company','email','phone','street','state','country','URL'):
					email_contents.append((key, request.POST.get(key, None)))
				message = '\n'.join([': '.join(v) for v in email_contents])
				send_email(PR_ADDR, PR_ADDR, 'Video guide request', message, reply_to=request.POST.get('email', None))
				return HttpResponseRedirect(reverse('sfdc'))
			except:
				error = 'There was an error sending this information. Please check your information and try again. If the error persists, please email pr@pantherexpress.net directly.'

		context = {
			'title': 'Clear away the streaming video fog',
			'blurb': "Please complete the information below and we'll send you our guide on delivering internet video.",
			'alternate_action': reverse('video_guide'),
			'error': error
		}
	return render_response(request, 'sfdc-form.html', context)

# def sfdc_form(request, type_):
# 	title_blurb = {
# 		'trial': ('Free trial inquiry','Request your free trial',"Fill out the form below to get started experiencing Panther's top-notch performance, reliability, and support."),
# 		'sales_lead': ('Sales inquiry','Sales inquiry', "Need more information? Fill out the form and we'll get back to you ASAP."),
# 		'video_guide':('Video streaming inquiry','Clear away the streaming video fog',  "Please complete the information below and we'll send you our guide on delivering internet video.")
# 	}
# 	if request.POST:
# 		email_contents = []
# 		for key in ('first_name','last_name','company','email','phone','street','state','country','URL', 'comment'):
# 			email_contents.append((key, request.POST.get(key,' ')))
# 		if type_ == 'trial':
# 			for key in ('site_content', 'site_description'):
# 				email_contents.append((key, request.POST.get(key,' ')))
# 		message = '\n'.join([': '.join(v) for v in email_contents])
# 		try:
# 			send_email(NO_REPLY, INFO_ADDR, title_blurb[type_][0], message,reply_to=request.POST.get('email', None))
# 		except:
# 			send_email(NO_REPLY, INFO_ADDR, 'Sales lead', message,reply_to=request.POST.get('email', None))
# 		return HttpResponseRedirect(reverse('sfdc'))
# 	context = {
# 		'title':title_blurb[type_][1],
# 		'blurb':title_blurb[type_][2]
# 	}
# 	if type_ == 'trial':
# 		context['trial_fields'] =  True
# 	return render_response(request, 'sfdc-form.html', context)
	
def contact(request):
	class ContactForm(forms.Form):
		name = forms.CharField()
		title = forms.CharField()
		email = forms.EmailField()
		phone = forms.CharField()
		subject = forms.CharField()
		message = forms.CharField(widget=forms.Textarea)
		
	if request.POST:
		contact_form = ContactForm(request.POST, auto_id='contact_form')
		if contact_form.is_valid():
			send_email(CONTACT_ADDR, [CONTACT_ADDR], contact_form.cleaned_data['subject'], contact_form.cleaned_data['message'], reply_to=contact_form.cleaned_data['email'])
	else:
		contact_form = ContactForm(auto_id='contact_form')
	
	return render_response(request, 'contact-form.html', {'contact_form': contact_form})


def ad_landing(request, campaign_tag):
	
	try:
		campaign = Campaign.objects.get(tag=campaign_tag).name
		custom_text = Campaign.objects.get(tag=campaign_tag).custom_text
		custom_list = Campaign.objects.get(tag=campaign_tag).custom_list
		
	except Campaign.DoesNotExist:
		campaign = campaign_tag
		custom_text = forms.CharField(max_length=300)
		custom_list = forms.CharField(max_length=300)
	return render_response(request, 'ad-landing.html', {'campaign': campaign, 'custom_text':custom_text, 'custom_list': custom_list})
