from django import forms
from django.core.urlresolvers import reverse
from django.utils.encoding import smart_unicode
from ci.constants import PR_ADDR
from ci.common.utils import render_response
from ci.common.utils.mail import send_email

def media_form(request):
	
	class MediaForm(forms.Form):
		name = forms.CharField(max_length=200, required=True)
		email = forms.EmailField(required=True)
		question = forms.CharField(widget=forms.Textarea, required=True)
		company = forms.CharField(max_length=200, required=False)
		when_do_you_need_an_answer = forms.CharField(max_length=100, required=False)
		phone = forms.CharField(max_length=10, required=False)
		best_method_to_reach_you = forms.ChoiceField(required=False,
						choices=[
							('phone','Phone'),
							('email','Email')
							])
		
	if request.POST:
		media_form = MediaForm(request.POST, auto_id='mediaform_%s')
		message = ''
		
		if media_form.is_valid():
			
			# message parts
			subject = media_form.cleaned_data['question'][:30]
			for fieldname in media_form.fields.keys():
				message += '%s: %s\n' % (fieldname, media_form.cleaned_data[fieldname])
			# send email
			send_email(PR_ADDR, PR_ADDR, subject, message, reply_to=media_form.cleaned_data['email'])
			
	else:
		media_form = MediaForm(auto_id='mediaform_%s')
		
	return render_response(request, 'media-form.html', {'media_form': media_form})

