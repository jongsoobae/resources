from django.conf.urls.defaults import patterns, url

urlpatterns = patterns('aurora_api.account.views.account',
    url(r'^customerprivilege/edit/account/(?P<account_no>[0-9]+)/', 'customerPrivilege_edit_account'),
    url(r'^customer/edit/account/', 'customer_edit_account'),
)