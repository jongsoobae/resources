from aurora_api.utils import APIException, APIErrorResponse, APIResponse
from aurora_fe.shared_components.models.acl_core import CustomerAccountWrapper, CustomerAccountHasPrivilege
from django.views.decorators.csrf import csrf_exempt
from aurora_api.group.views.control_group import update_controlGroup_account
from aurora_api.user.views.user import update_userProfile_account, update_userPrivilege_account
from aurora_api.email_report.views.email_report import update_emailReport_account
from aurora_api.stat_service.views.stat_service import update_statMaster_account
from django.db import transaction

from spectrum_fe.shared_components.utils.api import getOptionalParams

@csrf_exempt
def customerPrivilege_edit_account(request, account_no):
    try :
        opts = getOptionalParams(request)
        opts_set = set(opts)
        available_fields = set(('username', 'password', 'to_account_no'))
        required_fields = set(('username', 'password', 'to_account_no'))

        missing_opts = required_fields.difference(opts_set)
        
        to_account_no = opts.get('to_account_no')

        if len(missing_opts) > 0:
            return APIErrorResponse(request, "104", "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, "104", "Invalid parameters in request: " + ", ".join(invalid_opts))
        
        return_val = update_customerPrivilege_account(account_no, to_account_no)
        
        if return_val['returnCode'] != 0 :
            return APIErrorResponse(request, return_val['returnCode'], return_val['returnMsg'])
        
        return APIResponse(request, {})
    except Exception as e :
        return APIException(request, "999", e)
    
def update_customerPrivilege_account(account_no, to_account_no):
    try :
        try :
            CustomerAccountWrapper.objects.get(pk=to_account_no)
        except :
            return {'returnCode':404, 'returnMsg':"Matching account(to_account:"+to_account_no+") does not exist."}
        
        if CustomerAccountHasPrivilege.objects.filter(account_no=account_no).count() :
            try :
                CustomerAccountHasPrivilege.objects.filter(account_no=account_no).update(account_no=to_account_no)
            except Exception as e :
                return {'returnCode':999, 'returnMsg':e}
        else :
            return {'returnCode':404, 'returnMsg':"Matching customer privilege(from_account:"+account_no+") does not exist."} 
                     
        return {'returnCode':0, 'returnMsg':"Success"}
    except Exception as e :
        return {'returnCode':999, 'returnMsg':e}   
    
@csrf_exempt
@transaction.commit_on_success
def customer_edit_account(request):
    try :
        opts = getOptionalParams(request)
        opts_set = set(opts)
        available_fields = set(('username', 'password', 'from_account_no', 'to_account_no', 'from_customer_id', 'to_customer_id'))
        required_fields = set(('username', 'password', 'from_account_no', 'to_account_no', 'from_customer_id', 'to_customer_id'))

        missing_opts = required_fields.difference(opts_set)
        
        account_no = opts.get('from_account_no')
        to_account_no = opts.get('to_account_no')
        customer_id = opts.get('from_customer_id')
        to_customer_id = opts.get('to_customer_id')

        if len(missing_opts) > 0:
            return APIErrorResponse(request, "104", "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, "104", "Invalid parameters in request: " + ", ".join(invalid_opts))
        
        #control group
        return_val = update_controlGroup_account(account_no, to_account_no)
        if return_val['returnCode'] != 0 :
            return APIErrorResponse(request, return_val['returnCode'], return_val['returnMsg'])
        
        #customer privilege
        return_val = update_customerPrivilege_account(account_no, to_account_no)
        if return_val['returnCode'] != 0 and return_val['returnCode'] != 404 :
            return APIErrorResponse(request, return_val['returnCode'], return_val['returnMsg'])
        
        #user profile
        return_val = update_userProfile_account(customer_id, to_customer_id)
        if return_val['returnCode'] != 0 and return_val['returnCode'] != 404 :
            return APIErrorResponse(request, return_val['returnCode'], return_val['returnMsg'])

        #user privilege
        return_val = update_userPrivilege_account(account_no, to_account_no)
        if return_val['returnCode'] != 0 and return_val['returnCode'] != 404 :
            return APIErrorResponse(request, return_val['returnCode'], return_val['returnMsg'])
        
        #stat_master
        return_val = update_statMaster_account(customer_id, to_customer_id)
        if return_val['returnCode'] != 0 and return_val['returnCode'] != 404 :
            return APIErrorResponse(request, return_val['returnCode'], return_val['returnMsg'])
        
        #email report
        return_val = update_emailReport_account(account_no, to_account_no)
        if return_val['returnCode'] != 0 and return_val['returnCode'] != 404 :
            return APIErrorResponse(request, return_val['returnCode'], return_val['returnMsg'])
        
        return APIResponse(request, {})
    except Exception as e :
        return APIException(request, "999", e)        