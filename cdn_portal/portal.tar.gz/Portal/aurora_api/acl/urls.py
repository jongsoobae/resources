from django.conf.urls.defaults import patterns, url

urlpatterns = patterns('aurora_api.acl.views.ocsp',
    url(r'^ocsp/getServiceList/$', 'getServiceList'),
    url(r'^ocsp/setService/$', 'setService'),
)