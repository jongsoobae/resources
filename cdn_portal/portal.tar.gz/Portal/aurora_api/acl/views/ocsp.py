from aurora_api.utils import APIException, APIErrorResponse, APIResponse
from django.db import transaction
from django.views.decorators.csrf import csrf_exempt
from aurora_fe.shared_components.models.ocspacl import OCSPServiceMap, getOCSPServcieMap
from spectrum_fe.shared_components.utils.api import getOptionalParams, corporationTextToCode
from spectrum_fe.shared_components.models import StatMaster

@csrf_exempt
def getServiceList(request):
    try :
        opts = getOptionalParams(request)
        opts_set = set(opts)
        available_fields = set(('username', 'password', 'accountNo', 'serviceGroupKey','corporationCD'))
        required_fields = set(('username', 'password', 'accountNo', 'serviceGroupKey','corporationCD'))

        missing_opts = required_fields.difference(opts_set)

        if len(missing_opts) > 0:
            return APIErrorResponse(request, "104", "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, "104", "Invalid parameters in request: " + ", ".join(invalid_opts))

        def_account_no = opts.get('accountNo').strip()
        if '' == def_account_no :
            return APIErrorResponse(request, "104", "Invalid parameters in request is not valid: accountNo")

        def_sg_key = opts.get('serviceGroupKey').strip()
        if '' == def_sg_key :
            return APIErrorResponse(request, "104", "Invalid parameters in request is not valid: serviceGroupKey")

        def_corporation_cd = opts.get('corporationCD').strip()
        if '' == def_corporation_cd :
            return APIErrorResponse(request, "104", "Invalid parameters in request is not valid: corporationCD")

        corporation_code = corporationTextToCode(def_corporation_cd)

        default = getOCSPServcieMap(def_account_no, def_sg_key, def_corporation_cd, corporation_code)

        results = []
        for item in default:
            results.append({'stat_id':item[0], 'display_name':item[1], 'material_group_name':item[2], 'obj_state':item[3], 'statmaster_id':item[4]})
        return APIResponse(request, {'data': results})
    except Exception as e :
        return APIException(request, "999", e)

@csrf_exempt
@transaction.commit_on_success
def setService(request):
    try :
        opts = getOptionalParams(request)

        opts_set = set(opts)
        available_fields = set(('username', 'password', 'serviceGroupKey', 'corporationCD', 'statmasterList', 'lastUpdater'))
        required_fields = set(('username', 'password', 'serviceGroupKey', 'corporationCD', 'statmasterList', 'lastUpdater'))

        missing_opts = required_fields.difference(opts_set)

        if len(missing_opts) > 0:
            return APIErrorResponse(request, "104", "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, "104", "Invalid parameters in request: " + ", ".join(invalid_opts))

        try :
            OCSPServiceMap.objects.filter(service_group_key=opts.get('serviceGroupKey'), corporation_cd=opts.get('corporationCD')).delete()
            if opts.get('statmasterList') != '':
                itemList = opts.get('statmasterList').split('|')
                for item in itemList:
                    statmaster_obj = StatMaster.objects.get(stat_id=int(item))
                    ocspservicemap_create = OCSPServiceMap.objects.create(service_group_key=opts.get('serviceGroupKey'), corporation_cd=opts.get('corporationCD'), statmaster_id=statmaster_obj, last_updater=opts.get('lastUpdater'))
                    ocspservicemap_create.save()
        except Exception as e :
            transaction.rollback()
            return APIException(request, "999", e)

        return APIResponse(request, {})
    except Exception as e :
        return APIException(request, "999", e)


