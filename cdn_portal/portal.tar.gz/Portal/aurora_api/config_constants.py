AURORA_PROD_HANDLER = False

if not AURORA_PROD_HANDLER:
    ADMINS = (
            ('ENG-CLOUD', 'eng-cloud@cdnetworks.com'),
    )
    EMAIL_ALERTS = ['eng-cloud@cdnetworks.com']
else:
    ADMINS = (
            ('ENG-UI', 'eng-ui@cdnetworks.com'),
    )
    EMAIL_ALERTS = ['eng-ui@cdnetworks.com']

CACHE_BACKEND = "django.core.cache.backends.memcached.MemcachedCache"
CACHE_LOCATIONS = [
            '127.0.0.1:11211',
        ]
