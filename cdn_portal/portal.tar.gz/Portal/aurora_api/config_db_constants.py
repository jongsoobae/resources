# Database settings configuration
import config_constants

if not config_constants.AURORA_PROD_HANDLER:
    DEFAULT = {
            'NAME':'aurora',
            'ENGINE':'django.db.backends.mysql',
            'USER':'aurora_ui',
            'PASSWORD':'669#fC&8b8C&5#f3l@#2',
            'HOST':'ngpdb.cdnetworks.com',
            'PORT':'3306'
        }
    STATS = {
            'NAME':'stat',
            'ENGINE':'django.db.backends.mysql',
            'USER':'aurora_ui',
            'PASSWORD':'669#fC&8b8C&5#f3l@#2',
            'HOST':'ngpdb.cdnetworks.com',
            'PORT':'3306'
        }
    ONE_STAT = {
            'NAME':'one_stat',
            'ENGINE':'django.db.backends.mysql',
            'USER':'aurora_ui',
            'PASSWORD':'669#fC&8b8C&5#f3l@#2',
            'HOST':'statdb.cdnetworks.com',
            'PORT':'3306'
        }
    CENTRALDB = {
            'NAME':'centraldb',
            'ENGINE':'django.db.backends.mysql',
            'USER':'aurora-ro',
            'PASSWORD':'669#fC&8b8C&5#f3l@#2',
            'HOST':'cdb.cdnetworks.com',
            'PORT':'3306'
    }
else :
    DEFAULT = {
            'NAME':'aurora',
            'ENGINE':'mysql',
            'USER':'aurora_ui',
            'PASSWORD':'NeedS*HOE90SeMi',
            'HOST':'ngp-db.cdnetworks.net',
            'PORT':'3306'
    }
    STATS = {
            'NAME':'stat',
            'ENGINE':'mysql',
            'USER':'aurora_ui',
            'PASSWORD':'NeedS*HOE90SeMi',
            'HOST':'ngp-db.cdnetworks.net',
            'PORT':'3306'
    }
    ONE_STAT = {
            'NAME':'one_stat',
            'ENGINE':'django.db.backends.mysql',
            'USER':'aurora_ui',
            'PASSWORD':'NeedS*HOE90SeMi',
            'HOST':'ngp-one-stat.cdngp.net',
            'PORT':'3306'
        }
    CENTRALDB = {
            'NAME':'centraldb',
            'ENGINE':'django.db.backends.mysql',
            'USER':'aurora-ro',
            'PASSWORD':'TheConjuring,@0!#',
            'HOST':'cdb.panthercdn.com',
            'PORT':'3306'
    }
