import unittest

from aurora_api.dns.views_v1.zone_config import myinfra_push_check
from spectrum_fe.dns.models.dns import DNSZone
from spectrum_fe.configuration.models.clb import CustomerContractPop
from spectrum_fe.configuration.models.base import Pop
from spectrum_fe.shared_components.models import FakeRequest

class TestZoneConfigPush(unittest.TestCase):

    def setUp(self):
        self.request = FakeRequest()
        self.test_dns_zone = 'clb.davidkimtest.com'
        self.test_customer_id = 1  # CDNetworks Product Management

    def set_zone_and_myinfra_status(self, myinfra_status, zone_status):
        test_zone = DNSZone.objects.get(domain_name=self.test_dns_zone, customer__pk=self.test_customer_id)

        test_zone.status = zone_status
        test_zone.save(request=self.request)

        myinfra_list = CustomerContractPop.all_objects.filter(use_type=1, customer__pk=self.test_customer_id)
        for myinfra in myinfra_list:
            base_pop = Pop.objects.get(pk=myinfra.pop)
            base_pop.status = myinfra_status
            base_pop.save(request=self.request)

        return test_zone

    def test_check_the_infra_before_pushing_cdns(self):

        # MyInfra => New / Modify / Failed(to production)
        # zone status => On Staging Server
        infra_new_zone_staging = self.set_zone_and_myinfra_status(0, 2)
        if infra_new_zone_staging is not None:
            push_check, msg = myinfra_push_check(infra_new_zone_staging)
            self.assertEqual(push_check, False)
        # zone status => New / Modify / Failed(to production)
        infra_new_zone_new = self.set_zone_and_myinfra_status(0, 0)
        if infra_new_zone_new is not None:
            push_check, msg = myinfra_push_check(infra_new_zone_new)
            self.assertEqual(push_check, False)

        # MyInfra => On Staging Server
        # zone status => On Staging Server
        infra_staging_zone_staging = self.set_zone_and_myinfra_status(2, 2)
        if infra_staging_zone_staging is not None:
            push_check, msg = myinfra_push_check(infra_staging_zone_staging)
            self.assertEqual(push_check, False)
        # zone status => New / Modify / Failed(to production)
        infra_staging_zone_new = self.set_zone_and_myinfra_status(2, 0)
        if infra_staging_zone_new is not None:
            push_check, msg = myinfra_push_check(infra_staging_zone_new)
            self.assertEqual(push_check, True)

        # MyInfra => Production
        # zone status => on Staging Server
        infra_product_zone_staging = self.set_zone_and_myinfra_status(4, 2)
        if infra_product_zone_staging is not None:
            push_check, msg = myinfra_push_check(infra_product_zone_staging)
            self.assertEqual(push_check, True)
        # zone status => New / Modify / Failed(to production)
        infra_product_zone_new = self.set_zone_and_myinfra_status(4, 0)
        if infra_product_zone_new is not None:
            push_check, msg = myinfra_push_check(infra_product_zone_new)
            self.assertEqual(push_check, True)

