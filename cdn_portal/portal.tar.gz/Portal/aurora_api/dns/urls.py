from django.conf.urls.defaults import patterns, url


# api v1.0

urlpatterns = patterns('aurora_api.dns.views_v1',
    # zone configuration & get information.
    url(r'^cdns/v1/domains/$', 'zone_config.cdns_config', name='dns_zone_config'),

    url(r'^cdns/v1/domains/(?P<zone_id>\d+)/$', 'zone_config.cdns_config', name='dns_zone_config_by_zone_id'),
    url(r'^cdns/v1/domains/(?P<zone_id>\d+)/edit/$', 'zone_config.cdns_config_edit', name='dns_zone_config_edit'),
    url(r'^cdns/v1/domains/(?P<zone_id>\d+)/records/$', 'zone_config.record_config', name='dns_record_config'),
    url(r'^cdns/v1/domains/(?P<zone_id>\d+)/records/add/$', 'zone_config.record_config_add', name='dns_record_config_add'),
    url(r'^cdns/v1/domains/(?P<zone_id>\d+)/records/edit/$', 'zone_config.record_config_edit', name='dns_record_config_edit'),
    url(r'^cdns/v1/domains/(?P<zone_id>\d+)/records/(?P<record_type>\w+)/$', 'zone_config.record_config', name='dns_record_config_record_type'),
    url(r'^cdns/v1/domains/(?P<zone_id>\d+)/records/(?P<record_type>\w+)/add/$', 'zone_config.record_config_add', name='dns_record_record_type_config_add'),
    url(r'^cdns/v1/domains/(?P<zone_id>\d+)/records/(?P<record_type>\w+)/edit/$', 'zone_config.record_config_edit', name='dns_record_record_type_config_edit'),
    url(r'^cdns/v1/domains/(?P<zone_id>\d+)/records/(?P<record_type>\w+)/(?P<record_id>\d+)/$', 'zone_config.record_config', name='dns_record_config_record_type_id'),
    url(r'^cdns/v1/domains/(?P<zone_id>\d+)/records/(?P<record_type>\w+)/(?P<record_id>\d+)/edit/$', 'zone_config.record_config_edit', name='dns_record_edit'),
    url(r'^cdns/v1/domains/(?P<zone_id>\d+)/records/(?P<record_type>\w+)/(?P<record_id>\d+)/delete/$', 'zone_config.record_config_delete', name='dns_record_delete'),

    url(r'^cdns/v1/domains/(?P<zone_id>\d+)/deploy/$', 'zone_config.config_deploy', name='dns_config_deploy'),

    # clb config
    url(r'^cdns/v1/domains/export/clb/$', 'zone_config.export_conf', name='export_conf'),

    # My Infra
    # server group manage
    url(r'^infra/v1/servergroups/$', 'myinfra.server_groups', name='server_groups'),
    url(r'^infra/v1/servergroups/(?P<server_group_id>\d+)/$', 'myinfra.server_groups', name='server_groups_by_id'),

    url(r'^infra/v1/servergroups/add/$', 'myinfra.add_server_group', name='add_server_group'),
    url(r'^infra/v1/servergroups/(?P<server_group_id>\d+)/edit/$', 'myinfra.edit_server_group', name='edit_server_group'),
    url(r'^infra/v1/servergroups/(?P<server_group_id>\d+)/delete/$', 'myinfra.delete_server_group', name='delete_server_group'),

    # server manage
    url(r'^infra/v1/servergroups/(?P<server_group_id>\d+)/servers/$', 'myinfra.get_servers', name='get_servers'),
    url(r'^infra/v1/servergroups/(?P<server_group_id>\d+)/servers/(?P<server_id>\d+)/$', 'myinfra.get_servers', name='get_servers_by_id'),

    url(r'^infra/v1/servergroups/(?P<server_group_id>\d+)/servers/add/$', 'myinfra.add_server', name='add_server'),
    url(r'^infra/v1/servergroups/(?P<server_group_id>\d+)/servers/(?P<server_id>\d+)/edit/$', 'myinfra.edit_server', name='edit_server'),
    url(r'^infra/v1/servergroups/(?P<server_group_id>\d+)/servers/(?P<server_id>\d+)/delete/$', 'myinfra.delete_server', name='delete_server'),
    url(r'^infra/v1/servergroups/(?P<server_group_id>\d+)/servers/(?P<server_id>\d+)/is_deletable/$', 'myinfra.is_deletable_server', name='is_deletable_server'),
    url(r'^infra/v1/servergroups/(?P<server_group_id>\d+)/servers/(?P<server_id>\d+)/move/$', 'myinfra.change_server_group', name='change_server_group'),

    url(r'^infra/v1/servergroups/(?P<server_group_id>\d+)/servers/(?P<server_id>\d+)/addmon/$', 'myinfra.add_probe', name='add_probe'),
    url(r'^infra/v1/servergroups/(?P<server_group_id>\d+)/servers/(?P<server_id>\d+)/deletemon/$', 'myinfra.delete_probe', name='delete_probe'),

    # misc
    url(r'^infra/v1/location/$', 'myinfra.clb_location', name='clb_location'),
    url(r'^infra/v1/healthchecker/$', 'myinfra.get_probes', name='get_probes'),


    url(r'^infra/v1/deploy/$', 'myinfra.infra_deploy', name='my_infra_deploy'),
    url(r'^infra/v1/get_deploy_status/$', 'myinfra.get_deploy_status', name='get_deploy_status'),
    
    #clb api
    url(r'^cdns/v1/domains/(?P<zone_id>\d+)/clb/list/$', 'open_clb.get_all_clb_domain_list', name='get_all_clb_domain_list'),
    url(r'^cdns/v1/domains/clb/(?P<domain_id>\d+)/get/$', 'open_clb.get_clb_domain', name='get_clb_domain'),
    url(r'^cdns/v1/domains/clb/(?P<healthchecker>\d+)/(?P<servergroup>\d+)/(?P<active>\d+)/servers/get/$', 'open_clb.search_domain_servers', name='search_domain_servers'),
    url(r'^cdns/v1/domains/clb/post/$', 'open_clb.create_clb_domain', name='create_clb_domain'),
    url(r'^cdns/v1/domains/clb/put/$', 'open_clb.update_clb_domain', name='update_clb_domain'),
    url(r'^cdns/v1/domains/clb/(?P<domain_id>\d+)/delete/$', 'open_clb.delete_clb_domain', name='delete_clb_domain'),
    url(r'^cdns/v1/domains/clb_list/get/$', 'open_clb.get_clb_domain_list', name='get_clb_domain_list'),
    url(r'^cdns/v1/domains/geo_data/get/$', 'open_clb.get_geo_data', name='get_geo_data'),
)
