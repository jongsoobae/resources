# -*- coding: utf-8 -*-
"""
    Copyright (c) 2012 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Cloud LoadBalancer - My Infra Configuration
"""
from django import forms
from django.db import transaction
from django.db.models import Q
from django.utils.translation import ugettext as _
from django.views.decorators.csrf import csrf_exempt
import re, socket, struct

from aurora_api import error_code
from aurora_api.shared_components.decorators import config_api_authority_required, api_param_validate
from aurora_api.utils import APIErrorResponse, APIResponse
from aurora_fe.shared_components.utils import get_customer
from spectrum_fe.configuration.models.base import System, Host, Vip, BaseProbeConfig, VipProbeConfigs, POP_STATUS
from spectrum_fe.configuration.models.clb import CustomerAllowProbeConfig, CustomerContractPop
from spectrum_fe.configuration.models.ihms import IhmsVip
from spectrum_fe.dna.models.domain import DomainVip
from spectrum_fe.dns.forms.clb import IP_RE
from spectrum_fe.shared_components.utils.api import getOptionalParams, ApiHelper
import json
from spectrum_fe.dns.views.dns_myinfra import ajax_complete
from spectrum_fe.shared_components.decorators import validate_push_rate_limit, post_push_action_for_http_response

STATUS_CHOICES = ((0, 'Disabled',), (1, 'Enabled',))
_CDNS_CLB_MANAGE_ = "CD_CLB"

_CLB_POP_ = 1
LB_TYPES = None
regex_ip = re.compile(IP_RE)
PARAM_SEPERATOR = "|"

STATUS_TO_STAGE = 1
STATUS_TO_PRODUCTION = 3
STATUS_IN_PRODUCTION = 4
__STATUS_OF_PRODUCTION_ERR__ = -4
__ERR_MSG_NOT_EXISTS_SERVER__ = _(u"There is not exists server")
__ERR_MSG_INVAILD_PROBE__ = _(u"You choose Invalid Healthchecker. Please check available Server Healthcheckers.")
__ERR_MSG_INVAILD_SERVER_GROUP__ = _(u"Server group is not valid")
__ERR_MSG_DEPLOY_WAIT__ = _(u"Previous publishing has not been completed yet. Please wait until the push is completed.")
__ERR_MSG_ALREADY_EXISTS_PROBE__ = _(u"This healthchecker is already configured")
__ERR_MSG_DELETE_NOT_EXIST_PROBE__ = _(u"This healthchecker is not exists")
__ERR_MSG_UNKNOWN_ERROR__ = _(u"Operation is Failed. Please contact CDNetworks Technical Supports")
__ERR_MSG_EMPTY_PARAMS__ = _(u"You couldn't update without any parameters")
__ERR_MSG_ZONE_FAILED__ = _(u"My Infra configuration deployed successfully, but occurred an error while deploying the Cloud DNS configuration. Please check your Cloud DNS configuration.")

def cleanup_keyword(keyword):
    try:
        if keyword is None:
            return None
        else:
            return unicode(keyword).strip()
    except:
        return None

def display_pop_status_text(status):
    status_text = ""
    for text_pop_status in POP_STATUS:
        if status == text_pop_status[0]:
            status_text = text_pop_status[1]
            break
    return status_text

def convert_pop_status(pop_obj):
    if pop_obj.status == 0:
        if pop_obj.time_deployed is None:
            return pop_obj.status , _(u'New')

    if pop_obj.status in [STATUS_TO_STAGE, STATUS_TO_PRODUCTION]:
        if pop_obj.get_timeout():
            if pop_obj.status == STATUS_TO_STAGE:
                pop_status_code = -2
            elif pop_obj.status == STATUS_TO_PRODUCTION:
                pop_status_code = -4
            else:
                pop_status_code = -2
        else:
            pop_status_code = pop_obj.status
    else:
        pop_status_code = pop_obj.status

    zone_status = pop_obj.get_deploy_status_text()
    # return pop_status_code , "%s %s"%(display_pop_status_text(pop_status_code),zone_status)
    return pop_status_code , zone_status

def check_customer_with_server_group(request, server_group_id):
    customer_id = get_customer(request).pk
    server_group_list = CustomerContractPop.objects.filter(id=server_group_id)
    if len(server_group_list) > 0:
        server_group_customer_id = server_group_list[0].customer.pk
        if str(server_group_customer_id) == str(customer_id):
            return True
    return False

def check_customer_with_server_id(request, server_group_id, server_id):
    server_handler = MyInfraServer(request, server_group_id)
    servers = server_handler.get_server(None)
    server_list = servers["data"]
    for server in server_list:
        if int(server_id) == int(server["server_id"]):
            return True
    return False

def check_customer_with_server_group_and_server_id(request, server_group_id, server_id):
    is_check = check_customer_with_server_group(request, server_group_id)
    if is_check == True:
        is_server = check_customer_with_server_id(request, server_group_id, server_id)
        return is_server
    return False

def check_server_group_id_with_post_data(request, server_group_id):
    if int(server_group_id) == int(json.loads(request.POST.get("post_data"))["group_id"]):
        return True
    return False
# Server Group
@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_CLB_MANAGE_])
def server_groups(request, server_group_id=None):
    if server_group_id != None and check_customer_with_server_group(request, server_group_id) == False:
        return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, "%s" % 'no authority for service', 200)
    groups = []
    try:
        server_group_handler = MyInfraServerGroup(request)
        groups = server_group_handler.get_group(server_group_id)
    
        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'groups':groups})
    except Exception, e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e , 200)

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_CLB_MANAGE_])
@transaction.commit_on_success
def add_server_group(request):
    groups = []
    try:
        server_group_handler = MyInfraServerGroup(request)
        groups = server_group_handler.add_group()
        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'groups':groups})

    except Exception, e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e , 200)

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_CLB_MANAGE_])
@transaction.commit_on_success
def edit_server_group(request, server_group_id):
    if server_group_id != None and check_customer_with_server_group(request, server_group_id):
        groups = []
        try:
            server_group_handler = MyInfraServerGroup(request)
            groups = server_group_handler.edit_group(server_group_id)
            return APIResponse(request, {'returnCode':error_code.SUCCESS, 'groups':groups})
        except EmptyParams:
            return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % __ERR_MSG_EMPTY_PARAMS__ , 200)
        except Exception, e:
            return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e , 200)
    else:
        return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, "%s" % 'no authority for service', 200)

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_CLB_MANAGE_])
@transaction.commit_on_success
def delete_server_group(request, server_group_id):
    if server_group_id != None and check_customer_with_server_group(request, server_group_id):
        groups = []
        try:
            server_group_handler = MyInfraServerGroup(request)
            groups = server_group_handler.delete_group(server_group_id)
            return APIResponse(request, {'returnCode':error_code.SUCCESS, 'groups':groups})
        except Exception, e:
            return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e , 200)
    else:
        return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, "%s" % 'no authority for service', 200)

# Server
@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_CLB_MANAGE_])
def get_servers(request, server_group_id, server_id=None):
    if check_customer_with_server_group(request, server_group_id):
        if server_id != None:
            is_server = check_customer_with_server_id(request, server_group_id, server_id)
            if is_server == False:
                return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, "%s" % 'no authority for service', 200)
        servers = []
        try:
            server_handler = MyInfraServer(request, server_group_id)
            servers = server_handler.get_server(server_id)
            return APIResponse(request, {'returnCode':error_code.SUCCESS, 'servers':servers})
        except Exception, e:
            return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e , 200)
    else:
        return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, "%s" % 'no authority for service', 200)

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_CLB_MANAGE_])
@transaction.commit_on_success
def add_server(request, server_group_id):
    if check_customer_with_server_group(request, server_group_id):
        if check_server_group_id_with_post_data(request, server_group_id) == True:
            servers = []
            try:
                server_handler = MyInfraServer(request, server_group_id)
                servers = server_handler.add_server()
                return APIResponse(request, {'returnCode':error_code.SUCCESS, 'servers':servers})
            except Exception, e:
                return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e , 200)
        else:
            return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, "%s" % 'no authority for service', 200)
    else:
        return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, "%s" % 'no authority for service', 200)

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_CLB_MANAGE_])
@transaction.commit_on_success
def edit_server(request, server_group_id, server_id):
    if check_customer_with_server_group_and_server_id(request, server_group_id, server_id):
        servers = []
        try:
            server_handler = MyInfraServer(request, server_group_id)
            servers = server_handler.edit_server(server_id)
            return APIResponse(request, {'returnCode':error_code.SUCCESS, 'servers':servers})
        except EmptyParams:
            return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % __ERR_MSG_EMPTY_PARAMS__ , 200)
        except Exception, e:
            return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e , 200)
    else:
        return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, "%s" % 'no authority for service', 200)

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_CLB_MANAGE_])
@transaction.commit_on_success
def delete_server(request, server_group_id, server_id):
    if check_customer_with_server_group_and_server_id(request, server_group_id, server_id):
        try:
            server_handler = MyInfraServer(request, server_group_id)
            servers = server_handler.delete_server(server_id)
            return APIResponse(request, {'returnCode':error_code.SUCCESS, 'servers':servers})
        except Exception, e:
            return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e , 200)
    else:
        return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, "%s" % 'no authority for service', 200)

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_CLB_MANAGE_])
@transaction.commit_on_success
def is_deletable_server(request, server_group_id, server_id):
    if check_customer_with_server_group_and_server_id(request, server_group_id, server_id):
        try:
            server_handler = MyInfraServer(request, server_group_id)
            servers = server_handler.is_deletable_server(server_id)
            return APIResponse(request, {'returnCode':error_code.SUCCESS, 'servers':servers})
        except Exception, e:
            return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e , 200)
    else:
        return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, "%s" % 'no authority for service', 200)

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_CLB_MANAGE_])
@transaction.commit_on_success
def change_server_group(request, server_group_id, server_id):
    if check_customer_with_server_group(request, server_group_id):
        try:
            server_handler = MyInfraServer(request, server_group_id)
            servers = server_handler.change_group(server_id)
            return APIResponse(request, {'returnCode':error_code.SUCCESS, 'servers':servers})
        except Exception, e:
            return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e , 200)
    else:
        return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, "%s" % 'no authority for service', 200)

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_CLB_MANAGE_])
@transaction.commit_on_success
def add_probe(request, server_group_id, server_id):
    servers = []
    try:
        params = getOptionalParams(request)
        probe = params.get('healthcheck')
        server_handler = MyInfraServer(request, server_group_id)
        servers = server_handler.add_probe(server_id, probe)

        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'servers':servers})
    except DoesnotExistServer:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, __ERR_MSG_NOT_EXISTS_SERVER__ , 200)
    except Exception, e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e , 200)

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_CLB_MANAGE_])
@transaction.commit_on_success
def delete_probe(request, server_group_id, server_id):
    servers = []
    try:
        params = getOptionalParams(request)
        probe = params.get('healthcheck')

        server_handler = MyInfraServer(request, server_group_id)
        servers = server_handler.delete_probe(server_id, probe)

        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'servers':servers})
    except DoesnotExistServer:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, __ERR_MSG_NOT_EXISTS_SERVER__ , 200)
    except Exception, e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e , 200)

# deploy
@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_CLB_MANAGE_])
@transaction.commit_on_success
@validate_push_rate_limit('DNS API Myinfra push')
@post_push_action_for_http_response('DNS API Myinfra push')
def infra_deploy(request):
    try:
        deploy_response = ajax_complete(request)
        deploy_response_content = json.loads(deploy_response.content)
        if deploy_response_content['factor'] == 'success':
            return APIResponse(request, {'returnCode':error_code.SUCCESS, 'deploy_info':deploy_response_content})
        else:
            return APIErrorResponse(request, error_code.TEMP_UNAVAILABLE, "%s" % deploy_response_content['msg'])
    except Exception as e:
        return APIErrorResponse(request, error_code.TEMP_UNAVAILABLE, "%s" % e , 200)

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_CLB_MANAGE_])
@transaction.commit_on_success
def get_deploy_status(request):
    try:
        api = ApiHelper()
        customer = get_customer(request)
        params = {
            'customer': customer.pk
        }
        response = api.request_api_server(request, api.CALL_TYPE['GET'],
                                          'myinfra/status/', params)
        if response['data']['status'] == 0:
            if response['data']['msg'] != "":
                response['data']['status_message'] = "Pop ready to be deployed but related zone deploy has failed. Please make sure that related zone configuration is correct."
            else:
                if response['data']['time_deployed'] != None:
                    response['data']['status_message'] = "You have Configuration updates that are in production."
                else:
                    response['data']['status_message'] = "You have new Configuration."
        elif response['data']['status'] == 1:
            if response['data']['msg'] != "":
                if response['data']['timeout'] == True:
                    response['data']['status_message'] = "Your Push to staging has timed out. Please contact support@cdnetworks.com to push the configuration."
                else:
                    response['data']['status_message'] = "Pop deploy to staging is progressing but related zone deploy has failed. Please make sure that related zone configuration is correct."
            else:
                if response['data']['timeout'] == True:
                    response['data']['status_message'] = "Your Push to staging has timed out. Please contact support@cdnetworks.com to push the configuration."
                else:
                    response['data']['status_message'] = "You have requested to push the My Infra configuration to our staging servers. Please wait a few mins, as the push is in progress."
        elif response['data']['status'] == 2:
            if response['data']['msg'] != "":
                response['data']['status_message'] = "Being on staging, pop ready to be deployed but related zone deploy has failed. Please make sure that related zone configuration is correct."
            else:
                response['data']['status_message'] = "Your configuration has been successfully pushed to our staging servers. Please test to make sure you see expected behavior."
                if response['data']['related_zone_status'] == 1:
                    response['data']['status_message'] = "Your configuration has been successfully pushed to our staging servers. But related zone push has not been completed yet. Please wait until the push is completed."
        elif response['data']['status'] == 3:
            if response['data']['msg'] != "":
                if response['data']['timeout'] == True:
                    response['data']['status_message'] = "Your Publish to production has timed out. Please contact support@cdnetworks.com to publish the configuration."
                else:
                    response['data']['status_message'] = "Pop deploy to production is progressing but related zone deploy has failed. Please make sure that related zone configuration is correct."
            else:
                if response['data']['timeout'] == True:
                    response['data']['status_message'] = "Your Publish to production has timed out. Please contact support@cdnetworks.com to publish the configuration."
                else:
                    response['data']['status_message'] = "You have requested to publish the My Infra configuration to our Production Servers. Please wait a few mins, as the push is in progress. "
        elif response['data']['status'] == 4:
            if response['data']['msg'] != "":
                response['data']['status_message'] = "Published to production but related zone deploy has failed. Please make sure that related zone configuration is correct."
            else:
                response['data']['status_message'] = "Your configuration was successfully published on our Production Server.  Please allow a few minutes for the configuration to propagate to all the servers."
                if response['data']['related_zone_status'] == 3:
                    response['data']['status_message'] = "Your configuration was successfully published on our Production Server. But related zone push has not been completed yet. Please wait until the push is completed."
        elif response['data']['status'] == -2:
            response['data']['status_message'] = "Push to Staging Servers Failed. Please check your configuration and re-submit."
        elif response['data']['status'] == -4:
            response['data']['status_message'] = "Push to Production Servers Failed! Please check your configuration or contact the administrator at support@cdnetworks.com"
        
        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'deploy_status':response})
    except Exception as e:
        return APIErrorResponse(request, error_code.TEMP_UNAVAILABLE, "%s" % e , 200)
"""    
"""
# misc
@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_CLB_MANAGE_])
def clb_location(request):
    try:
        api = ApiHelper()
        params = {
            'page_size': 'max'
        }
        locations = api.request_api_server(request, api.CALL_TYPE['GET'],
                                  'clb/locationregion/', params)
        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'locations':locations})
    except Exception, e:
        return APIErrorResponse(request, error_code.TEMP_UNAVAILABLE, "%s" % e , 200)

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_CLB_MANAGE_])
def get_probes(request):
    try:
        api = ApiHelper()
        customer = get_customer(request)
        params = {
        'customer': customer.pk
        }
        response = api.request_api_server(request, api.CALL_TYPE['GET'],
                                  'myinfra/get_available_probes/', params)
        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'healthcheckers':response})
    except Exception, e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e , 200)

###################################################################################################
# FORM
###################################################################################################
class CLBServerGroupForm(forms.Form):
    server_name = forms.CharField(label=_(u"Server Name"), max_length=100, widget=forms.TextInput(attrs={'size':'25'}))
    vip_id = forms.CharField(label=_(u"vip_id"), required=False, max_length=10, widget=forms.TextInput(attrs={'size':'15'}))
    server_vip = forms.CharField(label=_(u"IP"), required=True, max_length=15, widget=forms.TextInput(attrs={'size':'15'}))
    server_enable = forms.ChoiceField(label="enable", choices=STATUS_CHOICES, initial=True, required=False, help_text="")
    server_delete = forms.BooleanField(label="Delete", required=False)
    server_health_check = forms.ModelMultipleChoiceField(label=_(u"Server Health Check"), queryset=BaseProbeConfig.all_objects.all(), required=False,)
    server_move_to = forms.CharField(label=_(u"Move to"), required=False, max_length=15, widget=forms.TextInput(attrs={'size':'15'}))

    def __init__(self, *args, **kwargs):
        super(CLBServerGroupForm, self).__init__(*args, **kwargs)


    def clean_server_vip(self):
        super(CLBServerGroupForm, self).clean()
        server_vip = self.cleaned_data['server_vip'].strip()

        if len(server_vip) > 15:
            raise forms.ValidationError(_(u'Max length must be 15'))

        if not regex_ip.match(server_vip):
            raise forms.ValidationError(_(u'Invalid ip address ipv4'))

        return server_vip

    def clean(self, *args, **kwargs):
        super(CLBServerGroupForm, self).clean()

        if len(self.errors) == 0:
            if self.cleaned_data['server_vip'].strip() != '' and self.cleaned_data['vip_id'].strip() == '':
                vips_obj = Vip.all_objects.filter(Q(vip_addr=self.cleaned_data['server_vip'].strip()))
                if len(vips_obj) > 0:
                    raise forms.ValidationError(_(u'Duplicate ip address'))

                positive_ip = struct.unpack('>L', socket.inet_aton(self.cleaned_data['server_vip'].strip()))[0]
                vips_obj = IhmsVip.all_objects.filter(ip_id=positive_ip)
                if len(vips_obj) > 0:
                    raise forms.ValidationError(_(u'Duplicate ip address'))

            if self.cleaned_data['server_vip'].strip() != '' and self.cleaned_data['vip_id'].strip() != '':
                vips_objs = Vip.all_objects.filter(Q(vip_addr=self.cleaned_data['server_vip'].strip())).exclude(vip=int(self.cleaned_data['vip_id'].strip()))
                if len(vips_objs) > 0:
                    raise forms.ValidationError(_(u'Duplicate IP address'))

                positive_ip = struct.unpack('>L', socket.inet_aton(self.cleaned_data['server_vip'].strip()))[0]
                vips_obj = IhmsVip.all_objects.filter(ip_id=positive_ip)
                if len(vips_obj) > 0:
                    raise forms.ValidationError(_(u'Duplicate ip address'))

            if self.cleaned_data['server_delete'] == True:
                vip = Vip.all_objects.get(Q(vip_addr=self.cleaned_data['server_vip'].strip()))
                domain_vip_objs = DomainVip.all_objects.filter(vip=vip)
                isFlag = False
                domains = []
                for domain_vip in domain_vip_objs:
                    zone = domain_vip.domain.clb_dns_zone
                    if not zone.is_modifiable():
                        isFlag = True
                        domains.append(zone.domain_name)
                if isFlag == True:
                    raise forms.ValidationError(_(u'Domains( %s ) can\'t be modified' % ','.join(domains)))

        return self.cleaned_data

###################################################################################################
class MyInfraServerGroup:
    def __init__(self, request):
        try:
            self.request = request
            self.customer = get_customer(self.request)
        except Exception, e:
            raise Exception(_("Server Group operate error"))

    @property
    def is_modifiable(self):
        return True

    def add_group(self):
        api = ApiHelper()
        customer_id = self.customer.pk
        group_name = self.request.POST.get('group_name', None)
        status = self.request.POST.get('status', None)
        loc = self.request.POST.get('loc', None)
        params = {
            'customer': customer_id,
            'enable_gslb': status,
            'group_name': group_name,
            'region': loc,
        }
        response = api.request_api_server(self.request, api.CALL_TYPE['POST'],
                                  'myinfra/server_group/', params)
        return response

    def get_group(self, server_group_id=None):
        api = ApiHelper()
        params = {
            'customer': self.customer.pk
         }
        if server_group_id != None:
            response = api.request_api_server(self.request, api.CALL_TYPE['GET'],
                              'myinfra/server_group/' + str(server_group_id) + '/', params)
        else:
            params['page_size'] = 'max'
            response = api.request_api_server(self.request, api.CALL_TYPE['GET'],
                              'myinfra/server_group/', params)
        return response

    def edit_group(self, server_group_id):
        api = ApiHelper()
        customer_id = self.customer.pk
        group_name = self.request.POST.get('group_name', None)
        status = self.request.POST.get('status', None)
        loc = self.request.POST.get('loc', None)
        params = {
            'customer': customer_id,
            'enable_gslb': status,
            'group_name': group_name,
            'region': loc,
        }
        response = api.request_api_server(self.request, api.CALL_TYPE['PUT'],
                                  'myinfra/server_group/' + str(server_group_id) + '/', params)
        return response

    def delete_group(self, server_group_id):
        api = ApiHelper()
        deletable = api.request_api_server(self.request, api.CALL_TYPE['GET'],
                                  'myinfra/server_group/'+str(server_group_id)+'/deletable/')
        if deletable['data']['is_deletable'] == True:
            response = api.request_api_server(self.request, api.CALL_TYPE['DELETE'],
                                  'myinfra/server_group/' + str(server_group_id) + '/')
        else:
            raise Exception("Operation is not allow")
        return response
    

class MyInfraServer(MyInfraServerGroup):
    def __init__(self, request, server_group_id=None):
        try:
            self.request = request
            self.customer = get_customer(self.request)
            self.server_group_id = server_group_id
            self.err_msg = ""
        except Exception, e:
            raise Exception(_("Server operate error"))

    @property
    def is_modifiable(self):
        try:
            cp = CustomerContractPop.all_objects.get(pk=self.server_group_id ,
                                                    customer=self.customer)
            if not cp.pop.is_modifiable():
                self.err_msg = 'Server group is in pending and locked(%s). please wait until the lock is released.' % (cp.pop.get_deploy_status())
                return False

            if cp.pop.is_related_clb_zone_pending():
                self.err_msg = "Related zone '%s' is locked(pending status). Please wait until the lock is released." % (cp.pop.get_related_pending_clb_zones())
                return False

            return True
        except CustomerContractPop.DoesNotExist:
            self.err_msg = __ERR_MSG_INVAILD_SERVER_GROUP__
            return False
        except:
            return False

    def add_server(self):
        api = ApiHelper()
        server_data = self.request.POST.get('post_data', None)
        server_data_dict = json.loads(server_data)
        response = api.request_api_server(self.request, api.CALL_TYPE['POST'],
                                  'myinfra/server/', server_data_dict)
        return response

    def get_server(self, server_id=None):
        api = ApiHelper()
        params = {
            'group_id': self.server_group_id,
            'page_size': 'max',
            'customer': self.customer.pk,
            'o': 'server_id'
        }
        get_server_url = 'myinfra/server/'
        if server_id != None:
            get_server_url = get_server_url + str(server_id) + '/'
        response = api.request_api_server(self.request, api.CALL_TYPE['GET'],
                                  get_server_url, params)
        return response

    def edit_server(self, server_id):
        api = ApiHelper()
        server_data = self.request.POST.get('post_data', None)
        server_data_dict = json.loads(server_data)
        response = api.request_api_server(self.request, api.CALL_TYPE['PUT'],
                                  'myinfra/server/' + str(server_id) + '/', server_data_dict)
        return response

    def is_deletable_server(self, server_id):
        api = ApiHelper()
        response = api.request_api_server(self.request, api.CALL_TYPE['GET'],
                                  'myinfra/server/' + str(server_id) + '/related/')
        return response

    def delete_server(self, server_id):
        api = ApiHelper()
        response = api.request_api_server(self.request, api.CALL_TYPE['DELETE'],
                                  'myinfra/server/' + str(server_id) + '/')
        return response

    def change_group(self, server_id):
        if self.is_modifiable:
            pass
        else:
            raise BlockConfiguration(self.err_msg)

        params = getOptionalParams(self.request)
        server_move_to = params.get("new_group_id", None)

        try:
            if server_move_to == "":
                raise Exception(_(u"Target Server group is not valid"))

            new_cp = CustomerContractPop.all_objects.get(pk=server_move_to , customer=self.customer)
        except:
            raise Exception(_(u"Target Server group is not valid"))

        try:
            cp = CustomerContractPop.all_objects.get(pk=self.server_group_id , customer=self.customer)
        except:
            raise Exception(__ERR_MSG_INVAILD_SERVER_GROUP__)

        try:
            vip_obj = Vip.all_objects.get(pk=server_id, host__system__pop=cp.pop)
        except:
            raise Exception(_(__ERR_MSG_NOT_EXISTS_SERVER__))

        try:
            other_host = Host.all_objects.get(system__pop=new_cp.pop)
            vip_obj.host = other_host
        except:
            system_objs = System.all_objects.filter(pop=new_cp.pop).order_by('-system_name')  # s999
            if system_objs.count() == 0:
                nex_system_name = 's0'
                system_obj = System(pop=new_cp.pop, system_name=nex_system_name)
            else:
                system_obj = system_objs[0]

            system_obj.save(request=self.request)

            host_objs = Host.all_objects.filter(system=system_obj).order_by('-host_name')  # h0
            if host_objs.count() == 0:
                nex_host_name = 'h0'
                host_obj = Host(system=system_obj, host_name=nex_host_name)
            else:
                host_obj = host_objs[0]

            host_obj.save(request=self.request)
            vip_obj.host = host_obj

        # first check dup in other system for move
        vip_check_objs = Vip.all_objects.filter(host=vip_obj.host, vip_name=vip_obj.vip_name).order_by('-vip_name')  # h0
        if len(vip_check_objs) > 0:
            vip_check_objs = Vip.all_objects.filter(host=vip_obj.host).order_by('-vip_name')  # h0

            name_arr = []
            for obj in vip_check_objs:
                try:
                    vip_num = int(obj.vip_name[1:len(obj.vip_name)])
                except:
                    continue
                name_arr.append(vip_num)
            name_arr.sort()
            cur_vip_max = max(name_arr)  # 0
            nex_vip_name = 'i' + str(int(cur_vip_max) + 1)
            vip_obj.vip_name = nex_vip_name

        vip_obj.save(request=self.request)
        vip_state = '1' if vip_obj.enable_gslb == True else '0'
        vip_probes = []
        for vip_probe_conf_obj in vip_obj.probeconfigs.all():
            vip_probes.append(vip_probe_conf_obj.name)

        # update pop status
        cp.pop.save(request=self.request)
        # cp.pop.update_status_modified_related_clb_zones(request=self.request)
        new_cp.pop.save(request=self.request)
        # new_cp.pop.update_status_modified_related_clb_zones(request=self.request)

        domains = [domainvip['domain__name'] for domainvip in DomainVip.objects.filter(vip=vip_obj)\
                                                                                .values('domain__name')]
        pop_status_code , status_text = convert_pop_status(new_cp.pop)
        server = {
            "server_id" : vip_obj.pk,
            "server_name" : vip_obj.vip_alias_name,
            'server_disp':vip_obj.vip_addr + ' (' + vip_obj.vip_alias_name + ')',
            "ip" : vip_obj.vip_addr,
            "group_id": cp.id,
            "group_name" : cp.pop_alias,
            "is_active" : vip_state,
            "healthcheckers" : vip_probes,
            "domains" :domains,
            "status" : pop_status_code,
            "status_text" : status_text

        }

        return server

    def add_probe(self, server_id, probe):
        if self.is_modifiable:
            pass
        else:
            raise BlockConfiguration(self.err_msg)

        pop_xml_changed = False
        probe = probe.split(PARAM_SEPERATOR)
        valid_probes = self.valid_probe(probe)

        if valid_probes is False:
            raise Exception(_(__ERR_MSG_INVAILD_PROBE__))

        cp = CustomerContractPop.all_objects.get(pk=self.server_group_id , customer=self.customer)
        try:
            vip = Vip.objects.get(vip=server_id, host__system__pop=cp.pop)
        except:
            raise DoesnotExistServer

        for add_probe in valid_probes:
            try:
                probe = VipProbeConfigs.objects.get(vip=vip , probe=add_probe)

                if probe:
                    raise Exception(__ERR_MSG_ALREADY_EXISTS_PROBE__)
            except VipProbeConfigs.DoesNotExist:
                probe = VipProbeConfigs(vip=vip, probe=add_probe)
                pop_xml_changed = True
            except Exception, e:
                raise Exception(e)

            probe.save(request=self.request)

        if pop_xml_changed :
            cp.pop.save(request=self.request)
            vip.save(request=self.request)
            # cp.pop.update_status_modified_related_clb_zones(request=self.request)
        return {"server_name": vip.vip_alias_name, "ip": vip.vip_addr , "add_probes":[p.name for p in valid_probes] }

    def delete_probe(self, server_id, probe):
        if self.is_modifiable:
            pass
        else:
            raise BlockConfiguration(self.err_msg)

        pop_xml_changed = False
        probe = probe.split(PARAM_SEPERATOR)
        valid_probes = self.valid_probe(probe)

        if valid_probes is False:
            raise Exception(_(__ERR_MSG_INVAILD_PROBE__))

        cp = CustomerContractPop.all_objects.get(pk=self.server_group_id , customer=self.customer)
        try:
            vip = Vip.objects.get(vip=server_id, host__system__pop=cp.pop)
        except:
            raise DoesnotExistServer

        try:
            probe = VipProbeConfigs.objects.filter(vip=vip , probe__in=valid_probes)

            if probe.count() > 0:
                cp.pop.save(request=self.request)

                probe.delete()
                vip.save(request=self.request)
                # cp.pop.update_status_modified_related_clb_zones(request=self.request)
            else:
                raise Exception(__ERR_MSG_DELETE_NOT_EXIST_PROBE__)

            return {"server_id": vip.pk, "server_name": vip.vip_alias_name, "ip": vip.vip_addr , "deleted_probes":[p.name for p in valid_probes] }
        except Exception , e:
            raise

    def valid_probe(self, probes):
        probe_ids = []
        probe_names = []

        if probes is None or probes == []:
            return []

        if type(probes) is list:
            param_probes = probes
        else:
            param_probes = [probes, ]

        for probe in param_probes:
            probe = probe.strip()
            try:
                probe_id = int(probe)
                probe_ids.append(probe_id)
            except:
                probe_names.append(probe)

        my_probe_objs = CustomerAllowProbeConfig.objects\
                                            .filter(customer=self.customer)\
                                            .values('probeconfig_id')
        other_allow_config_objs = CustomerAllowProbeConfig.objects\
                                                .exclude(customer=self.customer)\
                                                .values('probeconfig_id')
        base_probe_config_for_customer = BaseProbeConfig.objects.filter(use_clb=1)\
                                                        .exclude(pk__in=other_allow_config_objs) \
                                                        .filter(Q(name__in=probe_names)
                                                                | Q(probeconfig_id__in=probe_ids))

        base_probe_config_for_customer = base_probe_config_for_customer

        valid_probe_ids = [bp.pk for bp in base_probe_config_for_customer]
        valid_probe_names = [bp.name for bp in base_probe_config_for_customer]

        for probe_id in probe_ids:
            if probe_id in valid_probe_ids:
                pass
            else:
                raise Exception("%s (%s)" % (__ERR_MSG_INVAILD_PROBE__, probe_id))

        for probe_name in probe_names:
            if probe_name in valid_probe_names:
                pass
            else:
                raise Exception("%s (%s)" % (__ERR_MSG_INVAILD_PROBE__, probe_name))

        if base_probe_config_for_customer.count() > 0:
            return base_probe_config_for_customer
        else:
            return False

# exceptions
class DoesnotExistServer(Exception):
    pass

# BlockConfiguration
class BlockConfiguration(Exception):
    pass

class InvalidParams(Exception):
    pass

class EmptyParams(Exception):
    pass
