# -*- coding: utf-8 -*-
from django.views.decorators.csrf import csrf_exempt
from aurora_api.shared_components.decorators import api_param_validate, config_api_authority_required
from aurora_fe.shared_components.utils import get_customer
from spectrum_fe.dns.views.dns_zone import get_dns_zone, get_all_clb_domain
from aurora_api.utils import APIErrorResponse, APIResponse
from aurora_api import error_code
from django.utils.translation import ugettext as _
from spectrum_fe.shared_components.utils.api import ApiHelper, getOptionalParams
import json
from aurora_fe.dns.views.clb_list import ajax_get_clb_domains
from spectrum_fe.dna.models.domain import Domain

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=['CD', 'CD_CLB'])
def get_all_clb_domain_list(request, zone_id):
    try:
        customer = get_customer(request)
        dns_zone = get_dns_zone(zone_id, customer)
        if dns_zone == None:
            return APIErrorResponse(request, error_code.INVALID_REQUEST, "Invalid parameter", 200)
        clb_domain = get_all_clb_domain(zone_id, dns_zone)
        clb_domain_list = get_clb_domain_list_by_queryset(clb_domain)
        if len(clb_domain_list) != 0:
            return APIResponse(request, {'returnCode':error_code.SUCCESS, 'clb_domain':clb_domain_list})
        else:
            return APIErrorResponse(request, error_code.NO_DATA, _('There is not exists available domain'), 200)
    except Exception as e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e, 200)

def get_clb_domain_list_by_queryset(queryset_clb_domain):
    clb_domain_list = []
    for clb_domain in queryset_clb_domain:
        clb_domain_dict = {}
        clb_domain_dict["domain_id"] = clb_domain.domain_id
        clb_domain_dict["name"] = clb_domain.name
        clb_domain_list.append(clb_domain_dict)
    return clb_domain_list


@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=['CD', 'CD_CLB'])
def get_clb_domain(request, domain_id):
    try:
        customer_id = get_customer(request).customer_id
        api = ApiHelper()
        response = api.request_api_server(request, api.CALL_TYPE['GET'],
                                          "clb_domains/%s/?customer=%s" % (domain_id, customer_id))
        return APIResponse(request, {'returnCode': get_api_error_code(response['status_code']), 'clb_domain': response})
    except Exception as e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e, 200)

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=['CD', 'CD_CLB'])
def search_domain_servers(request, healthchecker, servergroup, active):
    try:
        customer_id = get_customer(request).customer_id
        iprule = request.POST.get('iprule', None)
        url = "servers/?customer=%s" % (customer_id)
        if healthchecker != "0":
            url = "%s&healthchecker=%s" % (url, healthchecker)
        if servergroup != "0":
            url = "%s&group_id=%s" % (url, servergroup)
        if iprule != None:
            url = "%s&ip__icontains=%s" % (url, iprule)
        if active != "2":
            url = url = "%s&is_active=%s" % (url, active)
        api = ApiHelper()
        response = api.request_api_server(request, api.CALL_TYPE['GET'], url)
        return APIResponse(request, {'returnCode': get_api_error_code(response['status_code']), 'domain_servers': response})
    except Exception as e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e, 200)

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=['CD', 'CD_CLB'])
def create_clb_domain(request):
    try:
        customer = get_customer(request)
        customer_id = customer.customer_id
        clb_data = request.POST.get('post_data', None)
        clb_data_dict = json.loads(clb_data)

        # SPECTRUM-244
        # when user posts without 'clb_dns_zone' value
        # returns API Error Response
        zone_id = clb_data_dict.get('clb_dns_zone')
        if zone_id is None:
            return APIErrorResponse(request, error_code.INVALID_REQUEST, "clb_dns_zone is required", 200)

        zone_id = int(zone_id)
        zone = get_dns_zone(zone_id, customer)
        if zone == None:
            return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, "no authority for service", 200)
        api = ApiHelper()
        response = api.request_api_server(request, api.CALL_TYPE['CREATE'],
                                      "clb_domains/?customer=%s" % (customer_id), clb_data_dict)
        return APIResponse(request, {'returnCode': get_api_error_code(response['status_code']), 'clb_domain': response})
    except Exception as e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e, 200)

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=['CD', 'CD_CLB'])
def update_clb_domain(request):
    try:
        customer = get_customer(request)
        customer_id = customer.customer_id
        clb_data = request.POST.get('post_data', None)
        clb_data_dict = json.loads(clb_data)
        zone_id = int(clb_data_dict['clb_dns_zone'])
        zone = get_dns_zone(zone_id, customer)
        if zone == None:
            return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, "no authority for service", 200)
        api = ApiHelper()
        response = api.request_api_server(request, api.CALL_TYPE['UPDATE'],
                                      "clb_domains/?customer=%s" % (customer_id), clb_data_dict)
        return APIResponse(request, {'returnCode': get_api_error_code(response['status_code']), 'clb_domain': response})
    except Exception as e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e, 200)

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=['CD', 'CD_CLB'])
def delete_clb_domain(request, domain_id):
    try:
        customer = get_customer(request)
        customer_id = customer.customer_id
        clb_domain = Domain.objects.filter(domain_id=domain_id)
        if len(clb_domain) > 0:
            zone_id = clb_domain[0].clb_dns_zone.zone_id
            zone = get_dns_zone(zone_id, customer)
            if zone == None:
                return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, "no authority for service", 200)
        else:
            return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, "no authority for service", 200)
        customer_id = get_customer(request).customer_id
        api = ApiHelper()
        response = api.request_api_server(request, api.CALL_TYPE['DELETE'], "clb_domains/%s/?customer=%s" % (domain_id, customer_id))
        return APIResponse(request, {'returnCode': get_api_error_code(response['status_code']), 'clb_domain': response})
    except Exception as e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e, 200)

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=['CD', 'CD_CLB'])
def get_clb_domain_list(request):
    try:
        params = getOptionalParams(request)
        cg_id = params.get('cgId')
        clb_domain_list = ajax_get_clb_domains(request, cg_id)
        clb_domain_list = json.loads(clb_domain_list.content)['data']
        if len(clb_domain_list) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, _('There is not exists available domain'), 200)
        return APIResponse(request, {'returnCode': error_code.SUCCESS, 'clb_domain_list': clb_domain_list})
    except Exception as e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e, 200)

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=['CD', 'CD_CLB'])
def get_geo_data(request):
    try:
        customer_id = get_customer(request).customer_id
        api = ApiHelper()
        response = api.request_api_server(request, api.CALL_TYPE['GET'],
                                          "geo/?customer=%s" % (customer_id))
        return APIResponse(request, {'returnCode': get_api_error_code(response['status_code']), 'geo_data': response})
    except Exception as e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e, 200)


def get_api_error_code(status_code):
    if int(status_code) == 200:
        return error_code.SUCCESS
    elif int(status_code) == 404:
        return error_code.NO_DATA
    else:
        return error_code.TEMP_UNAVAILABLE

