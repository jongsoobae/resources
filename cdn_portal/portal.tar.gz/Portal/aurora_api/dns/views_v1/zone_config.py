# -*- coding: utf-8 -*-
"""
    Copyright (c) 2012 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Cloud DNS configuration API
"""
from django.conf import settings
from django.core.paginator import Paginator, EmptyPage, InvalidPage, PageNotAnInteger
from django.db.models import Q
from django.utils import simplejson
from django.utils.translation import ugettext as _
from django.views.decorators.csrf import csrf_exempt

from aurora_api import error_code, settings
from aurora_api.shared_components.decorators import config_api_authority_required, api_param_validate
from aurora_api.utils import APIErrorResponse, APIResponse, APIException
from aurora_fe.shared_components.utils import get_customer
from spectrum_fe.dna.models.domain import Domain
from spectrum_fe.dns.forms.dns import DNSZoneForm, DNSNSForm, DNSSOAForm, DNSAForm, DNSAAAAForm, \
DNSCNAMEForm, DNSMXForm, DNSTXTForm, DNSSearchForm, DNSPTRForm, DNSRPForm, DNSSPFForm, DNSSRVForm,\
DNSResolveCNAMEForm
from spectrum_fe.dns.models.dns import DNSZone, DNSSoa, DNSNs, DNSA, DNSAaaa, \
 DNSCname, DNSMx, DNSTxt, DNSPtr, DNSRp, DNSSpf, DNSSrv, DNSResolveCname, ZONE_STATUS, DNSStatMaster
from spectrum_fe.shared_components.utils.api import getOptionalParams
from aurora_fe.shared_components.utils.stat import get_stat_master_queryset_by_control_group_and_material_no
from spectrum_fe.shared_components.decorators import validate_push_rate_limit, post_push_action_for_http_response

# from aurora_fe.api.views.stat import getKeys, checkServiceAuth, \
#    generate_base_traffic, chStrFormatOfDate, service_mapper, getMaterialNoByApiKey
__CLOUD_DNS_CONFIG_API_VERSION__ = 1

__XML_MIME_TYPE__ = "text/xml"
__JSON_MIME_TYPE__ = "application/json"

__CREATE_OPERATION_METHOD__ = "POST"
__READ_OPERATION_METHOD__ = "GET"
__UPDATE_OPERATION_METHOD__ = "PUT"
__DELETE_OPERATION_METHOD__ = "DELETE"

__SERIAL_FORMAT_DATEFORMAT__ = 0
__SERIAL_FORMAT_NUMBER__ = 1
__SERIAL_FORMAT_MANUAL__ = 2

__DNS_RECORD_A__ = 'A'
__DNS_RECORD_NS__ = 'NS'
__DNS_RECORD_MX__ = 'MX'
__DNS_RECORD_SOA__ = 'SOA'
__DNS_RECORD_TXT__ = 'TXT'
__DNS_RECORD_AAAA__ = 'AAAA'
__DNS_RECORD_CNAME__ = 'CNAME'
__DNS_RECORD_RCNAME__ = 'RCNAME'
__DNS_RECORD_PTR__ = 'PTR'
__DNS_RECORD_SRV__ = 'SRV'
__DNS_RECORD_SPF__ = 'SPF'
__DNS_RECORD_RP__ = 'RP'

DNS_SUPPORT_RECORD_TYPE = (
    __DNS_RECORD_A__,
    __DNS_RECORD_NS__,
    __DNS_RECORD_MX__,
    __DNS_RECORD_SOA__,
    __DNS_RECORD_TXT__,
    __DNS_RECORD_AAAA__,
    __DNS_RECORD_CNAME__,
    __DNS_RECORD_RCNAME__,
    __DNS_RECORD_PTR__,
    __DNS_RECORD_SRV__,
    __DNS_RECORD_SPF__,
    __DNS_RECORD_RP__
)

_CDNS_READ_ = "CD"
_CDNS_MANAGE_ = "CD_ZONE_MANAGEMENT"
_CDNS_CLB_MANAGE_ = "CD_CLB"

DEFAULT_LIST_SCALE_LIMIT = 25

ZONE_DATE_FORMAT = '%Y-%m-%d %H:%M:%S'


if settings.PROJECT_NAME == 'aurora_api':
    SERIAL_FORMAT_CHOICES = (
        (__SERIAL_FORMAT_DATEFORMAT__ , _(u"Date Format")),  # date
        (__SERIAL_FORMAT_NUMBER__ , _(u"Number")),  # incremental
    )
else:
    SERIAL_FORMAT_CHOICES = (
        (__SERIAL_FORMAT_DATEFORMAT__ , _(u"Date Format")),  # date
        (__SERIAL_FORMAT_NUMBER__ , _(u"Number")),  # incremental
        (__SERIAL_FORMAT_MANUAL__ , _(u"Manual")),  # no incremental
    )
LOCK_STATUS = (1, 3)
STATUS_IN_PRODUCTION = 4
WARN_DOMAIN_LOCKED = _(u'This Domain is locked while deploy. Please wait a progress.')
__READONLY_ZONE_STATE__ = 3
WARN_READONLY_DOMAIN = _(u'This Domain is set locked. You can just read domain records')

CDNS_MATRIAL = getattr(settings, 'DNS_MATERIAL')

MSG_DEFAULT_NS_LOCKED = _(u"You can't modify default name server record. Please contact technical supports.")

CDNS_PERMISSION = {
    CDNS_MATRIAL : {
        __READ_OPERATION_METHOD__ : [_CDNS_READ_, _CDNS_MANAGE_],
        __CREATE_OPERATION_METHOD__ : [_CDNS_MANAGE_],
        __UPDATE_OPERATION_METHOD__ : [_CDNS_MANAGE_],
        __DELETE_OPERATION_METHOD__ : [_CDNS_MANAGE_]
    }
}

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_READ_ , _CDNS_MANAGE_])
def cdns_config(request, zone_id=None):
    try:
        zone_handler = ZoneHandler(request)
        zones = zone_handler.get_zone_info(zone_id)
    except Exception, e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e , 200)

    return APIResponse(request, {'returnCode':error_code.SUCCESS, 'domains':zones})

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_MANAGE_])
def cdns_config_edit(request, zone_id=None):
    try:
        if zone_id:
            zone_handler = ZoneHandler(request)
            zones = zone_handler.update_zone_info(zone_id)
        else:
            return APIErrorResponse(request, error_code.INVALID_REQUEST, _('You missing input domain ID') , 200)
    except Exception, e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e, 200)
    return APIResponse(request, {'returnCode':error_code.SUCCESS, 'domains':zones})

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_READ_ , _CDNS_MANAGE_])
def record_config(request, zone_id, record_type=None, record_id=None):
    try:
        record_handler = RecordHandler(request, zone_id)
        records = record_handler.get_records(record_type, record_id)
    except Exception, e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e, 200)
    return APIResponse(request, {'returnCode':error_code.SUCCESS, 'records':records})

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_MANAGE_])
def record_config_add(request, zone_id, record_type=None):
    try:
        record_type = record_type.upper()
    except:
        record_type = None

    try:
        record_handler = RecordHandler(request, zone_id)
        records = record_handler.create_records(record_type)
    except Exception, e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e, 200)
    return APIResponse(request, {'returnCode':error_code.SUCCESS, 'records':records})

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_MANAGE_])
def record_config_edit(request, zone_id, record_type=None, record_id=None):
    try:
        if record_type:
            record_type = record_type.upper()
    except:
        record_type = None
    try:
        record_handler = RecordHandler(request, zone_id)
        records = record_handler.update_records(record_type, record_id)
    except Exception, e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e, 200)

    return APIResponse(request, {'returnCode':error_code.SUCCESS, 'records':records})

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_MANAGE_])
def record_config_delete(request, zone_id, record_type, record_id):
    try:
        if record_type:
            record_type = record_type.upper()
    except:
        record_type = None
    try:
        record_handler = RecordHandler(request, zone_id)
        records = record_handler.delete_records(record_type, record_id)
    except Exception, e:
        return APIErrorResponse(request, error_code.INVALID_REQUEST, "%s" % e, 200)

    return APIResponse(request, {'returnCode':error_code.SUCCESS, 'records':[]})

@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_MANAGE_])
@validate_push_rate_limit('DNS API push')
@post_push_action_for_http_response('DNS API push')
def config_deploy(request, zone_id):
    if zone_id:
        try:
            params = getOptionalParams(request)
            cg_id = params.get('cgId', None)
            stat_items = get_stat_master_queryset_by_control_group_and_material_no(cg_id, settings.DNS_MATERIAL)
            dnsstatmasters = DNSStatMaster.objects.filter(statmaster__in=stat_items).values('dnszone')
            is_permission = False
            for dnsstatmaster in dnsstatmasters:
                if dnsstatmaster.get("dnszone") == long(zone_id):
                      is_permission = True
            if is_permission == False:
                raise DNSZone.DoesNotExist
            zone = DNSZone.active_locked_objects.get(zone_id=zone_id, customer=get_customer(request),
                                    dnsstatmaster__statmaster__material_no__in=get_has_material(request.session['user_priv'])
                                    )
        except DNSZone.DoesNotExist:
            return APIErrorResponse(request, error_code.NO_DATA, _('There is not exists available domain'), 200)
        """
        ZONE_STATUS = (
            (0, 'Modified'),
            (1, 'Pending Testing'),
            (2, 'Sent to Stage'),
            (3, 'Promote to Production'),
            (4, 'In Production'),
            (-2, 'Pending Failed'),
            (-4, 'Production Failed'),
        )
        """
        allow_operation = False
        zone_product = zone.dnsstatmaster_set.all()[0].statmaster.material_no

        for user_priv in request.session['user_priv']:
            if user_priv in CDNS_PERMISSION[zone_product][__UPDATE_OPERATION_METHOD__]:
                allow_operation = True
                break

        if allow_operation is False:
            return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, _(u"You do not have permission to deploying"), 200)

        if not zone.is_modifiable():
            return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, WARN_DOMAIN_LOCKED, 200)
        elif zone.status == STATUS_IN_PRODUCTION:
            return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, _(u"Already configuration deployed"), 200)
        else:
            # MyInfra Push Check
            check_myinfra_push_status, fail_msg = myinfra_push_check(zone)
            if not check_myinfra_push_status:
                return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, fail_msg, 200)

            try:
                zone.save(request=request,
                            push=True,
                            user=request.user)
            except Exception, e:
                return APIErrorResponse(request, error_code.FAIL_CONFIG_UPDATE, _('Error occurred while deploy domain configuration'), 200)
    else:
        return APIException(request, error_code.WRONG_INPUT, _('You miss domain ID. Please Check Your input parameters'))
    return APIResponse(request, {'returnCode':error_code.SUCCESS, 'deploy_info': {'zone_id':zone_id, 'phase': zone_status(zone.status, zone.time_deployed)}})

# MyInfra Push Check
def myinfra_push_check(dns_zone):
    msg = ''
    try:
        clb_domains = dns_zone.get_clb_domains()
        if clb_domains.exists():
            clb_domain_status = dns_zone.get_clb_domain_deploy_status()
            pop_status = dns_zone.get_myinfra_deploy_status()
            timeout = dns_zone.get_myinfra_deploy_timeout()

            if dns_zone.status == 0:
                if pop_status in [-4, -2, 0]:
                    raise Exception(_("My Infra push needs to be done. \'My Infra\' push the configuration first."))
                elif pop_status in [1, 3] and not timeout:
                    raise Exception(_('My Infra is currently in status pending. Please wait until the push is completed.'))
            elif dns_zone.status == 2:
                if clb_domain_status == 1:
                    raise Exception(_('Related clb domain currently in status pending. Please wait until the push is completed.'))
                if pop_status in [-4, -2, 0, 2]:
                    raise Exception(_("My Infra push needs to be done. \'My Infra\' push the configuration first."))
                elif pop_status in [1, 3] and not timeout:
                    raise Exception(_('My Infra is currently in status pending. Please wait until the push is completed.'))
    except Exception as e:
        return False, "%s" % e

    return True, msg


@csrf_exempt
@api_param_validate
@config_api_authority_required(material_group_cd=[_CDNS_CLB_MANAGE_])
def export_conf(request, zone_id=None):
    configs = []
    try:
        clb_domains = Domain.objects.filter(clb_dns_zone__customer=get_customer(request))

        if zone_id:
            clb_domains = clb_domains.filter(clb_dns_zone__zone_id=zone_id)

        for gslb_domain in clb_domains:
            if gslb_domain.get_clb_attrib():
                configs.append(gslb_domain.get_clb_attrib())
        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'conf':configs})
    except Exception , e:
        return APIException(request, error_code.WRONG_INPUT, _('You miss domain ID. Please Check Your input parameters'))

def zone_status(zone_status, deployed_t):
    status_txt = ""
    for ZS in ZONE_STATUS:
        if zone_status == ZS[0]:
            if zone_status == 0:
                if deployed_t:
                    status_txt = ZS[1]
                else:
                    status_txt = _(u'New')
            else:
                status_txt = ZS[1]
            break
    return status_txt

def zone_readonly(zone_obj_state):
    if zone_obj_state == __READONLY_ZONE_STATE__:
        return True
    else:
        return False

def material_text(material):
    try:
        if CDNS_MATRIAL == material:
            return _(u'Cloud DNS')
        else:
            return ""
    except:
        return ""

def get_has_material(user_priv):
    has_cdns = False
    material_no = []
    for priv in user_priv:
        if priv.startswith(_CDNS_READ_):
            has_cdns = True

    if has_cdns:
        material_no.append(CDNS_MATRIAL)

    return material_no

class ZoneHandler:
    def __init__(self, request):
        try:
            self.request = request
            self.customer = get_customer(request)
            self.account = self.customer.account
        except Exception, e:
            raise Exception(_('Invalid Request'))

    def get_zone_info(self, zone_id=None):
        params = getOptionalParams(self.request)
        filter_keyword = params.get('name', None)
        list_scale = params.get('limit', None)
        page = params.get('page', None)
        cg_id = params.get('cgId', None)
        stat_items = get_stat_master_queryset_by_control_group_and_material_no(cg_id, settings.DNS_MATERIAL)

        try:
            dnsstatmasters = DNSStatMaster.objects.filter(statmaster__in=stat_items)
            zones = DNSZone.active_locked_objects.filter(customer=self.customer,
                                                         zone_id__in=dnsstatmasters.values('dnszone'),
                                                         dnsstatmaster__statmaster__material_no__in=get_has_material(self.request.session['user_priv']))
        except:
            raise Exception(_('Unable to get domain list'))

        if zone_id:
            zones = zones.filter(zone_id=zone_id)
        else:
            if filter_keyword:
                keyword_form = DNSSearchForm({'txt_search':filter_keyword})
                if keyword_form.is_valid():
                    filter_keyword = keyword_form.cleaned_data.get('txt_search')
                    zones = zones.filter(domain_name__icontains=filter_keyword)
                else:
                    raise Exception(_(u'Search keyword length should be 2~255 bytes.'))

        try:
            page = int(page)
            if page < 1 :
                page = 1
        except:
            page = 1

        try:
            list_scale = int(list_scale)
            if list_scale < 1 :
                list_scale = DEFAULT_LIST_SCALE_LIMIT
        except:
            list_scale = DEFAULT_LIST_SCALE_LIMIT

        paginator = Paginator(zones, list_scale)
        try:
            zone_items = paginator.page(page)
        except EmptyPage:
            zone_items = paginator.page(paginator.num_pages)
        except PageNotAnInteger:
            zone_items = paginator.page(1)
        except InvalidPage:
            zone_items = paginator.page(1)
        except:
            zone_items = paginator.page(1)

        page_info = {
            'max' : paginator.num_pages,
            'page' : page,
            'list_scale' : list_scale,
            'count' : paginator.count
        }

        data = []

        for zone_item in zone_items.object_list:
            try:
                updated_t = zone_item.time_updated.strftime(ZONE_DATE_FORMAT)
            except:
                updated_t = ""
            try:
                deployed_t = zone_item.time_deployed.strftime(ZONE_DATE_FORMAT)
            except:
                deployed_t = ""

            try:
                sr_no = zone_item.dnssoa.serial_number
            except:
                sr_no = ""

            try:
                product_name = material_text(zone_item.dnsstatmaster_set.all()[0].statmaster.material_no)
            except:
                product_name = ""

            zone_info = {
                    'domain_id': zone_item.zone_id,
                    'name' : zone_item.domain_name,
                    'ttl' : zone_item.ttl,
                    'serial' : sr_no,
                    'last_modified' : updated_t,
                    'last_published' : deployed_t,
                    'status' : zone_status(zone_item.status, zone_item.time_deployed),
                    'status_code' : zone_item.status,
                    'product' : product_name,
                    'readonly' : zone_readonly(zone_item.obj_state),
                    'customer' : {
                        'name' : zone_item.customer.customer_name.strip()
                    }
                }
            data.append(zone_info)
        return {'page_info' : page_info, 'domains': data}

    def update_zone_info(self, zone_id):
        try:
            zone = DNSZone.active_locked_objects.get(customer=self.customer,
                                                    dnsstatmaster__statmaster__material_no__in=get_has_material(self.request.session['user_priv']),
                                                    zone_id=zone_id)
        except DNSZone.DoesNotExist:
            raise Exception(_(u'Domain does not exists. Please check your input values'))
        except:
            raise Exception(_(u'Something happen in trouble'))

        if zone.obj_state == __READONLY_ZONE_STATE__:
            raise Exception(WARN_READONLY_DOMAIN)

        if not zone.is_modifiable():
            raise Exception(WARN_DOMAIN_LOCKED)

        allow_operation = False
        try:
            zone_product = zone.dnsstatmaster_set.all()[0].statmaster.material_no

            for user_priv in self.request.session['user_priv']:
                if user_priv in CDNS_PERMISSION[zone_product][__UPDATE_OPERATION_METHOD__]:
                    allow_operation = True
                    break
        except:
            # if zone hasn't product(cdns or cdns-d) type. raise error.
            raise Exception(_(u"This domain hasn't product type. Please contact CDNetworks technical supports."))

        if allow_operation is False:
            raise Exception(_(u"You do not have permission to update domain configuration."))

        # request_data = request.raw_post_data
        params = getOptionalParams(self.request)

        default_ttl = params.get('ttl', None)
        # serial = params.get('serial',None)
        # serial_format = params.get('serial_format',None)

        # initial_params = {'zone_name' : zone.domain_name , 'zone_ttl' : zone.ttl}
        # zone_form = DNSZoneForm(initial=initial_params)
        zone_form = DNSZoneForm({'zone_ttl' : default_ttl})
        # zone_soa_form = DNSSOAForm({
        #        'soa_ttl': zone.dnssoa.ttl,
        #        'soa_class' : zone.dnssoa.class_name,
        #        'soa_nameserver' : zone.dnssoa.name_server,
        #        'soa_email' : zone.dnssoa.email,
        #        'soa_serial_num_choices' : serial_format,
        #        'soa_serial_num' : serial,
        #    })

        # if zone_form.is_valid():
        try:
            if not zone_form.errors.get('zone_ttl'):
                zone.ttl = int(default_ttl)
                zone.save(request=self.request, allow_saving=True)
            else:
                raise Exception(_("%s" % zone_form.errors.get('zone_ttl').as_text().strip("*").strip()))
        except Exception, e:
            raise Exception(_('%s' % e))

        # if serial & serial format is valid do update serial.
        # if zone_soa_form.is_valid():
        #    try:
        #        if zone_soa_form.cleaned_data['soa_serial_num_choices'] == __SERIAL_FORMAT_DATEFORMAT__:
        #            zone.dnssoa.serial_format = zone_soa_form.cleaned_data['soa_serial_num_choices']
        #        elif zone_soa_form.cleaned_data['soa_serial_num_choices'] == __SERIAL_FORMAT_NUMBER__:
        #            zone.dnssoa.serial_format = zone_soa_form.cleaned_data['soa_serial_num_choices']
        #        else :
        #            zone.dnssoa.serial_format = zone_soa_form.cleaned_data['soa_serial_num_choices']
        #            zone.dnssoa.soa_serial_num = zone_soa_form.cleaned_data['soa_serial_num']
        #        zone.dnssoa.save(request=self.request,completed=1)
        #    except Exception, e:
        #        raise Exception(_('Domain serial number update failed'))

        try:
            updated_t = zone.time_updated.strftime(ZONE_DATE_FORMAT)
        except:
            updated_t = ""
        try:
            deployed_t = zone.time_deployed.strftime(ZONE_DATE_FORMAT)
        except:
            deployed_t = ""

        try:
            sr_no = zone.dnssoa.serial_number
        except:
            sr_no = ""

        try:
            product_name = material_text(zone.dnsstatmaster_set.all()[0].statmaster.material_no)
        except:
            product_name = ""

        zone_info = {
                'domain_id': zone.zone_id,
                'name' : zone.domain_name,
                'ttl' : zone.ttl,
                'serial' : sr_no,
                'last_modified' : updated_t,
                'last_published' : deployed_t,
                'status' : zone_status(zone.status, zone.time_deployed),
                'status_code' : zone.status,
                'product' : product_name,
                'readonly' : zone_readonly(zone.obj_state),
                'customer' : {
                    'name' : zone.customer.customer_name.strip()
                }
            }

        return zone_info

class RecordHandler:
    def __init__(self, request, zone_id):
        try:
            self.request = request
            self.customer = get_customer(request)
            self.account = self.customer.account
            self.readonly = False
            self.push_wait = False
            params = getOptionalParams(self.request)
            cg_id = params.get('cgId', None)
            stat_items = get_stat_master_queryset_by_control_group_and_material_no(cg_id, settings.DNS_MATERIAL)
            dnsstatmasters = DNSStatMaster.objects.filter(statmaster__in=stat_items).values('dnszone')
            is_permission = False
            zone_id = long(zone_id)
            for dnsstatmaster in dnsstatmasters:
                if dnsstatmaster.get("dnszone") == zone_id:
                      is_permission = True
            if is_permission == False:
                raise Exception
            self.zone = DNSZone.active_locked_objects.get(customer=self.customer, zone_id=zone_id,
                                                        dnsstatmaster__statmaster__material_no__in=get_has_material(self.request.session['user_priv']),
                                                        )
            if self.zone.obj_state == __READONLY_ZONE_STATE__:
                self.readonly = True

            if not self.zone.is_modifiable():
                self.push_wait = True

        except Exception, e:
            raise Exception(_('Domain does not exists'))

    def is_permitted(self, operation_type):
        allow_operation = False
        try:
            zone_product = self.zone.dnsstatmaster_set.all()[0].statmaster.material_no

            for user_priv in self.request.session['user_priv']:
                if user_priv in CDNS_PERMISSION[zone_product][operation_type]:
                    allow_operation = True
                    break
        except:
            # if zone hasn't product(cdns or cdns-d) type. raise error.
            raise Exception(_(u"This domain hasn't product type. Please contact CDNetworks technical supports."))

        return allow_operation

    def create_records(self, record_type=None):
        params = getOptionalParams(self.request)
        raw_data = params.get('records')
        cleanup_data = {}

        if self.readonly:
            raise Exception(WARN_READONLY_DOMAIN)

        if self.push_wait:
            raise Exception(WARN_DOMAIN_LOCKED)

        if self.is_permitted(__CREATE_OPERATION_METHOD__):
            pass
        else:
            raise Exception(_(u"You do not have permission to create a record."))

        if raw_data:
            try:
                data = simplejson.loads(raw_data.replace("'", "\""))
            except Exception, e:
                raise Exception(_('Your request is invalid. Please check your request URI and input values.'))
        else:
            raise Exception(_('You missed request parameters. Please check your input values.'))

        for item in data:
            if record_type:
                if item.get('record_type') == record_type:
                    pass
                else:
                    item['record_type'] = record_type
            else:
                if item.get('record_type') is None:
                    raise Exception(_(u'You should input record type'))

            input_record_type = item['record_type']
            valid_data = None

            if input_record_type in DNS_SUPPORT_RECORD_TYPE:
                pass
            else:
                # invalid record_type
                raise Exception(_('Unsupported DNS Record type'))

            try:
                if item['ttl']:
                    ttl = item['ttl']
                else:
                    ttl = None
            except:
                ttl = None

            if input_record_type == __DNS_RECORD_NS__:
                ns_form = DNSNSForm({
                        'ns_host_name' : item.get('host_name'),
                        'ns_nameserver' : item.get('value'),
                        'ns_ttl' : ttl
                    },
                    request=self.request,
                    zone_id=self.zone.pk,)

                if ns_form.is_valid():
                    valid_data = ns_form.cleaned_data
                else:
                    if ns_form.errors.keys().__len__() > 0:
                        error_key = ns_form.errors.keys()[0]
                        error_msg = ns_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (NS)'))

            elif input_record_type == __DNS_RECORD_A__:
                a_form = DNSAForm({
                        'a_host_name' : item.get('host_name'),
                        'a_ip' : item.get('value'),
                        'a_ttl' : ttl
                    },
                    request=self.request,
                    zone_id=self.zone.pk)

                if a_form.is_valid():
                    valid_data = a_form.cleaned_data
                else:
                    if a_form.errors.keys().__len__() > 0:
                        error_key = a_form.errors.keys()[0]
                        error_msg = a_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (A)'))
            elif input_record_type == __DNS_RECORD_AAAA__:
                aaaa_form = DNSAAAAForm({
                        'aaaa_host_name' : item.get('host_name'),
                        'aaaa_ipv6' : item.get('value'),
                        'aaaa_ttl' : ttl
                    },
                    request=self.request,
                    zone_id=self.zone.pk,)
                if aaaa_form.is_valid():
                    valid_data = aaaa_form.cleaned_data
                else:
                    if aaaa_form.errors.keys().__len__() > 0:
                        error_key = aaaa_form.errors.keys()[0]
                        error_msg = aaaa_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (AAAA)'))
            elif input_record_type == __DNS_RECORD_CNAME__:
                cname_form = DNSCNAMEForm({
                        'cname_host_name' : item.get('host_name'),
                        'cname_canonical' : item.get('value'),
                        'cname_ttl': ttl
                    },
                    request=self.request,
                    zone_id=self.zone.pk,)
                if cname_form.is_valid():
                    valid_data = cname_form.cleaned_data
                else:
                    if cname_form.errors.keys().__len__() > 0:
                        error_key = cname_form.errors.keys()[0]
                        error_msg = cname_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (CNAME)'))
            elif input_record_type == __DNS_RECORD_RCNAME__:
                rcname_form = DNSResolveCNAMEForm({
                        'cname_host_name' : item.get('host_name'),
                        'cname_canonical' : item.get('value')
                    },
                    request=self.request,
                    zone_id=self.zone.pk,)
                if rcname_form.is_valid():
                    valid_data = rcname_form.cleaned_data
                else:
                    if rcname_form.errors.keys().__len__() > 0:
                        error_key = rcname_form.errors.keys()[0]
                        error_msg = rcname_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (RCNAME)'))
            elif input_record_type == __DNS_RECORD_MX__:
                mx_form = DNSMXForm({
                    'mx_host_name' : item.get('host_name'),
                    'mx_mail_server' : item.get('value'),
                    'mx_ttl' :  ttl,
                    'mx_preference' : item.get('data')
                    },
                    request=self.request,
                    zone_id=self.zone.pk,)

                if mx_form.is_valid():
                    valid_data = mx_form.cleaned_data
                else:
                    if mx_form.errors.keys().__len__() > 0:
                        error_key = mx_form.errors.keys()[0]
                        error_msg = mx_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (MX)'))
            elif input_record_type == __DNS_RECORD_TXT__:
                txt_form = DNSTXTForm({
                        'txt_host_name' : item.get('host_name'),
                        'txt_text' : item.get('value'),
                        'txt_ttl' : ttl
                    },
                    request=self.request,
                    zone_id=self.zone.pk,)
                if txt_form.is_valid():
                    valid_data = txt_form.cleaned_data
                else:
                    if txt_form.errors.keys().__len__() > 0:
                        error_key = txt_form.errors.keys()[0]
                        error_msg = txt_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (TXT)'))
            elif input_record_type == __DNS_RECORD_PTR__:
                ptr_form = DNSPTRForm({
                        'ptr_host_name' : item.get('host_name'),
                        'ptr_name' : item.get('value'),
                        'ptr_ttl' : ttl
                    },
                    request=self.request,
                    zone_id=self.zone.pk,)
                if ptr_form.is_valid():
                    valid_data = ptr_form.cleaned_data
                else:
                    if ptr_form.errors.keys().__len__() > 0:
                        error_key = ptr_form.errors.keys()[0]
                        error_msg = ptr_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (PTR)'))
            elif input_record_type == __DNS_RECORD_SRV__:
                srv_form = DNSSRVForm({
                        'srv_host_name' : item.get('host_name'),
                        "srv_priority" : item.get('priority'),
                        "srv_weight" : item.get('weight'),
                        "srv_port" : item.get('port'),
                        "srv_target" : item.get('target'),
                        'srv_ttl' : ttl

                    },
                    request=self.request,
                    zone_id=self.zone.pk,)
                if srv_form.is_valid():
                    valid_data = srv_form.cleaned_data
                else:
                    if srv_form.errors.keys().__len__() > 0:
                        error_key = srv_form.errors.keys()[0]
                        error_msg = srv_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (SRV)'))
            elif input_record_type == __DNS_RECORD_SPF__:
                spf_form = DNSSPFForm({
                        'spf_host_name' : item.get('host_name'),
                        'spf_text' : item.get('value'),
                        'spf_ttl' : ttl
                    },
                    request=self.request,
                    zone_id=self.zone.pk,)
                if spf_form.is_valid():
                    valid_data = spf_form.cleaned_data
                else:
                    if spf_form.errors.keys().__len__() > 0:
                        error_key = spf_form.errors.keys()[0]
                        error_msg = spf_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (SPF)'))
            elif input_record_type == __DNS_RECORD_RP__:
                rp_form = DNSRPForm({
                        'rp_host_name' : item.get('host_name'),
                        'rp_mailbox_name' : item.get('mailbox_name'),
                        'rp_domain_name' : item.get('domain_name'),
                        'rp_ttl' : ttl
                    },
                    request=self.request,
                    zone_id=self.zone.pk,)
                if rp_form.is_valid():
                    valid_data = rp_form.cleaned_data
                else:
                    if rp_form.errors.keys().__len__() > 0:
                        error_key = rp_form.errors.keys()[0]
                        error_msg = rp_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (RP)'))
            else:
                pass

            try:
                cleanup_data[input_record_type].append(valid_data)
            except:
                cleanup_data[input_record_type] = [valid_data]

        records = {}
        for record_key in cleanup_data.keys():
            try:
                for cleaned_data in cleanup_data[record_key]:
                    record = {}
                    record_data = None
                    if record_key == __DNS_RECORD_NS__:
                        record_data = DNSNs(zone=self.zone,
                                                    host_name=cleaned_data['ns_host_name'],
                                                    name_server=cleaned_data['ns_nameserver'],
                                                    ttl=cleaned_data['ns_ttl'])
                        record_data.save(request=self.request)
                    elif record_key == __DNS_RECORD_A__:
                        record_data = DNSA(zone=self.zone,
                                        host_name=cleaned_data['a_host_name'],
                                        ip=cleaned_data['a_ip'],
                                        ttl=cleaned_data['a_ttl'])
                        record_data.save(request=self.request)
                    elif record_key == __DNS_RECORD_AAAA__:
                        record_data = DNSAaaa(zone=self.zone,
                                                    host_name=cleaned_data['aaaa_host_name'],
                                                    ipv6=cleaned_data['aaaa_ipv6'],
                                                    ttl=cleaned_data['aaaa_ttl'])
                        record_data.save(request=self.request)
                    elif record_key == __DNS_RECORD_CNAME__:
                        try:
                            dirty_record = DNSCname.all_objects.get(host_name=cleaned_data['cname_host_name'], zone=self.zone)
                        except:
                            dirty_record = None

                        if dirty_record:
                            record_data = dirty_record
                            record_data.host_name = cleaned_data['cname_host_name']
                            record_data.cname = set_dnszone_autofill(self.zone.pk, cleaned_data['cname_canonical'])
                            record_data.ttl = cleaned_data['cname_ttl']
                            record_data.obj_state = 1
                        else:
                            record_data = DNSCname(zone=self.zone,
                                                            host_name=cleaned_data['cname_host_name'],
                                                            cname=set_dnszone_autofill(self.zone.pk, cleaned_data['cname_canonical']),
                                                            ttl=cleaned_data['cname_ttl'])
                        record_data.save(request=self.request)
                    elif record_key == __DNS_RECORD_RCNAME__:
                        try:
                            dirty_record = DNSResolveCname.all_objects.get(host_name=cleaned_data['cname_host_name'], zone=self.zone)
                        except:
                            dirty_record = None

                        if dirty_record:
                            record_data = dirty_record
                            record_data.host_name = cleaned_data['cname_host_name']
                            record_data.cname = set_dnszone_autofill(self.zone.pk, cleaned_data['cname_canonical'])
                            record_data.obj_state = 1
                        else:
                            record_data = DNSResolveCname(zone=self.zone,
                                                            host_name=cleaned_data['cname_host_name'],
                                                            cname=set_dnszone_autofill(self.zone.pk, cleaned_data['cname_canonical']))
                        record_data.save(request=self.request)
                    elif record_key == __DNS_RECORD_MX__:
                        if cleaned_data['mx_preference'] is not None:
                            record_data = DNSMx(zone=self.zone,
                                            host_name=cleaned_data['mx_host_name'],
                                            mail_server=set_dnszone_autofill(self.zone.pk, cleaned_data['mx_mail_server']),
                                            ttl=cleaned_data['mx_ttl'],
                                            preference=cleaned_data['mx_preference'])
                        else:
                            record_data = DNSMx(zone=self.zone,
                                            host_name=cleaned_data['mx_host_name'],
                                            mail_server=cleaned_data['mx_mail_server'],
                                            ttl=cleaned_data['mx_ttl'])
                        record_data.save(request=self.request)
                    elif record_key == __DNS_RECORD_TXT__:
                        record_data = DNSTxt(zone=self.zone,
                                            host_name=cleaned_data['txt_host_name'],
                                            text=cleaned_data['txt_text'],
                                            ttl=cleaned_data['txt_ttl'])
                        record_data.save(request=self.request)
                    elif record_key == __DNS_RECORD_PTR__:
                        record_data = DNSPtr(zone=self.zone,
                                            host_name=cleaned_data['ptr_host_name'],
                                            ptr_name=cleaned_data['ptr_name'],
                                            ttl=cleaned_data['ptr_ttl'])
                        record_data.save(request=self.request)
                    elif record_key == __DNS_RECORD_SRV__:
                        record_data = DNSSrv(zone=self.zone,
                                            host_name=cleaned_data['srv_host_name'],
                                            priority=cleaned_data['srv_priority'],
                                            weight=cleaned_data['srv_weight'],
                                            port=cleaned_data['srv_port'],
                                            target=cleaned_data['srv_target'],
                                            ttl=cleaned_data['srv_ttl'])
                        record_data.save(request=self.request)
                    elif record_key == __DNS_RECORD_SPF__:
                        record_data = DNSSpf(zone=self.zone,
                                            host_name=cleaned_data['spf_host_name'],
                                            text=cleaned_data['spf_text'],
                                            ttl=cleaned_data['spf_ttl'])
                        record_data.save(request=self.request)

                    elif record_key == __DNS_RECORD_RP__:
                        record_data = DNSRp(zone=self.zone,
                                            host_name=cleaned_data['rp_host_name'],
                                            mailbox_name=cleaned_data['rp_mailbox_name'],
                                            txt_domain_name=cleaned_data['rp_domain_name'],
                                            ttl=cleaned_data['rp_ttl'])
                        record_data.save(request=self.request)
                    else:
                        pass

                    if record_key == __DNS_RECORD_RCNAME__:
                        record = {
                            'domain_id' : self.zone.pk,
                            'record_id' : record_data.pk,
                            'name' : record_data.host_name,
                            'type' : record_key,
                            'value': None
                        }
                    else:
                        record = {
                            'domain_id' : self.zone.pk,
                            'record_id' : record_data.pk,
                            'name' : record_data.host_name,
                            'type' : record_key,
                            'value': None,
                            'ttl' : record_data.ttl
                        }

                    if record_key == __DNS_RECORD_NS__:
                        record['value'] = record_data.name_server
                    elif record_key == __DNS_RECORD_A__:
                        record['value'] = record_data.ip
                    elif record_key == __DNS_RECORD_AAAA__:
                        record['value'] = record_data.ipv6
                    elif record_key == __DNS_RECORD_CNAME__:
                        record['value'] = record_data.cname
                    elif record_key == __DNS_RECORD_RCNAME__:
                        record['value'] = record_data.cname
                    elif record_key == __DNS_RECORD_MX__:
                        record['value'] = record_data.mail_server
                        record['preference'] = record_data.preference
                    elif record_key == __DNS_RECORD_TXT__:
                        record['value'] = record_data.text
                    elif record_key == __DNS_RECORD_PTR__:
                        record['value'] = record_data.ptr_name
                    elif record_key == __DNS_RECORD_SRV__:
                        record['priority'] = record_data.priority
                        record['weight'] = record_data.weight
                        record['port'] = record_data.port
                        record['target'] = record_data.target
                    elif record_key == __DNS_RECORD_SPF__:
                        record['value'] = record_data.text
                    elif record_key == __DNS_RECORD_RP__:
                        record['mailbox_name'] = record_data.mailbox_name
                        record['domain_name'] = record_data.txt_domain_name
                    else:
                        pass

                    try:
                        records[record_key].append([record])
                    except:
                        records[record_key] = [record]
            except Exception, e:
                raise Exception(_('DNS Record create failed'))

        return records

    def get_records(self, record_type=None, record_id=None):
        params = getOptionalParams(self.request)
        filter_host = params.get('name', None)  # hostname
        filter_data = params.get('value', None)
        list_scale = params.get('limit', None)
        page = params.get('page', None)

        try:
            record_type = record_type.upper()
        except:
            record_type = None

        records = {}
        data = {}

        if record_type in DNS_SUPPORT_RECORD_TYPE:
            if record_type == __DNS_RECORD_SOA__:
                records[record_type] = DNSSoa.objects.filter(zone=self.zone, obj_state=1)
            elif record_type == __DNS_RECORD_NS__:
                records[record_type] = DNSNs.objects.filter(zone=self.zone, obj_state=1)
            elif record_type == __DNS_RECORD_A__:
                records[record_type] = DNSA.objects.filter(zone=self.zone, obj_state=1)
            elif record_type == __DNS_RECORD_AAAA__:
                records[record_type] = DNSAaaa.objects.filter(zone=self.zone, obj_state=1)
            elif record_type == __DNS_RECORD_CNAME__:
                records[record_type] = DNSCname.objects.filter(zone=self.zone, obj_state=1)
            elif record_type == __DNS_RECORD_RCNAME__:
                records[record_type] = DNSResolveCname.objects.filter(zone=self.zone, obj_state=1)
            elif record_type == __DNS_RECORD_MX__:
                records[record_type] = DNSMx.objects.filter(zone=self.zone, obj_state=1)
            elif record_type == __DNS_RECORD_TXT__:
                records[record_type] = DNSTxt.objects.filter(zone=self.zone, obj_state=1)
            elif record_type == __DNS_RECORD_PTR__:
                records[record_type] = DNSPtr.objects.filter(zone=self.zone, obj_state=1)
            elif record_type == __DNS_RECORD_SRV__:
                records[record_type] = DNSSrv.objects.filter(zone=self.zone, obj_state=1)
            elif record_type == __DNS_RECORD_SPF__:
                records[record_type] = DNSSpf.objects.filter(zone=self.zone, obj_state=1)
            elif record_type == __DNS_RECORD_RP__:
                records[record_type] = DNSRp.objects.filter(zone=self.zone, obj_state=1)
            else:
                pass

            if record_id:
                try:
                    records[record_type] = records[record_type].filter(pk=record_id)
                except Exception, e:
                    raise Exception(_('Insert values are not correct. please check input parameters (NS)'))

        elif record_type is None:
            # soa
            records[__DNS_RECORD_SOA__] = DNSSoa.objects.filter(zone=self.zone, obj_state=1)
            # ns
            records[__DNS_RECORD_NS__] = DNSNs.objects.filter(zone=self.zone, obj_state=1)
            # a
            records[__DNS_RECORD_A__] = DNSA.objects.filter(zone=self.zone, obj_state=1)
            # aaaa
            records[__DNS_RECORD_AAAA__] = DNSAaaa.objects.filter(zone=self.zone, obj_state=1)
            # cname
            records[__DNS_RECORD_CNAME__] = DNSCname.objects.filter(zone=self.zone, obj_state=1)
            # rcname
            records[__DNS_RECORD_RCNAME__] = DNSResolveCname.objects.filter(zone=self.zone, obj_state=1)
            # mx
            records[__DNS_RECORD_MX__] = DNSMx.objects.filter(zone=self.zone, obj_state=1)
            # txt
            records[__DNS_RECORD_TXT__] = DNSTxt.objects.filter(zone=self.zone, obj_state=1)
            # ptr
            records[__DNS_RECORD_PTR__] = DNSPtr.objects.filter(zone=self.zone, obj_state=1)
            # svr
            records[__DNS_RECORD_SRV__] = DNSSrv.objects.filter(zone=self.zone, obj_state=1)
            # spf
            records[__DNS_RECORD_SPF__] = DNSSpf.objects.filter(zone=self.zone, obj_state=1)
            # rp
            records[__DNS_RECORD_RP__] = DNSRp.objects.filter(zone=self.zone, obj_state=1)

        else:
            raise Exception(_('Unsupported DNS Record type'))

        # filter records
        for record_type_key in records.keys():
            record_set = records[record_type_key]
            # filter
            if record_type_key == __DNS_RECORD_SOA__:
                if filter_host or filter_data:
                    record_set = []
            else:

                if filter_host:
                    record_set = record_set.filter(host_name__icontains=filter_host)

                if filter_data:
                    if record_type_key == __DNS_RECORD_NS__:
                        record_set = record_set.filter(name_server__icontains=filter_data)
                    elif record_type_key == __DNS_RECORD_A__:
                        record_set = record_set.filter(ip=filter_data)
                    elif record_type_key == __DNS_RECORD_AAAA__:
                        record_set = record_set.filter(ipv6=filter_data)
                    elif record_type_key == __DNS_RECORD_CNAME__:
                        record_set = record_set.filter(cname__icontains=filter_data)
                    elif record_type_key == __DNS_RECORD_RCNAME__:
                        record_set = record_set.filter(cname__icontains=filter_data)
                    elif record_type_key == __DNS_RECORD_MX__:
                        record_set = record_set.filter(mail_server__icontains=filter_data)
                    elif record_type_key == __DNS_RECORD_TXT__:
                        record_set = record_set.filter(text__icontains=filter_data)
                    elif record_type == __DNS_RECORD_PTR__:
                        record_set = record_set.filter(ptr_name__icontains=filter_data)
                    elif record_type == __DNS_RECORD_SRV__:
                        record_set = record_set.filter(target__icontains=filter_data)
                    elif record_type == __DNS_RECORD_SPF__:
                        record_set = record_set.filter(text__icontains=filter_data)
                    elif record_type == __DNS_RECORD_RP__:
                        record_set = record_set.filter(Q(txt_domain_name__icontains=filter_data) | Q(mailbox_name__icontains=filter_data))
                    else:
                        pass
            # paging
            for record_data in record_set:
                record = {}
                if record_type_key == __DNS_RECORD_SOA__:
                    record = {
                        'domain_id' : self.zone.pk,
                        'record_id' : record_data.pk,
                        'type' : record_type_key,
                        'value': None,
                        'ttl' : record_data.ttl
                    }
                elif record_type_key == __DNS_RECORD_RCNAME__:
                    record = {
                        'domain_id' : self.zone.pk,
                        'record_id' : record_data.pk,
                        'name' : record_data.host_name,
                        'type' : record_type_key,
                        'value': None
                    }
                else:
                    record = {
                        'domain_id' : self.zone.pk,
                        'record_id' : record_data.pk,
                        'name' : record_data.host_name,
                        'type' : record_type_key,
                        'value': None,
                        'ttl' : record_data.ttl
                    }

                if record_type_key == __DNS_RECORD_SOA__:
                    record['value'] = record_data.name_server
                    record['email'] = record_data.email
                    record['class'] = record_data.class_name
                    record['serial_number'] = record_data.serial_number
                    record['serial_format'] = record_data.serial_format
                    record['refresh'] = record_data.refresh
                    record['retry'] = record_data.retry
                    record['expire'] = record_data.expire
                    record['minmum'] = record_data.minimum

                elif record_type_key == __DNS_RECORD_NS__:
                    record['value'] = record_data.name_server
                elif record_type_key == __DNS_RECORD_A__:
                    record['value'] = record_data.ip
                elif record_type_key == __DNS_RECORD_AAAA__:
                    record['value'] = record_data.ipv6
                elif record_type_key == __DNS_RECORD_CNAME__:
                    record['value'] = record_data.cname
                elif record_type_key == __DNS_RECORD_RCNAME__:
                    record['value'] = record_data.cname
                elif record_type_key == __DNS_RECORD_MX__:
                    record['value'] = record_data.mail_server
                    record['preference'] = record_data.preference
                elif record_type_key == __DNS_RECORD_TXT__:
                    record['value'] = record_data.text
                elif record_type_key == __DNS_RECORD_PTR__:
                    record['value'] = record_data.ptr_name
                elif record_type_key == __DNS_RECORD_SRV__:
                    record['priority'] = record_data.priority
                    record['weight'] = record_data.weight
                    record['port'] = record_data.port
                    record['target'] = record_data.target
                elif record_type_key == __DNS_RECORD_SPF__:
                    record['value'] = record_data.text
                elif record_type_key == __DNS_RECORD_RP__:
                    record['mailbox_name'] = record_data.mailbox_name
                    record['domain_name'] = record_data.txt_domain_name
                else:
                    continue

                try:
                    data[record_type_key].append(record)
                except:
                    data[record_type_key] = [record]

        return data

    def update_records(self, record_type=None, record_id=None):
        params = getOptionalParams(self.request)
        raw_data = params.get('records')
        cleanup_data = {}

        if self.readonly:
            raise Exception(WARN_READONLY_DOMAIN)

        if self.push_wait:
            raise Exception(WARN_DOMAIN_LOCKED)

        if self.is_permitted(__UPDATE_OPERATION_METHOD__):
            pass
        else:
            raise Exception(_(u"You do not have permission to update the record."))

        if raw_data:
            try:
                data = simplejson.loads(raw_data.replace("'", "\""))
            except Exception, e:
                raise Exception(_('Your request is invalid. Please check your request URI and input values.'))
        else:
            raise Exception(_('You missed request parameters. Please check your input values.'))

        for item in data:
            if record_type:
                if item.get('record_type') == record_type:
                    pass
                else:
                    item['record_type'] = record_type
            else:
                if item.get('record_type') is None:
                    raise Exception(_(u'You should input record type'))

            if record_id:
                # shoude define record type
                item['record_id'] = record_id
            else:
                if item.get('record_id'):
                    pass
                else:
                    raise Exception(_('You missed record id what you want to update. Please check your input values.'))
                    break

            input_record_type = item['record_type']
            valid_data = None

            if input_record_type in DNS_SUPPORT_RECORD_TYPE:
                pass
            else:
                # invalid record_type
                raise Exception(_('Unsupported DNS Record type'))

            try:
                if item['ttl']:
                    ttl = item['ttl']
                else:
                    ttl = None
            except:
                ttl = None

            if input_record_type == __DNS_RECORD_SOA__:
                if settings.PROJECT_NAME == 'prism_fe':
                    soa_context = {
                            'soa_nameserver' : item.get('host_name'),
                            'soa_email' : item.get('value'),
                            'soa_ttl' : ttl,
                            }

                    soa_model = self.zone.dnssoa
                    if soa_model.serial_format == 2:  # manual serial format
                        soa_context['soa_serial_num'] = item.get('data')
                    soa_form = DNSSOAForm(soa_context)
                else:
                    soa_form = DNSSOAForm({'soa_ttl':ttl,
                                        'soa_email':item.get('value')})

                if not soa_form.errors.get('soa_ttl') \
                    and not soa_form.errors.get('soa_email') \
                    and not ((soa_form.errors.get('soa_serial_num') \
                        if (settings.PROJECT_NAME == 'prism_fe' and soa_model.serial_format == 2) else False)) \
                    and not ((soa_form.errors.get('soa_nameserver') \
                        if settings.PROJECT_NAME == 'prism_fe' else False)):
                    valid_data = {}
                    valid_data['soa_ttl'] = ttl
                    valid_data['soa_email'] = item.get('value').strip()
                    valid_data['pk'] = long(item['record_id'])
                else:
                    if soa_form.errors.keys().__len__() > 0:
                        error_keys = soa_form.errors.keys()
                        if 'soa_email' in error_keys:
                            error_msg = soa_form.errors.get('soa_email').as_text().strip("*")
                        elif 'soa_ttl' in error_keys:
                            error_msg = soa_form.errors.get('soa_ttl').as_text().strip("*")
                        else:
                            error_msg = _('Insert values are not correct. please check input parameters (SOA)')
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (SOA)'))
            elif input_record_type == __DNS_RECORD_NS__:
                ns_form = DNSNSForm({
                        'ns_host_name' : item.get('host_name'),
                        'ns_nameserver' : item.get('value'),
                        'ns_ttl' : ttl,
                    },
                    request=self.request,
                    zone_id=self.zone.pk,
                    pk=item['record_id'])

                if ns_form.is_valid():
                    valid_data = ns_form.cleaned_data
                else:
                    if ns_form.errors.keys().__len__() > 0:
                        error_key = ns_form.errors.keys()[0]
                        error_msg = ns_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (NS)'))
            elif input_record_type == __DNS_RECORD_A__:
                a_form = DNSAForm({
                        'a_host_name' : item.get('host_name'),
                        'a_ip' : item.get('value'),
                        'a_ttl' : ttl
                    },
                    request=self.request,
                    zone_id=self.zone.pk,
                    pk=item['record_id'])
                if a_form.is_valid():
                    valid_data = a_form.cleaned_data
                else:
                    if a_form.errors.keys().__len__() > 0:
                        error_key = a_form.errors.keys()[0]
                        error_msg = a_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (A)'))

            elif input_record_type == __DNS_RECORD_AAAA__:
                aaaa_form = DNSAAAAForm({
                        'aaaa_host_name' : item.get('host_name'),
                        'aaaa_ipv6' : item.get('value'),
                        'aaaa_ttl' : ttl
                    },
                    request=self.request,
                    zone_id=self.zone.pk,
                    pk=item['record_id'])
                if aaaa_form.is_valid():
                    valid_data = aaaa_form.cleaned_data
                else:
                    if aaaa_form.errors.keys().__len__() > 0:
                        error_key = aaaa_form.errors.keys()[0]
                        error_msg = aaaa_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (AAAA)'))
            elif input_record_type == __DNS_RECORD_CNAME__:
                cname_form = DNSCNAMEForm({
                        'cname_host_name' : item.get('host_name'),
                        'cname_canonical' : item.get('value'),
                        'cname_ttl': ttl
                    },
                    request=self.request,
                    zone_id=self.zone.pk,
                    pk=item['record_id'])
                if cname_form.is_valid():
                    valid_data = cname_form.cleaned_data
                else:
                    if cname_form.errors.keys().__len__() > 0:
                        error_key = cname_form.errors.keys()[0]
                        error_msg = cname_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (CNAME)'))
            elif input_record_type == __DNS_RECORD_RCNAME__:
                rcname_form = DNSResolveCNAMEForm({
                        'cname_host_name' : item.get('host_name'),
                        'cname_canonical' : item.get('value')
                    },
                    request=self.request,
                    zone_id=self.zone.pk,
                    pk=item['record_id'])
                if rcname_form.is_valid():
                    valid_data = rcname_form.cleaned_data
                else:
                    if rcname_form.errors.keys().__len__() > 0:
                        error_key = rcname_form.errors.keys()[0]
                        error_msg = rcname_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (CNAME)'))
            elif input_record_type == __DNS_RECORD_MX__:
                mx_form = DNSMXForm({
                    'mx_host_name' : item.get('host_name'),
                    'mx_mail_server' : item.get('value'),
                    'mx_ttl' :  ttl,
                    'mx_preference' : item.get('data')
                    },
                    request=self.request,
                    zone_id=self.zone.pk,
                    pk=item['record_id'])

                if mx_form.is_valid():
                    valid_data = mx_form.cleaned_data
                else:
                    if mx_form.errors.keys().__len__() > 0:
                        error_key = mx_form.errors.keys()[0]
                        error_msg = mx_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (MX)'))
            elif input_record_type == __DNS_RECORD_TXT__:
                txt_form = DNSTXTForm({
                        'txt_host_name' : item.get('host_name'),
                        'txt_text' : item.get('value'),
                        'txt_ttl' : ttl
                    },
                    request=self.request,
                    zone_id=self.zone.pk,
                    pk=item['record_id'])
                if txt_form.is_valid():
                    valid_data = txt_form.cleaned_data
                else:
                    if txt_form.errors.keys().__len__() > 0:
                        error_key = txt_form.errors.keys()[0]
                        error_msg = txt_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (TXT)'))
            elif input_record_type == __DNS_RECORD_PTR__:
                ptr_form = DNSPTRForm({
                        'ptr_host_name' : item.get('host_name'),
                        'ptr_name' : item.get('value'),
                        'ptr_ttl' : ttl
                    },
                    request=self.request,
                    zone_id=self.zone.pk,
                    pk=item['record_id'])
                if ptr_form.is_valid():
                    valid_data = ptr_form.cleaned_data
                else:
                    if ptr_form.errors.keys().__len__() > 0:
                        error_key = ptr_form.errors.keys()[0]
                        error_msg = ptr_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (PTR)'))
            elif input_record_type == __DNS_RECORD_SRV__:
                srv_form = DNSSRVForm({
                        'srv_host_name' : item.get('host_name'),
                        "srv_priority" : item.get('priority'),
                        "srv_weight" : item.get('weight'),
                        "srv_port" : item.get('port'),
                        "srv_target" : item.get('target'),
                        'srv_ttl' : ttl
                    },
                    request=self.request,
                    zone_id=self.zone.pk,
                    pk=item['record_id'])
                if srv_form.is_valid():
                    valid_data = srv_form.cleaned_data
                else:
                    if srv_form.errors.keys().__len__() > 0:
                        error_key = srv_form.errors.keys()[0]
                        error_msg = srv_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (SRV)'))
            elif input_record_type == __DNS_RECORD_SPF__:
                spf_form = DNSSPFForm({
                        'spf_host_name' : item.get('host_name'),
                        'spf_text' : item.get('value'),
                        'spf_ttl' : ttl
                    },
                    request=self.request,
                    zone_id=self.zone.pk,
                    pk=item['record_id'])
                if spf_form.is_valid():
                    valid_data = spf_form.cleaned_data
                else:
                    if spf_form.errors.keys().__len__() > 0:
                        error_key = spf_form.errors.keys()[0]
                        error_msg = spf_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (SPF)'))
            elif input_record_type == __DNS_RECORD_RP__:
                rp_form = DNSRPForm({
                        'rp_host_name' : item.get('host_name'),
                        'rp_mailbox_name' : item.get('mailbox_name'),
                        'rp_domain_name' : item.get('domain_name'),
                        'rp_ttl' : ttl
                    },
                    request=self.request,
                    zone_id=self.zone.pk,
                    pk=item['record_id'])
                if rp_form.is_valid():
                    valid_data = rp_form.cleaned_data
                else:
                    if rp_form.errors.keys().__len__() > 0:
                        error_key = rp_form.errors.keys()[0]
                        error_msg = rp_form.errors[error_key].as_text().strip("*")
                        raise Exception(_('%s' % error_msg))
                    else:
                        raise Exception(_('Insert values are not correct. please check input parameters (RP)'))
            else:
                pass

            try:
                valid_data.update({'pk':item['record_id']})
                cleanup_data[input_record_type].append(valid_data)
            except:
                cleanup_data[input_record_type] = [valid_data]

        records = {}
        for record_key in cleanup_data.keys():
            for cleaned_data in cleanup_data[record_key]:
                record = {}
                record_data = None
                if record_key == __DNS_RECORD_SOA__:
                    try:
                        record_data = DNSSoa.objects.get(zone=self.zone, pk=cleaned_data['pk'])
                        record_data.email = cleaned_data['soa_email']
                        record_data.ttl = cleaned_data['soa_ttl']
                        if self.zone.dnssoa.serial_format == __SERIAL_FORMAT_MANUAL__ and settings.PROJECT_NAME == 'prism_fe':
                            record_data.serial_number = cleaned_data['soa_serial_num']
                        record_data.save(request=self.request)
                    except:
                        raise Exception(_('DNS Record update failed(SOA)'))
                elif record_key == __DNS_RECORD_NS__:
                    try:
                        record_data = DNSNs.objects.get(zone=self.zone, pk=cleaned_data['pk'])
                        if getattr(settings, 'PROJECT_NAME', 'aurora_api') == 'aurora_api':
                            if record_data.is_default_ns():
                                raise DefaultNSNotEditable

                        record_data.host_name = cleaned_data['ns_host_name']
                        record_data.name_server = cleaned_data['ns_nameserver']
                        record_data.ttl = cleaned_data['ns_ttl']
                        record_data.save(request=self.request)
                    except DNSNs.DoesNotExist:
                        raise Exception(_('You access not available record (NS)'))
                    except DefaultNSNotEditable:
                        raise Exception(MSG_DEFAULT_NS_LOCKED)
                    except:
                        raise Exception(_('DNS Record update failed(NS)'))
                elif record_key == __DNS_RECORD_A__:
                    try:
                        record_data = DNSA.objects.get(zone=self.zone, pk=cleaned_data['pk'])
                        record_data.host_name = cleaned_data['a_host_name']
                        record_data.ip = cleaned_data['a_ip']
                        record_data.ttl = cleaned_data['a_ttl']
                        record_data.save(request=self.request)
                    except DNSA.DoesNotExist:
                        raise Exception(_('You access not available record (A)'))
                    except:
                        raise Exception(_('DNS Record update failed(A)'))
                elif record_key == __DNS_RECORD_AAAA__:
                    try:
                        record_data = DNSAaaa.objects.get(zone=self.zone, pk=cleaned_data['pk'])
                        record_data.host_name = cleaned_data['aaaa_host_name']
                        record_data.ipv6 = cleaned_data['aaaa_ipv6']
                        record_data.ttl = cleaned_data['aaaa_ttl']
                        record_data.save(request=self.request)
                    except DNSAaaa.DoesNotExist:
                        raise Exception(_('You access not available record (AAAA)'))
                    except:
                        raise Exception(_('DNS Record update failed(AAAA)'))
                elif record_key == __DNS_RECORD_CNAME__:
                    try:
                        try:
                            dirty_record = DNSCname.all_objects.get(host_name=cleaned_data['cname_host_name'], zone=self.zone)
                        except:
                            dirty_record = None

                        if dirty_record and dirty_record.obj_state == 0:
                            record_data = dirty_record
                            record_data.host_name = self.zone.pk, cleaned_data['cname_host_name']
                            record_data.cname = set_dnszone_autofill(self.zone.pk, cleaned_data['cname_canonical'])
                            record_data.ttl = cleaned_data['cname_ttl']
                            record_data.obj_state = 1
                        else:
                            record_data = DNSCname.objects.get(zone=self.zone, pk=cleaned_data['pk'])
                            record_data.host_name = cleaned_data['cname_host_name']
                            record_data.cname = set_dnszone_autofill(self.zone.pk, cleaned_data['cname_canonical'])
                            record_data.ttl = cleaned_data['cname_ttl']

                        record_data.save(request=self.request)
                    except DNSCname.DoesNotExist:
                        raise Exception(_('You access not available record (CNAME)'))
                    except:
                        raise Exception(_('DNS Record update failed(CNAME)'))
                elif record_key == __DNS_RECORD_RCNAME__:
                    try:
                        try:
                            dirty_record = DNSResolveCname.all_objects.get(host_name=cleaned_data['cname_host_name'], zone=self.zone)
                        except:
                            dirty_record = None

                        if dirty_record and dirty_record.obj_state == 0:
                            record_data = dirty_record
                            record_data.host_name = self.zone.pk, cleaned_data['cname_host_name']
                            record_data.cname = set_dnszone_autofill(self.zone.pk, cleaned_data['cname_canonical'])
                            record_data.obj_state = 1
                        else:
                            record_data = DNSResolveCname.objects.get(zone=self.zone, pk=cleaned_data['pk'])
                            record_data.host_name = cleaned_data['cname_host_name']
                            record_data.cname = set_dnszone_autofill(self.zone.pk, cleaned_data['cname_canonical'])

                        record_data.save(request=self.request)
                    except DNSResolveCname.DoesNotExist:
                        raise Exception(_('You access not available record (CNAME)'))
                    except:
                        raise Exception(_('DNS Record update failed(CNAME)'))
                elif record_key == __DNS_RECORD_MX__:
                    try:
                        record_data = DNSMx.objects.get(zone=self.zone, pk=cleaned_data['pk'])
                        record_data.host_name = cleaned_data['mx_host_name']
                        record_data.mail_server = set_dnszone_autofile(self.zone.pk, cleaned_data['mx_mail_server'])
                        record_data.ttl = cleaned_data['mx_ttl']
                        if cleaned_data['mx_preference'] is not None:
                            record_data.preference = cleaned_data['mx_preference']
                        else:
                            record_data.preference = record_data._meta.get_field_by_name('preference')[0].get_default()
                        record_data.save(request=self.request)
                    except DNSMx.DoesNotExist:
                        raise Exception(_('You access not available record (MX)'))
                    except:
                        raise Exception(_('DNS Record update failed(MX)'))
                elif record_key == __DNS_RECORD_TXT__:
                    try:
                        record_data = DNSTxt.objects.get(zone=self.zone, pk=cleaned_data['pk'])
                        record_data.host_name = cleaned_data['txt_host_name']
                        record_data.text = cleaned_data['txt_text']
                        record_data.ttl = cleaned_data['txt_ttl']
                        record_data.save(request=self.request)
                    except DNSTxt.DoesNotExist:
                        raise Exception(_('You access not available record (Txt)'))
                    except:
                        raise Exception(_('DNS Record update failed(TXT)'))
                elif record_key == __DNS_RECORD_PTR__:
                    try:
                        record_data = DNSPtr.objects.get(zone=self.zone, pk=cleaned_data['pk'])
                        record_data.host_name = cleaned_data['ptr_host_name']
                        record_data.ptr_name = cleaned_data['ptr_name']
                        record_data.ttl = cleaned_data['ptr_ttl']
                        record_data.save(request=self.request)
                    except DNSPtr.DoesNotExist:
                        raise Exception(_('You access not available record (PTR)'))
                    except:
                        raise Exception(_('DNS Record update failed(PTR)'))
                elif record_key == __DNS_RECORD_SRV__:
                    try:
                        record_data = DNSSrv.objects.get(zone=self.zone, pk=cleaned_data['pk'])
                        record_data.host_name = cleaned_data['srv_host_name']
                        record_data.priority = cleaned_data['srv_priority']
                        record_data.weight = cleaned_data['srv_weight']
                        record_data.port = cleaned_data['srv_port']
                        record_data.target = cleaned_data['srv_target']
                        record_data.ttl = cleaned_data['srv_ttl']
                        record_data.save(request=self.request)
                    except DNSSrv.DoesNotExist:
                        raise Exception(_('You access not available record (SRV)'))
                    except:
                        raise Exception(_('DNS Record update failed(SRV)'))
                elif record_key == __DNS_RECORD_SPF__:
                    try:
                        record_data = DNSSpf.objects.get(zone=self.zone, pk=cleaned_data['pk'])
                        record_data.host_name = cleaned_data['spf_host_name']
                        record_data.text = cleaned_data['spf_text']
                        record_data.ttl = cleaned_data['spf_ttl']
                        record_data.save(request=self.request)
                    except DNSSpf.DoesNotExist:
                        raise Exception(_('You access not available record (SPF)'))
                    except:
                        raise Exception(_('DNS Record update failed(SPF)'))

                elif record_key == __DNS_RECORD_RP__:
                    try:
                        record_data = DNSRp.objects.get(zone=self.zone, pk=cleaned_data['pk'])
                        record_data.host_name = cleaned_data['rp_host_name']
                        record_data.mailbox_name = cleaned_data['rp_mailbox_name']
                        record_data.txt_domain_name = cleaned_data['rp_domain_name']
                        record_data.ttl = cleaned_data['rp_ttl']
                        record_data.save(request=self.request)
                    except DNSRp.DoesNotExist:
                        raise Exception(_('You access not available record (RP)'))
                    except:
                        raise Exception(_('DNS Record update failed(RP)'))
                else:
                    pass

                if record_key == __DNS_RECORD_SOA__:
                    record = {
                        'domain_id' : self.zone.pk,
                        'record_id' : record_data.pk,
                        'name' : record_data.name_server,
                        'type' : record_key,
                        'value': None,
                        'ttl' : record_data.ttl
                    }
                elif record_key == __DNS_RECORD_RCNAME__:
                    record = {
                        'domain_id' : self.zone.pk,
                        'record_id' : record_data.pk,
                        'name' : record_data.host_name,
                        'type' : record_key,
                        'value': None
                    }
                else:
                    record = {
                        'domain_id' : self.zone.pk,
                        'record_id' : record_data.pk,
                        'name' : record_data.host_name,
                        'type' : record_key,
                        'value': None,
                        'ttl' : record_data.ttl
                    }

                if record_key == __DNS_RECORD_SOA__:
                    record['serial'] = record_data.serial_number
                    record['serial_format'] = record_data.serial_format
                    record['value'] = record_data.email
                elif record_key == __DNS_RECORD_NS__:
                    record['value'] = record_data.name_server
                elif record_key == __DNS_RECORD_A__:
                    record['value'] = record_data.ip
                elif record_key == __DNS_RECORD_AAAA__:
                    record['value'] = record_data.ipv6
                elif record_key == __DNS_RECORD_CNAME__:
                    record['value'] = record_data.cname
                elif record_key == __DNS_RECORD_RCNAME__:
                    record['value'] = record_data.cname
                elif record_key == __DNS_RECORD_MX__:
                    record['value'] = record_data.mail_server
                    record['preference'] = record_data.preference
                elif record_key == __DNS_RECORD_TXT__:
                    record['value'] = record_data.text
                elif record_key == __DNS_RECORD_PTR__:
                    record['value'] = record_data.ptr_name
                elif record_key == __DNS_RECORD_SRV__:
                    record['priority'] = record_data.priority
                    record['weight'] = record_data.weight
                    record['port'] = record_data.port
                    record['target'] = record_data.target
                elif record_key == __DNS_RECORD_SPF__:
                    record['value'] = record_data.text
                elif record_key == __DNS_RECORD_RP__:
                    record['mailbox_name'] = record_data.mailbox_name
                    record['domain_name'] = record_data.txt_domain_name
                else:
                    pass

                try:
                    records[record_key].append([record])
                except:
                    records[record_key] = [record]

        return records

    def delete_records(self, record_type, record_id):
        if self.readonly:
            raise Exception(WARN_READONLY_DOMAIN)

        if self.push_wait:
            raise Exception(WARN_DOMAIN_LOCKED)

        if self.is_permitted(__DELETE_OPERATION_METHOD__):
            pass
        else:
            raise Exception(_(u"You do not have permission to delete the record."))

        try:
            if record_type == __DNS_RECORD_NS__:
                record_data = DNSNs.objects.get(zone=self.zone, pk=record_id)
                if getattr(settings, 'PROJECT_NAME', 'aurora_api') == 'aurora_api':
                    if record_data.is_default_ns():
                        raise DefaultNSNotEditable
            elif record_type == __DNS_RECORD_A__:
                record_data = DNSA.objects.get(zone=self.zone, pk=record_id)
            elif record_type == __DNS_RECORD_AAAA__:
                record_data = DNSAaaa.objects.get(zone=self.zone, pk=record_id)
            elif record_type == __DNS_RECORD_CNAME__:
                record_data = DNSCname.objects.get(zone=self.zone, pk=record_id)
            elif record_type == __DNS_RECORD_RCNAME__:
                record_data = DNSResolveCname.objects.get(zone=self.zone, pk=record_id)
            elif record_type == __DNS_RECORD_MX__:
                record_data = DNSMx.objects.get(zone=self.zone, pk=record_id)
            elif record_type == __DNS_RECORD_TXT__:
                record_data = DNSTxt.objects.get(zone=self.zone, pk=record_id)
            elif record_type == __DNS_RECORD_PTR__:
                record_data = DNSPtr.objects.get(zone=self.zone, pk=record_id)
            elif record_type == __DNS_RECORD_SRV__:
                record_data = DNSSrv.objects.get(zone=self.zone, pk=record_id)
            elif record_type == __DNS_RECORD_SPF__:
                record_data = DNSSpf.objects.get(zone=self.zone, pk=record_id)
            elif record_type == __DNS_RECORD_RP__:
                record_data = DNSRp.objects.get(zone=self.zone, pk=record_id)
            else:
                raise Exception(_('Not support Record type.'))

            record_data.obj_state = 0
            record_data.save(request=self.request)

            return True
        except DefaultNSNotEditable:
            raise Exception(MSG_DEFAULT_NS_LOCKED)
            return False
        except Exception, e:
            raise Exception(_('Fail to delete DNS record'))
            return False
# exceptions
class DefaultNSNotEditable(Exception):
    pass


def set_dnszone_autofill(zone_id, name):
    """
    DNS Zone Domain Name Autofill Function

    This code from spectrum_fe.views.dns_zone.set_dnszone_autofill
    """
    autofill_name = ""
    try:
        if name.endswith('.'):
            autofill_name = name[:-1]
        else:
            if zone_id:
                dns_zone = DNSZone.objects.get(pk=zone_id)
                if dns_zone:
                    autofill_name = name + '.' + dns_zone.domain_name
    except:
        autofill_name = name
    return autofill_name
