import os

if os.environ.get('DJANGO_SETTINGS_MODULE') is None:
    os.environ['DJANGO_SETTINGS_MODULE'] = 'aurora_fe.settings'

import unittest2 as unittest
from django.contrib.auth.models import User
from aurora_fe.email_report.email_tools import make_custom_chart_option


class TestEmailReport(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_make_custom_chart_option_func_when_stat_item_cd_is_STAT_IC_HITS_and_one_series(self):
        """

        Description: To test  make_custom_chart_option() with stat_item_cd which is already in allow_enable_legend array
         and data has one series

        """
        series = [[]]  # It can't happen if the value of stat_item_cd is 'STAT_IC_HITS'. but just assume that can happen
        user = User.objects.get(username='cop_to_aurora@cdnetworks.com')
        result = make_custom_chart_option('STAT_IC_HITS', user, {'data': series, 'dataHeader': []})
        self.assertEqual(['enableLegend', 'header', 'stacking', 'xAxisName'], sorted(result.keys()))
        self.assertEqual(True, result['enableLegend'])

    def test_make_custom_chart_option_func_when_stat_item_cd_is_STAT_IC_HITS_and_two_series(self):
        """

        Description: To test  make_custom_chart_option() with stat_item_cd which is already in allow_enable_legend array
         and data has two series

        """
        series = [[], []]
        user = User.objects.get(username='cop_to_aurora@cdnetworks.com')
        result = make_custom_chart_option('STAT_IC_HITS', user, {'data': series, 'dataHeader': []})
        self.assertEqual(['enableLegend', 'header', 'stacking', 'xAxisName'], sorted(result.keys()))
        self.assertEqual(True, result['enableLegend'])
