from django.conf.urls.defaults import patterns, url

urlpatterns = patterns('aurora_api.email_report.views.email_report',
    url(r'^edit/account/(?P<account_no>[0-9]+)/', 'emailReport_edit_account'),
)