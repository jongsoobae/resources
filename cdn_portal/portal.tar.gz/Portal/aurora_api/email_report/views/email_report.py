from aurora_api.utils import APIException, APIErrorResponse, APIResponse
from aurora_fe.shared_components.models.acl_core import CustomerAccountWrapper
from aurora_fe.email_report.models.email_report import EmailReport
from django.views.decorators.csrf import csrf_exempt

from spectrum_fe.shared_components.utils.api import getOptionalParams

@csrf_exempt
def emailReport_edit_account(request, account_no):
    try :
        opts = getOptionalParams(request)
        opts_set = set(opts)
        available_fields = set(('username', 'password', 'to_account_no'))
        required_fields = set(('username', 'password', 'to_account_no'))

        missing_opts = required_fields.difference(opts_set)
        
        to_account_no = opts.get('to_account_no')

        if len(missing_opts) > 0:
            return APIErrorResponse(request, "104", "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, "104", "Invalid parameters in request: " + ", ".join(invalid_opts))
        
        return_val = update_emailReport_account(account_no, to_account_no)
        
        if return_val['returnCode'] != 0 :
            return APIErrorResponse(request, return_val['returnCode'], return_val['returnMsg'])
        
        return APIResponse(request, {})
    except Exception as e :
        return APIException(request, "999", e)
    
def update_emailReport_account(account_no, to_account_no):
    try :
        try :
            CustomerAccountWrapper.objects.get(pk=to_account_no)
        except :
            return {'returnCode':404, 'returnMsg':"Matching account(to_account:"+to_account_no+") does not exist."}
        
        if EmailReport.objects.filter(account=account_no).count() :
            try :
                EmailReport.objects.filter(account=account_no).update(account=to_account_no)
            except Exception as e :
                return {'returnCode':999, 'returnMsg':e}
        else :
            return {'returnCode':404, 'returnMsg':"Matching email report(from_account:"+account_no+") does not exist."} 
                     
        return {'returnCode':0, 'returnMsg':"Success"}
    except Exception as e :
        return {'returnCode':999, 'returnMsg':e}   