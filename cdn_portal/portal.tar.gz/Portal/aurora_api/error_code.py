# success
SUCCESS = 0;
# system error ( temporarily service unavailable )
TEMP_UNAVAILABLE = 999;
# login failure
INVALID_USERINFO = 101;
# invalid session token
INVALID_SESSION = 102;
# logout failure
LOGOUT_FAIL = 103;
# wrong input parameter
WRONG_INPUT = 104;
# client ip is not allowed
NOT_ALLOWED_IP = 201;
# no authority for menu
NOT_ALLOWED_MENU = 202;
# no authority for service
NOT_ALLOWED_SVC = 203;
# Inaccessible Request
NOT_SUPPORT_SVC = 204;
# wrong api key or not-registered api key
WRONG_API_KEY = 301;
# no data
NO_DATA = 404;
# wrong site id for CUI email noti issue
WRONG_SITE_ID = 600;
# Invalid parameter
INVALID_REQUEST = 105

# Get error from config update.
FAIL_CONFIG_UPDATE = 405

# no more progress
UNNECESSARY_OPERATION = 406

# hls data server error
HLS_DATA_SERVER_ERROR = 505
