from django.conf.urls.defaults import patterns, url

urlpatterns = patterns('aurora_api.fastmon.views.fast_mon',
    url(r'^getFastMonInfo$', 'get_fast_mon_info', name='url_get_fast_mon_info'),
)
