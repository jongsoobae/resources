import json
from django.views.decorators.csrf import csrf_exempt

from aurora_api import error_code
from aurora_api.shared_components.decorators import stat_api_param_required
from aurora_api.utils import APIException, APIResponse
from spectrum_fe.shared_components.utils.api import getOptionalParams
from django.db import connections
from aurora_api.utils import APIErrorResponse

def get_prefix_fast_mon(service_prefix):
    cursor = connections['one_stat'].cursor()
    try:
        sql = """select stat_time, dns_prefix, json_text from fast_monitor_snapshot
              where dns_prefix = '%s'"""%service_prefix
        cursor.execute(sql)
        rslist = cursor.fetchall()
        ret_fast_mon = rslist[0]
    except:
        ret_fast_mon = []
    finally:
        cursor.close()
        del cursor

    return ret_fast_mon


def get_acl_prefix_by_customer(customer_id):
    if customer_id == None:
        return None

    cursor = connections['centraldb'].cursor()
    try:
        customer_id = int(customer_id)
        if customer_id < 0:
            return None

        sql = """select cs.dns_prefix
                from fastmon_customer_prefix fcp
                inner join cdn_service cs on fcp.cdn_service_id = cs.CDN_SERVICE_ID
                where fcp.status = 1 and fcp.customer_id = %s"""%customer_id

        cursor.execute(sql)
        rslist = cursor.fetchall()
        ret_acl_prefix_list = [id[0] for id in rslist]
    except:
        ret_acl_prefix_list = None
    finally:
        cursor.close()
        del cursor

    return ret_acl_prefix_list


def get_customer_id_by_account(account_no):
    cursor = connections['default'].cursor()

    try:
        account_no = int(account_no)
        if account_no < 0:
            return None

        sql = """select ckey from control_group
            where account_no=%s and group_type=0"""%account_no

        cursor.execute(sql)
        rslist = cursor.fetchall()
        customer_id = int(rslist[0][0])
    except:
        customer_id = None
    finally:
        cursor.close()
        del cursor

    return customer_id

@csrf_exempt
@stat_api_param_required
def get_fast_mon_info(request):
    try:
        params = getOptionalParams(request)

        service_prefix = params.get("servicePrefix")
        account_no = params.get('account_no')

        customer_id = get_customer_id_by_account(account_no)
        service_prefix_list = get_acl_prefix_by_customer(customer_id)

        if customer_id == None \
                or service_prefix_list == None \
                or (service_prefix not in service_prefix_list and int(account_no) != 20036):
            error_obj_msg = 'no authority for %s'%('Customer' if customer_id == None else 'servicePrefix')
            return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, "%s" % error_obj_msg, 200)

        fast_mon_info = get_prefix_fast_mon(service_prefix)
        if fast_mon_info == []:
            return APIErrorResponse(request, error_code.NO_DATA, "No DATA")

        json_data_obj = json.loads(fast_mon_info[2])
        json_data_obj["Date"]= fast_mon_info[0].strftime("%Y-%m-%d %H:%M:%S")

        ret_api_data = {service_prefix:json_data_obj}

        api_response = {
            'data': ret_api_data
        }
        return APIResponse(request, api_response)

    except Exception as api_exception:
        return APIException(
            request,
            error_code.TEMP_UNAVAILABLE,
            api_exception
        )
