from django.conf.urls.defaults import patterns, url

urlpatterns = patterns('aurora_api.group.views.control_group',
    url(r'^control-group/add/$', 'controlGroup_add'),
    url(r'^control-group/edit/name/(?P<account_no>[0-9]+)/', 'controlGroup_edit_name'),
    url(r'^control-group/search/name/(?P<account_no>[0-9]+)/', 'controlGroup_search_name'),
    url(r'^control-group/add/ma_service_type/$', 'controlGroup_add_ma_servie_type'),
    url(r'^control-group/list/(?P<account_no>[0-9]+)/', 'controlGroup_list'),
    url(r'^control-group/edit/ckey/(?P<account_no>[0-9]+)/', 'controlGroup_edit_ckey'),
    url(r'^control-group/list/', 'controlGroup_all_list'),
    url(r'^control-group/edit/account/(?P<account_no>[0-9]+)/', 'controlGroup_edit_account'),
)
    
urlpatterns += patterns('aurora_api.group.views.customer_account',
    url(r'^control-group/account_list', 'get_account_list'),
)
