from aurora_api.utils import APIException, APIErrorResponse, APIResponse
from aurora_fe.shared_components.models.acl_core import ControlGroup, \
    CustomerAccountWrapper, AuthUserHasControlGroup, ServiceTypeCd
from django.conf.urls.defaults import patterns, url
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.utils import simplejson
from django.utils.encoding import smart_str
from django.views.decorators.csrf import csrf_exempt
from spectrum_fe.shared_components.models.customer import CustomerItem, \
    CustomerContract
from spectrum_fe.shared_components.utils.api import getOptionalParams
from aurora_fe.shared_components.utils.account import getAccountNameWithEng
from aurora_fe.shared_components.utils.control_group import ControlGroupCheckObject

@csrf_exempt
@transaction.commit_on_success
def controlGroup_add(request):
    try :
        opts = getOptionalParams(request)

        opts_set = set(opts)
        available_fields = set(('username', 'password', 'control_group_name', 'account_no', 'contract_no', 'item_no',
                                'ckey'))
        required_fields = set(('username', 'password', 'control_group_name', 'account_no', 'contract_no', 'item_no',
                               'ckey'))

        missing_opts = required_fields.difference(opts_set)

        if len(missing_opts) > 0:
            return APIErrorResponse(request, "104", "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, "104", "Invalid parameters in request: " + ", ".join(invalid_opts))

        try :
            account = CustomerAccountWrapper.objects.get(pk=opts.get('account_no'))
        except :
            return APIErrorResponse(request, "104", "Matching account does not exist.")

        if opts.get('contract_no').strip() == '' and opts.get('item_no').strip() == '' :
            ctr_cg_name = ''
        else :
            try :
                customerItem = CustomerItem.objects.get(contract=opts.get('contract_no'), item_no=opts.get('item_no'))
            except :
                return APIErrorResponse(request, "104", "Matching contract does not exist.")

            try :
                contract = CustomerContract.objects.get(account=opts.get('account_no'),
                                                        contract_no=opts.get('contract_no'))
            except :
                return APIErrorResponse(request, "104", "Invalid mapping between account and contract.")

            ctr_cg_name = "%s-%s" % (opts.get('contract_no'), opts.get('item_no'))

        def_cg_name = opts.get('control_group_name').strip()
        if '' == def_cg_name :
            def_cg_name = getAccountNameWithEng(account)

        groupKey = 0
        try :
            default = ControlGroup.objects.get(account_no=opts.get('account_no'), group_type=0)

            def_cg_name = default.control_group_name
            groupKey = default.pk

            if str(default.ckey) != opts.get('ckey') :
                return APIErrorResponse(request, "104", "Invalid mapping between account and ckey.")

        except ControlGroup.DoesNotExist:
            create = ControlGroup(control_group_name=def_cg_name, account_no=account, group_type=0,
                                  ckey=opts.get('ckey'))
            create.save(request=request)
            groupKey = create.pk

        if opts.get('contract_no').strip() == '' and opts.get('item_no').strip() == '' :
            pass
        else :
            try :
                contract = ControlGroup.objects.get(account_no=opts.get('account_no'), item_id=customerItem,
                                                    group_type=1)

                ctr_cg_name = contract.control_group_name
                if contract.pk > 0:
                    return APIErrorResponse(request, "302",
                                            "Already exists (TopLevelControlGroupName: %s, ContractControlGroupName: %s"
                                             % (def_cg_name, ctr_cg_name))

            except ControlGroup.DoesNotExist:
                try :
                    contract = ControlGroup(control_group_name=ctr_cg_name, account_no=account, item_id=customerItem,
                                            group_type=1)
                    contract.save(request=request)

                    cusItem = CustomerItem.objects.get(contract=opts.get('contract_no'), item_no=opts.get('item_no'))
                    cusItem.portal_flag = '03'
                    cusItem.save(request=request)


                    authUser = AuthUserHasControlGroup.objects.filter(control_group_id=groupKey, use_flag=1,
                                                                      auth_user_id__is_active=1)

                    for au in authUser :
                        addUserPriv = AuthUserHasControlGroup(auth_user_id=au.auth_user_id, control_group_id=contract,
                                                              use_flag=1)
                        addUserPriv.save(request=request)

                except Exception as e :
                    transaction.rollback()
                    return APIException(request, "999", e)

        returnSucc = {"TopLevelControlGroupName": def_cg_name, "ContractControlGroupName": ctr_cg_name,
                      "TopLevelControlGroupKey": groupKey}

        return APIResponse(request, returnSucc)
    except Exception as e :
        return APIException(request, "999", e)


@csrf_exempt
def controlGroup_edit_name(request, account_no):
    try :
        opts = getOptionalParams(request)
        opts_set = set(opts)
        available_fields = set(('username', 'password', 'control_group_name'))
        required_fields = set(('username', 'password', 'control_group_name'))

        missing_opts = required_fields.difference(opts_set)

        if len(missing_opts) > 0:
            return APIErrorResponse(request, "104", "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, "104", "Invalid parameters in request: " + ", ".join(invalid_opts))

        try :
            account = CustomerAccountWrapper.objects.get(pk=account_no)
        except :
            return APIErrorResponse(request, "104", "Matching account does not exist.")

        def_cg_name = opts.get('control_group_name').strip()
        if '' == def_cg_name :
            def_cg_name = getAccountNameWithEng(account)

        try :
            default = ControlGroup.objects.get(account_no=account_no, group_type=0)
            default.control_group_name = def_cg_name
            default.save(request=request)
        except ControlGroup.DoesNotExist:
            return APIErrorResponse(request, "404", "Matching control group does not exist.")
        except ControlGroup.MultipleObjectsReturned :
            return APIErrorResponse(request, "104", "MultipleObjectsReturned.")

        return APIResponse(request, {})
    except Exception as e :
        return APIException(request, "999", e)

@csrf_exempt
def controlGroup_search_name(request, account_no):
    try :
        opts = getOptionalParams(request)
        opts_set = set(opts)
        available_fields = set(('username', 'password'))
        required_fields = set(('username', 'password'))

        missing_opts = required_fields.difference(opts_set)

        if len(missing_opts) > 0:
            return APIErrorResponse(request, "104", "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, "104", "Invalid parameters in request: " + ", ".join(invalid_opts))

        default = None
        try :
            default = ControlGroup.objects.get(account_no=account_no, group_type=0)
        except ControlGroup.DoesNotExist:
            return APIErrorResponse(request, "404", "Matching control group does not exist.")

        returnSucc = {"TopLevelControlGroupName": default.control_group_name, "TopLevelControlGroupKey": default.pk, "ckey": default.ckey}
        return APIResponse(request, returnSucc)
    except Exception as e :
        return APIException(request, "999", e)

@csrf_exempt
def controlGroup_list(request, account_no):
    try :
        opts = getOptionalParams(request)
        opts_set = set(opts)
        available_fields = set(('username', 'password'))
        required_fields = set(('username', 'password'))

        missing_opts = required_fields.difference(opts_set)

        if len(missing_opts) > 0:
            return APIErrorResponse(request, "104", "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, "104", "Invalid parameters in request: " + ", ".join(invalid_opts))

        controlGroupList = ControlGroup.objects.filter(use_flag=1, account_no=account_no).order_by('group_type',
                                                                                                   'control_group_name')

        if len(controlGroupList) == 0 :
            return APIErrorResponse(request, "404", "Control group does not exist.")

        cg_list = []

        for i in controlGroupList:
            obj = ControlGroupCheckObject()

            obj.control_group_id = i.control_group_id
            obj.control_group_name = i.control_group_name
            obj.group_type = i.group_type

            cg_list.append(obj.__dict__)

        returnSucc = {"ControlGroupList": cg_list}
        return APIResponse(request, returnSucc)
    except Exception as e :
        return APIException(request, "999", e)

@csrf_exempt
def controlGroup_all_list(request):
    try :
        opts = getOptionalParams(request)
        opts_set = set(opts)
        available_fields = set(('username', 'password'))
        required_fields = set(('username', 'password'))

        missing_opts = required_fields.difference(opts_set)

        if len(missing_opts) > 0:
            return APIErrorResponse(request, "104", "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, "104", "Invalid parameters in request: " + ", ".join(invalid_opts))

        controlGroupList = ControlGroup.objects.filter(use_flag=1).order_by('account_no', 'group_type',
                                                                                                   'control_group_name')

        if len(controlGroupList) == 0 :
            return APIErrorResponse(request, "404", "Control group does not exist.")

        cg_list = []

        for i in controlGroupList:
            obj = ControlGroupCheckObject()

            obj.control_group_id = i.control_group_id
            obj.control_group_name = i.control_group_name
            obj.group_type = i.group_type

            cg_list.append(obj.__dict__)

        returnSucc = {"ControlGroupList": cg_list}
        return APIResponse(request, returnSucc)
    except Exception as e :
        return APIException(request, "999", e)

@csrf_exempt
def controlGroup_edit_ckey(request, account_no):
    try :
        opts = getOptionalParams(request)
        opts_set = set(opts)
        available_fields = set(('username', 'password', 'ckey'))
        required_fields = set(('username', 'password', 'ckey'))

        missing_opts = required_fields.difference(opts_set)

        if len(missing_opts) > 0:
            return APIErrorResponse(request, "104", "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, "104", "Invalid parameters in request: " + ", ".join(invalid_opts))

        try :
            account = CustomerAccountWrapper.objects.get(pk=account_no)
        except :
            return APIErrorResponse(request, "104", "Matching account does not exist.")

        controlgroup = ControlGroup.objects.filter(ckey=opts.get('ckey'), group_type=0).exclude(account_no=account_no)

        if controlgroup :
            return APIErrorResponse(request, "302", "Duplicate ckey.")

        try :
            default = ControlGroup.objects.get(account_no=account_no, group_type=0)
            default.ckey = opts.get('ckey')
            default.save(request=request)
        except ControlGroup.DoesNotExist:
            return APIErrorResponse(request, "404", "Matching control group does not exist.")
        except ControlGroup.MultipleObjectsReturned :
            return APIErrorResponse(request, "104", "MultipleObjectsReturned.")

        return APIResponse(request, {})
    except Exception as e :
        return APIException(request, "999", e)


@csrf_exempt
@transaction.commit_on_success
def controlGroup_add_ma_servie_type(request):
    try :
        opts = getOptionalParams(request)

        opts_set = set(opts)
        available_fields = set(('username', 'password', 'account_no', 'service_type_cd'))
        required_fields = set(('username', 'password', 'account_no', 'service_type_cd'))

        missing_opts = required_fields.difference(opts_set)

        if len(missing_opts) > 0:
            return APIErrorResponse(request, "104", "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, "104", "Invalid parameters in request: " + ", ".join(invalid_opts))

        try :
            account = CustomerAccountWrapper.objects.get(pk=opts.get('account_no'))
        except :
            return APIErrorResponse(request, "104", "Matching account does not exist.")

        try :
            serviceType = ServiceTypeCd.objects.get(service_type_cd=opts.get('service_type_cd'))
        except :
            return APIErrorResponse(request, "104", "Invalid service type code.")

        groupKey = 0
        ma_svc_cg_name = serviceType.service_type_name

        try :
            default = ControlGroup.objects.get(account_no=opts.get('account_no'), group_type=0)
            def_cg_name = default.control_group_name
            groupKey = default.pk
        except ControlGroup.DoesNotExist:
            def_cg_name = getAccountNameWithEng(account)
            create = ControlGroup(control_group_name=def_cg_name, account_no=account, group_type=0)
            create.save(request=request)
            groupKey = create.pk

        try :
            ma_svc_type_control_group = ControlGroup.objects.get(account_no=opts.get('account_no'), group_type=3,
                                               service_type_cd=opts.get('service_type_cd'))

            ma_svc_cg_name = ma_svc_type_control_group.control_group_name
            ma_svc_groupKey = ma_svc_type_control_group.pk

        except ControlGroup.DoesNotExist:
            try :
                ma_svc = ControlGroup(control_group_name=ma_svc_cg_name, account_no=account, group_type=3,
                                      service_type_cd=serviceType)
                ma_svc.save(request=request)
                ma_svc_groupKey = ma_svc.pk

                authUser = AuthUserHasControlGroup.objects.filter(control_group_id=groupKey, use_flag=1,
                                                                      auth_user_id__is_active=1)

                for au in authUser :
                    addUserPriv = AuthUserHasControlGroup(auth_user_id=au.auth_user_id,
                                                          control_group_id=ma_svc, use_flag=1)
                    addUserPriv.save(request=request)

            except Exception as e :
                    transaction.rollback()
                    return APIException(request, "999", e)

        returnSucc = {"MAServiceTypeControlGroupName": ma_svc_cg_name,
                      "MAServiceTypeCode": int(opts.get('service_type_cd')),
                      "MAServiceTypeControlGroupKey": ma_svc_groupKey}

        return APIResponse(request, returnSucc)
    except Exception as e :
        return APIException(request, "999", e)

   
@csrf_exempt
@transaction.commit_on_success
def controlGroup_edit_account(request, account_no):
    try :
        opts = getOptionalParams(request)
        opts_set = set(opts)
        available_fields = set(('username', 'password', 'to_account_no'))
        required_fields = set(('username', 'password', 'to_account_no'))

        missing_opts = required_fields.difference(opts_set)
        
        to_account_no = opts.get('to_account_no')

        if len(missing_opts) > 0:
            return APIErrorResponse(request, "104", "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, "104", "Invalid parameters in request: " + ", ".join(invalid_opts))
        
        return_val = update_controlGroup_account(account_no, to_account_no)
        
        if return_val['returnCode'] != 0 :
            return APIErrorResponse(request, return_val['returnCode'], return_val['returnMsg'])
        
        return APIResponse(request, {})
    except Exception as e :
        return APIException(request, "999", e)

def update_controlGroup_account(account_no, to_account_no):
    try :
        try :
            account = CustomerAccountWrapper.objects.get(pk=to_account_no)
        except :
            return {'returnCode':404, 'returnMsg':"Matching account(to_account:"+to_account_no+") does not exist."}

        controlgroup = ControlGroup.objects.filter(account_no=to_account_no)

        if controlgroup :
            return {'returnCode':302, 'returnMsg':"Duplicate control group(to_account:"+to_account_no+")"}

        if ControlGroup.objects.filter(account_no=account_no).count() :
            try :
                ControlGroup.objects.filter(account_no=account_no).update(account_no=to_account_no)
            except Exception as e :
                return {'returnCode':999, 'returnMsg':e}
        else :       
            return {'returnCode':404, 'returnMsg':"Matching control group(from_account:"+account_no+") does not exist."}
            
        def_cg_name = getAccountNameWithEng(account)

        try :
            default = ControlGroup.objects.get(account_no=to_account_no, group_type=0)
            default.control_group_name = def_cg_name
            default.save()
        except ControlGroup.DoesNotExist:
            return {'returnCode':404, 'returnMsg':"Matching customer control group(to_account:"+to_account_no+") does not exist."}
        except ControlGroup.MultipleObjectsReturned :
            return {'returnCode':104, 'returnMsg':"MultipleObjectsReturned."}
     
        return {'returnCode':0, 'returnMsg':"Success"}
    except Exception as e :
        return {'returnCode':999, 'returnMsg':e}
    