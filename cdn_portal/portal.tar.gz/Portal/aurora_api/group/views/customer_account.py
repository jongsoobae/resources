
import json

from django.views.decorators.csrf import csrf_exempt
from django.utils.encoding import smart_str

from spectrum_fe.shared_components.models.customer import CustomerAccount
from spectrum_fe.shared_components.models.customer import CustomerItem
from spectrum_fe.shared_components.models.portal_menu import MaterialGroup

from aurora_api.utils import APIException, APIResponse

@csrf_exempt
def get_account_list(request):
    '''
        @url
            [AURORA API URL] /rest/group/control-group/account_list/

        @description
            returns customer account list

        @params
            material_group_cd : aurora's material group code list.
                                (comma separated value such as 'abc,def,ghi', case sensetive)

            field_list : customer_account's field name list to search. (comma separated value such as 'abc,def,ghi')
                         'account_no', 'account_name_eng', 'account_name_local',
                         'sales_org', 'create_time', 'telco_type', 'description'

        @response
            { <= Account List Result

                "returnMsg" : <String - API Response Message>,
                "returnCode" : <Number - API Response Return Code 0 is Normal>,
                "AccountList" : [ <= Account List

                    { <= Account Object (field's value)

                        "account_no" : <Number - Customer Account ID>,
                        "account_name" : <String - UTF-8 URL Encoded Account Name>
                        ...

                    }, ...
                ]
            }
    '''

    # default field params
    customer_account_field_list = [
        'account_no',
        'account_name_eng',
        'account_name_local',
        'sales_org',
        'create_time',
        'telco_type',
        'description'
    ]

    try:
        # initialize request params
        try:
            # JSON Param
            if request.raw_post_data is not '':
                request_params = json.loads(request.raw_post_data)
            else:
                request_params = {}
        except Exception as ignored_exception:
            # Raw Param
            request_params = {
                'material_group_cd': request.POST.get('material_group_cd'),
                'field_list': request.POST.get('field_list')
            }

        request_material_group_param = request_params.get('material_group_cd', None)
        request_field_param = request_params.get('field_list', None)

        # get customer account from params
        if request_material_group_param is not None:
            request_material_group_list = request_material_group_param.split(',')

            material_no_list = MaterialGroup.objects.filter(
                material_group_cd__in=request_material_group_list
            ).values_list('material_no', flat=True)

            customer_item_list = CustomerItem.objects.filter(
                material_no__in=material_no_list
            ).values('contract__account__account_no').distinct('contract__account__account_no')

            customer_account_list = CustomerAccount.objects.filter(account_no__in=customer_item_list)
        else:
            customer_account_list = CustomerAccount.objects.all()

        # generate response content
        if request_field_param is not None:
            request_field_list = request_field_param.split(',')
        else:
            request_field_list = customer_account_field_list
        intersection_field = list(set(customer_account_field_list) & set(request_field_list))

        response_payload = []
        for customer_account in customer_account_list:
            response_account_object = {}
            for field in intersection_field:
                response_account_object[field] = smart_str(getattr(customer_account, field))

            response_payload.append(response_account_object)

        response_data = {"AccountList": response_payload}

        return APIResponse(request, response_data)
    except Exception as api_exception:
        return APIException(request, "999", api_exception)
