from aurora_api import settings, error_code
from aurora_api.hls.api.hls_internal_api import hlsInternalApi
from spectrum_fe.shared_components.utils.common import log_error

import socket
import json

def data_hls(request, hls_key, time_zone, path):
    result = ''
    if time_zone == None or time_zone == '':
        params = "hlskey=%s" % (hls_key)
    else:
        params = "hlskey=%s&timezone=%s" % (hls_key, time_zone)

    hip = hlsInternalApi()

    socket_reponse = socket.getaddrinfo(settings.HLS_API_HOST, '80')

    ip_val = ''
    for rdata in socket_reponse:
        try:
            family, socktype, proto, canonname, sockaddr = rdata
            hls_ip, port = sockaddr

            if ip_val == hls_ip:
                continue
            else:
                ip_val = hls_ip
            api_response = hip.send_and_receive(path, params, hls_ip)

            if api_response.status_code == 200:
                result = json.loads(api_response.content)
                result = result['HitCountResponse']

            break
        except Exception as e:
            print rdata, e
            log_error(None, "hls data error : "+hls_key, e)
            result = error_code.HLS_DATA_SERVER_ERROR

    return result
