from aurora_api import settings
from spectrum_fe.shared_components.utils.common import log_error
from spectrum_fe.shared_components import requests

import json

class hlsInternalApi:
    result = None

    def send_and_receive(self, path, params, ip):
        url = "http://%s/%s" % (ip, path)
        try:
            api_req_headers = {
                       'Content-Type': 'application/json',
                       'Accept': 'application/json',
                       'Host': settings.HLS_API_HOST
                          }
            self.result = requests.post(url, data=params, headers=api_req_headers, timeout=settings.HLS_API_TIMEOUT)
            return self.result
        except Exception as e:
            log_error(None, "hls internal api error : "+url, e)
