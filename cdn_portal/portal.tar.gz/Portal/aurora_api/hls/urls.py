from django.conf.urls.defaults import patterns, url

urlpatterns = patterns('aurora_api.hls.views.visitor',
    url(r'^hitCount$', 'get_hls_hit_count', name='get_hls_hit_count'),
)
