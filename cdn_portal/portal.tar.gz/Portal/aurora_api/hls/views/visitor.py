from aurora_api.shared_components.decorators import stat_api_param_required
from aurora_api.utils import APIException, APIPantherResponse
from aurora_api import error_code
from aurora_api.hls.api.hls_internal import data_hls
from spectrum_fe.shared_components.utils.api import getOptionalParams
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
@stat_api_param_required
def get_hls_hit_count(request):
    try :
        params = getOptionalParams(request)

        hls_key = params.get("hlsKey")
        time_zone = params.get("timeZone")
        path = 'internal'
        result = data_hls(request, hls_key, time_zone, path)

        if result == error_code.HLS_DATA_SERVER_ERROR:
            return APIPantherResponse(request, {'returnCode':error_code.HLS_DATA_SERVER_ERROR})

        return APIPantherResponse(request, result)

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)