
from collections import namedtuple


LdsPrefixApiResponseItem = namedtuple(
    'LdsPrefixApiResponseItem',
    'serviceName, apiKey, ldsPrefix'
)
