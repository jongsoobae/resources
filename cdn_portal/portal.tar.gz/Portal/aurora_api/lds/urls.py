from django.conf.urls.defaults import patterns, url

urlpatterns = patterns('aurora_api.lds.views.lds_prefix',
    url(r'^getLdsPrefixList$', 'get_lds_prefix_list', name='url_get_lds_prefix_list'),
)
