import json
from django.views.decorators.csrf import csrf_exempt

from aurora_api import error_code
from aurora_api.stat.views.common import getApiKeyList
from aurora_api.lds.models.lds_prefix_item import LdsPrefixApiResponseItem
from aurora_api.shared_components.decorators import stat_api_param_required
from aurora_api.utils import APIException, APIResponse

from aurora_fe.shared_components.utils.stat import getControlGroupStatItem
from spectrum_fe.shared_components.utils.api import getOptionalParams
from spectrum_fe.shared_components.models.api import StatApiKey


@csrf_exempt
@stat_api_param_required
def get_lds_prefix_list(request):
    try:
        # get api key from 'getApiKey' feature
        api_key_response = getApiKeyList(request)
        api_key_response_dict = json.loads(api_key_response.content)

        if api_key_response_dict.get('returnCode') != 0:
            raise Exception('Error occurred in "getApiKeyList"')

        api_key_payload = api_key_response_dict.get('data')

        # make filtered list which contains service item apikey
        # service domain type is 1, service group type is 0.
        api_key_list = [
            response_item.get("apiKey")
            for response_item in api_key_payload
            if response_item.get("type") == 1
        ]

        # make 'apikey:servicename' paired dictionary
        api_key_service_name_pair_dict = {}
        for response_item in api_key_response_dict.get('data'):

            api_key = response_item.get("apiKey")
            service_name = response_item.get("serviceName")

            api_key_service_name_pair_dict[api_key] = service_name

        # get api key object which contains lds temp key
        stat_api_key_list = StatApiKey.objects.filter(api_key__in=api_key_list)

        # generate api response payload
        # lds prefix defined by api_key or lds_temp_key.
        # if service domain is migrated from ocsp,
        # then lds_temp_key is used in lds as lds prefix.
        api_response_payload = [
            LdsPrefixApiResponseItem(
                apiKey=stat_api_key.api_key,
                ldsPrefix=stat_api_key.lds_temp_key \
                    if stat_api_key.lds_temp_key \
                    else stat_api_key.api_key,
                serviceName=api_key_service_name_pair_dict.get(
                    stat_api_key.api_key)
            )._asdict() for stat_api_key in stat_api_key_list
        ]

        api_response = {
            'data': api_response_payload
        }

        return APIResponse(request, api_response)

    except Exception as api_exception:
        return APIException(
            request,
            error_code.TEMP_UNAVAILABLE,
            api_exception
        )
