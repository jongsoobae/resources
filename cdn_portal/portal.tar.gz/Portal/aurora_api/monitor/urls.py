from django.conf.urls.defaults import patterns, url

urlpatterns = patterns('aurora_api.monitor.views.monitor',
    url(r'^purge/$', 'purge_monitor'),
    url(r'^login/$', 'login_monitor'),

)
