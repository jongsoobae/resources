from aurora_api import error_code
from aurora_api.utils import APIException, APIErrorResponse, APIResponse
from aurora_fe import settings as aurorSettings
from aurora_fe.flush.views.flush import is_valid_email
from django.conf.urls.defaults import url
from django.contrib.auth.models import User
from django.views.decorators.csrf import csrf_exempt
from spectrum_fe.shared_components.utils.api import getOptionalParams
import urllib

@csrf_exempt
def purge_monitor(request):
    try :
        opts = getOptionalParams(request)

        opts_set = set(opts)

        available_fields = set(('username', 'password', 'pad', 'path', 'mailTo', 'type'))
        required_fields = set(('username', 'password', 'pad'))

        missing_opts = required_fields.difference(opts_set)

        if len(missing_opts) > 0:
            return APIErrorResponse(request, error_code.WRONG_INPUT, "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, error_code.WRONG_INPUT, "Invalid parameters in request: " + ", ".join(invalid_opts))

        mailTo = opts.get('mailTo', None)
        username = opts.get('username', None)
        password = opts.get('password', None)
        pad = opts.get('pad', None)
        path = opts.get('path', None)
        intType = opts.get('type', None)

        try :
            intType = int(intType)
        except :
            intType = 1

        if mailTo != None and not is_valid_email(mailTo) :
            return APIErrorResponse(request, error_code.WRONG_INPUT, "%s is not a valid e-mail address." % mailTo)

        strType = 'item'

        if intType == 2:
            strType = 'wildcard'
        elif intType == 3:
            strType = 'all'


        url = aurorSettings.FLUSH_API_URL + "/purge/rest/doPurge?"

        path_param = {'user':username, 'pass':password, 'pad': pad}

        if strType == 'all':
            pass
        else:
            if None != path :
                path_param['path'] = path

        path_param['type'] = strType
        path_param['output'] = 'json'

        req = urllib.urlopen(url + urllib.urlencode(path_param, doseq=True))

        res = req.read()

        import ast
        dictRest = ast.literal_eval(res)

        resultCode = dictRest.get('resultCode')
        resultMsg = dictRest.get('details')

        if resultCode == 200 :
            return APIResponse(request, {})
        elif resultCode == 509 :
            return APIErrorResponse(request, resultCode, resultMsg)
        else :
            return APIErrorResponse(request, error_code.TEMP_UNAVAILABLE, resultMsg)

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
def login_monitor(request):
    try :
        opts = getOptionalParams(request)

        opts_set = set(opts)

        available_fields = set(('username', 'password'))
        required_fields = set(('username', 'password'))

        missing_opts = required_fields.difference(opts_set)

        if len(missing_opts) > 0:
            return APIErrorResponse(request, error_code.WRONG_INPUT, "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, error_code.WRONG_INPUT, "Invalid parameters in request: " + ", ".join(invalid_opts))

        username = opts.get('username', None)

        objUser = User.objects.filter(username=username)

        if len(objUser) > 0 :
            return APIResponse(request, {})
        else :
            return APIErrorResponse(request, error_code.TEMP_UNAVAILABLE, "Fail to find user in DB.")

        return ""
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)
