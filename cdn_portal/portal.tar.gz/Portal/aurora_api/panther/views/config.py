from django.views.decorators.csrf import csrf_exempt
from aurora_api import error_code
from aurora_api.panther.api.panther_api import pantherApi
from aurora_api.shared_components.decorators import cs_config_api_param_required, stat_api_param_required, \
    cs_config_api_key_check, api_authority_required, api_privilege_authority_required
from aurora_api.panther.api.panther import data_panther, sam_panther
from aurora_api.utils import APIException, APIPantherResponse
from spectrum_fe.shared_components.utils.api import getOptionalParams
import json

@csrf_exempt
@cs_config_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
def list_panther_contract(request):
    try:
        params = getOptionalParams(request)
        pad_param = ''
        path = '/contract/list/'

        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)
        json_result = json.loads(result)

        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@cs_config_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
def view_panther_contract(request, contract_no):
    try:
        params = getOptionalParams(request)

        pad_param = ''
        path = '/contract/view/%s/' % (contract_no)
        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)
        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@cs_config_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
def view_panther_contract_shields(request, contract_no):
    try:
        params = getOptionalParams(request)
        pad_param = ''
        path = '/contract/%s/shields/' % (contract_no)
        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)
        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@cs_config_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW', 'PAD_ADD_EDIT_VIEW_SAM'])
def add_panther_pad(request):
    try:
        params = getOptionalParams(request)
        pad_param = params.get("padParam")
        path = '/site/add/'
        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)
        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@cs_config_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW', 'PAD_ADD_EDIT_VIEW_SAM'])
def add_v2_panther_pad(request):
    try:
        params = getOptionalParams(request)
        pad_param = params.get("padParam")
        path = '/site/add/v2/'
        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)
        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW', 'PAD_EDIT_VIEW', 'PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def edit_panther_pad(request):
    try:
        params = getOptionalParams(request)
        pad_param = params.get("padParam")
        path = '/site/edit/%s/' % (params.get("pad"))
        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)

        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW', 'PAD_EDIT_VIEW', 'PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def edit_v2_panther_pad(request):
    try:
        params = getOptionalParams(request)
        pad_param = params.get("padParam")
        path = '/site/edit/v2/%s/' % (params.get("pad"))
        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)

        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW', 'PAD_EDIT_VIEW', 'PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def request_implement_panther_pad(request):
    try:
        params = getOptionalParams(request)
        pad_param = params.get("padParam")
        path = '/site/requestimplement/%s/' % (params.get("pad"))
        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)

        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW', 'PAD_EDIT_VIEW', 'PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def cancel_request_implement_panther_pad(request):
    try:
        params = getOptionalParams(request)
        pad_param = params.get("padParam")
        path = '/site/cancelrequest/%s/' % (params.get("pad"))
        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)

        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW', 'PAD_EDIT_VIEW', 'PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def delete_panther_pad(request):
    try:
        params = getOptionalParams(request)
        pad_param = params.get("padParam")
        path = '/site/delete/%s/' % (params.get("pad"))
        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)

        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW', 'PAD_EDIT_VIEW', 'PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def self_implementable_panther_pad(request):
    try:
        params = getOptionalParams(request)
        pad_param = params.get("padParam")
        path = '/site/selfimplementable/%s/' % (params.get("pad"))
        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)

        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW', 'PAD_EDIT_VIEW', 'PAD_VIEW', 'PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def view_panther_pad(request):
    try:
        params = getOptionalParams(request)
        pad_param = params.get("padParam")
        path = '/site/view/%s/' % (params.get("pad"))
        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)
        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW', 'PAD_EDIT_VIEW', 'PAD_VIEW', 'PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def trace_internal_panther_pad(request):
    try:
        params = getOptionalParams(request)
        pad_param = params.get("padParam")
        path = '/site/stagingtest/%s/' % (params.get("pad"))
        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)
        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW', 'PAD_EDIT_VIEW', 'PAD_VIEW', 'PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def history_panther_pad(request):
    try:
        params = getOptionalParams(request)
        pad_param = params.get("padParam")
        path = '/site/version/history/%s/' % (params.get("pad"))
        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)
        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW', 'PAD_EDIT_VIEW', 'PAD_VIEW', 'PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def version_compare_panther_pad(request):
    try:
        params = getOptionalParams(request)
        pad_param = params.get("padParam")
        path = '/site/version/compare/%s/' % (params.get("pad"))
        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)
        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW', 'PAD_EDIT_VIEW', 'PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def version_restore_panther_pad(request):
    try:
        params = getOptionalParams(request)
        pad_param = params.get("padParam")
        path = '/site/version/restore/%s/' % (params.get("pad"))
        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)
        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW', 'PAD_EDIT_VIEW', 'PAD_VIEW', 'PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def list_panther_pad(request):
    try:
        params = getOptionalParams(request)
        pad_param = params.get("padParam")
        path = '/site/list/'
        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)
        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW', 'PAD_EDIT_VIEW', 'PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def push_staging_panther_pad(request, pad_name):
    try:
        params = getOptionalParams(request)
        pad_param = params.get("padParam")
        path = '/site/push/%s/staging/' % (pad_name)

        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)
        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW', 'PAD_EDIT_VIEW', 'PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def push_production_panther_pad(request, pad_name):
    try:
        params = getOptionalParams(request)
        pad_param = params.get("padParam")
        path = '/site/push/%s/production/' % (pad_name)

        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)
        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW', 'PAD_EDIT_VIEW', 'PAD_VIEW', 'PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def push_status_panther_pad(request, pad_name):
    try:
        params = getOptionalParams(request)
        pad_param = params.get("padParam")
        path = '/site/push/%s/status/' % (pad_name)
        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)
        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)


@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW', 'PAD_EDIT_VIEW', 'PAD_VIEW', 'PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def view_panther_pad_push_history(request, pad_name):
    try :
        params = getOptionalParams(request)
        pad_param = params.get("padParam")
        path = '/site/push/%s/history/' % (pad_name)

        result = data_panther(request, pad_param, params.get("account_no"), request.session['stat_list'], path)
        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)


@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def add_sam_by_pad(request):
    try:
        params = getOptionalParams(request)

        sam_json = params.get('sam_json')
        account_no = params.get('account_no')
        pad = params.get('pad')
        path = '/site/' + pad + '/sam_add/'
        result = sam_panther(request=request, sam_json=sam_json, account_no=account_no, path=path, pad=pad, stat_list=request.session['stat_list'])

        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)


@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def view_sam_by_pad(request):
    try:
        params = getOptionalParams(request)

        account_no = params.get('account_no')
        pad = params.get('pad')
        rule_id = params.get('rule_id')
        path = '/site/' + pad + '/sam_view/'
        result = sam_panther(request=request, sam_json='', account_no=account_no, path=path, pad=pad, stat_list=request.session['stat_list'], rule_id=rule_id)

        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)


@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def list_sam_by_pad(request):
    try:
        params = getOptionalParams(request)

        account_no = params.get('account_no')
        pad = params.get('pad')
        path = '/site/' + pad + '/sam_list/'
        result = sam_panther(request=request, sam_json='', account_no=account_no, path=path, pad=pad, stat_list=request.session['stat_list'])

        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)


@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def edit_sam_by_pad(request):
    try:
        params = getOptionalParams(request)

        sam_json = params.get('sam_json')
        account_no = params.get('account_no')
        pad = params.get('pad')
        rule_id = params.get('rule_id')
        path = '/site/' + pad + '/sam_edit/'
        result = sam_panther(request=request, sam_json=sam_json, account_no=account_no, path=path, pad=pad, stat_list=request.session['stat_list'], rule_id=rule_id)

        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)


@csrf_exempt
@stat_api_param_required
@cs_config_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(orPrivilegeMenus=['PAD_ADD_EDIT_VIEW_SAM', 'PAD_EDIT_VIEW_SAM'])
def delete_sam_by_pad(request):
    try:
        params = getOptionalParams(request)

        sam_json = params.get('sam_json')
        account_no = params.get('account_no')
        pad = params.get('pad')
        rule_id = params.get('rule_id')
        path = '/site/' + pad + '/sam_delete/'
        result = sam_panther(request=request, sam_json='', account_no=account_no, path=path, pad=pad, stat_list=request.session['stat_list'], rule_id=rule_id)

        json_result = json.loads(result)
        if json_result['status_code'] == 200:
            json_result['errors'] = ''
        return APIPantherResponse(request, {'returnCode':json_result['status_code'],
                                            'data': {'data':json_result['data'], 'errors':json_result['errors']}})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)
