# Django settings for aurora_api project.
import os
import config_db_constants
import config_constants
from config_constants import CACHE_BACKEND, CACHE_LOCATIONS
import sys
from aurora_fe import __version__
ROOT = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, os.path.dirname(ROOT))

DEBUG = False
TEMPLATE_DEBUG = DEBUG

PROJECT_NAME = 'aurora_api'
AURORA_NAME = 'aurora_fe'
PROJECT_LOCATION = ROOT + '/'
SPECTRUM_LOCATION = os.path.dirname(ROOT) + '/spectrum_fe/'

SPECTRUM_NAME = 'spectrum_fe'
VERSION_NUMBER = __version__
IS_PRODUCTION = config_constants.AURORA_PROD_HANDLER

DNA_MATERIAL = 1197
DNS_MATERIAL = 1182
CS_MATERIAL = 1028
CLOUD_STORAGE_MATERIAL = 1202
CLB_MATERIAL = 1199

MEGAFON_BILL_TO_CODE = 36561
DORA_BILL_TO_CODE = 20034
INDOSAT_BILL_TO_CODE = 49643

ADMINS = config_constants.ADMINS
EMAIL_HOST = 'send.mx.cdnetworks.com'
EMAIL_PORT = 25
EMAIL_ALERTS = config_constants.EMAIL_ALERTS

MANAGERS = ADMINS

AUTH_PROFILE_MODULE = 'shared_components.userprofile'

DATABASES = {
    'default': config_db_constants.DEFAULT,
    'stats':config_db_constants.STATS,
    'one_stat':config_db_constants.ONE_STAT,
    'centraldb':config_db_constants.CENTRALDB
}

DATABASE_ROUTERS = ["spectrum_fe.shared_components.database_routers.SpectrumRouter"]

# Local time zone for this installation. Choices can be found here:
# http://en.wikipedia.org/wiki/List_of_tz_zones_by_name
# although not all choices may be available on all operating systems.
# On Unix systems, a value of None will cause Django to use the same
# timezone as the operating system.
# If running in a Windows environment this must be set to the same as your
# system time zone.
TIME_ZONE = None

SITE_ID = 1

# Make this unique, and don't share it with anybody.
SECRET_KEY = 'dzkm(-&68!y=t_&3qsu+($m@v6+rs^sp^$=!g=vgaz!)tvs_v%'

# List of callables that know how to import templates from various sources.
TEMPLATE_LOADERS = (
    'django.template.loaders.filesystem.Loader',
    'django.template.loaders.app_directories.Loader',
#     'django.template.loaders.eggs.Loader',
)

MIDDLEWARE_CLASSES = (
    'django.middleware.common.CommonMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.middleware.transaction.TransactionMiddleware',
    PROJECT_NAME + '.shared_components.middleware.auth.AuthenticateUser',
)

ROOT_URLCONF = PROJECT_NAME + '.urls'

INSTALLED_APPS = (
    'django.contrib.auth',
    'django.contrib.sessions',
    PROJECT_NAME + '.group',
    PROJECT_NAME + '.user',
    PROJECT_NAME + '.dns',
    PROJECT_NAME + '.stat',
    PROJECT_NAME + '.monitor',
    PROJECT_NAME + '.shared_components',
    PROJECT_NAME + '.acl',
)

AUTHENTICATION_BACKENDS = (
    # PROJECT_NAME+'.shared_components.backends.login-auth.LoginAuth',
    AURORA_NAME + '.crowd.backend.CrowdBackend',
)

PASSWORD_HASHERS = (
    'spectrum_fe.shared_components.utils.hashers.PBKDF2PasswordHasher',
    'spectrum_fe.shared_components.utils.hashers.PBKDF2SHA1PasswordHasher',
    'spectrum_fe.shared_components.utils.hashers.BCryptPasswordHasher',
    'spectrum_fe.shared_components.utils.hashers.SHA1PasswordHasher',
    'spectrum_fe.shared_components.utils.hashers.MD5PasswordHasher',
    'spectrum_fe.shared_components.utils.hashers.CryptPasswordHasher',
)

DEFAULT_FROM_EMAIL = 'portaladmin@cdnetworks.com'

STAT_API_ROOT = '/rest/stat/'
CONFIG_API_ROOT = '/rest/config/'
PANTHER_API_ROOT = '/rest/pan/'
HLS_API_ROOT = '/rest/hls/'
FASTMON_API_ROOT = '/rest/fastmon/'
LDS_API_ROOT = '/rest/lds/'

API_ID = 'apiUserID'
API_PWD = 'apiUserPWD'

STAFF_REST_LOGIN_REQUIRED = (
    r'^rest/group/control-group',
    r'^rest/acl/ocsp',
)

CONTENT_API_SALT = "apiinterface@apiadmin"
PANTHER_MD5_SALT = 'scpinterface@cuiadmin'

if not config_constants.AURORA_PROD_HANDLER:
    CONTENT_API_URL = "contentsearch.cdnetworks.com"

    # Cloud Security 2.0 FireBlade API Information
    FIREBLADE_API_HOST = ''
    FIREBLADE_API_PUBLIC_KEY = 'c57168b8e2fc7356bd2cac3bd990d20b34caa270'
    FIREBLADE_API_SECRET_KEY = '99d5a93e83469d3b72555662525929dee4447581'
    FIREBLADE_API_TIMEOUT = 10

    # hls
    HLS_API_HOST = 'vhost.internal.cdnetworks.com'
    HLS_API_TIMEOUT = 5

    REDIS_SENTINEL_LOCATIONS = [
                "mymaster://127.0.0.1:26379",
                "mymaster://127.0.0.1:26379",
            ]
else :
    CONTENT_API_URL = "contentsearch.cdnetworks.com"

    # Cloud Security 2.0 FireBlade API Information
    FIREBLADE_API_HOST = 'https://api.fireblade.com/v1/cpanel/'
    FIREBLADE_API_PUBLIC_KEY = 'c57168b8e2fc7356bd2cac3bd990d20b34caa270'
    FIREBLADE_API_SECRET_KEY = '99d5a93e83469d3b72555662525929dee4447581'
    FIREBLADE_API_TIMEOUT = 10

    # hls
    HLS_API_HOST = 'hlsapi.cdnetworks.com'
    HLS_API_TIMEOUT = 5

    REDIS_SENTINEL_LOCATIONS = [
                "mymaster://api1.p59-icn.cdngp.net:26379",
                "mymaster://api2.p59-icn.cdngp.net:26379",
                "mymaster://ui2.p59-icn.cdngp.net:26379",
            ]

LAST_TRAFFIC_UPDATE_RATE = 85
PUSH_RATE_REDIS_CACHE_TTL = 60 * 60 * 24 #seconds
PUSH_RATE_THRESHOLD_COUNT = 60
PUSH_RATE_THRESHOLD_UNIT = 60 #minutes
REDIS_DEFAULT_TIMEOUT = 60

REDIS_CACHE_BACKEND = "spectrum_fe.shared_components.django_redis.cache.RedisCache"
REDIS_SENTINEL_OPTIONS = {
    "CLIENT_CLASS": "spectrum_fe.shared_components.utils.sentinel.SentinelClient"
}

CACHES = {
    'default': {
        'BACKEND': CACHE_BACKEND,
        'LOCATION': CACHE_LOCATIONS,
    },
    'redis': {
        'BACKEND': REDIS_CACHE_BACKEND,
        'LOCATION': REDIS_SENTINEL_LOCATIONS,
        'OPTIONS': REDIS_SENTINEL_OPTIONS,
    }
}

SESSION_ENGINE = "django.contrib.sessions.backends.cached_db"


LOGGING = {
        'version': 1,
        'disable_existing_loggers': True,
        'formatters': {
                    'verbose': {
                                'format': '%(levelname)s %(asctime)s %(name)s %(module)s %(process)d %(thread)d %(message)s'
                    },
                    'simple': {
                                'format': '%(levelname)s %(message)s'
                    },
        },
        'handlers': {
                    'null': {
                                'level':'DEBUG',
                                'class':'django.utils.log.NullHandler',
                    },
                    'logfile': {
                                'level':'DEBUG',
                                'class':'logging.handlers.TimedRotatingFileHandler',
                                'filename': '/usr/local/cdnet/logs/aurora_api/aurora_api.log',
#                                 'filename': 'D:/prism/aurora_api/aurora_api.log',
                                'when' : 'midnight',
                                'interval' : 1,
                                'backupCount' : 30,
                                'formatter': 'verbose',
                    },
                    'console':{
                                'level':'INFO',
                                'class':'logging.StreamHandler',
                                'formatter': 'simple',
                    },
                    'mail_admins': {
                                'level': 'ERROR',
                                'class': 'django.utils.log.AdminEmailHandler',
                                'include_html': True,
                    }
        },
        'loggers': {
                    'django': {
                                'handlers':['console'],
                                'propagate': True,
                                'level':'WARN',
                    },
                    'django.db.backends': {
                                'handlers': ['console', 'logfile'],
                                'level': 'DEBUG',
                                'propagate': False,
                    },
                    'aurora_api': {
                                'handlers': ['console', 'logfile', 'mail_admins'],
                                'level': 'INFO',
                    },
                    'aurora_fe': {
                                'handlers': ['null'],
                                'level': 'DEBUG',
                    },
                    'spectrum_fe': {
                                'handlers': ['null'],
                                'level': 'DEBUG',
                    },
        }
}

DEFAULT_THROTTLE_RATES = {
}