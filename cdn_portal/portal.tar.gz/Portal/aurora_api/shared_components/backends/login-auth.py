from django.contrib.auth.models import User

class LoginAuth(object):

    def authenticate(self, username=None, password=None):
        try:
            user = User.objects.get(username=username, password=password, is_active=True)
            return user
        except User.DoesNotExist, e:
            return None

        return user

    def get_user(self, user_id):
        try:
            return User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return None
