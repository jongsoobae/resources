from aurora_api import error_code
from aurora_api.utils import APIErrorResponse, APIException
from aurora_fe.shared_components.models.acl_core import CustomerAccountWrapper, \
    CustomerAccountHasPrivilege, AuthUserHasPrivilege, ControlGroup
from aurora_fe.shared_components.utils.account import get_account_wrapper_from_session, getSubAccountByResellerUser
from aurora_fe.shared_components.utils.privilege import checkPrivilege
from aurora_fe.shared_components.utils.stat import getControlGroupStatItem, \
    getNGPStatItemAsObject
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect
from django.conf import settings
from django.utils.translation import ugettext as _
from functools import wraps
from spectrum_fe.shared_components.models import StatMaster
from spectrum_fe.shared_components.models.api import StatApiKey
from spectrum_fe.shared_components.models.customer import CustomerAccount
from spectrum_fe.shared_components.models.portal_menu import MaterialGroup, \
    MaterialGroupCD
from spectrum_fe.shared_components.utils.api import getOptionalParams

def has_group_all_permission_key(api_key_list):
    """
    return boolean has_all_group_permission_key
    :param api_key_list: list
    :param material_group_key_names: queryset values
    :return:
    """
    material_group_codes = MaterialGroupCD.objects.filter(api_key_name__in=api_key_list)
    return material_group_codes.exists()

def get_material_infos_from_group(api_key_name):
    """
    return tuples
    :param material_group_codes: queryset
    :param api_key_name: given api key name from request
    :return:
    """
    material_no_list = None
    material_group_cd = None
    material_group_type = None
    material_group_codes = MaterialGroupCD.objects.filter(api_key_name=api_key_name)
    if material_group_codes.exists():
        material_group_cd = material_group_codes[0].material_group_cd
        material_no_set = MaterialGroup.objects.filter(material_group_cd=material_group_cd).values('material_no')
        material_no_list = [j.get('material_no') for j in material_no_set]
        material_group_type = material_group_codes[0].material_group_type
    return material_no_list, material_group_cd, material_group_type

def get_material_infos_from_statmaster(stat_list_set, api_key_list):
    material_no_list = None
    material_group_cd = None
    material_group_type = None
    try:
        material_no_set = stat_list_set.values('material_no').distinct()
        material_group_cd_set = MaterialGroup.objects.filter(material_no__in=material_no_set).values('material_group_cd').distinct()

        if material_group_cd_set.count() != 1 :
            raise Exception("Cann't query using multiple material_group")

        material_no_list = [i.get('material_no') for i in material_no_set]
        material_group_cd = material_group_cd_set[0].get('material_group_cd')

        material_group_codes = MaterialGroupCD.objects.filter(material_group_cd=material_group_cd)
        if material_group_codes.exists():
            material_group_type = material_group_codes[0].material_group_type
    except:
        pass
    return material_no_list, material_group_cd, material_group_type


def get_material_infos_from_control_group(control_group_id,account_no):
    material_no_list = None
    material_group_cd = None
    material_group_type = None
    try:
        control_group = ControlGroup.objects.get(pk=int(control_group_id))
        return control_group.get_granted_material_infos()
    except:
        return material_no_list, material_group_cd, material_group_type

def stat_api_param_required(func):
    """
    validate api parameters
    :param func:
    :return:
    """
    def _item_exist_check(request, *args, **kwargs):
        try :
            params = getOptionalParams(request)
            if None == params.get("cgId", None) or \
                    None == params.get("gmtCd", None) or \
                    None == params.get("cgType", None) or \
                    None == params.get("account_no", None) :
                return APIErrorResponse(request, error_code.INVALID_SESSION, "Session Parameter is not valid")
            return func(request, *args, **kwargs)
        except Exception as e:
            return APIException(request, error_code.TEMP_UNAVAILABLE, e)
    return _item_exist_check

def cs_config_api_param_required(func):
    """
    validate api parameters
    :param func:
    :return:
    """
    def _item_exist_check(request, *args, **kwargs):
        try :
            params = getOptionalParams(request)
            if None == params.get("cgId", None) or \
                    None == params.get("gmtCd", None) or \
                    None == params.get("cgType", None) or \
                    None == params.get("account_no", None) :
                return APIErrorResponse(request, error_code.INVALID_SESSION, "Session Parameter is not valid")
            return func(request, *args, **kwargs)
        except Exception as e:
            return APIException(request, error_code.TEMP_UNAVAILABLE, e)
    return _item_exist_check


def cs_config_api_key_check(func):
    """
    apikey is not necessary
    :param func:
    :return:
    """
    def _item_exist_check(request, *args, **kwargs):
        try :
            params = getOptionalParams(request)
            api_keys = params.get("apiKey", None)

            control_group_id = params.get("cgId", None)
            account_no = params.get("account_no", None)

            if api_keys is None:
                return APIErrorResponse(request, error_code.WRONG_INPUT, "apiKey is required")
            api_key_list = api_keys.split('|')
            # delete dup api_key
            api_key_list = list(set(api_key_list))
            if len(api_key_list) == 0:
                return APIErrorResponse(request, error_code.WRONG_INPUT, "invalid apiKey format")
            try:
                control_group = ControlGroup.objects.get(pk=control_group_id)
            except:
                return APIErrorResponse(request, error_code.WRONG_INPUT, "invalid cgID input")

            try:
                customer_account = CustomerAccount.objects.get(pk=int(account_no))
            except:
                return APIErrorResponse(request, error_code.WRONG_INPUT, "invalid account_no input")

            has_all_group_permission_key = has_group_all_permission_key(api_key_list)
            if has_all_group_permission_key:
                if len(api_key_list) > 1 :
                    return APIErrorResponse(request, error_code.WRONG_INPUT, "Can't use apiGroupKey with apiKey")
                material_no_list, material_group_cd, material_group_type = get_material_infos_from_group(api_key_list[0])
                stat_list = control_group.get_stat_id_list(material_group_type, material_no_list,
                                                             only_active=False, include_legacy_add_service=False)
            else:
                stat_list_set = StatMaster.all_objects.filter(stat_id__in=StatApiKey.objects.filter(
                                                                        api_key__in=api_key_list).values('stat_id'))
                stat_list = list(stat_list_set.values_list('stat_id',flat=True))
                if 0 == stat_list_set.count() or len(api_key_list) != len(stat_list):
                    return APIErrorResponse(request, error_code.WRONG_INPUT, "There is wrong apiKey")
                else :
                    material_no_list, material_group_cd, material_group_type = control_group.get_granted_material_infos(
                        stat_list_set=stat_list_set)

                    csStatObj = getControlGroupStatItem(control_group_id, isGetValid=False,
                                                        include_legacy_add_service=False)
                    auth_stat_list = [i.stat_id for i in csStatObj if i.material_no in material_no_list]

                    for i in stat_list :
                        if i not in auth_stat_list :
                            return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC,
                                                     "Invalid service access (exists one more unauthrized apikeys)")

            request.session['contract_stat'] = control_group.get_granted_customer_items().values_list("pk", flat=True)
            request.session['stat_list'] = stat_list
            request.session['stat_material_no'] = material_no_list
            request.session['stat_material_group_cd'] = material_group_cd
            request.session['stat_material_group_type'] = material_group_type
            request.session['customer_account'] = customer_account

            return func(request, *args, **kwargs)
        except Exception as e:
            return APIException(request, error_code.TEMP_UNAVAILABLE, e)
    return _item_exist_check


def stat_api_key_check(func):
    """
    apiKey is mandatory and required and bound to stat_master item.
    So in order to use stat api, there should be at least one stat_master item
    set request session after checking material group cd key. session will be used to check authorization
    :param func:
    :return:
    """
    def _item_exist_check(request, *args, **kwargs):
        try :
            params = getOptionalParams(request)
            api_keys = params.get("apiKey", None)
            control_group_id = params.get("cgId", None)
            account_no = params.get("account_no", None)

            if api_keys is None:
                return APIErrorResponse(request, error_code.WRONG_INPUT, "apiKey is required")

            api_key_list = api_keys.split('|')
            # delete dup api_key
            api_key_list = list(set(api_key_list))
            if len(api_key_list) == 0:
                return APIErrorResponse(request, error_code.WRONG_INPUT, "invalid apiKey format")

            has_all_group_permission_key = has_group_all_permission_key(api_key_list)

            material_no_list = None
            material_group_cd = None
            material_group_type = None
            try:
                customer_account = CustomerAccount.objects.get(pk=int(account_no))
            except:
                return APIErrorResponse(request, error_code.WRONG_INPUT, "invalid account_no input")

            if has_all_group_permission_key:
                if len(api_key_list) > 1 :
                    return APIErrorResponse(request, error_code.WRONG_INPUT, "Can't use apiGroupKey with apiKey")

                material_no_list, material_group_cd, material_group_type = get_material_infos_from_group(api_key_list[0])
                if material_no_list is None or material_group_type is None:
                    return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC, "There is no service to access")
                request.session['contract_stat'] = None

                stat_list = []
                if "NGP" == material_group_type:
                    stat_list = None
                elif "CS" == material_group_type or material_group_type == "LEGACY":
                    try:
                        control_group = ControlGroup.objects.get(pk=control_group_id)
                        if control_group.group_type == 1:
                            request.session['contract_stat'] = control_group.get_granted_customer_items().values_list("pk", flat=True)
                    except:
                        return APIErrorResponse(request, error_code.WRONG_INPUT, "Can't use apiGroupKey with apiKey")

                    stat_list = control_group.get_stat_id_list(material_group_type, material_no_list,
                                                             only_active=False, include_legacy_add_service=False)
                request.session['stat_list'] = stat_list
                request.session['stat_material_no'] = material_no_list
                request.session['stat_material_group_cd'] = material_group_cd
                request.session['stat_material_group_type'] = material_group_type
                request.session['customer_account'] = customer_account
            else :
                stat_list_set = StatMaster.all_objects.filter(stat_id__in=StatApiKey.objects.filter(api_key__in=api_key_list).values('stat_id'))
                stat_list = list(stat_list_set.values_list('stat_id',flat=True))

                if 0 == stat_list_set.count() or len(api_key_list) != len(stat_list):
                    return APIErrorResponse(request, error_code.WRONG_INPUT, "There is wrong apiKey")
                else :
                    try:
                        material_no_list, material_group_cd, material_group_type = get_material_infos_from_statmaster(
                        stat_list_set, api_key_list)
                    except Exception,e:
                        return APIErrorResponse(request, error_code.WRONG_INPUT,"Invalid service access (not support svc)")

                    if "NGP" == material_group_type and len(api_key_list) > 1 :
                        return APIErrorResponse(request, error_code.WRONG_INPUT,
                                                 "Cann't use multiple api key for NGP product")

                    auth_stat_list = []
                    if material_group_type in ["CS", "LEGACY"]:
                        csStatObj = getControlGroupStatItem(control_group_id,
                                                            isGetValid=False,
                                                            include_legacy_add_service=False)
                        auth_stat_list = [i.stat_id for i in csStatObj if i.material_no in material_no_list]
                    elif "NGP" == material_group_type :
                        ngpStatObj = getNGPStatItemAsObject(customer_account, False)
                        auth_stat_list = [i.stat_id for i in ngpStatObj if i.material_no in material_no_list]
                    for i in stat_list :
                        if i not in auth_stat_list :
                            return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC,
                                                     "Invalid service access (exists one more unauthrized apikeys)")

                    if "NGP" == material_group_type :
                        try:
                            request.session['stat_list'] = StatMaster.objects.get(pk=stat_list[0])
                        except:
                            request.session['stat_list'] = None
                    else :
                        request.session['stat_list'] = stat_list

                    request.session['stat_material_no'] = material_no_list
                    request.session['stat_material_group_cd'] = material_group_cd
                    request.session['stat_material_group_type'] = material_group_type
                    request.session['customer_account'] = customer_account
                    request.session['contract_stat'] = None

            return func(request, *args, **kwargs)
        except Exception as e:
            return APIException(request, error_code.TEMP_UNAVAILABLE, e)
    return _item_exist_check


def api_authority_required(material_group_type=[], material_group_cd=[]):
    """
    validate material_group_type or material_group_cd from with request session value
    :param material_group_type:
    :param material_group_cd:
    :return:
    """
    def inner_decorator(fn):
        def wrapped(request, *args, **kwargs):
            try :
                if request.session['stat_material_group_type'] in material_group_type or \
                                request.session['stat_material_group_cd'] in material_group_cd :
                    pass
                else :
                    return APIErrorResponse(request,
                                            error_code.NOT_SUPPORT_SVC,
                                            "Request API shouldn't use using %s:%s" % (request.session['stat_material_group_type'],
                                                                                       request.session['stat_material_group_cd']))

                return fn(request, *args, **kwargs)
            except Exception as e:
                return APIException(request, error_code.TEMP_UNAVAILABLE, e)
        return wraps(fn)(wrapped)
    return inner_decorator

def config_api_authority_required(material_group_cd=[]):
    """
    For now this function is used by only NGP configuration api
    :param material_group_cd:
    :return:
    """
    def inner_decorator(fn):
        def wrapped(request, *args, **kwargs):
            try :
                account_wrapper = get_account_wrapper_from_session(request)
                user_privileges = AuthUserHasPrivilege.objects.filter(auth_user_id=request.user, account_no=account_wrapper)
                has_permission = False
                allow_privilege_keys = []
                if user_privileges.count() > 0:
                    allow_privilege_keys = [p.privilege_id.privilege_key for p in user_privileges]
                    for material_cd in allow_privilege_keys:
                        if material_cd in material_group_cd:
                            has_permission = True
                            break

                    if has_permission:
                        pass
                    else:
                        return APIErrorResponse(request, error_code.NOT_SUPPORT_SVC, _("You do not have API access permission"))
                else:
                    return APIErrorResponse(request, error_code.NOT_SUPPORT_SVC, _("You do not have API access permission(-2)"))

                return fn(request, *args, **kwargs)
            except Exception as e:
                return APIException(request, error_code.TEMP_UNAVAILABLE, e)
        return wraps(fn)(wrapped)
    return inner_decorator

def api_privilege_authority_required(andPrivilegeMenus=[], orPrivilegeMenus=[]):
    def inner_decorator(fn):
        def wrapped(request, *args, **kwargs):

            if len(andPrivilegeMenus) > 0 and len(orPrivilegeMenus) > 0:
                return APIErrorResponse(request, error_code.NOT_ALLOWED_MENU, "Invalid menu authorization")

            userprofile = request.user.get_profile()
            if userprofile is None:
                return APIErrorResponse(request, error_code.NOT_ALLOWED_MENU, "Not allowed due to innsufficient user info")

            account_wrapper = get_account_wrapper_from_session(request)
            material_group_cd = request.session['stat_material_group_cd']
            access_granted = False
            if len(andPrivilegeMenus) > 0:
                mandatory_privilege_menus = ['%s_%s' % (material_group_cd, x) for x in andPrivilegeMenus]
                access_granted = userprofile.granted_with_mandatory_privilege_menu(mandatory_privilege_menus,account_wrapper)
            elif len(orPrivilegeMenus) > 0:
                optional_privilege_menus = ['%s_%s' % (material_group_cd, x) for x in orPrivilegeMenus]
                access_granted = userprofile.granted_with_optional_privilege_menu(optional_privilege_menus,account_wrapper)

            if not access_granted:
                return APIErrorResponse(request, error_code.NOT_ALLOWED_MENU, "Insufficient menu authorization")

            return fn(request, *args, **kwargs)

        return wraps(fn)(wrapped)
    return inner_decorator

def api_param_validate(func):
    def _item_exist_check(request, *args, **kwargs):
        try :
            params = getOptionalParams(request)

            if None == params.get("cgId", None) or \
                    None == params.get("gmtCd", None) or \
                    None == params.get("cgType", None) or \
                    None == params.get("account_no", None) :
                return APIErrorResponse(request, error_code.INVALID_SESSION, "Session Parameter is not valid")
            else:
                try:
                    try:
                        account = CustomerAccount.objects.get(pk=params.get("account_no", None))
                    except:
                        return APIErrorResponse(request, error_code.INVALID_SESSION, "account_no input is not valid")
                    request.session['customer_account'] = account
                    account_wrapper = get_account_wrapper_from_session(request)
                    user_privileges = AuthUserHasPrivilege.objects.filter(auth_user_id=request.user, account_no=account_wrapper)
                    if user_privileges.exists():
                        request.session['user_priv'] = [p.privilege_id.privilege_key for p in user_privileges]
                    else:
                        request.session['user_priv'] = []
                except:
                    return APIErrorResponse(request, error_code.INVALID_SESSION, "Session Parameter is not valid(2)")
            return func(request, *args, **kwargs)
        except Exception as e:
            return APIException(request, error_code.TEMP_UNAVAILABLE, e)
    return _item_exist_check
