from aurora_api import error_code
from aurora_api.settings import FASTMON_API_ROOT
from aurora_api.settings import STAT_API_ROOT
from aurora_api.settings import CONFIG_API_ROOT
from aurora_api.settings import PANTHER_API_ROOT
from aurora_api.settings import HLS_API_ROOT
from aurora_api.settings import LDS_API_ROOT

from aurora_api.utils import APIException, APIErrorResponse
from aurora_api.utils.regex import match_list, matches_any
from aurora_fe.shared_components.utils.aquacrypto import decrypt
from django.conf import settings
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from spectrum_fe.shared_components.utils.api import getOptionalParams
import re
import urllib


REST_STAFF_REQUIRED = match_list(getattr(settings, 'STAFF_REST_LOGIN_REQUIRED', []))
API_ROOT = getattr(settings, 'STAT_API_ROOT', "-1")

class AuthenticateUser(object):
    def process_request(self, request):
        try:
            params = getOptionalParams(request)
            if request.path.startswith(STAT_API_ROOT) or request.path.startswith(CONFIG_API_ROOT)\
                or request.path.startswith(PANTHER_API_ROOT) or request.path.startswith(HLS_API_ROOT) \
                or request.path.startswith(FASTMON_API_ROOT) \
                or request.path.startswith(LDS_API_ROOT):
                decryptedKey = decrypt(urllib.unquote(params.get("encData", None)))
                if decryptedKey:
                    try:
                        apiID = re.search('apiID=([^;]+);', decryptedKey).group(1)
                        apiPWD = re.search('apiPWD=([^;]+);', decryptedKey).group(1)
                    except:
                        decryptedKey = urllib.unquote(decryptedKey)
                        apiID = re.search('apiID=([^;]+);', decryptedKey).group(1)
                        apiPWD = re.search('apiPWD=([^;]+);', decryptedKey).group(1)

                    try :
                        username = re.search('username=([^;]+);', decryptedKey).group(1)
                        password = re.search('password=([^;]+);', decryptedKey).group(1)
                    except :
                        username = None
                        password = None

                    try :
                        user_id = re.search('user_id=([^;]+);', decryptedKey).group(1)
                    except :
                        user_id = None

                if apiID != settings.API_ID or apiPWD != settings.API_PWD :
                    if settings.DEBUG:
                        username = params.get('username', None)
                        password = params.get('password', None)
                        user_id = None
                    else:
                        return APIErrorResponse(request, error_code.INVALID_USERINFO, "Invalid Access")

                if user_id :
                    user = User.objects.get(pk=user_id)
                else :
                    user = authenticate(username=username, password=password, isApiLogin=True)

                if user:
                    if hasattr(request, 'user'):
                        request.user = user
                    return None
                else :
                    return APIErrorResponse(request, error_code.INVALID_USERINFO, "Invalid username or password")
            else:
                username = params.get('username', None)
                password = params.get('password', None)

                auth_user = authenticate(username=username, password=password, isApiLogin=True)

                if auth_user == None :
                    return APIErrorResponse(request, error_code.INVALID_USERINFO, "Invalid username or password")

                if (not auth_user.is_staff and matches_any(REST_STAFF_REQUIRED, request.path)):
                    return APIErrorResponse(request, error_code.INVALID_USERINFO, "Staff access only")

                if auth_user:
                    if hasattr(request, 'user'):
                        request.user = auth_user

                # login(request, auth_user)

                if request.user == None or not request.user.is_authenticated():
                    return APIErrorResponse(request, error_code.INVALID_USERINFO, "API Logon Fail")

            return None
        except Exception as e:
            return APIException(request, error_code.TEMP_UNAVAILABLE, e)
