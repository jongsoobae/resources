from aurora_fe.shared_components.models.pal_api import PalApi
from aurora_fe.shared_components.models.acl_core import LegacyAddService
from aurora_fe.shared_components.utils.common import get_monitoring_service_bl
from datetime import datetime

def data_legacy_mon(request, account_no, cg_id, gmt_cd, mode, service_name=""):
    ret_val = []
    service_list_string = ''
    if mode == 1:
        service = get_monitoring_service_bl(account_no, cg_id)
        for i in service:
            if service_list_string == '':
                service_list_string = "%s,%s,%s" % (i.add_svc_name, i.service_type_cd, mode)
            else:
                service_list_string = "%s:%s,%s,%s" \
                    % (service_list_string, i.add_svc_name, i.service_type_cd, mode)
    elif mode == 2:
        try:
            servoce = LegacyAddService.objects.get(add_svc_name=service_name)
            service_list_string = "%s,%s,%s" % (servoce.add_svc_name, servoce.service_type_cd, mode)
        except:
            pass
    palApi = PalApi(gmt_cd, service_list_string, cg_id)
    stats = palApi.get_json_data()

    if stats['returnMsg'] == 'Success':
        if mode == 1:
            for obj in stats['serviceList']:
                service_name = obj['serviceID']
                for val in obj['dataList']:
                    ret_val.append({'service' : service_name, 'currentConnected' : val['curConnectedPlayers'],
                                   'currentStream' : val['curStreamPlayers'],
                                   'currentBandwidth' : val['curPlayerBandWidth'],
                                   'peakConnected' : val['pkConnectedPlayers'],
                                   'peakStream': val['pkStreamPlayers'],
                                   'peakBandwidth' : val['pkPlayersBandWidth'],
                                   'totalConnected' : val['totConnectedPlayers'],
                                   'totStreamPlayers' : val['totStreamPlayers']})
        elif mode == 2:
            for obj in stats['serviceList']:
                service_name = obj['serviceID']
                for val in obj['dataList']:
                    ret_val.append({'dateTime' : datetime.strptime(val['dateCode'], '%Y-%m-%d %H:%M:%S.%f')\
                                    .strftime('%Y%m%d%H%M'),
                                   'currentConnected' : val['curConnectedPlayers'],
                                   'currentStream' : val['curStreamPlayers'],
                                   'currentBandwidth' : val['curPlayerBandWidth'],
                                   'peakConnected' : val['pkConnectedPlayers'],
                                   'peakStream': val['pkStreamPlayers'],
                                   'peakBandwidth' : val['pkPlayersBandWidth'],
                                   'totalConnected' : val['totConnectedPlayers'],
                                   'totStreamPlayers' : val['totStreamPlayers']})

    return ret_val
