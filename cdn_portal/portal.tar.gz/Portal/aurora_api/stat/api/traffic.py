from spectrum_fe.shared_components.utils.api import ApiHelper
from spectrum_fe.shared_components.utils.byte_conv_utils import timestamp_to_datetime
from spectrum_fe.shared_components.utils.common import log_error

def data_legacy_bandwidth_api(request, stat_ids, date_from, date_to, time_span, tz_offset):
    ret_val = []
    customer_stat_unit = []
    for stat_id in stat_ids:
        customer_stat_unit.append(stat_id.pk)

    try:
        params = {}
        params['tz_cd'] = tz_offset
        params['date_from'] = date_from.strftime('%Y-%m-%d')
        params['date_to'] = date_to.strftime('%Y-%m-%d')
        params['time_span'] = time_span
        params['customer_stat_unit'] = customer_stat_unit
        params['report_type'] = 'MB'

        api_url = 'report/legacy/traffic/totaltraffic/'
        api = ApiHelper()

        stats = api.request_api_server(request, api.CALL_TYPE['POST'], api_url, params)

        if stats['data']['factor'] == 'success':
            for i in stats['data']['items']['chart_data']['Edge']:
                ret_val.append({'dateTime' : timestamp_to_datetime(i[0]).strftime('%Y%m%d%H%M'), 'bandwidth' : i[1]})
    except Exception as e:
        log_error(None, api_url + ' - ' + str(params), e)
    return ret_val

def data_legacy_data_transferred_api(request, stat_ids, date_from, date_to, time_span, tz_offset):
    ret_val = []
    customer_stat_unit = []
    for stat_id in stat_ids:
        customer_stat_unit.append(stat_id.pk)

    try:
        params = {}
        params['tz_cd'] = tz_offset
        params['date_from'] = date_from.strftime('%Y-%m-%d')
        params['date_to'] = date_to.strftime('%Y-%m-%d')
        params['time_span'] = time_span
        params['customer_stat_unit'] = customer_stat_unit
        params['report_type'] = 'GB'

        api_url = 'report/legacy/traffic/totaltraffic/'
        api = ApiHelper()

        stats = api.request_api_server(request, api.CALL_TYPE['POST'], api_url, params)

        if stats['data']['factor'] == 'success':
            for i in stats['data']['items']['chart_data']['Edge']:
                ret_val.append({'dateTime' : timestamp_to_datetime(i[0]).strftime('%Y%m%d%H%M'),
                                'dataTransferred' : i[1]})
    except Exception as e:
        log_error(None, api_url + ' - ' + str(params), e)
    return ret_val

def data_legacy_bandwidth_by_service_api(request, stat_ids, date_from, date_to, tz_offset):
    ret_val = []
    customer_stat_unit = []
    for stat_id in stat_ids:
        customer_stat_unit.append(stat_id.pk)

    try:
        params = {}
        params['tz_cd'] = tz_offset
        params['date_from'] = date_from.strftime('%Y-%m-%d')
        params['date_to'] = date_to.strftime('%Y-%m-%d')
        params['time_span'] = '5'
        params['customer_stat_unit'] = customer_stat_unit

        api_url = 'report/legacy/traffic/trafficbyservice/'
        api = ApiHelper()

        stats = api.request_api_server(request, api.CALL_TYPE['POST'], api_url, params)

        if stats['data']['factor'] == 'success':
            for i in stats['data']['items']['table_data']['data']:
                ret_val.append({'url' : i.get('service'), 'min' : i.get('data_min'), 'max' : i.get('data_max'),
                                'avg' : i.get('data_avg'), '_95th' : i.get('data_95'),
                                'dataTransferred' : i.get('data_trans')})
    except Exception as e:
        log_error(None, api_url + ' - ' + str(params), e)
    return ret_val

def data_legacy_data_transferred_by_service_api(request, stat_ids, date_from, date_to, tz_offset):
    ret_val = []
    customer_stat_unit = []
    for stat_id in stat_ids:
        customer_stat_unit.append(stat_id.pk)

    try:
        params = {}
        params['tz_cd'] = tz_offset
        params['date_from'] = date_from.strftime('%Y-%m-%d')
        params['date_to'] = date_to.strftime('%Y-%m-%d')
        params['time_span'] = '5'
        params['customer_stat_unit'] = customer_stat_unit

        api_url = 'report/legacy/traffic/transferredbyservice/'
        api = ApiHelper()

        stats = api.request_api_server(request, api.CALL_TYPE['POST'], api_url, params)

        if stats['data']['factor'] == 'success':
            for i in stats['data']['items']['table_data']['data']:
                ret_val.append({'url' : i.get('service'), 
                                'dataTransferred' : i.get('data_trans')})
    except Exception as e:
        log_error(None, api_url + ' - ' + str(params), e)
    return ret_val

def data_legacy_peak_hits_api(request, stat_ids, date_from, date_to, time_span, tz_offset):
    ret_val = []
    customer_stat_unit = []
    for stat_id in stat_ids:
        customer_stat_unit.append(stat_id.pk)

    try:
        params = {}
        params['tz_cd'] = tz_offset
        params['date_from'] = date_from.strftime('%Y-%m-%d')
        params['date_to'] = date_to.strftime('%Y-%m-%d')
        params['time_span'] = time_span
        params['customer_stat_unit'] = customer_stat_unit

        api_url = 'report/legacy/traffic/originhits/'
        api = ApiHelper()

        stats = api.request_api_server(request, api.CALL_TYPE['POST'], api_url, params)

        if stats['data']['factor'] == 'success':
            for i in stats['data']['items']['chart_data']:
                ret_val.append({'dateTime' : timestamp_to_datetime(i[0]).strftime('%Y%m%d%H%M'), 'peakHits' : i[1]})
    except Exception as e:
        log_error(None, api_url + ' - ' + str(params), e)
    return ret_val
