from spectrum_fe.shared_components.utils.api import ApiHelper
from spectrum_fe.shared_components.utils.byte_conv_utils import timestamp_to_datetime
from spectrum_fe.shared_components.requests.packages.urllib3.packages.ordered_dict import OrderedDict
from spectrum_fe.shared_components.utils.common import log_error

def data_legacy_unique_visitors_api(request, stat_ids, date_from, date_to, time_span, tz_offset):
    ret_val = []
    customer_stat_unit = []
    for stat_id in stat_ids:
        customer_stat_unit.append(stat_id.pk)

    try:
        params = {}
        params['tz_cd'] = tz_offset
        params['date_from'] = date_from.strftime('%Y-%m-%d')
        params['date_to'] = date_to.strftime('%Y-%m-%d')
        params['time_span'] = time_span
        params['customer_stat_unit'] = customer_stat_unit

        api_url = 'report/legacy/visitor/uniquevisitors/'
        api = ApiHelper()

        stats = api.request_api_server(request, api.CALL_TYPE['POST'], api_url, params)

        if stats['data']['factor'] == 'success':
            for i in stats['data']['items']['chart_data']:
                ret_val.append({'dateTime' : timestamp_to_datetime(i[0]).strftime('%Y%m%d%H%M'),
                                'uniqueVisitors' : i[1]})
    except Exception as e:
        log_error(None, api_url + ' - ' + str(params), e)
    return ret_val

def data_legacy_response_code_api(request, stat_ids, date_from, date_to, time_span, tz_offset):
    ret_val = []
    customer_stat_unit = []
    for stat_id in stat_ids:
        customer_stat_unit.append(stat_id.pk)

    try:
        params = {}
        params['tz_cd'] = tz_offset
        params['date_from'] = date_from.strftime('%Y-%m-%d')
        params['date_to'] = date_to.strftime('%Y-%m-%d')
        params['time_span'] = time_span
        params['customer_stat_unit'] = customer_stat_unit

        api_url = 'report/legacy/visitor/edgeresponsecode/'
        api = ApiHelper()

        stats = api.request_api_server(request, api.CALL_TYPE['POST'], api_url, params)

        if stats['data']['factor'] == 'success':
            ret_val_dict = OrderedDict()
            for i in stats['data']['items']['chart_data']:
                if i.keys()[0] == 'OK hit 2XX':
                    for j0 in i[i.keys()[0]]:
                        ret_val_dict[j0[0]] = {}
                        ret_val_dict[j0[0]]['dateTime'] = timestamp_to_datetime(j0[0]).strftime('%Y%m%d%H%M')
                        ret_val_dict[j0[0]]['okHits'] = j0[1]
                elif i.keys()[0] == 'Permission 401':
                    for j1 in i[i.keys()[0]]:
                        ret_val_dict[j1[0]]['permissionHits'] = j1[1]
                elif i.keys()[0] == 'Not-Found 404':
                    for j2 in i[i.keys()[0]]: 
                        ret_val_dict[j2[0]]['notFoundHits'] = j2[1]
                elif i.keys()[0] == 'Server Error 5xx':
                    for j3 in i[i.keys()[0]]:
                        ret_val_dict[j3[0]]['serverErrorHits'] = j3[1]
                elif i.keys()[0] == 'Others':
                    for j4 in i[i.keys()[0]]:
                        ret_val_dict[j4[0]]['othersHits'] = j4[1]

            for key in ret_val_dict.keys():
                ret_val.append(ret_val_dict[key])
    except Exception as e:
        log_error(None, api_url + ' - ' + str(params), e)
    return ret_val

def data_legacy_avg_client_bandwidth_api(request, stat_ids, date_from, date_to, time_span, tz_offset):
    ret_val = []
    customer_stat_unit = []
    for stat_id in stat_ids:
        customer_stat_unit.append(stat_id.pk)

    try:
        params = {}
        params['tz_cd'] = tz_offset
        params['date_from'] = date_from.strftime('%Y-%m-%d')
        params['date_to'] = date_to.strftime('%Y-%m-%d')
        params['time_span'] = time_span
        params['customer_stat_unit'] = customer_stat_unit

        api_url = 'report/legacy/visitor/responsebandwidth/'
        api = ApiHelper()

        stats = api.request_api_server(request, api.CALL_TYPE['POST'], api_url, params)

        if stats['data']['factor'] == 'success':
            for i in stats['data']['items']['chart_data']:
                ret_val.append({'dateTime' : timestamp_to_datetime(i[0]).strftime('%Y%m%d%H%M'),
                                 'avgClientBandwidth' : i[1]})
    except Exception as e:
        log_error(None, api_url + ' - ' + str(params), e)
    return ret_val

def data_legacy_avg_client_browser_api(request, stat_ids, date_from, date_to):
    ret_val = []
    customer_stat_unit = []
    for stat_id in stat_ids:
        customer_stat_unit.append(stat_id.pk)

    try:
        params = {}
        params['date_from'] = date_from.strftime('%Y-%m-%d')
        params['date_to'] = date_to.strftime('%Y-%m-%d')
        params['time_span'] = 'daily'
        params['customer_stat_unit'] = customer_stat_unit

        api_url = 'report/legacy/visitor/browser/'
        api = ApiHelper()

        stats = api.request_api_server(request, api.CALL_TYPE['POST'], api_url, params)

        if stats['data']['factor'] == 'success':
            for i in stats['data']['items']['chart_data']:
                ret_val.append({'browserName' : i[0], 'totalHits' : i[1]})
    except Exception as e:
        log_error(None, api_url + ' - ' + str(params), e)
    return ret_val

def data_legacy_avg_client_os_api(request, stat_ids, date_from, date_to):
    ret_val = []
    customer_stat_unit = []
    for stat_id in stat_ids:
        customer_stat_unit.append(stat_id.pk)

    try:
        params = {}
        params['date_from'] = date_from.strftime('%Y-%m-%d')
        params['date_to'] = date_to.strftime('%Y-%m-%d')
        params['time_span'] = 'daily'
        params['customer_stat_unit'] = customer_stat_unit

        api_url = 'report/legacy/visitor/operatingsystem/'
        api = ApiHelper()

        stats = api.request_api_server(request, api.CALL_TYPE['POST'], api_url, params)

        if stats['data']['factor'] == 'success':
            for i in stats['data']['items']['chart_data']:
                ret_val.append({'osName' : i[0], 'totalHits' : i[1]})
    except Exception as e:
        log_error(None, api_url + ' - ' + str(params), e)
    return ret_val

def data_legacy_visitors_by_player_api(request, stat_ids, date_from, date_to):
    ret_val = []
    customer_stat_unit = []
    for stat_id in stat_ids:
        customer_stat_unit.append(stat_id.pk)

    try:
        params = {}
        params['date_from'] = date_from.strftime('%Y-%m-%d')
        params['date_to'] = date_to.strftime('%Y-%m-%d')
        params['time_span'] = 'daily'
        params['customer_stat_unit'] = customer_stat_unit

        api_url = 'report/legacy/visitor/player/'
        api = ApiHelper()

        stats = api.request_api_server(request, api.CALL_TYPE['POST'], api_url, params)

        if stats['data']['factor'] == 'success':
            for i in stats['data']['items']['table_data']['data']:
                ret_val.append({'playerName' : i['Player'], 'visitors' : i['Visitors'], 'ratio' : i['ratio']})
    except Exception as e:
        log_error(None, api_url + ' - ' + str(params), e)
    return ret_val

def data_legacy_visitors_by_isp_api(request, stat_ids, date_from, date_to):
    ret_val = []
    customer_stat_unit = []
    for stat_id in stat_ids:
        customer_stat_unit.append(stat_id.pk)

    try:
        params = {}
        params['date_from'] = date_from.strftime('%Y-%m-%d')
        params['date_to'] = date_to.strftime('%Y-%m-%d')
        params['time_span'] = 'daily'
        params['customer_stat_unit'] = customer_stat_unit

        api_url = 'report/legacy/visitor/top10isp/'
        api = ApiHelper()

        stats = api.request_api_server(request, api.CALL_TYPE['POST'], api_url, params)

        if stats['data']['factor'] == 'success':
            for i in stats['data']['items']['table_data']['data']:
                ret_val.append({'isp' : i['ISP'], 'totalHits' : i['TotalHits'], 'uniqueVisitors' : i['UniqueVisitors'],
                                'ratioVisitors' : i['ratio'], 'dataTransferred' : i['DataTransferred']})
    except Exception as e:
        log_error(None, api_url + ' - ' + str(params), e)
    return ret_val

def data_legacy_visitors_by_location_api(request, stat_ids, date_from, date_to, location_range, country_name):
    ret_val = []
    customer_stat_unit = []
    for stat_id in stat_ids:
        customer_stat_unit.append(stat_id.pk)

    try:
        params = {}
        params['date_from'] = date_from.strftime('%Y-%m-%d')
        params['date_to'] = date_to.strftime('%Y-%m-%d')
        params['time_span'] = 'daily'
        params['customer_stat_unit'] = customer_stat_unit
        params['location_range'] = location_range
        params['country'] = country_name
        params['state'] = ''

        api_url = 'report/legacy/visitor/location/'
        api = ApiHelper()

        stats = api.request_api_server(request, api.CALL_TYPE['POST'], api_url, params)

        if stats['data']['factor'] == 'success':
            seq = 0
            for i in stats['data']['items']['table_data']['data']:
                seq = seq+1
                ret_val.append({'rank' : seq, 'location' : i['Location'], 'totalHits' : i['TotalHits'],
                                'succHits' : i['OKHits'], 'failHits' : i['ErrorHits'],
                                'uniqueVisitors' : i['UniqueVisitors'], 'dataTransferred' : i['DataTransferred']})
    except Exception as e:
        log_error(None, api_url + ' - ' + str(params), e)
    return ret_val
