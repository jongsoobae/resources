import os
if os.environ.get('DJANGO_SETTINGS_MODULE') is None:
    os.environ['DJANGO_SETTINGS_MODULE'] = 'aurora_api.settings'

import json
import unittest

from django.test import Client

# [AURORAUI-3133]
class TestTrafficCacheHitRatio(unittest.TestCase):

    def setUp(self):
        self.client = Client()
        self.fixture_user = 'hwaeun.seo@cdnetworks.com'
        self.fixture_digest = 'NFkDsYWCbr6v56yYc8vv3eZBirpHNEXCjOg0SuHd5OXFIW1MavE3Uz%2FHey4VMm54'
        self.fixture_control_group_id = '6085'
        self.fixture_control_group_type = '0'
        self.fixture_gmt_code = 'GMT_15'
        self.fixture_account_no = '0000001000'
        self.fixture_api_key_all = 'SERVICECATEGORY_CA'
        self.fixture_api_key = '37EBBE307EAA82907DAD0B35DCC873CF'


    def test_traffic_cache_hit_ratio(self):
        date_from = '2016-12-01'
        date_to = '2016-12-01'

        param = {
            'apiKey' : self.fixture_api_key_all,
            'encData': self.fixture_digest,
            'cgId': self.fixture_control_group_id,
            'gmtCd': self.fixture_gmt_code,
            'cgType': self.fixture_control_group_type,
            'account_no': self.fixture_account_no,
            'date_from': date_from,
            'date_to': date_to,
            'time_period': 'hourly',
        }

        param_string = '&'.join([
            '%s=%s' % (key, param[key]) for key in param.keys()
        ])

        api_url = '%(endpoint_url)s?%(param_string)s' % {
            'endpoint_url': '/rest/stat/traffic/cacheHitRatio',
            'param_string': param_string
        }

        response = self.client.get(api_url)
        response_json = json.loads(response.content)

        self.assertEqual(response.status_code, 200)
        self.assertIn('totalAvg', response_json.keys())
