import json
import unittest

from django.test import Client
from django.contrib.auth.models import User

from aurora_fe.shared_components.models.acl_core import AuthUserHasPrivilege
from aurora_fe.shared_components.models.acl_core import ControlGroup
from aurora_fe.shared_components.utils.common import getGmtCdByAccountNo


class TestStatStorageInfoAPI(unittest.TestCase):

    def setUp(self):
        self.client = Client()
        self.fixture_user = 'test_storage_88brothers@aurora.com'
        self.fixture_digest = 'NFkDsYWCbr6v56yYc8vv3eZBirpHNEXCjOg0SuHd5OUHcUgdQtgZyT1rPjlmsGlz'
        self.fixture_control_group_id = '5635'
        self.fixture_control_group_type = '1'
        self.fixture_gmt_code = 'GMT_61'
        self.fixture_account_no = '0000044944'
        self.fixture_api_key_all = 'SERVICECATEGORY_STORAGE'
        self.fixture_api_key = 'AB440914D3EB656FB8F0EC45966B1B76' # 88brothers

    def test_fixture_is_valid(self):

        # assertion of api user
        user = User.objects.get(username=self.fixture_user)
        auth_user_has_privilege = AuthUserHasPrivilege.objects.filter(auth_user_id=user.id)

        # assertion of user account_no
        account_no = auth_user_has_privilege[0].account_no
        for privilege in auth_user_has_privilege:
            self.assertEqual(account_no, privilege.account_no)

        self.assertEqual(int(self.fixture_account_no), int(account_no.account_no))

        # assertion of control_group
        control_group = ControlGroup.objects.get(
            account_no=self.fixture_account_no,
            control_group_id=self.fixture_control_group_id)

        self.assertEqual(int(control_group.group_type), int(self.fixture_control_group_type))

        # assertion customer account's gmt code
        self.assertEqual(self.fixture_gmt_code, getGmtCdByAccountNo(self.fixture_account_no))

    def test_stat_storage_info_all_api_with_fixture_user(self):

        param = {
            'apiKey' : self.fixture_api_key_all,
            'encData': self.fixture_digest,
            'cgId': self.fixture_control_group_id,
            'gmtCd': self.fixture_gmt_code,
            'cgType': self.fixture_control_group_type,
            'account_no': self.fixture_account_no
        }

        param_string = '&'.join([
            '%s=%s' % (key, param[key]) for key in param.keys()
        ])

        api_url = '%(endpoint_url)s?%(param_string)s' % {
            'endpoint_url': '/rest/stat/storage/detail',
            'param_string': param_string
        }

        response = self.client.get(api_url)
        response_json = json.loads(response.content)
        response_storage = response_json.get('data')

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response_json.get('returnCode'), 0)
        self.assertEqual(response_json.get('returnMsg'), 'Success')
        self.assertEqual(type(response_storage), list)

        for item in response_storage:
            self.assertIsNotNone(item.get('sID'))
            self.assertIsNotNone(item.get('sName'))
            self.assertIsNotNone(item.get('clusterCount'))
            self.assertIsNotNone(item.get('clusterName'))

    def test_stat_storage_info_api_with_fixture_user(self):

        param = {
            'apiKey' : self.fixture_api_key,
            'encData': self.fixture_digest,
            'cgId': self.fixture_control_group_id,
            'gmtCd': self.fixture_gmt_code,
            'cgType': self.fixture_control_group_type,
            'account_no': self.fixture_account_no
        }

        param_string = '&'.join([
            '%s=%s' % (key, param[key]) for key in param.keys()
        ])

        api_url = '%(endpoint_url)s?%(param_string)s' % {
            'endpoint_url': '/rest/stat/storage/detail',
            'param_string': param_string
        }

        response = self.client.get(api_url)
        response_json = json.loads(response.content)
        response_storage = response_json.get('data')

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response_json.get('returnCode'), 0)
        self.assertEqual(response_json.get('returnMsg'), 'Success')
        self.assertEqual(type(response_storage), list)

        for item in response_storage:
            self.assertIsNotNone(item.get('sID'))
            self.assertIsNotNone(item.get('sName'))
            self.assertIsNotNone(item.get('clusterCount'))
            self.assertIsNotNone(item.get('clusterName'))
