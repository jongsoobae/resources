
import json
import unittest

from django.test import Client


class TestAverageDownloadSpeedApi(unittest.TestCase):

    def setUp(self):

        self.client = Client()
        self.fixture_user = 'qiniutek-apitestuser-01@cdnetworks.com'
        self.fixture_digest = 'NFkDsYWCbr6v56yYc8vv3eZBirpHNEXCjOg0SuHd5OUSxumYyVK0Y9jvoEklZO9d'
        self.fixture_control_group_id = '1985'
        self.fixture_control_group_type = '0'
        self.fixture_gmt_code = 'GMT_20'
        self.fixture_account_no = '0000043038'

        self.default_param = {
            'encData': self.fixture_digest,
            'cgId': self.fixture_control_group_id,
            'gmtCd': self.fixture_gmt_code,
            'cgType': self.fixture_control_group_type,
            'account_no': self.fixture_account_no,
        }

    def get_api_url(self, request_param):
        request_param.update(self.default_param)

        param_string = '&'.join([
            '%s=%s' % (key, request_param[key]) for key in request_param.keys()
        ])

        api_url = '%(endpoint_url)s?%(param_string)s' % {
            'endpoint_url': '/rest/stat/visitors/avgClientDownloadSpeed',
            'param_string': param_string
        }

        return api_url

    def test_invalid_parameter_exception(self):

        # only api key params
        invalid_api_url_a = self.get_api_url({
            'apiKey': '101E68B273FBCD12198714C4BE8C36C4'
        })

        response = self.client.get(invalid_api_url_a)
        response_dict = json.loads(response.content)

        return_code = response_dict.get('returnCode')
        self.assertEqual(return_code, 105)

    def test_wrong_parameter_exception(self):

        # wrong category value
        invalid_api_url = self.get_api_url({
            'apiKey': '101E68B273FBCD12198714C4BE8C36C4',
            'location_type': 'asdf'
        })

        response = self.client.get(invalid_api_url)
        response_dict = json.loads(response.content)

        return_code = response_dict.get('returnCode')
        self.assertEqual(return_code, 105)

    def test_wrong_datetime_exception(self):

        # wrong datetime format
        invalid_api_url_a = self.get_api_url({
            'apiKey': '101E68B273FBCD12198714C4BE8C36C4',
            'location_type': 'pop',
            'country_code': '',
            'date_from': '20161001',
            'date_to': '2016-10-01'
        })

        response = self.client.get(invalid_api_url_a)
        response_dict = json.loads(response.content)

        return_code = response_dict.get('returnCode')
        self.assertEqual(return_code, 105)

        # wrong datetime range
        invalid_api_url_b = self.get_api_url({
            'apiKey': '101E68B273FBCD12198714C4BE8C36C4',
            'location_type': 'pop',
            'country_code': '',
            'date_from': '2016-10-02',
            'date_to': '2016-10-01'
        })

        response = self.client.get(invalid_api_url_b)
        response_dict = json.loads(response.content)

        return_code = response_dict.get('returnCode')
        self.assertEqual(return_code, 105)

    def test_no_data(self):

        api_url = self.get_api_url({
            'apiKey': '101E68B273FBCD12198714C4BE8C36C4',
            'location_type': 'pop',
            'country_code': '',
            'date_from': '2016-10-01',
            'date_to': '2016-10-07'
        })

        response = self.client.get(api_url)
        response_dict = json.loads(response.content)

        print response_dict
        return_code = response_dict.get('returnCode')
        self.assertEqual(return_code, 404)
