from django.conf.urls.defaults import patterns, url

urlpatterns = patterns('aurora_api.stat.views.common',
    url(r'^getUserInfo$', 'getUserInfo'),
    url(r'^getApiKeyList', 'getApiKeyList'),
    url(r'^getCdnEdgeList$', 'getCdnEdgeList'),
)

# CS and Legacy Traffic
urlpatterns += patterns('aurora_api.stat.views.traffic',
    url(r'^traffic/totalTraffic$', 'getTotalTraffic', name='getTotalTraffic'),
    url(r'^traffic/pageViews$', 'getPageViews', name='getPageViews'),
    url(r'^traffic/activeConnection$', 'getActiveConnection', name='getActiveConnection'),
    url(r'^traffic/totalHits$', 'getTotalHits', name='getTotalHits'),
    url(r'^traffic/totalHitsByReturnCode$', 'getTotalHitsByReturnCode',
         name='getTotalHitsByReturnCode'),
    url(r'^traffic/perzoneTraffic$', 'getPerzoneTraffic', name='getPerzoneTraffic'),
    url(r'^traffic/byService$', 'get_by_service', name='get_by_service'),
    url(r'^traffic/cacheHitRatio$', 'get_cache_hit_ratio', name='get_cache_hit_ratio'),
    url(r'^traffic/dynamicStaticTraffic$', 'get_dynamic_static_traffic',
         name='get_dynamic_static_traffic'),
    url(r'^traffic/bandwidth$', 'get_bandwith', name='get_bandwidth'),
    url(r'^traffic/dataTransferred$', 'get_data_transferred', name='get_data_transferred'),
)

# CS and Legacy Visitor
urlpatterns += patterns('aurora_api.stat.views.visitor',
    url(r'^visitors/uniqueVisitor$', 'getUniqueVisitor', name='getUniqueVisitor'),
    url(r'^visitors/avgClientBandwidth$', 'getAvgClientBandwidth', name='getAvgClientBandwidth'),
    url(r'^visitors/avgClientUploadBandwidth$', 'getAvgClientUploadBandwidth',
         name='getAvgClientUploadBandwidth'),
    url(r'^visitors/avgClientBrowser$', 'getAvgClientBrowser', name='getAvgClientBrowser'),
    url(r'^visitors/avgClientOS$', 'getAvgClientOS', name='getAvgClientOS'),
    url(r'^visitors/visitorsByLocation$', 'getVisitorsByLocation', name='getVisitorsByLocation'),
    url(r'^visitors/visitorsByIsp$', 'get_visitors_by_isp', name='get_visitors_by_isp'),
    url(r'^visitors/responseCode$', 'get_visitors_response_code', name='get_visitors_response_code'),
    url(r'^visitors/visitorsByPlayer', 'get_visitors_by_player', name='get_visitors_by_player'),
    url(r'^visitors/visitorsByHTTPVersion', 'getVisitorsHTTPVersion', name='getVisitorsHTTPVersion'),

)

urlpatterns += patterns(
    'aurora_api.stat.views.download_speed',
    url(
        regex=r'^visitors/avgClientDownloadSpeed$',
        view='api_get_average_client_download_speed',
        name='api_get_average_client_downlaod_speed_view'
    ),
)

# CS and Legacy Content
urlpatterns += patterns('aurora_api.stat.views.content',
    url(r'^content/topContent$', 'getContent', name='getContent'),
    url(r'^content/topDirectory$', 'getDirectory', name='getDirectory'),
    url(r'^content/topContent/detail$', 'get_content_detail', name='get_content_detail'),
    url(r'^content/topDirectory/detail$', 'get_directory_detail', name='get_directory_detail'),
    url(r'^content/contentFailedResponseCode$', 'get_content_failed_response_code',
        name='get_content_failed_response_code'),
    url(r'^content/contentFailedResponseCode/detail$', 'get_content_failed_response_code_detail',
        name='get_content_failed_response_code_detail'),
    url(r'^content/contentResponseCode$', 'get_content_response_code', name='get_content_response_code'),
    url(r'^content/contentResponseCode/detail$', 'get_content_response_code_detail',
        name='get_content_response_code_detail'),
    url(r'^content/contentPlayRate$', 'get_content_play_rate', name='get_content_play_rate'),
    url(r'^content/contentPlayRate/detail$', 'get_content_play_rate_detail', name='get_content_play_rate_detail'),
)

# Legacy Monitoring
urlpatterns += patterns('aurora_api.stat.views.monitoring',
    url(r'^monitoring/currentSummary$', 'get_current_summary', name='get_current_summary'),
    url(r'^monitoring/currentSummary/detail$', 'get_current_summary_detail', name='get_current_summary_detail'),
)

# Dynamic Network Acceleration
urlpatterns += patterns('aurora_api.stat.views.dna',
    url(r'^overallTraffic/connections$', 'getConnections', name='getConnections'),
    url(r'^overallTraffic/dataTransferred$', 'getDataTransferred', name='getDataTransferred'),
    url(r'^overallTraffic/errorConnections', 'getErrorConnections', name='getErrorConnections'),
    url(r'^byLocation/byLocationContinent', 'getByLocationContinent', name='getByLocationContinent'),
)

# Cloud DNS, Cloud DNS-D
urlpatterns += patterns('aurora_api.stat.views.dns',
    url(r'^overallTraffic/requests', 'getRequests', name='getRequests'),
    url(r'^overallTraffic/responseTypes', 'getResponseTypes', name='getResponseTypes'),
    url(r'^overallTraffic/processTime$', 'getProcessTime', name='getProcessTime'),
    url(r'^byRecordTypes/hitsByRecordTypes$', 'getHitsByRecordTypes', name='getHitsByRecordTypes'),
)

# Cloud Storage
urlpatterns += patterns('aurora_api.stat.views.storage',
    url(r'^storage/usage$', 'getStorageUsage', name='getStorageUsage'),
    url(r'^storage/detail$', 'getStorageDetail', name='getStorageDetail'),
)

urlpatterns += patterns('aurora_api.stat.views.common',
    url(r'^contractItems$', 'getContractItems', name='getContractItems'),
    url(r'^contractBasedDataTransferred$', 'getContractBasedDataTransferred', name='getContractBasedDataTransferred'),
    url(r'^byLocation/byLocation$', 'getByLocation', name='getByLocation'),
    url(r'^contractStorage/usage$', 'get_contract_storage_usage',
         name='get_contract_storage_usage'),

)
