from aurora_api import error_code
from aurora_api.shared_components.decorators import stat_api_param_required, \
    stat_api_key_check, api_authority_required, api_privilege_authority_required
from aurora_api.stat.views.dna import getStats as dna_getStats
from aurora_api.stat.views.dns import getStats as dns_getStats
from aurora_api.utils import APIResponse, APIException, APIErrorResponse
from aurora_fe.shared_components.backends.account import getUserByUserId
from aurora_fe.shared_components.models import UserProfile
from aurora_fe.shared_components.models.acl_core import CustomerAccountWrapper, \
    ControlGroup, AuthUserHasControlGroup, CustomerAccountHasPrivilege, StatItemWhiteList
from aurora_fe.shared_components.models.common_code import GMTCD
from aurora_fe.shared_components.utils.account import \
    getSubAccountByResellerUser
from aurora_fe.shared_components.utils.privilege import checkPrivilege
from aurora_fe.shared_components.utils.stat import getControlGroupStatItem, \
    getNGPStatItemAsObject, NGPStatItemObject
from aurora_fe.shared_components.utils.control_group import \
    getControlGroupByStorageAccountAsObject
from aurora_fe.storage.views.storage import get_data_result_by_request_api
from datetime import datetime, timedelta
from django.views.decorators.csrf import csrf_exempt
from spectrum_fe.cs_reports.models.erp_contract import getErp_contract
from spectrum_fe.cs_reports.models.traffic import get_data_per_zone_traffic, \
    get_data_total_traffic, get_data_per_zone_shield_traffic
from spectrum_fe.shared_components.models.api import StatApiKey
from spectrum_fe.shared_components.models.customer import CustomerAccount, \
    CustomerItem, SFAZone
from spectrum_fe.shared_components.models.portal_menu import MaterialGroup, \
    MaterialGroupCD
from spectrum_fe.shared_components.utils.api import getOptionalParams
from spectrum_fe.shared_components.utils.byte_conv_utils import \
    generate_null_traffic
from operator import itemgetter
import urllib

GET_CND_BLOCKIP_SOURCE = "https://melon.cdnetworks.com/network/ipms/api/get_cdn_subnet.jsp"

@csrf_exempt
def getUserInfo(request):
    """
    if customer_info is empty, openapi will deny login
    :param request:
    :return:
    """
    try:
        user = getUserByUserId(request.user.pk)
        userProfile = UserProfile.objects.get(user=user.pk)
        user_info = userProfile.get_user_info_for_open_api()
        customer_info = userProfile.get_customer_info_for_open_api()
        return APIResponse(request, {"userInfo": user_info, 'customInfo': customer_info })
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
def getApiKeyList(request):
    try :
        params = getOptionalParams(request)
        control_group_id = params.get("cgId")
        account_no = params.get("account_no")
        csStatObj = getControlGroupStatItem(control_group_id,
                                            isGetValid=False,
                                            include_legacy_add_service=False)
        account_wrapper = CustomerAccountWrapper.objects.get(pk=int(account_no))
        ngpStatObj = getNGPStatItemAsObject(account_wrapper, False)
        stat_ids = []
        try:
            control_group = ControlGroup.objects.get(pk=control_group_id)
            if control_group.group_type == 2:
                stat_ids = StatItemWhiteList.objects.filter(control_group_id=control_group_id).values_list('stat_id',
                                                                                                           flat=True)
        except:
            pass

        csStat = [i.stat_id for i in csStatObj]
        ngpStat = [i.stat_id for i in ngpStatObj if i.stat_id in stat_ids]

        csStat = StatApiKey.objects.filter(stat_id__in=csStat)\
                    .extra(
                           select={
                                'domain' :'SELECT domain FROM cs_stat_master WHERE statmaster_id = stat_master.stat_id \
                                           UNION \
                                           SELECT stat_svc_name FROM legacy_stat_master \
                                           WHERE statmaster_id = stat_master.stat_id LIMIT 1',
                                'material_group_name' : 'SELECT material_group_name \
                                            FROM material_group_cd INNER JOIN material_group \
                                            ON material_group_cd.material_group_cd=material_group.material_group_cd \
                                            WHERE material_group.material_no=stat_master.material_no'
                           }
                    ).values('api_key', 'stat_id__material_no', 'domain', 'material_group_name')

        ngpStat = StatApiKey.objects.filter(stat_id__in=ngpStat)\
                    .extra(
                           select={
                                'domain':'display_name',
                                'material_group_name' : 'SELECT material_group_name  \
                                            FROM material_group_cd INNER JOIN material_group \
                                            ON material_group_cd.material_group_cd=material_group.material_group_cd \
                                            WHERE material_group.material_no=stat_master.material_no'
                           }
                    ).values('api_key', 'stat_id__material_no', 'domain', 'material_group_name')

        sortedCsStat = sorted(list(csStat), key=itemgetter('stat_id__material_no'))
        sortedNgpStat = sorted(list(ngpStat), key=itemgetter('stat_id__material_no'))

        mergedStat = []
        mergedStat.extend(sortedCsStat)
        mergedStat.extend(sortedNgpStat)

        apiGroupKeyCheck = []
        apiKeyNameCheck = []
        apiGroupKeyData = []
        apiKeyData = []

        api_key_name = None

        for i in mergedStat :
            if i.get('stat_id__material_no') not in apiGroupKeyCheck :
                apiGroupKeyCheck.append(i.get('stat_id__material_no'))
                api_key_name = MaterialGroupCD.objects.get(pk=MaterialGroup.objects.get(material_no=
                                                        i.get('stat_id__material_no')).material_group_cd).api_key_name

                if api_key_name in apiKeyNameCheck :
                    apiKeyData.append({'type':1, 'serviceName':i.get('domain'), 'apiKey':i.get('api_key'),
                                        'parentApiKey': api_key_name})
                    continue

                apiKeyNameCheck.append(api_key_name)
                apiGroupKeyData.append({'type':0, 'serviceName':i.get('material_group_name'), 'apiKey':api_key_name,
                                         'parentApiKey': api_key_name})

            apiKeyData.append({'type':1, 'serviceName':i.get('domain'), 'apiKey':i.get('api_key'),
                                'parentApiKey': api_key_name})

        if len(mergedStat) == 0:
            try:
                control_group = ControlGroup.objects.get(pk=control_group_id)
                apiGroupKeyData = control_group.get_api_key_infos_for_config_api()
            except Exception,e:
                return APIErrorResponse(request, error_code.NO_DATA, "There is no available api keys.")

        if len(apiKeyData) == 0:
            if len(apiGroupKeyData) == 0:
                return APIErrorResponse(request, error_code.NO_DATA, "There is no available api keys")
            else:
                return APIResponse(request, {'data':apiGroupKeyData})
        else:
            apiGroupKeyData.extend(apiKeyData)
            return APIResponse(request, {'data':apiGroupKeyData})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_cd=['CD', 'DA'])
@api_privilege_authority_required(andPrivilegeMenus=['REPORT'])
def getByLocation(request):
    try :
        params = getOptionalParams(request)
        cg_id = params.get('cgId')
        # tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        # tz_offset = get_customer(request).tz_offset
        tz_offset = 0

        date_from = datetime.strptime(params.get('fromDate'),
                                      '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)
        date_to = datetime.strptime(params.get('toDate'),
                                     '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)

        mtNum = request.session['stat_material_no']

        mtCD = MaterialGroup.objects.get(material_no__in=mtNum).material_group_cd

        # DA -> 1197
        # CD -> 1182
        # DD -> 1284
        if mtCD == "DA" :
            stats = dna_getStats(request, date_from, date_to, tz_offset, "location", 0, request.session['stat_list'], cg_id=cg_id)
        elif mtCD == "CD" :
            stats = dns_getStats(request, date_from, date_to, tz_offset, "location", 0, request.session['stat_list'], cg_id=cg_id)
        else :
            return APIErrorResponse(request, error_code.WRONG_API_KEY, "Wrong API Key..")

        if stats == None :
            return APIErrorResponse(request, error_code.TEMP_UNAVAILABLE, "Get DNS Stats Fail...")

        if stats.count() == 0 :
            return APIErrorResponse(request, error_code.NO_DATA, "No DATA")

        data = []

        if mtCD == "DA" :
            if stats :
                for s in stats:
                    try:
                        country = s['location__region__country__country_name']
                        if (country == ''):
                            country = "Unknown"
                    except:
                        country = '-'

                    data.append({'location':country,
                        'newConns':s['agg_hits'],
                        'activeConns':s['agg_conn_snapshot'],
                        'inBound':s['agg_bytes_in'],
                        'outBound':s['agg_bytes_out']})
        else :
            if stats :
                for s in stats:
                    try:
                        country = s['location__region__country__country_name']
                        if (country == ''):
                            country = "Unknown"
                    except:
                        country = '-'

                    data.append({'location':country,
                        'hits':s['agg_hits']})

        return APIResponse(request, {
            'returnCode':error_code.SUCCESS,
            'data': data,
            'material_no': mtNum[0],
        })

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)




@csrf_exempt
@stat_api_param_required
def getContractItems(request):
    try :
        params = getOptionalParams(request)

        cg = ControlGroup.objects.get(pk=params.get("cgId"))
        cgType = cg.group_type
        acNo = params.get("account_no")

        if cgType != 0 and cgType != 1 : #customized controlgroup
            return APIErrorResponse(request, error_code.WRONG_INPUT,
                   "Only Can use Predefined - Customer or Predefined - Contract control group.")

        contractItems = CustomerAccount.objects.get(pk=int(acNo)).getContractItems()

        data = []

        for ci in contractItems :
            if cgType == 1 and ci.get('item_id') != cg.item_id.pk:
                continue

            isTrial = 0
            isPerZone = 0
            isShield = 0
            isDynamic = 0

            erpContractInfo = getErp_contract("%s-%s" % (str(ci.get('contract__contract_no')),
                                                          ci.get('item_no')))

            if len(erpContractInfo) == 0 :
                continue;
            else :
                erpContractInfo = erpContractInfo[0]

            if erpContractInfo.get('perzone_yn') == 'Y' :
                isPerZone = 1
            if erpContractInfo.get('dynamic_yn') == 'Y':
                    isDynamic = 1
            if erpContractInfo.get('shield_yn') == 'Y':
                    isShield = 1
            if 'YC1' == ci.get('contract__contract_type') :
                isTrial = 1

            data.append({
                         'customerName': ci.get('contract__account__account_name_local').strip(),
                         'contractName': ci.get('contract__contract_name').strip(),
                         'contractItemNo': "%s-%s" % (str(ci.get('contract__contract_no')).rjust(10, '0'),
                                                      ci.get('item_no')),
                         'contractItemCode': str(ci.get('material_no')).rjust(18, '0'),
                         'trial': isTrial,
                         'perZone': isPerZone,
                         'shield': isShield,
                         'dynamic': isDynamic,
                         })

        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':data})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
def getContractBasedDataTransferred(request) :
    try :
        params = getOptionalParams(request)

        tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh

        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')

        contractNo = params.get("contractNo")

        if contractNo == None or contractNo == "" :
            contractNo = "ALL"

        cg = ControlGroup.objects.get(pk=params.get("cgId"))
        cgType = cg.group_type

        acNo = int(params.get("account_no"))

        if cgType != 0 and cgType != 1 :
            return APIErrorResponse(request, error_code.WRONG_INPUT,
                   "Only Can use Predefined - Customer or Predefined - Contract control group.")

        if cgType == 1 :
            mgGroupCD = MaterialGroup.objects.get(material_no=cg.item_id.material_no)

            req_Privilege_name = '%s_%s' % (mgGroupCD.material_group_cd, 'TRAFFIC')

            hasMenuAuth = checkPrivilege(request.user.pk, acNo, req_Privilege_name)

            if hasMenuAuth == False :
                try :
                    subAccNos = getSubAccountByResellerUser(request.user.pk)
                    if acNo in subAccNos :
                        parentAcNo = ControlGroup.objects.get(account_no=acNo, group_type=0,
                                                               use_flag=1).parent_account_no.pk
                        hasMenuAuth = checkPrivilege(request.user.pk, parentAcNo,
                                                      req_Privilege_name)
                except Exception as e:
                    pass

            if hasMenuAuth == False :
                return APIErrorResponse(request, error_code.NOT_ALLOWED_MENU,
                                         "Insufficient menu authorization")

        contractItems = CustomerAccount.objects.get(pk=int(acNo)).getContractItems()

        data = []
        dataSub = []

        for ci in contractItems :
            if cgType == 1 and ci.get('item_id') != cg.item_id.pk :
                continue

            curContractNo = "%s-%s" % (str(ci.get('contract__contract_no')).rjust(10, '0'),
                                        ci.get('item_no'))

            if "ALL" != contractNo and contractNo != curContractNo :
                continue

            isPerZone = 0
            isShield = 0

            erpContractInfo = getErp_contract("%s-%s" % (str(ci.get('contract__contract_no')),
                                                          ci.get('item_no')))

            if len(erpContractInfo) == 0 :
                continue;
            else :
                erpContractInfo = erpContractInfo[0]

            if erpContractInfo.get('perzone_yn') == 'Y' :
                isPerZone = 1
            if erpContractInfo.get('shield_yn') == 'Y':
                    isShield = 1

            splitContractNo = curContractNo.split('-')

            objItem = None
            try :
                objItem = CustomerItem.objects.get(contract__contract_no=int(splitContractNo[0]),
                                                    item_no=int(splitContractNo[1]))
            except :
                return APIErrorResponse(request, error_code.WRONG_INPUT, "Invalid contract.")

            try :
                mtGroupCD = MaterialGroup.objects.get(
                          material_no=objItem.material_no).material_group_cd
            except MaterialGroup.DoesNotExist:
                # not support material on aurora
                continue

            statData = []

            dataSub = []
            shieldDataSub = []

            if isPerZone == 1:
                statData = get_data_per_zone_traffic([objItem.pk], date_from, date_to, "5",
                         tz_offset, return_time_type='str',
                         material_group_code=mtGroupCD, return_type='api', is_contract_stat=True)

                sfaZoneMap = {}
                for q in statData.keys():
                    if q == 'total_data' :
                        continue;

                    try :
                        sfaZoneMap[q] = SFAZone.objects.get(zone_name=q).zone_code
                    except SFAZone.DoesNotExist:
                        continue

                for idx, val in enumerate(statData['total_data']['value_list']):
                    dateTime = val[0]
                    dataItems = []
                    # dataItems.append({'type':"TO", 'value':val[1]})

                    for key, val in sfaZoneMap.iteritems():
                        if key == 'total_data' :
                            continue;
                        dataItems.append({'type':sfaZoneMap.get(key, None),
                                          'value':statData[key]['transferred_list'][idx][1]})

                    dataItems = sorted(dataItems, key=itemgetter('type'))
                    dataSub.append({'dateTime':dateTime, 'dataItems':dataItems})

                if isShield == 1 :
                    statData = get_data_per_zone_shield_traffic([objItem.pk], date_from, date_to,
                            "5", tz_offset, return_time_type='str',
                            return_type='api', is_contract_stat=True)

                    sfaZoneMap = {}
                    for q in statData.keys():
                        if q == 'total_data' :
                            continue;

                        try :
                            sfaZoneMap[q] = SFAZone.objects.get(zone_name=q).zone_code
                        except SFAZone.DoesNotExist:
                            continue

                    for idx, val in enumerate(statData['total_data']['value_list']):
                        dateTime = val[0]
                        dataItems = []
                        # dataItems.append({'type':"TO", 'value':val[1]})

                        for key, val in sfaZoneMap.iteritems():
                            if key == 'total_data' :
                                continue;
                            dataItems.append({'type':sfaZoneMap.get(key, None),
                                              'value':statData[key]['transferred_list'][idx][1]})

                        dataItems = sorted(dataItems, key=itemgetter('type'))
                        shieldDataSub.append({'dateTime':dateTime, 'dataItems':dataItems})
            else :
                statData = get_data_total_traffic([objItem.pk], date_from, date_to, "5", tz_offset,
                         return_time_type='str', return_type='api', material_group_code=mtGroupCD,
                         is_shield=True, is_contract_stat=True)

                if len(statData['edge_data'].get('value_list')) == 0 :
                    statData = generate_null_traffic("5", date_from, date_to + timedelta(days=1),
                             "", return_time_type="str", tz_offset=tz_offset, transferredData=True)

                    statData = statData['transferred_list']

                    for idx, val in enumerate(statData):
                        dateTime = val[0]
                        dataItems = {'type':"TO", 'value':val[1]}

                        dataSub.append({'dateTime':dateTime, 'dataItems':[dataItems]})
                else :
                    for idx, val in enumerate(statData['edge_data'].get('transferred_list')):
                        dateTime = val[0]
                        dataItems = {'type':"TO", 'value':val[1]}

                        dataSub.append({'dateTime':dateTime, 'dataItems':[dataItems]})

                if isShield == 1 :
                    if len(statData['shield_data'].get('value_list')) == 0 :
                        statData = generate_null_traffic("5", date_from,
                                 date_to + timedelta(days=1), "", return_time_type="str",
                                 tz_offset=tz_offset, transferredData=True)

                        statData = statData['transferred_list']

                        for idx, val in enumerate(statData):
                            dateTime = val[0]
                            dataItems = {'type':"TO", 'value':val[1]}

                            shieldDataSub.append({'dateTime':dateTime, 'dataItems':[dataItems]})
                    else :
                        for idx, val in enumerate(statData['shield_data'].get('transferred_list')):
                            dateTime = val[0]
                            dataItems = {'type':"TO", 'value':val[1]}

                            shieldDataSub.append({'dateTime':dateTime, 'dataItems':[dataItems]})

            if isShield == 1:
                data.append({
                             'contractItemNo':
                                 "%s-%s" % (str(ci.get('contract__contract_no')).rjust(10, '0'),
                                             ci.get('item_no')),
                             'contractItemCode': str(ci.get('material_no')).rjust(18, '0'),
                             'timeBasedDataItems': dataSub,
                             'timeBasedShieldDataItems': shieldDataSub
                             })
            else :
                data.append({
                             'contractItemNo':
                                 "%s-%s" % (str(ci.get('contract__contract_no')).rjust(10, '0'),
                                             ci.get('item_no')),
                             'contractItemCode': str(ci.get('material_no')).rjust(18, '0'),
                             'timeBasedDataItems': dataSub
                             })

        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':data})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
def getCdnEdgeList(request):
    try :
        params = getOptionalParams(request)
        acNo = params.get("account_no")

        req_Privilege_name = 'API_GET_EDGE_BLOCK_IP'

        accCheck = CustomerAccountHasPrivilege.objects.filter(account_no=acNo,
                 privilege_id__use_flag=1, privilege_id__privilege_key=req_Privilege_name)

        if len(accCheck) <= 0 :
            return APIErrorResponse(request, error_code.NOT_ALLOWED_MENU,
                  "Insufficient menu authorization")

        f = urllib.urlopen(GET_CND_BLOCKIP_SOURCE)

        ipList = f.readlines()

        result = []
        for i in ipList:
            result.append(i.rstrip('\n'))

        return APIResponse(request, {"item": result})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
def get_contract_storage_usage(request):
    try:
        params = getOptionalParams(request)

        acNo = int(params.get("account_no"))

        cgTmp = getControlGroupByStorageAccountAsObject(request.user.pk, acNo)

        hasContractAuth = False
        for c in cgTmp :
            if str(c.control_group_id) == params.get("cgId") :
                hasContractAuth = True
                break
        if hasContractAuth == False :
            return APIErrorResponse(request, error_code.NOT_SUPPORT_SVC,
                   "Only Can use Predefined - Customer or Predefined - Contract control group.")

        cg = ControlGroup.objects.get(pk=params.get("cgId"))
        cgType = cg.group_type

        if cgType != 0 and cgType != 1 :
            return APIErrorResponse(request, error_code.NOT_ALLOWED_SVC,
                   "Only Can use Predefined - Customer or Predefined - Contract control group.")

        if cgType == 1 :
            hasMenuAuth = checkPrivilege(request.user.pk, acNo, 'STORAGE_USAGE')

            if hasMenuAuth == False :
                try :
                    subAccNos = getSubAccountByResellerUser(request.user.pk)
                    if acNo in subAccNos :
                        parentAcNo = ControlGroup.objects.get(account_no=acNo, group_type=0,
                                   use_flag=1).parent_account_no.pk
                        hasMenuAuth = checkPrivilege(request.user.pk, parentAcNo, 'STORAGE_USAGE')
                except Exception as e:
                    pass

            if hasMenuAuth == False :
                return APIErrorResponse(request, error_code.NOT_ALLOWED_MENU,
                       "Insufficient menu authorization")

        time_span = params.get('time_period', 'daily')

        result_data = get_data_result_by_request_api(request, params, cg.item_id.pk, "str")
        item_title = result_data["main_item"]["main_item_title"]
        item_title_id = int(result_data["main_item"]["main_item_id"])
        stats = result_data["stat_items"]["stat_items_title"]

        data = []
        mainData = []
        if time_span == 'hourly' :
            hourly_value_dict = \
                result_data["main_item"]["main_item_data"][int(item_title_id)]["value"]
            hourly_value_list = sorted(hourly_value_dict)

            for time_key in hourly_value_list :
                mainData.append({'dateTime' : str(time_key), 'usage' : hourly_value_dict[time_key]})
            data.append({'storageItemNo' : item_title, 'dataItems' : mainData})

            for stat in stats :
                statData = []
                stat_hourly_dict = result_data["stat_items"]['stat_items_data'][stat[0]]['value']
                stat_hourly_list = sorted(stat_hourly_dict)

                for time_key in stat_hourly_list :
                    statData.append({'dateTime' : str(time_key),
                                     'usage' : stat_hourly_dict[time_key]})
                data.append({'storageItemNo' : stat[1], 'dataItems' : statData})
        elif time_span == 'daily' :
            daily_value_dict =\
                result_data["main_item"]["main_item_data"][int(item_title_id)]["dayValue"]
            daily_value_list = sorted(daily_value_dict)

            for time_key in daily_value_list :
                mainData.append({'dateTime' : str(time_key),
                                 'usage' : daily_value_dict[time_key]['peakValue']})
            data.append({'storageItemNo' : item_title, 'dataItems' : mainData})

            for stat in stats :
                statData = []
                stat_daily_dict = result_data["stat_items"]['stat_items_data'][stat[0]]['dayValue']
                stat_daily_list = sorted(stat_daily_dict)

                for time_key in stat_daily_list :
                    statData.append({'dateTime' : str(time_key),
                                    'usage' : stat_daily_dict[time_key]['peakValue']})
                data.append({'storageItemNo' : stat[1], 'dataItems' : statData})
        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':data})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)
