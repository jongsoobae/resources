from aurora_api import error_code
from aurora_api.shared_components.decorators import stat_api_param_required, \
    stat_api_key_check, api_authority_required, api_privilege_authority_required
from aurora_api.utils import APIErrorResponse, APIResponse, APIException
from aurora_fe.shared_components.utils.privilege import checkPrivilege
from datetime import datetime
from django.views.decorators.csrf import csrf_exempt
from spectrum_fe.cs_reports.views.content import \
    get_data_top_10_urls_by_error_hits, get_data_top_10_urls_by_hits, \
    get_data_top_10_directory_by_error_hits, get_data_top_10_directory_by_hits, get_data_content_history, \
    get_data_directory_history, get_data_urls_by_failed_response_code, get_data_urls_by_failed_response_code_detail, \
    get_data_urls_by_play_rate, get_data_urls_by_play_rate_detail
from spectrum_fe.shared_components.utils.api import getOptionalParams


@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS', 'LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['CONTENT'])
def getContent(request):
    try :
        params = getOptionalParams(request)

        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        stat_list = request.session['stat_list']
        queryType = params.get("queryType")
        sortby = params.get("sortby")
        completion_yn = params.get("completionType", None)

        if completion_yn == 'Y':
            has_completion_auth = checkPrivilege(request.user.pk, params.get("account_no"),
                            request.session['stat_material_group_cd'] + "_CONTENT_COMPLETION")

            if False == has_completion_auth :
                return APIErrorResponse(request, error_code.NOT_ALLOWED_MENU, "Insufficient menu authorization")
            has_completion_privilege = True
        else:
            has_completion_privilege = False

        if "error" == sortby :
            if None == request.session['contract_stat'] :
                stats = get_data_top_10_urls_by_error_hits(stat_list, date_from, date_to,
                      queryType, return_type="api", is_contract_stat=False,
                      has_completion_privilege = has_completion_privilege)
            else :
                stats = get_data_top_10_urls_by_error_hits(request.session['contract_stat'],
                      date_from, date_to, queryType, return_type="api", is_contract_stat=True,
                       has_completion_privilege = has_completion_privilege)
        else :
            if None == request.session['contract_stat'] :
                stats = get_data_top_10_urls_by_hits(stat_list, date_from, date_to, queryType,
                      return_type="api", is_contract_stat=False, has_completion_privilege = has_completion_privilege)
            else :
                stats = get_data_top_10_urls_by_hits(request.session['contract_stat'], date_from,
                      date_to, queryType, return_type="api", is_contract_stat=True,
                      has_completion_privilege = has_completion_privilege)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS', 'LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['CONTENT'])
def getDirectory(request):
    try :
        params = getOptionalParams(request)

        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        stat_list = request.session['stat_list']
        queryType = params.get("queryType")
        sortby = params.get("sortby")
        completion_yn = params.get("completionType", None)

        if completion_yn == 'Y':
            has_completion_auth = checkPrivilege(request.user.pk, params.get("account_no"),
                            request.session['stat_material_group_cd'] + "_CONTENT_COMPLETION")

            if False == has_completion_auth :
                return APIErrorResponse(request, error_code.NOT_ALLOWED_MENU, "Insufficient menu authorization")
            has_completion_privilege = True
        else:
            has_completion_privilege = False

        if "error" == sortby :
            if None == request.session['contract_stat'] :
                stats = get_data_top_10_directory_by_error_hits(stat_list, date_from, date_to,
                      queryType, return_type="api", is_contract_stat=False,
                      has_completion_privilege = has_completion_privilege)
            else :
                stats = get_data_top_10_directory_by_error_hits(request.session['contract_stat'],
                      date_from, date_to, queryType, return_type="api", is_contract_stat=True,
                       has_completion_privilege = has_completion_privilege)
        else :
            if None == request.session['contract_stat'] :
                stats = get_data_top_10_directory_by_hits(stat_list, date_from, date_to, queryType,
                      return_type="api", is_contract_stat=False, has_completion_privilege = has_completion_privilege)
            else :
                stats = get_data_top_10_directory_by_hits(request.session['contract_stat'],
                      date_from, date_to, queryType, return_type="api", is_contract_stat=True,
                       has_completion_privilege = has_completion_privilege)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)


@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS', 'LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['CONTENT'])
def get_content_detail(request):
    try:
        params = getOptionalParams(request)

        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        stat_list = request.session['stat_list']
        sort_by = params.get("sortby")
        url = params.get("url")
        completion_yn = params.get("completionType", None)

        if completion_yn == 'Y':
            has_completion_auth = checkPrivilege(request.user.pk, params.get("account_no"),
                            request.session['stat_material_group_cd'] + "_CONTENT_COMPLETION")

            if False == has_completion_auth :
                return APIErrorResponse(request, error_code.NOT_ALLOWED_MENU, "Insufficient menu authorization")
            has_completion_privilege = True
        else:
            has_completion_privilege = False

        if None == request.session['contract_stat'] :
            stats = get_data_content_history(stat_list, date_from, date_to, "all", sort_by, is_contract_stat=False,
                                              keyword=url, has_completion_privilege=has_completion_privilege)
        else :
            stats = get_data_content_history(request.session['contract_stat'], date_from, date_to, "all", sort_by,
                                is_contract_stat=True, keyword=url, has_completion_privilege=has_completion_privilege)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        result = []
        if has_completion_privilege:
            if sort_by == 'error':
                for obj in stats:
                    result.append({'dateTime' : obj.date, 'errorHits' : obj.error_hits, 'okHits' : obj.ok_hits,
                                   'okDataTransferred' : obj.transferred, 'completionTotalHits' : obj.total_hits,
                                   'completionCompletedHits' : obj.completed_hits,
                                   'completionInitatedHits' : obj.incompleted_hits,
                                   'completionRate' : obj.completion_ratio})
            else:
                for obj in stats:
                    result.append({'dateTime' : obj.date, 'okHits' : obj.ok_hits,
                                   'okDataTransferred' : obj.transferred, 'completionTotalHits' : obj.total_hits,
                                   'completionCompletedHits' : obj.completed_hits,
                                   'completionInitatedHits' : obj.incompleted_hits,
                                   'completionRate' : obj.completion_ratio})
        else:
            if sort_by == 'error':
                for obj in stats:
                    result.append({'dateTime' : obj.date, 'errorHits' : obj.error_hits, 'okHits' : obj.ok_hits,
                                   'okDataTransferred' : obj.transferred})
            else:
                for obj in stats:
                    result.append({'dateTime' : obj.date, 'okHits' : obj.ok_hits,
                                   'okDataTransferred' : obj.transferred})

        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':result})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS', 'LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['CONTENT'])
def get_directory_detail(request):
    try:
        params = getOptionalParams(request)

        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        stat_list = request.session['stat_list']
        sort_by = params.get("sortby")
        url = params.get("url")
        completion_yn = params.get("completionType", None)

        if completion_yn == 'Y':
            has_completion_auth = checkPrivilege(request.user.pk, params.get("account_no"),
                            request.session['stat_material_group_cd'] + "_CONTENT_COMPLETION")

            if False == has_completion_auth :
                return APIErrorResponse(request, error_code.NOT_ALLOWED_MENU, "Insufficient menu authorization")
            has_completion_privilege = True
        else:
            has_completion_privilege = False

        if None == request.session['contract_stat'] :
            stats = get_data_directory_history(stat_list, date_from, date_to, "all", sort_by, is_contract_stat=False,
                                              keyword=url, has_completion_privilege=has_completion_privilege)
        else :
            stats = get_data_directory_history(request.session['contract_stat'], date_from, date_to, "all", sort_by,
                                 is_contract_stat=True, keyword=url, has_completion_privilege=has_completion_privilege)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        result = []
        if has_completion_privilege:
            if sort_by == 'error':
                for obj in stats:
                    result.append({'dateTime' : obj.date, 'errorHits' : obj.error_hits, 'okHits' : obj.ok_hits,
                                   'okDataTransferred' : obj.transferred, 'completionTotalHits' : obj.total_hits,
                                   'completionCompletedHits' : obj.completed_hits,
                                   'completionInitatedHits' : obj.incompleted_hits,
                                   'completionRate' : obj.completion_ratio})
            else:
                for obj in stats:
                    result.append({'dateTime' : obj.date, 'okHits' : obj.ok_hits,
                                   'okDataTransferred' : obj.transferred, 'completionTotalHits' : obj.total_hits,
                                   'completionCompletedHits' : obj.completed_hits,
                                   'completionInitatedHits' : obj.incompleted_hits,
                                   'completionRate' : obj.completion_ratio})
        else:
            if sort_by == 'error':
                for obj in stats:
                    result.append({'dateTime' : obj.date, 'errorHits' : obj.error_hits, 'okHits' : obj.ok_hits,
                                   'okDataTransferred' : obj.transferred})
            else:
                for obj in stats:
                    result.append({'dateTime' : obj.date, 'okHits' : obj.ok_hits,
                                   'okDataTransferred' : obj.transferred})

        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':result})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(andPrivilegeMenus=['CONTENT'])
def get_content_failed_response_code(request):
    try :
        params = getOptionalParams(request)

        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        stat_list = request.session['stat_list']

        if None == request.session['contract_stat'] :
            stats = get_data_urls_by_failed_response_code(stat_list, date_from, date_to, "all", "ok",
                                            return_type="api", is_contract_stat=False, has_completion_privilege=False)
        else :
            stats = get_data_urls_by_failed_response_code(request.session['contract_stat'], date_from, date_to, "all",
                                        "ok", return_type="api", is_contract_stat=True, has_completion_privilege=False)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(andPrivilegeMenus=['CONTENT'])
def get_content_failed_response_code_detail(request):
    try :
        params = getOptionalParams(request)

        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        stat_list = request.session['stat_list']
        response_code = params.get("responseCode")

        if None == request.session['contract_stat'] :
            stats = get_data_urls_by_failed_response_code_detail(stat_list, date_from, date_to, "all", "ok",
                                                return_type="api", is_contract_stat=False, response_code=response_code,
                                                has_completion_privilege=False)
        else :
            stats = get_data_urls_by_failed_response_code_detail(request.session['contract_stat'], date_from, date_to,
                                                            "all", "ok", return_type="api", is_contract_stat=True,
                                                            response_code=response_code, has_completion_privilege=False)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['CONTENT'])
def get_content_response_code(request):
    try :
        params = getOptionalParams(request)

        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        stat_list = request.session['stat_list']

        if None == request.session['contract_stat'] :
            stats = get_data_urls_by_failed_response_code(stat_list, date_from, date_to, "all", "ok",
                                            return_type="api", is_contract_stat=False, has_completion_privilege=False)
        else :
            stats = get_data_urls_by_failed_response_code(request.session['contract_stat'], date_from, date_to, "all",
                                        "ok", return_type="api", is_contract_stat=True, has_completion_privilege=False)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['CONTENT'])
def get_content_response_code_detail(request):
    try :
        params = getOptionalParams(request)

        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        stat_list = request.session['stat_list']
        response_code = params.get("responseCode")

        if None == request.session['contract_stat'] :
            stats = get_data_urls_by_failed_response_code_detail(stat_list, date_from, date_to, "all", "ok",
                                                return_type="api", is_contract_stat=False, response_code=response_code,
                                                has_completion_privilege=False)
        else :
            stats = get_data_urls_by_failed_response_code_detail(request.session['contract_stat'], date_from, date_to,
                                                          "all", "ok", return_type="api", is_contract_stat=True,
                                                          response_code=response_code, has_completion_privilege=False)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['CONTENT'])
def get_content_play_rate(request):
    try :
        params = getOptionalParams(request)

        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        stat_list = request.session['stat_list']

        if None == request.session['contract_stat'] :
            stats = get_data_urls_by_play_rate(stat_list, date_from, date_to, "all", "ok",
                                            return_type="api", is_contract_stat=False,)
        else :
            stats = get_data_urls_by_play_rate(request.session['contract_stat'], date_from, date_to, "all",
                                        "ok", return_type="api", is_contract_stat=True)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['CONTENT'])
def get_content_play_rate_detail(request):
    try :
        params = getOptionalParams(request)

        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        stat_list = request.session['stat_list']
        rateZone = params.get("rateZone")

        if None == request.session['contract_stat'] :
            stats = get_data_urls_by_play_rate_detail(stat_list, date_from, date_to, "all", "ok",
                                                          return_type="api", is_contract_stat=False,
                                                          playrate=rateZone)
        else :
            stats = get_data_urls_by_play_rate_detail(request.session['contract_stat'], date_from, date_to,
                                                          "all", "ok", return_type="api", is_contract_stat=True,
                                                          playrate=rateZone)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)
