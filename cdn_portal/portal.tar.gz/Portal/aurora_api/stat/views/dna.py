from aurora_api import error_code, settings
from aurora_api.shared_components.decorators import stat_api_param_required, \
    stat_api_key_check, api_authority_required, api_privilege_authority_required
from aurora_api.utils import APIErrorResponse, APIResponse, APIException
from aurora_fe.api.views.stat import generate_base_traffic, chStrFormatOfDate
from datetime import datetime, timedelta
from django.db.models import Sum, Q
from django.views.decorators.csrf import csrf_exempt
from spectrum_fe.dna.models.stats import DnaTrafficStats, \
    DnaTrafficStatsLocation
from spectrum_fe.cs_reports.models.traffic import get_api_real_date

from spectrum_fe.shared_components.utils.api import getOptionalParams
from aurora_fe.shared_components.utils.stat import get_stat_item_ids_by_control_group_and_material_no


def getStats(request, date_from, date_to, tz_offset, type, time_span, filter_domain, cg_id=0):
    try :
        tz_start_time = date_from
        tz_string = "{tz_sign}{tz_offset}:00".\
                format(tz_sign='+' if  tz_offset >= 0 else '-', \
                tz_offset=abs(tz_offset))

        if type == 'overall':
            date_format = "start_time"

            if time_span == '5':
                date_format = "CONCAT(SUBSTR(convert_tz(start_time, '+00:00', '{tz_string}'),1,16))".\
                format(tz_string=tz_string)
                date_interval = "SUBSTR(CONCAT(SUBSTR(start_time,1,1),'1'),2)"
            elif time_span == 'hourly':
                date_format = "CONCAT(SUBSTR(convert_tz(start_time, '+00:00', '{tz_string}'),1,13),':00')".\
                format(tz_string=tz_string)
                date_interval = "SUBSTR(CONCAT(SUBSTR(start_time,1,1),'12'),2)"
            elif time_span == 'daily':
                date_format = "SUBSTR(convert_tz(start_time, '+00:00', '{tz_string}'),1,10)".\
                format(tz_string=tz_string)
                date_interval = "SUBSTR(CONCAT(SUBSTR(start_time,1,1),'288'),2)"
            elif time_span == 'monthly':
                date_format = "SUBSTR(convert_tz(start_time, '+00:00', '{tz_string}'),1,7)".\
                format(tz_string=tz_string)
                date_interval = "(DAY(LAST_DAY(start_time)) * 288)"

            if filter_domain:
                stats = DnaTrafficStats.c_objects.filter_customer(request).\
                        filter(start_time__gte=date_from,
                            start_time__lt=date_to,
                            stat=filter_domain.pk).\
                        extra(select={'date': date_format, 'interval': date_interval }).\
                        values('date', 'interval').\
                        annotate(Sum('bytes_in'),
                            Sum('bytes_out'),
                            Sum('hits'),
                            Sum('conn_snapshot'),
                            Sum('error_client'),
                            Sum('error_origin')).\
                        order_by('start_time')
            else:
                if cg_id in [None, 0]:
                    raise Exception
                stat_item_ids = get_stat_item_ids_by_control_group_and_material_no(cg_id, settings.DNA_MATERIAL, isGetValid=False)
                stats = DnaTrafficStats.c_objects.filter_customer(request).\
                    filter(start_time__gte=date_from,
                        start_time__lt=date_to, 
                        stat__stat_id__in=stat_item_ids).\
                        extra(select={'date': date_format,
                            'tz_start_time':tz_start_time, 'interval': date_interval }).\
                        values('date', 'interval').\
                        annotate(Sum('bytes_in'),
                            Sum('bytes_out'),
                            Sum('hits'),
                            Sum('conn_snapshot'),
                            Sum('error_client'),
                            Sum('error_origin')).\
                        order_by('start_time')
        elif type == 'location':
            if cg_id in [None, 0]:
                raise Exception
            stat_item_ids = get_stat_item_ids_by_control_group_and_material_no(cg_id, settings.DNA_MATERIAL, isGetValid=False)
            stats = DnaTrafficStatsLocation.c_objects.filter_customer(request).\
                filter(Q(start_time__gte=date_from,
                        start_time__lt=date_to, 
                        stat__stat_id__in=stat_item_ids),
                        Q(location__start_time__lt=date_to) | Q(location__end_time__gte=date_from))
            if filter_domain != '' and filter_domain != None:
                # statmaster = StatMasterReport.objects.get(pk=filter_domain)
                stats = stats.filter(stat=filter_domain)
            stats = stats.values('location__region__country__country_name').\
                    annotate(agg_hits=Sum('hits'),
                        agg_bytes_in=Sum('bytes_in'),
                        agg_bytes_out=Sum('bytes_out'),
                        agg_conn_snapshot=Sum('conn_snapshot')).\
                    order_by('-hits')
        elif type == 'continent':
            if cg_id in [None, 0]:
                raise Exception
            stat_item_ids = get_stat_item_ids_by_control_group_and_material_no(cg_id, settings.DNA_MATERIAL, isGetValid=False)
            stats = DnaTrafficStatsLocation.c_objects.filter_customer(request).\
                filter(Q(start_time__gte=date_from,
                        start_time__lt=date_to, 
                        stat__stat_id__in=stat_item_ids),
                        Q(location__start_time__lt=date_to) | Q(location__end_time__gte=date_from))
            if filter_domain != '' and filter_domain != None:
                # statmaster = StatMasterReport.objects.get(pk=filter_domain)
                stats = stats.filter(stat=filter_domain)
            stats = stats.values('location__region__country__continent__continent_alias').\
                    annotate(agg_hits=Sum('hits'),
                        agg_bytes_in=Sum('bytes_in'),
                        agg_bytes_out=Sum('bytes_out'),
                        agg_conn_snapshot=Sum('conn_snapshot')).\
                    order_by('-hits')
        else :
            return None

        return stats

    except :
        raise

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_cd=['DA'])
@api_privilege_authority_required(andPrivilegeMenus=['REPORT'])
def getDataTransferred(request):
    try :
        params = getOptionalParams(request)
        cg_id = params.get('cgId')

        # tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        # tz_offset = get_customer(request).tz_offset
        tz_offset = 0

        date_from = datetime.strptime(params.get('fromDate'), '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)
        date_to = datetime.strptime(params.get('toDate'), '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)

        time_span = params.get('timeInterval')

        stats = getStats(request, date_from, date_to, tz_offset, "overall", time_span, request.session['stat_list'], cg_id=cg_id)

        if stats == None :
            return APIErrorResponse(request, error_code.TEMP_UNAVAILABLE, "Get DNA Stats Fail...")

        if stats.count() == 0 :
            return APIErrorResponse(request, error_code.NO_DATA, "No DATA")


        timeline = generate_base_traffic(time_span, date_from, date_to)

        data = []

        if stats and timeline.__len__() > 0:
            for s in stats:
                while timeline.__len__() > 0 :
                    curTimeline = timeline.popleft()
                    if curTimeline == s['date'] :
                        data.append({'dateTime':chStrFormatOfDate(s['date']),
                            'inBound':s['bytes_in__sum'],
                            'outBound':s['bytes_out__sum']})
                        break;
                    else :
                        data.append({'dateTime':chStrFormatOfDate(curTimeline),
                            'inBound':0,
                            'outBound':0})
            while timeline.__len__() > 0 :
                    curTimeline = timeline.popleft()
                    data.append({'dateTime':chStrFormatOfDate(curTimeline),
                            'inBound':0,
                            'outBound':0})

        real_date = get_api_real_date(date_to, tz_offset)

        return APIResponse(request, {
            'returnCode':error_code.SUCCESS,
            'data': data,
            'real_date': real_date
        })

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_cd=['DA'])
@api_privilege_authority_required(andPrivilegeMenus=['REPORT'])
def getConnections(request):
    try :
        params = getOptionalParams(request)
        cg_id = params.get('cgId')
        # tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        tz_offset = 0

        date_from = datetime.strptime(params.get('fromDate'), '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)
        date_to = datetime.strptime(params.get('toDate'), '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)

        time_span = params.get('timeInterval')

        stats = getStats(request, date_from, date_to, tz_offset, "overall", time_span, request.session['stat_list'], cg_id=cg_id)

        if stats == None :
            return APIErrorResponse(request, error_code.TEMP_UNAVAILABLE, "Get DNA Stats Fail...")

        if stats.count() == 0 :
            return APIErrorResponse(request, error_code.NO_DATA, "No DATA")

        timeline = generate_base_traffic(time_span, date_from, date_to)

        data = []

        if stats and timeline.__len__() > 0:
            for s in stats:
                while timeline.__len__() > 0 :
                    curTimeline = timeline.popleft()
                    if curTimeline == s['date'] :
                        data.append({'dateTime':chStrFormatOfDate(s['date']),
                            'newConns':s['hits__sum'],
                            'activeConns':s['conn_snapshot__sum'] / int(s['interval'])})
                        break;
                    else :
                        data.append({'dateTime':chStrFormatOfDate(curTimeline),
                            'newConns':0,
                            'activeConns':0})
            while timeline.__len__() > 0 :
                    curTimeline = timeline.popleft()
                    data.append({'dateTime':chStrFormatOfDate(curTimeline),
                            'newConns':0,
                            'activeConns':0})

        real_date = get_api_real_date(date_to, tz_offset)

        return APIResponse(request, {
            'returnCode':error_code.SUCCESS,
            'data': data,
            'real_date': real_date
        })

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_cd=['DA'])
@api_privilege_authority_required(andPrivilegeMenus=['REPORT'])
def getErrorConnections(request):
    try :
        params = getOptionalParams(request)
        cg_id = params.get('cgId')
        # tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        tz_offset = 0

        date_from = datetime.strptime(params.get('fromDate'), '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)
        date_to = datetime.strptime(params.get('toDate'), '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)

        time_span = params.get('timeInterval')

        stats = getStats(request, date_from, date_to, tz_offset, "overall", time_span, request.session['stat_list'], cg_id=cg_id)

        if stats == None :
            return APIErrorResponse(request, error_code.TEMP_UNAVAILABLE, "Get DNA Stats Fail...")

        if stats.count() == 0 :
            return APIErrorResponse(request, error_code.NO_DATA, "No DATA")

        timeline = generate_base_traffic(time_span, date_from, date_to)

        data = []

        if stats and timeline.__len__() > 0:
            for s in stats:
                while timeline.__len__() > 0 :
                    curTimeline = timeline.popleft()
                    if curTimeline == s['date'] :
                        data.append({'dateTime':chStrFormatOfDate(s['date']),
                            'errorClient':s['error_client__sum'],
                            'errorOrigin':s['error_origin__sum']})
                        break;
                    else :
                        data.append({'dateTime':chStrFormatOfDate(curTimeline),
                            'errorClient':0,
                            'errorOrigin':0})
            while timeline.__len__() > 0 :
                    curTimeline = timeline.popleft()
                    data.append({'dateTime':chStrFormatOfDate(curTimeline),
                            'errorClient':0,
                            'errorOrigin':0})

        real_date = get_api_real_date(date_to, tz_offset)

        return APIResponse(request, {
            'returnCode':error_code.SUCCESS,
            'data': data,
            'real_date': real_date
        })

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)


@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_cd=['DA'])
@api_privilege_authority_required(andPrivilegeMenus=['REPORT'])
def getByLocationContinent(request):
    try :
        params = getOptionalParams(request)
        cg_id = params.get('cgId')
        # tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        # tz_offset = get_customer(request).tz_offset
        tz_offset = 0

        date_from = datetime.strptime(params.get('fromDate'),
                                      '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)
        date_to = datetime.strptime(params.get('toDate'),
                                     '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)

        stats = getStats(request, date_from, date_to, tz_offset, "continent", 0, request.session['stat_list'], cg_id=cg_id)

        if stats == None :
            return APIErrorResponse(request, error_code.TEMP_UNAVAILABLE, "Get DNS Stats Fail...")

        if stats.count() == 0 :
            return APIErrorResponse(request, error_code.NO_DATA, "No DATA")

        data = []

        if stats :
            for s in stats:
                try:
                    continent = s['location__region__country__continent__continent_alias']
                    if (continent == ''):
                        continent = "Unknown"
                except:
                    continent = '-'

                data.append({'continent':continent,
                    'newConns':s['agg_hits'],
                    'activeConns':s['agg_conn_snapshot'],
                    'inBound':s['agg_bytes_in'],
                    'outBound':s['agg_bytes_out']})

        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':data})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)
