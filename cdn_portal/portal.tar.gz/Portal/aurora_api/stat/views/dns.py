from aurora_api import error_code, settings
from aurora_api.shared_components.decorators import stat_api_param_required, \
    stat_api_key_check, api_authority_required, api_privilege_authority_required
from aurora_api.utils import APIErrorResponse, APIResponse, APIException
from aurora_fe.api.views.stat import generate_base_traffic, chStrFormatOfDate
from datetime import datetime, timedelta
from django.db.models import Sum, Q
from django.views.decorators.csrf import csrf_exempt
from spectrum_fe.dns.models.stats import DnsTrafficStats, \
    DnsTrafficStatsLocation, DnsTrafficStatsRequestType
from spectrum_fe.shared_components.models.portal_menu import MaterialGroup
from spectrum_fe.shared_components.utils.api import getOptionalParams
from aurora_fe.shared_components.utils.stat import get_stat_item_ids_by_control_group_and_material_no
from spectrum_fe.dns.models.dns_reports import get_list_dns_record, get_top_10_success_record, get_top_10_fail_record
from spectrum_fe.cs_reports.models.traffic import get_api_real_date

def getStats(request, date_from, date_to, tz_offset, type, time_span, filter_domain, cg_id=0):
    try :
        tz_string = "{tz_sign}{tz_offset}:00".\
                format(tz_sign='+' if  tz_offset >= 0 else '-', \
                tz_offset=abs(tz_offset))

        if type == 'overall':
            date_format = "start_time"
            if cg_id in [None, 0]:
                raise Exception
            stat_item_ids = get_stat_item_ids_by_control_group_and_material_no(cg_id, settings.DNS_MATERIAL, isGetValid=False)
            stats = DnsTrafficStats.c_objects.filter_customer(request).\
                filter(start_time__gte=date_from, start_time__lt=date_to, stat__stat_id__in=stat_item_ids)

            if time_span == '5':
                date_format = "CONCAT(SUBSTR(convert_tz(start_time, '+00:00', '{tz_string}'),1,16))".\
                format(tz_string=tz_string)
            elif time_span == 'hourly':
                date_format = "CONCAT(SUBSTR(convert_tz(start_time, '+00:00', '{tz_string}'),1,13),':00')".\
                    format(tz_string=tz_string)
            elif time_span == 'daily':
                date_format = "SUBSTR(convert_tz(start_time, '+00:00', '{tz_string}'),1,10)".\
                    format(tz_string=tz_string)
            elif time_span == 'monthly':
                date_format = "SUBSTR(convert_tz(start_time, '+00:00', '{tz_string}'),1,7)".\
                    format(tz_string=tz_string)

            if filter_domain != '' and filter_domain != None:
                stats = stats.filter(stat=filter_domain)

            stats = stats.extra(select={'date': date_format}).values('date').\
                        annotate(Sum('hits'),
                            Sum('no_error_hits'),
                            Sum('nx_domain_hits'),
                            Sum('server_fail_hits'),
                            Sum('query_error_hits'),
                            Sum('processed_0ms_1ms'),
                            Sum('processed_1ms_10ms'),
                            Sum('processed_10ms_100ms')).\
                         order_by('start_time')
        elif type == 'record_type':
            if cg_id in [None, 0]:
                raise Exception
            stat_item_ids = get_stat_item_ids_by_control_group_and_material_no(cg_id, settings.DNS_MATERIAL, isGetValid=False)
            stats = DnsTrafficStatsRequestType.c_objects.filter_customer(request).\
                        filter(start_time__gte=date_from, start_time__lt=date_to
                               , stat__stat_id__in=stat_item_ids)
            if filter_domain != '' and filter_domain != None:
                stats = stats.filter(stat=filter_domain)

            stats = stats.extra(select={'request_type':'case when request_type REGEXP BINARY \'^[0-9]\' then \'Unknown\' else request_type end'})

            stats = stats.values('request_type').annotate(agg_hits=Sum('hits'), success_hits=Sum('success_hits'), fail_hits=Sum('fail_hits'))
            stats = stats.order_by('-agg_hits')
        elif type == 'location':
            if cg_id in [None, 0]:
                raise Exception
            stat_item_ids = get_stat_item_ids_by_control_group_and_material_no(cg_id, settings.DNS_MATERIAL, isGetValid=False)
            stats = DnsTrafficStatsLocation.c_objects.filter_customer(request).\
                        filter(start_time__gte=date_from, start_time__lt=date_to
                               , stat__stat_id__in=stat_item_ids).\
                        filter(Q(location__start_time__lt=date_to) | Q(location__end_time__gte=date_from))
            if filter_domain != '' and filter_domain != None:
                stats = stats.filter(stat=filter_domain)
            stats = stats.values('location__region__country__country_name').\
                annotate(agg_hits=Sum('hits'))

            stats = stats.order_by('-agg_hits', 'location')
        else:
            return None

        return stats

    except :
        raise

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_cd=['CD'])
@api_privilege_authority_required(andPrivilegeMenus=['REPORT'])
def getRequests(request):
    try :
        params = getOptionalParams(request)
        cg_id = params.get('cgId')
        tz_offset = 0

        date_from = datetime.strptime(params.get('fromDate'), '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)
        date_to = datetime.strptime(params.get('toDate'), '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)

        time_span = params.get('timeInterval')

        stats = getStats(request, date_from, date_to, tz_offset, "overall", time_span, request.session['stat_list'], cg_id=cg_id)

        if stats == None :
            return APIErrorResponse(request, error_code.TEMP_UNAVAILABLE, "Get DNS Stats Fail...")

        if stats.count() == 0 :
            return APIErrorResponse(request, error_code.NO_DATA, "No DATA")

        timeline = generate_base_traffic(time_span, date_from, date_to)

        data = []

        if stats and timeline.__len__() > 0:
            for s in stats:
                while timeline.__len__() > 0 :
                    curTimeline = timeline.popleft()
                    if curTimeline == s['date'] :
                        data.append({'dateTime':chStrFormatOfDate(s['date']),
                            'requests':s['hits__sum']})
                        break;
                    else :
                        data.append({'dateTime':chStrFormatOfDate(curTimeline),
                            'requests':0})
            while timeline.__len__() > 0 :
                    curTimeline = timeline.popleft()
                    data.append({'dateTime':chStrFormatOfDate(curTimeline),
                            'requests':0})

        real_date = get_api_real_date(date_to, tz_offset)

        return APIResponse(request, {
            'returnCode':error_code.SUCCESS,
            'data': data,
            'real_date': real_date
        })

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_cd=['CD'])
@api_privilege_authority_required(andPrivilegeMenus=['REPORT'])
def getResponseTypes(request):
    try :
        params = getOptionalParams(request)
        cg_id = params.get('cgId')
        #tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        #tz_offset = get_customer(request).tz_offset
        tz_offset = 0

        date_from = datetime.strptime(params.get('fromDate'), '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)
        date_to = datetime.strptime(params.get('toDate'), '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)

        time_span = params.get('timeInterval')

        stats = getStats(request, date_from, date_to, tz_offset, "overall", time_span, request.session['stat_list'], cg_id=cg_id)

        if stats == None :
            return APIErrorResponse(request, error_code.TEMP_UNAVAILABLE, "Get DNS Stats Fail...")

        if stats.count() == 0 :
            return APIErrorResponse(request, error_code.NO_DATA, "No DATA")

        timeline = generate_base_traffic(time_span, date_from, date_to)

        data = []

        if stats and timeline.__len__() > 0:
            for s in stats:
                while timeline.__len__() > 0 :
                    curTimeline = timeline.popleft()
                    if curTimeline == s['date'] :
                        data.append({'dateTime':chStrFormatOfDate(s['date']),
                            'success':s['no_error_hits__sum'],
                            'successNxDomain':s['nx_domain_hits__sum'],
                            'error':s['server_fail_hits__sum'],
                            'errorInvalidQuery':s['query_error_hits__sum']})
                        break;
                    else :
                        data.append({'dateTime':chStrFormatOfDate(curTimeline),
                            'success':0,
                            'successNxDomain':0,
                            'error':0,
                            'errorInvalidQuery':0})
            while timeline.__len__() > 0 :
                    curTimeline = timeline.popleft()
                    data.append({'dateTime':chStrFormatOfDate(curTimeline),
                            'success':0,
                            'successNxDomain':0,
                            'error':0,
                            'errorInvalidQuery':0})

        real_date = get_api_real_date(date_to, tz_offset)

        return APIResponse(request, {
            'returnCode':error_code.SUCCESS,
            'data': data,
            'real_date': real_date
        })
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_cd=['CD'])
@api_privilege_authority_required(andPrivilegeMenus=['REPORT'])
def getProcessTime(request):
    try :
        params = getOptionalParams(request)
        cg_id = params.get('cgId')
        #tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        #tz_offset = get_customer(request).tz_offset
        tz_offset = 0

        date_from = datetime.strptime(params.get('fromDate'), '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)
        date_to = datetime.strptime(params.get('toDate'), '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)

        time_span = params.get('timeInterval')

        mtNum = request.session['stat_material_no']
        mtCD = MaterialGroup.objects.get(material_no__in=mtNum).material_group_cd

        stats = getStats(request, date_from, date_to, tz_offset, "overall", time_span, request.session['stat_list'], cg_id=cg_id)

        if stats == None :
            return APIErrorResponse(request, error_code.TEMP_UNAVAILABLE, "Get DNS Stats Fail...")

        if stats.count() == 0 :
            return APIErrorResponse(request, error_code.NO_DATA, "No DATA")


        timeline = generate_base_traffic(time_span, date_from, date_to)

        data = []

        if stats and timeline.__len__() > 0:
            for s in stats:
                while timeline.__len__() > 0 :
                    curTimeline = timeline.popleft()
                    if curTimeline == s['date'] :
                        data.append({'dateTime':chStrFormatOfDate(s['date']),
                            'zeroToOnems':s['processed_0ms_1ms__sum'],
                            'ontToTenms':s['processed_1ms_10ms__sum'],
                            'tenToHundredms':s['processed_10ms_100ms__sum']})
                        break;
                    else :
                        data.append({'dateTime':chStrFormatOfDate(curTimeline),
                            'zeroToOnems':0,
                            'ontToTenms':0,
                            'tenToHundredms':0})
            while timeline.__len__() > 0 :
                    curTimeline = timeline.popleft()
                    data.append({'dateTime':chStrFormatOfDate(curTimeline),
                            'zeroToOnems':0,
                            'ontToTenms':0,
                            'tenToHundredms':0})

        real_date = get_api_real_date(date_to, tz_offset)

        return APIResponse(request, {
            'returnCode':error_code.SUCCESS,
            'data': data,
            'real_date': real_date
        })
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)


@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_cd=['CD'])
@api_privilege_authority_required(andPrivilegeMenus=['REPORT'])
def getHitsByRecordTypes(request):
    try :
        params = getOptionalParams(request)
        cg_id = params.get('cgId')
        tz_offset = 0

        date_from = datetime.strptime(params.get('fromDate'), '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)
        date_to = datetime.strptime(params.get('toDate'), '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)

        stats = getStats(request, date_from, date_to, tz_offset, "record_type", 0, request.session['stat_list'], cg_id=cg_id)
        list_dns_record = get_list_dns_record(request, '', '', tz_offset, cg_id, date_from, date_to)
        success_top_list = get_top_10_success_record(request, list_dns_record, full_list=True)
        fail_top_list = get_top_10_fail_record(request, list_dns_record, full_list=True)

        if stats == None :
            return APIErrorResponse(request, error_code.TEMP_UNAVAILABLE, "Get DNS Stats Fail...")

        if stats.count() == 0 :
            return APIErrorResponse(request, error_code.NO_DATA, "No DATA")

        data = []
        success_data = []
        fail_data = []

        if stats :
            for s in stats:
                data.append({'recordType':s['request_type'], 'hits':s['agg_hits'], 'successHits':s['success_hits'], 'failHits':s['fail_hits']})
        
        if success_top_list:
            for s in success_top_list:
                success_data.append({'domainName':s['domain_name'], 'recordType':s['record_type'], 'successHits':s['success_hits']})
        
        if fail_top_list:
            for s in fail_top_list:
                fail_data.append({'domainName':s['domain_name'], 'recordType':s['record_type'], 'failHits':s['fail_hits']})

        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':data, 'success_data':success_data, 'fail_data':fail_data})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)
