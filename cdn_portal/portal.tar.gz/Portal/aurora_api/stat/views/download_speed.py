
from datetime import datetime

from django.views.decorators.csrf import csrf_exempt

from aurora_api import error_code

from aurora_api.utils import APIErrorResponse
from aurora_api.utils import APIResponse
from aurora_api.utils import APIException

from aurora_api.shared_components.decorators import stat_api_param_required
from aurora_api.shared_components.decorators import stat_api_key_check
from aurora_api.shared_components.decorators import api_authority_required
from aurora_api.shared_components.decorators import api_privilege_authority_required

from spectrum_fe.cs_reports.views.visitor import get_average_client_downlaod_speed
from spectrum_fe.shared_components.utils.api import getOptionalParams
from spectrum_fe.shared_components.utils.common import log_error


DOWNLOADSPEED_API_PARAMS = (
    'apiKey', 'date_from', 'date_to', 'location_type', 'country_code'
)

API_PARAM_DATE_FORMAT = '%Y-%m-%d'
API_PARAM_AVAILABLE_CATEGORY = (
    'country', 'state', 'city', 'isp', 'asn', 'pop'
)

MSG_API_RESPONSE_NO_DATA = 'No Data'

MSG_ERROR_PARAM_NOT_FULFILLED = "api request param is not fulfilled."
MSG_ERROR_INVALID_TIMERANGE = "invalid datetime format. 'date_from' should be less than 'date_to'"
MSG_ERROR_INVALID_DATETIME = "invalid datetime format. 'date_from' and 'date_to' should be formed as 'yyyy-mm-dd'"
MSG_ERROR_INVALID_CATEGORY = "'{category}' is not valid value. available: {available}"


def validate_api_parameters(request):
    ''' validates api request parameters
        if parameters is invalid, then return APIErrorResponse
        else return valid parameter tuple.
    '''

    # get api parameters
    params = getOptionalParams(request)

    diff = set(DOWNLOADSPEED_API_PARAMS).difference(set(params))
    if diff:
        return APIErrorResponse(
            request=request,
            returnCode=error_code.INVALID_REQUEST,
            returnMsg=MSG_ERROR_PARAM_NOT_FULFILLED + str(diff)
        )

    # serialize api request parameters
    location_type = params.get('location_type')
    if location_type not in API_PARAM_AVAILABLE_CATEGORY:
        return APIErrorResponse(
            request=request,
            returnCode=error_code.INVALID_REQUEST,
            returnMsg=MSG_ERROR_INVALID_CATEGORY.format(
                category=location_type,
                available=API_PARAM_AVAILABLE_CATEGORY)
        )

    try:
        date_from = datetime.strptime(
            params.get('date_from'), API_PARAM_DATE_FORMAT)
        date_to = datetime.strptime(
            params.get('date_to'), API_PARAM_DATE_FORMAT)

        if date_from > date_to:
            # date_from is bigger than date_to
            return APIErrorResponse(
                request=request,
                returnCode=error_code.INVALID_REQUEST,
                returnMsg=MSG_ERROR_INVALID_TIMERANGE
            )

    except (TypeError, ValueError):
        # datetime_parse_error
        return APIErrorResponse(
            request=request,
            returnCode=error_code.INVALID_REQUEST,
            returnMsg=MSG_ERROR_INVALID_DATETIME
        )

    country_code = params.get('country_code', '')

    # session values, pass validation.
    stat_list = request.session.get('stat_list')
    # boolean value to check "stat_list" is "contract stat item".
    is_contract_stat_item = request.session.get('contract_stat', False)

    # return serialized parameters
    return (
        location_type, country_code,
        date_from, date_to, stat_list,
        is_contract_stat_item)


@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS', 'LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['VISITOR'])
def api_get_average_client_download_speed(request):
    try:
        # validate api request params
        # if return value is "APIErrorResponse", then return APIErrorResponse
        request_params = validate_api_parameters(request)
        if type(request_params) is APIErrorResponse:
            return request_params

        # extract parameters
        (location_type, country_code,
         date_from, date_to, stat_list,
         is_contract_stat_item) = request_params

        # generate api response data
        average_download_speed_report_data = get_average_client_downlaod_speed(
            location_type=location_type, country_code=country_code,
            date_from=date_from, date_to=date_to, stat_list=stat_list,
            is_contract_stat_item=is_contract_stat_item, return_type="api")

        # generate api response
        if average_download_speed_report_data:

            response_data = {
                'returnCode': error_code.SUCCESS,
                'data': average_download_speed_report_data
            }

            return APIResponse(request, response_data)

        else:
            # when stat_list is empty
            return APIErrorResponse(
                request, error_code.NO_DATA,
                MSG_API_RESPONSE_NO_DATA)

    except Exception as api_unknown_exception:

        log_error(
            request=request, e=api_unknown_exception,
            message='Unknown error in "aurora_api.stat.api.views.download_speed"')

        return APIException(
            request, error_code.TEMP_UNAVAILABLE, api_unknown_exception
        )
