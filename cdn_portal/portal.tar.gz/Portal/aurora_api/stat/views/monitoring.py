from django.views.decorators.csrf import csrf_exempt
from aurora_api import error_code
from aurora_api.shared_components.decorators import stat_api_param_required
from aurora_api.stat.api.monitoring import data_legacy_mon
from aurora_api.utils import APIErrorResponse, APIResponse, APIException
from aurora_fe.shared_components.utils.privilege import checkPrivilege
from spectrum_fe.shared_components.utils.api import getOptionalParams

@csrf_exempt
@stat_api_param_required
def get_current_summary(request):
    try :
        params = getOptionalParams(request)

        account_no = params.get("account_no")

        has_mon_auth = checkPrivilege(request.user.pk, account_no, "MAW_AQUAMONITORING")

        if False == has_mon_auth :
            return APIErrorResponse(request, error_code.NOT_ALLOWED_MENU, "Insufficient menu authorization")

        stats = data_legacy_mon(request, account_no, params.get("cgId"), params.get("gmtCd", None), 1)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
def get_current_summary_detail(request):
    try :
        params = getOptionalParams(request)

        account_no = params.get("account_no")

        has_mon_auth = checkPrivilege(request.user.pk, account_no, "MAW_AQUAMONITORING")

        if False == has_mon_auth :
            return APIErrorResponse(request, error_code.NOT_ALLOWED_MENU, "Insufficient menu authorization")

        stats = data_legacy_mon(request, account_no, params.get("cgId"), params.get("gmtCd", None), 2,
                                params.get("serviceName"))

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)
