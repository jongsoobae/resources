from aurora_api import error_code, settings
from aurora_api.shared_components.decorators import stat_api_param_required, \
    stat_api_key_check, api_authority_required, api_privilege_authority_required
from aurora_api.utils import APIErrorResponse, APIResponse, APIException
from aurora_fe.api.views.stat import chStrFormatOfDateFixLen
from datetime import datetime, timedelta
from django.views.decorators.csrf import csrf_exempt
from spectrum_fe.cloudstorage.models.cloudstorage import Storage, StorageStat
from spectrum_fe.shared_components.models import StatMaster
from spectrum_fe.shared_components.utils.api import getOptionalParams
from aurora_fe.shared_components.utils.stat import get_stat_item_ids_by_control_group_and_material_no


def getStats(request, date_from, date_to, tz_offset, filter_domain, cg_id=0):
    try :
        if filter_domain == None or filter_domain == '' :
            if cg_id in [None, 0]:
                raise Exception
            stat_item_ids = get_stat_item_ids_by_control_group_and_material_no(cg_id, settings.CLOUD_STORAGE_MATERIAL, isGetValid=False)
            statmaster_ids = ','.join(map(str, stat_item_ids)) if stat_item_ids.__len__() > 0 else 'null'
            rawsql = '''SELECT 0 as cluster_id, 0 as storag_id, 'ALL' AS storage_name, DATE_FORMAT(MAX(start_time), '%%Y-%%m-%%d') AS start_time, '' as status,
                                MAX(block_number) AS block_number, MAX(directory_number) AS directory_number, MAX(file_number) AS file_number FROM
                                (SELECT  start_time, SUM(block_number) AS block_number, SUM(directory_number) AS directory_number, SUM(file_number) AS file_number FROM
                                    (SELECT storage_id,start_time,MAX(block_number) AS block_number, MAX(directory_number) AS directory_number, MAX(file_number) AS file_number FROM
                                             stat.storage_stats s INNER JOIN stat.stat_master sm ON s.storage_name = sm.keyword
                                             AND start_time >= %(start)s and start_time <= %(end)s
                                             AND sm.stat_id in (''' + statmaster_ids + ''')
                                             AND STATUS <> 'D'
                                    GROUP BY storage_id,start_time, STATUS) a
                                 GROUP BY start_time) b
                                 GROUP BY DATE_FORMAT(start_time, '%%Y%%m%%d')'''
            params = {'start':str(date_from), 'end':str(date_to)}
            storageStats = StorageStat.objects.raw(rawsql, params)
        else :
            statmaster = StatMaster.objects.filter(stat_id=filter_domain.pk)

            if statmaster:
                storage = Storage.objects.filter(storage_name=statmaster[0].keyword)

                if storage:
                    rawsql = '''SELECT 0 as cluster_id,storage_id,storage_name,DATE_FORMAT(a.start_time, '%%Y-%%m-%%d') AS start_time,STATUS,a.block_number,directory_number,file_number FROM
                                (SELECT MAX(b.start_time) AS start_time, a.block_number FROM
                                      (SELECT DATE_FORMAT(start_time, '%%Y%%m%%d') AS start_time, MAX(block_number) AS block_number FROM
                                     stat.storage_stats
                                     WHERE start_time >= %(start)s and start_time <= %(end)s and storage_name =%(storage_name)s
                                     AND STATUS <> 'D'
                                    GROUP BY DATE_FORMAT(start_time, '%%Y%%m%%d') ) a INNER JOIN stat.storage_stats b
                                    ON a.block_number=b.block_number
                                    AND a.start_time=DATE_FORMAT(b.start_time, '%%Y%%m%%d')
                                    AND b.storage_name =%(storage_name)s
                                     AND b.STATUS <> 'D'
                                     GROUP BY a.start_time) a INNER JOIN
                                    stat.storage_stats  b
                                    ON a.start_time=b.start_time
                                    AND a.block_number=b.block_number
                                    AND storage_name =%(storage_name)s
                                    AND STATUS <> 'D'
                                GROUP BY storage_id,storage_name,a.start_time,STATUS,a.block_number,directory_number,file_number '''
                    params = {'start':str(date_from), 'end':str(date_to), 'storage_name':str(storage[0].storage_name)}
                    storageStats = StorageStat.objects.raw(rawsql, params)

                else:
                    raise Exception('No SID found')
            else:
                raise Exception('No stat data avaliable')

        return storageStats

    except :
        raise

def getStorage(request, filter_domain, cg_id=0):
    try :
        if filter_domain == None or filter_domain == '' :
            if cg_id in [None, 0]:
                raise Exception
            stat_item_ids = get_stat_item_ids_by_control_group_and_material_no(cg_id, settings.CLOUD_STORAGE_MATERIAL, isGetValid=False)
            statmaster_ids = ','.join(map(str, stat_item_ids)) if stat_item_ids.__len__() > 0 else 'null'

            rawsql = '''SELECT
                            ss.storage_id, ss.storage_name,
                            GROUP_CONCAT(LEFT(sc.cluster_name, 3) SEPARATOR ',') AS cluster_name,
                            ci.sales_charge AS cluster_count
                        FROM aurora.storage_storage ss 
                            INNER JOIN aurora.stat_master sm ON sm.keyword = ss.storage_name
                            LEFT JOIN aurora.storage_cluster_storage scs ON ss.storage_id = scs.storage_id
                            LEFT JOIN aurora.storage_cluster sc ON scs.cluster_id = sc.cluster_id
                            LEFT JOIN aurora.customer_item ci ON sm.item_id = ci.item_id
                        WHERE
                            sm.stat_id in (''' + statmaster_ids + ''') AND ss.obj_state = 1
                        GROUP BY ss.storage_id'''
            storage = Storage.objects.raw(rawsql)
        else :
            statmaster = StatMaster.objects.filter(stat_id=filter_domain.pk)

            if statmaster.exists():
                rawsql = '''SELECT
                                ss.storage_id, ss.storage_name,
                                GROUP_CONCAT(LEFT(sc.cluster_name, 3) SEPARATOR ',') AS cluster_name,
                                ci.sales_charge AS cluster_count
                            FROM aurora.storage_storage ss
                                INNER JOIN aurora.stat_master sm ON sm.keyword = ss.storage_name
                                LEFT JOIN aurora.storage_cluster_storage scs ON ss.storage_id = scs.storage_id
                                LEFT JOIN aurora.storage_cluster sc ON scs.cluster_id = sc.cluster_id
                                LEFT JOIN aurora.customer_item ci ON sm.item_id = ci.item_id
                            WHERE
                                sm.stat_id =%(stat_id)s AND ss.obj_state = 1
                            GROUP BY ss.storage_id '''
                params = {'stat_id':str(statmaster[0].pk)}
                storage = Storage.objects.raw(rawsql, params)
            else:
                raise Exception('No stat data avaliable')

        return storage

    except :
        raise


@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_cd=['SR'])
@api_privilege_authority_required(andPrivilegeMenus=['REPORT'])
def getStorageUsage(request):
    try :
        params = getOptionalParams(request)
        cg_id = params.get('cgId')
        # tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        # tz_offset = get_customer(request).tz_offset
        tz_offset = 0

        date_from = datetime.strptime(params.get('fromDate'), '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)
        date_to = datetime.strptime(params.get('toDate'), '%Y-%m-%d %H:%M') + timedelta(hours=tz_offset)

        stats = getStats(request, date_from, date_to, tz_offset, request.session['stat_list'], cg_id=cg_id)

        if stats == None :
            return APIErrorResponse(request, error_code.TEMP_UNAVAILABLE, "Get Storage Stats Fail...")

        retStatObj = []
        for storageStat in stats:
            retStatObj.append(storageStat)


        if len(retStatObj) == 0 :
            return APIErrorResponse(request, error_code.NO_DATA, "No DATA")

        data = []

        for s in retStatObj:
            data.append({'dateTime':chStrFormatOfDateFixLen(s.start_time, 8),
                            'sID':s.storage_name,
                            'blockNumber':long(s.block_number),
                            'byteSize':long(s.block_number) * 4096,
                            'directoryNumber':str(s.directory_number),
                            'fileNumber':str(s.file_number),
                        })
        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':data})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_cd=['SR'])
@api_privilege_authority_required(andPrivilegeMenus=['REPORT'])
def getStorageDetail(request):
    try :
        params = getOptionalParams(request)
        cg_id = params.get('cgId')

        storages = getStorage(request, request.session['stat_list'], cg_id=cg_id)

        if storages == None :
            return APIErrorResponse(request, error_code.TEMP_UNAVAILABLE, "Get Storage Information Call Fail...")

        retStorageObj = []
        for storage in storages:
            retStorageObj.append(storage)

        if len(retStorageObj) == 0 :
            return APIErrorResponse(request, error_code.NO_DATA, "No DATA")

        data = []

        for s in retStorageObj:
            data.append({'sID':s.storage_id,
                         'sName':s.storage_name,
                         'clusterCount':s.cluster_count,
                         'clusterName':s.cluster_name,
                        })
        return APIResponse(request, {'returnCode':error_code.SUCCESS, 'data':data})
    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)
