
from datetime import datetime
from django.views.decorators.csrf import csrf_exempt
from operator import itemgetter

from aurora_api import error_code
from aurora_api.shared_components.decorators import stat_api_param_required, \
    stat_api_key_check, api_authority_required, api_privilege_authority_required
from aurora_api.stat.api.traffic import data_legacy_bandwidth_by_service_api, data_legacy_bandwidth_api, \
    data_legacy_data_transferred_api, data_legacy_peak_hits_api, data_legacy_data_transferred_by_service_api
from aurora_api.utils import APIErrorResponse, APIResponse, APIException
from aurora_api.utils.common import get_legacy_stat_list
from aurora_fe.shared_components.models.common_code import GMTCD
from aurora_fe.shared_components.models.acl_core import CustomerAccountWrapper
from aurora_fe.shared_components.utils.privilege import checkHasPrivilegeOfAccount
from aurora_fe.shared_components.utils.reportItem import getTrafficReportItemList
from spectrum_fe.cs_reports.models.csReportsModels import getContractListByStatList
from spectrum_fe.cs_reports.models.traffic import get_data_edge_page_views, \
    get_data_edge_active_connection, get_data_edge_hits, get_data_origin_hits, \
    get_data_origin_response_code, get_data_edge_response_code, \
    get_data_total_traffic, get_data_per_zone_traffic, get_data_traffic_by_service, \
    get_data_cache_hit_ratio, get_data_cache_hit_ratio_by_service, \
    get_data_edge_page_views_by_service, get_data_edge_bandwidth, \
    get_data_transfer_by_service, get_api_real_date
from spectrum_fe.shared_components.models.customer import CustomerItem, SFAZone
from spectrum_fe.shared_components.utils.api import getOptionalParams
from spectrum_fe.shared_components.utils.common import periodToTimeSpan
from aurora_fe.shared_components.utils.account import get_account_wrapper_from_session
from spectrum_fe.shared_components.utils.byte_conv_utils import data_to_rounddown

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(andPrivilegeMenus=['TRAFFIC'])
def getTotalTraffic(request):
    try :
        params = getOptionalParams(request)

        tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        time_span = params.get('time_period')
        stat_list = request.session['stat_list']
        queryType = params.get("queryType")
        mtGroupCD = request.session['stat_material_group_cd']

        account = CustomerAccountWrapper.objects.get(pk=params.get('account_no'))
        is_shield = checkHasPrivilegeOfAccount(account, request.user, mtGroupCD + "_SHIELD_TRAFFIC")
        if queryType == 'shield' and is_shield == False:
            return APIErrorResponse(request, error_code.NOT_SUPPORT_SVC,
                   "Invalid service access (not support svc)")

        if None == request.session['contract_stat'] :
            stats = get_data_total_traffic(stat_list, date_from, date_to, time_span, tz_offset,
                  return_time_type='str', return_type='api',
                  material_group_code=mtGroupCD, is_shield=is_shield, is_contract_stat=False)
        else:
            stats = get_data_total_traffic(request.session['contract_stat'], date_from, date_to,
                  time_span, tz_offset, return_time_type='str', return_type='api',
                  material_group_code=mtGroupCD, is_shield=is_shield, is_contract_stat=True)

        result = []

        if queryType == 'origin':
            if len(stats['origin_data'].get('value_list')) == 0 :
                return APIErrorResponse(request, error_code.NO_DATA, "No Data")

            for idx, val in enumerate(stats['origin_data'].get('value_list')):
                result.append({'dateTime':val[0], 'bandwidth':val[1],
                'dataTransferred':stats['origin_data'].get('transferred_list')[idx][1]})
        elif queryType == 'shield':
            if len(stats['shield_data'].get('value_list')) == 0 :
                return APIErrorResponse(request, error_code.NO_DATA, "No Data")

            for idx, val in enumerate(stats['shield_data'].get('value_list')):
                result.append({'dateTime':val[0], 'bandwidth':val[1],
                'dataTransferred':stats['shield_data'].get('transferred_list')[idx][1]})
        else:
            if len(stats['edge_data'].get('value_list')) == 0 :
                return APIErrorResponse(request, error_code.NO_DATA, "No Data")

            for idx, val in enumerate(stats['edge_data'].get('value_list')):
                result.append({'dateTime':val[0], 'bandwidth':val[1],
                'dataTransferred':stats['edge_data'].get('transferred_list')[idx][1]})

        real_date = get_api_real_date(date_to, tz_offset)

        return APIResponse(request, {
            'returnCode':error_code.SUCCESS,
            'data': result,
            'real_date': real_date
        })

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(andPrivilegeMenus=['TRAFFIC'])
def getPageViews(request):
    try :

        hasPageViewsReportAuth = checkHasPrivilegeOfAccount(get_account_wrapper_from_session(request),
                               request.user,
                               request.session['stat_material_group_cd'] + "_PAGE_VIEWS")

        if False == hasPageViewsReportAuth :
            return APIErrorResponse(request, error_code.NOT_ALLOWED_MENU,\
                   "Insufficient menu authorization")

        params = getOptionalParams(request)

        tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        time_span = params.get('time_period')
        stat_list = request.session['stat_list']

        if None == request.session['contract_stat'] :
            stats = get_data_edge_page_views(stat_list, date_from, date_to, time_span, tz_offset,
                  return_time_type="str", return_type="api", is_contract_stat=False)
        else:
            stats = get_data_edge_page_views(request.session['contract_stat'], date_from, date_to,
                    time_span, tz_offset, return_time_type="str", return_type="api",
                    is_contract_stat=True)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        real_date = get_api_real_date(date_to, tz_offset)

        return APIResponse(request, {
            'returnCode':error_code.SUCCESS,
            'data': stats,
            'real_date': real_date
        })

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)


@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_cd=['CA', 'SCA', 'MH', 'MA', 'MM'])
@api_privilege_authority_required(andPrivilegeMenus=['TRAFFIC'])
def getActiveConnection(request):
    try :
        params = getOptionalParams(request)

        tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        time_span = params.get('time_period')
        stat_list = request.session['stat_list']

        if None == request.session['contract_stat'] :
            stats = get_data_edge_active_connection(stat_list, date_from, date_to, time_span,
                  tz_offset, return_time_type="str", return_type="api",
                  is_contract_stat=False)
        else:
            stats = get_data_edge_active_connection(request.session['contract_stat'], date_from,
                  date_to, time_span, tz_offset, return_time_type="str",
                  return_type="api", is_contract_stat=True)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        real_date = get_api_real_date(date_to, tz_offset)

        return APIResponse(request, {
            'returnCode':error_code.SUCCESS,
            'data': stats,
            'real_date': real_date
        })

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)


@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS', 'LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['TRAFFIC'])
def getTotalHits(request):
    try :
        params = getOptionalParams(request)

        tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        time_span = params.get('time_period')
        stat_list = request.session['stat_list']
        queryType = params.get("queryType")
        mtGroupCD = request.session['stat_material_group_cd']

        if mtGroupCD == 'MAW':
            if queryType == 'origin':
                legacy_stat_list = get_legacy_stat_list(request)
                stats = data_legacy_peak_hits_api(request, legacy_stat_list, date_from, date_to, time_span,
                                                   params.get("gmtCd", None))
            else:
                return APIErrorResponse(request, error_code.NOT_SUPPORT_SVC,
                                         "This API is accessible in case of legacy hits")
        else:
            if "origin" == queryType :
                if None == request.session['contract_stat'] :
                    stats = get_data_origin_hits(stat_list, date_from, date_to, time_span, tz_offset,
                          return_time_type="str", return_type="api",
                          is_contract_stat=False)
                else :
                    stats = get_data_origin_hits(request.session['contract_stat'], date_from, date_to,
                          time_span, tz_offset, return_time_type="str",
                          return_type="api", is_contract_stat=True)
            else :
                if None == request.session['contract_stat'] :
                    stats = get_data_edge_hits(stat_list, date_from, date_to, time_span, tz_offset,
                          return_time_type="str", return_type="api", is_contract_stat=False)
                else :
                    stats = get_data_edge_hits(request.session['contract_stat'], date_from, date_to,
                          time_span, tz_offset, return_time_type="str",
                          return_type="api", is_contract_stat=True)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        real_date = get_api_real_date(date_to, tz_offset)

        return APIResponse(request, {
            'returnCode':error_code.SUCCESS,
            'data': stats,
            'real_date': real_date
        })

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)


@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(andPrivilegeMenus=['TRAFFIC'])
def getTotalHitsByReturnCode(request):
    try :
        params = getOptionalParams(request)

        tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        time_span = params.get('time_period')
        stat_list = request.session['stat_list']
        queryType = params.get("queryType")

        if "origin" == queryType :
            if None == request.session['contract_stat'] :
                stats = get_data_origin_response_code(stat_list, date_from, date_to, time_span,
                      tz_offset, return_time_type="str", return_type="api",
                      is_contract_stat=False)
            else :
                stats = get_data_origin_response_code(request.session['contract_stat'], date_from,
                      date_to, time_span, tz_offset, return_time_type="str",
                      return_type="api", is_contract_stat=True)
        else :
            if None == request.session['contract_stat'] :
                stats = get_data_edge_response_code(stat_list, date_from, date_to, time_span,
                      tz_offset, return_time_type="str", return_type="api",
                      is_contract_stat=False)
            else :
                stats = get_data_edge_response_code(request.session['contract_stat'], date_from,
                      date_to, time_span, tz_offset, return_time_type="str",
                      return_type="api", is_contract_stat=True)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")


        real_date = get_api_real_date(date_to, tz_offset)

        return APIResponse(request, {
            'returnCode':error_code.SUCCESS,
            'data': stats,
            'real_date': real_date
        })

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(andPrivilegeMenus=['TRAFFIC'])
def getPerzoneTraffic(request):
    try :
        params = getOptionalParams(request)

        acNo = params.get("account_no", None)
        tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        time_span = params.get('time_period')
        stat_list = request.session['stat_list']
        mtGroupCD = request.session['stat_material_group_cd']

        # check whether perzone contract
        hasPerzoneReportAuth = False
        contractList = []

        if None == request.session['contract_stat'] :
            contractList = getContractListByStatList(stat_list)
        else:
            item = CustomerItem.objects.get(pk=request.session['contract_stat'][0])
            contractList.append(str(item.contract.contract_no) + '-' + str(item.item_no))

        auth_report_list = getTrafficReportItemList(request, contractList, acNo, mtGroupCD)

        if auth_report_list:
            for s in auth_report_list:
                if 'STAT_PER_ZONE_TRAFFIC' == s.stat_item_cd.stat_item_cd :
                    hasPerzoneReportAuth = True
                    break

        if hasPerzoneReportAuth == False:
            return APIErrorResponse(request, error_code.NOT_SUPPORT_SVC,\
                   "This API is accessible in case of perzone contract.")

        if None == request.session['contract_stat'] :
            stats = get_data_per_zone_traffic(stat_list, date_from, date_to, time_span, tz_offset,
                  return_time_type='str', material_group_code=mtGroupCD,
                  return_type='api', is_contract_stat=False)
        else:
            stats = get_data_per_zone_traffic(request.session['contract_stat'], date_from, date_to,
                  time_span, tz_offset, return_time_type='str',
                  material_group_code=mtGroupCD, return_type='api', is_contract_stat=True)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        dataSub = []
        sfaZoneMap = {}

        for q in stats.keys():
            if q == 'total_data' :
                sfaZoneMap[q] = 'TO'
            elif q == 'total_trans_data':
                continue
            else:
                sfaZoneMap[q] = stats[q].get('zone_name')

        for idx, val in enumerate(stats['total_data']['value_list']):
            dateTime = val[0]
            dataItems = []

            for key, val in sfaZoneMap.iteritems():
                if key == 'total_data' :
                    dataItems.append({'type':val,
                    'bandwidth':stats['total_data']['value_list'][idx][1],
                    'dataTransferred':stats['total_trans_data']['value_list'][idx][1]})
                else :
                    dataItems.append({'type':key,
                    'bandwidth':stats[key]['value_list'][idx][1],
                    'dataTransferred':stats[key]['transferred_list'][idx][1]})

            dataItems = sorted(dataItems, key=itemgetter('type'))

            dataSub.append({'dateTime':dateTime, 'dataItems':dataItems})

        real_date = get_api_real_date(date_to, tz_offset)

        return APIResponse(request, {
            'returnCode':error_code.SUCCESS,
            'data': dataSub,
            'real_date': real_date
        })

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS','LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['TRAFFIC'])
def get_by_service(request):
    try:
        params = getOptionalParams(request)

        tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        stat_list = request.session['stat_list']
        queryType = params.get("queryType")

        if queryType == 'edge':
            time_span = periodToTimeSpan(date_from, date_to)
            mtGroupCD = request.session['stat_material_group_cd']
            account = CustomerAccountWrapper.objects.get(pk=params.get('account_no'))
            is_shield = checkHasPrivilegeOfAccount(account, request.user,
                      mtGroupCD + "_SHIELD_TRAFFIC")

            if None == request.session['contract_stat']:
                stats = get_data_traffic_by_service(stat_list, date_from, date_to, time_span,
                      tz_offset, return_time_type="str", return_type="api",
                      material_group_code=mtGroupCD , is_shield=is_shield, is_contract_stat=False)
            else:
                stats = get_data_traffic_by_service(request.session['contract_stat'], date_from,
                      date_to, time_span, tz_offset, return_time_type="str", return_type="api",
                      material_group_code=mtGroupCD , is_shield=is_shield, is_contract_stat=True)

        elif queryType == 'cacheHitRatio':
            mtGroupCD = request.session['stat_material_group_cd']
            if mtGroupCD == 'MM':
                return APIErrorResponse(request, error_code.NOT_SUPPORT_SVC, "This API is not accessible in MH product")

            time_span = params.get('time_period')
            if None == request.session['contract_stat']:
                stats = get_data_cache_hit_ratio_by_service(stat_list, date_from, date_to,
                      time_span, tz_offset, return_time_type="str", return_type="api",
                      is_contract_stat=False)
            else:
                stats = get_data_cache_hit_ratio_by_service(request.session['contract_stat'],
                      date_from, date_to, time_span, tz_offset, return_time_type="str",
                      return_type="api", is_contract_stat=True)

        elif queryType == 'pageView':
            time_span = params.get('time_period')
            hasPageViewsReportAuth = checkHasPrivilegeOfAccount(
                                   get_account_wrapper_from_session(request), request.user,
                                   request.session['stat_material_group_cd'] + "_PAGE_VIEWS")

            if False == hasPageViewsReportAuth :
                return APIErrorResponse(request, error_code.NOT_ALLOWED_MENU,
                       "Insufficient menu authorization")

            if None == request.session['contract_stat']:
                stats = get_data_edge_page_views_by_service(stat_list, date_from, date_to,
                      time_span, tz_offset, return_time_type="str", return_type="api",
                      is_contract_stat=False)
            else:
                stats = get_data_edge_page_views_by_service(request.session['contract_stat'],
                      date_from, date_to, time_span, tz_offset, return_time_type="str",
                      return_type="api", is_contract_stat=True)

        elif queryType == 'bandwidth':
            legacy_stat_list = get_legacy_stat_list(request)

            stats = data_legacy_bandwidth_by_service_api(request, legacy_stat_list, date_from, date_to,
                                                   params.get("gmtCd", None))

        elif queryType == 'dataTransferred':
            legacy_stat_list = get_legacy_stat_list(request)

            stats = data_legacy_data_transferred_by_service_api(request, legacy_stat_list, date_from, date_to,
                                                   params.get("gmtCd", None))

        elif queryType == 'edgeDataTransferred':
            time_span = periodToTimeSpan(date_from, date_to)
            mtGroupCD = request.session['stat_material_group_cd']
            account = CustomerAccountWrapper.objects.get(pk=params.get('account_no'))
            is_shield = checkHasPrivilegeOfAccount(account, request.user,
                      mtGroupCD + "_SHIELD_TRAFFIC")

            if None == request.session['contract_stat']:
                stats = get_data_transfer_by_service(stat_list, date_from, date_to, time_span,
                      tz_offset, return_time_type="str", return_type="api",
                      material_group_code=mtGroupCD , is_shield=is_shield, is_contract_stat=False)
            else:
                stats = get_data_transfer_by_service(request.session['contract_stat'], date_from,
                      date_to, time_span, tz_offset, return_time_type="str", return_type="api",
                      material_group_code=mtGroupCD , is_shield=is_shield, is_contract_stat=True)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        return APIResponse(request, {
            'returnCode':error_code.SUCCESS,
            'data': stats,
        })

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)


@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_cd=['CA', 'SCA', 'AC', 'SAC', 'MA', 'MH'])
@api_privilege_authority_required(andPrivilegeMenus=['TRAFFIC'])
def get_cache_hit_ratio(request):
    try:
        params = getOptionalParams(request)

        tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        time_span = params.get('time_period')
        stat_list = request.session['stat_list']

        if None == request.session['contract_stat'] :
            stats = get_data_cache_hit_ratio(stat_list, date_from, date_to, time_span, tz_offset,
                  return_time_type="str", return_type="api", is_contract_stat=False)
        else:
            stats = get_data_cache_hit_ratio(request.session['contract_stat'], date_from, date_to,
                  time_span, tz_offset, return_time_type="str",
                  return_type="api", is_contract_stat=True)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        real_date = get_api_real_date(date_to, tz_offset)

        sum_cache_hit = stats['cache_hit'].get('totValue', 0)
        sum_total_hit = stats['total_hit'].get('totValue', 0)

        total_avg = float(data_to_rounddown(sum_cache_hit / sum_total_hit * 100, 2))

        results = [{'dateTime': r[0], 'hitRatio': r[1]} for r in stats['cache_ratio'].get('value_list', [])]

        return APIResponse(request, {
            'returnCode':error_code.SUCCESS,
            'data': results,
            'real_date': real_date,
            'totalAvg': total_avg
        })

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(andPrivilegeMenus=['TRAFFIC'])
def get_dynamic_static_traffic(request):
    try:
        params = getOptionalParams(request)

        acNo = params.get("account_no", None)
        tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        time_span = params.get('time_period')
        stat_list = request.session['stat_list']
        mtGroupCD = request.session['stat_material_group_cd']

        # check whether dynamic/static contract
        hasDynamicStaticReportAuth = False
        contractList = []

        if None == request.session['contract_stat'] :
            contractList = getContractListByStatList(stat_list)
        else:
            item = CustomerItem.objects.get(pk=request.session['contract_stat'][0])
            contractList.append(str(item.contract.contract_no) + '-' + str(item.item_no))

        auth_report_list = getTrafficReportItemList(request, contractList, acNo, mtGroupCD)

        if auth_report_list:
            for s in auth_report_list:
                if 'STAT_EDGE_BANDWIDTH' == s.stat_item_cd.stat_item_cd :
                    hasDynamicStaticReportAuth = True
                    break

        if hasDynamicStaticReportAuth == False:
            return APIErrorResponse(request, error_code.NOT_SUPPORT_SVC,
                   "This API is accessible in case of dynamic/static.")

        if None == request.session['contract_stat'] :
            stats = get_data_edge_bandwidth(stat_list, date_from, date_to, time_span, tz_offset,
                  return_time_type="str", return_type="api", is_contract_stat=False)
        else :
            stats = get_data_edge_bandwidth(request.session['contract_stat'], date_from, date_to,
                  time_span, tz_offset, return_time_type="str",
                  return_type="api", is_contract_stat=True)

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        real_date = get_api_real_date(date_to, tz_offset)

        return APIResponse(request, {
            'returnCode':error_code.SUCCESS,
            'data': stats,
            'real_date': real_date
        })

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['TRAFFIC'])
def get_bandwith(request):
    try :
        params = getOptionalParams(request)

        tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        time_span = params.get('time_period')

        legacy_stat_list = get_legacy_stat_list(request)

        stats = data_legacy_bandwidth_api(request, legacy_stat_list, date_from, date_to, time_span,
                                                   params.get("gmtCd", None))

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        real_date = get_api_real_date(date_to, tz_offset)

        return APIResponse(request, {
            'returnCode':error_code.SUCCESS,
            'data': stats,
            'real_date': real_date
        })

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['TRAFFIC'])
def get_data_transferred(request):
    try :
        params = getOptionalParams(request)

        tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        time_span = params.get('time_period')

        legacy_stat_list = get_legacy_stat_list(request)

        stats = data_legacy_data_transferred_api(request, legacy_stat_list, date_from, date_to, time_span,
                                                   params.get("gmtCd", None))

        if stats == None or len(stats) == 0:
            return APIErrorResponse(request, error_code.NO_DATA, "No Data")

        real_date = get_api_real_date(date_to, tz_offset)

        return APIResponse(request, {
            'returnCode':error_code.SUCCESS,
            'data': stats,
            'real_date': real_date
        })

    except Exception as e:
        return APIException(request, error_code.TEMP_UNAVAILABLE, e)

