from aurora_api import error_code
from aurora_api.shared_components.decorators import stat_api_param_required, \
    stat_api_key_check, api_authority_required, api_privilege_authority_required
from aurora_api.stat.api.visitor import data_legacy_unique_visitors_api, data_legacy_response_code_api, \
    data_legacy_avg_client_bandwidth_api, data_legacy_avg_client_browser_api, data_legacy_avg_client_os_api, \
    data_legacy_visitors_by_player_api, data_legacy_visitors_by_isp_api, data_legacy_visitors_by_location_api
from aurora_api.utils import APIErrorResponse, APIResponse, APIException
from aurora_api.utils.common import get_legacy_stat_list
from aurora_fe.shared_components.models.common_code import GMTCD
from aurora_fe.shared_components.utils.privilege import \
    checkHasPrivilegeOfAccount
from aurora_fe.shared_components.utils.reportItem import getVisitorReportItemList
from spectrum_fe.cs_reports.models.csReportsModels import getContractListByStatList
from datetime import datetime
from django.views.decorators.csrf import csrf_exempt
from spectrum_fe.cs_reports.views.visitor import \
    get_data_unique_visitors_per_hour, get_data_top_10_countries, \
    get_data_average_client_response_bandwidth, \
    get_data_average_client_request_bandwidth, get_data_operating_system, \
    get_data_browser, get_data_location_city, get_data_location_state, get_data_top_10_isp, \
    get_data_http_version
from spectrum_fe.shared_components.utils.api import getOptionalParams
from spectrum_fe.shared_components.models.customer import CustomerItem
from aurora_fe.shared_components.utils.account import get_account_wrapper_from_session

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS', 'LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['VISITOR'])
def getUniqueVisitor(request):
    try :
        params = getOptionalParams(request)

        tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh

        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        time_span = params.get('time_period')
        stat_list = request.session['stat_list']
        material_group_cd = request.session['stat_material_group_cd']

        if material_group_cd == 'MAW':
            legacy_stat_list = get_legacy_stat_list(request)

            stats = data_legacy_unique_visitors_api(request, legacy_stat_list, date_from, date_to, time_span,
                                                   params.get("gmtCd", None))
        else:
            if None == request.session['contract_stat'] :
                stats = get_data_unique_visitors_per_hour(stat_list, date_from, date_to, time_span,
                      tz_offset, "api", is_contract_stat=False)
            else:
                stats = get_data_unique_visitors_per_hour(request.session['contract_stat'], date_from,
                      date_to, time_span, tz_offset, "api", is_contract_stat=True)

        if stats == None or len(stats)==0:
            return APIErrorResponse(request,error_code.NO_DATA, "No Data")

        return APIResponse(request,{'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request,error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS', 'LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['VISITOR'])
def getVisitorsByLocation(request):
    try :
        params = getOptionalParams(request)

        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')

        try :
            locationCode  = int(params.get('locationCode'))
        except :
            locationCode  = 2

        countryCode  = params.get('countryCode')
        stat_list = request.session['stat_list']
        material_group_cd = request.session['stat_material_group_cd']

        if locationCode == 1 or locationCode == 0 :
            if "CN" == countryCode or "US" == countryCode or "RU" == countryCode or\
             "CA" == countryCode or "IT" == countryCode :
                pass
            else :
                return APIErrorResponse(request,error_code.NOT_ALLOWED_SVC, "Not allow countryCode")

        if material_group_cd == 'MAW':
            location_nm = 'world'
            if locationCode == 0:
                location_nm = 'states'
            elif locationCode == 1:
                location_nm = 'countries'

            legacy_stat_list = get_legacy_stat_list(request)

            stats = data_legacy_visitors_by_location_api(request, legacy_stat_list, date_from, date_to, location_nm,
                                                   countryCode)
        else:
            if 0 == locationCode :
                if None == request.session['contract_stat'] :
                    stats = get_data_location_city(stat_list, date_from, date_to, time_span="daily",
                          tz_offset="0", return_type="api", country=countryCode, state='',\
                          material_group_code= material_group_cd, is_contract_stat=False)
                else :
                    stats = get_data_location_city(request.session['contract_stat'], date_from,
                          date_to, time_span="daily", tz_offset="0", return_type="api", \
                          country=countryCode, state='', material_group_code= material_group_cd,
                          is_contract_stat=True)
            elif 1 == locationCode :
                if None == request.session['contract_stat'] :
                    stats = get_data_location_state(stat_list, date_from, date_to, time_span="daily",
                          tz_offset="0", return_type="api", country=countryCode,
                          material_group_code= material_group_cd, is_contract_stat=False)
                else :
                    stats = get_data_location_state(request.session['contract_stat'], date_from,
                          date_to, time_span="daily", tz_offset="0", return_type="api",
                          country=countryCode, material_group_code= material_group_cd,
                          is_contract_stat=True)
            elif 2 == locationCode :
                if None == request.session['contract_stat'] :
                    stats = get_data_top_10_countries(stat_list, date_from, date_to, time_span="daily",
                          tz_offset="0", return_type="api", material_group_code= material_group_cd,
                          is_contract_stat=False)
                else :
                    stats = get_data_top_10_countries(request.session['contract_stat'], date_from,
                          date_to, time_span="daily", tz_offset="0", return_type="api",
                          material_group_code= material_group_cd, is_contract_stat=True)
            else :
                return APIErrorResponse(request,error_code.WRONG_INPUT, "Wrong locationCode")

        if stats == None or len(stats)==0:
            return APIErrorResponse(request,error_code.NO_DATA, "No Data")

        return APIResponse(request,{'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request,error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS', 'LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['VISITOR'])
def getAvgClientBandwidth(request):
    try :
        params = getOptionalParams(request)

        tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        time_span = params.get('time_period')
        stat_list = request.session['stat_list']
        material_group_cd = request.session['stat_material_group_cd']

        if material_group_cd == 'MAW':
            legacy_stat_list = get_legacy_stat_list(request)

            stats = data_legacy_avg_client_bandwidth_api(request, legacy_stat_list, date_from, date_to, time_span,
                                                   params.get("gmtCd", None))
        else:
            if None == request.session['contract_stat'] :
                stats = get_data_average_client_response_bandwidth(stat_list, date_from, date_to,
                      time_span, tz_offset, "api", is_contract_stat=False)
            else :
                stats = get_data_average_client_response_bandwidth(request.session['contract_stat'],
                      date_from, date_to, time_span, tz_offset, "api", is_contract_stat=True)

        if stats == None or len(stats)==0:
            return APIErrorResponse(request,error_code.NO_DATA, "No Data")

        return APIResponse(request,{'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request,error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_cd=['AC', 'SAC'])
@api_privilege_authority_required(andPrivilegeMenus=['VISITOR'])
def getAvgClientUploadBandwidth(request):
    try :
        params = getOptionalParams(request)

        tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        time_span = params.get('time_period')
        stat_list = request.session['stat_list']

        if None == request.session['contract_stat'] :
            stats = get_data_average_client_request_bandwidth(stat_list, date_from, date_to,\
                  time_span, tz_offset, "api", is_contract_stat=False)
        else :
            stats = get_data_average_client_request_bandwidth(request.session['contract_stat'],
                  date_from, date_to, time_span, tz_offset, "api", is_contract_stat=True)

        if stats == None or len(stats)==0:
            return APIErrorResponse(request,error_code.NO_DATA, "No Data")

        return APIResponse(request,{'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request,error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS', 'LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['VISITOR'])
def getAvgClientBrowser(request):
    try :
        hasBrowserReportAuth = checkHasPrivilegeOfAccount(get_account_wrapper_from_session(request),
                             request.user, request.session['stat_material_group_cd']+"_BROWSER")

        if False == hasBrowserReportAuth :
            return APIErrorResponse(request,error_code.NOT_ALLOWED_MENU,\
                   "Insufficient menu authorization")

        params = getOptionalParams(request)

        tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        stat_list = request.session['stat_list']
        material_group_cd = request.session['stat_material_group_cd']

        if material_group_cd == 'MAW':
            legacy_stat_list = get_legacy_stat_list(request)

            stats = data_legacy_avg_client_browser_api(request, legacy_stat_list, date_from, date_to)
        else:
            if None == request.session['contract_stat'] :
                stats = get_data_browser(stat_list, date_from, date_to, "daily", tz_offset, "api",
                      is_contract_stat=False)
            else :
                stats = get_data_browser(request.session['contract_stat'], date_from, date_to, "daily",
                      tz_offset, "api", is_contract_stat=True)

        if stats == None or len(stats)==0:
            return APIErrorResponse(request,error_code.NO_DATA, "No Data")

        return APIResponse(request,{'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request,error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS', 'LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['VISITOR'])
def getAvgClientOS(request):
    try :
        hasOSReportAuth = checkHasPrivilegeOfAccount(get_account_wrapper_from_session(request),
                        request.user, request.session['stat_material_group_cd']+"_OPERATING_SYSTEM")

        if False == hasOSReportAuth :
            return APIErrorResponse(request,error_code.NOT_ALLOWED_MENU,
                   "Insufficient menu authorization")

        params = getOptionalParams(request)

        tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        stat_list = request.session['stat_list']
        material_group_cd = request.session['stat_material_group_cd']

        if material_group_cd == 'MAW':
            legacy_stat_list = get_legacy_stat_list(request)

            stats = data_legacy_avg_client_os_api(request, legacy_stat_list, date_from, date_to)
        else:
            if None == request.session['contract_stat'] :
                stats = get_data_operating_system(stat_list, date_from, date_to, "daily", tz_offset,
                      "api", is_contract_stat=False)
            else :
                stats = get_data_operating_system(request.session['contract_stat'], date_from, date_to,
                      "daily", tz_offset, "api", is_contract_stat=True)

        if stats == None or len(stats)==0:
            return APIErrorResponse(request,error_code.NO_DATA, "No Data")

        return APIResponse(request,{'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request,error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS', 'LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['VISITOR'])
def get_visitors_by_isp(request):
    try:
        params = getOptionalParams(request)

        acNo = params.get("account_no", None)
        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        stat_list = request.session['stat_list']
        mtGroupCD = request.session['stat_material_group_cd']

        # check whether isp
        hasIspReportAuth = False
        contractList = []

        if None == request.session['contract_stat'] :
            contractList = getContractListByStatList(stat_list)
        else:
            item = CustomerItem.objects.get(pk=request.session['contract_stat'][0])
            contractList.append(str(item.contract.contract_no) + '-' + str(item.item_no))

        auth_report_list = getVisitorReportItemList(request, contractList, acNo, mtGroupCD)

        if auth_report_list:
            for s in auth_report_list:

                if 'STAT_TOP_10_ISP' == s.stat_item_cd.stat_item_cd or\
                   'STAT_MAW_ISP' == s.stat_item_cd.stat_item_cd  :
                    hasIspReportAuth = True
                    break

        if hasIspReportAuth == False:
            return APIErrorResponse(request, error_code.NOT_SUPPORT_SVC,\
                   "This API is accessible in case of isp.")

        if mtGroupCD == 'MAW':
            legacy_stat_list = get_legacy_stat_list(request)

            stats = data_legacy_visitors_by_isp_api(request, legacy_stat_list, date_from, date_to)
        else:
            if None == request.session['contract_stat'] :
                stats = get_data_top_10_isp(stat_list, date_from, date_to, return_type="api",
                        is_contract_stat=False)
            else :
                stats = get_data_top_10_isp(request.session['contract_stat'], date_from, date_to,
                        return_type="api", is_contract_stat=True)

        if stats == None or len(stats)==0:
            return APIErrorResponse(request,error_code.NO_DATA, "No Data")

        return APIResponse(request,{'returnCode':error_code.SUCCESS, 'data':stats})
    except Exception as e:
        return APIException(request,error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['VISITOR'])
def get_visitors_response_code(request):
    try :
        params = getOptionalParams(request)

        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        time_span = params.get('time_period')

        legacy_stat_list = get_legacy_stat_list(request)

        stats = data_legacy_response_code_api(request, legacy_stat_list, date_from, date_to, time_span,
                                               params.get("gmtCd", None))

        if stats == None or len(stats)==0:
                return APIErrorResponse(request,error_code.NO_DATA, "No Data")

        return APIResponse(request,{'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request,error_code.TEMP_UNAVAILABLE, e)

@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['LEGACY'])
@api_privilege_authority_required(andPrivilegeMenus=['VISITOR'])
def get_visitors_by_player(request):
    try :
        params = getOptionalParams(request)

        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')

        legacy_stat_list = get_legacy_stat_list(request)

        stats = data_legacy_visitors_by_player_api(request, legacy_stat_list, date_from, date_to)

        if stats == None or len(stats)==0:
            return APIErrorResponse(request,error_code.NO_DATA, "No Data")

        return APIResponse(request,{'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request,error_code.TEMP_UNAVAILABLE, e)


@csrf_exempt
@stat_api_param_required
@stat_api_key_check
@api_authority_required(material_group_type=['CS'])
@api_privilege_authority_required(andPrivilegeMenus=['VISITOR'])
def getVisitorsHTTPVersion(request):
    try :
        hasHttpVersionReportAuth = checkHasPrivilegeOfAccount(get_account_wrapper_from_session(request),
                             request.user, request.session['stat_material_group_cd']+"_HTTP_VERSION")

        if False == hasHttpVersionReportAuth :
            return APIErrorResponse(request,error_code.NOT_ALLOWED_MENU,\
                   "Insufficient menu authorization")

        params = getOptionalParams(request)

        tz_offset = GMTCD.objects.get(pk=params.get("gmtCd", None)).gmt_hh
        date_from = datetime.strptime(params.get('date_from'), '%Y-%m-%d')
        date_to = datetime.strptime(params.get('date_to'), '%Y-%m-%d')
        stat_list = request.session['stat_list']
        material_group_cd = request.session['stat_material_group_cd']

        if None == request.session['contract_stat'] :
            stats = get_data_http_version(stat_list, date_from, date_to, "daily", tz_offset, "api",
                  is_contract_stat=False)
        else :
            stats = get_data_http_version(request.session['contract_stat'], date_from, date_to, "daily",
                  tz_offset, "api", is_contract_stat=True)

        if stats == None or len(stats)==0:
            return APIErrorResponse(request,error_code.NO_DATA, "No Data")

        return APIResponse(request,{'returnCode':error_code.SUCCESS, 'data':stats})

    except Exception as e:
        return APIException(request,error_code.TEMP_UNAVAILABLE, e)
