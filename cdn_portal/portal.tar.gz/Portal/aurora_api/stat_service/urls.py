from django.conf.urls.defaults import patterns, url

urlpatterns = patterns('aurora_api.stat_service.views.stat_service',
    url(r'^statmaster/edit/customerid/(?P<customer_id>[0-9]+)/', 'statMaster_edit_account'),
)