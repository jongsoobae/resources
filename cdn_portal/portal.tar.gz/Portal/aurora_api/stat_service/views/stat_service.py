from aurora_api.utils import APIException, APIErrorResponse, APIResponse
from spectrum_fe.shared_components.models.customer import CustomerDisplay
from spectrum_fe.shared_components.models import StatMaster
from django.views.decorators.csrf import csrf_exempt

from spectrum_fe.shared_components.utils.api import getOptionalParams

@csrf_exempt
def statMaster_edit_account(request, customer_id):
    try :
        opts = getOptionalParams(request)
        opts_set = set(opts)
        available_fields = set(('username', 'password', 'to_customer_id'))
        required_fields = set(('username', 'password', 'to_customer_id'))

        missing_opts = required_fields.difference(opts_set)
        
        to_customer_id = opts.get('to_customer_id')

        if len(missing_opts) > 0:
            return APIErrorResponse(request, "104", "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, "104", "Invalid parameters in request: " + ", ".join(invalid_opts))
        
        return_val = update_statMaster_account(customer_id, to_customer_id)
        
        if return_val['returnCode'] != 0 :
            return APIErrorResponse(request, return_val['returnCode'], return_val['returnMsg'])
        
        return APIResponse(request, {})
    except Exception as e :
        return APIException(request, "999", e)
    
def update_statMaster_account(customer_id, to_customer_id):
    try :
        try :
            CustomerDisplay.objects.get(pk=to_customer_id)
        except :
            return {'returnCode':404, 'returnMsg':"Matching customer(to_customer:"+to_customer_id+") does not exist."}
        
        if StatMaster.objects.filter(customer=customer_id, platform_no__in=(8008,8003,8004)).count() :
            try :
                StatMaster.objects.filter(customer=customer_id, platform_no__in=(8008,8003,8004)).update(customer=to_customer_id)
            except Exception as e :
                return {'returnCode':999, 'returnMsg':e}
        else :
            return {'returnCode':404, 'returnMsg':"Matching stat master(from_customer:"+customer_id+") does not exist."} 
                     
        return {'returnCode':0, 'returnMsg':"Success"}
    except Exception as e :
        return {'returnCode':999, 'returnMsg':e}