from django.conf.urls.defaults import patterns, include

# Application Urls - ordered alphabetically
urlpatterns = patterns('',
    (r'^rest/user/', include('aurora_api.user.urls')),  # user api
    (r'^rest/group/', include('aurora_api.group.urls')),  # control group api
    (r'^rest/stat/', include('aurora_api.stat.urls')),  # aurora stat api
    (r'^rest/config/', include('aurora_api.dns.urls')),  # aurora cloud dns api
    (r'^rest/monitor/', include('aurora_api.monitor.urls')),
    (r'^rest/acl/', include('aurora_api.acl.urls')),
    (r'^rest/pan/', include('aurora_api.panther.urls')), # pad configuration api
    (r'^rest/waf/', include('aurora_api.waf.urls')),    # fireblade api
    (r'^rest/hls/', include('aurora_api.hls.urls')),    # hls api
    (r'^rest/fastmon/', include('aurora_api.fastmon.urls')), #mon fast mon api
    (r'^rest/lds/', include('aurora_api.lds.urls')),    # lds api
    (r'^rest/account/', include('aurora_api.account.urls')), #account api
    (r'^rest/emailreport/', include('aurora_api.email_report.urls')), #email report api
    (r'^rest/statservice/', include('aurora_api.stat_service.urls')), #stat service api
)
