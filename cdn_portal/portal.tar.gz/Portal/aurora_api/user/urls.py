from django.conf.urls.defaults import patterns, url

urlpatterns = patterns('aurora_api.user.views.domain',
    url(r'^domain/list/', 'getDomainList'),
    url(r'^domain/auth/list/ckey/(?P<ckey>[0-9]+)', 'getAuthUserEmailListByCkey'),
    url(r'^domain/auth/list/site_id/(?P<site_id>[0-9]+)', 'getAuthUserEmailListBySiteid'),
)

urlpatterns += patterns('aurora_api.user.views.user',
    url(r'^email/list/ckey/(?P<ckey>[0-9]+)', 'get_subscriber_email_list_by_ckey'),
    url(r'^email/list/site/(?P<site_id>[0-9]+)', 'get_subscriber_email_list_by_site_id'),
    url(r'^email/list/zones/', 'get_subscriber_email_list_by_zone_list'),
    url(r'^userprofile/edit/customerid/(?P<customer_id>[0-9]+)/', 'userProfile_edit_account'),
    url(r'^userprivilege/edit/account/(?P<account_no>[0-9]+)/', 'userPrivilege_edit_account'),
)