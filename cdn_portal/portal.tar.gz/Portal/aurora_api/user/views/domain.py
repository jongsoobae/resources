from aurora_api import error_code, config_constants
from aurora_api.utils import APIErrorResponse, APIResponse, APIException
from aurora_fe.shared_components.models.acl_core import ControlGroup, \
    AuthUserHasControlGroup, StatItemWhiteList
from aurora_fe.shared_components.utils.common import checkSuperUser
from aurora_fe.shared_components.utils.stat import getAvailableStatByUser
from django.views.decorators.csrf import csrf_exempt
from spectrum_fe.shared_components.utils.common import log_error
from spectrum_fe.shared_components.models import StatMaster
from spectrum_fe.shared_components.models.customer import CustomerContract, CustomerItem
from spectrum_fe.shared_components.utils.api import getOptionalParams
from spectrum_fe.shared_components.utils.api import ApiHelper
from django.core.cache import cache

api = ApiHelper()
MAIL_ITEM_CODE = {
    'PAD Create/Modification': 1
}


@csrf_exempt
def getDomainList(request):
    try :
        opts = getOptionalParams(request)
        opts_set = set(opts)
        available_fields = set(('username', 'password'))
        required_fields = set(('username', 'password'))

        missing_opts = required_fields.difference(opts_set)

        if len(missing_opts) > 0:
            return APIErrorResponse(request, "104", "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, "104", "Invalid parameters in request: " + ", ".join(invalid_opts))

        cache_key = '%s_user_%s' % ("getDomainList", str(request.user.pk))
        result_data = None
        try:
            result_data = cache.get(cache_key)
        except:
            result_data = None
        if result_data is None:
            if checkSuperUser(request.user.pk) == True :
                result_data = {"is_superuser": True, "data": ["*"] }
            else :
                result_data = {"is_superuser": False, "data": getAvailableStatByUser(request.user.pk) }
            cache.set(cache_key, result_data, 10)

        return APIResponse(request, result_data)
    except Exception as e :
        return APIException(request, "999", e)

@csrf_exempt
def getAuthUserEmailListByCkey(request, ckey):
    try:
        opts = getOptionalParams(request)
        opts_set = set(opts)
        available_fields = set(('username', 'password', 'is_valid'))
        required_fields = set(('username', 'password'))

        missing_opts = required_fields.difference(opts_set)
        if len(missing_opts) > 0:
            return APIErrorResponse(request, error_code.WRONG_INPUT, "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, error_code.WRONG_INPUT, "Invalid parameters in request: " + ", ".join(invalid_opts))

        try:
            cg = ControlGroup.objects.get(ckey=ckey, group_type=0, use_flag=1)
        except ControlGroup.DoesNotExist :
            return APIErrorResponse(request, error_code.WRONG_INPUT, "Ckey is wrong.(There is no matching control group)")

        authUserList = AuthUserHasControlGroup.objects.\
            filter(control_group_id=cg, use_flag=1, auth_user_id__is_active=1).\
            values('auth_user_id__id', 'auth_user_id__email')

        mail_list_of_filtered_users = filter_user_list_using_mail_item_cd(
            request,
            authUserList,
            mail_item_cd=MAIL_ITEM_CODE['PAD Create/Modification'])

        if config_constants.AURORA_PROD_HANDLER == True or opts.get('is_valid', None) == 'Y':
            returnSucc = {"data": list(set(mail_list_of_filtered_users))}
        else:
            returnSucc = {"data": config_constants.EMAIL_ALERTS}

        return APIResponse(request, returnSucc)
    except Exception as e :
        return APIException(request, "999", e)

@csrf_exempt
def getAuthUserEmailListBySiteid(request, site_id):
    try:
        opts = getOptionalParams(request)
        opts_set = set(opts)
        available_fields = set(('username', 'password', 'is_valid'))
        required_fields = set(('username', 'password'))

        missing_opts = required_fields.difference(opts_set)

        if len(missing_opts) > 0:
            return APIErrorResponse(request, error_code.WRONG_INPUT, "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, error_code.WRONG_INPUT, "Invalid parameters in request: " + ", ".join(invalid_opts))

        try:
            stat = StatMaster.objects.get(keyword=site_id)
        except StatMaster.DoesNotExist:
            return APIErrorResponse(request, error_code.WRONG_SITE_ID, "Site_id is wrong.(There is no matching stat)")

        account = CustomerContract.objects.get(pk=CustomerItem.objects.get(pk=stat.item.pk).contract.pk).account
        item = stat.item

        authUserList = []

        try :
            cg = ControlGroup.objects.get(account_no=account, group_type=0, use_flag=1)
        except ControlGroup.DoesNotExist :
            return APIErrorResponse(request, error_code.WRONG_INPUT, "Site_id is wrong.(There is no matching control group)")

        listTmp = AuthUserHasControlGroup.objects.\
            filter(control_group_id=cg, use_flag=1, auth_user_id__is_active=1).\
            values('auth_user_id__id', 'auth_user_id__email')

        for u in listTmp :
            authUserList.append({
                'auth_user_id__id': u.get('auth_user_id__id'),
                'auth_user_id__email': u.get('auth_user_id__email'),
            })

        try :
            cg = ControlGroup.objects.get(item_id=item, group_type=1, use_flag=1)
        except ControlGroup.DoesNotExist :
            pass

        listTmp = AuthUserHasControlGroup.objects.\
            filter(control_group_id=cg, use_flag=1, auth_user_id__is_active=1).\
            values('auth_user_id__id', 'auth_user_id__email')

        for u in listTmp :
            authUserList.append({
                'auth_user_id__id': u.get('auth_user_id__id'),
                'auth_user_id__email': u.get('auth_user_id__email'),
            })

        cgList = StatItemWhiteList.objects.filter(stat_id=stat).values('control_group_id')
        cgList = [cg.get('control_group_id') for cg in cgList]

        listTmp = AuthUserHasControlGroup.objects.\
            filter(control_group_id__in=cgList, control_group_id__use_flag=1, auth_user_id__is_active=1).\
            values('auth_user_id__id', 'auth_user_id__email')

        for u in listTmp :
            authUserList.append({
                'auth_user_id__id': u.get('auth_user_id__id'),
                'auth_user_id__email': u.get('auth_user_id__email'),
            })

        mail_list_of_filtered_users = filter_user_list_using_mail_item_cd(
            request,
            authUserList,
            mail_item_cd=MAIL_ITEM_CODE['PAD Create/Modification'])

        if config_constants.AURORA_PROD_HANDLER == True or opts.get('is_valid', None) == 'Y':
            returnSucc = {"data": list(set(mail_list_of_filtered_users))}
        else:
            returnSucc = {"data": config_constants.EMAIL_ALERTS}

        return APIResponse(request, returnSucc)
    except Exception as e :
        return APIException(request, "999", e)


def filter_user_list_using_mail_item_cd(request, user_list, mail_item_cd=None):
    try:
        if mail_item_cd is not None:
            result = []
            user_ids = [str(user['auth_user_id__id']) for user in user_list]

            response = get_mail_notification_items_by_user_using_api(
                request,
                ",".join(user_ids),
                mail_item_cd)

            if response['success'] == 'OK':
                mail_notification_list = response['data']
            else:
                raise Exception

            if len(mail_notification_list):
                if mail_notification_list[0]['default_send'] == 1:
                    for user in user_list:
                        for item in mail_notification_list:
                            if user['auth_user_id__id'] == item['auth_user']:
                                user['auth_user_id__email'] = None
                                break
                        if user['auth_user_id__email']:
                            result.append(user['auth_user_id__email'])
                else:
                    for user in user_list:
                        for item in mail_notification_list:
                            if user['auth_user_id__id'] == item['auth_user']:
                                result.append(user['auth_user_id__email'])
                                break
            else:
                response = get_mail_item_code_by_id_using_api(request, mail_item_cd)

                if response['success'] == 'OK':
                    if response['data']['default_send'] == 1:
                        for user in user_list:
                            result.append(user['auth_user_id__email'])
                    else:
                        pass  # return []
                else:
                    raise Exception
            return result
        else:
            return user_list
    except Exception as e:
        raise e


def get_mail_item_code_by_id_using_api(request, mail_item_cd):
    try:
        response = api.request_api_server(
                    request,
                    api.CALL_TYPE['GET'],
                    '/mail_notification/codes/' + str(mail_item_cd) + '/')
        return response
    except Exception as e:
        log_error(request, "Mail notification API GET request call failed.", e=e)
        raise e


def get_mail_notification_items_by_user_using_api(request, user_ids, mail_item_cd):
    try:
        response = api.request_api_server(
                request,
                api.CALL_TYPE['GET'],
                '/mail_notification/items/',
                {
                    "auth_user": user_ids,
                    "mail_item": mail_item_cd
                })
        return response
    except Exception as e:
        log_error(request, "Mail notification API GET request call failed.", e=e)
        raise e