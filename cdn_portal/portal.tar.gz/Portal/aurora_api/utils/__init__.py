from aurora_api import error_code
from django.db.models.base import ModelBase
from django.db.models.fields import *
from django.forms import fields as formfields
from django.forms.util import ErrorList
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from django.utils import simplejson
from spectrum_fe.shared_components.utils.api import getOptionalParams
import logging

log = logging.getLogger(__name__)


class APIResponse(HttpResponse):
    def __init__(self, request, output, status=200):

        output['returnCode'] = error_code.SUCCESS
        output['returnMsg'] = 'Success'

        HttpResponse.__init__(self, content=simplejson.dumps(output), status=status)

class APIPantherResponse(HttpResponse):
    def __init__(self, request, output, status=200):
        HttpResponse.__init__(self, content=simplejson.dumps(output), status=status)

class APIErrorResponse(HttpResponse):
    def __init__(self, request, returnCode, returnMsg, status=200):

        reqDict = getOptionalParams(request)

        debugMsg = []
        debugMsg.extend(['%s=%s' % ('request_user', request.user.username)])
        debugMsg.extend(['%s=%s' % ('returnMsg', returnMsg)])

        for key in reqDict.iterkeys():
            valuelist = reqDict.getlist(key)

            for val in valuelist :
                if key == "password" :
                    debugMsg.extend(['%s=%s' % (key, "*******")])
                    continue
                debugMsg.extend(['%s=%s' % (key, val)])

        log.warn('&'.join(debugMsg))

        HttpResponse.__init__(self, content=simplejson.dumps({'returnCode':returnCode, 'returnMsg':returnMsg}), status=status)

class APIException(HttpResponse):
    def __init__(self, request, returnCode, error, status=200):

        reqDict = getOptionalParams(request)
        #aaa= aaa.__setitem__('error',str(error))

        debugMsg = []
        debugMsg.extend(['%s=%s' % ('request_user', request.user.username)])

        for key in reqDict.iterkeys():
            valuelist = reqDict.getlist(key)

            for val in valuelist :
                if key == "password" :
                    debugMsg.extend(['%s=%s' % (key, "*******")])
                    continue
                debugMsg.extend(['%s=%s' % (key, val)])

        log.exception('&'.join(debugMsg))
        HttpResponse.__init__(self, content=simplejson.dumps({'returnCode':returnCode, 'returnMsg':'Temporary error'}), status=status)
