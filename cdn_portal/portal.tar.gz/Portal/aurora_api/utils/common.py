from spectrum_fe.shared_components.models import StatMaster

def get_legacy_stat_list(request):
    if request.session['contract_stat'] != None:
        stat_list = StatMaster.all_objects.filter(item__in=request.session['contract_stat'])
    else:
        stat_list = StatMaster.all_objects.filter(stat_id__in=request.session['stat_list'])
    return stat_list
