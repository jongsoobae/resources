import os

if os.environ.get('DJANGO_SETTINGS_MODULE') is None:
    os.environ['DJANGO_SETTINGS_MODULE'] = 'aurora_api.settings'

import unittest2 as unittest
from django.http import QueryDict
from django.test import RequestFactory
from aurora_api.waf.views.waf_account import add_waf_account


class Test(unittest.TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.request = RequestFactory().get('')
        query_string = "username=cop_to_aurora@cdnetworks.com&password=auroraapi@cdnadmin&account_no=42975"

        get_data = QueryDict(query_string, mutable=True)
        self.request.GET = get_data

    def tearDown(self):
        pass

    def test_given_waf_account_is_already_exists_when_add_new_waf_account_then_throws_conflict_error(self):
        result = add_waf_account(self.request)
        self.assertEqual(result.content, '{"returnMsg": "WAF account is already exists", "returnCode": 409}')

