from django.conf.urls.defaults import patterns, url

urlpatterns = patterns('aurora_api.waf.views.waf_account',
    url(r'^add$', 'add_waf_account', name='add_waf_account'),
)
