from django.views.decorators.csrf import csrf_exempt

from aurora_api.utils import APIException, APIErrorResponse, APIPantherResponse

from aurora_fe.shared_components.models.fireblade import wafAccount
from aurora_fe.cloudsecurity.api.fireblade_api import fireblade_user_create

from spectrum_fe.shared_components.models.customer import CustomerAccount
from spectrum_fe.shared_components.utils.api import getOptionalParams
from spectrum_fe.shared_components.utils.common import log_error

import json

@csrf_exempt
def add_waf_account(request):
    try:
        opts = getOptionalParams(request)

        opts_set = set(opts)
        available_fields = set(('username', 'password', 'account_no'))
        required_fields = set(('username', 'password', 'account_no'))

        missing_opts = required_fields.difference(opts_set)

        if len(missing_opts) > 0:
            return APIErrorResponse(request, "104", "Following parameters are required: " + ", ".join(missing_opts))

        invalid_opts = opts_set.difference(available_fields)
        if len(invalid_opts) > 0:
            return APIErrorResponse(request, "104", "Invalid parameters in request: " + ", ".join(invalid_opts))

        # fireblade create api
        return_api_value = {}
        account_name = ''
        account_no = opts.get('account_no')

        try:
            customer_account = CustomerAccount.objects.get(account_no=account_no)
            account_name = customer_account.account_name_eng
        except CustomerAccount.DoesNotExist:
            return APIErrorResponse(request, "104", "Invalid account_no parameter in request")
        except ValueError:
            return APIErrorResponse(request, "104", "Invalid account_no parameter in request")

        try:
            # Check WAF account is already exists
            wafAccount.objects.get(account_no=account_no)
        except wafAccount.DoesNotExist:
            # Create new WAF account
            waf_email = 'cdn_%(account_no)s@cdnetworks.com' % {
                        'account_no': int(account_no)
                      }
            api_response = fireblade_user_create(request, account_no, waf_email, account_name[:100])
            api_response_data = json.loads(api_response.content)

            if api_response.status_code == 201:
                waf_account_id = api_response_data.get('account_id')

                waf_table = wafAccount(account_no = account_no, user_email = waf_email, waf_account_id = waf_account_id)
                waf_table.save(request=request)

                return_api_value = {'returnCode' : api_response.status_code}
            else:
                return_api_value = {'returnCode' : api_response.status_code, 'returnMsg' : api_response_data.get('errors')}

            return APIPantherResponse(request, return_api_value)
        else:
            # Do nothing
            return APIPantherResponse(request,
                                      {
                                          'returnCode': 409,
                                          'returnMsg': 'WAF account is already exists'
                                      })
    except Exception as e:
        log_error(request, 'fireblade api failed.', e)
        return APIException(request, "999", e)
