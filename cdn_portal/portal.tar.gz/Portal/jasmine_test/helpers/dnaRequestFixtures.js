var commonAjaxGetCurrentCustomerFixture = {
    "user_first_name": "selenium",
    "user_language": "en-us",
    "user_utc": "UTC +0",
    "customer_name": "CDNetworks Product Management      ",
    "account": 20036,
    "user_id": 10267,
    "user_mobile": "",
    "user_last_name": "hello",
    "is_superuser": false,
    "user_email": "selenium-testdriver-01@cdnetworks.com",
    "factor": "success",
    "customer_id": 1,
    "user_name": "selenium-testdriver-01@cdnetworks.com",
    "today": "2016-06-28 10:01",
    "user_time": "Jun 28, 2016 10:01:27 UTC +0"
};

var getDnaAppsFixture = {
    "status": "OK",
    "success": "OK",
    "status_code": "200",
    "reason": "",
    "detail_reason": "",
    "data": {
        "mproxy_app_id": "164",
        "services": [{
            "edge_domain_id": 5576,
            "external_domain": null,
            "dynamic_relay": 1,
            "domain_edge_id": 678,
            "edge_name": "fota-fra-mproxy-edge",
            "mproxy_edge_id": 406,
            "edge_domain_name": "fotatest2-dn.dna.cdngd.net",
            "origin_domain_id": 5578,
            "relay_domain_id": null,
            "shields": [{
                "pop_id": 605,
                "shield_domain_name": "fotatest2-dn.mshield.cdngd.net",
                "vips": [{
                    "ip": "14.0.75.66"
                }, {
                    "ip": "14.0.75.97"
                }, {
                    "ip": "14.0.75.82"
                }],
                "pop_name": "P59-ICN",
                "shield_domain_id": 5577,
                "pop_status": -1,
                "city_name": "Seoul"
            }],
            "displayname": "tcp/2022",
            "origins": [{
                "pop_id": 521,
                "vips": [{
                    "ip": "61.110.250.163"
                }, {
                    "ip": "61.110.250.142"
                }, {
                    "ip": "61.110.250.141"
                }, {
                    "ip": "61.110.250.162"
                }, {
                    "ip": "61.110.250.143"
                }],
                "origin_domain_id": 5578,
                "origin_domain_name": "fotatest2-dn.morigin.cdngd.net",
                "pop_name": "P51-ICN",
                "pop_status": -1,
                "city_name": "Seoul"
            }],
            "shield_domain_id": 5577,
            "edges": [{
                "pop_id": 766,
                "vips": [{
                    "ip": "174.35.71.205"
                }, {
                    "ip": "174.35.71.219"
                }, {
                    "ip": "151.249.90.93"
                }, {
                    "ip": "174.35.71.209"
                }],
                "pop_name": "P11-FRA",
                "pop_status": -1,
                "domain_edge_id": 678,
                "city_name": "Frankfurt am main"
            }, {
                "pop_id": 605,
                "vips": [{
                    "ip": "14.0.75.67"
                }, {
                    "ip": "14.0.75.122"
                }, {
                    "ip": "14.0.75.110"
                }],
                "pop_name": "P59-ICN",
                "pop_status": -1,
                "domain_edge_id": 678,
                "city_name": "Seoul"
            }],
            "edge_id": 413,
            "external_domain_enabled": 0,
            "protocol": "tcp",
            "dynamics": [],
            "mproxy_preset_id": 1,
            "relays": [{
                "relay_domain_name": null,
                "vips": [{
                    "ip": null
                }],
                "pop_id": null,
                "relay_domain_id": null,
                "pop_name": null,
                "pop_status": -1,
                "city_name": null
            }],
            "port": "2022"
        }],
        "mproxy_app_name": "upload.starfs.samsung.cdnetworks.com"
    }
};

var getDnaApps3ServiceItemFixture = {
    "status": "OK",
    "success": "OK",
    "status_code": "200",
    "reason": "",
    "detail_reason": "",
    "data": {
        "mproxy_app_id": "313",
        "services": [{
            "edge_domain_id": 11869,
            "external_domain": null,
            "dynamic_relay": 0,
            "domain_edge_id": 1778,
            "edge_name": "3dns_test",
            "mproxy_edge_id": 881,
            "edge_domain_name": "mproxy.multirelay.edge.com",
            "origin_domain_id": 11871,
            "relay_domain_id": null,
            "shields": [{
                "pop_id": 928,
                "shield_domain_name": "mproxy.multirelay.shield.com",
                "vips": [{
                    "ip": "134.213.1.17"
                }],
                "pop_name": "C0-LHR",
                "shield_domain_id": 11870,
                "pop_status": -1,
                "city_name": "London"
            }],
            "displayname": "tcp/8080,9030,4050",
            "origins": [{
                "pop_id": 533,
                "vips": [{
                    "ip": "136.166.4.203"
                }],
                "origin_domain_id": 11871,
                "origin_domain_name": "mproxy.multirelay.origin.com",
                "pop_name": "CP-JFK",
                "pop_status": -1,
                "city_name": "New York"
            }],
            "shield_domain_id": 11870,
            "edges": [{
                "pop_id": 605,
                "vips": [{
                    "ip": "14.0.67.222"
                }, {
                    "ip": "14.0.68.215"
                }],
                "pop_name": "P59-ICN",
                "pop_status": -1,
                "domain_edge_id": 1778,
                "city_name": "Seoul"
            }],
            "edge_id": 330,
            "external_domain_enabled": 0,
            "protocol": "tcp",
            "dynamics": [],
            "mproxy_preset_id": 1,
            "relays": [{
                "relay_domain_name": null,
                "vips": [{
                    "ip": null
                }],
                "pop_id": null,
                "relay_domain_id": null,
                "pop_name": null,
                "pop_status": -1,
                "city_name": null
            }],
            "port": "8080,9030,4050"
        }, {
            "edge_domain_id": 11869,
            "external_domain": null,
            "dynamic_relay": 1,
            "domain_edge_id": 1778,
            "edge_name": "3dns_test",
            "mproxy_edge_id": 882,
            "edge_domain_name": "mproxy.multirelay.edge.com",
            "origin_domain_id": 11871,
            "relay_domain_id": null,
            "shields": [{
                "pop_id": 928,
                "shield_domain_name": "mproxy.multirelay.shield.com",
                "vips": [{
                    "ip": "134.213.1.17"
                }],
                "pop_name": "C0-LHR",
                "shield_domain_id": 11870,
                "pop_status": -1,
                "city_name": "London"
            }],
            "displayname": "tcp/7000,7001,7001,7040,7080,8010,9000",
            "origins": [{
                "pop_id": 533,
                "vips": [{
                    "ip": "136.166.4.203"
                }],
                "origin_domain_id": 11871,
                "origin_domain_name": "mproxy.multirelay.origin.com",
                "pop_name": "CP-JFK",
                "pop_status": -1,
                "city_name": "New York"
            }],
            "shield_domain_id": 11870,
            "edges": [{
                "pop_id": 605,
                "vips": [{
                    "ip": "14.0.68.215"
                }, {
                    "ip": "14.0.67.222"
                }],
                "pop_name": "P59-ICN",
                "pop_status": -1,
                "domain_edge_id": 1778,
                "city_name": "Seoul"
            }],
            "edge_id": 330,
            "external_domain_enabled": 0,
            "protocol": "tcp",
            "dynamics": [],
            "mproxy_preset_id": 1,
            "relays": [{
                "relay_domain_name": null,
                "vips": [{
                    "ip": null
                }],
                "pop_id": null,
                "relay_domain_id": null,
                "pop_name": null,
                "pop_status": -1,
                "city_name": null
            }],
            "port": "7000,7001,7001,7040,7080,8010,9000"
        }, {
            "edge_domain_id": 11869,
            "external_domain": null,
            "dynamic_relay": 1,
            "domain_edge_id": 1778,
            "edge_name": "3dns_test",
            "mproxy_edge_id": 883,
            "edge_domain_name": "mproxy.multirelay.edge.com",
            "origin_domain_id": 3325,
            "relay_domain_id": null,
            "shields": [{
                "pop_id": 773,
                "shield_domain_name": "www.clarins.com.cn.hkg-tpe.mshield.cdnetworks.net",
                "vips": [{
                    "ip": "175.41.10.2"
                }, {
                    "ip": "175.41.11.144"
                }],
                "pop_name": "P5-HKG",
                "shield_domain_id": 2071,
                "pop_status": -1,
                "city_name": "Hong kong"
            }],
            "displayname": "tcp/80",
            "origins": [{
                "pop_id": 831,
                "vips": [{
                    "ip": "199.108.92.238"
                }],
                "origin_domain_id": 3325,
                "origin_domain_name": "vistest.mclarens.com.mclaren.morigin.cdnetworks.net",
                "pop_name": "CMCLARENS-JFK",
                "pop_status": -1,
                "city_name": "New York"
            }],
            "shield_domain_id": 2071,
            "edges": [{
                "pop_id": 605,
                "vips": [{
                    "ip": "14.0.68.215"
                }, {
                    "ip": "14.0.67.222"
                }],
                "pop_name": "P59-ICN",
                "pop_status": -1,
                "domain_edge_id": 1778,
                "city_name": "Seoul"
            }],
            "edge_id": 330,
            "external_domain_enabled": 0,
            "protocol": "tcp",
            "dynamics": [],
            "mproxy_preset_id": null,
            "relays": [{
                "relay_domain_name": null,
                "vips": [{
                    "ip": null
                }],
                "pop_id": null,
                "relay_domain_id": null,
                "pop_name": null,
                "pop_status": -1,
                "city_name": null
            }],
            "port": "80"
        }],
        "mproxy_app_name": "mproxy.multirelay.com"
    }
}
var getMproxyEdgeRoutingPath1RelayItemFixture = {
    "status": "OK",
    "success": "OK",
    "status_code": "200",
    "reason": "",
    "detail_reason": "",
    "data": {
        "shield_domain_name": "fotatest2-dn.mshield.cdngd.net",
        "relay_pop_code": ["P0-ULN"],
        "protocol": "tcp",
        "mproxy_edge_id": "406",
        "shield_pop_code": "P59-ICN",
        "relay_domain": "",
        "mproxy_preset_id": 1,
        "relay_pop_city": ["Ulaanbaatar"],
        "dynamic_relay": "True",
        "edge_pop_code": "P11-FRA",
        "origin_pop_code": "P51-ICN",
        "origin_ip_list": ["61.110.250.162"],
        "mproxy_app_id": "164",
        "relay_ip_list": [
            ["14.0.59.130", "14.0.59.135"],
        ],
        "shield_ip_list": ["14.0.75.97", "14.0.75.82"],
        "origin_domain_name": "fotatest2-dn.morigin.cdngd.net",
        "relay_pop_status": [-1],
        "port": "2022"
    }
};

var getMproxyEdgeRoutingPath2RelayItemFixture = {
    "status": "OK",
    "success": "OK",
    "status_code": "200",
    "reason": "",
    "detail_reason": "",
    "data": {
        "shield_domain_name": "fotatest2-dn.mshield.cdngd.net",
        "relay_pop_code": ["P0-ULN", "P59-ICN"],
        "protocol": "tcp",
        "mproxy_edge_id": "406",
        "shield_pop_code": "P59-ICN",
        "relay_domain": "",
        "mproxy_preset_id": 1,
        "relay_pop_city": ["Ulaanbaatar", "Seoul"],
        "dynamic_relay": "True",
        "edge_pop_code": "P11-FRA",
        "origin_pop_code": "P51-ICN",
        "origin_ip_list": ["61.110.250.162", "61.110.250.142"],
        "mproxy_app_id": "164",
        "relay_ip_list": [
            ["14.0.59.130", "14.0.59.135"],
            ["14.0.75.97", "14.0.75.82"]
        ],
        "shield_ip_list": ["14.0.75.97", "14.0.75.82"],
        "origin_domain_name": "fotatest2-dn.morigin.cdngd.net",
        "relay_pop_status": [-1, -1],
        "port": "2022"
    }
};

var getMproxyEdgeRoutingPath3RelayItemFixture = {
    "status": "OK",
    "success": "OK",
    "status_code": "200",
    "reason": "",
    "detail_reason": "",
    "data": {
        "shield_domain_name": "fotatest2-dn.mshield.cdngd.net",
        "relay_pop_code": ["P0-ULN", "P59-ICN", "P1-TST"],
        "protocol": "tcp",
        "mproxy_edge_id": "406",
        "shield_pop_code": "P59-ICN",
        "relay_domain": "",
        "mproxy_preset_id": 1,
        "relay_pop_city": ["Ulaanbaatar", "Seoul", "TestCity"],
        "dynamic_relay": "True",
        "edge_pop_code": "P11-FRA",
        "origin_pop_code": "P51-ICN",
        "origin_ip_list": ["61.110.250.162", "61.110.250.142"],
        "mproxy_app_id": "164",
        "relay_ip_list": [
            ["14.0.59.130", "14.0.59.135"],
            ["14.0.75.97", "14.0.75.82"],
            ["14.0.15.97", "14.0.15.82"]
        ],
        "shield_ip_list": ["14.0.75.97", "14.0.75.82"],
        "origin_domain_name": "fotatest2-dn.morigin.cdngd.net",
        "relay_pop_status": [-1, 1, 2],
        "port": "2022"
    }
};

var getMproxyEdgeRoutingPath2DuplicatedRelayItemFixture = {
    "status": "OK",
    "success": "OK",
    "status_code": "200",
    "reason": "",
    "detail_reason": "",
    "data": {
        "shield_domain_name": "fotatest2-dn.mshield.cdngd.net",
        "relay_pop_code": ["P0-ULN", "P0-ULN"],
        "protocol": "tcp",
        "mproxy_edge_id": "406",
        "shield_pop_code": "P59-ICN",
        "relay_domain": "",
        "mproxy_preset_id": 1,
        "relay_pop_city": ["Ulaanbaatar", "Ulaanbaatar"],
        "dynamic_relay": "True",
        "edge_pop_code": "P11-FRA",
        "origin_pop_code": "P51-ICN",
        "origin_ip_list": ["61.110.250.162", "61.110.250.142"],
        "mproxy_app_id": "164",
        "relay_ip_list": [
            ["14.0.59.130", "14.0.59.135"],
            ["14.0.59.130", "14.0.59.135"],
        ],
        "shield_ip_list": ["14.0.75.97", "14.0.75.82"],
        "origin_domain_name": "fotatest2-dn.morigin.cdngd.net",
        "relay_pop_status": [-1, -1],
        "port": "2022"
    }
};

var getAccountListFixture = {
    "accountList": [
        [20036, "CDNetworks Product Management"]
    ],
    "selected_account": 20036,
    "from_date": "",
    "to_date": "",
    "factor": "success",
    "date_selection": ""
};

var saveSessionFixture = {
    "session": "ok",
    "factor": "success"
};

var getControlGroupFixture = {
    "selected_control_group": "1037",
    "control_group": [
        ["CDNetworks Product Management      ", 1037]
    ],
    "factor": "success"
};

var getServiceDomainListFixture = {
    "status": "OK",
    "success": "OK",
    "status_code": "200",
    "reason": "",
    "detail_reason": "",
    "data": [{
        "mproxy_app_id": 164,
        "customer": 1,
        "account": 20036,
        "mproxy_app_name": "upload.starfs.samsung.cdnetworks.com"
    }]
};