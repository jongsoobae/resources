'use strict';

describe('Aurora - Dynamic Network Acceleration Page', function() {

    beforeEach(function() {
        module('aurora');
    });

    describe('dnaRoutingPathController', function() {

        var $scope;
        var $auroraFactory;
        var $dnaFactory;
        var $dnaRoutingPathController;

        var $httpBackend;

        beforeEach(inject(function($rootScope, $controller, $injector) {

            $scope = $rootScope.$new();

            $auroraFactory = $injector.get('auroraFactory');
            $dnaFactory = $injector.get('dnaFactory');

            $dnaRoutingPathController = $controller('dnaRoutingPathController', {
                '$scope': $scope,
                'auroraFactory': $auroraFactory,
                'dnaFactory': $dnaFactory
            });

            $httpBackend = $injector.get('$httpBackend');

        }));

        it('should be empty grphicContext when dna_apps is empty', function() {

            $scope.initializeGraphicContext();

            expect(Array.isArray($scope.dna_apps)).toBe(true);
            expect($scope.graphicContext).toEqual({});

        });

        it('should have object type grphicContext when dna_apps is not empty', function() {

            // setup http request flow
            $httpBackend
                .expectGET('/common_ajax/get_current_customer/')
                .respond(200, commonAjaxGetCurrentCustomerFixture);

            $httpBackend
                .expectGET('get_dna_apps/?mproxy_app_id=164')
                .respond(200, getDnaAppsFixture);

            $httpBackend
                .expectGET('/common_ajax/get_account_list_rf/?menu_id=394')
                .respond(200, getAccountListFixture);

            $httpBackend
                .expectPOST('/common_ajax/save_session/', 'filter_account=20036&filter_cust=1037&date_selection=&from_date=&to_date=')
                .respond(200, saveSessionFixture);

            $httpBackend
                .expectGET('/common_ajax/get_control_group/?account_id=20036')
                .respond(200, getControlGroupFixture);

            $httpBackend
                .expectGET('/dna/monitoring/alert/get_service_domain_list/?account_no=20036&control_group_id=1037')
                .respond(200, getServiceDomainListFixture);

            // setup scope variables
            $scope.menu_id = 394;
            $scope.account_id = 20036;
            $scope.selected_control_group = 1037;
            $scope.search_app.mproxy_app = 164;

            $scope.search_mproxy_app();

            $httpBackend.flush();

            // graphic context has 1 dna app item
            expect(Object.keys($scope.graphicContext).length).toEqual(1);
        });

        it('should have 2 relay pop UI when routingPathResponse has 2 relay pop', function() {

            // setup http request flow
            $httpBackend
                .expectGET('/common_ajax/get_current_customer/')
                .respond(200, commonAjaxGetCurrentCustomerFixture);

            $httpBackend
                .expectGET('get_dna_apps/?mproxy_app_id=164')
                .respond(200, getDnaAppsFixture);

            $httpBackend
                .expectGET('get_mproxy_edge_routing_path/?edge_pop_code=P11-FRA&mproxy_edge=406')
                .respond(200, getMproxyEdgeRoutingPath2RelayItemFixture);

            $httpBackend
                .expectGET('/common_ajax/get_account_list_rf/?menu_id=394')
                .respond(200, getAccountListFixture);

            $httpBackend
                .expectPOST('/common_ajax/save_session/', 'filter_account=20036&filter_cust=1037&date_selection=&from_date=&to_date=')
                .respond(200, saveSessionFixture);

            $httpBackend
                .expectGET('/common_ajax/get_control_group/?account_id=20036')
                .respond(200, getControlGroupFixture);

            $httpBackend
                .expectGET('/dna/monitoring/alert/get_service_domain_list/?account_no=20036&control_group_id=1037')
                .respond(200, getServiceDomainListFixture);

            // setup scope variables
            $scope.menu_id = 394;
            $scope.account_id = 20036;
            $scope.selected_control_group = 1037;
            $scope.search_app.mproxy_app = 164;

            // setup function flow
            $scope.search_mproxy_app();
            $scope.routing_path_call('P11-FRA', '406');

            // digest http requests
            $httpBackend.flush();

            expect($scope.m_edge_routing_path).toBeDefined();
            expect($scope.graphicContext).toBeDefined();

            // selected service should be 1
            expect(Object.keys($scope.graphicContext).length).toEqual(1);

            // service's relay item should be 2
            expect(Object.keys($scope.graphicContext['406'].relayUI).length).toEqual(2);

            // 2 relay container's width should be 230 px.
            expect($scope.graphicContext['406'].relayContainerWidth).toEqual(230);

        });

        it('should have 1 relay pop UI when routingPathResponse has 1 relay pop', function() {

            // setup http request flow
            $httpBackend
                .expectGET('/common_ajax/get_current_customer/')
                .respond(200, commonAjaxGetCurrentCustomerFixture);

            $httpBackend
                .expectGET('get_dna_apps/?mproxy_app_id=164')
                .respond(200, getDnaAppsFixture);

            $httpBackend
                .expectGET('get_mproxy_edge_routing_path/?edge_pop_code=P11-FRA&mproxy_edge=406')
                .respond(200, getMproxyEdgeRoutingPath1RelayItemFixture);

            $httpBackend
                .expectGET('/common_ajax/get_account_list_rf/?menu_id=394')
                .respond(200, getAccountListFixture);

            $httpBackend
                .expectPOST('/common_ajax/save_session/', 'filter_account=20036&filter_cust=1037&date_selection=&from_date=&to_date=')
                .respond(200, saveSessionFixture);

            $httpBackend
                .expectGET('/common_ajax/get_control_group/?account_id=20036')
                .respond(200, getControlGroupFixture);

            $httpBackend
                .expectGET('/dna/monitoring/alert/get_service_domain_list/?account_no=20036&control_group_id=1037')
                .respond(200, getServiceDomainListFixture);

            // setup scope variables
            $scope.menu_id = 394;
            $scope.account_id = 20036;
            $scope.selected_control_group = 1037;
            $scope.search_app.mproxy_app = 164;

            // setup function flow
            $scope.search_mproxy_app();
            $scope.routing_path_call('P11-FRA', '406');

            // digest http requests
            $httpBackend.flush();

            expect($scope.m_edge_routing_path).toBeDefined();
            expect($scope.graphicContext).toBeDefined();

            // selected service should be 1
            expect(Object.keys($scope.graphicContext).length).toEqual(1);

            // service's relay item should be 1
            expect(Object.keys($scope.graphicContext['406'].relayUI).length).toEqual(1);

            // 2 relay container's width should be 160 px.
            expect($scope.graphicContext['406'].relayContainerWidth).toEqual(160);
        });

        it('should have 3 relay pop UI when routingPathResponse has 3 relay pop', function() {

            // setup http request flow
            $httpBackend
                .expectGET('/common_ajax/get_current_customer/')
                .respond(200, commonAjaxGetCurrentCustomerFixture);

            $httpBackend
                .expectGET('get_dna_apps/?mproxy_app_id=164')
                .respond(200, getDnaAppsFixture);

            $httpBackend
                .expectGET('get_mproxy_edge_routing_path/?edge_pop_code=P11-FRA&mproxy_edge=406')
                .respond(200, getMproxyEdgeRoutingPath3RelayItemFixture);

            $httpBackend
                .expectGET('/common_ajax/get_account_list_rf/?menu_id=394')
                .respond(200, getAccountListFixture);

            $httpBackend
                .expectPOST('/common_ajax/save_session/', 'filter_account=20036&filter_cust=1037&date_selection=&from_date=&to_date=')
                .respond(200, saveSessionFixture);

            $httpBackend
                .expectGET('/common_ajax/get_control_group/?account_id=20036')
                .respond(200, getControlGroupFixture);

            $httpBackend
                .expectGET('/dna/monitoring/alert/get_service_domain_list/?account_no=20036&control_group_id=1037')
                .respond(200, getServiceDomainListFixture);

            // setup scope variables
            $scope.menu_id = 394;
            $scope.account_id = 20036;
            $scope.selected_control_group = 1037;
            $scope.search_app.mproxy_app = 164;

            // setup spy
            spyOn($scope, 'draw_routing_path_line');

            // setup function flow
            $scope.search_mproxy_app();
            $scope.routing_path_call('P11-FRA', '406');

            // digest http requests
            $httpBackend.flush();

            expect($scope.draw_routing_path_line).toHaveBeenCalled();

            expect($scope.m_edge_routing_path).toBeDefined();
            expect($scope.graphicContext).toBeDefined();

            // selected service should be 1
            expect(Object.keys($scope.graphicContext).length).toEqual(1);

            // service's relay item should be 2
            expect(Object.keys($scope.graphicContext['406'].relayUI).length).toEqual(3);


            var serviceContext = $scope.graphicContext['406'];

            // 3 relay container's width should be 350 px.
            expect(serviceContext.relayContainerWidth).toEqual(350);
            // strict check
            expect(serviceContext.relayContainerWidth).toEqual($scope.relayLayerItemWidth * 3 - 10);

            // expect each relay ui components
            var firstRelayItem = serviceContext.relayUI[0];
            expect(firstRelayItem.cityName).toEqual('Ulaanbaatar');
            expect(firstRelayItem.popCode).toEqual('P0-ULN');
            expect(firstRelayItem.popStatus).toEqual(-1);
            expect(firstRelayItem.imgSrc).toEqual($scope.popServerStatusImage[-1]);

            var secondRelayItem = serviceContext.relayUI[1];
            expect(secondRelayItem.cityName).toEqual('Seoul');
            expect(secondRelayItem.popCode).toEqual('P59-ICN');
            expect(secondRelayItem.popStatus).toEqual(1);
            expect(secondRelayItem.imgSrc).toEqual($scope.popServerStatusImage[1]);

            var thirdRelayItem = serviceContext.relayUI[2];
            expect(thirdRelayItem.cityName).toEqual('TestCity');
            expect(thirdRelayItem.popCode).toEqual('P1-TST');
            expect(thirdRelayItem.popStatus).toEqual(2);
            expect(thirdRelayItem.imgSrc).toEqual($scope.popServerStatusImage[2]);

        });


        it('should have 2 relay pop UI when routingPathResponse has 2 duplicated relay pop', function() {

            // setup http request flow
            $httpBackend
                .expectGET('/common_ajax/get_current_customer/')
                .respond(200, commonAjaxGetCurrentCustomerFixture);

            $httpBackend
                .expectGET('get_dna_apps/?mproxy_app_id=164')
                .respond(200, getDnaAppsFixture);

            $httpBackend
                .expectGET('get_mproxy_edge_routing_path/?edge_pop_code=P11-FRA&mproxy_edge=406')
                .respond(200, getMproxyEdgeRoutingPath2DuplicatedRelayItemFixture);

            $httpBackend
                .expectGET('/common_ajax/get_account_list_rf/?menu_id=394')
                .respond(200, getAccountListFixture);

            $httpBackend
                .expectPOST('/common_ajax/save_session/', 'filter_account=20036&filter_cust=1037&date_selection=&from_date=&to_date=')
                .respond(200, saveSessionFixture);

            $httpBackend
                .expectGET('/common_ajax/get_control_group/?account_id=20036')
                .respond(200, getControlGroupFixture);

            $httpBackend
                .expectGET('/dna/monitoring/alert/get_service_domain_list/?account_no=20036&control_group_id=1037')
                .respond(200, getServiceDomainListFixture);

            // setup scope variables
            $scope.menu_id = 394;
            $scope.account_id = 20036;
            $scope.selected_control_group = 1037;
            $scope.search_app.mproxy_app = 164;

            // setup function flow
            $scope.search_mproxy_app();
            $scope.routing_path_call('P11-FRA', '406');

            // digest http requests
            $httpBackend.flush();

            console.log($scope)
            expect($scope.m_edge_routing_path).toBeDefined();
            expect($scope.graphicContext).toBeDefined();

            // selected service should be 1
            expect(Object.keys($scope.graphicContext).length).toEqual(1);

            // service's relay item should be 2
            expect(Object.keys($scope.graphicContext['406'].relayUI).length).toEqual(2);

            // 2 relay container's width should be 230 px.
            expect($scope.graphicContext['406'].relayContainerWidth).toEqual(230);

        });

    });

});
