#!/bin/bash

export PRISM_INTERNAL_USER_NAME=juwon.lee
export PRISM_INTERNAL_USER_PASS=Fkls560tru11w#@
