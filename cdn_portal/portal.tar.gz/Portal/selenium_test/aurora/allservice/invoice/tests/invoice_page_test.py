import unittest

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver


class InvoicePageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_internal_user_when_display_invoice_page_then_should_be_shown(self):
        driver = self.driver
        ###########################################################################################################
        driver.find_elements(By.XPATH, "//span[text() = 'All Services']")[0].click()

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[text() = 'Invoice']"))
        )

        driver.find_elements(By.XPATH, "//a[text() = 'Invoice']")[0].click()

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "btn_filter"))
        )

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "account_list_chosen"))
        )

        el1 = driver.find_element(By.ID, "account_list_chosen")
        driver.implicitly_wait(1)
        el4 = el1.find_element(By.CSS_SELECTOR, ".chosen-single")
        el4.click()

        el6 = el1.find_element(By.XPATH, "//input[@type='text']")
        el6.clear()
        el6.send_keys('32red')
        el6.send_keys(Keys.RETURN)

        el = driver.find_element(By.ID, "from_date")
        el.clear()
        el.send_keys('2014-10-01')

        el = driver.find_element(By.ID, "to_date")
        el.clear()
        el.send_keys('2015-10-01')

        el = driver.find_element(By.ID, "btn_filter")
        el.click()

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, './/th[contains(text(), "Invoice Number")]'))
        )
        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
