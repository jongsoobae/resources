import unittest

from datetime import datetime

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from selenium_test.config_user_constants import AURORA_INTERNAL_USER


class StoragePageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    # [AURORAUI-3167]
    def test_available_years(self):
        driver = self.driver
        ###########################################################################################################
        driver.find_elements(By.XPATH, "//span[text() = 'All Services']")[0].click()

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[text() = 'Storage']"))
        )

        driver.find_elements(By.XPATH, "//a[text() = 'Storage']")[0].click()

        year_options_in_calendar = driver.find_elements(By.CSS_SELECTOR, "select.ui-datepicker-year > option")

        self.assertEqual(len(year_options_in_calendar), 2)

        current_year = datetime.now().year

        self.assertEqual(current_year - 1, int(year_options_in_calendar[0].text))
        self.assertEqual(current_year, int(year_options_in_calendar[1].text))

        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
