
import time

from selenium_test.shared_components import testcase


class TestBhrDashboardTestCase(testcase.AuroraTestCase):

    @classmethod
    def setUpClass(cls):
        super(TestBhrDashboardTestCase, cls).setUpClass()

        cls.direct_to('/cs/blocked_ip_info/?m=411')


class TestBhrDashboardWithoutData(TestBhrDashboardTestCase):

    def test_no_data(self):

        # get report view button
        view_report_button = self.driver.find_element_by_xpath(
            '//input[@id="btn_view"]')

        view_report_button.click()

        time.sleep(5)

        # get indicator elements
        indicator_elements = self.driver.find_elements_by_xpath(
            '//div[@class="indicator"]')

        # filter no data indicator
        no_data_indicators = [elem for elem in indicator_elements if elem.text == 'No Data.']

        # elements length should be 3
        self.assertEqual(len(no_data_indicators), 3)


class TestBhrDashboard(TestBhrDashboardTestCase):

    def test_a_report_settings_ui_select_customer(self):

        # find customer dropdown ui
        select_cutsomer_dropdown_ui = self.driver.find_element_by_xpath(
            '//div[@id="id_filter_account_chosen"]')

        self.assertIsNotNone(select_cutsomer_dropdown_ui)

        # click to input customer
        select_cutsomer_dropdown_ui.click()
        select_customer_text_input = select_cutsomer_dropdown_ui.find_element_by_xpath(
            './/input[@type="text"]')

        # input customer input to find customer
        select_customer_text_input.send_keys('abb')

        # wait
        time.sleep(3)

        # get found customer listitem
        found_customer = select_cutsomer_dropdown_ui.find_element_by_xpath(
            './/li[contains(@class, "active-result")]')

        # click to select found customer
        self.assertIsNotNone(found_customer)
        found_customer.click()

    def test_b_report_settings_ui_select_daterange(self):

        # set daterange to custom
        customer_daterange_button = self.driver.find_element_by_xpath(
            '//button[@data-value="specified"]')

        customer_daterange_button.click()

        # find from & to datetime picker input
        from_date_input = self.driver.find_element_by_xpath(
            '//input[@id="id_date_from"]')

        self.assertIsNotNone(from_date_input)

        to_date_input = self.driver.find_element_by_xpath(
            '//input[@id="id_date_to"]')

        self.assertIsNotNone(to_date_input)

        # set customized report date
        from_date_input.clear()
        from_date_input.send_keys('2016-06-28')

        to_date_input.clear()
        to_date_input.send_keys('2016-06-30')

        time.sleep(3)

    def test_c_report_settings_ui_show_report(self):

        # get report view button
        view_report_button = self.driver.find_element_by_xpath(
            '//input[@id="btn_view"]')

        view_report_button.click()

        time.sleep(5)

    def test_d_validate_ui_components(self):

        num_of_blocked_ip_section = self.driver.find_element_by_xpath(
            '//div[@id="container_STAT_BHR_NUMBER_OF_BLOCKED_IP"]')
        self.assertIsNotNone(num_of_blocked_ip_section)

        chart_container = num_of_blocked_ip_section.find_element_by_xpath(
            './/div[@id="C_STAT_BHR_NUMBER_OF_BLOCKED_IP"]')
        self.assertIsNotNone(chart_container)

        chart_summary = num_of_blocked_ip_section.find_element_by_xpath(
            './/div[@id="I_STAT_BHR_NUMBER_OF_BLOCKED_IP"]')
        self.assertIsNotNone(chart_summary)

        blocked_ip_list_section = self.driver.find_element_by_xpath(
            '//div[@id="container_STAT_BHR_BLOCKED_IP_LIST"]')
        self.assertIsNotNone(blocked_ip_list_section)

        search_section = blocked_ip_list_section.find_element_by_xpath(
            './/div[@class="block_ip_list_search_section"]')
        self.assertIsNotNone(search_section)

        table_section = blocked_ip_list_section.find_element_by_xpath(
            './/div[@id="T_STAT_BHR_BLOCKED_IP_LIST"]')
        self.assertIsNotNone(table_section)

        blocked_ip_location_section = self.driver.find_element_by_xpath(
            '//div[@id="container_STAT_BHR_BLOCKED_IP_LOCATION"]')
        self.assertIsNotNone(blocked_ip_location_section)

        map_section = blocked_ip_location_section.find_element_by_xpath(
            './/div[@id="M_STAT_BHR_BLOCKED_IP_LOCATION"]')
        self.assertIsNotNone(map_section)

        table_section = blocked_ip_location_section.find_element_by_xpath(
            './/div[@id="T_STAT_BHR_BLOCKED_IP_LOCATION"]')
        self.assertIsNotNone(table_section)

    def test_e_blocked_ip_list_control_ui_search_ipaddr(self):

        blocked_ip_list_section = self.driver.find_element_by_xpath(
            '//div[@id="container_STAT_BHR_BLOCKED_IP_LIST"]')
        self.assertIsNotNone(blocked_ip_list_section)

        search_section = blocked_ip_list_section.find_element_by_xpath(
            './/div[@class="block_ip_list_search_section"]')
        self.assertIsNotNone(search_section)

        ip_address_search_input = search_section.find_element_by_xpath(
            './/input[@id="blocked_ip_address"]')
        self.assertIsNotNone(ip_address_search_input)

        search_submit_button = search_section.find_element_by_xpath(
            './/button[@id="blocked_ip_list_search_btn"]')
        self.assertIsNotNone(search_submit_button)

        # search blocked ip scenario
        ip_address_search_input.clear()
        ip_address_search_input.send_keys('10.0.154')

        search_submit_button.click()

        time.sleep(5)

        table_section = blocked_ip_list_section.find_element_by_xpath(
            './/div[@id="T_STAT_BHR_BLOCKED_IP_LIST"]')
        self.assertIsNotNone(table_section)

        table_items = table_section.find_elements_by_xpath(
            './/div[contains(@class, "slick-row")]')
        # the number of found ip should be 1 item
        self.assertEqual(len(table_items), 1)

    def test_f_blocked_ip_location_drilldown(self):

        blocked_ip_location_section = self.driver.find_element_by_xpath(
            '//div[@id="container_STAT_BHR_BLOCKED_IP_LOCATION"]')
        self.assertIsNotNone(blocked_ip_location_section)

        map_section = blocked_ip_location_section.find_element_by_xpath(
            './/div[@id="M_STAT_BHR_BLOCKED_IP_LOCATION"]')
        self.assertIsNotNone(map_section)

        china_svg_element = map_section.find_element_by_xpath(
            './/*[local-name()="path" and @fill="rgb(157,169,189)"]')
        self.assertIsNotNone(china_svg_element)

        # click to drilldown
        china_svg_element.click()
        time.sleep(5)

    def test_g_blocked_ip_location_drillup(self):

        blocked_ip_location_section = self.driver.find_element_by_xpath(
            '//div[@id="container_STAT_BHR_BLOCKED_IP_LOCATION"]')
        self.assertIsNotNone(blocked_ip_location_section)

        map_section = blocked_ip_location_section.find_element_by_xpath(
            './/div[@id="M_STAT_BHR_BLOCKED_IP_LOCATION"]')
        self.assertIsNotNone(map_section)

        back_to_worldmap_button = map_section.find_element_by_xpath(
            './/*[local-name()="g" and @class="highcharts-button"]')
        self.assertIsNotNone(back_to_worldmap_button)

        # click to drillup
        back_to_worldmap_button.click()
        time.sleep(5)
