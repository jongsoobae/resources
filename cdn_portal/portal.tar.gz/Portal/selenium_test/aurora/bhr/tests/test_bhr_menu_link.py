
import time

from selenium_test.shared_components import testcase


class TestBhrMenu(testcase.AuroraTestCase):

    bhr_page_url = '/cs/blocked_ip_info/'
    parent_menu_link_xpath_query = \
        '//menu[@class="product-gnb"]//li//span[contains(text(), "%s")]'

    def setUp(self):
        self.direct_to('/')

    def get_bhr_link_element_from_parent_menu(self, parent_menu_name):

        paernt_menu_link = self.driver.find_element_by_xpath(
            self.parent_menu_link_xpath_query % parent_menu_name)

        paernt_menu_link.click()

        bhr_menu_link = paernt_menu_link.find_element_by_xpath(
            '..//menu//a[contains(text(), "Blocked IP Information")]')

        return bhr_menu_link

    def test_bhr_menu_in_content_acceleration(self):

        bhr_menu_link = self.get_bhr_link_element_from_parent_menu(
            parent_menu_name='Content Acceleration')

        bhr_menu_link.click()

        self.assertTrue(
            self.driver.current_url.find(self.bhr_page_url) > -1)

        time.sleep(1)

    def test_bhr_menu_in_dynamic_web_acceleration(self):

        bhr_menu_link = self.get_bhr_link_element_from_parent_menu(
            parent_menu_name='Dynamic Web Acceleration')

        bhr_menu_link.click()

        self.assertTrue(
            self.driver.current_url.find(self.bhr_page_url) > -1)

        time.sleep(1)
