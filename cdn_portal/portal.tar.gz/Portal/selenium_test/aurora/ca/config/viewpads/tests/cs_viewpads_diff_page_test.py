import unittest

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver


class CAViewPADsDiffPageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_internal_user_when_display_viewpads_diff_page_then_should_be_shown(self):
        driver = self.driver
        ###########################################################################################################
        driver.find_elements(By.XPATH, "//span[text() = 'Content Acceleration']")[0].click()

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[text() = 'View PADs']"))
        )

        driver.find_elements(By.XPATH, "//a[text() = 'View PADs']")[0].click()

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "account_list_chosen"))
        )

        el1 = driver.find_element(By.ID, "account_list_chosen")
        el4 = el1.find_element(By.CSS_SELECTOR, ".chosen-single")
        el4.click()

        el4 = el1.find_element(By.CSS_SELECTOR, ".chosen-drop")
        el6 = el4.find_element(By.XPATH, ".//input[@type='text']")
        el6.clear()
        el6.send_keys('88 Brothers IT')
        el6.send_keys(Keys.RETURN)

        driver.switch_to.frame(driver.find_element(By.TAG_NAME, "iframe"))

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '//a[contains(text(), "download.ggnet.com")]'))
        )

        el = driver.find_element(By.XPATH, "//a[contains(@href, '/pads/compare/')]")
        el.click()

        Select(driver.find_element(By.NAME, "original")).select_by_visible_text("download.ggnet.com")
        Select(driver.find_element(By.NAME, "target")).select_by_visible_text("download.good-game-network.com")

        el = driver.find_element(By.XPATH, "//a[contains(text(), 'compare')]")
        el.click()

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".original.diff"))
        )

        el1 = driver.find_element(By.CSS_SELECTOR, ".original.diff")

        if el1.text.find('download.ggnet.com') >= 0:
            pass
        else:
            raise

        driver.switch_to.default_content()

        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
