import unittest2 as unittest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait

from selenium_test.config_user_constants import AURORA_CUSTOMER_USER
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from selenium.webdriver.support import expected_conditions as EC


class Test(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()

    def tearDown(self):
        self.driver.quit()

    def test_given_is_customer_user_when_show_traffic_of_ic_contract_then_should_shown_two_series(self):
        driver = self.driver
        AuroraLogin(driver).login_with(AURORA_CUSTOMER_USER['edge_hits_with_ic'])
        ###########################################################################################################
        driver.find_elements(By.XPATH, "//span[text() = 'Content Acceleration']")[0].click()

        WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, "//a[text() = 'Traffic']"))
        )

        driver.find_elements(By.XPATH, "//a[text() = 'Traffic']")[0].click()

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.ID, "btn_view"))
        )

        el4 = driver.find_element(By.CSS_SELECTOR, ".chosen-single")
        el4.click()

        el5 = driver.find_element(By.CSS_SELECTOR, ".chosen-search")
        el6 = el5.find_element(By.XPATH, ".//input[@type='text']")
        el6.clear()
        el6.send_keys('Namee')
        el6.send_keys(Keys.RETURN)

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, './/span[contains(text(), "selected")]'))
        )

        control_group_filter = driver.find_element_by_id('id_filter_cust')
        for option in control_group_filter.find_elements_by_tag_name('option'):
            if option.text == '0040011881-10':
                option.click()
                break

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//button[@class='ui-multiselect ui-widget ui-state-default ui-corner-all']//span[contains(text(), '40011881-10')]"))
        )

        el1 = driver.find_elements(By.XPATH, "//*[@data-value='specified']")
        el1[0].click()

        el = driver.find_element(By.ID, "id_date_from")
        el.clear()
        el.send_keys('2016-12-01')

        el = driver.find_element(By.ID, "id_date_to")
        el.clear()
        el.send_keys('2016-12-01')

        el = driver.find_element(By.ID, "btn_view")
        webdriver.ActionChains(driver).move_to_element(el).click(el).perform()

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//ul[@id='I_STAT_IC_HITS']"))
        )

        edge_hits_info = driver.find_elements(By.XPATH, "//ul[@id='I_STAT_IC_HITS']//li")
        self.assertEqual(2, len(edge_hits_info))
        edge_hits_info_label = driver.find_elements(By.XPATH, "//ul[@id='I_STAT_IC_HITS']//li//b")
        self.assertEqual('Converted Total:', edge_hits_info_label[0].text)
        self.assertEqual('Total:', edge_hits_info_label[1].text)
        self.assertEqual('Peak:', edge_hits_info_label[2].text)

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//div[@id='C_STAT_IC_HITS']"))
        )

        edge_hits_series = driver.find_elements(By.XPATH, "//div[@id='C_STAT_IC_HITS']//div[@class='highcharts-container']//*[name()='svg']//*[@class='highcharts-series']//*[name()='path']")
        self.assertEqual(2, len(edge_hits_series))

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//section[@id='container_STAT_IC_HITS']//header//p"))
        )

        edge_hits_desc = driver.find_element(By.XPATH, "//section[@id='container_STAT_IC_HITS']//header//p").text
        self.assertEqual(edge_hits_desc, 'CIC hits are the number of connections established in 5 minute segment from CDNetworks edge servers to CIC servers.')

if __name__ == '__main__':
    unittest.main()
