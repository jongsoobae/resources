import unittest2 as unittest
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait

from selenium_test.config_user_constants import AURORA_CUSTOMER_USER
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from selenium.webdriver.support import expected_conditions as EC


class CAICPageViewsByServiceTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()

    def tearDown(self):
        self.driver.quit()

    def test_given_is_customer_user_when_access_ic_page_views_by_service_page_then_title_and_column_has_CIC_string(self):
        driver = self.driver
        AuroraLogin(driver).login_with(AURORA_CUSTOMER_USER['edge_hits_with_ic'])
        ###########################################################################################################
        # Expand 'Content Acceleration' menu
        driver.find_element(By.XPATH,
                            "//menu[@id='menu1']//li//span[text() = 'Content Acceleration']").click()

        WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, "//a[contains(@href, '/cs/traffic/')]"))
        )

        # Go to Traffic Page
        driver.find_element(By.XPATH, "//a[contains(@href, '/cs/traffic/')]").click()

        # Wait until select element for selecting customer
        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.ID, "id_filter_account_chosen"))
        )

        customer_selector = driver.find_element(By.ID, "id_filter_account_chosen")
        customer_selector.click()

        # Find a customer has name is 'Namee'
        customer_search_input = driver.find_element(By.XPATH,
                                                    "//div[@id='id_filter_account_chosen']//div[@class='chosen-search']//input")
        customer_search_input.clear()
        customer_search_input.send_keys('Namee')
        customer_search_input.send_keys(Keys.RETURN)

        # Wait until select element for selecting contract
        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.ID, 'id_filter_cust'))
        )

        # Find a contract name is '0040011881-10' and select it
        control_group_filter = driver.find_element_by_id('id_filter_cust')
        for option in control_group_filter.find_elements_by_tag_name('option'):
            if option.text == '0040011881-10':
                option.click()
                break

        # Wait until select element for domain list is updated
        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//button[@class='ui-multiselect ui-widget ui-state-default ui-corner-all']//span[contains(text(), '40011881-10')]"))
        )

        # Select 'Custom Range'
        custom_range_button = driver.find_element(By.XPATH, "//button[@data-value='specified']")
        custom_range_button.click()

        # Set 'Date from'
        date_from_input = driver.find_element(By.ID, "id_date_from")
        date_from_input.clear()
        date_from_input.send_keys('2016-12-01')

        # Set 'Date to'
        date_to_input = driver.find_element(By.ID, "id_date_to")
        date_to_input.clear()
        date_to_input.send_keys('2016-12-01')

        # Click 'View' button to see reports
        view_button = driver.find_element(By.ID, "btn_view")
        view_button.click()

        # Wait 'Show Page Views by service' button until this button is displayed
        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//a[contains(@href, '/cs/byservice/STAT_IC_PAGE_VIEWS_BY_SERVICE/')]"))
        )

        # Go to IC Page Views by service
        driver.find_element(By.XPATH, "//a[contains(@href, '/cs/byservice/STAT_IC_PAGE_VIEWS_BY_SERVICE/')]").click()

        # Wait until a chart for 'IC Page Views by service' is displayed
        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.ID, "C_STAT_IC_PAGE_VIEWS_BY_SERVICE"))
        )

        # Wait until a table for 'IC Page Views by service' is displayed
        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.ID, "T_STAT_IC_PAGE_VIEWS_BY_SERVICE"))
        )

        # Get page title
        page_title = driver.find_element(By.XPATH, "//h1[@class='content-title']").text

        # Get page table header
        table_header_name = driver.find_element(By.XPATH, "//div[@id='T_STAT_IC_PAGE_VIEWS_BY_SERVICE']//div[@class='slick-header-columns']//div[@title='CIC Page Views']//span[@class='slick-column-name']").text

        self.assertEqual(page_title, 'CIC Page Views By Service')
        self.assertEqual(table_header_name, 'CIC Page Views')


if __name__ == '__main__':
    unittest.main()
