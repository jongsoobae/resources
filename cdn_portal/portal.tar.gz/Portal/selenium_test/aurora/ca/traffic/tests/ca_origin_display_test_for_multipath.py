import unittest2 as unittest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait

from selenium_test.config_user_constants import AURORA_CUSTOMER_USER
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from selenium.webdriver.support import expected_conditions as EC

FIXTURE_ORIGIN_DISPALY = {'container_STAT_ORIGIN_HITS':{'display':1, 'no-display':0},
                        'container_STAT_CACHE_HIT_RATIO':{'display':1, 'no-display':0},
                        'E_STAT_ORIGIN_RESPONSE_CODE':{'display':1, 'no-display':0}}

class Test(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()

        self.input_customer_data = {'tf_customer':'nhn Entertainment',
                        'tf_contract_group':'Download_KR (40010458-10)',
                        'tf_multipath':'winning.dn.toastoven.net',
                        'tf_no_multipath':'analytics.dn.toastoven.net',
                        'tf_search_keyword':'40010458-10',
                        'tf_date_from':'2016-12-01',
                        'tf_date_to':'2016-12-01'}

    def tearDown(self):
        self.driver.quit()

    def test_no_display_for_origin_chart_by_multipath(self):
        input_customer_data = self.input_customer_data
        driver = self.driver

        AuroraLogin(driver).login_with(AURORA_CUSTOMER_USER['edge_hits_with_ic'])
        ###########################################################################################################
        driver.find_elements(By.XPATH, "//span[text() = 'Content Acceleration']")[0].click()

        WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, "//a[text() = 'Traffic']"))
        )

        driver.find_elements(By.XPATH, "//a[text() = 'Traffic']")[0].click()

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.ID, "btn_view"))
        )

        el4 = driver.find_element(By.CSS_SELECTOR, ".chosen-single")
        el4.click()

        el5 = driver.find_element(By.CSS_SELECTOR, ".chosen-search")
        el6 = el5.find_element(By.XPATH, ".//input[@type='text']")
        el6.clear()
        el6.send_keys(input_customer_data['tf_customer'])
        el6.send_keys(Keys.RETURN)

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, './/span[contains(text(), "selected")]'))
        )

        control_group_filter = driver.find_element_by_id('id_filter_cust')
        for option in control_group_filter.find_elements_by_tag_name('option'):
            if option.text == input_customer_data['tf_contract_group']:
                option.click()
                break

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//button[@class='ui-multiselect ui-widget ui-state-default ui-corner-all']//span[contains(text(), '%s')]"%input_customer_data['tf_search_keyword']))
        )

        el13 = driver.find_elements(By.XPATH, "//button[@class='ui-multiselect ui-widget ui-state-default ui-corner-all']//span[contains(text(), '%s')]"%input_customer_data['tf_search_keyword'])
        el13[0].click()
        el11 = driver.find_element(By.CSS_SELECTOR, ".ui-multiselect-filter")
        el12 = el11.find_element(By.XPATH, ".//input[@type='search']")
        el12.clear()
        el12.send_keys(input_customer_data['tf_multipath'])
        el14 = driver.find_elements(By.XPATH, "//input[@title='%s']"%input_customer_data['tf_multipath'])
        el14[0].click()
        el15 = driver.find_element(By.CSS_SELECTOR, ".ui-multiselect-close")
        el15.click()

        el1 = driver.find_elements(By.XPATH, "//*[@data-value='specified']")
        el1[0].click()

        el = driver.find_element(By.ID, "id_date_from")
        el.clear()
        el.send_keys(input_customer_data['tf_date_from'])

        el = driver.find_element(By.ID, "id_date_to")
        el.clear()
        el.send_keys(input_customer_data['tf_date_to'])

        el = driver.find_element(By.ID, "btn_view")
        webdriver.ActionChains(driver).move_to_element(el).click(el).perform()

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.ID, "container_STAT_TOTAL_TRAFFIC"))
        )

        for pri_obj in FIXTURE_ORIGIN_DISPALY.iteritems():
            result = driver.find_elements(By.ID, pri_obj[0])
            self.assertEqual(len(result), pri_obj[1]['no-display'])

    def test_display_for_origin_chart_by_multipath(self):
        input_customer_data = self.input_customer_data
        driver = self.driver

        AuroraLogin(driver).login_with(AURORA_CUSTOMER_USER['edge_hits_with_ic'])
        ###########################################################################################################
        driver.find_elements(By.XPATH, "//span[text() = 'Content Acceleration']")[0].click()

        WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, "//a[text() = 'Traffic']"))
        )

        driver.find_elements(By.XPATH, "//a[text() = 'Traffic']")[0].click()

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.ID, "btn_view"))
        )

        el4 = driver.find_element(By.CSS_SELECTOR, ".chosen-single")
        el4.click()

        el5 = driver.find_element(By.CSS_SELECTOR, ".chosen-search")
        el6 = el5.find_element(By.XPATH, ".//input[@type='text']")
        el6.clear()
        el6.send_keys(input_customer_data['tf_customer'])
        el6.send_keys(Keys.RETURN)

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, './/span[contains(text(), "selected")]'))
        )

        control_group_filter = driver.find_element_by_id('id_filter_cust')
        for option in control_group_filter.find_elements_by_tag_name('option'):
            if option.text == input_customer_data['tf_contract_group']:
                option.click()
                break

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//button[@class='ui-multiselect ui-widget ui-state-default ui-corner-all']//span[contains(text(), '%s')]"%input_customer_data['tf_search_keyword']))
        )

        el13 = driver.find_elements(By.XPATH, "//button[@class='ui-multiselect ui-widget ui-state-default ui-corner-all']//span[contains(text(), '%s')]"%input_customer_data['tf_search_keyword'])
        el13[0].click()
        el11 = driver.find_element(By.CSS_SELECTOR, ".ui-multiselect-filter")
        el12 = el11.find_element(By.XPATH, ".//input[@type='search']")
        el12.clear()
        el12.send_keys(input_customer_data['tf_no_multipath'])
        el14 = driver.find_elements(By.XPATH, "//input[@title='%s']"%input_customer_data['tf_no_multipath'])
        el14[0].click()
        el15 = driver.find_element(By.CSS_SELECTOR, ".ui-multiselect-close")
        el15.click()

        el1 = driver.find_elements(By.XPATH, "//*[@data-value='specified']")
        el1[0].click()

        el = driver.find_element(By.ID, "id_date_from")
        el.clear()
        el.send_keys(input_customer_data['tf_date_from'])

        el = driver.find_element(By.ID, "id_date_to")
        el.clear()
        el.send_keys(input_customer_data['tf_date_to'])

        el = driver.find_element(By.ID, "btn_view")
        webdriver.ActionChains(driver).move_to_element(el).click(el).perform()

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.ID, "container_STAT_TOTAL_TRAFFIC"))
        )

        for pri_obj in FIXTURE_ORIGIN_DISPALY.iteritems():
            result = driver.find_elements(By.ID, pri_obj[0])
            self.assertEqual(len(result), pri_obj[1]['display'])

if __name__ == '__main__':
    unittest.main()
