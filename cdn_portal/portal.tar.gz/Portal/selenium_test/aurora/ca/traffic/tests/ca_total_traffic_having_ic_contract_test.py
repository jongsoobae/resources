import unittest2 as unittest
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait

from selenium_test.config_user_constants import AURORA_CUSTOMER_USER
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from selenium.webdriver.support import expected_conditions as EC


class CATotalTrafficHavingICContractTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()

    def tearDown(self):
        self.driver.quit()

    def test_given_is_customer_user_when_access_total_traffic_page_then_label_and_legend_has_CIC_string(self):
        driver = self.driver
        AuroraLogin(driver).login_with(AURORA_CUSTOMER_USER['edge_hits_with_ic'])
        ###########################################################################################################
        # Expand 'Content Acceleration' menu
        driver.find_element(By.XPATH,
                            "//menu[@id='menu1']//li//span[text() = 'Content Acceleration']").click()

        WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, "//a[contains(@href, '/cs/traffic/')]"))
        )

        # Go to Traffic Page
        driver.find_element(By.XPATH, "//a[contains(@href, '/cs/traffic/')]").click()

        # Wait until select element for selecting customer
        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.ID, "id_filter_account_chosen"))
        )

        customer_selector = driver.find_element(By.ID, "id_filter_account_chosen")
        customer_selector.click()

        # Find a customer has name is 'Namee'
        customer_search_input = driver.find_element(By.XPATH,
                                                    "//div[@id='id_filter_account_chosen']//div[@class='chosen-search']//input")
        customer_search_input.clear()
        customer_search_input.send_keys('Namee')
        customer_search_input.send_keys(Keys.RETURN)

        # Wait until select element for selecting contract
        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.ID, 'id_filter_cust'))
        )

        # Find a contract name is '0040011881-10' and select it
        control_group_filter = driver.find_element_by_id('id_filter_cust')
        for option in control_group_filter.find_elements_by_tag_name('option'):
            if option.text == '0040011881-10':
                option.click()
                break

        # Wait until select element for domain list is updated
        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//button[@class='ui-multiselect ui-widget ui-state-default ui-corner-all']//span[contains(text(), '40011881-10')]"))
        )

        # Select 'Custom Range'
        custom_range_button = driver.find_element(By.XPATH, "//button[@data-value='specified']")
        custom_range_button.click()

        # Set 'Date from'
        date_from_input = driver.find_element(By.ID, "id_date_from")
        date_from_input.clear()
        date_from_input.send_keys('2016-12-01')

        # Set 'Date to'
        date_to_input = driver.find_element(By.ID, "id_date_to")
        date_to_input.clear()
        date_to_input.send_keys('2016-12-01')

        # Click 'View' button to see reports
        view_button = driver.find_element(By.ID, "btn_view")
        view_button.click()

        # Wait until a chart for 'Total Traffic' is displayed
        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.ID, "C_STAT_TOTAL_TRAFFIC"))
        )

        # Wait until a information panel for 'Total Traffic' is displayed
        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.ID, "I_STAT_TOTAL_TRAFFIC"))
        )

        # Get every labels in the information panel for 'Total Traffic'
        label_list = [label.text for label in driver.find_elements(By.XPATH, "//ul[@id='I_STAT_TOTAL_TRAFFIC']//li//strong")]

        # Check those values are in label_list
        self.assertIn('CIC -', label_list)
        self.assertIn('CIC Origin -', label_list)

        # Get every labels on the legend of 'Total Traffic' chart
        label_list_on_legend = [label.text for label in driver.find_elements(By.XPATH, "//div[@id='C_STAT_TOTAL_TRAFFIC']//*[name()='g' and @class='highcharts-legend']//*[name()='text']")]

        # Check those values are in label_list_on_legend
        self.assertIn('CIC', label_list_on_legend)
        self.assertIn('CIC Origin', label_list_on_legend)


if __name__ == '__main__':
    unittest.main()
