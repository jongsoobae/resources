import unittest

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from time import sleep


class CATrafficPageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_internal_user_when_display_ca_traffic_page_then_total_traffic_report_should_be_shown(self):
        driver = self.driver
        ###########################################################################################################
        driver.find_elements(By.XPATH, "//span[text() = 'Content Acceleration']")[0].click()

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[text() = 'Traffic']"))
        )

        driver.find_elements(By.XPATH, "//a[text() = 'Traffic']")[0].click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, "btn_view"))
        )

        el4 = driver.find_element(By.CSS_SELECTOR, ".chosen-single")
        el4.click()

        el5 = driver.find_element(By.CSS_SELECTOR, ".chosen-search")
        el6 = el5.find_element(By.XPATH, ".//input[@type='text']")
        el6.clear()
        el6.send_keys('Atanar Technologies')
        el6.send_keys(Keys.RETURN)

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, './/span[contains(text(), "selected")]'))
        )

        el1 = driver.find_elements(By.XPATH, "//*[@data-value='specified']")
        el1[0].click()

        el = driver.find_element(By.ID, "id_date_from")
        el.clear()
        el.send_keys('2015-01-29')

        el = driver.find_element(By.ID, "id_date_to")
        el.clear()
        el.send_keys('2015-01-29')

        el = driver.find_element(By.ID, "btn_view")
        webdriver.ActionChains(driver).move_to_element(el).click(el).perform()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, './/b[contains(text(), "Total Transferred")]'))
        )
        #AURORAUI-1576 Check============================================================================================
        export_btn = driver.find_element(By.ID, "btn_filter_export")
        export_btn.click()
        
        test_date = "2015-01-29"
        el = driver.find_element(By.ID, "id_date_from")
        el.clear()
        el.send_keys(test_date)

        el = driver.find_element(By.ID, "id_date_to")
        el.clear()
        el.send_keys(test_date)
        sleep(1)
        WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.ID, "id_stat_item"))
        )
        stat_item = driver.find_element(By.ID, "id_stat_item")
        stat_item.click()
        WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//option[text() = 'Total Traffic']"))
        )
        first_item = driver.find_element(By.XPATH, "//option[text() = 'Total Traffic']")
        first_item.click()
        export = driver.find_element(By.ID, "btn_export")
        export.click()
        date_element = driver.find_element(By.ID, "id_date_from")
        after_date = date_element.get_attribute("value")
        self.assertEqual(test_date, after_date, "[AURORAUI-1576] Test error")
        #=================================================================================================================================

        
        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
