import unittest2 as unittest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait

from selenium_test.config_user_constants import AURORA_CUSTOMER_USER
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from selenium.webdriver.support import expected_conditions as EC
import time


class Test(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()

        self.input_customer_data = {'tf_customer':'canalchat',
            'tf_date_from':'2016-12-01',
            'tf_date_to':'2016-12-01'}

    def tearDown(self):
        self.driver.quit()

    def test_no_display_for_origin_chart_by_multipath(self):
        input_customer_data = self.input_customer_data
        driver = self.driver

        AuroraLogin(driver).login_with(AURORA_CUSTOMER_USER['default'])
        ###########################################################################################################
        driver.find_elements(By.XPATH, "//span[text() = 'Media Acceleration']")[0].click()
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//span[text() = 'Media Acceleration']/following-sibling::menu//li//a[text() = 'Traffic']"))
        )

        driver.find_element(By.XPATH, "//span[text() = 'Media Acceleration']/following-sibling::menu//li//a[text() = 'Traffic']").click()


        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.ID, "btn_view"))
        )

        el4 = driver.find_element(By.CSS_SELECTOR, ".chosen-single")
        el4.click()

        el5 = driver.find_element(By.CSS_SELECTOR, ".chosen-search")
        el6 = el5.find_element(By.XPATH, ".//input[@type='text']")
        el6.clear()
        el6.send_keys(input_customer_data['tf_customer'])
        el6.send_keys(Keys.RETURN)

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, './/span[contains(text(), "selected")]'))
        )

        el1 = driver.find_elements(By.XPATH, "//*[@data-value='specified']")
        el1[0].click()

        el = driver.find_element(By.ID, "id_date_from")
        el.clear()
        el.send_keys(input_customer_data['tf_date_from'])

        el = driver.find_element(By.ID, "id_date_to")
        el.clear()
        el.send_keys(input_customer_data['tf_date_to'])

        el = driver.find_element(By.ID, "btn_view")
        webdriver.ActionChains(driver).move_to_element(el).click(el).perform()

        details_btn = driver.find_element(By.ID, "edge_response_export")
        details_btn.click()

        element = driver.find_element_by_id("detail_msg")
        msg = "When the 'today' included in data range for searching, the result could be little different because of real time data processing."
        detail_msg = element.get_attribute('innerHTML').strip()

        self.assertEqual(msg, detail_msg)

if __name__ == '__main__':
    unittest.main()
