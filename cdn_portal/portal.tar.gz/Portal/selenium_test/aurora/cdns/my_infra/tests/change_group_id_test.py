import os, sys

os.environ['DJANGO_SETTINGS_MODULE'] = 'aurora_fe.settings'

import unittest
import time
from datetime import datetime
from selenium_test.shared_components.decorators import catch_exception

from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from selenium_test.shared_components.conf import settings
from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys

from selenium_test.shared_components.spectrum_api_manager import SpectrumAPIManager

class MyInfraTest(unittest.TestCase):

    TEST_RANGE = range(0, 2)

    SERVER_GROUP_NAME = 'momo_%d'
    SERVER_NAME = 'server_momo_%d'

    VALID_VALUE = 'Modified\n(but in production)'
    # VALID_VALUE = 'New'

    WAIT_TIME = 60

    def setUp(self):
        self.driver = get_web_driver()
        self.spectrum_api = SpectrumAPIManager()

        driver = self.driver

        AuroraLogin(driver).login_with(AURORA_INTERNAL_USER)

        WebDriverWait(driver, self.WAIT_TIME).until(
            EC.visibility_of_element_located((By.ID, 'content-right'))
        )

        # Going to the My Infra in Cloud DNS.
        driver.get(settings.AURORA_FE_URL + '/dns/myinfra/server_group_list/?m=272#/server_group/list/')

        for idx in self.TEST_RANGE:
            # Waitting to load 'My Infra' page.
            WebDriverWait(driver, self.WAIT_TIME).until(
                EC.presence_of_element_located((By.XPATH, "//a[text() = 'Location1']"))
            )

            # Clicking 'Add New Server Gorup' button.
            driver.find_element(By.XPATH, "//a[text() = 'Add New Server Group']").click()

            WebDriverWait(driver, self.WAIT_TIME).until(
                EC.presence_of_element_located((By.XPATH, "//input[@value = 'Next']"))
            )

            # Filling 'Server Group Name'.
            text_server_group_name = driver.find_element(By.XPATH, "//input[@ng-model = 'object.group_name']")
            text_server_group_name.send_keys((self.SERVER_GROUP_NAME % idx))
            # text_server_group.name.send(Keys.Return)

            # Selecting 'Server Group Location'
            # value = 0 is 'korea, Republic of - SKB'
            driver.find_element(By.XPATH, "//select[@ng-model = 'object.region']/option[@value = 0]").click()

            # Clicking 'Next' button.
            driver.find_element(By.XPATH, "//input[@value = 'Next']").click()

            # Waitting for to load 'Server list'.
            WebDriverWait(driver, self.WAIT_TIME).until(
                EC.presence_of_element_located((By.XPATH, "//span[text() = 'Add Server']"))
            )

            # Clicking 'Add Server' link.
            driver.find_element(By.XPATH, "//span[text() = 'Add Server']").click()

            # Waitting for to load 'Insert Server' Dialog.
            WebDriverWait(driver, self.WAIT_TIME).until(
                EC.presence_of_element_located((By.XPATH, "//span[text() = 'Insert Server']"))
            )

            # Filling 'Server Name'.
            text_server_name = driver.find_element(By.XPATH, "//input[@ng-model = 'adding_server.server_name']")
            text_server_name.send_keys((self.SERVER_NAME % idx))

            # Filling 'Vip Address'.
            text_vip_address = driver.find_element(By.XPATH, "//input[@ng-model = 'adding_server.ip']")
            text_vip_address.send_keys(('11.11.12.1%d' % idx))

            # Clicking 'Save' button.
            driver.find_element(By.XPATH, "//a[text() = 'Save']").click()

            # Waitting for to load 'Server list'.
            WebDriverWait(driver, self.WAIT_TIME).until(
                EC.presence_of_element_located((By.XPATH, "//span[text() = 'Add Server']"))
            )

            time.sleep(2)

            # Clicking 'Existing Server Groups' button.
            driver.find_element(By.XPATH, "//a[text() = 'Existing Server Groups']").click()

        # To change status of server groups from 'New' to 'production'.
        self.change_status_of_pop()

    def tearDown(self):
        driver = self.driver

        # Setting time_deployed of server group 'None'
        self.change_status_of_pop(1)

        for idx in self.TEST_RANGE:
            # Waitting for to load last list of server group list.
            xpath_server_group_name = "//a[text() = '%s']" % (self.SERVER_GROUP_NAME % idx)

            WebDriverWait(driver, self.WAIT_TIME).until(
                EC.presence_of_element_located((By.XPATH, xpath_server_group_name))
            )

            # Clicking the momo_x server group.
            driver.find_element(By.XPATH, xpath_server_group_name).click()

            # Waitting for to load 'Server list'.
            WebDriverWait(driver, self.WAIT_TIME).until(
                EC.presence_of_element_located((By.XPATH, "//span[text() = 'Add Server']"))
            )

            # Because the first server group has not server list, you don't need to the following code.
            if(0 < idx):
                for idx in self.TEST_RANGE:
                    # Clicking the 'Delete' link.
                    driver.find_element(By.XPATH, "//a[text() = 'Delete']").click()

                    # Waitting for to load 'Delete Server' Dialog.
                    WebDriverWait(driver, self.WAIT_TIME).until(
                        EC.presence_of_element_located((By.XPATH, "//span[text() = 'Delete Server']"))
                    )

                    # Clicking the 'Yes' button.
                    driver.find_element(By.XPATH, "//button[@ng-click='do_server_delete()']").click()

                    # Waitting for to load 'Server list'.
                    WebDriverWait(driver, self.WAIT_TIME).until(
                        EC.presence_of_element_located((By.XPATH, "//span[text() = 'Add Server']"))
                    )

                    time.sleep(2)

                # To refresh current page which is 'Manage My Infra' to show 'Delete Server Group' link.
                driver.refresh()

            xpath_delete_server_group_link = "//span[text() = 'Delete Server Group']"

            # Waitting for to load 'Manage Server Group'.
            WebDriverWait(driver, self.WAIT_TIME).until(
                EC.presence_of_element_located((By.XPATH, xpath_delete_server_group_link))
            )

            # Clicking the 'Delete Server Group' link.
            driver.find_element(By.XPATH, xpath_delete_server_group_link).click()

            # Waitting for to load the 'Delete' dialog.
            WebDriverWait(driver, self.WAIT_TIME).until(
                EC.presence_of_element_located((By.XPATH, "//span[text() = 'Delete']"))
            )

            # Clicking the 'Yes' button.
            driver.find_element(By.XPATH, "//button[@ng-click='do_servergroup_delete()']").click()

            self.move_last_server_group_list()

        driver.close()

    def test_deploy_status(self):
        driver = self.driver

        self.move_last_server_group_list()

        # Waitting for to load last list of server group list.
        xpath_server_group_name = "//a[text() = '%s']" % (self.SERVER_GROUP_NAME % 0)

        WebDriverWait(driver, self.WAIT_TIME).until(
            EC.presence_of_element_located((By.XPATH, xpath_server_group_name))
        )

        # Clicking server group which name is 'momo_0'.
        driver.find_element(By.XPATH, xpath_server_group_name).click()

        # Waitting for to load 'Server list'.
        WebDriverWait(driver, self.WAIT_TIME).until(
            EC.presence_of_element_located((By.XPATH, "//span[text() = 'Add Server']"))
        )

        # Clicking 'Edit' link
        edit_link = driver.find_element(By.XPATH, '//*[@id="accordion"]/div/div/div/div[1]/div/a[1]').click()

        # Waitting for to load 'Server Group' selector.
        WebDriverWait(driver, self.WAIT_TIME).until(
            EC.presence_of_element_located((By.ID, "my_infra_server_list_server_group_selector"))
        )

        # To change the server group which name is 'momo_1'
        driver.find_element(
                By.XPATH,
                ("//select[@id='my_infra_server_list_server_group_selector']/option[text() = '%s']" % (self.SERVER_GROUP_NAME % 1))).click()

        # Clicking 'Save' link.
        driver.find_element(By.XPATH, "//a[text() = 'Save']").click()

        # Clicking 'Existing Server Groups' link.
        driver.find_element(By.XPATH, "//a[text() = 'Existing Server Groups']").click()

        self.move_last_server_group_list()

        for idx in self.TEST_RANGE:
            self.validate_deploy_status((self.SERVER_GROUP_NAME % idx))

    def move_last_server_group_list(self):
        driver = self.driver

        # Waitting to load 'My Infra' page.
        WebDriverWait(driver, self.WAIT_TIME).until(
            EC.presence_of_element_located((By.XPATH, "//a[text() = 'Location1']"))
        )

        # Waitting for to load the server grouplist.
        WebDriverWait(driver, self.WAIT_TIME).until(
            EC.presence_of_element_located((By.ID, "clb_pagination_container"))
        )

        button_pages = driver.find_elements(By.XPATH, "//*[@id='clb_pagination_container']/ul/li")

        # Clicking '>>' link to move last list of server group list.
        driver.find_element(By.XPATH, ("//*[@id='clb_pagination_container']/ul/li[%d]/a" % len(button_pages))).click()

    def validate_deploy_status(self, server_group_name):
        driver = self.driver

        # Waitting to load 'My Infra' page and getting server group created previously.
        td_title = WebDriverWait(driver, self.WAIT_TIME).until(
            EC.presence_of_element_located((By.XPATH, ("//td[@title = '%s']" % server_group_name)))
        )

        # Finding parent tr element to find 'Deploy Status' td element.
        parent_tr = td_title.find_element(By.XPATH, '..')

        # Getting td elements to find 'Deploy Status' td element.
        td_list = parent_tr.find_elements(By.XPATH, 'td')

        # Getting 'Deploy Status' td element.
        deploy_status_td = td_list[len(td_list) - 1]

        # Validating value of 'Deploy Status'.
        self.assertEqual(deploy_status_td.text, self.VALID_VALUE)

    def change_status_of_pop(self, behavior=0):
        pop_names = []
        for idx in self.TEST_RANGE:
            pop_names.append(self.SERVER_GROUP_NAME % idx)

        post_data = {
            'behavior': behavior,
            'pop_names': pop_names
        }

        response = self.spectrum_api.request(
            'myinfra/mockup_server_group/', method='put', post_data=post_data)

if __name__ == '__main__':
    unittest.main()
