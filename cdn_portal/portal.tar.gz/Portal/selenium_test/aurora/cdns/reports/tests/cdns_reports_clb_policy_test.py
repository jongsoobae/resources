import unittest

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver


class CDNSReportsCLBPolicyTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='hyejun.yim')
    def test_given_user_is_internal_user_when_display_cdns_reports_clb_policy_then_should_be_shown(self):
        driver = self.driver
        ###########################################################################################################
        driver.find_elements(By.XPATH, "//span[text() = 'Cloud DNS']")[0].click()

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '/int/dns/reports/')]"))
        )

        driver.find_element(By.XPATH, "//a[contains(@href, '/int/dns/reports/')]").click()

        el = driver.find_element(By.CSS_SELECTOR, ".chosen-single")
        el.click()

        el2 = driver.find_element(By.CSS_SELECTOR, ".chosen-search")
        el3 = el2.find_element(By.XPATH, ".//input[@type='text']")
        el3.clear()
        el3.send_keys('CDNetworks Product Management')
        el3.send_keys(Keys.RETURN)

        driver.switch_to.frame(driver.find_element(By.TAG_NAME, "iframe"))

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[contains(text(), 'By CLB Domains')]"))
        )

        driver.find_element(By.XPATH, "//a[contains(text(), 'By CLB Domains')]").click()

        # Day TEST
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "btn_filter_charts"))
        )

        driver.find_element(By.ID, "btn_filter_charts").click()

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "btn_view"))
        )

        el4 = driver.find_element(By.ID, "id_customer_stat_unit")
        el4.send_keys('davidkimtest.com')

        driver.find_element(By.XPATH, "//a[contains(text(), 'Day')]").click()

        el5 = driver.find_element(By.ID, "btn_view")
        webdriver.ActionChains(driver).move_to_element(el5).click(el5).perform()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, './/div[contains(text(), "Requests")]'))
        )

        # driver.find_element(By.XPATH, "//a[contains(text(), 'abc.davidkimtest.com')]").click()
        #
        # WebDriverWait(driver, 120).until(
        #     EC.presence_of_element_located((By.XPATH, '//th[contains(text(), "Policy Name")]'))
        # )
        #
        # driver.find_element_by_css_selector("#clb_policy_filter > span.close").click()
        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
