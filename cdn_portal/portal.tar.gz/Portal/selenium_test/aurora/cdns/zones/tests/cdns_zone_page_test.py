import unittest

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver


class CDNSZonePageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_internal_user_when_display_cdns_zone_page_then_should_be_shown(self):
        driver = self.driver
        ###########################################################################################################
        driver.find_elements(By.XPATH, "//span[text() = 'Cloud DNS']")[0].click()

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[text() = 'Zones']"))
        )

        driver.find_elements(By.XPATH, "//a[text() = 'Zones']")[0].click()

        el = driver.find_element(By.ID, "txt_search")
        el.clear()
        el.send_keys("david")
        el.send_keys(Keys.RETURN)

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '/dns/zone/')][contains(text(), 'clb.davidkimtest.com')]"))
        )

        el = driver.find_elements(By.XPATH, "//a[contains(@href, '/dns/zone/')][contains(text(), 'clb.davidkimtest.com')]")
        el[0].click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, './/label[contains(text(), "Zone Name:")]'))
        )

        zone_name = driver.find_elements(By.XPATH, './/span[contains(text(), "clb.davidkimtest.com")]')[0].text

        self.assertEqual(zone_name, 'clb.davidkimtest.com')
        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
