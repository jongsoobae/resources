import unittest
import time
import re
from selenium_test.config_constants import AURORA_FE_URL
from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from selenium import webdriver

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium_test.aurora_api import APIManager, reset_zone_deploy_status, reset_user_push_threshold

class CDNSZonePushTest(unittest.TestCase):
    def setUp(self):
        self.username = AURORA_INTERNAL_USER.get('username')
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)
        reset_user_push_threshold(self.username)

    def tearDown(self):
        self.driver.close()

    def push_dns_zone(self, zone_id):
        driver = self.driver
        reset_zone_deploy_status(zone_id)
        driver.get("%s/dns/zone/%s/" % (AURORA_FE_URL,zone_id))
        time.sleep(5)
        #WebDriverWait(driver, 20).until(
        #    EC.presence_of_element_located((By.ID, 'btn_complete2'))
        #)
        driver.find_element(By.XPATH, "//input[@value='Push to Staging']").click()
        time.sleep(3)

        el9 = driver.find_element(By.ID, "btn_confirm")
        el9.click()
        #aa = driver.execute_script("arguments[0].click()", el9)
        time.sleep(5)

        return driver.page_source

    @catch_exception(author='injune.hwang')
    def test_cdns_zone_push(self):
        driver = self.driver
        driver.maximize_window()
        zone_id = 11210
        driver.get("%s/dns/zones_list/?m=268" % (AURORA_FE_URL))

        page_source = self.push_dns_zone(zone_id)
        page_source = self.push_dns_zone(zone_id)

        text_found = re.search(r'You have reached push rate limitation', page_source)
        self.assertNotEqual(text_found, None)


if __name__ == '__main__':
    unittest.main()
