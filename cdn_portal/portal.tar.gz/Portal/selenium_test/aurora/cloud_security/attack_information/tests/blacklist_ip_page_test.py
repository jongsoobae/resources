import unittest

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait

from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By


class BlacklistIPPageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='mi.jun')
    def test_given_user_is_internal_user_when_display_blacklist_ip_page_then_blacklist_ip_should_be_shown(self):
        driver = self.driver
        ###########################################################################################################
        driver.find_elements(By.XPATH, "//span[text() = 'Cloud Security']")[0].click()

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//span[text() = 'Cloud Security']/following-sibling::menu//a[text() = 'Blacklist IP']"))
        )
        
        driver.find_element(By.XPATH, "//span[text() = 'Cloud Security']/following-sibling::menu//a[text() = 'Blacklist IP']").click()
        
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//span[text() = 'Customer']"))
        )
        
        el = driver.find_element(By.ID, "account_list_chosen")
        el4 = el.find_element(By.CSS_SELECTOR, ".chosen-single")
        el4.click()
        el6 = el.find_element(By.XPATH, ".//input[@type='text']")
        el6.clear()
        el6.send_keys('Delta Productions Limited (Micro Gaming)')
        el6.send_keys(Keys.RETURN)

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//span[text() = 'Blacklisted IP Address']"))
        )
        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
