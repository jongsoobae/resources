import os
import unittest

if os.environ.get('DJANGO_SETTINGS_MODULE') is None:
    os.environ['DJANGO_SETTINGS_MODULE'] = 'aurora_fe.settings'

from aurora_fe.shared_components.models.acl_core import AuthUserHasPrivilege
from aurora_fe.shared_components.models.acl_core import Privilege
from aurora_fe.shared_components.models.acl_core import CustomerAccountHasPrivilege
from aurora_fe.shared_components.models.acl_core import CustomerAccountWrapper

from selenium_test.shared_components.decorators import catch_exception

from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.config_user_constants import AURORA_CUSTOMER_USER
from selenium.webdriver.common.by import By

from django.contrib.auth.models import User

class DocumentationPageTest(unittest.TestCase):

    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.quit()

    @catch_exception(author='dasol.kim')
    def test_is_documentation(self):
        driver = self.driver
        driver.find_elements(By.XPATH, "//span[text() = 'Cloud Security']")[0].click()
        driver.find_element_by_xpath("(//a[contains(text(),'Documentation')])[3]").click()
        driver.switch_to_frame(driver.find_element_by_tag_name("iframe"))
        driver.find_element_by_link_text("WAF User Guide").click()

class DocumentationMenuPrivilegeTest(unittest.TestCase):

    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_CUSTOMER_USER['cloud_security_documentation'])

    def tearDown(self):
        self.driver.quit()

    @catch_exception(author='dasol.kim')
    def test_is_documentation(self):
        driver = self.driver
        auth_user_id = User.objects.get(username=AURORA_CUSTOMER_USER['cloud_security_documentation']['username'])
        account_no = CustomerAccountWrapper.objects.get(account_name_eng='giordano')
        privilege_id_of_csc_documentation = Privilege.objects.get(privilege_key='CSC_DOCUMENTATION')
        privilege_id_of_csc = Privilege.objects.get(privilege_key='CSC')

        # add MenuPrivilege of cloud_security
        try:
            AuthUserHasPrivilege.objects.create(auth_user_id=auth_user_id, account_no=account_no,
                                                                privilege_id=privilege_id_of_csc)
        except Exception as e:
            pass
        try:
            CustomerAccountHasPrivilege.objects.create(account_no=account_no,
                                                       privilege_id=privilege_id_of_csc)
        except Exception as e:
            pass

        # add MenuPrivilege of cloud_security_documentation
        try:
            AuthUserHasPrivilege.objects.create(auth_user_id=auth_user_id, account_no=account_no,
                                                                privilege_id=privilege_id_of_csc_documentation)
        except Exception as e:
            pass
        try:
            CustomerAccountHasPrivilege.objects.create(account_no=account_no,
                                                       privilege_id=privilege_id_of_csc_documentation)
        except Exception as e:
            pass

        driver.find_element_by_css_selector("img").click()
        driver.find_elements(By.XPATH, "//span[text() = 'Cloud Security']")[0].click()
        driver.find_element_by_link_text("Documentation").click()

        # delete MenuPrivilege of cloud_security
        AuthUserHasPrivilege.objects.filter(auth_user_id=auth_user_id, account_no=account_no,
                                            privilege_id=privilege_id_of_csc).delete()

        CustomerAccountHasPrivilege.objects.filter(account_no=account_no,
                                                   privilege_id=privilege_id_of_csc).delete()

        # delete MenuPrivilege of cloud_security_documentation
        AuthUserHasPrivilege.objects.filter(auth_user_id=auth_user_id, account_no=account_no,
                                            privilege_id=privilege_id_of_csc_documentation).delete()

        CustomerAccountHasPrivilege.objects.filter(account_no=account_no,
                                                   privilege_id=privilege_id_of_csc_documentation).delete()

if __name__ == '__main__':
    unittest.main()