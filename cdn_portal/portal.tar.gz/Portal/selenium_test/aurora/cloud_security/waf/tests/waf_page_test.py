import unittest
import time

from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.select import Select
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.utils import get_web_driver
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.config_user_constants import AURORA_INTERNAL_USER

class WafPageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.quit()

    @catch_exception(author='sichoon.kwon')
    def test_waf_page_open_shown(self):
        driver = self.driver

        driver.find_elements(By.XPATH, "//span[text() = 'Cloud Security']")[0].click()

        driver.find_element(By.XPATH, "//span[text() = 'Cloud Security']/following-sibling::menu//a[text() = 'WAF']").click()

        Select(driver.find_element(By.ID,"account_list")).select_by_value("32red")
        driver.find_element(By.XPATH, "//button[@ng-click=\"onWafHandler()\"]").click()

        time.sleep(3)

        WebDriverWait(driver, 60).until(
            EC.presence_of_element_located((By.CLASS_NAME, "logo"))
        )

if __name__ == '__main__':
    unittest.main()
