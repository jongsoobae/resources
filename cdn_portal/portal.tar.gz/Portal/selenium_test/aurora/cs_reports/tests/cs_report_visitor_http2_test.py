# [AURORAUI-3185]
import unittest
import time

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from selenium_test.config_constants import AURORA_FE_URL

##############################################################
# Customer : Dora Telekomunikasyon Hizmetleri AS
# - customer_id = 4354, account_no = 20034
# Content Acceleration
# - control_group_id = 1086
CUSTOMER_NAME = 'Dora Telekomunikasyon Hizmetleri AS'
DATE_FROM = '2016-12-05'
DATE_TO = '2016-12-06'
##############################################################

class TestCSReportVisitorHTTP2(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='hyejun.yim')
    def test_ca_visitor_http_version(self):
        driver = self.driver
        # Go to content page
        driver.get('%s/cs/visitor/?m=203' % AURORA_FE_URL)
        time.sleep(1)

        el1 = driver.find_element(By.CSS_SELECTOR, ".chosen-single")
        el1.click()
        el2 = driver.find_element(By.CSS_SELECTOR, ".chosen-search")
        txt_customer = el2.find_element(By.XPATH, "//input[@type='text']")
        txt_customer.clear()
        txt_customer.send_keys(CUSTOMER_NAME)
        txt_customer.send_keys(Keys.RETURN)

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, './/span[contains(text(), "selected")]'))
        )

        driver.find_element(By.XPATH, "//button[@data-value='specified']").click()

        txt_date_from = driver.find_element(By.ID, 'id_date_from')
        txt_date_from.clear()
        txt_date_from.send_keys(DATE_FROM)
        txt_date_to = driver.find_element(By.ID, 'id_date_to')
        txt_date_to.clear()
        txt_date_to.send_keys(DATE_TO)

        driver.find_element(By.ID, 'btn_view').click()
        time.sleep(2)

        # HTTP version
        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//div[@id='L_STAT_HTTP_VERSION']//div//img[@src='/op_media/cdnetworks_standalone/en-us/core/images/indicator/loader-3.gif']"))
        )
        WebDriverWait(driver, 120).until(
            EC.invisibility_of_element_located((By.XPATH, "//div[@id='L_STAT_HTTP_VERSION']//div//img[@src='/op_media/cdnetworks_standalone/en-us/core/images/indicator/loader-3.gif']"))
        )
        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.ID, "T_STAT_HTTP_VERSION"))
        )
        if driver.find_element(By.XPATH, "//div[@id='E_STAT_HTTP_VERSION']//div").text == 'No Data.':
            pass
        else:
            WebDriverWait(driver, 30).until(
                EC.presence_of_element_located((By.XPATH, './/div[@id="T_STAT_HTTP_VERSION"]//table//td[contains(text(), "Total")]'))
            )
            
    @catch_exception(author='hyejun.yim')
    def test_dwa_visitor_http_version(self):
        driver = self.driver
        # Go to content page
        driver.get('%s/cs/visitor/?m=218' % AURORA_FE_URL)
        time.sleep(1)

        driver.find_element(By.XPATH, "//button[@data-value='specified']").click()

        txt_date_from = driver.find_element(By.ID, 'id_date_from')
        txt_date_from.clear()
        txt_date_from.send_keys(DATE_FROM)
        txt_date_to = driver.find_element(By.ID, 'id_date_to')
        txt_date_to.clear()
        txt_date_to.send_keys(DATE_TO)

        driver.find_element(By.ID, 'btn_view').click()
        time.sleep(2)

        # HTTP version
        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.ID, "E_STAT_HTTP_VERSION"))
        )
        if driver.find_element(By.XPATH, "//div[@id='E_STAT_HTTP_VERSION']//div").text == 'No Data.':
            pass
        else:
            WebDriverWait(driver, 30).until(
                EC.presence_of_element_located((By.XPATH, './/div[@id="T_STAT_HTTP_VERSION"]//table//td[contains(text(), "Total")]'))
            )

    @catch_exception(author='hyejun.yim')
    def test_ma_visitor_http_version(self):
        driver = self.driver
        # Go to content page
        driver.get('%s/cs/visitor/?m=236' % AURORA_FE_URL)
        time.sleep(1)

        driver.find_element(By.XPATH, "//button[@data-value='specified']").click()

        txt_date_from = driver.find_element(By.ID, 'id_date_from')
        txt_date_from.clear()
        txt_date_from.send_keys(DATE_FROM)
        txt_date_to = driver.find_element(By.ID, 'id_date_to')
        txt_date_to.clear()
        txt_date_to.send_keys(DATE_TO)

        driver.find_element(By.ID, 'btn_view').click()
        time.sleep(2)

        # HTTP version
        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.ID, "E_STAT_HTTP_VERSION"))
        )
        if driver.find_element(By.XPATH, "//div[@id='E_STAT_HTTP_VERSION']//div").text == 'No Data.':
            pass
        else:
            WebDriverWait(driver, 30).until(
                EC.presence_of_element_located((By.XPATH, './/div[@id="T_STAT_HTTP_VERSION"]//table//td[contains(text(), "Total")]'))
            )

    @catch_exception(author='hyejun.yim')
    def test_ma_http_visitor_http_version(self):
        driver = self.driver
        # Go to content page
        driver.get('%s/cs/visitor/?m=251' % AURORA_FE_URL)
        time.sleep(1)

        driver.find_element(By.XPATH, "//button[@data-value='specified']").click()

        txt_date_from = driver.find_element(By.ID, 'id_date_from')
        txt_date_from.clear()
        txt_date_from.send_keys(DATE_FROM)
        txt_date_to = driver.find_element(By.ID, 'id_date_to')
        txt_date_to.clear()
        txt_date_to.send_keys(DATE_TO)

        driver.find_element(By.ID, 'btn_view').click()
        time.sleep(2)

        # HTTP version
        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.ID, "E_STAT_HTTP_VERSION"))
        )
        if driver.find_element(By.XPATH, "//div[@id='E_STAT_HTTP_VERSION']//div").text == 'No Data.':
            pass
        else:
            WebDriverWait(driver, 30).until(
                EC.presence_of_element_located((By.XPATH, './/div[@id="T_STAT_HTTP_VERSION"]//table//td[contains(text(), "Total")]'))
            )

    @catch_exception(author='hyejun.yim')
    def test_ma_mobile_visitor_http_version(self):
        driver = self.driver
        # Go to content page
        driver.get('%s/cs/visitor/?m=266' % AURORA_FE_URL)
        time.sleep(1)

        driver.find_element(By.XPATH, "//button[@data-value='specified']").click()

        txt_date_from = driver.find_element(By.ID, 'id_date_from')
        txt_date_from.clear()
        txt_date_from.send_keys(DATE_FROM)
        txt_date_to = driver.find_element(By.ID, 'id_date_to')
        txt_date_to.clear()
        txt_date_to.send_keys(DATE_TO)

        driver.find_element(By.ID, 'btn_view').click()
        time.sleep(2)

        # HTTP version
        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.ID, "E_STAT_HTTP_VERSION"))
        )
        if driver.find_element(By.XPATH, "//div[@id='E_STAT_HTTP_VERSION']//div").text == 'No Data.':
            pass
        else:
            WebDriverWait(driver, 30).until(
                EC.presence_of_element_located((By.XPATH, './/div[@id="T_STAT_HTTP_VERSION"]//table//td[contains(text(), "Total")]'))
            )

if __name__ == '__main__':
    unittest.main()
