import unittest

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver


class DNAAlertManagementTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='hyejun.yim')
    def test_given_user_is_internal_user_when_display_dna_alert_management_then_should_be_shown(self):
        driver = self.driver
        ###########################################################################################################
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//span[text() = 'Dynamic Network Acceleration']"))
        )

        driver.find_elements(By.XPATH, "//span[text() = 'Dynamic Network Acceleration']")[0].click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '/dna/monitoring/alert/')]"))
        )

        driver.find_element(By.XPATH, "//a[contains(@href, '/dna/monitoring/alert/')]").click()
 
        el = driver.find_element(By.CSS_SELECTOR, ".chosen-single")
        el.click()

        el2 = driver.find_element(By.CSS_SELECTOR, ".chosen-search")
        el3 = el2.find_element(By.XPATH, ".//input[@type='text']")
        el3.clear()
        el3.send_keys('88 Brothers IT')
        el3.send_keys(Keys.RETURN)

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[contains(text(), 'Alert Management')]"))
        )

        driver.find_element(By.XPATH, "//a[contains(text(), 'Alert Management')]").click()

        # Alert Management Add
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, '//div[contains(text(), "deletetest.cdnetworks.com")]'))
        )

        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.ID, "btn_add_alert"))
        )

        driver.find_element(By.ID, "btn_add_alert").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, '//select[@ng-model="info.alert_type"]'))
        )

        el4 = driver.find_element(By.XPATH, "//select[@ng-model='info.alert_type']")
        el4.send_keys('Error Spike')

        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, "//select[@ng-model='info.stat_master']/option[text()='deletetest.cdnetworks.com']"))
        )

        el5 = driver.find_element(By.XPATH, "//select[@ng-model='info.stat_master']")
        el5.send_keys('mproxy.hjtest.com')

        el6 = driver.find_element(By.XPATH, "//select[@ng-model='info.threshold_type']")
        el6.send_keys('Dynamic')

        el7 = driver.find_element(By.XPATH, "//input[@ng-model='info.threshold_value']")
        el7.send_keys('250')

        el8 = driver.find_element(By.XPATH, "//input[@ng-model='info.alert_receiver']")
        el8.send_keys('seleniumtest@cdnetworks.com')

        driver.find_element(By.XPATH, "//button[contains(@ng-click,'alert_save')]").click()

        # Alert Management modify
        WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.ID, "btn_add_alert"))
        )

        WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, "//div[@ng-show='!_is_management_loading']//table//tbody//tr[1]//button[contains(@ng-click,'alert_modify_ui(')]"))
        )

        driver.find_element(By.XPATH, "//div[@ng-show='!_is_management_loading']//table//tbody//tr[1]//button[contains(@ng-click,'alert_modify_ui(')]").click()

        el7 = driver.find_elements(By.XPATH, "//input[@ng-model='a_management.threshold_value']")[0]
        el7.send_keys('300')

        driver.find_elements(By.XPATH, "//button[contains(@ng-click,'alert_modify(')]")[0].click()

        # Alert Management delete
        WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, "//div[contains(text(),'seleniumtest@cdnetworks.com')]"))
        )

        driver.find_elements(By.XPATH, "//button[contains(@ng-click,'alert_delete')]")[0].click()

        WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, "//a[contains(text(),'Yes')]"))
        )

        driver.find_element(By.XPATH, "//a[contains(text(),'Yes')]").click()
        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
