import unittest
from selenium_test.shared_components.decorators import catch_exception

from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium.webdriver.common.by import By

class DnaDocumentTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='wonho.choi')
    def test_is_documentation(self):
        driver = self.driver
        driver.find_elements(By.XPATH, "//span[text() = 'Dynamic Network Acceleration']")[0].click()
        driver.find_element_by_xpath("(//a[contains(text(),'Documentation')])[5]").click()
        driver.switch_to_frame(driver.find_element_by_tag_name("iframe"))
        driver.find_element_by_link_text("Dynamic Network Acceleration User Guide").click()
        
if __name__ == '__main__':
    unittest.main()
