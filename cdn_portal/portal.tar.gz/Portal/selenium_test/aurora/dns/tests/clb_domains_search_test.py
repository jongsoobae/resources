import unittest

## CONFIGURATIONS
from selenium_test.config_user_constants import AURORA_CUSTOMER_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver

from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from time import sleep

class ClbDomainsSearchTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_CUSTOMER_USER['dns_clb_customer_user'])

    def tearDown(self):
        self.driver.quit()

    @catch_exception(author='hyejun.yim')
    def test_is_clb_domains_list_search_option(self):
        driver = self.driver
        ##############################################################################################
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//span[text() = 'Cloud DNS']"))
        )

        driver.find_elements(By.XPATH, "//span[text() = 'Cloud DNS']")[0].click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[text() = 'CLB Domains']"))
        )

        driver.find_element(By.XPATH, "//a[text() = 'CLB Domains']").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, "txt_clb_search"))
        )

        search_txt = driver.find_element(By.ID, "txt_clb_search")
        search_txt.clear()
        search_txt.send_keys('davidkim')

        driver.find_element(By.ID, "btn_clb_search").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//td[@class='clb_domains_td_domain']"))
        )
        sleep(3)
        table_lists = driver.find_elements(By.XPATH, "//td[@class='clb_domains_td_domain']")

        for elm in table_lists:
            if 'davidkim' not in elm.text:
                raise

        # page change test
        driver.find_element(By.XPATH, "//a[@ng-click='selectPage(page.number)'][text()='2']").click()
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//td[@class='clb_domains_td_domain']"))
        )
        sleep(3)

        active_page = driver.find_element(By.XPATH, "//li[@class='ng-scope active']/a").text
        self.assertEqual(active_page, '2')

        # clb domain search reset
        driver.find_element(By.ID, "reset_clb_domain").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//td[@class='clb_domains_td_domain']"))
        )
        sleep(3)

        # Click the reset button to return to the first page.
        active_page = driver.find_element(By.XPATH, "//li[@class='ng-scope active']/a").text
        self.assertEqual(active_page, '1')

        davidkim_txt_cnt = 0
        table_lists = driver.find_elements(By.XPATH, "//td[@class='clb_domains_td_domain']")

        for elm in table_lists:
            if 'davidkim' not in elm.text:
                davidkim_txt_cnt += 1

        self.assertTrue(davidkim_txt_cnt > 0)

        # no data -> search box reset test
        search_txt = driver.find_element(By.ID, "txt_clb_search")
        search_txt.clear()
        search_txt.send_keys('atgaetaet')
        driver.find_element(By.ID, "btn_clb_search").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, "list_reset_clb_domain"))
        )
        driver.find_element(By.ID, "list_reset_clb_domain").click()

if __name__ == '__main__':
    unittest.main()