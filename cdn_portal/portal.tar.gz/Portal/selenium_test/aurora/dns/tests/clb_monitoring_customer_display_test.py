import unittest

## CONFIGURATIONS
from selenium_test.config_user_constants import AURORA_CUSTOMER_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from time import sleep

class ClbMonitoringCustomerDisplayTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_CUSTOMER_USER.get('cloud_dns'))

    def tearDown(self):
        self.driver.quit()

    @catch_exception(author='hyejun.yim')
    def test_is_clb_monitoring_customer_display(self):
        driver = self.driver
        ##############################################################################################
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//span[text() = 'Cloud DNS']"))
        )

        driver.find_elements(By.XPATH, "//span[text() = 'Cloud DNS']")[0].click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[text() = 'CLB Monitoring']"))
        )

        # get the current window handle
        main_window_handle = None
        while not main_window_handle:
            main_window_handle = driver.current_window_handle

        # click some link that opens a new window
        driver.find_element(By.XPATH, "//a[text() = 'CLB Monitoring']").click()

        # switch focus of WebDriver to the next found window handle (that's your newly opened window)
        driver.switch_to_window(driver.window_handles[-1])

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//h1[text() = 'CLB Monitoring']"))
        )

        sleep(2)
        # select box customer name check
        driver.find_element(By.XPATH, "//button[@ng-click='showConditions()']").click()
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//span[text() = 'Conditions']"))
        )
        sleep(1)
        el1 = driver.find_element(By.XPATH, "//div[@id='account_list_chosen']/a").text
        driver.find_element(By.XPATH, "//button[@ng-click='cancelRefresh()']").click()
        el2 = driver.find_elements(By.XPATH, "//div[@class='clb_top_container']/div/div[@class='ng-binding']")[0].text

        # check : select box customer name = CLB Monitoring page ui customer name 
        self.assertEqual(el1,el2)
        ##############################################################################################
        # close newly opened window when done with it
        driver.close()
        # switch back to the original window
        driver.switch_to_window(main_window_handle)

if __name__ == '__main__':
    unittest.main()