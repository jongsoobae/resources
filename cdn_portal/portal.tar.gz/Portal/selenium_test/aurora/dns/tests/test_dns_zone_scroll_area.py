
from selenium_test.shared_components.testcase import AuroraTestCase


class TestDnsZoneScrollArea(AuroraTestCase):

    dns_zone_list_uri = '/dns/zones_list/?m=268'
    dns_zone_page_uri = '/dns/zone/11201'

    def setUp(self):
        # get to dns zone page directly will occurs 403 error.
        # need to get to zone list page first, and initialize session.
        self.direct_to(self.dns_zone_list_uri)
        self.direct_to(self.dns_zone_page_uri)

    def test_dns_zone_field_area_is_scrollable(self):

        dns_zone_field_area = self.driver.find_element_by_xpath('//div[@id="edit_form"]')

        height = dns_zone_field_area.value_of_css_property('height')
        overflow = dns_zone_field_area.value_of_css_property('overflow-y')

        self.assertEqual(height, '600px')
        self.assertEqual(overflow, 'scroll')
