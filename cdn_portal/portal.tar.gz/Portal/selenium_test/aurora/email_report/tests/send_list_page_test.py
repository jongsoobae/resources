import unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.utils import get_web_driver
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.conf import settings


class send_list_page_test(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='sichoon.kwon')
    def test_send_list_shown(self):
        driver = self.driver

        driver.get(settings.AURORA_FE_URL + "/email_report/send_list/")
        Select(driver.find_element(By.NAME, "corporationCD")).select_by_value("UK")

        driver.find_element(By.XPATH, "//input[@type=\"submit\"]").click()

        region_text = Select(driver.find_element(By.NAME, "corporationCD")).first_selected_option.text
        self.assertEqual(region_text, "UK")

if __name__ == "__main__":
    unittest.main()
