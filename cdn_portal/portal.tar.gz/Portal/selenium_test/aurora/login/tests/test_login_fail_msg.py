import unittest

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By

from selenium_test.config_constants import AURORA_FE_URL
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.utils import get_web_driver


class CAVisitorPageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='hwaeun.seo')
    def test_fail_msg(self):
        message = 'Your username and/or password were incorrect.'
        driver = self.driver
        driver.get(AURORA_FE_URL + "/accounts/login/?next=/")
        driver.find_element(By.ID, "id_login").click()
        msg = driver.find_element(By.CLASS_NAME, 'warning-box').text
        self.assertEqual(message, msg)

if __name__ == '__main__':
    unittest.main()
