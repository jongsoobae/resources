import unittest
import datetime

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from time import sleep

class MATrafficPageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)
        self.driver.implicitly_wait(1)

    def tearDown(self):
        self.driver.close()
        #pass

    # [AURORAUI-2569]
    @catch_exception(author='hwaeun.seo')
    def test_edge_active_connection_check(self):
        driver = self.driver
        ###########################################################################################################
        driver.find_elements(By.XPATH, "//span[text() = 'Media Acceleration']")[0].click()

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[text() = 'Traffic']"))
        )
        driver.find_elements(By.XPATH, "//a[text() = 'Traffic']")[2].click()

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "btn_view"))
        )
        sleep(2)

        el4 = driver.find_element(By.CSS_SELECTOR, ".chosen-single")
        el4.click()

        el5 = driver.find_element(By.CSS_SELECTOR, ".chosen-search")
        el6 = el5.find_element(By.XPATH, ".//input[@type='text']")
        el6.clear()
        el6.send_keys('Canalchat')
        el6.send_keys(Keys.RETURN)
        sleep(2)

        el1 = driver.find_elements(By.XPATH, "//*[@data-value='specified']")
        el1[0].click()

        today = datetime.date.today()
        date_to = today.strftime('%Y-%m-%d')
        date_from = (today - datetime.timedelta(days=1)).strftime('%Y-%m-%d')

        el = driver.find_element(By.ID, "id_date_from")
        el.clear()
        el.send_keys(date_from)

        el = driver.find_element(By.ID, "id_date_to")
        el.clear()
        el.send_keys(date_to)

        el = driver.find_element(By.ID, "btn_view")
        webdriver.ActionChains(driver).move_to_element(el).click(el).perform()

        sleep(3)

        try:
            active_connection = driver.find_element(By.ID, 'container_STAT_EDGE_ACTIVE_CONNECTION')
        except NoSuchElementException:
            raise Exception('No Such Edge Active Connection')


        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
