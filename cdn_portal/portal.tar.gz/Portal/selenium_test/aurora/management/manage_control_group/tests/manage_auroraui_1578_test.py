# -*- coding: utf-8 -*-
import unittest

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver


class ManageControlGroupPageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='wonho.choi')
    def test_auroraui_1578_add_privileges(self):
        driver = self.driver
        ###########################################################################################################

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[text() = 'Manage Control Groups']"))
        )

        driver.find_elements(By.XPATH, "//a[text() = 'Manage Control Groups']")[0].click()

        el = driver.find_element(By.ID, "account_list_chosen")
        el4 = el.find_element(By.CSS_SELECTOR, ".chosen-single")
        el4.click()
        el6 = el.find_element(By.XPATH, ".//input[@type='text']")
        el6.clear()
        el6.send_keys('Neungyule')
        el6.send_keys(Keys.RETURN)

        WebDriverWait(driver, 20).until(
            EC.visibility_of_element_located((By.XPATH, "//a[contains(text(), 'Neungyule')]"))
        )

        driver.find_element(By.ID, "priv_button").click()
        #[AURORAUI-1578] Test
        driver.find_elements(By.XPATH, "//label[text() = 'Response Code']")[0].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Top 10 URLs Resulting in Error']")[0].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Top 10 Directories Resulting in Error']")[0].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Number of URLs by Response Code']")[0].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Edge Hits (Number of Requests)']")[0].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Edge Response Code']")[0].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Origin Hits']")[0].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Origin Response Code']")[0].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Cache Hit Ratio (by Number of Requests)']")[0].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Top 10 URLs Resulting in Error']")[1].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Top 10 Directories Resulting in Error']")[1].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Number of URLs by Failed Response Code']")[0].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Edge Hits (Number of Requests)']")[1].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Edge Response Code']")[1].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Origin Hits']")[1].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Origin Response Code']")[1].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Cache Hit Ratio (by Number of Requests)']")[1].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Top 10 URLs Resulting in Error']")[2].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Top 10 Directories Resulting in Error']")[2].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Number of URLs by Failed Response Code']")[1].click()
        #[AURORAUI-2462] Test
        driver.find_elements(By.XPATH, "//label[text() = 'Edge Response Code Detail']")[0].click()
        driver.find_elements(By.XPATH, "//label[text() = 'Origin Response Code Detail']")[0].click()
        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
