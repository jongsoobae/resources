import unittest
import time

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver


class ManageControlGroupPageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.quit()

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_internal_user_when_display_manage_control_group_page_then_should_be_shown(self):
        driver = self.driver
        ###########################################################################################################

        WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, "//menu[@id='menu2']//a[text() = 'Manage Control Groups']"))
        )

        driver.find_element(By.XPATH, "//menu[@id='menu2']//a[text() = 'Manage Control Groups']").click()

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//a[contains(@href, '/manage/user_control/update/cg_')]"))
        )

        el_list = driver.find_elements(By.XPATH, "//a[contains(@href, '/manage/user_control/update/cg_')]")

        for elm in el_list:
            elm.click()
            el = driver.find_element(By.ID, "user_list")
            usr_list = el.find_elements(By.XPATH, "//input[@type='checkbox']")
            if len(usr_list) >= 0:
                break
        ###########################################################################################################

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_internal_user_when_customer_privilege__then_should_be_shown(self):
        driver = self.driver
        ###########################################################################################################

        WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, "//menu[@id='menu2']//a[text() = 'Manage Control Groups']"))
        )

        # Go to Manage Control Group
        driver.find_element(By.XPATH, "//menu[@id='menu2']//a[text() = 'Manage Control Groups']").click()

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//button[@id='priv_button']"))
        )

        # Click Customer Privilege button
        driver.find_element(By.XPATH, "//button[@id='priv_button']").click()

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//label[text()='Content Acceleration']/following-sibling::ul//li"))
        )

        # Get all privileges of 'Content Acceleration' menu
        ca_privilege_list = []
        ca_privilege_elements = driver.find_elements(By.XPATH, "//label[text()='Content Acceleration']/following-sibling::ul//li")

        for elem in ca_privilege_elements:
            ca_privilege_list.append(elem.find_element(By.TAG_NAME, 'label').text)

        # Check privileges of CIC are exist in privilege list of CA.
        # Because product name is changed from 'ImageConverter' to 'CIC'.
        self.assertIn('CIC Traffic Report', ca_privilege_list)
        self.assertIn('CIC Response Code Detail', ca_privilege_list)
        self.assertIn('CIC Origin Response Code Detail', ca_privilege_list)

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//label[text()='Dynamic Web Acceleration']/following-sibling::ul//li"))
        )

        # Get all privileges of 'Dynamic Web Acceleration' menu
        dwa_privilege_list = []
        dwa_privilege_elements = driver.find_elements(By.XPATH, "//label[text()='Dynamic Web Acceleration']/following-sibling::ul//li")

        for elem in dwa_privilege_elements:
            dwa_privilege_list.append(elem.find_element(By.TAG_NAME, 'label').text)

        # Check privileges of CIC are exist in privilege list of DWA.
        # Because product name is changed from 'ImageConverter' to 'CIC'.
        self.assertIn('CIC Traffic Report', dwa_privilege_list)
        self.assertIn('CIC Response Code Detail', dwa_privilege_list)
        self.assertIn('CIC Origin Response Code Detail', dwa_privilege_list)

        ###########################################################################################################

    # [AURORAUI-2569]
    @catch_exception(author='hwaeun.seo')
    def test_ma_mm_privilege_edge_action_connection(self):
        driver = self.driver

        WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, "//menu[@id='menu2']//a[text() = 'Manage Control Groups']"))
        )

        # Go to Manage Control Group
        driver.find_element(By.XPATH, "//menu[@id='menu2']//a[text() = 'Manage Control Groups']").click()

        el = driver.find_element(By.ID, "account_list_chosen")
        el4 = el.find_element(By.CSS_SELECTOR, ".chosen-single")
        el4.click()
        for i in driver.find_elements(By.CLASS_NAME, 'active-result'):
            if i.text.strip() == 'CDNetworks':
                i.click()
                break

        time.sleep(5)
        # Click Customer Privilege button
        driver.find_element(By.XPATH, "//button[@id='priv_button']").click()

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//label[text()='Media Acceleration']/following-sibling::ul//li"))
        )

        # Get all privileges of 'Media Acceleration' menu
        ma_privilege_list = []
        ma_privilege_elements = driver.find_elements(By.XPATH, "//label[text()='Media Acceleration']/following-sibling::ul//li")

        for elem in ma_privilege_elements:
            ma_privilege_list.append(elem.find_element(By.TAG_NAME, 'label').text)

        self.assertIn('Edge Active Connection', ma_privilege_list)

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//label[text()='Media Acceleration - Mobile']/following-sibling::ul//li"))
        )

        # Get all privileges of 'Media Acceleration - Mobile' menu
        mm_privilege_list = []
        mm_privilege_elements = driver.find_elements(By.XPATH, "//label[text()='Media Acceleration - Mobile']/following-sibling::ul//li")

        for elem in mm_privilege_elements:
            mm_privilege_list.append(elem.find_element(By.TAG_NAME, 'label').text)

        self.assertIn('Edge Active Connection', mm_privilege_list)

        # multiple
        elem = driver.find_elements(By.XPATH, "//label[text()='Edge Active Connection']")
        for i in elem:
            i.click()
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, 'btn_submit'))
        )
        driver.find_element(By.ID, 'btn_submit').click()
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, 'common-dialog'))
        )
        common_dialog_text = driver.find_element(By.ID, 'common-dialog').text.strip()
        if common_dialog_text == '':
            time.sleep(5)
            common_dialog_text = driver.find_element(By.ID, 'common-dialog').text.strip()

        self.assertEqual('Customer privileges has been changed', common_dialog_text)

