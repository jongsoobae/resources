import unittest
import time

from django.contrib.auth.models import User
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from aurora_fe.shared_components.models.acl_core import AuthUserHasControlGroup
from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from datetime import datetime


class ManageUserAccountsPageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_internal_user_when_add_new_user_then_should_be_worked(self):
        driver = self.driver
        ###########################################################################################################

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[text() = 'Manage User Accounts']"))
        )

        driver.find_elements(By.XPATH, "//a[text() = 'Manage User Accounts']")[0].click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, "add_btn"))
        )

        driver.find_element(By.ID, "add_btn").click()

        i = 1
        date_str = datetime.now().strftime('%Y%m%d')
        while 1:
            user_to_create = date_str + 'testuser' + str(i) + '@cdnetworks.com'
            driver.find_element(By.ID, "id_email").clear()
            driver.find_element(By.ID, "id_email").send_keys(user_to_create)
            driver.find_element(By.ID, "duplicate_btn").click()

            WebDriverWait(driver, 120).until(
                EC.presence_of_element_located((By.ID, 'common-dialog'))
            )
            common_dialog_text = driver.find_element(By.ID, 'common-dialog').text.strip()

            if common_dialog_text == '':
                time.sleep(5)
                common_dialog_text = driver.find_element(By.ID, 'common-dialog').text.strip()

            WebDriverWait(driver, 120).until(
                EC.presence_of_element_located((By.XPATH, "//div[@id = 'common-dialog']/following-sibling::div//div//button"))
            )

            if common_dialog_text == 'It is valid e-mail address.':
                driver.find_element(By.XPATH, "//div[@id = 'common-dialog']/following-sibling::div//div//button").click()
                break
            else:
                driver.find_element(By.XPATH, "//div[@id = 'common-dialog']/following-sibling::div//div//button").click()
                i += 1

        driver.find_element(By.ID, "id_first_name").clear()
        driver.find_element(By.ID, "id_first_name").send_keys("testuser" + str(i))
        driver.find_element(By.ID, "id_last_name").clear()
        driver.find_element(By.ID, "id_last_name").send_keys(date_str)
        driver.find_element(By.ID, "account_list_chosen").click()
        driver.find_element(By.CSS_SELECTOR, "div.chosen-search > input[type=\"text\"]").clear()
        driver.find_element(By.CSS_SELECTOR, "div.chosen-search > input[type=\"text\"]").send_keys("32red")
        driver.find_element(By.ID, "btn_submit").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "(//button[@type='button'])[12]"))
        )
        driver.find_element(By.XPATH, "(//button[@type='button'])[12]").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, 'common-dialog'))
        )
        common_dialog_text = driver.find_element(By.ID, 'common-dialog').text.strip()

        self.assertEqual(common_dialog_text, 'User information has been created.')
        ###########################################################################################################

    @catch_exception(author='dasol.kim')
    def test_select_all_checkBox_for_control_group_select(self):
        driver = self.driver
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[text() = 'Manage User Accounts']"))
        )

        driver.find_elements(By.XPATH, "//a[text() = 'Manage User Accounts']")[0].click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, "add_btn"))
        )

        driver.find_element(By.ID, "add_btn").click()

        i = 1
        date_str = datetime.now().strftime('%Y%m%d')
        while 1:
            user_to_create = date_str + 'testuser' + str(i) + '@cdnetworks.com'
            driver.find_element(By.ID, "id_email").clear()
            driver.find_element(By.ID, "id_email").send_keys(user_to_create)
            driver.find_element(By.ID, "duplicate_btn").click()

            WebDriverWait(driver, 120).until(
                EC.presence_of_element_located((By.ID, 'common-dialog'))
            )
            common_dialog_text = driver.find_element(By.ID, 'common-dialog').text.strip()

            if common_dialog_text == '':
                time.sleep(5)
                common_dialog_text = driver.find_element(By.ID, 'common-dialog').text.strip()

            WebDriverWait(driver, 120).until(
                EC.presence_of_element_located(
                    (By.XPATH, "//div[@id = 'common-dialog']/following-sibling::div//div//button"))
            )

            if common_dialog_text == 'It is valid e-mail address.':
                driver.find_element(By.XPATH,
                                    "//div[@id = 'common-dialog']/following-sibling::div//div//button").click()
                break
            else:
                driver.find_element(By.XPATH,
                                    "//div[@id = 'common-dialog']/following-sibling::div//div//button").click()
                i += 1

        driver.find_element(By.ID, "id_first_name").clear()
        driver.find_element(By.ID, "id_first_name").send_keys("testuser" + str(i))
        driver.find_element(By.ID, "id_last_name").clear()
        driver.find_element(By.ID, "id_last_name").send_keys(date_str)

        # select_all_checkBox: check off
        driver.find_element_by_css_selector("input.select_all").click()
        control_group_checkBox_for_test1 = driver.find_elements(By.XPATH, "//input[@name='control_group']")
        for i in range(control_group_checkBox_for_test1.__len__()):
            self.assertEqual(None, control_group_checkBox_for_test1[i].get_attribute('checked'))

        # select_all_checkBox: Check on
        driver.find_element_by_css_selector("input.select_all").click()
        control_group_checkBox_for_test2 = driver.find_elements(By.XPATH, "//input[@name='control_group']")
        for i in range(control_group_checkBox_for_test2.__len__()):
            self.assertEqual(u'true', control_group_checkBox_for_test2[i].get_attribute('checked'))

        # a checkBox that is one of control group list: check off
        driver.find_element_by_name("control_group").click()
        self.assertEqual(None, driver.find_element_by_css_selector("input.select_all").get_attribute('checked'))

        # a checkBox that is one of control group list: check on
        driver.find_element_by_name("control_group").click()
        self.assertEqual(u'true', driver.find_element_by_css_selector("input.select_all").get_attribute('checked'))

        checked_count = driver.find_elements_by_css_selector("input[name=control_group]:checked").__len__()

        driver.find_element(By.ID, "btn_submit").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, 'common-dialog'))
        )
        common_dialog_text = driver.find_element(By.ID, 'common-dialog').text.strip()

        self.assertEqual(common_dialog_text, 'User information has been created.')

        auth_user_id = User.objects.get(username=user_to_create)
        self.assertEqual(checked_count, len(AuthUserHasControlGroup.objects.filter(auth_user_id=auth_user_id)))

if __name__ == '__main__':
    unittest.main()
