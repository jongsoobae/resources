import unittest
import time

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from datetime import datetime


class ManageUserAddTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='hwaeun.seo')
    def test_add_user_duplicated_email(self):
        driver = self.driver

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[text() = 'Manage User Accounts']"))
        )

        driver.find_elements(By.XPATH, "//a[text() = 'Manage User Accounts']")[0].click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, "add_btn"))
        )

        driver.find_element(By.ID, "add_btn").click()
        time.sleep(3)

        date_str = datetime.now().strftime('%Y%m%d%H%M%S')
        user_to_create = date_str + '_testuser' + '@cdnetworks.com'

        driver.find_element(By.ID, "id_email").clear()
        driver.find_element(By.ID, "id_email").send_keys(user_to_create)
        driver.find_element(By.ID, "duplicate_btn").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, 'common-dialog'))
        )
        common_dialog_text = driver.find_element(By.ID, 'common-dialog').text.strip()

        if common_dialog_text == '':
            time.sleep(5)
            common_dialog_text = driver.find_element(By.ID, 'common-dialog').text.strip()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//div[@id = 'common-dialog']/following-sibling::div//div//button"))
        )

        if common_dialog_text == 'It is valid e-mail address.':
            driver.find_element(By.XPATH, "//div[@id = 'common-dialog']/following-sibling::div//div//button").click()
        else:
            driver.find_element(By.XPATH, "//div[@id = 'common-dialog']/following-sibling::div//div//button").click()
            raise

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, 'btn_submit'))
        )
        driver.find_element(By.ID, 'btn_submit').click()

        # WebDriverWait(driver, 120).until(
        #     EC.presence_of_element_located((By.CLASS_NAME, 'ic-excal2'))
        # )
        # driver.find_element(By.CLASS_NAME, 'ic-excal2')

        driver.find_element(By.ID, "id_first_name").clear()
        driver.find_element(By.ID, "id_first_name").send_keys("testuser")
        driver.find_element(By.ID, "id_last_name").clear()
        driver.find_element(By.ID, "id_last_name").send_keys(date_str)

        driver.find_element(By.ID, "btn_submit").click()
        time.sleep(3)

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, 'common-dialog'))
        )
        common_dialog_text = driver.find_element(By.ID, 'common-dialog').text.strip()

        if common_dialog_text == '':
            time.sleep(5)
            common_dialog_text = driver.find_element(By.ID, 'common-dialog').text.strip()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//div[@id = 'common-dialog']/following-sibling::div//div//button"))
        )

        if common_dialog_text == 'User information has been created.':
            driver.find_element(By.XPATH, "//div[@id = 'common-dialog']/following-sibling::div//div//button").click()
        else:
            driver.find_element(By.XPATH, "//div[@id = 'common-dialog']/following-sibling::div//div//button").click()
            raise

    # [AURORAUI-2569]
    @catch_exception(author='hwaeun.seo')
    def test_add_user_check_privileges(self):
        driver = self.driver

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[text() = 'Manage User Accounts']"))
        )

        driver.find_elements(By.XPATH, "//a[text() = 'Manage User Accounts']")[0].click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, "add_btn"))
        )

        driver.find_element(By.ID, "add_btn").click()

        date_str = datetime.now().strftime('%Y%m%d%H%M%S')
        user_to_create = date_str + '_testuser' + '@cdnetworks.com'

        driver.find_element(By.ID, "id_email").clear()
        driver.find_element(By.ID, "id_email").send_keys(user_to_create)
        driver.find_element(By.ID, "duplicate_btn").click()
        common_dialog_text = driver.find_element(By.ID, 'common-dialog').text.strip()

        if common_dialog_text == '':
            time.sleep(5)
            common_dialog_text = driver.find_element(By.ID, 'common-dialog').text.strip()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//div[@id = 'common-dialog']/following-sibling::div//div//button"))
        )

        driver.find_element(By.XPATH, "//div[@id = 'common-dialog']/following-sibling::div//div//button").click()

        driver.find_element(By.ID, "id_first_name").clear()
        driver.find_element(By.ID, "id_first_name").send_keys("testuser")
        driver.find_element(By.ID, "id_last_name").clear()
        driver.find_element(By.ID, "id_last_name").send_keys(date_str)

        elem = driver.find_elements(By.XPATH, "//span[text()='Edge Active Connection']")

        for i in elem:
            # click event ... element is not clickable at point
            driver.execute_script("arguments[0].click();", i)

        time.sleep(3)
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, 'btn_submit'))
        )
        btn_button = driver.find_element(By.ID, 'btn_submit')
        driver.execute_script("arguments[0].click();", btn_button)
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, 'common-dialog'))
        )
        common_dialog_text = driver.find_element(By.ID, 'common-dialog').text.strip()
        if common_dialog_text == '':
            time.sleep(5)
            common_dialog_text = driver.find_element(By.ID, 'common-dialog').text.strip()

        self.assertEqual('User information has been created.', common_dialog_text)


if __name__ == '__main__':
    unittest.main()
