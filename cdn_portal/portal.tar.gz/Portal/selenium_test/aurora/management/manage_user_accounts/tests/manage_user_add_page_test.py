# [AURORAUI-3256]
import os
import unittest as unittest

if os.environ.get('DJANGO_SETTINGS_MODULE') is None:
    os.environ['DJANGO_SETTINGS_MODULE'] = 'aurora_fe.settings'

import time
from selenium.webdriver.common.by import By
from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from selenium.common.exceptions import NoSuchElementException


class DuplicateUserTest(unittest.TestCase):

    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    def check_exists_by_xpath(self, xpath):
        try:
            self.driver.find_element_by_xpath(xpath)
        except NoSuchElementException:
            self.fail("xpath doesn't exist")


    def test_user_goes_to_add_page(self):
        # user goes to manage user account and clicks on add
        driver = self.driver
        driver.find_elements(By.XPATH, "//a[text() = 'Manage User Accounts']")[0].click()
        driver.find_element(By.ID, "add_btn").click()
        time.sleep(1)

        # user adds email address (already exist) and gets error and clicks ok
        driver.find_element(By.ID, "id_email").send_keys("mlbi77@naver.com")
        driver.find_element(By.ID, "duplicate_btn").click()
        time.sleep(1)

        dialogText = driver.find_element(By.ID, "common-dialog").text
        self.assertIn("E-mail address is duplicated", dialogText)
        driver.find_element(By.XPATH, '/html/body/div[4]/div[3]/div/button/span').click()
        time.sleep(1)

        control_group_before = driver.find_element(By.ID, "control_group")

        # user tries to add another email with special case
        driver.find_element(By.ID, "id_email").clear()
        driver.find_element(By.ID, "id_email").send_keys("jeanie.baker@us.abb.com")
        driver.find_element(By.ID, "duplicate_btn").click()
        time.sleep(1)


        dialogText = driver.find_element(By.ID, "dialog_access_information").text
        self.assertIn("The email you have entered already exists in CDNetworks database.", dialogText)
        driver.find_element(By.XPATH, '/html/body/div[3]/div[3]/div/button[1]/span').click()
        time.sleep(1)

        #check if control groups are the same
        control_group_after = driver.find_element(By.ID, "control_group")
        self.assertEqual(control_group_before, control_group_after)

        # checks to see if control appears
        xpath1 = '//*[@id="control_group"]/li'
        xpath2 = '//*[@id="role_privilege"]/ul/li'
        self.check_exists_by_xpath(xpath1)
        self.check_exists_by_xpath(xpath2)

        self.fail("finish")