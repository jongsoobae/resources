# -*- coding: utf-8 -*-
# [AURORAUI-3175]
import unittest

import time

from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.config_constants import AURORA_FE_URL
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver


class ManageUserToChangeStatusTest(unittest.TestCase):
    def setUp(self):
        driver = self.driver = get_web_driver()

        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)
        driver.get(('%s/manage/user_profile/?m=167' % AURORA_FE_URL))
        korean_option = driver.find_element(By.XPATH, '//option[@value="ko-kr"]')
        korean_option.click()
        driver.find_element(By.ID, 'btn_submit').click()

        driver.get(('%s/manage/user_manage_list/?m=168' % AURORA_FE_URL))

        driver.find_element(By.ID, 'filter_button').click()

    def tearDown(self):
        self.driver.close()

    def test_try_to_change_status_from_active_to_active(self):
        self.assert_try_to_change_status(1, 'active', u'활성화 하려는 사용자를 체크해 주십시오')

    def test_try_to_change_status_from_inactive_to_inactive(self):
        self.assert_try_to_change_status(2, 'inactive', u'비활성화 하려는 사용자를 체크해 주십시오')

    def test_try_to_chnage_status_from_active(self):
        driver = self.driver

        self.assert_try_to_change_status(1, 'inactive', u'User 정보가 성공적으로 변경되었습니다.')

        driver.find_element(By.CSS_SELECTOR, 'button.ui-button.ui-widget.ui-state-default.ui-corner-all.ui-button-text-only').click()

        driver.find_element(By.ID, 'active_user').click()
        time.sleep(1)

        self.assertEqual(driver.find_element(By.ID, 'common-dialog').text, u'User 정보가 성공적으로 변경되었습니다.')

    def assert_try_to_change_status(self, option_idx, status, warning_msg):
        driver = self.driver

        driver.find_elements(By.CSS_SELECTOR, '#id_status > option')[option_idx].click()
        driver.find_element(By.ID, 'search_btn').click()

        driver.find_element(By.CSS_SELECTOR, 'div.table > table > tbody > tr > td > input').click()
        driver.find_element(By.ID, '%s_user' % status).click()

        time.sleep(1)

        self.assertEqual(driver.find_element(By.ID, 'common-dialog').text, warning_msg)

if __name__ == '__main__':
    unittest.main()
