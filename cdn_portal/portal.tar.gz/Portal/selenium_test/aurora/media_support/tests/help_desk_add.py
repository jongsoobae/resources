import unittest
import time

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from datetime import datetime


# [AURORAUI-2925]
class HelpDeskAddTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='hwaeun.seo')
    def test_add_help_desk(self):
        driver = self.driver

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[text() = 'Customer Support']"))
        )

        driver.find_elements(By.XPATH, "//a[text() = 'Customer Support']")[0].click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, "add_btn"))
        )

        driver.find_element(By.ID, "add_btn").click()
        time.sleep(3)

        el = driver.find_element(By.ID, "customer_selector_chosen")
        el4 = el.find_element(By.CSS_SELECTOR, ".chosen-single")
        el4.click()
        el6 = el.find_element(By.XPATH, ".//input[@type='text']")
        el6.clear()
        el6.send_keys('CDNetworks')
        el6.send_keys(Keys.RETURN)
        time.sleep(3)

        driver.find_element(By.ID, "user_search_button").click()
        time.sleep(3)

        el = driver.find_element(By.ID, "customer_selector_for_search_chosen")
        el4 = el.find_element(By.CSS_SELECTOR, ".chosen-single")
        el4.click()
        el6 = el.find_element(By.XPATH, ".//input[@type='text']")
        el6.clear()
        el6.send_keys('CDNetworks')
        el6.send_keys(Keys.RETURN)

        driver.find_element(By.ID, "search_user_search_button").click()

        driver.find_elements(By.XPATH, "//td[text()='hwaeun.seo@cdnetworks.com']")[0].click()
        time.sleep(3)

        driver.find_element(By.XPATH, "//textarea[@ng-model = 'request.info.help_desc']").clear()
        driver.find_element(By.XPATH, "//textarea[@ng-model = 'request.info.help_desc']").send_keys('test')

        driver.find_element(By.ID, "save_button").click()

if __name__ == '__main__':
    unittest.main()
