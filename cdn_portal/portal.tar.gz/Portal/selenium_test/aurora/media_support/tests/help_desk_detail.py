# -*- coding: utf-8 -*-

import unittest
import time

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from datetime import datetime


# [AURORAUI-2925]
class HelpDeskDetailTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='hwaeun.seo')
    def test_processing_help_desk(self):
        driver = self.driver

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[text() = 'Customer Support']"))
        )

        driver.find_elements(By.XPATH, "//a[text() = 'Customer Support']")[0].click()
        time.sleep(3)
        driver.find_elements(By.XPATH, "//td[text()='seohwaeun']")[0].click()
        time.sleep(3)

        error_cause_cd = driver.find_element(By.ID, "select_error_cause_cd")
        error_cause_cd.click()

        new_option_check = False
        for option in error_cause_cd.find_elements_by_tag_name('option'):
            if option.text.encode('utf-8') == '모바일장애':
                new_option_check = True
                break


        if not new_option_check:
            raise Exception("New Option Error")

        driver.find_element(By.XPATH, '//*[@id="content-right"]/div/div[3]/table[2]/tbody/tr[1]/td[2]').click()

        for i in range(1, 21):
            driver.find_element(
                By.XPATH,
                '//*[@id="content-right"]/div/div[3]/table[2]/tbody/tr[2]/td/span[%s]/span/input'
                % i
            ).click()

        driver.find_element(By.XPATH, '//*[@id="content-right"]/div/div[3]/table[2]/tbody/tr[4]/td/textarea').clear()
        driver.find_element(By.XPATH, '//*[@id="content-right"]/div/div[3]/table[2]/tbody/tr[4]/td/textarea').send_keys('test')

        time.sleep(3)
        driver.find_element(By.XPATH,
                '//*[@id="content-right"]/div/div[3]/div[2]/div/button[1]').click()


    @catch_exception(author='hwaeun.seo')
    def test_edit_help_desk(self):
        driver = self.driver

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[text() = 'Customer Support']"))
        )

        driver.find_elements(By.XPATH, "//a[text() = 'Customer Support']")[0].click()
        time.sleep(3)
        driver.find_elements(By.XPATH, "//td[text()='seohwaeun']")[0].click()

        driver.find_element(By.XPATH, '//*[@id="content-right"]/div/div[3]/div[1]/div/button[1]').click()
        time.sleep(3)


        # email
        driver.find_element(By.XPATH, "//select[@id='select_register_case_cd']/option[@value='2']").click()

        driver.find_element(By.XPATH, '//*[@id="content-right"]/div/div[3]/div/div/button').click()


if __name__ == '__main__':
    unittest.main()
