import unittest

from selenium.webdriver.common.by import By
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.utils import get_web_driver
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.config_user_constants import AURORA_INTERNAL_USER

class MsgDashboardPageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='sichoon.kwon')
    def test_msg_dashboard_shown(self):
        driver = self.driver

        driver.find_element(By.ID, "msg_add_form").click()

        region_text = driver.find_element(By.XPATH, "//label[@for=\"id_service_area_5\"]").text.strip()
        self.assertEqual(region_text, "UK")

if __name__=='__main__':
    unittest.main()
