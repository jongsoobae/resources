import unittest2 as unittest
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait

from selenium_test.config_user_constants import AURORA_CUSTOMER_USER
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver
from selenium.webdriver.support import expected_conditions as EC


DATE_HAS_DATA = '2015-07-16'
DATE_HAS_NO_DATA = '2014-07-16'


class CapturingPageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_CUSTOMER_USER['aqua_player_customer'])

    def tearDown(self):
        self.driver.quit()

    def test_given_user_has_capturing_privilege_when_click_capturing_statistic_button_then_should_be_shown(self):
        driver = self.driver
        ###########################################################################################################
        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//span[text() = 'Media Acceleration - HTTP']"))
        )

        # Expand 'Media Acceleration - HTTP' menu
        driver.find_element(By.XPATH, "//span[text() = 'Media Acceleration - HTTP']").click()

        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//a[contains(@href, '/aqua/player/capturing')]"))
        )

        # Go to Capturing Page
        driver.find_element(By.XPATH, "//a[contains(@href, '/aqua/player/capturing')]").click()

        # Wait until capturing list page is loaded
        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//table[@ng-show='capturing_list_loaded']"))
        )

        # Wait until the capturing statistics button is shown
        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//button[@ng-click='showCapturingStatistics()']"))
        )

        # Find date input for search
        date_input = driver.find_element(By.XPATH, "//input[@ng-model='capturing.search_params.date']")

        # Set the date which has capturing statistics data
        date_input.clear()
        date_input.send_keys(DATE_HAS_DATA)
        date_input.send_keys(Keys.TAB)

        self.validate_domains_and_count_values(driver)

        # Wait until the capturing statistics button is clickable
        WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//button[@ng-click='showCapturingStatistics()']"))
        )

        # Set the date which has no capturing statistics data
        date_input.clear()
        date_input.send_keys(DATE_HAS_NO_DATA)
        date_input.send_keys(Keys.TAB)

        self.validate_domains_and_count_values(driver)

    def validate_domains_and_count_values(self, driver):
        # Click the capturing statistics button
        driver.find_element(By.XPATH, "//button[@ng-click='showCapturingStatistics()']").click()

        # Wait until the capturing statistics button is shown
        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//div[@ng-show='capturing_statistics_loaded']//table"))
        )

        # Get domain list of capturing statistics table
        table_rows_except_total = \
            driver.find_elements(By.XPATH,
                                 "//div[@ng-show='capturing_statistics_loaded']//table//tbody//tr//td[1][not(contains(text(), 'Total'))]")

        service_domains = []
        for row in table_rows_except_total:
            service_domains.append(row.text)

        # Get domain list of capturing statistics table
        service_domain_options = driver.find_elements(By.XPATH, "//select[@ng-model='capturing.search_params.service_name']//option")

        service_domain_list = []
        for option in service_domain_options:
            service_domain_list.append(option.text)

        # Check domains on capturing statistics table are same with domains on service domain select
        self.assertEqual(service_domain_list, service_domains)

        # Get total count of all domains
        total_count_value = \
            int(driver.find_element(By.XPATH,
                                    "//div[@ng-show='capturing_statistics_loaded']//table//tbody//tr[last()]//td[2]").text)

        # Get count list of each domains
        count_value_list = \
            driver.find_elements(By.XPATH,
                                 "//div[@ng-show='capturing_statistics_loaded']//table//tbody//tr[position() < last()]//td[2]")

        # Calculate total count by summing each domains
        calculated_total_by_count_value_list = 0
        for value in count_value_list:
            calculated_total_by_count_value_list += int(value.text)

        # Check calculated total count is same with total value
        self.assertEqual(total_count_value, calculated_total_by_count_value_list)

        # Close modal
        modal_close_btn = driver.find_element(By.XPATH, "//button[@data-dismiss='modal' and @class='aurora_btn btn btn-default']")
        modal_close_btn.click()

        # Wait until the capturing statistics modal is disappeared
        WebDriverWait(driver, 30).until(
            EC.invisibility_of_element_located((By.XPATH, "//div[@ng-show='capturing_statistics_loaded']"))
        )


