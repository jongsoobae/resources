import requests
import json
from selenium_test.config_user_constants import AURORA_CUSTOMER_USER
from selenium_test.config_constants import AURORA_API_URL
from selenium_test.config_user_constants import PRISM_API_USER
from selenium_test.config_constants import PRISM_API_URL

def get_prism_credential():
    return "user=%s&pass=%s" % (PRISM_API_USER.get('username'), PRISM_API_USER.get('password'))

def get_token(prism_url, username, password):
    """
    get encrypted token using prism api
    this call replaces open api's encrypt function
    :param prism_url:
    :param username:
    :param password:
    :return:
    """
    uri = "help/encrypt"
    prism_url = "%s/%s?%s" % (prism_url, uri, get_prism_credential())
    token = "apiID=apiUserID;apiPWD=apiUserPWD;username=%s;password=%s;" % (username, password)
    parameters = {'token':token}
    print prism_url
    response = requests.post(prism_url, data=parameters)
    print response._content
    data = json.loads(response._content)
    return data.get('result')

def reset_zone_deploy_status(zone_id):
    uri = 'dns/zone/reset_status'
    prism_url = "%s/%s?%s" % (PRISM_API_URL, uri, get_prism_credential())
    parameters = {'zone_id':zone_id}
    print prism_url
    response = requests.post(prism_url, data=parameters)
    print response._content
    return response

def reset_user_push_threshold(username):
    uri = 'customer/user/reset_push_threshold'
    prism_url = "%s/%s?%s" % (PRISM_API_URL, uri, get_prism_credential())
    parameters = {'username':username}
    print prism_url
    response = requests.post(prism_url, data=parameters)
    print response._content
    return response


class APIManager(object):
    def __init__(self, api_key, control_group, username=None, password=None):
        try:
            self.control_group_name = control_group
            self.control_group_id = int(control_group)
        except:
            self.control_group_id = None
            self.control_group_name = control_group
        self.api_key_name = api_key
        self.url = AURORA_API_URL
        self.username = username if username else AURORA_CUSTOMER_USER.get('default').get('username')
        self.password = password if password else AURORA_CUSTOMER_USER.get('default').get('password')

        self.prism_url = PRISM_API_URL
        self.prism_credential = get_prism_credential()
        self.encrypted_token = get_token(self.prism_url, self.username, self.password)
        def get_user_info(url, encrypted_token):
            uri = "rest/stat/getUserInfo"
            url = "%s/%s" % (url, uri)
            parameters = {'encData': encrypted_token}
            print url
            response = requests.get(url, params=parameters)
            print response._content
            data = json.loads(response._content)
            return data
        user_infos = get_user_info(AURORA_API_URL, self.encrypted_token)
        self.user_info = user_infos.get('userInfo')
        self.customer_infos = user_infos.get('customInfo')

        def get_api_key_list():
            uri = "rest/stat/getApiKeyList"
            url = "%s/%s" % (self.url, uri)

            for customer_info in self.customer_infos:
                control_group_id = customer_info.get('customKey')
                control_group_name = customer_info.get('customName')
                self.control_group_type = customer_info.get('customType')
                self.account_no = customer_info.get('customAccountKey')
                if control_group_id == self.control_group_id or control_group_name == self.control_group_name:
                    self.control_group_id = control_group_id
                    self.control_group_name = control_group_name
                    break
            parameters = {'encData':self.encrypted_token,
                          'cgId': self.control_group_id,
                          'gmtCd': self.user_info.get('gmtCd'),
                          'cgType': self.control_group_type,
                          'account_no': self.account_no}
            response = requests.get(url, params=parameters)
            data = json.loads(response._content)
            return data
        self.api_key_list = get_api_key_list()


    def _get_default_parameters(self, params):
        parameters = {'encData':self.encrypted_token,
                      'apiKey':self.api_key_name,
                      'cgId': self.control_group_id,
                      'gmtCd': self.user_info.get('gmtCd'),
                      'cgType': self.control_group_type,
                      'account_no': self.account_no}
        if params is not None:
            for k,v in params.iteritems():
                try:
                    parameters.update({k:v})
                except:
                    pass
        return parameters

    def request(self,uri, params):
        """
        wrap request library. build url and parameters
        :param uri: uri path
        :param params: additional parameters
        :return:
        """
        url = "%s/%s" % (self.url, uri)
        parameters = self._get_default_parameters(params)
        print url, parameters
        response = requests.get(url, params=parameters)
        print response._content
        return response

    def edit_dns_zone(self, zone_id, params):
        uri='rest/config/cdns/v1/domains/%s/edit/' % zone_id
        response2 = self.request(uri, params)
        return response2

    def deploy_dns_zone(self, zone_id, params):
        uri='rest/config/cdns/v1/domains/%s/deploy/' % zone_id
        response2 = self.request(uri, params)
        return response2