import unittest
import requests
from selenium_test.config_user_constants import AURORA_API_USER
from selenium_test.shared_components.conf import settings
from selenium_test.shared_components.decorators import catch_exception


class TestConfig(unittest.TestCase):

    def setUp(self):
        self.url = settings.AURORA_API_URL
        self.credential = "username=%s&password=%s" % (AURORA_API_USER.get('username'), AURORA_API_USER.get('password'))

    @catch_exception(author='mi.jun')
    def test_customer_edit_account(self):
        uri = "rest/account/customer/edit/account/"
        parameters = "from_account_no=45674&to_account_no=25002&from_customer_id=3844&to_customer_id=3905"
        self.url = "%s/%s?%s&%s" % (self.url, uri, self.credential, parameters)
        parameters = {}
        response = requests.get(self.url, params=parameters)
        assert 'Success' in response._content
        
        self.cleanup_customer_edit_account()
        
    #clean up    
    def cleanup_customer_edit_account(self):
        uri = "rest/account/customer/edit/account/"
        parameters = "from_account_no=25002&to_account_no=45674&from_customer_id=3905&to_customer_id=3844"
        self.url = "%s/%s?%s&%s" % (self.url, uri, self.credential, parameters)
        parameters = {}
        response = requests.get(self.url, params=parameters)
        assert 'Success' in response._content    

if __name__ == "__main__":
    unittest.main()
