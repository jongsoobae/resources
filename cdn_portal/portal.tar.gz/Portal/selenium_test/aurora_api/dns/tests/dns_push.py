import unittest
import requests
import json
from selenium_test.aurora_api import APIManager, reset_zone_deploy_status, reset_user_push_threshold

class TestDNSPush(unittest.TestCase):

    def setUp(self):
        api_key = 'SERVICECATEGORY_DNS'
        #control_group = 1037 #CDNetworks Product Management
        control_group = 'CDNetworks Product Management'
        self.username = 'dns_demo_test_master@cdn.com'
        self.api_manager = APIManager(api_key, control_group, self.username, 'test!@dmin')

    def build_pad_params(self,params):
        param_list = []
        if params is not None:
            for k,v in params.iteritems():
                try:
                    param_list.append("%s=%s" % (k,v))
                except:
                    pass
        return "&".join(param_list)

    def test_deploy_dns_config(self):
        params = {}
        zone_id = 11289
        reset_zone_deploy_status(zone_id)
        reset_user_push_threshold(self.username)
        #response = self.api_manager.edit_dns_zone(zone_id, {'TTL':60})
        response2 = self.api_manager.deploy_dns_zone(zone_id, params)

        reset_zone_deploy_status(zone_id)
        response2 = self.api_manager.deploy_dns_zone(zone_id, params)
        assert 'You have reached push rate limitation' in response2._content
        #{"msg": "You have reached push rate limitation. Threshold: 1/60 minute. Please try again sometime later.", "factor": "not_permitted"}


if __name__ == "__main__":
    unittest.main()

