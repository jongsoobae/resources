import unittest
import json
from selenium_test.aurora_api import APIManager

class TestContractInfo(unittest.TestCase):

    def setUp(self):
        CS_API_KEY_NAME = 'SERVICECATEGORY_CA'
        CS_API_KEY_NAME = 'SERVICECATEGORY_AC'
        control_group_id = 4978 #auction ebay
        self.api_manager = APIManager(CS_API_KEY_NAME, control_group_id)

    def list_contract(self):
        uri = "rest/pan/config/contract/list"
        parameters = {}
        response = self.api_manager.request(uri, parameters)
        return response

    def get_contract_info(self, contract_no):
        uri = "rest/pan/config/contract/%s/view" % contract_no
        parameters = {}
        response = self.api_manager.request(uri, parameters)
        return response

    def get_contract_shields(self, contract_no):
        uri = "rest/pan/config/contract/%s/shields" % contract_no
        parameters = {}
        response = self.api_manager.request(uri, parameters)
        return response

    def test_contract_info(self):
        response = self.list_contract()
        print response._content
        assert '200' in response._content
        contract_no = json.loads(response._content).get('data').get('data')[0].get('contract_no')
        response2 = self.get_contract_info(contract_no)
        print response2._content
        assert '200' in response2._content
        response3 = self.get_contract_shields(contract_no)
        print response3._content
        assert '200' in response3._content

if __name__ == "__main__":
    unittest.main()
