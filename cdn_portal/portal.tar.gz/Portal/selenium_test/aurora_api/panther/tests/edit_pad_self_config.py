import unittest
import requests
import json
from selenium_test.aurora_api import APIManager

class TestPADSelfConfigEdit(unittest.TestCase):

    def setUp(self):
        CS_API_KEY_NAME = 'SERVICECATEGORY_CA'
        control_group_id = 4978 #7175 #ebay
        self.api_manager = APIManager(CS_API_KEY_NAME, control_group_id)

    def build_pad_params(self,params):
        param_list = []
        if params is not None:
            for k,v in params.iteritems():
                try:
                    param_list.append("%s=%s" % (k,v))
                except:
                    pass
        return "&".join(param_list)

    def get_pad_config(self, pad_name):
        uri = "rest/pan/config/site/view"
        parameters = {'pad': pad_name}
        response = self.api_manager.request(uri, parameters)
        return response

    def edit_pad_config(self, pad_info):
        #parameters = {'padParam': self.build_pad_params(pad_info)}
        #parameters = {'padParam': pad_info}
        print json.dumps(pad_info)
        uri = "rest/pan/config/site/edit"
        response = self.api_manager.request(uri,pad_info)
        return response



    def test_edit_panther_dwa_pad_self_config(self):
        pad_name= 'r2.cdn.com' #dwa self implementable
        #pad_name= 'in.test.com' #ca self implementable
        response = self.get_pad_config(pad_name)
        pad_info = json.loads(response._content).get('data').get('data')
        print response._content
        print json.dumps(pad_info)
        assert '200' in response._content

        pad_info={'pad':pad_name, 'padParam': self.build_pad_params(pad_info)}
        response2 = self.edit_pad_config(pad_info)
        print response2._content
        assert '200a' in response2._content

"""
    def test_edit_panther_ca_pad_self_config(self):
        pad_name= 'in.test.com' #ca self implementable
        response = self.get_pad_config(pad_name)
        pad_info = json.loads(response._content).get('data').get('data')
        print response._content
        print json.dumps(pad_info)
        assert '200' in response._content

        pad_info={'pad':pad_name, 'padParam': self.build_pad_params(pad_info)}
        response2 = self.edit_pad_config(pad_info)
        print response2._content
        assert '200a' in response2._content
"""

if __name__ == "__main__":
    unittest.main()

