import unittest
import requests
import json
from selenium_test.aurora_api import APIManager

class TestPADConfigAdd(unittest.TestCase):

    def setUp(self):
        CS_API_KEY_NAME = 'SERVICECATEGORY_CA'
        control_group_id = 4978 #7175 #ebay
        self.api_manager = APIManager(CS_API_KEY_NAME, control_group_id)

    def build_pad_params(self,params):
        param_list = []
        if params is not None:
            for k,v in params.iteritems():
                try:
                    param_list.append("%s=%s" % (k,v))
                except:
                    pass
        return "&".join(param_list)

    def get_pad_config(self, pad_name):
        uri = "rest/pan/config/site/view"
        parameters = {'pad': pad_name}
        response = self.api_manager.request(uri, parameters)
        return response

    def add_pad_config(self, pad_name, origin_name):
        pad_parameters = {'origin': origin_name,
                          'pad': pad_name}
        parameters = {'padParam': self.build_pad_params(pad_parameters)}
        response = self.api_manager.request("rest/pan/config/site/add", parameters)
        return response

    def add_pad_config_with_product(self, pad_name, origin_name,contract_no):
        pad_parameters = {'origin': origin_name,
                          'pad': pad_name,
                          'product': contract_no,
                          'shielded_service': ''} #optional
        parameters = {'padParam': self.build_pad_params(pad_parameters)}
        response = self.api_manager.request("rest/pan/config/site/add", parameters)
        return response

    def add_pad_config_with_product_and_shield(self,pad_name, origin_name,contract_no):
        pad_parameters = {'pad':pad_name,
                            'origin': origin_name,
                            'product': contract_no,
                          #'shielded_service': '13',
                          'shield_location': '14'} #optional
        parameters = {'padParam': self.build_pad_params(pad_parameters)}
        response = self.api_manager.request("rest/pan/config/site/add", parameters)
        return response


    def test_add_panther_pad_config(self):
        origin_name = 'ktest106.foo2.com'
        pad_name= 'ktest106.bar2.com'
        contract_no = '0040008732-000030' #ca request implementation
        contract_no = '0040006594-000011' #ca ssl self implentable
        contract_no = '0040005613-000010' #dwa request implementation
        contract_no = '0040007321-000100' #dwa self implementable contract
        #response2 = self.get_pad_config(pad_name)
        #result_pad_name = json.loads(response2._content).get('data').get('data').get('origin')
        #print response2._content
        #print result_pad_name
        #assert '200' in response2._content

        #response = self.add_pad_config(pad_name,origin_name)
        #response = self.add_pad_config_with_product(pad_name,origin_name,contract_no)
        response = self.add_pad_config_with_product_and_shield(pad_name,origin_name,contract_no)
        print response._content
        assert '200' in response._content



        #response4 = self.push_to_staging_pad_config(pad_name)
        #assert '200' in response4._content

        #response5 = self.get_push_status_pad_config(pad_name)
        #assert '200' in response5._content

        #response6 = self.push_to_production_pad_config(pad_name)
        #assert '200' in response6._content

if __name__ == "__main__":
    unittest.main()
