import unittest
import requests
import json
from selenium_test.aurora_api import APIManager

class TestPADConfigView(unittest.TestCase):

    def setUp(self):
        CS_API_KEY_NAME = 'SERVICECATEGORY_CA'
        control_group_id = 4978 #7175 #ebay
        self.api_manager = APIManager(CS_API_KEY_NAME, control_group_id)

    def build_pad_params(self,params):
        param_list = []
        if params is not None:
            for k,v in params.iteritems():
                try:
                    param_list.append("%s=%s" % (k,v))
                except:
                    pass
        return "&".join(param_list)

    def get_pad_config(self, pad_name):
        uri = "rest/pan/config/site/view"
        parameters = {'pad': pad_name}
        response = self.api_manager.request(uri, parameters)
        return response

    def push_to_staging_pad_config(self,pad_name):
        uri = "rest/pan/config/site/push/%s/staging" % (pad_name)
        parameters = {'pad': pad_name}
        response = self.api_manager.request(uri, parameters)
        return response

    def push_to_production_pad_config(self,pad_name):
        uri = "rest/pan/config/site/push/%s/production" % (pad_name)
        parameters = {'pad': pad_name}
        response = self.api_manager.request(uri, parameters)
        return response

    def get_push_status_pad_config(self,pad_name):
        uri = "rest/pan/config/site/push/%s/status" % (pad_name)
        parameters = {'pad': pad_name}
        response = self.api_manager.request(uri, parameters)
        return response

    def get_panther_pad_push_history(self, pad_name):
        uri = "rest/pan/config/site/push/%s/history" % (pad_name)
        parameters = {}
        response = self.api_manager.request(uri, parameters)
        return response

    def list_pad_config(self):
        uri = "rest/pan/config/site/list"
        parameters = {'padParam':'info=1'}
        response = self.api_manager.request(uri, parameters)
        return response


    def test_list_panther_pad_config(self):
        response = self.list_pad_config()

        print response._content
        assert '200' in response._content
        pad_name = json.loads(response._content).get('data').get('data')[1].get('pad')
        response2 = self.get_pad_config(pad_name)
        assert '200' in response2._content
        print response2._content
        response3 = self.get_panther_pad_push_history(pad_name)
        assert '200' in response3._content
        print response3._content
        assert '1ddaadw' in response
        #response4 = self.push_to_staging_pad_config(pad_name)
        #assert '200' in response4._content

        #response5 = self.get_push_status_pad_config(pad_name)
        #assert '200' in response5._content

        #response6 = self.push_to_production_pad_config(pad_name)
        #assert '200' in response6._content

if __name__ == "__main__":
    unittest.main()
