import unittest
import requests
import json
from selenium_test.aurora_api import APIManager

class TestPADConfigPush(unittest.TestCase):

    def setUp(self):
        CS_API_KEY_NAME = 'SERVICECATEGORY_CA'
        control_group_id = 4978 #7175 #ebay
        self.api_manager = APIManager(CS_API_KEY_NAME, control_group_id)

    def build_pad_params(self,params):
        param_list = []
        if params is not None:
            for k,v in params.iteritems():
                try:
                    param_list.append("%s=%s" % (k,v))
                except:
                    pass
        return "&".join(param_list)

    def push_to_staging_pad_config(self,pad_name):
        uri = "rest/pan/config/site/push/%s/staging" % (pad_name)
        parameters = {'pad': pad_name}
        response = self.api_manager.request(uri, parameters)
        return response

    def push_to_production_pad_config(self,pad_name):
        uri = "rest/pan/config/site/push/%s/production" % (pad_name)
        parameters = {'pad': pad_name}
        response = self.api_manager.request(uri, parameters)
        return response

    def get_push_status_pad_config(self,pad_name):
        uri = "rest/pan/config/site/push/%s/status" % (pad_name)
        parameters = {'pad': pad_name}
        response = self.api_manager.request(uri, parameters)
        return response

    def get_panther_pad_push_history(self, pad_name):
        uri = "rest/pan/config/site/push/%s/history" % (pad_name)
        parameters = {}
        response = self.api_manager.request(uri, parameters)
        return response


    def test_panther_pad_config_push_history(self):
        pad_name = 'ktest.bar2.com'
        response = self.get_panther_pad_push_history(pad_name)
        print response._content
        assert '200' in response._content

        response2 = self.push_to_production_pad_config(pad_name)
        print response2._content
        assert '200' in response2._content


if __name__ == "__main__":
    unittest.main()
