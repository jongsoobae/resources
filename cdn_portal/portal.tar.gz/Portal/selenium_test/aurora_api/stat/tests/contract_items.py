import unittest
from selenium_test.aurora_api import APIManager

class TestContractInfo(unittest.TestCase):

    def setUp(self):
        CS_API_KEY_NAME = 'SERVICECATEGORY_CA'
        control_group_id = 7175 #ebay
        self.api_manager = APIManager(CS_API_KEY_NAME, control_group_id)

    def list_panther_pad_contract(self):
        uri = "rest/stat/contractItems"
        parameters = {}
        response = self.api_manager.request(uri, parameters)
        return response

    def test_list_panther_pad_contract(self):
        response = self.list_panther_pad_contract()
        assert 'Success' in response._content

if __name__ == "__main__":
    unittest.main()
