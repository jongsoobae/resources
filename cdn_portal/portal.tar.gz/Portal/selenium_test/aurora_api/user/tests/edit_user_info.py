import unittest
from selenium_test.aurora_api import APIManager

class TestEditUser(unittest.TestCase):

    def setUp(self):
        CS_API_KEY_NAME = 'SERVICECATEGORY_CA'
        control_group_id = 7175 #ebay
        self.api_manager = APIManager(CS_API_KEY_NAME, control_group_id)

    def test_get_api_key_list(self):
        assert "Success" in self.api_manager.api_key_list.get('returnMsg')

if __name__ == "__main__":
    unittest.main()
