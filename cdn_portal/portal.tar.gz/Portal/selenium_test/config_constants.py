import os

# If config file is exists on this path, config is going to apply this setting's value.
CONFIG_FILE_PATH = os.environ.get('SELENIUM_TEST_CFG_PATH', '')

EMAIL_HOST = 'send.mx.cdnetworks.com'
EMAIL_PORT = 25
ADMIN_MAIL_ADDRESS = 'portaladmin@cdnetworks.com'
PORTAL_TEAM_MAIL_ADDRESS = 'CDN10001032@cdnetworks.com'

AURORA_FE_URL = 'https://openstack-adminportal.cdnetworks.com'
PRISM_FE_URL = 'https://openstack-prism.cdnetworks.com'
PRISM_API_URL = 'http://openstack-prismapi.cdnetworks.com'
AURORA_API_URL = 'http://openstack-auroraapi.cdnetworks.com'
OPEN_API_URL = 'http://openstack-openapi.cdnetworks.com/api'

CI_SERVER_HOSTNAME = 'ci-slave-portal-ngpos-1'
SELENIUM_REMOTE_SERVER_IP = '10.192.234.217'
SELENIUM_REMOTE_SERVER_PORT = '4444'
NO_SCREENSHOT = True

IMPLICITLY_WAIT = 10  # Second
USE_REMOTE_SELENIUM_SERVER = False
BLOCK_URL_LIST = (
    'https://control.cdnetworks.com',
    'https://prism.cdnetworks.com',
)

# -------------------------------------------------------------------------------------------------
# The following settings are for 'SepctrumAPIManager'.
# -------------------------------------------------------------------------------------------------
DEBUG = True
API_LOCAL_MODE = False
PROJECT_NAME = 'prism_fe'

SPECTRUMAPI_SERVER_URI = "http://10.40.196.179:8087/api"  # 10.40.207.110 for Aurora 2.7 test
AUTH_SPECTRUMAPI_APPLICATION_USER = "aurorauser"
AUTH_SPECTRUMAPI_APPLICATION_PASSWORD = "cdn!@admin"
AUTH_SPECTRUMAPI_TIMEOUT = 120
END_USER_EMAIL = 'injune.hwang@cdnetworks.com'
# -------------------------------------------------------------------------------------------------


