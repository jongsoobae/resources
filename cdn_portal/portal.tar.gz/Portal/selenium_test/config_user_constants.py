import os

AURORA_INTERNAL_USER = {
    'username': os.environ.get('AURORA_INTERNAL_USER_NAME', ''),
    'password': os.environ.get('AURORA_INTERNAL_USER_PASS', '')
}
AURORA_CUSTOMER_USER = {
    'default': {
        'username': os.environ.get('AURORA_CUSTOMER_DEFAULT_USER_NAME', 'adminportal@ksm.com'),
        'password': os.environ.get('AURORA_CUSTOMER_DEFAULT_USER_PASS', 'qw12!@!@')
    },
    'sla_report_granted_user': {
        'username': os.environ.get('AURORA_SLA_REPORT_GRANTED_CUSTOMER_USERNAME', 'selenium-testdriver-01@cdnetworks.com'),
        'password': os.environ.get('AURORA_SLA_REPORT_GRANTED_CUSTOMER_PASSWORD', 'qw12!@!@')
    },
    'not_customer_admin': {
        'username': 'selenium_tester001@cdnetworks.com',
        'password': 'qw12!@!@'
    },
    'clb_customer': {
        'username': os.environ.get('AURORA_CUSTOMER_CLB_USER_NAME', 'test_clb_customer@aurora.cdn.com'),
        'password': os.environ.get('AURORA_CUSTOMER_CLB_USER_PASS', 'qw12!@!@')
    },
    'dns_customer': {
        'username': os.environ.get('AURORA_CUSTOMER_CLB_USER_NAME', 'test_clb_customer@aurora.cdn.com'),
        'password': os.environ.get('AURORA_CUSTOMER_CLB_USER_PASS', 'qw12!@!@')
    },
    'has_documentation_privilege': {
        'username': 'selenium_doc_priv@cdnetworks.com',
        'password': 'qw12!@!@'
     },
    'has_edge_block_ip_and_documentation_privilege': {
        'username': 'selenium_edge_block_ip_and_doc_priv@cdnetworks.com',
        'password': 'qw12!@!@'
     },
    'customer_who_has_modifiable_lds_conf': {
        'username': 'ssilva@squiz.co.uk',
        'password': 'qw12!@!@'
    },
    'migrated_customer_user': {
        'username': '32red-selenium-testdriver-04@cdnetworks.com',
        'password': 'qw12!@!@'
    },
    'ngp_customer_user': {
        'username': 'selenium-testdriver-01@cdnetworks.com',
        'password': 'qw12!@!@'
    },
    'email_report_test_user': {
        'username': os.environ.get('AURORA_EMAIL_REPORT_TEST_USER_NAME', '32red-selenium-testdriver-04@cdnetworks.com'),
        'password': os.environ.get('AURORA_EMAIL_REPORT_TEST_USER_NAME', 'qw12!@!@')
    },
    'cloud_storage_customer_user': {
        'username': '88bro-selenium-testdriver-02@cdnetworks.com',
        'password': 'qw12!@!@'
    },
    'user_has_completion_ratio': {
        'username': 'nhnent-selenium-testdriver-01@cdnetworks.com',
        'password': 'qw12!@!@'
    },
    'customer_admin': {
        'username': os.environ.get('AURORA_CUSTOMER_DEFAULT_USER_NAME', 'selenium_customer_admin@cdnetworks.com'),
        'password': os.environ.get('AURORA_CUSTOMER_DEFAULT_USER_PASS', 'qw12!@!@')
    },
    'not_customer_admin': {
        'username': 'selenium_tester@cdnetworks.com',
        'password': 'qw12!@!@'
    },
    'edge_hits_with_ic': {
        'username': 'selenium_edge_hits_with_ic01@test.com',
        'password': 'qw12!@!@'
    },
    'cloud_dns': {
        'username': os.environ.get('AURORA_CUSTOMER_DEFAULT_USER_NAME', 'cdns_testuser_refluence@selenium.com'),
        'password': os.environ.get('AURORA_CUSTOMER_DEFAULT_USER_PASS', 'qw12!@!@')
    },
    'aqua_player_customer': {
        'username': 'selenium_aqua_player_tester@test.com',
        'password': 'selenium'
    },
    'cloud_security_documentation': {
        'username': 'seungjeha@giordano.co.kr',
        'password': '!'
    },
    'dns_clb_customer_user': {
        'username': 'selenium_dns_clb_domain_tester@cdnetworks.com',
        'password': 'qw12!@!@'
    }
}

PRISM_INTERNAL_USER = {
    'username': os.environ.get('PRISM_INTERNAL_USER_NAME', 'seonmi.kim'),
    'password': os.environ.get('PRISM_INTERNAL_USER_PASS', '9660skdisk!@#$')
}

PRISM_API_USER = {
    'username': os.environ.get('PRISM_API_USER_NAME', ''),
    'password': os.environ.get('PRISM_API_USER_PASS', '')
}

AURORA_API_USER = {
    'username': os.environ.get('AURORA_API_USER_NAME', 'cop_to_aurora@cdnetworks.com'),
    'password': os.environ.get('AURORA_API_USER_PASS', 'auroraapi@cdnadmin')
}

AURORA_CUSTOMER_ADMIN_USER = {
    'clb_customer_admin': {
        'username': os.environ.get('AURORA_CUSTOMER_ADMIN_CLB_USER_NAME', 'test_clb_customer_admin@aurora.cdn.com'),
        'password': os.environ.get('AURORA_CUSTOMER_ADMIN_CLB_USER_PASS', 'qw12!@!@')
    }
}
OPENAPI_CUSTOMER_USER = {
    'username': 'hwaeun.seo@cdnetworks.com',
    'password': '@qwer1234'
}
