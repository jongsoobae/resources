import time
from datetime import datetime
from selenium.webdriver.common.by import By


def check_search_limit(tdd, driver, txt_date_id):
    txt_date_from = driver.find_element(By.ID, txt_date_id)
    txt_date_from.click()

    year_options_in_calendar = driver.find_elements(By.CSS_SELECTOR, "select.ui-datepicker-year > option")

    tdd.assertEqual(len(year_options_in_calendar), 2)

    current_year = datetime.now().year

    tdd.assertEqual(current_year - 1, int(year_options_in_calendar[0].text))
    tdd.assertEqual(current_year, int(year_options_in_calendar[1].text))

    btn_next_in_calendar = driver.find_element(By.XPATH, '//*[@id="ui-datepicker-div"]/div/a[2]')
    tdd.assertTrue('ui-state-disabled' in btn_next_in_calendar.get_attribute('class'))

    btn_prev_in_calendar = driver.find_element(By.XPATH, '//*[@id="ui-datepicker-div"]/div/a[1]')
    tdd.assertFalse('ui-state-disabled' in btn_prev_in_calendar.get_attribute('class'))

    for month in range((datetime.now().month - 1) + 12):
        btn_prev_in_calendar = driver.find_element(By.XPATH, '//*[@id="ui-datepicker-div"]/div/a[1]')
        btn_prev_in_calendar.click()

    btn_prev_in_calendar = driver.find_element(By.XPATH, '//*[@id="ui-datepicker-div"]/div/a[1]')
    tdd.assertTrue('ui-state-disabled' in btn_prev_in_calendar.get_attribute('class'))


def check_search_duration(tdd, driver, duration_warn_msg, max_num):
    btn_custom_date = driver.find_element(By.XPATH, "//button[@data-value='specified']")
    btn_custom_date.click()

    txt_date_from = driver.find_element(By.ID, 'id_date_from')
    txt_date_from.click()

    for month in range(0, max_num):
        btn_prev_in_calendar = driver.find_element(By.XPATH, '//*[@id="ui-datepicker-div"]/div/a[1]')
        btn_prev_in_calendar.click()

    ele_day = driver.find_element(By.XPATH, '//*[@id="ui-datepicker-div"]/table/tbody/tr[2]/td[1]/a')
    ele_day.click()

    time.sleep(1)

    btn_view = driver.find_element(By.ID, 'btn_view')
    btn_view.click()

    time.sleep(1)

    warning_msg = driver.find_element(By.ID, 'filter_wb')
    tdd.assertEqual(duration_warn_msg, warning_msg.text)


def assert_duration_of_year_on_calendar(selenium_test):
    driver = selenium_test.driver

    btn_view_report = driver.find_element(By.ID, 'btn_filter_charts')
    btn_view_report.click()

    btn_user_specified = driver.find_element(By.CSS_SELECTOR, '#date_selection > a.last')
    btn_user_specified.click()

    date_to = driver.find_element(By.ID, 'id_date_from')
    date_to.click()

    btn_cal_next = driver.find_element(By.ID, 'calnext')
    selenium_test.assertEqual(btn_cal_next.get_attribute('class'), 'caldisabled')

    btn_cal_prev = driver.find_element(By.ID, 'calprev')
    selenium_test.assertEqual(btn_cal_prev.get_attribute('class'), '')

    for month in range((datetime.now().month - 1) + 12):
        btn_cal_prev.click()

    selenium_test.assertEqual(btn_cal_prev.get_attribute('class'), 'caldisabled')

    date_to = driver.find_element(By.ID, 'id_date_to')
    date_to.click()

    btn_cal_next = driver.find_element(By.ID, 'calnext')
    selenium_test.assertEqual(btn_cal_next.get_attribute('class'), 'caldisabled')

    btn_cal_prev = driver.find_element(By.ID, 'calprev')
    selenium_test.assertEqual(btn_cal_prev.get_attribute('class'), 'caldisabled')


# [AURORAUI-3213]
# type_a is 'Overall Traffic' and 'By Record Types'
def assert_available_reporting_duration_type_a(unittest, type, id_btn_report):
    driver = unittest.driver

    driver.find_element(By.XPATH, "//a[@data-value='%s']" % type).click()
    driver.find_element(By.ID, id_btn_report).click()

    btn_user_specified = driver.find_element(By.CSS_SELECTOR, '#date_selection > a.last')
    btn_user_specified.click()

    date_from = driver.find_element(By.ID, 'id_date_from')
    date_from.click()

    btn_cal_prev = driver.find_element(By.ID, 'calprev')
    for month in range(4):
        btn_cal_prev.click()

    driver.find_element(By.XPATH, '//*[@id="calweeks"]/div[2]/a[1]').click()

    driver.find_element(By.ID, 'btn_view').click()

    unittest.assertEqual(driver.find_element(By.ID, 'filter_wb').text, 'Report cannot be generated more than 3 months.')

    date_from = driver.find_element(By.ID, 'id_date_from')
    date_from.click()

    btn_cal_next = driver.find_element(By.ID, 'calnext')
    for month in range(2):
        btn_cal_next.click()

    driver.find_element(By.XPATH, '//*[@id="calweeks"]/div[2]/a[1]').click()

    driver.find_element(By.ID, 'btn_view').click()

    time.sleep(1)

    unittest.assertFalse(driver.find_element(By.ID, 'filter_wb').text)


# [AURORAUI-3213]
# type_a is 'locations' and 'By  CLB Domains'
def assert_available_reporting_duration_type_b(unittest, type, id_btn_report):
    driver = unittest.driver

    driver.find_element(By.XPATH, "//a[@data-value='%s']" % type).click()
    driver.find_element(By.ID, id_btn_report).click()

    btn_user_specified = driver.find_element(By.CSS_SELECTOR, '#date_selection > a.last')
    btn_user_specified.click()

    driver.find_element(By.ID, 'btn_view').click()

    unittest.assertFalse(driver.find_element(By.ID, 'filter_wb').text)

    driver.find_element(By.ID, id_btn_report).click()

    date_from = driver.find_element(By.ID, 'id_date_from')
    date_from.click()

    btn_cal_prev = driver.find_element(By.ID, 'calprev')
    for month in range(2):
        btn_cal_prev.click()

    driver.find_element(By.XPATH, '//*[@id="calweeks"]/div[2]/a[1]').click()

    driver.find_element(By.ID, 'btn_view').click()

    unittest.assertEqual(driver.find_element(By.ID, 'filter_wb').text, 'Reports cannot be generated more than 32 days.')

