# [AURORAUI-3167]
import unittest
from datetime import datetime
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

from selenium_test.config_constants import AURORA_FE_URL
from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.cs_reports.test_common_utils.assert_duration import check_search_limit, check_search_duration
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver


class DashboardReportingParametersConstraintsTest(unittest.TestCase):
    URL = '%s/cs/dashboard/?m=320'
    CUSTOMER = None
    DURATION_WARN = 'Report cannot be generated more than 3 months.'
    ID_CUSTOMER_SELECTOR = 'id_filter_account_chosen'

    def setUp(self):
        self.driver = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

        self._setUpEx()

    def _setUpEx(self):
        driver = self.driver
        driver.get(self.URL % AURORA_FE_URL)

        if self.CUSTOMER:
            driver.find_element(By.ID, self.ID_CUSTOMER_SELECTOR).click()
            input_customer = driver.find_element(By.CSS_SELECTOR,
                                                 ('#%s > div > div > input[type="text"]' % self.ID_CUSTOMER_SELECTOR))

            input_customer.send_keys(self.CUSTOMER)
            input_customer.send_keys(Keys.RETURN)

            time.sleep(1)

    def tearDown(self):
        self.driver.close()

    def test_available_years(self):
        driver = self.driver

        btn_custom_date = driver.find_element(By.XPATH, "//button[@data-value='specified']")
        btn_custom_date.click()

        check_search_limit(self, driver, 'id_date_from')
        check_search_limit(self, driver, 'id_date_to')

    def test_available_month(self):
        check_search_duration(self, self.driver, self.DURATION_WARN, 4)

    def test_available_duration(self):
        check_search_duration(self, self.driver, '', 1)


class TrafficReportingParametersConstraintsTest(DashboardReportingParametersConstraintsTest):
    URL = '%s/cs/traffic/?m=201'


class TrafficByServiceReportingParametersConstraintsTest(DashboardReportingParametersConstraintsTest):
    URL = '%s/cs/traffic/?m=201'
    SUB_URL = '%s/cs/byservice/STAT_TRAFFIC_BY_SERVICE/?m=201'

    def _setUpEx(self):
        super(TrafficByServiceReportingParametersConstraintsTest, self)._setUpEx()

        driver = self.driver

        if self.CUSTOMER:
            btn_custom_date = driver.find_element(By.XPATH, "//button[@data-value='day']")
            btn_custom_date.click()

            driver.find_element(By.ID, 'btn_view').click()

        driver.get(self.SUB_URL % AURORA_FE_URL)

        btn_filter = driver.find_element(By.ID, 'btn_filter')
        time.sleep(1)
        btn_filter.click()


class TrafficTransferByServiceReportingParametersConstraintsTest(TrafficByServiceReportingParametersConstraintsTest):
    SUB_URL = '%s/cs/byservice/STAT_TRANSFER_BY_SERVICE/?m=201'


class TrafficEdgePageViewByServiceReportingParametersConstraintsTest(TrafficByServiceReportingParametersConstraintsTest):
    SUB_URL = '%s/cs/byservice/STAT_EDGE_PAGE_VIEWS_BY_SERVICE/?m=201'


class MAWTrafficBandWidthReportingParametersConstraintsTest(TrafficByServiceReportingParametersConstraintsTest):
    URL = '%s/maw/traffic_by_service/?m=347&report_type=MB'


class MAWTrafficDataTransferredByServiceReportingParametersConstraintsTest(TrafficByServiceReportingParametersConstraintsTest):
    URL = '%s/maw/traffic_by_service/?m=347&report_type=GB'


class VisitorsReportingParametersConstraintsTest(DashboardReportingParametersConstraintsTest):
    URL = '%s/cs/visitor/?m=203'


class ContentReportingParametersConstraintsTest(DashboardReportingParametersConstraintsTest):
    URL = '%s/cs/content/?m=192'
    DURATION_WARN = 'Report cannot be generated more than 1 months.'

    def test_available_duration(self):
        check_search_duration(self, self.driver, '', 0)


class MAWDashboardReportingParametersConstraintsTest(DashboardReportingParametersConstraintsTest):
    URL = '%s/maw/dashboard/?m=349'


class MAWTrafficReportingParametersConstraintsTest(DashboardReportingParametersConstraintsTest):
    URL = '%s/maw/traffic/?m=347'


class MAWVisitorReportingParametersConstraintsTest(DashboardReportingParametersConstraintsTest):
    URL = '%s/maw/visitors/?m=348'


class MAWContentReportingParametersConstraintsTest(DashboardReportingParametersConstraintsTest):
    URL = '%s/maw/content/?m=345'
    DURATION_WARN = 'Report cannot be generated more than 1 months.'

    def test_available_duration(self):
        check_search_duration(self, self.driver, '', 0)

if __name__ == '__main__':
    unittest.main()