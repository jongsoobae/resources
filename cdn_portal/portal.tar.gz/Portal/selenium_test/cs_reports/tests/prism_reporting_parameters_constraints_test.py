# [AURORAUI-3167]
import unittest

from selenium_test.config_constants import PRISM_FE_URL
from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver

from selenium_test.cs_reports.test_common_utils.assert_duration import assert_duration_of_year_on_calendar \
    ,assert_available_reporting_duration_type_a, assert_available_reporting_duration_type_b


class PrismDNAReportingParametersConstraintsTest(unittest.TestCase):
    URL = '%s/dna/reports/'

    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

        self.driver.get(self.URL % PRISM_FE_URL)

    def tearDown(self):
        self.driver.close()

    def test_available_year(self):
        assert_duration_of_year_on_calendar(self)


class PrismCloudDNSReportingParametersConstraintsTest(PrismDNAReportingParametersConstraintsTest):
    URL = '%s/dns/reports/'

    # [AURORAUI-3213]
    def test_available_reporting_duration_of_overall(self):
        assert_available_reporting_duration_type_a(self, 'overall', 'btn_filter_charts')

    # [AURORAUI-3213]
    def test_available_reporting_duration_of_record(self):
        assert_available_reporting_duration_type_a(self, 'record_type', 'btn_filter')

    # [AURORAUI-3213]
    def test_available_reporting_duration_of_location(self):
        assert_available_reporting_duration_type_b(self, 'location', 'btn_filter')

    # [AURORAUI-3213]
    def test_available_reporting_duration_of_clb_domains(self):
        assert_available_reporting_duration_type_b(self, 'clb_domains', 'btn_filter_charts')


class PrismCloudStorageReportingParametersConstraintsTest(PrismDNAReportingParametersConstraintsTest):
    URL = '%s/cloudstorage/reports/'

if __name__ == '__main__':
    unittest.main()