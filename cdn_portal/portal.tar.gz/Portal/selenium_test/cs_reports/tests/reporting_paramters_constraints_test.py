# [AURORAUI-3167]
import unittest

from selenium_test.config_constants import AURORA_FE_URL
from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.utils import get_web_driver

from selenium_test.cs_reports.test_common_utils.assert_duration import assert_duration_of_year_on_calendar\
    ,assert_available_reporting_duration_type_a, assert_available_reporting_duration_type_b


class DNAReportingParametersConstraintsTest(unittest.TestCase):
    URL = '%s/int/dna/reports/?m=221'

    def setUp(self):
        self.driver  = get_web_driver()
        AuroraLogin(self.driver).login_with(AURORA_INTERNAL_USER)

        self.driver.get(self.URL % AURORA_FE_URL)

    def tearDown(self):
        self.driver.close()

    def test_available_year(self):
        self.driver.switch_to_frame(self.driver.find_element_by_tag_name("iframe"))
        assert_duration_of_year_on_calendar(self)


class CloudDNSReportingParametersConstraintsTest(DNAReportingParametersConstraintsTest):
    URL = '%s/int/dns/reports/?m=269'

    # [AURORAUI-3213]
    def test_available_reporting_duration_of_overall(self):
        self.driver.switch_to_frame(self.driver.find_element_by_tag_name("iframe"))
        assert_available_reporting_duration_type_a(self, 'overall', 'btn_filter_charts')

    # [AURORAUI-3213]
    def test_available_reporting_duration_of_record(self):
        self.driver.switch_to_frame(self.driver.find_element_by_tag_name("iframe"))
        assert_available_reporting_duration_type_a(self, 'record_type', 'btn_filter')

    # [AURORAUI-3213]
    def test_available_reporting_duration_of_location(self):
        self.driver.switch_to_frame(self.driver.find_element_by_tag_name("iframe"))
        assert_available_reporting_duration_type_b(self, 'location', 'btn_filter')

    # [AURORAUI-3213]
    def test_available_reporting_duration_of_clb_domains(self):
        self.driver.switch_to_frame(self.driver.find_element_by_tag_name("iframe"))
        assert_available_reporting_duration_type_b(self, 'clb_domains', 'btn_filter_charts')


class CloudStorageReportingParametersConstraintsTest(DNAReportingParametersConstraintsTest):
    URL = '%s/int/cloudstorage/reports/?m=284'


if __name__ == '__main__':
    unittest.main()
