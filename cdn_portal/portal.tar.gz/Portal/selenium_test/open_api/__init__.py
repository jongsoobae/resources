import requests
import json
from selenium_test.config_user_constants import OPENAPI_CUSTOMER_USER
from selenium_test.config_constants import OPEN_API_URL

def get_user_session_context(url, username, password):
    uri = "rest/login"
    url = "%s/%s" % (url, uri)
    parameters = {'user': username, 'pass':password,'output':'json'}
    response = requests.get(url, params=parameters)
    print response._content
    data = json.loads(response._content)
    return data

def get_session_token(user_session_infos, control_group_identifier):
    for session_info in user_session_infos.get('loginResponse').get('session'):
        if session_info.get('svcGroupIdentifier') == control_group_identifier:
            return session_info.get('sessionToken')
    return ''



class OpenAPIManager(object):
    def __init__(self, control_group_identifier, api_key):
        self.control_group_identifier = control_group_identifier
        self.url = OPEN_API_URL
        self.username = OPENAPI_CUSTOMER_USER.get('username')
        self.password = OPENAPI_CUSTOMER_USER.get('password')

        self.user_session_infos = get_user_session_context(self.url, self.username, self.password)
        self.session_token = get_session_token(self.user_session_infos, self.control_group_identifier)
        self.api_key = api_key

    def get_random_session_token(self):
        sessions = self.user_session_infos.get('loginResponse').get('session', [])
        if sessions:
            return sessions[0]['sessionToken']
        return ''

    def _get_api_key_infos(self):
        uri = "rest/getApiKeyList"
        url = "%s/%s" % (self.url, uri)
        print url
        parameters = {'sessionToken':self.session_token, 'output': 'json'}
        response = requests.get(url, params=parameters)
        print response._content
        data = json.loads(response._content)
        return data

    def get_api_key(self,service_name=None):
        if service_name:
            api_keys = self._get_api_key_infos()
            for api_info in api_keys.get('apiKeyInfo').get('apiKeyInfoItem'):
                if api_info.get('serviceName') == service_name:
                    return api_info.get('apiKey')
        return self.api_key

    def _get_default_parameters(self, params, output=True):
        parameters = {'sessionToken': self.session_token}
        if output:
            parameters.update({'output': 'json'})

        if params is not None:
            for k,v in params.iteritems():
                try:
                    parameters.update({k:v})
                except:
                    pass
        return parameters

    def request(self,uri, params, output=True):
        """
        wrap request library. build url and parameters
        :param uri: uri path
        :param params: additional parameters
        :return:
        """
        url = "%s/%s" % (self.url, uri)
        parameters = self._get_default_parameters(params, output)
        response = requests.get(url, params=parameters)
        print "%s : %s" % (url,parameters)
        print response._content
        return response

    def request_post(self, uri, params):
        url = "%s/%s" % (self.url, uri)
        parameters = self._get_default_parameters(params)
        response = requests.post(url, data=parameters)
        return response
