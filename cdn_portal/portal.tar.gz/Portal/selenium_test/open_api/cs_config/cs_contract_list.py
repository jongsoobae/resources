import unittest
from selenium_test.open_api import OpenAPIManager

class TestCSContractList(unittest.TestCase):

    def setUp(self):
        CS_API_KEY_NAME = 'SERVICECATEGORY_CA'
        control_group_identifier = '501627AA14E37BD1D4143159E0E9620F' #ebay
        self.api_manager = OpenAPIManager(control_group_identifier, CS_API_KEY_NAME)

    def list_cs_contract(self):
        uri = "rest/pan/contract/list"

        #api_key = self.api_manager.get_api_key(contract_no)
        parameters = {'apiKey':self.api_manager.api_key}
        response = self.api_manager.request(uri, parameters)
        return response

    def test_cs_contract_list(self):
        response = self.list_cs_contract()
        print response._content
        assert 'resultCode' in response._content

if __name__ == "__main__":
    unittest.main()