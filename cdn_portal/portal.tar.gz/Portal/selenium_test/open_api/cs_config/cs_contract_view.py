import unittest
from selenium_test.open_api import OpenAPIManager

class TestCSContractView(unittest.TestCase):

    def setUp(self):
        CS_API_KEY_NAME = 'SERVICECATEGORY_CA'
        control_group_identifier = '501627AA14E37BD1D4143159E0E9620F' #ebay
        self.api_manager = OpenAPIManager(control_group_identifier, CS_API_KEY_NAME)

    def list_cs_contract(self):
        uri = "rest/pan/contract/list"
        #api_key = self.api_manager.get_api_key(contract_no)
        parameters = {'apiKey':self.api_manager.api_key}
        response = self.api_manager.request(uri, parameters)
        return response

    def view_cs_contract(self):
        contract_no = '40005613-10'
        uri = "rest/pan/contract/%s/view" % contract_no
        #uri = "rest/pan/contract/view"

        api_key = self.api_manager.get_api_key(contract_no)
        print api_key + '---'
        #parameters = {'contract_no':contract_no, 'apiKey':'SERVICECATEGORY_CA'}
        parameters = {'apiKey':self.api_manager.api_key}
        response = self.api_manager.request(uri, parameters)
        return response

    def test_cs_contract_view(self):
        response1 = self.list_cs_contract()
        print response1._content
        response = self.view_cs_contract()
        print response._content
        assert 'resultCode' in response._content

if __name__ == "__main__":
    unittest.main()