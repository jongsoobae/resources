import unittest
import requests
import json
from selenium_test.open_api import OpenAPIManager

class TestPADConfigEdit(unittest.TestCase):

    def setUp(self):
        CS_API_KEY_NAME = 'SERVICECATEGORY_CA'
        control_group_identifier = '501627AA14E37BD1D4143159E0E9620F' #ebay
        self.api_manager = OpenAPIManager(control_group_identifier, CS_API_KEY_NAME)

    def build_pad_params(self,params):
        param_list = []
        if params is not None:
            for k,v in params.iteritems():
                try:
                    param_list.append("%s=%s" % (k,v))
                except:
                    pass
        return "&".join(param_list)

    def get_pad_config(self, pad_name):
        uri = "rest/pan/site/view"
        parameters = {'pad': pad_name, 'apiKey':self.api_manager.get_api_key(pad_name)}
        response = self.api_manager.request(uri, parameters)
        return response

    def edit_pad_config(self, pad_info):
        uri = "rest/pan/site/edit"
        response = self.api_manager.request(uri,pad_info, output=False)
        return response

    def test_edit_panther_pad_config(self):
        pad_name = 'jsdiff.ebay.com' #ca request implementation
        #pad_name= 'r.abc.com' # dwa request implementation
        response = self.get_pad_config(pad_name)
        pad_info = json.loads(response._content).get('PadConfigResponse').get('data').get('data')
        print json.dumps(pad_info)
        assert '200' in response._content

        edit_info = {'pad':pad_name, 'apiKey':self.api_manager.get_api_key(pad_name), 'honor_byte_range':1, }
        pad_info.update(edit_info)
        response2 = self.edit_pad_config(pad_info)

        assert '200' in response2._content


if __name__ == "__main__":
    unittest.main()

