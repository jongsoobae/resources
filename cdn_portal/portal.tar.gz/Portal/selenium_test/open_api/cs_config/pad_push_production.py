import unittest
from selenium_test.open_api import OpenAPIManager

class TestSitePushProduction(unittest.TestCase):

    def setUp(self):
        CS_API_KEY_NAME = 'SERVICECATEGORY_CA'
        control_group_identifier = '501627AA14E37BD1D4143159E0E9620F' #ebay
        self.api_manager = OpenAPIManager(control_group_identifier, CS_API_KEY_NAME)

    def push_production(self):
        pad_name = 'jsdiff.ebay.com'
        uri = "rest/pan/site/push/%s/production" % pad_name

        api_key = self.api_manager.get_api_key(pad_name)
        parameters = {'pad':pad_name, 'apiKey':api_key}
        response = self.api_manager.request(uri, parameters)
        return response

    def get_push_history(self):
        pad_name = 'jsdiff.ebay.com'
        uri = "rest/pan/site/push/%s/history" % pad_name

        api_key = self.api_manager.get_api_key(pad_name)
        parameters = {'pad':pad_name, 'apiKey':api_key}
        response = self.api_manager.request(uri, parameters)
        return response

    def test_push_production(self):
        response = self.get_push_history()
        print response._content
        assert 'resultCode' in response._content

if __name__ == "__main__":
    unittest.main()