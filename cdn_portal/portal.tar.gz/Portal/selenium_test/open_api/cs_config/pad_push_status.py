import unittest
from selenium_test.open_api import OpenAPIManager

class TestSitePushStatus(unittest.TestCase):

    def setUp(self):
        CS_API_KEY_NAME = 'SERVICECATEGORY_CA'
        control_group_identifier = '501627AA14E37BD1D4143159E0E9620F' #ebay
        self.api_manager = OpenAPIManager(control_group_identifier, CS_API_KEY_NAME)

    def push_status(self):
        pad_name = 'jsdiff.ebay.com'
        uri = "rest/pan/site/push/%s/status" % pad_name
        uri = "rest/pan/site/pushStatus"

        api_key = self.api_manager.get_api_key(pad_name)
        parameters = {'pad':pad_name, 'apiKey':api_key}
        response = self.api_manager.request(uri, parameters)
        return response

    def test_push_status(self):
        response = self.push_status()
        print response._content
        assert 'resultCode' in response._content

if __name__ == "__main__":
    unittest.main()