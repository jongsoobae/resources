import unittest
from selenium_test.open_api import OpenAPIManager
import json


class TestSamView(unittest.TestCase):

    def setUp(self):
        CS_API_KEY_NAME = 'SERVICECATEGORY_CA'
        control_group_identifier = '501627AA14E37BD1D4143159E0E9620F' #ebay
        self.api_manager = OpenAPIManager(control_group_identifier, CS_API_KEY_NAME)

        self.pad_name = 'jsdiff.ebay.com'
        self.sam_rule = [
            {
                "do": [
                    {
                        "id": "NOA",
                        "on": ""
                    }
                ],
                "if": {
                    "id": "STR",
                    "m": "aaa",
                    "string": ""
                },
                "name": "test",
                "proc": "1"
            }
        ]

    def sam_view(self):
        uri = "rest/pan/sam/%s/view" % self.pad_name
        api_key = self.api_manager.get_api_key(self.pad_name)
        parameters = {'apiKey':api_key}
        response = self.api_manager.request(uri, parameters)
        return response

    def sam_add(self):
        uri = "rest/pan/sam/%s/add" % self.pad_name
        api_key = self.api_manager.get_api_key(self.pad_name)
        parameters = {'apiKey': api_key, 'sam_json': json.dumps(self.sam_rule)}
        response = self.api_manager.request_post(uri=uri, params=parameters)
        return response

    def sam_delete(self):
        uri = "rest/pan/sam/%s/delete" % self.pad_name
        api_key = self.api_manager.get_api_key(self.pad_name)
        parameters = {'apiKey': api_key}
        response = self.api_manager.request(uri=uri, params=parameters)
        return response

    def test_sam(self):
        response_add = self.sam_add()
        json_view = json.loads(response_add._content)
        print json_view
        assert 'SAMAddResponse' in json_view \
               and 'resultCode' in json_view['SAMAddResponse'] \
               and json_view['SAMAddResponse']['resultCode'] == 200

        response_view = self.sam_view()
        json_view = json.loads(response_view._content)
        print json_view
        assert 'SAMViewResponse' in json_view \
               and 'resultCode' in json_view['SAMViewResponse'] \
               and json_view['SAMViewResponse']['resultCode'] == 200

        response_delete = self.sam_delete()
        json_view = json.loads(response_delete._content)
        print json_view
        assert 'SAMDeleteResponse' in json_view \
               and 'resultCode' in json_view['SAMDeleteResponse'] \
               and json_view['SAMDeleteResponse']['resultCode'] == 200


if __name__ == "__main__":
    unittest.main()
