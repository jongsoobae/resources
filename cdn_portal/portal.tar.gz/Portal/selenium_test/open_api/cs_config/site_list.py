import unittest
from selenium_test.open_api import OpenAPIManager

class TestSiteList(unittest.TestCase):

    def setUp(self):
        CS_API_KEY_NAME = 'SERVICECATEGORY_CA'
        control_group_identifier = '501627AA14E37BD1D4143159E0E9620F' #ebay
        self.api_manager = OpenAPIManager(control_group_identifier, CS_API_KEY_NAME)

    def site_list(self):
        uri = "rest/pan/site/list"
        api_key = self.api_manager.get_api_key()
        parameters = {'apiKey':api_key,'info':1}
        response = self.api_manager.request(uri, parameters)
        return response

    def test_site_list(self):
        response = self.site_list()
        assert 'resultCode' in response._content

if __name__ == "__main__":
    unittest.main()