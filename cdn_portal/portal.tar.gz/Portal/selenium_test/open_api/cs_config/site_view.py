import unittest
import json
from selenium_test.open_api import OpenAPIManager
from selenium_test.open_api.cs_config import obj

class TestSiteView(unittest.TestCase):

    def setUp(self):
        CS_API_KEY_NAME = 'SERVICECATEGORY_CA'
        control_group_identifier = '501627AA14E37BD1D4143159E0E9620F' #ebay
        self.api_manager = OpenAPIManager(control_group_identifier, CS_API_KEY_NAME)

    def site_view(self, pad_name):
        uri = "rest/pan/site/view"
        api_key = self.api_manager.get_api_key(pad_name)
        parameters = {'pad':pad_name, 'apiKey':api_key}
        response = self.api_manager.request(uri, parameters)
        return response

    def edit_pad_config(self, pad_info):
        uri = "rest/pan/site/edit"
        response = self.api_manager.request(uri,pad_info, output=False)
        return response

    def is_self_implementable(self, pad_name):
        uri = "rest/pan/site/selfimplementable"
        api_key = self.api_manager.get_api_key(pad_name)
        parameters = {'pad':pad_name, 'apiKey':api_key}
        response = self.api_manager.request(uri, parameters)
        return response

    def test_site_view(self):
        pad_name = 'jsdiff.ebay.com'
        pad_name = 'tyk222.test.com'
        response = self.site_view(pad_name)
        pad_info = json.loads(response._content).get('PadConfigResponse').get('data').get('data')
        pad_info.update({'status':1})
        #myobj = obj(pad_info)

        response3 = self.is_self_implementable(pad_name)

        #edit_info = {'pad':pad_name, 'apiKey':self.api_manager.get_api_key(pad_name) }
        #pad_info.update(edit_info)
        #response2 = self.edit_pad_config(pad_info)
        assert 'resultCode' in response3._content

if __name__ == "__main__":
    unittest.main()