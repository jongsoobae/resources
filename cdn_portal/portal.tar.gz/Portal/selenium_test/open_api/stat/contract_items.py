import unittest
from selenium_test.open_api import OpenAPIManager

class TestContractInfo(unittest.TestCase):

    def setUp(self):
        CS_API_KEY_NAME = 'SERVICECATEGORY_CA'
        control_group_identifier = '501627AA14E37BD1D4143159E0E9620F' #ebay
        self.api_manager = OpenAPIManager(control_group_identifier, CS_API_KEY_NAME)

    def list_contracts(self):
        uri = "rest/contractItems"
        parameters = {}
        response = self.api_manager.request(uri, parameters)
        return response

    def test_list_contract(self):
        response = self.list_contracts()
        print response._content
        assert 'returnCode' in response._content

if __name__ == "__main__":
    unittest.main()