import unittest
from selenium_test.open_api import OpenAPIManager
import json

class TestContractInfo(unittest.TestCase):

    def setUp(self):
        self.default_url = "rest/overallTraffic"
        self.dns_api_key = 'SERVICECATEGORY_DNS'
        self.session_token = 'D2D62D943AE571415B42C170E4BEF5B2'
        self.api_manager = OpenAPIManager(self.session_token, self.dns_api_key)

    def check_real_date(self, response):
        if response['returnCode'] == 0:
            self.assertIn('real_date', response.keys())
        elif response['returnCode'] == 404:
            print '== No data ==', response
        else:
            print '*** ELSE *** ', response

    def test_processTime(self):
        uri = "%s/processTime" % self.default_url
        parameters = {
            'sessionToken': self.session_token,
            'apiKey': self.dns_api_key,
            'fromDate': '20161201',
            'toDate': '20161202',
            'timeInterval': 0,
        }
        response = self.api_manager.request(uri, parameters)
        ret_body = json.loads(response._content)['processTimeResponse']
        self.check_real_date(ret_body)

    def test_responseTypes(self):
        uri = "%s/responseTypes" % self.default_url
        parameters = {
            'sessionToken': self.session_token,
            'apiKey': self.dns_api_key,
            'fromDate': '20161201',
            'toDate': '20161202',
            'timeInterval': 0,
        }
        response = self.api_manager.request(uri, parameters)
        ret_body = json.loads(response._content)['responseTypesResponse']
        self.check_real_date(ret_body)

    def test_requests(self):
        uri = "%s/requests" % self.default_url
        parameters = {
            'sessionToken': self.session_token,
            'apiKey': self.dns_api_key,
            'fromDate': '20161201',
            'toDate': '20161202',
            'timeInterval': 0,
        }
        response = self.api_manager.request(uri, parameters)
        ret_body = json.loads(response._content)['requestsResponse']
        self.check_real_date(ret_body)

if __name__ == "__main__":
    unittest.main()
