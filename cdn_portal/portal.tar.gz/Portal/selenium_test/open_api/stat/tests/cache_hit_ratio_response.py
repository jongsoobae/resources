import unittest
from selenium_test.open_api import OpenAPIManager
import json

# [AURORAUI-3133]
class TestContractInfo(unittest.TestCase):

    def setUp(self):
        self.ca_api_key = 'SERVICECATEGORY_CA'
        self.group_id = '3413CE14D52B87557E87E2C1518C2CBE'
        self.api_manager = OpenAPIManager(self.group_id, self.ca_api_key)
        self.session_token = self.api_manager.get_random_session_token()

    def check_total_avg(self, response):
        if response['returnCode'] == 0:
            self.assertIn('totalAvg', response.keys())
        elif response['returnCode'] == 404:
            print '== No data ==', response
        else:
            print '*** ELSE *** ', response

    def test_cache_hit_ratio(self):
        uri = "rest/traffic/cacheHitRatio"
        parameters = {
            'sessionToken': self.session_token,
            'apiKey': self.ca_api_key,
            'fromDate': '20161201',
            'toDate': '20161201',
            'timeInterval': 1,
        }
        response = self.api_manager.request(uri, parameters)
        ret_body = json.loads(response._content)['cacheHitRatioResponse']
        self.check_total_avg(ret_body)



if __name__ == "__main__":
    unittest.main()
