import unittest
import json
from selenium_test.open_api import OpenAPIManager
from selenium_test.config_user_constants import AURORA_CUSTOMER_USER

# [AURORAUI-3185]
class TestVisitorHttpVersion(unittest.TestCase):

    def setUp(self):
        self.ca_api_key = 'SERVICECATEGORY_CA'
        #Dora Telekomunikasyon Hizmetleri AS (control_group_id = 1086)
        control_group_id = "D91D1B4D82419DE8A614ABCE9CC0E6D4"
        self.api_manager = OpenAPIManager(control_group_id, self.ca_api_key)
        self.session_token = self.api_manager.get_random_session_token()

    def test_list_http_version(self):
        uri = "rest/visitor/visitorsByHTTPVersion"
        parameters = {
            'sessionToken': self.session_token,
            'apiKey': self.ca_api_key,
            'fromDate':'20161206',
            'toDate':'20161206',
            'output':'json',
        }
        response = self.api_manager.request(uri, parameters)
        ret_body = json.loads(response._content)['visitorsByHTTPVersionResponse']

        if ret_body['returnCode'] == 0:
            for item in ret_body['visitorsByHTTPVersionItem']:
                self.assertIn('httpVersion', item)
                self.assertIn('totalHits', item)
        elif ret_body['returnCode'] == 404:
            print '== No data ==', response
        else:
            print '*** ELSE *** ', response


if __name__ == "__main__":
    unittest.main()
