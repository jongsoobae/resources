import unittest
from selenium_test.open_api import OpenAPIManager
import json

class TestContractInfo(unittest.TestCase):

    def setUp(self):
        self.default_url = "rest/traffic"
        self.ca_api_key = 'SERVICECATEGORY_CA'
        self.session_token = 'D2D62D943AE571415B42C170E4BEF5B2'
        self.api_manager = OpenAPIManager(self.session_token, self.ca_api_key)

    def check_real_date(self, response):
        if response['returnCode'] == 0:
            self.assertIn('real_date', response.keys())
        elif response['returnCode'] == 404:
            print '== No data ==', response
        else:
            print '*** ELSE *** ', response

    def test_active_connection(self):
        uri = "%s/activeConnection" % self.default_url
        parameters = {
            'sessionToken': self.session_token,
            'apiKey': self.ca_api_key,
            'fromDate': '20161201',
            'toDate': '20161202',
            'timeInterval': 0,
        }
        response = self.api_manager.request(uri, parameters)
        ret_body = json.loads(response._content)['activeConnectionResponse']
        self.check_real_date(ret_body)

    def test_page_views(self):
        uri = "%s/pageViews" % self.default_url
        parameters = {
            'sessionToken': self.session_token,
            'apiKey': self.ca_api_key,
            'fromDate': '20161201',
            'toDate': '20161202',
            'timeInterval': 0,
        }
        response = self.api_manager.request(uri, parameters)
        ret_body = json.loads(response._content)['pageViewsResponse']
        self.check_real_date(ret_body)

    def test_cache_hit_ratio(self):
        uri = "%s/cacheHitRatio" % self.default_url
        parameters = {
            'sessionToken': self.session_token,
            'apiKey': self.ca_api_key,
            'fromDate': '20161201',
            'toDate': '20161201',
            'timeInterval': 0,
        }
        response = self.api_manager.request(uri, parameters)
        ret_body = json.loads(response._content)['cacheHitRatioResponse']
        self.check_real_date(ret_body)

    def test_responsecode_origin(self):
        uri = "%s/responseCode/origin" % self.default_url
        parameters = {
            'sessionToken': self.session_token,
            'apiKey': self.ca_api_key,
            'fromDate': '20161201',
            'toDate': '20161230',
            'timeInterval': 0,
        }
        response = self.api_manager.request(uri, parameters)
        ret_body = json.loads(response._content)['responseCodeResponse']
        self.check_real_date(ret_body)

    def test_responsecode_edge(self):
        uri = "%s/responseCode/edge" % self.default_url
        parameters = {
            'sessionToken': self.session_token,
            'apiKey': self.ca_api_key,
            'fromDate': '20161201',
            'toDate': '20161230',
            'timeInterval': 0,
        }
        response = self.api_manager.request(uri, parameters)
        ret_body = json.loads(response._content)['responseCodeResponse']
        self.check_real_date(ret_body)

    def test_peakHits_origin(self):
        uri = "%s/peakHits/origin" % self.default_url
        parameters = {
            'sessionToken': self.session_token,
            'apiKey': self.ca_api_key,
            'fromDate': '20161201',
            'toDate': '20161230',
            'timeInterval': 0,
        }
        response = self.api_manager.request(uri, parameters)
        ret_body = json.loads(response._content)['peakHitsResponse']
        self.check_real_date(ret_body)

    def test_peakHits_edge(self):
        uri = "%s/peakHits/edge" % self.default_url
        parameters = {
            'sessionToken': self.session_token,
            'apiKey': self.ca_api_key,
            'fromDate': '20161201',
            'toDate': '20161230',
            'timeInterval': 0,
        }
        response = self.api_manager.request(uri, parameters)
        ret_body = json.loads(response._content)['peakHitsResponse']
        self.check_real_date(ret_body)

    def test_dynamicStatic(self):
        uri = "%s/dynaicStatic" % self.default_url
        parameters = {
            'sessionToken': self.session_token,
            'apiKey': self.ca_api_key,
            'fromDate': '20161201',
            'toDate': '20161230',
            'timeInterval': 0,
        }
        response = self.api_manager.request(uri, parameters)
        ret_body = json.loads(response._content)['trafficResponse']
        self.check_real_date(ret_body)

    def test_perzone(self):
        uri = "%s/perzone" % self.default_url
        parameters = {
            'sessionToken': self.session_token,
            'apiKey': self.ca_api_key,
            'fromDate': '20161201',
            'toDate': '20161230',
            'timeInterval': 0,
        }
        response = self.api_manager.request(uri, parameters)
        ret_body = json.loads(response._content)['perzoneTrafficResponse']
        self.check_real_date(ret_body)

    def test_shield(self):
        uri = "%s/shield" % self.default_url
        parameters = {
            'sessionToken': self.session_token,
            'apiKey': self.ca_api_key,
            'fromDate': '20161201',
            'toDate': '20161202',
            'timeInterval': 0,
        }
        response = self.api_manager.request(uri, parameters)
        ret_body = json.loads(response._content)['trafficResponse']
        self.check_real_date(ret_body)

    def test_origin(self):
        uri = "%s/origin" % self.default_url
        parameters = {
            'sessionToken': self.session_token,
            'apiKey': self.ca_api_key,
            'fromDate': '20161201',
            'toDate': '20161230',
            'timeInterval': 0,
        }
        response = self.api_manager.request(uri, parameters)
        ret_body = json.loads(response._content)['trafficResponse']
        self.check_real_date(ret_body)

    def test_edge(self):
        uri = "%s/edge" % self.default_url
        parameters = {
            'sessionToken': self.session_token,
            'apiKey': self.ca_api_key,
            'fromDate': '20161201',
            'toDate': '20161230',
            'timeInterval': 0,
        }
        response = self.api_manager.request(uri, parameters)
        ret_body = json.loads(response._content)['trafficResponse']
        self.check_real_date(ret_body)



if __name__ == "__main__":
    unittest.main()
