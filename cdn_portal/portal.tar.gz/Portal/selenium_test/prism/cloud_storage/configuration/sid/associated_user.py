import time
from datetime import datetime

from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait

from selenium_test.shared_components.conf import settings


def cstorage_add_new_associated_user(driver, sid_name):
    driver.get(settings.PRISM_FE_URL + "/")
    ###########################################################################################################
    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.ID, "leftnav_product_dropdown_chzn"))
    )

    driver.find_element(By.ID, "leftnav_product_dropdown_chzn").click()
    product_selector = driver.find_element(By.ID, "leftnav_product_dropdown_chzn")
    product_search_input = product_selector.find_element(By.XPATH, ".//input[@type='text']")
    product_search_input.clear()
    product_search_input.send_keys('Cloud Storage')
    product_search_input.send_keys(Keys.RETURN)

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '#config-storage')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '#config-storage')]").click()

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '/cloudstorage/#/storages/')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '/cloudstorage/#/storages/')]").click()

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//table[@sort-column-clicked='getStorageList(1)']//tbody//tr[position()=1]"))
    )

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//table[@sort-info = 'sid.sort_params']//td[text() = '" + sid_name + "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Edit']"))
    )

    sid_edit_button = driver.find_element(By.XPATH, "//table[@sort-info = 'sid.sort_params']//td[text() = '" + sid_name + "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Edit']")
    sid_edit_button.click()

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//b[@ng-if='is_detail_page' and text() != '']"))
    )

    WebDriverWait(driver, 120).until(
        EC.invisibility_of_element_located((By.XPATH, "//div[@ng-show='!(storage_detail_loaded && customer_list_loaded && customer_item_list_loaded && starfs_related_domain_loaded)']"))
    )

    driver.find_element(By.XPATH, '//div[@ng-controller = "SIDAssociatedUserController"]//button[@ng-click= "openModal(null, \'add\')"]').click()

    i = 1
    date_str = datetime.now().strftime('%Y%m%d')
    retry = 20
    while retry:
        user_name = "-".join(['user', date_str, str(i)])
        driver.find_element(By.NAME, "user_name").clear()
        driver.find_element(By.NAME, "user_name").send_keys(user_name)
        driver.find_element(By.NAME, "password").clear()
        driver.find_element(By.NAME, "password").send_keys('1234')
        driver.find_element(By.NAME, "confirm_password").clear()
        driver.find_element(By.NAME, "confirm_password").send_keys('1234')
        driver.find_element(By.XPATH, "//button[@ng-click = 'save(forms.associated_user, associated_user.info, $event)']").click()

        timeout = 120
        while timeout:
            time.sleep(5)
            try:
                if driver.find_element(By.XPATH, '//div[@ng-bind = "associated_user_error"]').is_displayed():
                    i += 1
                    break
                elif driver.find_element(By.XPATH, '//div[@ng-bind-html-unsafe = "associated_user_success"]').is_displayed():
                    return user_name + '_' + sid_name
                else:
                    timeout -= 5
                    pass
            except:
                timeout -= 5
                pass

        retry -= 1

    return user_name + '_' + sid_name


def cstorage_delete_associated_user(driver, sid_name, user_name):
    driver.get(settings.PRISM_FE_URL + "/")
    ###########################################################################################################
    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.ID, "leftnav_product_dropdown_chzn"))
    )

    driver.find_element(By.ID, "leftnav_product_dropdown_chzn").click()
    product_selector = driver.find_element(By.ID, "leftnav_product_dropdown_chzn")
    product_search_input = product_selector.find_element(By.XPATH, ".//input[@type='text']")
    product_search_input.clear()
    product_search_input.send_keys('Cloud Storage')
    product_search_input.send_keys(Keys.RETURN)

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '#config-storage')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '#config-storage')]").click()

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '/cloudstorage/#/storages/')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '/cloudstorage/#/storages/')]").click()

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//table[@sort-column-clicked='getStorageList(1)']//tbody//tr[position()=1]"))
    )

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//table[@sort-info = 'sid.sort_params']//td[text() = '" + sid_name + "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Edit']"))
    )

    sid_edit_button = driver.find_element(By.XPATH, "//table[@sort-info = 'sid.sort_params']//td[text() = '" + sid_name + "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Edit']")
    sid_edit_button.click()

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//b[@ng-if='is_detail_page' and text() != '']"))
    )

    WebDriverWait(driver, 120).until(
        EC.invisibility_of_element_located((By.XPATH, "//div[@ng-show='!(storage_detail_loaded && customer_list_loaded && customer_item_list_loaded && starfs_related_domain_loaded)']"))
    )

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//div[@ng-controller = \"SIDAssociatedUserController\"]//table//tbody//td[text() = '" + user_name + "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Delete']"))
    )

    delete_modal_button = driver.find_element(By.XPATH, "//div[@ng-controller = \"SIDAssociatedUserController\"]//table//tbody//td[text() = '" + user_name + "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Delete']")
    delete_modal_button.click()

    WebDriverWait(driver, 120).until(
        EC.element_to_be_clickable((By.XPATH, "//div[@id = 'delete_modal']//div[@class='modal-footer']//button[@ng-click = 'deleteActionMethod(delete_action_target, $event)']"))
    )
    delete_button = driver.find_element(By.XPATH, "//div[@id = 'delete_modal']//div[@class='modal-footer']//button[@ng-click = 'deleteActionMethod(delete_action_target, $event)']")
    delete_button.click()

    try:
        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, '//div[@ng-bind-html-unsafe = "associated_user_success"]'))
        )
    except:
        return False
    else:
        return True
    ###########################################################################################################


# Created Date  : 2017.02.01 (WED)
# Modified Date : 2017.02.02 (THU)
# Author        : jaeyoung.cho
# Description   : Manipulate update button on grid and 'Modify User' dialog.
def assert_access_path(driver, access_path, assertion_msg):
    # Click Edit button of first row on grid in 'Associated Users'
    btn_edit = driver.find_element(By.XPATH,
                                   '// *[ @ id = "content-right"] / div[1] / div / div[2] / div[2] / div[3] / div[1] / div[5] / div[1] / div[2] / table / tbody / tr[1] / td[5] / button[1]')
    btn_edit.click()

    # Wait 'Modify User' dialog.
    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located(
            (By.XPATH, '//*[ @ id = "associated_user_modal"]/div/div/div[2]/form/table/tbody/tr[5]/td/input'))
    )

    # Edit 'Access Path' textbox.
    ele_access_path = driver.find_element(By.XPATH,
                                          '//*[ @ id = "associated_user_modal"]/div/div/div[2]/form/table/tbody/tr[5]/td/input')
    ele_access_path.clear()
    ele_access_path.send_keys(access_path)

    # Click Save button on 'Modify User' dialog
    btn_save = driver.find_element(By.XPATH,
                                   '// *[ @ id = "associated_user_modal"] / div / div / div[3] / button[1]')
    btn_save.click()

    time.sleep(2)

    # Becuase wargnin_box is already exists in html page, the following code doesn't work.
    # WebDriverWait(driver, 120).until(
    #     EC.presence_of_element_located((By.XPATH, '// *[ @ id = "associated_user_modal"] / div / div / div[2] / form / div'))
    # )

    # Get message which is printed on warning box
    warning_box = driver.find_element(By.XPATH,
                                      '// *[ @ id = "associated_user_modal"] / div / div / div[2] / form / div')
    msg = warning_box.text

    if assertion_msg is None:
        return '' == msg
    else:
        driver.find_element(By.XPATH,
                            '// *[ @ id = "associated_user_modal"] / div / div / div[3] / button[2]').click()

        time.sleep(1)

        return msg == (assertion_msg % access_path)



