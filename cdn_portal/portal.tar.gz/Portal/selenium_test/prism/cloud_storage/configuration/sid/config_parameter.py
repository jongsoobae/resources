import random
import time
from datetime import datetime

from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.wait import WebDriverWait

from selenium_test.shared_components.conf import settings


def cstorage_add_new_config_parameter(driver, sid_name):
    driver.get(settings.PRISM_FE_URL + "/")
    ###########################################################################################################
    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.ID, "leftnav_product_dropdown_chzn"))
    )

    driver.find_element(By.ID, "leftnav_product_dropdown_chzn").click()
    product_selector = driver.find_element(By.ID, "leftnav_product_dropdown_chzn")
    product_search_input = product_selector.find_element(By.XPATH, ".//input[@type='text']")
    product_search_input.clear()
    product_search_input.send_keys('Cloud Storage')
    product_search_input.send_keys(Keys.RETURN)

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '#config-storage')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '#config-storage')]").click()

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '/cloudstorage/#/storages/')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '/cloudstorage/#/storages/')]").click()

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//table[@sort-column-clicked='getStorageList(1)']//tbody//tr[position()=1]"))
    )

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//table[@sort-info = 'sid.sort_params']//td[text() = '" + sid_name + "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Edit']"))
    )

    sid_edit_button = driver.find_element(By.XPATH, "//table[@sort-info = 'sid.sort_params']//td[text() = '" + sid_name + "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Edit']")
    sid_edit_button.click()

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//b[@ng-if='is_detail_page' and text() != '']"))
    )

    WebDriverWait(driver, 120).until(
        EC.invisibility_of_element_located((By.XPATH, "//div[@ng-show='!(storage_detail_loaded && customer_list_loaded && customer_item_list_loaded && starfs_related_domain_loaded)']"))
    )

    driver.find_element(By.XPATH, '//div[@ng-controller = "SIDConfigParameterController"]//button[@ng-click= "openModal(null, \'add\')"]').click()

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//select[@ng-model = 'config_parameter.info.param_name' and count(option) != 1]"))
    )

    i = 1
    retry = 20
    while retry:
        param_count = driver.find_elements(By.XPATH, "//select[@ng-model = 'config_parameter.info.param_name']//option").__len__()
        random_index = random.randrange(1, param_count)
        Select(driver.find_element_by_name("param_name")).select_by_index(random_index)
        param_name = driver.find_elements(By.XPATH, "//select[@ng-model = 'config_parameter.info.param_name']//option")[random_index].text
        driver.find_element(By.NAME, "param_value").clear()
        driver.find_element(By.NAME, "param_value").send_keys('1234')

        driver.find_element(By.XPATH, "//button[@ng-click = 'save(forms.config_parameter, config_parameter.info, $event)']").click()

        timeout = 120
        while timeout:
            time.sleep(5)
            try:
                if driver.find_element(By.XPATH, '//div[@ng-bind = "config_parameter_error"]').is_displayed():
                    i += 1
                    break
                elif driver.find_element(By.XPATH, '//div[@ng-bind-html-unsafe = "config_parameter_success"]').is_displayed():
                    return param_name
                else:
                    timeout -= 5
                    pass
            except:
                timeout -= 5
                pass

        retry -= 1

    return param_name


def cstorage_delete_config_parameter(driver, sid_name, param_name):
    driver.get(settings.PRISM_FE_URL + "/")
    ###########################################################################################################
    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.ID, "leftnav_product_dropdown_chzn"))
    )

    driver.find_element(By.ID, "leftnav_product_dropdown_chzn").click()
    product_selector = driver.find_element(By.ID, "leftnav_product_dropdown_chzn")
    product_search_input = product_selector.find_element(By.XPATH, ".//input[@type='text']")
    product_search_input.clear()
    product_search_input.send_keys('Cloud Storage')
    product_search_input.send_keys(Keys.RETURN)

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '#config-storage')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '#config-storage')]").click()

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '/cloudstorage/#/storages/')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '/cloudstorage/#/storages/')]").click()

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//table[@sort-column-clicked='getStorageList(1)']//tbody//tr[position()=1]"))
    )

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//table[@sort-info = 'sid.sort_params']//td[text() = '" + sid_name + "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Edit']"))
    )

    sid_edit_button = driver.find_element(By.XPATH, "//table[@sort-info = 'sid.sort_params']//td[text() = '" + sid_name + "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Edit']")
    sid_edit_button.click()

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//b[@ng-if='is_detail_page' and text() != '']"))
    )

    WebDriverWait(driver, 120).until(
        EC.invisibility_of_element_located((By.XPATH, "//div[@ng-show='!(storage_detail_loaded && customer_list_loaded && customer_item_list_loaded && starfs_related_domain_loaded)']"))
    )

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//div[@ng-controller = \"SIDConfigParameterController\"]//table//tbody//td[text() = '" + param_name + "']/following-sibling::td/following-sibling::td//button[@title = 'Delete']"))
    )

    delete_modal_button = driver.find_element(By.XPATH, "//div[@ng-controller = \"SIDConfigParameterController\"]//table//tbody//td[text() = '" + param_name + "']/following-sibling::td/following-sibling::td//button[@title = 'Delete']")
    delete_modal_button.click()

    WebDriverWait(driver, 120).until(
        EC.element_to_be_clickable((By.XPATH, "//div[@id = 'delete_modal']//div[@class='modal-footer']//button[@ng-click = 'deleteActionMethod(delete_action_target, $event)']"))
    )
    delete_button = driver.find_element(By.XPATH, "//div[@id = 'delete_modal']//div[@class='modal-footer']//button[@ng-click = 'deleteActionMethod(delete_action_target, $event)']")
    delete_button.click()

    try:
        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, '//div[@ng-bind-html-unsafe = "config_parameter_success"]'))
        )
    except:
        return False
    else:
        return True
    ###########################################################################################################
