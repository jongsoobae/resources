import time
from datetime import datetime

from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.wait import WebDriverWait

from selenium_test.shared_components.conf import settings


def cstorage_add_new_sid(driver):
    driver.get(settings.PRISM_FE_URL + "/")
    ###########################################################################################################
    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.ID, "leftnav_product_dropdown_chzn"))
    )

    driver.find_element(By.ID, "leftnav_product_dropdown_chzn").click()
    product_selector = driver.find_element(By.ID, "leftnav_product_dropdown_chzn")
    product_search_input = product_selector.find_element(By.XPATH, ".//input[@type='text']")
    product_search_input.clear()
    product_search_input.send_keys('Cloud Storage')
    product_search_input.send_keys(Keys.RETURN)

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '#config-storage')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '#config-storage')]").click()

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '/cloudstorage/#/storages/')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '/cloudstorage/#/storages/')]").click()

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//table[@sort-column-clicked='getStorageList(1)']//tbody//tr[position()=1]"))
    )

    driver.find_element(By.XPATH, '//button[@ng-click = "go(\'/storage/new/\')"]').click()

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//select[@ng-model = 'storage.info.customer_id' and count(option) != 1]"))
    )

    i = 1
    date_str = datetime.now().strftime('%Y%m%d')
    retry = 20
    while retry:
        storage_name = "-".join(['sid', date_str, str(i)])
        driver.find_element(By.NAME, "storage_name").clear()
        driver.find_element(By.NAME, "storage_name").send_keys(storage_name)
        Select(driver.find_element_by_name("customer_id")).select_by_visible_text("88 Brothers IT [US]")

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//select[@ng-model = 'storage.info.item_id' and count(option) != 1]"))
        )

        Select(driver.find_element_by_name("item_id")).select_by_value("24093")
        driver.find_element(By.XPATH, "//button[@ng-click = 'SIDDetail(forms.storage, storage.info, $event)']").click()

        timeout = 120
        while timeout:
            time.sleep(5)
            try:
                if driver.find_element(By.CSS_SELECTOR, "div.cstorage_content_wrapper > div.error_msg.ng-binding").is_displayed():
                    i += 1
                    break
                elif driver.find_element(By.CSS_SELECTOR, "div.cstorage_content_wrapper > div.success_msg.ng-binding").is_displayed():
                    return storage_name
                else:
                    timeout -= 5
                    pass
            except:
                timeout -= 5
                pass

        retry -= 1

    return storage_name


def cstorage_delete_sid(driver, sid_name):
    driver.get(settings.PRISM_FE_URL + "/")
    ###########################################################################################################
    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.ID, "leftnav_product_dropdown_chzn"))
    )

    driver.find_element(By.ID, "leftnav_product_dropdown_chzn").click()
    product_selector = driver.find_element(By.ID, "leftnav_product_dropdown_chzn")
    product_search_input = product_selector.find_element(By.XPATH, ".//input[@type='text']")
    product_search_input.clear()
    product_search_input.send_keys('Cloud Storage')
    product_search_input.send_keys(Keys.RETURN)

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '#config-storage')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '#config-storage')]").click()

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '/cloudstorage/#/storages/')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '/cloudstorage/#/storages/')]").click()

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//table[@sort-column-clicked='getStorageList(1)']//tbody//tr[position()=1]"))
    )

    WebDriverWait(driver, 120).until(
        EC.visibility_of_element_located((By.XPATH, "//table[@sort-info = 'sid.sort_params']//td[text() = '" + sid_name+ "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Delete']"))
    )

    delete_modal_button = driver.find_element(By.XPATH, "//table[@sort-info = 'sid.sort_params']//td[text() = '" + sid_name+ "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Delete']")
    delete_modal_button.click()

    WebDriverWait(driver, 120).until(
        EC.element_to_be_clickable((By.XPATH, "//div[@id = 'delete_modal']//div[@class='modal-footer']//button[@ng-click = 'deleteStorage(delete_action_target, $event)']"))
    )
    delete_button = driver.find_element(By.XPATH, "//div[@id = 'delete_modal']//div[@class='modal-footer']//button[@ng-click = 'deleteStorage(delete_action_target, $event)']")
    delete_button.click()

    try:
        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.CSS_SELECTOR, "div.cstorage_content_wrapper > div.success_msg.ng-binding"))
        )
    except:
        return False
    else:
        return True
    ###########################################################################################################
