import unittest

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.prism.cloud_storage.configuration.sid.sid import cstorage_add_new_sid, cstorage_delete_sid
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


class CStorageAddPageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_logged_in_when_display_sid_add_page_then_should_be_shown(self):
        driver = self.driver
        ###########################################################################################################
        driver.find_element(By.XPATH, "//span[contains(text(),'Select a Product')]").click()
        el1 = driver.find_element(By.ID, "leftnav_product_dropdown_chzn")
        el6 = el1.find_element(By.XPATH, ".//input[@type='text']")
        el6.clear()
        el6.send_keys('Cloud Storage')
        el6.send_keys(Keys.RETURN)

        driver.find_element(By.XPATH, "//a[contains(@href, '/cloudstorage/#/storages/')]").click()

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//table[@sort-column-clicked='getStorageList(1)']//tbody//tr[position()=1]"))
        )

        driver.find_element(By.XPATH, '//button[@ng-click = "go(\'/storage/new/\')"]').click()

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//select[@ng-model = 'storage.info.customer_id' and count(option) != 1]"))
        )

        ###########################################################################################################

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_logged_in_when_add_new_cstorage_sid_with_valid_data_then_should_be_added(self):
        driver = self.driver
        sid_name = cstorage_add_new_sid(driver)
        self.assertEqual(sid_name, driver.find_element(By.CSS_SELECTOR, "div.cstorage_content_wrapper > div.success_msg.ng-binding > b").text)

        # Delete newly added location.
        self.assertTrue(cstorage_delete_sid(driver, sid_name))
        ###########################################################################################################
if __name__ == '__main__':
    unittest.main()
