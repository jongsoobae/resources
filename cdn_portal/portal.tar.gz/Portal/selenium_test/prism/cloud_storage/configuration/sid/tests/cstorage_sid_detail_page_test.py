import unittest

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.prism.cloud_storage.configuration.sid.associated_user import cstorage_add_new_associated_user, \
    cstorage_delete_associated_user, assert_access_path
from selenium_test.prism.cloud_storage.configuration.sid.config_parameter import cstorage_add_new_config_parameter, \
    cstorage_delete_config_parameter
from selenium_test.prism.cloud_storage.configuration.sid.ip_based_acl import cstorage_add_new_ip_based_acl, \
    cstorage_delete_ip_based_acl
from selenium_test.prism.cloud_storage.configuration.sid.mime_config_parameter import \
    cstorage_add_new_mime_config_parameter
from selenium_test.prism.cloud_storage.configuration.sid.mime_config_parameter import \
    cstorage_delete_mime_config_parameter
from selenium_test.prism.cloud_storage.configuration.sid.sid import cstorage_add_new_sid, cstorage_delete_sid
from selenium_test.prism.cloud_storage.configuration.sid.synced_cluster import cstorage_add_new_synced_cluster, \
    cstorage_delete_synced_cluster
from selenium_test.prism.cloud_storage.configuration.sid.virtual_host import cstorage_add_new_virtual_host,\
    cstorage_delete_virtual_host
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver
import time


class CStorageDetailPageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_logged_in_when_display_sid_detail_page_then_should_be_shown(self):
        driver = self.driver
        ###########################################################################################################
        driver.find_element(By.XPATH, "//span[contains(text(),'Select a Product')]").click()
        el1 = driver.find_element(By.ID, "leftnav_product_dropdown_chzn")
        el6 = el1.find_element(By.XPATH, ".//input[@type='text']")
        el6.clear()
        el6.send_keys('Cloud Storage')
        el6.send_keys(Keys.RETURN)

        driver.find_element(By.XPATH, "//a[contains(@href, '/cloudstorage/#/storages/')]").click()

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//table[@sort-column-clicked='getStorageList(1)']//tbody//tr[position()=1]//button[@ng-click='SIDDetail(obj.storage_id)']"))
        )

        driver.find_element(By.XPATH, "//table[@sort-column-clicked='getStorageList(1)']//tbody//tr[position()=1]//button[@ng-click='SIDDetail(obj.storage_id)']").click()

        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//b[@ng-if='is_detail_page' and text() != '']"))
        )

        ###########################################################################################################

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_logged_in_when_add_new_virtual_host_with_valid_data_then_should_be_added(self):
        driver = self.driver
        sid_name = cstorage_add_new_sid(driver)
        self.assertEqual(sid_name, driver.find_element(By.CSS_SELECTOR, "div.cstorage_content_wrapper > div.success_msg.ng-binding > b").text)
        virtual_host_name = cstorage_add_new_virtual_host(driver, sid_name)
        self.assertEqual(virtual_host_name, driver.find_element(By.XPATH, '//div[@ng-bind-html-unsafe = "virtual_host_success"]//b').text)

        # Delete newly added location.
        self.assertTrue(cstorage_delete_virtual_host(driver, sid_name, virtual_host_name))
        self.assertTrue(cstorage_delete_sid(driver, sid_name))
        ###########################################################################################################

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_logged_in_when_add_new_synced_cluster_with_valid_data_then_should_be_added(self):
        driver = self.driver
        sid_name = cstorage_add_new_sid(driver)
        self.assertEqual(sid_name, driver.find_element(By.CSS_SELECTOR, "div.cstorage_content_wrapper > div.success_msg.ng-binding > b").text)
        cluster_name = cstorage_add_new_synced_cluster(driver, sid_name)
        self.assertEqual(cluster_name, driver.find_element(By.XPATH, '//div[@ng-bind-html-unsafe = "synced_cluster_success"]//b').text)

        # Delete newly added location.
        self.assertTrue(cstorage_delete_synced_cluster(driver, sid_name, cluster_name))
        self.assertTrue(cstorage_delete_sid(driver, sid_name))
        ###########################################################################################################

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_logged_in_when_add_new_associated_user_with_valid_data_then_should_be_added(self):
        driver = self.driver
        sid_name = cstorage_add_new_sid(driver)
        self.assertEqual(sid_name, driver.find_element(By.CSS_SELECTOR, "div.cstorage_content_wrapper > div.success_msg.ng-binding > b").text)
        user_name = cstorage_add_new_associated_user(driver, sid_name)
        self.assertEqual(user_name, driver.find_element(By.XPATH, '//div[@ng-bind-html-unsafe = "associated_user_success"]//b').text)

        # Delete newly added location.
        self.assertTrue(cstorage_delete_associated_user(driver, sid_name, user_name))
        self.assertTrue(cstorage_delete_sid(driver, sid_name))
        ###########################################################################################################

    # Created Date  : 2017.02.01 (WED)
    # Modified Date : 2017.02.02 (THU)
    # Author        : jaeyoung.cho
    # Description   : Inspect to validate input value of 'Access Path'
    @catch_exception(author='jaeyoung.cho')
    def test_given_user_is_logged_in_when_add_new_associated_user_with_valid_data_then_should_be_edited(self):
        driver = self.driver

        sid_name = cstorage_add_new_sid(driver)
        self.assertEqual(sid_name, driver.find_element(By.CSS_SELECTOR,
                                                       "div.cstorage_content_wrapper > div.success_msg.ng-binding > b").text)
        user_name = cstorage_add_new_associated_user(driver, sid_name)
        self.assertEqual(user_name, driver.find_element(By.XPATH,
                                                        '//div[@ng-bind-html-unsafe = "associated_user_success"]//b').text)

        self.assertTrue(assert_access_path(driver, '-_test.txt._-', "Access Path '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '_test.txt._-', "Access Path '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '_test.txt-', "Access Path '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '_test.txt.', "Access Path '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '_test.txt_', "Access Path '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '_test.txt_', "Access Path '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/_test.txt-', "Access Path '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/_test.txt.', "Access Path '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/_test.txt_', "Access Path '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, 'test.txt', "Access Path '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/-_test.txt', "Access Path '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/te#$@#$@#$@#$@#$st.txt', "Access Path '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/test/test.', "Access Path '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/test/test.txt-', "Access Path '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/.test', "Access Path '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/..test', "Access Path '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/test.txt', None))
        self.assertTrue(assert_access_path(driver, '/_test/test.txt', None))
        self.assertTrue(assert_access_path(driver, '/_test.txt/text.txt', None))
        self.assertTrue(assert_access_path(driver, '/_test.txt', None))

        # Delete newly added location.
        self.assertTrue(cstorage_delete_associated_user(driver, sid_name, user_name))
        self.assertTrue(cstorage_delete_sid(driver, sid_name))


    @catch_exception(author='jaeik.lee')
    def test_given_user_is_logged_in_when_add_new_config_parameter_with_valid_data_then_should_be_added(self):
        driver = self.driver
        sid_name = cstorage_add_new_sid(driver)
        self.assertEqual(sid_name, driver.find_element(By.CSS_SELECTOR, "div.cstorage_content_wrapper > div.success_msg.ng-binding > b").text)
        config_parameter_name = cstorage_add_new_config_parameter(driver, sid_name)
        self.assertEqual(config_parameter_name, driver.find_element(By.XPATH, '//div[@ng-bind-html-unsafe = "config_parameter_success"]//b').text)

        # Delete newly added location.
        self.assertTrue(cstorage_delete_config_parameter(driver, sid_name, config_parameter_name))
        self.assertTrue(cstorage_delete_sid(driver, sid_name))
        ###########################################################################################################

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_logged_in_when_add_new_mime_config_parameter_with_valid_data_then_should_be_added(self):
        driver = self.driver
        sid_name = cstorage_add_new_sid(driver)
        self.assertEqual(sid_name, driver.find_element(By.CSS_SELECTOR, "div.cstorage_content_wrapper > div.success_msg.ng-binding > b").text)
        mime_config_parameter_name = cstorage_add_new_mime_config_parameter(driver, sid_name)
        self.assertEqual(mime_config_parameter_name, driver.find_element(By.XPATH, '//div[@ng-bind-html-unsafe = "mime_config_parameter_success"]//b').text)

        # Delete newly added location.
        self.assertTrue(cstorage_delete_mime_config_parameter(driver, sid_name, mime_config_parameter_name))
        self.assertTrue(cstorage_delete_sid(driver, sid_name))
        ###########################################################################################################

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_logged_in_when_add_new_ip_based_acl_with_valid_data_then_should_be_added(self):
        driver = self.driver
        sid_name = cstorage_add_new_sid(driver)
        self.assertEqual(sid_name, driver.find_element(By.CSS_SELECTOR, "div.cstorage_content_wrapper > div.success_msg.ng-binding > b").text)
        self.assertTrue(cstorage_add_new_ip_based_acl(driver, sid_name))

        # Delete newly added location.
        self.assertTrue(cstorage_delete_ip_based_acl(driver, sid_name))
        self.assertTrue(cstorage_delete_sid(driver, sid_name))
        ###########################################################################################################




if __name__ == '__main__':
    unittest.main()
