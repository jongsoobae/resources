import unittest

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


class CStorageRelatedDomainLinkTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='juwon.lee')
    def test_click_related_domain_link(self):
        driver = self.driver

        ###########################################################################################################

        # move to gslb domain page which has related sid
        # test fixture : 88 brothers (domain id 5884)
        fixture_domain_id = 5884

        # move to gslb domain page
        driver.get('http://10.40.196.120:3020/config/domains/#/view/%s' % str(fixture_domain_id))

        storage_name_xpath = (By.XPATH, "//li[contains(text(), 'Storage Name:')]")

        # find related domain panel
        storage_name_node = driver.find_element(*storage_name_xpath)
        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located(storage_name_xpath)
        )

        # wait for 3 seconds..
        WebDriverWait(driver, 3)

        # find related domain link to redirect sid detail page
        related_sid_link = storage_name_node.find_element(By.XPATH, ".//a").click()

        # find cstorage sid ui container
        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.XPATH, "//div[contains(@class, 'cstorage_float_left')]"))
        )

        # wait for 3 seconds..
        WebDriverWait(driver, 3)

        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
