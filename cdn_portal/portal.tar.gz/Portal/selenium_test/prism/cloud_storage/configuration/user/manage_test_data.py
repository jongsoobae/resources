from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import time

# Created Date  : 2017.02.02 (THU)
# Modified Date :
# Author        : jaeyoung.cho
# Description   : Manage test data for test.
class TestDataManager():
    def __init__(self, driver):
        self.driver = driver

    # Created Date  : 2017.02.02 (THU)
    # Modified Date :
    # Author        : jaeyoung.cho
    # Description   : Create test data
    def create(self):
        driver = self.driver

        driver.find_element(By.XPATH, "//span[contains(text(),'Select a Product')]").click()
        el1 = driver.find_element(By.ID, "leftnav_product_dropdown_chzn")
        el6 = el1.find_element(By.XPATH, ".//input[@type='text']")
        el6.clear()
        el6.send_keys('Cloud Storage')
        el6.send_keys(Keys.RETURN)

        el1 = driver.find_element(By.ID, "leftnav-cstorage")
        el1 = el1.find_element(By.XPATH, ".//a[contains(@href, '/cloudstorage/storage_user_list/')]")
        el1.click()

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".datatable2.datatable"))
        )

        driver.find_element(By.XPATH, '// *[ @ id = "btn_add_user2"]').click()

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '//*[@id="select_sid"]'))
        )

        Select(driver.find_element(By.XPATH, '//*[@id="select_sid"]')).select_by_visible_text("88brothers")

        ele_temp = driver.find_element(By.XPATH, '//*[@id="id_user_name"]')
        ele_temp.send_keys('jaeyoung_test')
        ele_temp.send_keys(Keys.RETURN)

        ele_temp = driver.find_element(By.XPATH, '//*[@id="id_password"]')
        ele_temp.send_keys('1234')
        ele_temp.send_keys(Keys.RETURN)

        ele_temp = driver.find_element(By.XPATH, '//*[@id="id_password2"]')
        ele_temp.send_keys('1234')
        ele_temp.send_keys(Keys.RETURN)

        driver.find_element(By.XPATH, '//*[@id="btn_complete_user"]').click()


    # Created Date  : 2017.02.02 (THU)
    # Modified Date :
    # Author        : jaeyoung.cho
    # Description   : Delete test data
    def delete(self):
        driver = self.driver

        ele_search = driver.find_element(By.XPATH, '// *[ @ id = "txt_search"]')
        ele_search.send_keys('jaeyoung_test_88brothers')
        ele_search.send_keys(Keys.ENTER)

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//td[contains(text(),'jaeyoung_test_88brothers')]"))
        )

        # Get grid element
        datatable = driver.find_element(By.CSS_SELECTOR, ".datatable2.datatable")

        # Click update button on grid
        btn_edit = datatable.find_element(By.CSS_SELECTOR, ".btn-delete")
        btn_edit.click()

        driver.find_element(By.XPATH, '//*[@id="btn_delete_yes"]').click()


# Created Date  : 2017.02.01 (WED)
# Modified Date : 2017.02.02 (THU)
# Author        : jaeyoung.cho
# Description   : Manipulate update button on grid and 'Modify User' dialog.
def assert_access_path(driver, access_path, assertion_msg):
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, ".datatable2.datatable"))
    )

    ele_search = driver.find_element(By.XPATH, '// *[ @ id = "txt_search"]')
    ele_search.send_keys('jaeyoung_test_88brothers')
    ele_search.send_keys(Keys.ENTER)

    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.XPATH, "//td[contains(text(),'jaeyoung_test_88brothers')]"))
    )

    # Get grid element
    datatable = driver.find_element(By.CSS_SELECTOR, ".datatable2.datatable")

    # Click update button on grid
    btn_edit = datatable.find_element(By.CSS_SELECTOR, ".btn-update")
    btn_edit.click()

    # Wait 'Modify User' dialog.
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, "id_access_path"))
    )

    # Edit 'Access Path' textbox.
    ele_access_path = driver.find_element(By.ID, "id_access_path")
    ele_access_path.clear()
    ele_access_path.send_keys(access_path)

    # Click Save button on 'Modify User' dialog
    btn_save = driver.find_element(By.ID, 'btn_complete_user')
    btn_save.click()

    WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.ID, "warning_box"))
    )

    # Get message which is printed on warning box
    warning_box = driver.find_element(By.ID, 'warning_box')
    msg = warning_box.text

    if assertion_msg is None:
        # When validation check is success, this code wait for 3 seconds to reflect the change.
        # If this code is deleted, This test code doesn't work well.
        time.sleep(3)
        return '' == msg
    else:
        return msg == (assertion_msg % access_path)