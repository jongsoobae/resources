import unittest

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import time

from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver

from selenium_test.prism.cloud_storage.configuration.user.manage_test_data import TestDataManager, assert_access_path


class CStorageUserPageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_logged_in_when_display_cstorage_user_page_then_should_be_shown(self):
        driver = self.driver
        ###########################################################################################################
        driver.find_element(By.XPATH, "//span[contains(text(),'Select a Product')]").click()
        el1 = driver.find_element(By.ID, "leftnav_product_dropdown_chzn")
        el6 = el1.find_element(By.XPATH, ".//input[@type='text']")
        el6.clear()
        el6.send_keys('Cloud Storage')
        el6.send_keys(Keys.RETURN)

        el1 = driver.find_element(By.ID, "leftnav-cstorage")
        el1 = el1.find_element(By.XPATH, ".//a[contains(@href, '/cloudstorage/storage_user_list/')]")
        el1.click()

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".datatable2.datatable"))
        )

        Select(driver.find_element(By.ID, "select_customer")).select_by_visible_text("88 Brothers IT [US]")

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//td[contains(text(),'88brothers')]"))
        )

        ###########################################################################################################

    # Created Date  : 2017.02.01 (WED)
    # Modified Date : 2017.02.02 (THU)
    # Author        : jaeyoung.cho
    # Description   : Inspect to validate input value of 'Access Path'
    @catch_exception(author='jaeyoung.cho')
    def test_given_user_is_logged_in_when_display_cstorage_user_page_then_edit_access_path(self):
        driver = self.driver

        test_data_manager = TestDataManager(driver)
        test_data_manager.create()

        self.assertTrue(assert_access_path(driver, '-_test.txt._-', "path_name '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '_test.txt._-', "path_name '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '_test.txt-', "path_name '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '_test.txt.', "path_name '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '_test.txt_', "path_name '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '_test.txt_', "path_name '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/_test.txt-', "path_name '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/_test.txt.', "path_name '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/_test.txt_', "path_name '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, 'test.txt', "path_name '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/-_test.txt', "path_name '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/te#$@#$@#$@#$@#$st.txt', "path_name '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/test/test.', "path_name '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/test/test.txt-', "path_name '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/.test', "path_name '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/..test', "path_name '%s' is not valid."))
        self.assertTrue(assert_access_path(driver, '/test.txt', None))
        self.assertTrue(assert_access_path(driver, '/_test/test.txt', None))
        self.assertTrue(assert_access_path(driver, '/_test.txt/text.txt', None))
        self.assertTrue(assert_access_path(driver, '/_test.txt', None))

        test_data_manager.delete()





if __name__ == '__main__':
    unittest.main()
