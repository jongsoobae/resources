from datetime import datetime
from random import random
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.wait import WebDriverWait

from selenium_test.shared_components.conf import settings


def add_new_domain(driver, domain_type):
    # Go to preset menu
    go_to_domain_page(driver)

    WebDriverWait(driver, 30).until(
        EC.element_to_be_clickable((By.XPATH, "//a[@ng-click=\"addDomainForm()\"]"))
    )

    # Click "Add domain" button
    preset_add_btn = driver.find_element(By.XPATH, "//a[@ng-click=\"addDomainForm()\"]")
    preset_add_btn.click()

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//input[@ng-model='adddomain_modal.domain_name']"))
    )

    # Get "Domain Name" input
    domain_name_input = driver.find_element(By.XPATH, "//input[@ng-model='adddomain_modal.domain_name']")

    date_str = datetime.now().strftime('%Y%m%d')
    random_number = int(random()*99999)
    retry = 10
    while retry:
        # To make domain name
        domain_name = "-".join(['domain', date_str, str(random_number)])
        domain_name_input.clear()
        domain_name_input.send_keys(domain_name)

        # Select Domain Type
        Select(driver.find_element_by_xpath("//select[@ng-model='adddomain_modal.domain_type']"))\
            .select_by_visible_text(domain_type)

        # Click "Save" button
        save_btn = driver.find_element(By.XPATH, "//a[@ng-click='domainAdd()']")
        save_btn.click()

        timeout = 30
        while timeout:
            time.sleep(5)
            try:
                # Check success message is displayed
                if driver.find_element(By.XPATH, "//div[@id='dtl_message_box']").is_displayed():
                    return domain_name
                # Check error message is displayed
                elif driver.find_element(By.XPATH, "//div[@id='domain_add_warning' and contains(text(), 'Domain already exists.')]").is_displayed():
                    break
                else:
                    timeout -= 5
                    pass
            except:
                timeout -= 5
                pass

        retry -= 1


def delete_domain(driver, domain_name):
    # Go to preset menu
    go_to_domain_page(driver)

    WebDriverWait(driver, 30).until(
        EC.element_to_be_clickable((By.XPATH, "//input[@ng-click=\"domainListSearch(list.customer,list.type,list.searchbar)\"]"))
    )

    # Get search input element and search domain to delete
    search_input = driver.find_element(By.XPATH, "//input[@ng-model='list.searchbar']")
    search_input.clear()
    search_input.send_keys(domain_name)

    # Click search button
    search_btn = driver.find_element(By.XPATH, "//input[@ng-click=\"domainListSearch(list.customer,list.type,list.searchbar)\"]")
    search_btn.click()

    WebDriverWait(driver, 30).until(
        EC.element_to_be_clickable((By.XPATH,
                                    "//div[@ng-show='domains_loaded']//table//tbody//tr//td//a//div[text()='" +
                                    domain_name +
                                    "']//..//../following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title='Delete']"))
    )

    # Click "Delete" button
    delete_btn = driver.find_element(By.XPATH, "//div[@ng-show='domains_loaded']//table//tbody//tr//td//a//div[text()='" + domain_name + "']//..//../following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title='Delete']")
    delete_btn.click()

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//a[@ng-click='deleteDomainOK(del_domain_id, del_name)']"))
    )

    # Click "Yes. I'm sure" button
    delete_confirm_btn = driver.find_element(By.XPATH, "//a[@ng-click='deleteDomainOK(del_domain_id, del_name)']")
    delete_confirm_btn.click()

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//div[@id='list_message_box']//ul//li"))
    )

    # Get message
    msg = driver.find_element(By.XPATH, "//div[@id='list_message_box']//ul//li").text

    return msg


def go_to_domain_page(driver):
    # Go to Home
    driver.get(settings.PRISM_FE_URL + "/")

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//div[@id='leftnav']//ul//li//a[@href='#config']"))
    )

    # Click Configuration menu
    configuration_menu = driver.find_element(By.XPATH, "//div[@id='leftnav']//ul//li//a[@href='#config']")
    configuration_menu.click()

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//div[@id='leftnav']//ul//li//a[@href='/config/domains/']"))
    )

    # Click Domains menu
    preset_relay_menu = driver.find_element(By.XPATH, "//div[@id='leftnav']//ul//li//a[@href='/config/domains/']")
    preset_relay_menu.click()
