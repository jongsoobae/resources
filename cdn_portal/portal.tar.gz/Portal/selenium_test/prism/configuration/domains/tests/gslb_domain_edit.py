import unittest

## CONFIGURATIONS
from selenium_test.config_constants import PRISM_FE_URL
from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from time import sleep

class GslbDomainEditTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='injune.hwang')
    def test_gslb_domain_edit_monitoring_type(self):
        driver = self.driver
        driver.get('%s/config/domains/#/view/%s' % (PRISM_FE_URL,4176))

        #WebDriverWait(driver, 20).until(
        #    EC.presence_of_element_located((By.XPATH, "//select[@ng-model='dtl_monitoring_type']/option[text()='KR Sejong Monitoring']"))
        #)
        sleep(3)

        monitoring_type_filter = driver.find_element_by_id('dtl_monitoring_type')
        for option in monitoring_type_filter.find_elements_by_tag_name('option'):
            if option.text == 'KR Sejong Monitoring':
                option.click()
                break
        edit_domain_btn = driver.find_element(By.XPATH, '//a[@id="dtl_tab_save"]')
        edit_domain_btn.click()

        confirm_btn = driver.find_element(By.XPATH, "//a[@ng-click='domainDetailSave()']")
        confirm_btn.click()
        sleep(3)
        monitoring_type_filter = driver.find_element_by_id('dtl_monitoring_type')
        region_text = Select(monitoring_type_filter).first_selected_option.text
        self.assertEqual(region_text, "KR Sejong Monitoring")

if __name__ == '__main__':
    unittest.main()
