import unittest2 as unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver
from selenium_test.config_user_constants import PRISM_INTERNAL_USER

from selenium_test.prism.configuration.domains import add_new_domain, delete_domain


class GslbDomainsDelaystartSlowstartTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

        # Add new domain
        self.test_domain_name = add_new_domain(self.driver, 'GSLB')

        # test value set
        self.test_delay_start_time = 2
        self.test_slowstart_period = 2
        # Dealy start time (1~172800), Slowstart period (0~4294967295)
        self.test_error_dealy_start_time_min = 0
        self.test_error_delay_start_time_max = 172801
        self.test_error_slowstart_period_min = -1
        self.test_error_slowstart_period_max = 4294967300

    def tearDown(self):
        # Delete GSLB domain
        delete_domain(self.driver, self.test_domain_name)
        self.driver.quit()

    def check_enable_disable_field(self, field_name, element, check_value):
        if check_value:
            if element.is_enabled():
                print(field_name+" is enabled")
                pass
            else:
                raise
        else:
            if element.is_enabled():
                raise
            else:
                print(field_name+" is disabled")
                pass


    def test_gslb_domain_used_by_delaystart_slowstart(self):
        driver = self.driver

        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.ID, "dtl_probe"))
        )

        # Select Probe value(----------)
        Select(driver.find_element_by_id("dtl_probe")).select_by_visible_text("----------")

        # Click 'Basic Properties' tab
        basic_properties_tab = driver.find_element(By.XPATH, "//li/a[text()='Basic Properties']")
        basic_properties_tab.click()

        # Delay start time and Slowstart period input (disabled check)
        delay_start_time = driver.find_element(By.ID, "dtl_delay_start_time")
        slowstart_period = driver.find_element(By.ID, "dtl_slowstart_period")
        self.check_enable_disable_field("Delay start time", delay_start_time, False)
        self.check_enable_disable_field("Slowstart period", slowstart_period, False)

        # Click 'Probe Metric' tab
        probe_matric_tab = driver.find_element(By.XPATH, "//li/a[text()='Probe Metric']")
        probe_matric_tab.click()
        # Select Probe value(TCP_80)
        Select(driver.find_element_by_id("dtl_probe")).select_by_visible_text("TCP_80")

        # Click 'Basic Properties' tab
        basic_properties_tab = driver.find_element(By.XPATH, "//li/a[text()='Basic Properties']")
        basic_properties_tab.click()

        # Delay start time and Slowstart period input (Validation)
        delay_start_time = driver.find_element(By.ID, "dtl_delay_start_time")
        slowstart_period = driver.find_element(By.ID, "dtl_slowstart_period")
        self.check_enable_disable_field("Delay start time", delay_start_time, True)
        self.check_enable_disable_field("Slowstart period", slowstart_period, True)

        # Check 1
        delay_start_time.clear()
        delay_start_time.send_keys(self.test_error_dealy_start_time_min)
        delay_start_time.send_keys(Keys.RETURN)

        slowstart_period.clear()
        slowstart_period.send_keys(self.test_error_slowstart_period_min)
        slowstart_period.send_keys(Keys.RETURN)

        driver.find_element(By.ID, "dtl_tab_save").click()

        # Click 'Yes' button to confirm
        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//a[@ng-click='domainDetailSave()']"))
        )
        driver.find_element(By.XPATH, "//a[@ng-click='domainDetailSave()']").click()

        # Check Save Error Msg
        err_msg = driver.find_element(By.XPATH, "//a[@ng-click='domainDetailSave()']").text
        check_msg = "delay_start_time : Ensure this value is less than or equal to 172800."
        check_msg += "<br>"
        check_msg += "slowstart_period : Ensure this value is less than or equal to 4294967295."
        check_msg += "<br>"
        self.assertEqual(check_msg, err_msg)

        # Check 2
        delay_start_time.clear()
        delay_start_time.send_keys(self.test_error_delay_start_time_max)
        delay_start_time.send_keys(Keys.RETURN)

        slowstart_period.clear()
        slowstart_period.send_keys(self.test_error_slowstart_period_max)
        slowstart_period.send_keys(Keys.RETURN)

        driver.find_element(By.ID, "dtl_tab_save").click()

        # Click 'Yes' button to confirm
        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//a[@ng-click='domainDetailSave()']"))
        )
        driver.find_element(By.XPATH, "//a[@ng-click='domainDetailSave()']").click()

        # Check Save Error Msg
        err_msg = driver.find_element(By.XPATH, "//a[@ng-click='domainDetailSave()']").text
        check_msg = "delay_start_time : Ensure this value is greater than or equal to 1."
        check_msg += "<br>"
        check_msg += "slowstart_period : Ensure this value is greater than or equal to 0."
        check_msg += "<br>"
        self.assertEqual(check_msg, err_msg)

        # Save
        delay_start_time.clear()
        delay_start_time.send_keys(self.test_delay_start_time)
        delay_start_time.send_keys(Keys.RETURN)

        slowstart_period.clear()
        slowstart_period.send_keys(self.test_slowstart_period)
        slowstart_period.send_keys(Keys.RETURN)

        driver.find_element(By.ID, "dtl_tab_save").click()

        # Click 'Yes' button to confirm
        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//a[@ng-click='domainDetailSave()']"))
        )
        driver.find_element(By.XPATH, "//a[@ng-click='domainDetailSave()']").click()

        # Check Save Msg
        success_msg = driver.find_element(By.XPATH, "//ul[@class='messagelist']/li").text
        check_msg = "The domain "+self.test_domain_name+" was changed successfully. You may edit it again below."
        self.assertEqual(success_msg, check_msg)
