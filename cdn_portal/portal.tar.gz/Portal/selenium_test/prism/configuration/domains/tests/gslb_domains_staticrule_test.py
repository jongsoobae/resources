import unittest

## CONFIGURATIONS
from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from time import sleep
from selenium.common.exceptions import NoSuchElementException


static_rule_txt = """<domainstaticruleconditions>
<list-item>
<action>
<list-item>
response.answer=cname,7200,giopek.gccdn.cn
</list-item>
</action>
<invert>
True
</invert>
<condition>
client.ip=61.135.155.250,114.112.65.107
</condition>
</list-item>
<list-item>
<action>
<list-item>
response.answer=cname,7200,gioctsh.gccdn.cn
</list-item>
</action>
<invert>
False
</invert>
<condition>
client.ip=101.227.71.10
</condition>
</list-item>
<list-item>
<action>
<list-item>
response.answer=cname,350,n5csgio2.cdngc.net
</list-item>
</action>
<invert/>
<condition>
always
</condition>
</list-item>
</domainstaticruleconditions>"""

class GslbDomainsStaticRuleTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='hyejun.yim')
    def test_is_internal_user_when_domain_static_rule_import(self):
        driver = self.driver
        ###########################################################################################################
        driver.find_element(By.XPATH, "//a[@href='#config']").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[text()='Domains']"))
        )
        driver.find_element(By.XPATH, "//a[text()='Domains']").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[@ng-click='addDomainForm()']"))
        )
        driver.find_element(By.XPATH, "//a[@ng-click='addDomainForm()']").click()
 
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, "domain_name"))
        )
        sleep(1)

        # domain add
        el1 = driver.find_element(By.ID, "domain_name")
        el1.send_keys("domain.staticruleimport.com")
        Select(driver.find_element_by_name("domain_type")).select_by_visible_text("GSLB")
        Select(driver.find_element_by_name("domain_customer")).select_by_visible_text("CDNetworks Product Management [US]")

        driver.find_element(By.XPATH, "//a[@ng-click='domainAdd()']").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[@href='#staticRules-tab']"))
        )
        driver.find_element(By.XPATH, "//a[@href='#staticRules-tab']").click()
        sleep(1)

        driver.find_element(By.ID, "import_xml").click()
        WebDriverWait(driver, 120).until(
            EC.element_to_be_clickable((By.XPATH, "//a[@ng-click='staticruleValidateCheck()']"))
        )

        static_rule = driver.find_element(By.XPATH, "//textarea[@ng-model='dtl_staticrule']")
        static_rule.clear()
        static_rule.send_keys(static_rule_txt)

        driver.find_element(By.XPATH, "//a[@ng-click='staticruleValidateCheck()']").click()

        WebDriverWait(driver, 5).until(EC.alert_is_present())
        alert = driver.switch_to_alert()
        alert.accept()
        WebDriverWait(driver, 120).until(
            EC.visibility_of_element_located((By.ID, "dtl_staticrule_btn"))
        )
        driver.find_element(By.ID, "dtl_staticrule_btn").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//ul[@class='messagelist']/li"))
        )

        # Invert value check
        namedInput = driver.find_element(By.XPATH, "//pre[text()='client.ip=61.135.155.250,114.112.65.107']")
        rowElement = namedInput.find_element(By.XPATH, "..//div")
        rowElement.find_element(By.XPATH, "..//div[text()='Invert']")

        namedInput2 = driver.find_element(By.XPATH, "//pre[text()='client.ip=101.227.71.10']")
        rowElement2 = namedInput2.find_element(By.XPATH, "..//div")
        with self.assertRaises(NoSuchElementException) as exception:
            rowElement2.find_element(By.XPATH, "..//div[text()='Invert']")

        static_rule_count = len(driver.find_elements(By.XPATH, "//a[@ng-click='deleteStaticRule(data.domain_staticrule_condition_id)']"))
        for i in range(static_rule_count):
            driver.find_elements(By.XPATH, "//a[@ng-click='deleteStaticRule(data.domain_staticrule_condition_id)']")[0].click()
            WebDriverWait(driver, 120).until(
                EC.presence_of_element_located((By.XPATH, "//a[@ng-click='dtlStaticRuleDelete(delete_staticrule_condition_id)']"))
            )
            driver.find_element(By.XPATH, "//a[@ng-click='dtlStaticRuleDelete(delete_staticrule_condition_id)']").click()

            WebDriverWait(driver, 120).until(
                EC.presence_of_element_located((By.XPATH, "//ul[@class='messagelist']/li[text()='Static Rule Delete Successfully']"))
            )
            sleep(1)

        # domain delete
        driver.find_element(By.CLASS_NAME, "deletelink").click()
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[@ng-click='deleteDomainInfo(dtl_del_domain, dtl_del_name)']"))
        )
        driver.find_element(By.XPATH, "//a[@ng-click='deleteDomainInfo(dtl_del_domain, dtl_del_name)']").click()

        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
