import unittest

## CONFIGURATIONS
from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver

from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from time import sleep

class GslbDomainsVipAddTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='hyejun.yim')
    def test_is_internal_user_when_domains_vip_list(self):
        driver = self.driver
        ###########################################################################################################
        driver.find_element(By.XPATH, "//a[@href='#config']").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[text()='Domains']"))
        )
        driver.find_element(By.XPATH, "//a[text()='Domains']").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[@ng-click='addDomainForm()']"))
        )
        driver.find_element(By.XPATH, "//a[@ng-click='addDomainForm()']").click()
 
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.ID, "domain_name"))
        )

        # domain add
        el1 = driver.find_element(By.ID, "domain_name")
        el1.send_keys("domain.vipadd.test.com")
        Select(driver.find_element_by_name("domain_type")).select_by_visible_text("GSLB")
        Select(driver.find_element_by_name("domain_customer")).select_by_visible_text("CDNetworks Product Management [US]")

        driver.find_element(By.XPATH, "//a[@ng-click='domainAdd()']").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[text()='Add a Domain Vip']"))
        )

        # Add Vip(11 additional)
        for i in range(10,21):
            text = "66.114.62." + str(i)
            driver.find_element(By.XPATH, "//a[text()='Add a Domain Vip']").click()
            sleep(1)
            WebDriverWait(driver, 120).until(
                EC.visibility_of_element_located((By.ID, "id_ac_vip"))
            )
            el2 = driver.find_element(By.ID, "id_ac_vip")
            el2.send_keys(text)
            sleep(1)
            if i > 18:
                element_to_hover_over = driver.find_element_by_css_selector("ul.ui-autocomplete > :last-child ")
            else:
                element_to_hover_over = driver.find_element_by_css_selector("ul.ui-autocomplete > :first-child ")
            webdriver.ActionChains(driver).move_to_element(element_to_hover_over).click(element_to_hover_over).perform()
            driver.find_element(By.XPATH, "//a[@ng-click='domainVipSave()']").click()
            WebDriverWait(driver, 120).until(
                EC.visibility_of_element_located((By.XPATH, "//a[text()='"+ text +"']"))
            )

        el3 = driver.find_elements(By.XPATH, "//table/tbody/tr[@ng-repeat='dtl_vip in dtl_domainvips']")
        vip_size = len(el3)
        self.assertEqual(vip_size, 11)

        # domain delete
        driver.find_element(By.CLASS_NAME, "deletelink").click()
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[@ng-click='deleteDomainInfo(dtl_del_domain, dtl_del_name)']"))
        )
        driver.find_element(By.XPATH, "//a[@ng-click='deleteDomainInfo(dtl_del_domain, dtl_del_name)']").click()

        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
