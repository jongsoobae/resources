
import unittest
import time

from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from selenium_test.config_constants import PRISM_FE_URL
from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


class TestDnaShieldDomainEditPage(unittest.TestCase):

    # define xpaths
    xpath_advanced_relay_tab = (By.XPATH, "//a[@href = '#advancedRelay-tab']")
    xpath_add_pop_button = (By.XPATH, "//a[@ng-click = 'openAddPOPs()']")
    xpath_add_preset_relay = (By.XPATH, "//a[@ng-click='openSearchPresetRelay()']")

    xpath_add_preset_relay_select_confirm_button = (By.XPATH, "//a[@ng-click='openDomainPresetRelay()']")
    xpath_add_preset_relay_save_button = (By.XPATH, "//a[@ng-click=\"saveDomainPresetRelay(\'modify\')\"]")

    xpath_add_preset_relay_modal_input = (By.XPATH, "//input[@ng-model='_preset.selected_search_preset']")
    xpath_add_preset_relay_modal_relay_item = (By.XPATH, "//tr[@ng-repeat='preset_relay in _preset.preset_relays']")
    xpath_add_preset_relay_modal_search_button = (By.XPATH, "//a[@ng-click='searchPresetRelay(_preset.selected_search_preset)']")

    xpath_delete_preset_relay_item = (By.XPATH, "//td//a[@ng-click='openDelDomainPresetRelay(domainPresetRelay.preset_name)']")
    xpath_delete_preset_relay_modal = (By.XPATH, "//div[@id='delete_preset_relay_modal']")
    xpath_delete_preset_relay_modal_yes_button = (By.XPATH, "//a[@ng-click=\"saveDomainPresetRelay(\'del\')\"]")

    # define test wait threshold
    wait_threshold = 10 # sec

    # alert popup text
    add_pop_alert_popup_text = \
        u'You can configure Advanced Relay only by one way,' \
        u' \u2018Add POPs\u2019 or \u2018Add Pre-set Relay\u2019.'

    # shield domain
    fixture_dna_shield_domain_id_with_empty_relay = 2071
    fixture_dna_shield_domain_id_with_preset_relay = 11870
    fixture_dna_shield_domain_id_with_dynamic_relay_pop = 8934

    # gslb domain (not dna shield)
    fixture_gslb_domain_id = 11920

    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.quit()

    ''' Test Helper Functions '''

    def get_to_domain_configuration_edit_page(self, driver, domain_id):

        # get to dna shield domain edit page
        url = PRISM_FE_URL + '/config/domains/#/view/%s' % domain_id
        driver.get(url)

    def wait_for_advanced_relay_tab(self, driver):

        WebDriverWait(driver, self.wait_threshold).until(
            EC.visibility_of_element_located(self.xpath_advanced_relay_tab)
        )

    def move_to_advanced_relay_tab_menu(self, driver):

        # find 'Advanced Relay' tab menu and move
        advanced_relay_tab_menu = driver.find_element(*self.xpath_advanced_relay_tab)
        advanced_relay_tab_menu.click()

    def wait_for_add_pop_button(self, driver):

        WebDriverWait(driver, self.wait_threshold).until(
            EC.visibility_of_element_located(self.xpath_add_pop_button)
        )

    def try_to_add_dynamic_pop(self, driver):

        add_pop_button = driver.find_element(*self.xpath_add_pop_button)
        add_pop_button.click()

    def wait_for_delete_preset_relay_modal(self, driver):

        WebDriverWait(driver, self.wait_threshold).until(
            EC.visibility_of_element_located(self.xpath_delete_preset_relay_modal)
        )

    def click_delete_confirm_button_in_preset_relay_delete_modal(self, driver):

        delete_confirm_button = driver.find_element(*self.xpath_delete_preset_relay_modal_yes_button)
        delete_confirm_button.click()

    def wait_for_add_preset_relay_button(self, driver):

        WebDriverWait(driver, self.wait_threshold).until(
            EC.visibility_of_element_located(self.xpath_add_preset_relay)
        )

    def check_add_alert_popup_and_close(self, driver):

        alert_window = driver.switch_to_alert()
        self.assertEqual(alert_window.text, self.add_pop_alert_popup_text)
        alert_window.accept()

    def click_add_preset_relay_button(self, driver):

        add_preset_relay_button = driver.find_element(*self.xpath_add_preset_relay)
        add_preset_relay_button.click()

    def click_apply_button_in_add_preset_relay_modal(self, driver):

        apply_button = driver.find_element(*self.xpath_add_preset_relay_select_confirm_button)
        apply_button.click()

    def click_save_button_in_add_preset_relay_confirm_modal(self, driver):

        # save preset relay
        save_button = driver.find_element(*self.xpath_add_preset_relay_save_button)
        save_button.click()

    def search_preset_relay_in_add_preset_relay_modal(self, driver, preset_relay):

        search_preset_relay_input = driver.find_element(*self.xpath_add_preset_relay_modal_input)
        search_preset_relay_input.send_keys(preset_relay)

        search_button = driver.find_element(*self.xpath_add_preset_relay_modal_search_button)
        search_button.click()

    ''' DNA MultiRelay TestCases '''

    def test_advanced_relay_tab_should_be_shown_if_domain_type_is_dna_shield(self):

        # get to dna shield domain edit page
        self.get_to_domain_configuration_edit_page(
            driver=self.driver,
            domain_id=self.fixture_dna_shield_domain_id_with_preset_relay)

        # find advanced relay tab
        self.wait_for_advanced_relay_tab(self.driver)


    def test_advanced_relay_tab_should_be_hidden_if_domain_type_is_not_dna_shield(self):

        self.get_to_domain_configuration_edit_page(
            driver=self.driver,
            domain_id=self.fixture_gslb_domain_id)

        # find advanced relay tab. TimeoutException will be occurred.
        # because this domain is not dna shield domain.
        with self.assertRaises(TimeoutException):
            self.wait_for_advanced_relay_tab(self.driver)

    def test_shield_domain_cannot_append_dynamic_relay_pop_when_preset_relay_is_set(self):

        self.get_to_domain_configuration_edit_page(
            driver=self.driver,
            domain_id=self.fixture_dna_shield_domain_id_with_preset_relay)

        self.wait_for_advanced_relay_tab(self.driver)
        self.move_to_advanced_relay_tab_menu(self.driver)

        # try to add pop
        self.wait_for_add_pop_button(self.driver)
        self.try_to_add_dynamic_pop(self.driver)

        # check alert popup text then close
        self.check_add_alert_popup_and_close(self.driver)

    def test_shield_domain_cannot_set_preset_relay_when_dynmic_pop_is_set(self):

        self.get_to_domain_configuration_edit_page(
            driver=self.driver,
            domain_id=self.fixture_dna_shield_domain_id_with_dynamic_relay_pop)

        self.wait_for_advanced_relay_tab(self.driver)
        self.move_to_advanced_relay_tab_menu(self.driver)

        # try to add preset relay
        self.wait_for_add_preset_relay_button(self.driver)
        self.click_add_preset_relay_button(self.driver)

        # check alert popup text then close
        self.check_add_alert_popup_and_close(self.driver)

    def test_shield_domain_preset_relay_should_be_removed_when_remove_action_served(self):

        self.get_to_domain_configuration_edit_page(
            driver=self.driver,
            domain_id=self.fixture_dna_shield_domain_id_with_preset_relay)

        self.wait_for_advanced_relay_tab(self.driver)
        self.move_to_advanced_relay_tab_menu(self.driver)

        # find preset relay delete buttons in each table items.
        # allows only one preset relay item
        preset_relay_delete_button_list = self.driver.find_elements(*self.xpath_delete_preset_relay_item)
        self.assertEqual(len(preset_relay_delete_button_list), 1)

        # try to remove preset relay
        preset_relay_delete_button_list[0].click()

        # remove confirm modal should be shown
        self.wait_for_delete_preset_relay_modal(self.driver)

        # confirm to delete preset relay
        self.click_delete_confirm_button_in_preset_relay_delete_modal(self.driver)

        # wait for delete
        time.sleep(3)

        # remove confirm modal should be hidden
        with self.assertRaises(TimeoutException):
            self.wait_for_delete_preset_relay_modal(self.driver)

        # recover fixture - add preset relay
        # find add preset relay butto
        self.click_add_preset_relay_button(self.driver)

        # find apply button & click (select first preset relay item)
        self.click_apply_button_in_add_preset_relay_modal(self.driver)
        self.click_save_button_in_add_preset_relay_confirm_modal(self.driver)

        # wait for add preset relay
        time.sleep(3)

        # find preset relay delete buttons in each table items.
        preset_relay_delete_button_list = self.driver.find_elements(*self.xpath_delete_preset_relay_item)
        self.assertEqual(len(preset_relay_delete_button_list), 1)

    def test_shield_domain_preset_relay_should_be_set_when_preset_relay_is_empty(self):

        self.get_to_domain_configuration_edit_page(
            driver=self.driver,
            domain_id=self.fixture_dna_shield_domain_id_with_empty_relay)

        self.wait_for_advanced_relay_tab(self.driver)
        self.move_to_advanced_relay_tab_menu(self.driver)

        # find add preset relay button
        self.wait_for_add_preset_relay_button(self.driver)
        self.click_add_preset_relay_button(self.driver)

        # find apply button & click (select first preset relay item)
        self.click_apply_button_in_add_preset_relay_modal(self.driver)
        self.click_save_button_in_add_preset_relay_confirm_modal(self.driver)

        # wait for cooldown
        time.sleep(3)

        # find preset relay delete buttons in each table items.
        # allows only one preset relay item
        preset_relay_delete_button_list = self.driver.find_elements(*self.xpath_delete_preset_relay_item)
        self.assertEqual(len(preset_relay_delete_button_list), 1)

        # wait for delete
        time.sleep(3)

        # recover fixture - remove added preset relay
        # try to delete preset relay
        preset_relay_delete_button_list[0].click()

        # confirm to delete preset relay
        self.click_delete_confirm_button_in_preset_relay_delete_modal(self.driver)

        # wait for delete
        time.sleep(3)

        # remove confirm modal should be hidden
        with self.assertRaises(TimeoutException):
            self.wait_for_delete_preset_relay_modal(self.driver)

    def test_searched_preset_relay_should_be_shown_in_add_preset_relay_modal(self):

        self.get_to_domain_configuration_edit_page(
            driver=self.driver,
            domain_id=self.fixture_dna_shield_domain_id_with_empty_relay)

        self.wait_for_advanced_relay_tab(self.driver)
        self.move_to_advanced_relay_tab_menu(self.driver)

        self.wait_for_add_preset_relay_button(self.driver)
        self.click_add_preset_relay_button(self.driver)

        # get preset relay item list
        # table should have 1 more preset relay item.
        preset_relay_list = self.driver.find_elements(*self.xpath_add_preset_relay_modal_relay_item)
        self.assertTrue(len(preset_relay_list) > 0)

        # send keys to search input
        self.search_preset_relay_in_add_preset_relay_modal(self.driver, 'CN')

        time.sleep(1)

        searched_relay_item_list = self.driver.find_elements(*self.xpath_add_preset_relay_modal_relay_item)
        self.assertEqual(len(searched_relay_item_list), 2)

    def test_preset_relay_item_should_be_changed_when_change_action_served(self):

        self.get_to_domain_configuration_edit_page(
            driver=self.driver,
            domain_id=self.fixture_dna_shield_domain_id_with_preset_relay)

        self.wait_for_advanced_relay_tab(self.driver)
        self.move_to_advanced_relay_tab_menu(self.driver)

        self.wait_for_add_preset_relay_button(self.driver)
        self.click_add_preset_relay_button(self.driver)

        # change preset relay to CN_US
        self.search_preset_relay_in_add_preset_relay_modal(self.driver, 'CN_US')

        searched_relay_item_list = self.driver.find_elements(*self.xpath_add_preset_relay_modal_relay_item)
        self.assertEqual(len(searched_relay_item_list), 1)

        target_radio_btn = self.driver.find_element(By.XPATH, "//input[@id='radio_CN_US']")
        target_radio_btn.click()

        self.click_apply_button_in_add_preset_relay_modal(self.driver)
        self.click_save_button_in_add_preset_relay_confirm_modal(self.driver)

        time.sleep(1)

        # changed preset relay should be exists
        self.driver.find_element(By.XPATH, '//td//span[contains(text(), "CN_US")]')

        # recover preset relay to CN_EU
        self.wait_for_add_preset_relay_button(self.driver)
        self.click_add_preset_relay_button(self.driver)

        self.search_preset_relay_in_add_preset_relay_modal(self.driver, 'CN_EU')

        searched_relay_item_list = self.driver.find_elements(*self.xpath_add_preset_relay_modal_relay_item)
        self.assertEqual(len(searched_relay_item_list), 1)

        target_radio_btn = self.driver.find_element(By.XPATH, "//input[@id='radio_CN_EU']")
        target_radio_btn.click()

        self.click_apply_button_in_add_preset_relay_modal(self.driver)
        self.click_save_button_in_add_preset_relay_confirm_modal(self.driver)

        # changed preset relay should be exists
        self.driver.find_element(By.XPATH, '//td//span[contains(text(), "CN_EU")]')
