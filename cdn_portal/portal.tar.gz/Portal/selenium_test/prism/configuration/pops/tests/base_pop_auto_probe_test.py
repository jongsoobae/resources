import unittest

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


class BasePopAutoProbeTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='hyejun.yim')
    def test_given_user_is_internal_user_when_display_base_pop_auto_probe_then_should_be_shown(self):
        driver = self.driver
        ###########################################################################################################
        driver.find_element(By.XPATH, "//a[@href = '#config']").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[text() = 'Pops']"))
        )
        driver.find_element(By.XPATH, "//a[text() = 'Pops']").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[@href = '/config/base/#/pops/config/484/']"))
        )
        driver.find_element(By.XPATH, "//a[@href = '/config/base/#/pops/config/484/']").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//label[text() = 'Auto Probe']"))
        )

        el1 = driver.find_element(By.XPATH, "//a[text() = 'Add Probeagent']")
        el2 = driver.find_element(By.XPATH, "//input[@id = 'ac_autoprobe_check']")
        el3 = driver.find_elements(By.XPATH, "//table/tbody/tr[@ng-repeat='probeagent in viewdata.probeagent_info']")
        probe_size = len(el3)

        if el2.is_selected():
            print("Auto Probe is selected")
            if el1.is_displayed():
                raise
            else:
                print("Add Probeagent button is not displayed")
                pass
        else:
            if probe_size > 1:
                print("Probe Agent Count >= 2")
                if el2.is_enabled():
                    print("Auto Probe is enabled")
                    pass
                else:
                    raise
            else:
                print("Probe Agent Count < 2")
                if el2.is_enabled():
                    raise
                else:
                    print("Auto Probe is disabled")
                    pass


        driver.find_element(By.XPATH, "//a[@href = '#/pops/']").click()
 
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[@href = '/config/base/#/pops/config/986/']"))
        )
        driver.find_element(By.XPATH, "//a[@href = '/config/base/#/pops/config/986/']").click()
 
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//label[text() = 'Auto Probe']"))
        )
 
        el1 = driver.find_element(By.XPATH, "//a[text() = 'Add Probeagent']")
        el2 = driver.find_element(By.XPATH, "//input[@id = 'ac_autoprobe_check']")
        el3 = driver.find_elements(By.XPATH, "//table/tbody/tr[@ng-repeat='probeagent in viewdata.probeagent_info']")
        probe_size = len(el3)

        if el2.is_selected():
            print("Auto Probe is selected")
            if el1.is_displayed():
                raise
            else:
                print("Add Probeagent button is not displayed")
                pass
        else:
            if probe_size > 1:
                print("Probe Agent Count >= 2")
                if el2.is_enabled():
                    print("Auto Probe is enabled")
                    pass
                else:
                    raise
            else:
                print("Probe Agent Count < 2")
                if el2.is_enabled():
                    raise
                else:
                    print("Auto Probe is disabled")
                    pass
        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
