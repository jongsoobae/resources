import random
import re
import time
from datetime import datetime

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait

from selenium_test.shared_components.conf import settings


def add_new_preset_relay(driver):
    # Go to preset menu
    go_to_preset_page(driver)

    WebDriverWait(driver, 30).until(
        EC.element_to_be_clickable((By.XPATH, "//button[@ng-click=\"movePresetRelayPage('new', '')\"]"))
    )

    # Click "Add Pre-set" button
    preset_add_btn = driver.find_element(By.XPATH, "//button[@ng-click=\"movePresetRelayPage('new', '')\"]")
    preset_add_btn.click()

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//input[@ng-model='dtl_preset_name']"))
    )

    # Get "Pre-set Name" input
    preset_name_input = driver.find_element(By.XPATH, "//input[@ng-model='dtl_preset_name']")

    date_str = datetime.now().strftime('%Y%m%d')
    random_number = int(random.random()*99999)
    retry = 10
    while retry:
        # To make preset name
        preset_name = "-".join(['preset', date_str, str(random_number)])
        preset_name_input.clear()
        preset_name_input.send_keys(preset_name)

        add_pop_to_relay(driver, 1)

        # Click "Save" button
        save_btn = driver.find_element(By.XPATH, "//button[@ng-click='savePresetRelay()']")
        save_btn.click()

        timeout = 30
        while timeout:
            time.sleep(5)
            try:
                # Check success message is displayed
                if driver.find_element(By.XPATH, "//div[@id='dtl_message_box']").is_displayed():
                    return preset_name
                # Check error message is displayed
                elif driver.find_element(By.XPATH, "//div[@id='edit_errornote' and contains(text(), 'Preset name already exists.')]").is_displayed():
                    break
                else:
                    timeout -= 5
                    pass
            except:
                timeout -= 5
                pass

        retry -= 1


def edit_preset_relay(driver, preset_name):
    # Go to preset menu
    go_to_preset_edit_page(driver, preset_name)

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//input[@ng-model='dtl_preset_name']"))
    )

    # Change preset name
    preset_name_input = driver.find_element(By.XPATH, "//input[@ng-model='dtl_preset_name']")
    preset_name_input.clear()
    preset_name_input.send_keys(preset_name + '_changed')

    # Click "Save" button
    save_btn = driver.find_element(By.XPATH, "//button[@ng-click='savePresetRelay()']")
    save_btn.click()

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//div[@id='dtl_message_box']//ul//li"))
    )

    # Get message
    msg = driver.find_element(By.XPATH, "//div[@id='dtl_message_box']//ul//li").text

    return msg


def delete_preset_relay(driver, preset_name):
    # Go to preset menu
    go_to_preset_page(driver)

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//input[@id='searchbar']"))
    )

    # Search preset by preset_name parameter
    search_input = driver.find_element(By.XPATH, "//input[@id='searchbar']")
    search_input.clear()
    search_input.send_keys(preset_name)
    search_input.send_keys(Keys.RETURN)

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//tbody[@ng-repeat='info in preset_list']//th//a[text()='" + preset_name + "']//../following-sibling::td/following-sibling::td//button[@ng-click='movePresetRelayPage(info.preset_id, info.preset_name)']"))
    )

    # Click "Delete" button
    delete_btn = driver.find_element(By.XPATH, "//tbody[@ng-repeat='info in preset_list']//th//a[text()='" + preset_name + "']//../following-sibling::td/following-sibling::td//button[@ng-click='openDeletePresetModal(info.preset_id, info.preset_name)']")
    delete_btn.click()

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//button[@ng-click='deletePreset(del_preset_id, del_preset_name)']"))
    )

    # Click "Yes. I'm sure" button
    delete_confirm_btn = driver.find_element(By.XPATH, "//button[@ng-click='deletePreset(del_preset_id, del_preset_name)']")
    delete_confirm_btn.click()

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//div[@id='list_message_box']//ul//li"))
    )

    # Get message
    msg = driver.find_element(By.XPATH, "//div[@id='list_message_box']//ul//li").text

    return msg


def go_to_preset_page(driver):
    # Go to Home
    driver.get(settings.PRISM_FE_URL + "/")

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//div[@id='leftnav']//ul//li//a[@href='#config']"))
    )

    # Click Configuration menu
    configuration_menu = driver.find_element(By.XPATH, "//div[@id='leftnav']//ul//li//a[@href='#config']")
    configuration_menu.click()

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//div[@id='leftnav']//ul//li//a[@href='/config/preset_relay/']"))
    )

    # Click Pre-set Relay menu
    preset_relay_menu = driver.find_element(By.XPATH, "//div[@id='leftnav']//ul//li//a[@href='/config/preset_relay/']")
    preset_relay_menu.click()


def go_to_preset_add_page(driver):
    go_to_preset_page(driver)

    WebDriverWait(driver, 30).until(
        EC.element_to_be_clickable((By.XPATH, "//button[@ng-click=\"movePresetRelayPage('new', '')\"]"))
    )

    # Click "Add Pre-set" button
    preset_add_btn = driver.find_element(By.XPATH, "//button[@ng-click=\"movePresetRelayPage('new', '')\"]")
    preset_add_btn.click()

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//input[@ng-model='dtl_preset_name']"))
    )


def go_to_preset_edit_page(driver, preset_name):
    go_to_preset_page(driver)

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//input[@id='searchbar']"))
    )

    # Search preset by preset_name parameter
    search_input = driver.find_element(By.XPATH, "//input[@id='searchbar']")
    search_input.clear()
    search_input.send_keys(preset_name)
    search_input.send_keys(Keys.RETURN)

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//tbody[@ng-repeat='info in preset_list']//th//a[text()='" + preset_name + "']//../following-sibling::td/following-sibling::td//button[@ng-click='movePresetRelayPage(info.preset_id, info.preset_name)']"))
    )

    # Click "Edit" button
    edit_btn = driver.find_element(By.XPATH, "//tbody[@ng-repeat='info in preset_list']//th//a[text()='" + preset_name + "']//../following-sibling::td/following-sibling::td//button[@ng-click='movePresetRelayPage(info.preset_id, info.preset_name)']")
    edit_btn.click()


def add_pop_to_relay(driver, relay_num, pop_name='', add_all=False):
    try:
        # Open all preset relay panel
        while driver.find_element(By.XPATH, "//button[@ng-click='addRelayBox()']").is_displayed():
            add_relay_btn = driver.find_element(By.XPATH, "//button[@ng-click='addRelayBox()']")
            add_relay_btn.click()  # Add relay
    except NoSuchElementException:
        pass

    # Click "Add POPs" button on relay
    relay1_add_pop_btn = driver.find_element(By.XPATH, "//button[@ng-click='openAddPOPs(" + str(relay_num) + ")']")
    relay1_add_pop_btn.click()

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//a[@ng-click='searchDinamicRelay()']"))
    )

    if add_all is False:
        # Set POP name to search
        pop_search_input = driver.find_element(By.XPATH, "//input[@ng-model='_add_relay.selected_search_pop']")
        pop_search_input.clear()
        pop_search_input.send_keys(pop_name)

    # Search POP
    search_btn = driver.find_element(By.XPATH, "//a[@ng-click='searchDinamicRelay()']")
    search_btn.click()

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//div[@id='add_danamicrelay_modal']//table//tbody//tr[1]//input[@ng-model='pop.checked']"))
    )

    if add_all is True:
        # Checking all button on POP list
        select_all_checkbox = driver.find_element(By.XPATH, "//div[@id='add_danamicrelay_modal']//table//thead//input[@ng-change='checkSearchedPop()']")
        select_all_checkbox.click()
    else:
        # Checking first on POP list
        checkbox_of_first_pop = driver.find_element(By.XPATH, "//div[@id='add_danamicrelay_modal']//table//tbody//tr[1]//input[@ng-model='pop.checked']")
        checkbox_of_first_pop.click()

    WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.XPATH, "//a[@ng-click='addRelayPops(relayBoxNum)']"))
    )

    # Click "Add POPs" button on modal
    add_pops_btn = driver.find_element(By.XPATH, "//a[@ng-click='addRelayPops(relayBoxNum)']")
    add_pops_btn.click()

    WebDriverWait(driver, 30).until(
        EC.invisibility_of_element_located((By.XPATH, "//div[@id='add_danamicrelay_modal']"))
    )

    WebDriverWait(driver, 30).until(
        EC.element_to_be_clickable((By.XPATH, "//button[@ng-click='savePresetRelay()']"))
    )


def remove_pop_from_relay(driver, relay_num, pop_name):
    delete_pop_btn = driver.find_element(By.XPATH, "//div[@id='relay_" + str(relay_num) + "_box']//table//tbody//tr//td[contains(text(), '" + pop_name + "')]/following-sibling::td//button[@class='close']")
    delete_pop_btn.click()


def get_preset_information(driver):
    """
        It returns preset name and pop list of each relays.
    """
    preset_info = {
        'relay': [
            [], [], []
        ]
    }

    # Wait loading image disappeared
    WebDriverWait(driver, 30).until(
        EC.invisibility_of_element_located((By.XPATH, "//img[@src='/op_media/shared/common/core/images/ajax-loader-big.gif']"))
    )

    # Find "Pre-set Name" input
    preset_name_input = driver.find_element(By.XPATH, "//input[@ng-model='dtl_preset_name']")

    # Get "Pre-set Name"
    preset_name = preset_name_input.get_attribute('value')
    preset_info['preset_name'] = preset_name

    # Get relay elements
    preset_relays = driver.find_elements(By.XPATH, "//form[@ng-show='preset_relay_loaded']//div[@class='well box-relay']")

    # Extract pop list from each relays
    for relay in preset_relays:
        relay_num = re.match(r'relay_(\d)_box', relay.get_attribute('id')).group(1)
        pops_on_relay = relay.find_elements(By.XPATH, "//div[@id='relay_" + relay_num + "_box']//table//tbody//tr//td[1]")

        for pop in pops_on_relay:
            # int(relay_num)-1 is to matching with python array index
            preset_info['relay'][int(relay_num)-1].append(pop.text)

    return preset_info


def chk_pop_name_is_exists_on_pop_search_result_by_relay(driver, relay_num, pop_name):
    # Click "Add POPs" button on relay to confirm pop_name exists in search result.
    relay2_add_pop_btn = driver.find_element(By.XPATH, "//button[@ng-click='openAddPOPs(" + str(relay_num) + ")']")
    relay2_add_pop_btn.click()

    # Set POP name to search
    pop_search_input = driver.find_element(By.XPATH, "//input[@ng-model='_add_relay.selected_search_pop']")
    pop_search_input.clear()
    pop_search_input.send_keys(pop_name)

    # Search POP
    search_btn = driver.find_element(By.XPATH, "//a[@ng-click='searchDinamicRelay()']")
    search_btn.click()

    # Wait until loading indicator is disappeared
    WebDriverWait(driver, 30).until(
        EC.invisibility_of_element_located((By.XPATH, "//div[@id='add_danamicrelay_modal']//img[src='/op_media/shared/common/core/images/ajax-loader-small.gif']"))
    )

    try:
        # Get pop name
        pop_name_searched = driver.find_element(By.XPATH, "//div[@id='add_danamicrelay_modal']//table//tbody//tr[1]//td[2]").text

        # Check pop name is same with pop_name
        is_exists = pop_name_searched == pop_name
    except NoSuchElementException:
        is_exists = False

    # Click "Close" button
    close_btn = driver.find_element(By.XPATH, "//a[text()='Close']")
    close_btn.click()

    WebDriverWait(driver, 30).until(
        EC.invisibility_of_element_located((By.XPATH, "//div[@id='add_danamicrelay_modal']"))
    )

    WebDriverWait(driver, 30).until(
        EC.element_to_be_clickable((By.XPATH, "//button[@ng-click='savePresetRelay()']"))
    )

    return is_exists



