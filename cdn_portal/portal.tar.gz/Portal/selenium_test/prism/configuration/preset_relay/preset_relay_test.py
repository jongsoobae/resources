import unittest2 as unittest
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.prism.configuration.domains import add_new_domain, delete_domain
from selenium_test.prism.configuration.preset_relay import add_new_preset_relay, go_to_preset_page, \
    go_to_preset_edit_page, add_pop_to_relay, remove_pop_from_relay, get_preset_information, \
    chk_pop_name_is_exists_on_pop_search_result_by_relay, go_to_preset_add_page
from selenium_test.prism.configuration.preset_relay import delete_preset_relay
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


class PresetRelayListPageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

        # Add new preset
        self.test_preset_name = add_new_preset_relay(self.driver)

    def tearDown(self):
        delete_preset_relay(self.driver, self.test_preset_name)
        self.driver.quit()

    def test_preset_list_page(self):
        driver = self.driver
        go_to_preset_page(driver)

        # Get "Add Pre-set" button element
        preset_add_btn = driver.find_element(By.XPATH, '//button[@ng-click="movePresetRelayPage(\'new\', \'\')"]')

        # Check "Add Pre-set" button is found
        self.assertTrue(isinstance(preset_add_btn, WebElement))
        self.assertEqual(preset_add_btn.text, 'Add Pre-set')

        # Search preset by preset_name parameter
        search_input = driver.find_element(By.XPATH, "//input[@id='searchbar']")
        search_input.clear()
        search_input.send_keys(self.test_preset_name)
        search_input.send_keys(Keys.RETURN)

        # Wait loading image appeared
        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//img[@src='/op_media/shared/common/core/images/ajax-loader-big.gif']"))
        )

        # Wait loading image disappeared
        WebDriverWait(driver, 30).until(
            EC.invisibility_of_element_located((By.XPATH, "//img[@src='/op_media/shared/common/core/images/ajax-loader-big.gif']"))
        )

        # Get searched result
        preset_list = driver.find_elements(By.XPATH, "//tbody[@ng-repeat='info in preset_list']//th//a")
        preset_name_list = [preset.text for preset in preset_list]

        # Check all of preset contains search string.
        for preset_name in preset_name_list:
            self.assertIn(self.test_preset_name, preset_name)

        # Get "Edit" button element
        edit_btn = driver.find_element(By.XPATH, "//tbody[@ng-repeat='info in preset_list']//th//a[text()='" + self.test_preset_name + "']//../following-sibling::td/following-sibling::td//button[@ng-click='movePresetRelayPage(info.preset_id, info.preset_name)']")

        # Check "Edit" button is found
        self.assertTrue(isinstance(edit_btn, WebElement))
        self.assertEqual(edit_btn.text, 'Edit')

        # Get "Delete" button element
        delete_btn = driver.find_element(By.XPATH, "//tbody[@ng-repeat='info in preset_list']//th//a[text()='" + self.test_preset_name + "']//../following-sibling::td/following-sibling::td//button[@ng-click='openDeletePresetModal(info.preset_id, info.preset_name)']")

        # Check "Delete" button is found
        self.assertTrue(isinstance(delete_btn, WebElement))
        self.assertEqual(delete_btn.text, 'Delete')

        # Click 'Edit' button
        edit_btn.click()

    def test_delete_preset_used_by_dna_shield_domain(self):
        driver = self.driver
        # Create DNA shield domain
        domain_name = add_new_domain(driver, 'DNA_SHIELD')  # 3 means DNA_SHIELD_DOMAIN

        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//li[@id=\"relaytab\"]"))
        )

        # Click 'Advanced Relay' tab
        advanced_relay_tab = driver.find_element(By.XPATH, "//li[@id=\"relaytab\"]")
        advanced_relay_tab.click()

        WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//a[@id=\"btn_search_preset_relay\"]"))
        )

        # Click 'Add Pre-set Relay' button
        advanced_relay_tab = driver.find_element(By.XPATH, "//a[@id=\"btn_search_preset_relay\"]")
        advanced_relay_tab.click()

        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//input[@ng-model=\"_preset.selected_search_preset\"]"))
        )

        # Search preset by test_preset_name parameter
        search_input = driver.find_element(By.XPATH, "//input[@ng-model=\"_preset.selected_search_preset\"]")
        search_input.clear()
        search_input.send_keys(self.test_preset_name)

        # Click search button
        search_btn = driver.find_element(By.XPATH, "//a[@ng-click=\"searchPresetRelay(_preset.selected_search_preset)\"]")
        search_btn.click()

        # Click 'Apply' button
        apply_btn = driver.find_element(By.XPATH, "//a[@ng-click='openDomainPresetRelay()']")
        apply_btn.click()

        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//a[@ng-click=\"saveDomainPresetRelay('modify')\"]"))
        )

        # Click 'Yes' button to confirm
        yes_btn = driver.find_element(By.XPATH, "//a[@ng-click=\"saveDomainPresetRelay('modify')\"]")
        yes_btn.click()

        # Go to preset page
        go_to_preset_page(driver)

        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//input[@id='searchbar']"))
        )

        # Search preset by preset_name parameter
        search_input = driver.find_element(By.XPATH, "//input[@id='searchbar']")
        search_input.clear()
        search_input.send_keys(self.test_preset_name)
        search_input.send_keys(Keys.RETURN)

        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//tbody[@ng-repeat='info in preset_list']//th//a[text()='" + self.test_preset_name + "']//../following-sibling::td/following-sibling::td//button[@ng-click='movePresetRelayPage(info.preset_id, info.preset_name)']"))
        )

        # Click "Delete" button
        delete_btn = driver.find_element(By.XPATH, "//tbody[@ng-repeat='info in preset_list']//th//a[text()='" + self.test_preset_name + "']//../following-sibling::td/following-sibling::td//button[@ng-click='openDeletePresetModal(info.preset_id, info.preset_name)']")
        delete_btn.click()

        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//div[@id='preset_relate_items']//ul//li/following-sibling::ul//li[text()='" + domain_name + "']"))
        )

        # Check "No" button has "data-dismiss" attribute.
        no_btn = driver.find_element(By.XPATH, "//div[@id='delete_preset_modal']//div[@class='modal-footer']//button[text()='No']")
        self.assertEqual(no_btn.get_attribute('data-dismiss'), 'modal')

        # Check "Yes. I'm sure" button does not exists.
        with self.assertRaises(NoSuchElementException):
            driver.find_element(By.XPATH, "//button[@ng-click='deletePreset(del_preset_id, del_preset_name)']")

        # Delete DNA shield domain
        delete_domain(driver, domain_name)

    def test_preset_update_with_three_relay(self):
        driver = self.driver
        go_to_preset_edit_page(driver, self.test_preset_name)

        # Get preset information
        preset_info = get_preset_information(driver)

        # Clear "Pre-set Name" input
        preset_name_input = driver.find_element(By.XPATH, "//input[@ng-model='dtl_preset_name']")
        preset_name_input.clear()

        # Click "Save" button
        save_btn = driver.find_element(By.XPATH, "//button[@ng-click='savePresetRelay()']")
        save_btn.click()

        # Get alert message
        alert_message = driver.switch_to_alert().text
        # Close alert box
        driver.switch_to_alert().accept()

        # Check alert message
        self.assertEqual(alert_message, 'Pre-set Name is required.')

        # Set "Pre-set Name" input to previous value
        preset_name_input.send_keys(preset_info['preset_name'])

        # Delete pops on relay 1
        relay_1_pops = driver.find_elements(By.XPATH, "//div[@id='relay_1_box']//table//tbody//tr//td[1]")
        relay_1_pop_list = []
        for pop in relay_1_pops:
            relay_1_pop_list.append(pop.text)

        for pop_name in relay_1_pop_list:
            remove_pop_from_relay(driver, 1, pop_name)

        # Click "Save" button
        save_btn = driver.find_element(By.XPATH, "//button[@ng-click='savePresetRelay()']")
        save_btn.click()

        # Get alert message
        alert_message = driver.switch_to_alert().text
        # Close alert box
        driver.switch_to_alert().accept()

        # Check alert message
        self.assertEqual(alert_message, 'Relay 1\'s POP is required.')

        # Click "Reset" button
        reset_btn = driver.find_element(By.XPATH, "//button[@ng-click='resetPresetRelay()']")
        reset_btn.click()

        # Get preset information after reset
        preset_info_after_reset = get_preset_information(driver)

        # Check both values are same.
        self.assertEqual(preset_info, preset_info_after_reset)

        # Change preset name
        preset_name_input.clear()
        preset_name_input.send_keys(preset_info['preset_name'] + '_changed')

        # Fill each relays with all pops
        add_pop_to_relay(driver, 1, add_all=True)
        add_pop_to_relay(driver, 2, add_all=True)
        add_pop_to_relay(driver, 3, add_all=True)

        # Click "Save" button
        save_btn = driver.find_element(By.XPATH, "//button[@ng-click='savePresetRelay()']")
        save_btn.click()

        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//div[@id='dtl_message_box']//ul//li"))
        )

        # Get message
        msg = driver.find_element(By.XPATH, "//div[@id='dtl_message_box']//ul//li").text

        # Check preset is changed successfully
        self.assertEqual(msg, 'Pre-set Relay "' + preset_info['preset_name'] + '" was changed successfully.')

        # Update test_preset_name
        self.test_preset_name = preset_info['preset_name'] + '_changed'

        # Check current page is "Pre-Set Relay Edit" page
        sub_title = driver.find_element(By.XPATH, "//h1[@id='preset_relay_title']").text
        self.assertEqual(sub_title, 'Pre-Set Relay Edit')

        # Get preset information after save
        preset_info_after_save = get_preset_information(driver)

        # Change preset name to test cancel button
        preset_name_input.clear()
        preset_name_input.send_keys(preset_info['preset_name'] + '_canceled')

        # Remove relay 3 to test cancel button
        delete_btn_for_relay3 = driver.find_element(By.XPATH, "//button[@ng-click='deleteRelayBox(3)']")
        delete_btn_for_relay3.click()

        # Click "Cancel" button. It makes browser moves to preset list page.
        cancel_btn = driver.find_element(By.XPATH, "//button[@ng-click='backPresetListPage()']")
        cancel_btn.click()

        # Go to Edit page
        go_to_preset_edit_page(driver, preset_info_after_save['preset_name'])

        # Get preset information after cancel
        preset_info_after_cancel = get_preset_information(driver)

        # Check preset information is same with preset_info_after_save
        self.assertEqual(preset_info_after_save, preset_info_after_cancel)

    def test_preset_add_with_three_relay(self):
        driver = self.driver
        go_to_preset_add_page(driver)

        # Click "Pre-set Relay List" on navigation links.
        preset_relay_list_link = driver.find_element(By.XPATH, "//a[text()='Pre-set Relay List']")
        preset_relay_list_link.click()

        # Wait loading image disappeared
        WebDriverWait(driver, 30).until(
            EC.invisibility_of_element_located((By.XPATH, "//img[@src='/op_media/shared/common/core/images/ajax-loader-big.gif']"))
        )

        # Check current page is preset list page.
        self.assertTrue(driver.find_element(By.XPATH, "//h1[text()='Pre-Set Relay List']"))

        # Return to preset add page
        go_to_preset_add_page(driver)

        # Click "Add Pre-set Relay" on navigation links.
        preset_relay_add_link = driver.find_element(By.XPATH, "//a[text()='Add Pre-set Relay']")
        preset_relay_add_link.click()

        # Wait loading image disappeared
        WebDriverWait(driver, 30).until(
            EC.invisibility_of_element_located((By.XPATH, "//img[@src='/op_media/shared/common/core/images/ajax-loader-big.gif']"))
        )

        # Check current page is preset list page.
        self.assertTrue(driver.find_element(By.XPATH, "//h1[text()='Pre-Set Relay Add']"))

        # Return to preset add page
        go_to_preset_add_page(driver)

        # Get "Pre-set Name" input
        preset_name_input = driver.find_element(By.XPATH, "//input[@ng-model='dtl_preset_name']")

        # Set "Pre-set Name" to self.test_preset_name to confirm duplicated name error is occurred.
        preset_name_input.clear()
        preset_name_input.send_keys(self.test_preset_name)

        # Add random pop to save preset relay 1
        add_pop_to_relay(driver, 1)

        # Click "Save" button
        save_btn = driver.find_element(By.XPATH, "//button[@ng-click='savePresetRelay()']")
        save_btn.click()

        # Wait until error message is appeared.
        WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//div[@id='edit_errornote']"))
        )

        # Get error message
        error_msg = driver.find_element(By.XPATH, "//div[@id='edit_errornote']").text

        # Check error message means preset name is duplicated
        self.assertEqual(error_msg, "preset_name : Pre-set name is duplicated")

        # Add random pop to save preset relay 3 to confirm error is occurred.
        # Because at least one pop is included in relay 2 to save this preset
        add_pop_to_relay(driver, 3)

        # Click "Save" button
        save_btn = driver.find_element(By.XPATH, "//button[@ng-click='savePresetRelay()']")
        save_btn.click()

        # Get alert message
        alert_message = driver.switch_to_alert().text
        # Close alert box
        driver.switch_to_alert().accept()

        # Check alert message
        self.assertEqual(alert_message, 'To configure the Relay-3 must necessarily Relay-1 and Relay-2.')

        # Add pop (P59-ICN) to relay 2
        add_pop_to_relay(driver, 2, pop_name='P59-ICN')

        # Check 'P59-ICN' pop doesn't exists in pop search result about relay 2. Because it is already added on relay 2
        is_exists = chk_pop_name_is_exists_on_pop_search_result_by_relay(driver, 2, 'P59-ICN')
        self.assertFalse(is_exists)

        # Check 'P59-ICN' pop exists in pop search result about relay 1. Because it isn't already added on relay 1
        is_exists = chk_pop_name_is_exists_on_pop_search_result_by_relay(driver, 1, 'P59-ICN')
        self.assertTrue(is_exists)

        # Check 'P59-ICN' pop exists in pop search result about relay 3. Because it isn't already added on relay 3
        is_exists = chk_pop_name_is_exists_on_pop_search_result_by_relay(driver, 3, 'P59-ICN')
        self.assertTrue(is_exists)

        # Add 'P59-ICN' pop to relay 1 and 2
        add_pop_to_relay(driver, 1, pop_name='P59-ICN')
        add_pop_to_relay(driver, 3, pop_name='P59-ICN')

        # Check 'P59-ICN' pop added on relay 1
        self.assertTrue(
                driver.find_element(By.XPATH,
                                    "//div[@id='relay_1_box']//table//tbody//tr//td[contains(text(), 'P59-ICN')]")
                .is_displayed())

        # Check 'P59-ICN' pop added on relay 3
        self.assertTrue(
                driver.find_element(By.XPATH,
                                    "//div[@id='relay_3_box']//table//tbody//tr//td[contains(text(), 'P59-ICN')]")
                .is_displayed())

        # Append '_to_add' to confirm preset is saved successfully
        preset_name_input.send_keys('_to_add')

        # Click "Save" button
        save_btn = driver.find_element(By.XPATH, "//button[@ng-click='savePresetRelay()']")
        save_btn.click()

        # Get message
        msg = driver.find_element(By.XPATH, "//div[@id='dtl_message_box']//ul//li").text

        # Check preset is changed successfully
        self.assertEqual(msg, 'Pre-set Relay "' + self.test_preset_name + '_to_add' + '" was added successfully.')

        # Delete preset to just clean up
        delete_preset_relay(driver, self.test_preset_name + '_to_add')
