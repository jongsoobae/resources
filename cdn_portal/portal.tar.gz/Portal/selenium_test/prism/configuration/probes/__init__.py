from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
from selenium_test.shared_components.testcase import PrismTestCase

class ProbesTryCountTestCase(PrismTestCase):

    REQUEST_WAIT_LIMIT = 2

    def get_probe_name_input_element(self):
        probe_name_element = self.driver.find_element(By.ID, "probe_name")
        self.assertIsNotNone(probe_name_element)

        return probe_name_element

    def get_try_count_input_element(self):
        try_count_element = self.driver.find_element(By.ID, "try_count")
        self.assertIsNotNone(try_count_element)

        return try_count_element

    def get_iterval_input_element(self):
        interval_element = self.driver.find_element(By.ID, "interval")
        self.assertIsNotNone(interval_element)

        return interval_element

    def get_port_input_element(self):
        port_element = self.driver.find_element(By.ID, "id_port")
        self.assertIsNotNone(port_element)

        return port_element

    def get_oid_input_element(self):
        oid_element = self.driver.find_element(By.ID, "id_oid")
        self.assertIsNotNone(oid_element)

        return oid_element

    def get_probe_save_button(self):
        probe_save_button = self.driver.find_element(By.ID, "btn_save")
        self.assertIsNotNone(probe_save_button)

        return probe_save_button

    def get_probe_delete_button(self):
        probe_delete_button = self.driver.find_element(
                                By.XPATH, "//a[@ng-click='doDelete(delete_modal.probeconfig_id)']")
        self.assertIsNotNone(probe_delete_button)

        return probe_delete_button

    def get_probe_delete_modal_open_button(self, probe_name):
        probe_row = self.driver.find_element(
                        By.XPATH, "//a[text() = '" + probe_name + "']")
        self.assertIsNotNone(probe_row)
        probe_delete_modal = probe_row.find_element(
                                By.XPATH, ".//ancestor::tr//button[@title='Delete']")

        return probe_delete_modal

    def get_try_count_message(self, try_count_container):
        return try_count_container.find_element(
            By.XPATH, ".//ancestor::div//span//code//strong").text

    def get_probe_save_success_message(self):
        return self.driver.find_element(
            By.XPATH, "//div[@id='list_message_box']//ul//li").text

    def wait_for_save_button(self):
        WebDriverWait(self.driver, 120).until(
            EC.element_to_be_clickable((By.ID, "btn_save"))
        )

    def wait_for_try_count_textbox(self):
        WebDriverWait(self.driver, 120).until(
            EC.presence_of_element_located((By.ID, "try_count"))
        )

    def wait_for_loading_indicator(self):
        # Wait loading image appeared
        WebDriverWait(self.driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//div[@id='content-right']//img[@src='/op_media/shared/common/core/images/ajax-loader-big.gif']"))
        )
        # Wait until loading indicator is disappeared
        WebDriverWait(self.driver, 30).until(
            EC.invisibility_of_element_located((By.XPATH, "//div[@id='content-right']//img[@src='/op_media/shared/common/core/images/ajax-loader-big.gif']"))
        )

    def wait_for_delete_probe_modal_open(self):
        WebDriverWait(self.driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//a[@ng-click='doDelete(delete_modal.probeconfig_id)']"))
        )

    def get_save_message(self, probe_info, probe_name):
        return 'The ' + probe_info + ' probe "' + probe_name + '" was added successfully.'

    @classmethod
    def setUpClass(cls):
        super(ProbesTryCountTestCase, cls).setUpClass()

        # move to probes Pages
        cls.direct_to('/config/probes/')
