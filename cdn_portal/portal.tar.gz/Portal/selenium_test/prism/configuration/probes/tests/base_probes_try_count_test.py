
from time import sleep
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from selenium_test.prism.configuration.probes import ProbesTryCountTestCase


class BaseProbesTryCountTest(ProbesTryCountTestCase):

    icmp_probe_test = 'icmp_try_count_test'
    snmp_probe_test = 'snmp_try_count_test'
    tcp_probe_test = 'tcp_try_count_test'
    ssl_probe_test = 'ssl_try_count_test'
    udp_probe_test = 'udp_try_count_test'
    ftp_probe_test = 'ftp_try_count_test'
    rtmp_probe_test = 'rtmp_try_count_test'
    dns_probe_test = 'dns_try_count_test'
    aggregate_probe_test = 'aggregate_test'

    false_test_interval = 3
    true_test_interval = 10
    test_try_count = 2
    test_oid = 30
    test_port = 8000

    try_count_err_msg = 'This field is invalied. ((Try Count * Timeout) + Try Count)8.0 < 3(Interval)'

    def test_set_try_count_value_then_icmp_probe_page(self):
        driver = self.driver
        ###########################################################################
        # ICMP TEST
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[text()='ICMP']"))
        )
        driver.find_element(By.XPATH, "//a[text()='ICMP']").click()

        self.wait_for_save_button()
        self.wait_for_try_count_textbox()

        # Set probe name
        icmp_probe_name = self.get_probe_name_input_element()
        icmp_probe_name.clear()
        icmp_probe_name.send_keys(self.icmp_probe_test)

        # try_count validate : (try_count * timeout) + try_count < interval
        # try_count : 2, timeout : 3.0(default), interval : 3
        # => (2*3.0) + 2 < 3 => False
        # Set interval
        icmp_interval = self.get_iterval_input_element()
        icmp_interval.clear()
        icmp_interval.send_keys(self.false_test_interval)
        # Set Try count
        icmp_try_count = self.get_try_count_input_element()
        icmp_try_count.clear()
        icmp_try_count.send_keys(self.test_try_count)

        # Click "Save" button
        self.get_probe_save_button().click()
        sleep(self.REQUEST_WAIT_LIMIT)

        # Check "This field is invalied." message
        # Get try_count error message element
        icmp_try_count = self.get_try_count_input_element()
        icmp_try_count_msg = self.get_try_count_message(icmp_try_count)
        self.assertEqual(icmp_try_count_msg, self.try_count_err_msg)

        # try_count : 2, timeout : 3.0(default), interval : 10
        # => (2*3.0) + 2 < 10 => True
        # Set interval
        icmp_interval = self.get_iterval_input_element()
        icmp_interval.clear()
        icmp_interval.send_keys(self.true_test_interval)

        # Click "Save" button
        self.get_probe_save_button().click()

        # Wait until loading indicator is disappeared
        self.wait_for_loading_indicator()

        # Check probes save successfully
        self.assertEqual(self.get_probe_save_success_message(),
                         self.get_save_message('icmp', self.icmp_probe_test))

        # Click Delete modal open button
        self.get_probe_delete_modal_open_button(self.icmp_probe_test).click()

        # Delete probe
        self.wait_for_delete_probe_modal_open()
        self.get_probe_delete_button().click()

        # Wait until loading indicator is disappeared
        self.wait_for_loading_indicator()

        # Delete Check
        with self.assertRaises(NoSuchElementException):
            driver.find_element(By.XPATH, "//a[text() = '" + self.icmp_probe_test + "']")
        ###########################################################################

    def test_set_try_count_value_then_snmp_probe_page(self):
        driver = self.driver
        ###########################################################################
        # SNMP TEST
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[text()='SNMP']"))
        )
        driver.find_element(By.XPATH, "//a[text()='SNMP']").click()

        self.wait_for_save_button()
        self.wait_for_try_count_textbox()

        # Set probe name
        snmp_probe_name = self.get_probe_name_input_element()
        snmp_probe_name.clear()
        snmp_probe_name.send_keys(self.snmp_probe_test)

        # Set Oid
        snmp_oid = self.get_oid_input_element()
        snmp_oid.clear()
        snmp_oid.send_keys(self.test_oid)

        # try_count validate : (try_count * timeout) + try_count < interval
        # try_count : 2, timeout : 3.0(default), interval : 3
        # => (2*3.0) + 2 < 3 => False
        # Set interval
        snmp_interval = self.get_iterval_input_element()
        snmp_interval.clear()
        snmp_interval.send_keys(self.false_test_interval)
        # Set Try count
        snmp_try_count = self.get_try_count_input_element()
        snmp_try_count.clear()
        snmp_try_count.send_keys(self.test_try_count)

        # Click "Save" button
        self.get_probe_save_button().click()
        sleep(self.REQUEST_WAIT_LIMIT)

        # Check "This field is invalied." message
        # Get try_count error message element
        snmp_try_count = self.get_try_count_input_element()
        snmp_try_count_msg = self.get_try_count_message(snmp_try_count)
        self.assertEqual(snmp_try_count_msg, self.try_count_err_msg)

        # try_count : 2, timeout : 3.0(default), interval : 10
        # => (2*3.0) + 2 < 10 => True
        # Set interval
        snmp_interval = self.get_iterval_input_element()
        snmp_interval.clear()
        snmp_interval.send_keys(self.true_test_interval)

        # Click "Save" button
        self.get_probe_save_button().click()

        # Wait until loading indicator is disappeared
        self.wait_for_loading_indicator()

        # Check probes save successfully
        self.assertEqual(self.get_probe_save_success_message(),
                         self.get_save_message('snmp', self.snmp_probe_test))

        # Click Delete modal open button
        self.get_probe_delete_modal_open_button(self.snmp_probe_test).click()

        # Delete probe
        self.wait_for_delete_probe_modal_open()
        self.get_probe_delete_button().click()

        # Wait until loading indicator is disappeared
        self.wait_for_loading_indicator()

        # Delete Check
        with self.assertRaises(NoSuchElementException):
            driver.find_element(By.XPATH, "//a[text() = '" + self.snmp_probe_test + "']")
        ###########################################################################

    def test_set_try_count_value_then_tcp_probe_page(self):
        driver = self.driver
        ###########################################################################
        # TCP TEST
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[text()='TCP']"))
        )
        driver.find_element(By.XPATH, "//a[text()='TCP']").click()

        self.wait_for_save_button()
        self.wait_for_try_count_textbox()

        # Set probe name
        tcp_probe_name = self.get_probe_name_input_element()
        tcp_probe_name.clear()
        tcp_probe_name.send_keys(self.tcp_probe_test)

        # Set port
        tcp_port = self.get_port_input_element()
        tcp_port.clear()
        tcp_port.send_keys(self.test_port)

        # try_count validate : (try_count * timeout) + try_count < interval
        # try_count : 2, timeout : 3.0(default), interval : 3
        # => (2*3.0) + 2 < 3 => False
        # Set interval
        tcp_interval = self.get_iterval_input_element()
        tcp_interval.clear()
        tcp_interval.send_keys(self.false_test_interval)
        # Set Try count
        tcp_try_count = self.get_try_count_input_element()
        tcp_try_count.clear()
        tcp_try_count.send_keys(self.test_try_count)

        # Click "Save" button
        self.get_probe_save_button().click()
        sleep(self.REQUEST_WAIT_LIMIT)

        # Check "This field is invalied." message
        # Get try_count error message element
        tcp_try_count = self.get_try_count_input_element()
        tcp_try_count_msg = self.get_try_count_message(tcp_try_count)
        self.assertEqual(tcp_try_count_msg, self.try_count_err_msg)

        # try_count : 2, timeout : 3.0(default), interval : 10
        # => (2*3.0) + 2 < 10 => True
        # Set interval
        tcp_interval = self.get_iterval_input_element()
        tcp_interval.clear()
        tcp_interval.send_keys(self.true_test_interval)

        # Click "Save" button
        self.get_probe_save_button().click()

        # Wait until loading indicator is disappeared
        self.wait_for_loading_indicator()

        # Check probes save successfully
        self.assertEqual(self.get_probe_save_success_message(),
                         self.get_save_message('tcp', self.tcp_probe_test))
 
        # Click Delete modal open button
        self.get_probe_delete_modal_open_button(self.tcp_probe_test).click()

        # Delete probe
        self.wait_for_delete_probe_modal_open()
        self.get_probe_delete_button().click()

        # Wait until loading indicator is disappeared
        self.wait_for_loading_indicator()

        # Delete Check
        with self.assertRaises(NoSuchElementException):
            driver.find_element(By.XPATH, "//a[text() = '" + self.tcp_probe_test + "']")
        ###########################################################################

    def test_set_try_count_value_then_ssl_probe_page(self):
        driver = self.driver
        ###########################################################################
        # SSL TEST
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[text()='SSL']"))
        )
        driver.find_element(By.XPATH, "//a[text()='SSL']").click()

        self.wait_for_save_button()
        self.wait_for_try_count_textbox()

        # Set probe name
        ssl_probe_name = self.get_probe_name_input_element()
        ssl_probe_name.clear()
        ssl_probe_name.send_keys(self.ssl_probe_test)

        # try_count validate : (try_count * timeout) + try_count < interval
        # try_count : 2, timeout : 3.0(default), interval : 3
        # => (2*3.0) + 2 < 3 => False
        # Set interval
        ssl_interval = self.get_iterval_input_element()
        ssl_interval.clear()
        ssl_interval.send_keys(self.false_test_interval)
        # Set Try count
        ssl_try_count = self.get_try_count_input_element()
        ssl_try_count.clear()
        ssl_try_count.send_keys(self.test_try_count)

        # Click "Save" button
        self.get_probe_save_button().click()
        sleep(self.REQUEST_WAIT_LIMIT)

        # Check "This field is invalied." message
        # Get try_count error message element
        ssl_try_count = self.get_try_count_input_element()
        ssl_try_count_msg = self.get_try_count_message(ssl_try_count)
        self.assertEqual(ssl_try_count_msg, self.try_count_err_msg)

        # try_count : 2, timeout : 3.0(default), interval : 10
        # => (2*3.0) + 2 < 10 => True
        # Set interval
        ssl_interval = self.get_iterval_input_element()
        ssl_interval.clear()
        ssl_interval.send_keys(self.true_test_interval)

        # Click "Save" button
        self.get_probe_save_button().click()

        # Wait until loading indicator is disappeared
        self.wait_for_loading_indicator()

        # Check probes save successfully
        self.assertEqual(self.get_probe_save_success_message(),
                         self.get_save_message('ssl', self.ssl_probe_test))

        # Click Delete modal open button
        self.get_probe_delete_modal_open_button(self.ssl_probe_test).click()

        # Delete probe
        self.wait_for_delete_probe_modal_open()
        self.get_probe_delete_button().click()

        # Wait until loading indicator is disappeared
        self.wait_for_loading_indicator()

        # Delete Check
        with self.assertRaises(NoSuchElementException):
            driver.find_element(By.XPATH, "//a[text() = '" + self.ssl_probe_test + "']")
        ###########################################################################

    def test_set_try_count_value_then_udp_probe_page(self):
        driver = self.driver
        ###########################################################################
        # UDP TEST
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[text()='UDP']"))
        )
        driver.find_element(By.XPATH, "//a[text()='UDP']").click()

        self.wait_for_save_button()
        self.wait_for_try_count_textbox()

        # Set probe name
        udp_probe_name = self.get_probe_name_input_element()
        udp_probe_name.clear()
        udp_probe_name.send_keys(self.udp_probe_test)

        # Set "Port" element
        udp_port = self.get_port_input_element()
        udp_port.clear()
        udp_port.send_keys(self.test_port)

        # try_count validate : (try_count * timeout) + try_count < interval
        # try_count : 2, timeout : 3.0(default), interval : 3
        # => (2*3.0) + 2 < 3 => False
        # Set interval
        udp_interval = self.get_iterval_input_element()
        udp_interval.clear()
        udp_interval.send_keys(self.false_test_interval)
        # Set Try count
        udp_try_count = self.get_try_count_input_element()
        udp_try_count.clear()
        udp_try_count.send_keys(self.test_try_count)

        # Click "Save" button
        self.get_probe_save_button().click()
        sleep(self.REQUEST_WAIT_LIMIT)

        # Check "This field is invalied." message
        # Get try_count error message element
        udp_try_count = self.get_try_count_input_element()
        udp_try_count_msg = self.get_try_count_message(udp_try_count)
        self.assertEqual(udp_try_count_msg, self.try_count_err_msg)

        # try_count : 2, timeout : 3.0(default), interval : 10
        # => (2*3.0) + 2 < 10 => True
        # Set interval
        udp_interval = self.get_iterval_input_element()
        udp_interval.clear()
        udp_interval.send_keys(self.true_test_interval)

        # Click "Save" button
        self.get_probe_save_button().click()

        # Wait until loading indicator is disappeared
        self.wait_for_loading_indicator()

        # Check probes save successfully
        self.assertEqual(self.get_probe_save_success_message(),
                         self.get_save_message('udp', self.udp_probe_test))

        # Click Delete modal open button
        self.get_probe_delete_modal_open_button(self.udp_probe_test).click()

        # Delete probe
        self.wait_for_delete_probe_modal_open()
        self.get_probe_delete_button().click()

        # Wait until loading indicator is disappeared
        self.wait_for_loading_indicator()

        # Delete Check
        with self.assertRaises(NoSuchElementException):
            driver.find_element(By.XPATH, "//a[text() = '" + self.udp_probe_test + "']")
        ###########################################################################

    def test_set_try_count_value_then_ftp_probe_page(self):
        driver = self.driver
        ###########################################################################
        # FTP TEST
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[text()='FTP']"))
        )
        driver.find_element(By.XPATH, "//a[text()='FTP']").click()

        self.wait_for_save_button()
        self.wait_for_try_count_textbox()

        # Set probe name
        ftp_probe_name = self.get_probe_name_input_element()
        ftp_probe_name.clear()
        ftp_probe_name.send_keys(self.ftp_probe_test)

        # try_count validate : (try_count * timeout) + try_count < interval
        # try_count : 2, timeout : 3.0(default), interval : 3
        # => (2*3.0) + 2 < 3 => False
        # Set interval
        ftp_interval = self.get_iterval_input_element()
        ftp_interval.clear()
        ftp_interval.send_keys(self.false_test_interval)
        # Set Try count
        ftp_try_count = self.get_try_count_input_element()
        ftp_try_count.clear()
        ftp_try_count.send_keys(self.test_try_count)

        # Click "Save" button
        self.get_probe_save_button().click()
        sleep(self.REQUEST_WAIT_LIMIT)

        # Check "This field is invalied." message
        # Get try_count error message element
        ftp_try_count = self.get_try_count_input_element()
        ftp_try_count_msg = self.get_try_count_message(ftp_try_count)
        self.assertEqual(ftp_try_count_msg, self.try_count_err_msg)

        # try_count : 2, timeout : 3.0(default), interval : 10
        # => (2*3.0) + 2 < 10 => True
        # Set interval
        ftp_interval = self.get_iterval_input_element()
        ftp_interval.clear()
        ftp_interval.send_keys(self.true_test_interval)

        # Click "Save" button
        self.get_probe_save_button().click()

        # Wait until loading indicator is disappeared
        self.wait_for_loading_indicator()

        # Check probes save successfully
        self.assertEqual(self.get_probe_save_success_message(),
                         self.get_save_message('ftp', self.ftp_probe_test))

        # Click Delete modal open button
        self.get_probe_delete_modal_open_button(self.ftp_probe_test).click()

        # Delete probe
        self.wait_for_delete_probe_modal_open()
        self.get_probe_delete_button().click()

        # Wait until loading indicator is disappeared
        self.wait_for_loading_indicator()

        # Delete Check
        with self.assertRaises(NoSuchElementException):
            driver.find_element(By.XPATH, "//a[text() = '" + self.ftp_probe_test + "']")
        ###########################################################################

    def test_set_try_count_value_then_rtmp_probe_page(self):
        driver = self.driver
        ###########################################################################
        # RTMP TEST
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[text()='RTMP']"))
        )
        driver.find_element(By.XPATH, "//a[text()='RTMP']").click()

        self.wait_for_save_button()
        self.wait_for_try_count_textbox()

        # Set probe name
        rtmp_probe_name = self.get_probe_name_input_element()
        rtmp_probe_name.clear()
        rtmp_probe_name.send_keys(self.rtmp_probe_test)

        # try_count validate : (try_count * timeout) + try_count < interval
        # try_count : 2, timeout : 3.0(default), interval : 3
        # => (2*3.0) + 2 < 3 => False
        # Set interval
        rtmp_interval = self.get_iterval_input_element()
        rtmp_interval.clear()
        rtmp_interval.send_keys(self.false_test_interval)
        # Set Try count
        rtmp_try_count = self.get_try_count_input_element()
        rtmp_try_count.clear()
        rtmp_try_count.send_keys(self.test_try_count)

        # Click "Save" button
        self.get_probe_save_button().click()
        sleep(self.REQUEST_WAIT_LIMIT)

        # Check "This field is invalied." message
        # Get try_count error message element
        rtmp_try_count = self.get_try_count_input_element()
        rtmp_try_count_msg = self.get_try_count_message(rtmp_try_count)
        self.assertEqual(rtmp_try_count_msg, self.try_count_err_msg)

        # try_count : 2, timeout : 3.0(default), interval : 10
        # => (2*3.0) + 2 < 10 => True
        # Set interval
        rtmp_interval = self.get_iterval_input_element()
        rtmp_interval.clear()
        rtmp_interval.send_keys(self.true_test_interval)

        # Click "Save" button
        self.get_probe_save_button().click()

        # Wait until loading indicator is disappeared
        self.wait_for_loading_indicator()

        # Check probes save successfully
        self.assertEqual(self.get_probe_save_success_message(),
                         self.get_save_message('rtmp', self.rtmp_probe_test))

        # Click Delete modal open button
        self.get_probe_delete_modal_open_button(self.rtmp_probe_test).click()

        # Delete probe
        self.wait_for_delete_probe_modal_open()
        self.get_probe_delete_button().click()

        # Wait until loading indicator is disappeared
        self.wait_for_loading_indicator()

        # Delete Check
        with self.assertRaises(NoSuchElementException):
            driver.find_element(By.XPATH, "//a[text() = '" + self.rtmp_probe_test + "']")
        ###########################################################################

    def test_set_try_count_value_then_dns_probe_page(self):
        driver = self.driver
        ###########################################################################
        # DNS TEST
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[text()='DNS']"))
        )
        driver.find_element(By.XPATH, "//a[text()='DNS']").click()

        self.wait_for_save_button()
        self.wait_for_try_count_textbox()

        # Set probe name
        dns_probe_name = self.get_probe_name_input_element()
        dns_probe_name.clear()
        dns_probe_name.send_keys(self.dns_probe_test)

        # try_count validate : (try_count * timeout) + try_count < interval
        # try_count : 2, timeout : 3.0(default), interval : 3
        # => (2*3.0) + 2 < 3 => False
        # Set interval
        dns_interval = self.get_iterval_input_element()
        dns_interval.clear()
        dns_interval.send_keys(self.false_test_interval)
        # Set Try count
        dns_try_count = self.get_try_count_input_element()
        dns_try_count.clear()
        dns_try_count.send_keys(self.test_try_count)

        # Click "Save" button
        self.get_probe_save_button().click()
        sleep(self.REQUEST_WAIT_LIMIT)

        # Check "This field is invalied." message
        # Get try_count error message element
        dns_try_count = self.get_try_count_input_element()
        dns_try_count_msg = self.get_try_count_message(dns_try_count)
        self.assertEqual(dns_try_count_msg, self.try_count_err_msg)

        # try_count : 2, timeout : 3.0(default), interval : 10
        # => (2*3.0) + 2 < 10 => True
        # Set interval
        dns_interval = self.get_iterval_input_element()
        dns_interval.clear()
        dns_interval.send_keys(self.true_test_interval)

        # Click "Save" button
        self.get_probe_save_button().click()

        # Wait until loading indicator is disappeared
        self.wait_for_loading_indicator()

        # Check probes save successfully
        self.assertEqual(self.get_probe_save_success_message(),
                         self.get_save_message('dns', self.dns_probe_test))

        # Click Delete modal open button
        self.get_probe_delete_modal_open_button(self.dns_probe_test).click()

        # Delete probe
        self.wait_for_delete_probe_modal_open()
        self.get_probe_delete_button().click()

        # Wait until loading indicator is disappeared
        self.wait_for_loading_indicator()

        # Delete Check
        with self.assertRaises(NoSuchElementException):
            driver.find_element(By.XPATH, "//a[text() = '" + self.dns_probe_test + "']")
        ###########################################################################

    def test_set_try_count_value_then_aggregate_probes_page(self):
        driver = self.driver
        ###########################################################################
        # Aggregation TEST
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[text()='Aggregation']"))
        )
        driver.find_element(By.XPATH, "//a[text()='Aggregation']").click()

        self.wait_for_save_button()

        # Make sure the "Try Count" field is not displayed.
        with self.assertRaises(NoSuchElementException):
            driver.find_element(By.ID, "try_count")

        # Set probe name
        aggregate_probe_name = self.get_probe_name_input_element()
        aggregate_probe_name.clear()
        aggregate_probe_name.send_keys(self.aggregate_probe_test)

        # Click "Save" button
        self.get_probe_save_button().click()

        # Wait until loading indicator is disappeared
        self.wait_for_loading_indicator()

        # Check probes save successfully
        self.assertEqual(self.get_probe_save_success_message(),
                         self.get_save_message('aggregate', self.aggregate_probe_test))

        # Click Delete modal open button
        self.get_probe_delete_modal_open_button(self.aggregate_probe_test).click()

        # Delete probe
        self.wait_for_delete_probe_modal_open()
        self.get_probe_delete_button().click()

        # Wait until loading indicator is disappeared
        self.wait_for_loading_indicator()

        # Delete Check
        with self.assertRaises(NoSuchElementException):
            driver.find_element(By.XPATH, "//a[text() = '" + self.aggregate_probe_test + "']")
        ###########################################################################################################
