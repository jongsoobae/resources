import unittest

## CONFIGURATIONS
from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from time import sleep

class BaseVipDisableTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='hyejun.yim')
    def test_is_internal_user_when_Base_Vip_Disable(self):
        driver = self.driver
        ###########################################################################################################
        driver.find_element(By.XPATH, "//a[@href='#config']").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[text()='Pops']"))
        )
        driver.find_element(By.XPATH, "//a[text()='Pops']").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[@href='/config/base/#/pops/config/484/']"))
        )
        driver.find_element(By.XPATH, "//a[@href='/config/base/#/pops/config/484/']").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//label[text()='Auto Probe']"))
        )

        ############################################################################################################################
        # Check the status AutoProbe set
        # auto probe value check
        driver.find_element(By.XPATH, "//input[@id='ac_autoprobe_check']").click()
        driver.find_element(By.XPATH, "//a[@ng-click='save()']").click()
        WebDriverWait(driver, 120).until(
            EC.element_to_be_clickable((By.XPATH, "//ul/li[text()='P0-EZE successfully saved.']"))
        )

        auto_probe = driver.find_element(By.XPATH, "//input[@id='ac_autoprobe_check']").is_selected()

        driver.find_element(By.XPATH, "//a[@href = '#/pops/484/']").click()
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[@href = '#/hosts/7489/']"))
        )
        driver.find_element(By.XPATH, "//a[@href = '#/hosts/7489/']").click()

        self.autoProbe_vipStatus_check(auto_probe)

        ############################################################################################################################
        # Check the status AutoProbe is not set
        # Move the POP Detail Page
        driver.find_element(By.XPATH, "//a[@href='#/pops/484/']").click()
        WebDriverWait(driver, 120).until(
            EC.element_to_be_clickable((By.XPATH, "//a[@href='#/hosts/7489/']"))
        )
        driver.find_element(By.XPATH, "//a[text()='Edit POP Detail']").click()
        WebDriverWait(driver, 120).until(
            EC.element_to_be_clickable((By.XPATH, "//span[text()='P0-EZE']"))
        )

        # auto probe value check
        driver.find_element(By.XPATH, "//input[@id='ac_autoprobe_check']").click()
        driver.find_element(By.XPATH, "//a[@ng-click='save()']").click()
        WebDriverWait(driver, 120).until(
            EC.element_to_be_clickable((By.XPATH, "//ul/li[text()='P0-EZE successfully saved.']"))
        )

        auto_probe2 = driver.find_element(By.XPATH, "//input[@id='ac_autoprobe_check']").is_selected()

        driver.find_element(By.XPATH, "//a[@href = '#/pops/484/']").click()
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[@href = '#/hosts/7489/']"))
        )
        driver.find_element(By.XPATH, "//a[@href = '#/hosts/7489/']").click()

        self.autoProbe_vipStatus_check(auto_probe2)

    def autoProbe_vipStatus_check(self, auto_probe):
        driver = self.driver

        if auto_probe:
            # auto probe
            WebDriverWait(driver, 120).until(
                EC.presence_of_element_located((By.XPATH, "//a[@href = '#/vips/config/24043/']"))
            )

            # Test by selecting a 2 VIPs.
            namedInput = driver.find_element(By.XPATH, "//a[@href='#/vips/config/24043/']")
            rowElement = namedInput.find_element(By.XPATH, ".//ancestor::tr")
            checkdOption = rowElement.find_element(By.XPATH, ".//input[@ng-model='vip.selected']")
            checkdOption.click()
            namedInput2 = driver.find_element(By.XPATH, "//a[@href='#/vips/config/90999/']")
            rowElement2 = namedInput2.find_element(By.XPATH, ".//ancestor::tr")
            checkdOption2 = rowElement2.find_element(By.XPATH, ".//input[@ng-model='vip.selected']")
            checkdOption2.click()

            Select(driver.find_element(By.XPATH, "//select[@ng-model='config_push_vip.enable_gslb']")).select_by_visible_text("False")
            driver.find_element(By.XPATH, "//input[@ng-model='config_push_vip.description']").send_keys('test')
            driver.find_element(By.XPATH, "//input[@value='Save Only']").click()

            WebDriverWait(driver, 5).until(EC.alert_is_present())
            alert = driver.switch_to_alert()

            self.assertEqual(alert.text, "Cannot be changed.Please check the auto probe option.")
            alert.accept()

            # Test by selecting a 1 VIP.
            # It was selected to cancel the vip one.
            namedInput2 = driver.find_element(By.XPATH, "//a[@href='#/vips/config/90999/']")
            rowElement2 = namedInput2.find_element(By.XPATH, ".//ancestor::tr")
            checkdOption2 = rowElement2.find_element(By.XPATH, ".//input[@ng-model='vip.selected']")
            checkdOption2.click()

            Select(driver.find_element(By.XPATH, "//select[@ng-model='config_push_vip.enable_gslb']")).select_by_visible_text("False")
            driver.find_element(By.XPATH, "//input[@ng-model='config_push_vip.description']").send_keys('test')
            driver.find_element(By.XPATH, "//input[@value='Save Only']").click()

            WebDriverWait(driver, 5).until(EC.alert_is_present())
            alert = driver.switch_to_alert()

            self.assertEqual(alert.text, "Cannot be changed.Please check the auto probe option.")
            alert.accept()
        else:
            # not auto probe
            WebDriverWait(driver, 120).until(
                EC.presence_of_element_located((By.XPATH, "//a[@href = '#/vips/config/90999/']"))
            )

            # vip disable
            # Test by selecting a 1 VIP.
            namedInput = driver.find_element(By.XPATH, "//a[@href='#/vips/config/90999/']")
            rowElement = namedInput.find_element(By.XPATH, ".//ancestor::tr")
            checkdOption = rowElement.find_element(By.XPATH, ".//input[@ng-model='vip.selected']")
            checkdOption.click()

            Select(driver.find_element(By.XPATH, "//select[@ng-model='config_push_vip.enable_gslb']")).select_by_visible_text("False")
            driver.find_element(By.XPATH, "//input[@ng-model='config_push_vip.description']").send_keys('test')
            driver.find_element(By.XPATH, "//input[@value='Save Only']").click()

            WebDriverWait(driver, 5).until(EC.alert_is_present())
            alert = driver.switch_to_alert()

            self.assertEqual(alert.text, "Saving status successful")
            alert.accept()
            sleep(5)

            WebDriverWait(driver, 120).until(
                EC.visibility_of_element_located((By.XPATH, "//a[@href = '#/vips/config/90999/']"))
            )

            # Test by selecting a 2 VIPs.
            namedInput2 = driver.find_element(By.XPATH, "//a[@href='#/vips/config/91000/']")
            rowElement2 = namedInput2.find_element(By.XPATH, ".//ancestor::tr")
            checkdOption2 = rowElement2.find_element(By.XPATH, ".//input[@ng-model='vip.selected']")
            checkdOption2.click()
            namedInput3 = driver.find_element(By.XPATH, "//a[@href='#/vips/config/91001/']")
            rowElement3 = namedInput3.find_element(By.XPATH, ".//ancestor::tr")
            checkdOption3 = rowElement3.find_element(By.XPATH, ".//input[@ng-model='vip.selected']")
            checkdOption3.click()

            Select(driver.find_element(By.XPATH, "//select[@ng-model='config_push_vip.enable_gslb']")).select_by_visible_text("False")
            driver.find_element(By.XPATH, "//input[@ng-model='config_push_vip.description']").send_keys('test')
            driver.find_element(By.XPATH, "//input[@value='Save Only']").click()

            WebDriverWait(driver, 5).until(EC.alert_is_present())
            alert = driver.switch_to_alert()

            self.assertEqual(alert.text, "Saving status successful")
            alert.accept()
            sleep(5)

            # wait for save
            WebDriverWait(driver, 120).until(
                EC.visibility_of_element_located((By.XPATH, "//a[@href = '#/vips/config/91000/']"))
            )

            # vip enable
            namedInput = driver.find_element(By.XPATH, "//a[@href='#/vips/config/90999/']")
            rowElement = namedInput.find_element(By.XPATH, ".//ancestor::tr")
            checkdOption = rowElement.find_element(By.XPATH, ".//input[@ng-model='vip.selected']")
            checkdOption.click()
            namedInput2 = driver.find_element(By.XPATH, "//a[@href='#/vips/config/91000/']")
            rowElement2 = namedInput2.find_element(By.XPATH, ".//ancestor::tr")
            checkdOption2 = rowElement2.find_element(By.XPATH, ".//input[@ng-model='vip.selected']")
            checkdOption2.click()
            namedInput3 = driver.find_element(By.XPATH, "//a[@href='#/vips/config/91001/']")
            rowElement3 = namedInput3.find_element(By.XPATH, ".//ancestor::tr")
            checkdOption3 = rowElement3.find_element(By.XPATH, ".//input[@ng-model='vip.selected']")
            checkdOption3.click()

            Select(driver.find_element(By.XPATH, "//select[@ng-model='config_push_vip.enable_gslb']")).select_by_visible_text("True")
            driver.find_element(By.XPATH, "//input[@ng-model='config_push_vip.description']").send_keys('test')
            driver.find_element(By.XPATH, "//input[@value='Save Only']").click()

            WebDriverWait(driver, 5).until(EC.alert_is_present())
            alert = driver.switch_to_alert()

            self.assertEqual(alert.text, "Saving status successful")
            alert.accept()

        sleep(2)
        return


if __name__ == '__main__':
    unittest.main()
