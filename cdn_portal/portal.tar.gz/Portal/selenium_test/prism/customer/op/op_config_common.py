import requests
import time

from selenium_test.shared_components import testcase
from selenium_test.config_constants import PRISM_API_URL
from selenium_test.config_user_constants import PRISM_API_USER
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support.expected_conditions import presence_of_element_located
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.by import By


WAIT_PAGE_LOAD_TIME = 3
RESULT_WAIT_TIME = 2
LOCAL_WAIT_TIME = 0.5


class TestOPConfigCommon(testcase.PrismTestCase):
    default_assignee_user = 'seungho.ryu@cdnetworks.co.kr'
    find_assignee = 'seungho'

    @classmethod
    def setUpClass(cls):
        super(TestOPConfigCommon, cls).setUpClass()
        cls.direct_to('/customer/op_list/')

    def click_search(self):
        btn_search = self.driver.find_element_by_xpath('//button[@ng-click="selectPage(1)"]')
        btn_search.click()

    def get_index_of_table_by_column_name(self, column_name):
        ths = self.driver.find_elements_by_xpath('//table[@id="result_table"]/thead/tr/th')
        for i, th in enumerate(ths):
            if th.text == column_name:
                return i
        return -1

    def get_first_content_of_table_by_index(self, index):
        tds = self.driver.find_elements_by_xpath('//table[@id="result_table"]/tbody/tr[1]/td')
        for i, td, in enumerate(tds):
            if i == index:
                return td.text
        return None

    def assign_sm(self, prime, sub):
        trs = self.driver.find_elements_by_xpath('//table[@class="table-contract-details"]/tbody/tr')
        for tr in trs:
            th = tr.find_element_by_tag_name('th')
            if th.text == 'SM':
                td = tr.find_element_by_tag_name('td')
                if td.text == 'Assign':
                    td.find_element_by_tag_name('button').click()
                else:
                    td.find_element_by_tag_name('a').click()
                break
        self.WAIT_XPATH('//select[@ng-model="selected_prime"]')

        # Update SM
        prime_sm = self.driver.find_element_by_xpath('//select[@ng-model="selected_prime"]')
        sub_sm = self.driver.find_element_by_xpath('//select[@ng-model="selected_sub"]')
        Select(prime_sm).select_by_value(prime)
        Select(sub_sm).select_by_value(sub)

        # Click save
        btn_save = self.driver.find_element_by_xpath('//div[@ng-click="onModalSave(selected_prime, selected_sub)"]')
        btn_save.click()
        time.sleep(RESULT_WAIT_TIME)

    # This function assign SM if the SM is empty(NOT assigned) status only.
    def assign_sm_only_empty(self, prime, sub):
        trs = self.driver.find_elements_by_xpath('//table[@class="table-contract-details"]/tbody/tr')
        for tr in trs:
            th = tr.find_element_by_tag_name('th')
            if th.text == 'SM':
                td = tr.find_element_by_tag_name('td')
                if td.text == 'Assign':
                    self.assign_sm(prime, sub)
                break

    def WAIT_XPATH(self, xpath, seconds=10):
        WebDriverWait(self.driver, seconds).until(presence_of_element_located((By.XPATH, xpath)))

    def load_and_create_csorder_no(self, csorderno, move_detail_page=True):
        search_name = self.driver.find_element_by_xpath('.//input[@ng-model="ng.name"]')
        search_name.send_keys(csorderno)
        self.click_search()
        time.sleep(RESULT_WAIT_TIME)

        result_table = self.driver.find_elements_by_xpath('//table[@id="result_table"]/tbody/tr')
        if len(result_table) == 0:
            full_csorder = '000%s' % csorderno
            url = '%s/customer/order/add?user=%s&pass=%s&csorderno=%s' % \
                  (PRISM_API_URL, PRISM_API_USER['username'], PRISM_API_USER['password'], full_csorder)
            resp = requests.get(url)
            self.assertEqual(resp.status_code, 200)
            self.assertEqual(resp.content, 'Prism Success - %s' % full_csorder)

            # search again
            search_name.clear()
            search_name.send_keys(csorderno)
            self.click_search()
            time.sleep(LOCAL_WAIT_TIME)
            self.WAIT_XPATH('//table[@id="result_table"]/tbody/tr[1]/td')

        if move_detail_page:
            # Move detail page.
            contract_idx = self.get_index_of_table_by_column_name('Contract No [Item No] / Contract / Product / Platform')
            tds = self.driver.find_elements_by_xpath('//table[@id="result_table"]/tbody/tr[1]/td')
            for i, td, in enumerate(tds):
                if i == 0:  # 1==0 means csorderno
                    if td.text != csorderno:
                        self.assertTrue(False, 'We don\'t find csorderno=%s' % csorderno)
                if i == contract_idx:
                    a_href = td.find_element_by_tag_name('a')
                    a_href.click()
                    time.sleep(RESULT_WAIT_TIME)
                    break

            # Assign SM, If SM is empty only.
            self.assign_sm_only_empty(self.default_assignee_user, self.default_assignee_user)
