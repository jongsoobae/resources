import time

from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support.expected_conditions import presence_of_element_located
from selenium.webdriver.common.by import By

from selenium_test.prism.customer.op.op_config_common import TestOPConfigCommon
from selenium_test.prism.customer.op.op_config_common import WAIT_PAGE_LOAD_TIME
from selenium_test.prism.customer.op.op_config_common import RESULT_WAIT_TIME


class TestOPListTestCase(TestOPConfigCommon):
    def _get_base_detail_table_contents(self):
        dict_contents = {}
        trs = self.driver.find_elements_by_xpath('//table[@class="table-contract-details"]/tbody/tr')
        for tr in trs:
            th = tr.find_element_by_tag_name('th')
            try:
                td = tr.find_element_by_tag_name('td')
                dict_contents[th.text] = td.text
            except:
                dict_contents[th.text] = None
        return dict_contents

    def _get_task_type_and_request_type_of_first_of_assignee_table(self):
        task_type_idx = -1
        request_type_idx = -1
        task_type = None
        request_type = None
        ths = self.driver.find_elements_by_xpath('//table[@class="table table-confirmation"]/thead/tr[1]/th')
        for i, th in enumerate(ths):
            if th.text == 'Task Type':
                task_type_idx = i
            elif th.text == 'Request Type':
                request_type_idx = i
        tds = self.driver.find_elements_by_xpath('//table[@class="table table-confirmation"]/tbody/tr[1]/td')
        for i, td in enumerate(tds):
            if i == task_type_idx:
                task_type = td.text
            elif i == request_type_idx:
                request_type = td.text
        return task_type, request_type

    # Start testing
    def test_a_contract_region(self):
        self.load_and_create_csorder_no('300024187', move_detail_page=False)
        search_name = self.driver.find_element_by_xpath('.//input[@ng-model="ng.name"]')
        search_name.clear()

        # Get contract information of first item of table.
        account_name = self.get_first_content_of_table_by_index(self.get_index_of_table_by_column_name('Account'))
        contract_idx = self.get_index_of_table_by_column_name('Contract No [Item No] / Contract / Product / Platform')
        contract = self.get_first_content_of_table_by_index(contract_idx)
        am = self.get_first_content_of_table_by_index(self.get_index_of_table_by_column_name('AM'))

        # Move first item's detail page.
        tds = self.driver.find_elements_by_xpath('//table[@id="result_table"]/tbody/tr[1]/td')
        for i, td, in enumerate(tds):
            if i == contract_idx:
                a_href = td.find_element_by_tag_name('a')
                a_href.click()
                break
        time.sleep(WAIT_PAGE_LOAD_TIME)
        base_contents = self._get_base_detail_table_contents()

        self.assertNotEqual(len(base_contents), 0, 'Not found base contents of Base Detail table')

        # Compare base detail table.
        self.assertEqual(account_name, base_contents['Account'])
        self.assertFalse(base_contents['Platform'] not in contract)
        self.assertEqual(am, base_contents['AM'])

    def test_b_assign_sm(self):
        trs = self.driver.find_elements_by_xpath('//table[@class="table-contract-details"]/tbody/tr')
        for tr in trs:
            th = tr.find_element_by_tag_name('th')
            if th.text == 'SM':
                td = tr.find_element_by_tag_name('td')
                if td.text == 'Assign':
                    td.find_element_by_tag_name('button').click()
                else:
                    td.find_element_by_tag_name('a').click()
                break

        WebDriverWait(self.driver, 10).until(
            presence_of_element_located((By.XPATH, '//select[@ng-model="selected_prime"]'))
        )
        # Update SM to 'default_assignee_user'
        prime_sm = self.driver.find_element_by_xpath('//select[@ng-model="selected_prime"]')
        sub_sm = self.driver.find_element_by_xpath('//select[@ng-model="selected_sub"]')
        Select(prime_sm).select_by_value(self.default_assignee_user)
        Select(sub_sm).select_by_value(self.default_assignee_user)

        # Click save
        btn_save = self.driver.find_element_by_xpath('//div[@ng-click="onModalSave(selected_prime, selected_sub)"]')
        btn_save.click()
        time.sleep(RESULT_WAIT_TIME)

        # Check first SM is whether 'find_assignee' or not
        trs = self.driver.find_elements_by_xpath('//table[@class="table-contract-details"]/tbody/tr')
        for tr in trs:
            th = tr.find_element_by_tag_name('th')
            if th.text == 'SM':
                td = tr.find_element_by_tag_name('td')
                self.assertTrue(self.find_assignee in td.text.lower())
                break
        # finish

    def test_c_click_sub_item_show_parent_item_information(self):
        # Return to list page
        self.driver.back()
        # 300022404: 40011686-50
        self.load_and_create_csorder_no('300022404', move_detail_page=False)
        search_name = self.driver.find_element_by_xpath('.//input[@ng-model="ng.name"]')
        search_name.clear()
        # 300022996: 40011686-60 (parent: 40011686-50)
        self.load_and_create_csorder_no('300022996', move_detail_page=True)

        # We have to find '40011686 [60]' and '40011686 [50]' in table-confirmation.
        find_item_50 = False    # it means '40011686 [50]'
        find_item_60 = False    # it means '40011686 [60]'
        contract_idx = None
        ths = self.driver.find_elements_by_xpath('//table[@class="table table-confirmation"]/thead/tr/th')
        for i, th in enumerate(ths):
            if th.text == 'Contract':
                contract_idx = i
                break
        self.assertTrue(contract_idx)
        trs = self.driver.find_elements_by_xpath('//table[@class="table table-confirmation"]/tbody/tr')
        for i, tr in enumerate(trs):
            tds = tr.find_elements_by_tag_name('td')
            for j, td in enumerate(tds):
                if j == contract_idx:
                    if td.text.startswith('40011686 [50]'):
                        find_item_50 = True
                    elif td.text.startswith('40011686 [60]'):
                        find_item_60 = True
                    break

        self.assertTrue(find_item_50)
        self.assertTrue(find_item_60)
