import time

from selenium.webdriver.common.keys import Keys

from selenium_test.prism.customer.op.op_config_common import TestOPConfigCommon
from selenium_test.prism.customer.op.op_config_common import LOCAL_WAIT_TIME
from selenium_test.prism.customer.op.op_config_common import RESULT_WAIT_TIME


class TestOPConfigLMTestCase(TestOPConfigCommon):
    aqua_director_add_test_domain = 'www.aqua_director_add_test_domain.com'

    def test_a_load_live_monitoring_part(self):
        self.load_and_create_csorder_no('300012295')

        # Find and Wait table-added-services table.
        self.WAIT_XPATH('//table[@class="table table-aqua-director"]/tbody')
        self.assertTrue(True)

    def test_b_add_customer_domain(self):
        # Check list
        b_find = False
        customer_domains = self.driver.find_elements_by_class_name('txt_dns')
        for domain in customer_domains:
            if domain.text == self.aqua_director_add_test_domain:
                b_find = True
                break

        # We can't delete customer domain.
        # So, if we find 'aqua_director_add_test_domain', we pass this testing.
        if b_find:
            self.assertTrue(True)
        else:
            # Click Add button
            btn_add_ad_domain = self.driver.find_element_by_xpath('//button[@ng-click="click_add_ad_domain()"]')
            time.sleep(LOCAL_WAIT_TIME)
            btn_add_ad_domain.click()
            time.sleep(LOCAL_WAIT_TIME)

            # input 'aqua_director_add_test_domain'
            input_ad_domain = self.driver.find_element_by_xpath('//input[@ng-model="ad.add_svc_name"]')
            input_ad_domain.send_keys(self.aqua_director_add_test_domain)
            input_ad_domain.send_keys(Keys.RETURN)
            time.sleep(RESULT_WAIT_TIME)

            # Check list
            customer_domains = self.driver.find_elements_by_class_name('txt_dns')
            customer_domain = customer_domains[len(customer_domains) - 1]
            self.assertTrue(customer_domain.text == self.aqua_director_add_test_domain)

    def test_c_duplicate_customer_domain(self):
        # Click Add button
        btn_add_ad_domain = self.driver.find_element_by_xpath('//button[@ng-click="click_add_ad_domain()"]')
        time.sleep(LOCAL_WAIT_TIME)
        btn_add_ad_domain.click()
        time.sleep(LOCAL_WAIT_TIME)

        # input 'aqua_director_add_test_domain'
        input_ad_domain = self.driver.find_element_by_xpath('//input[@ng-model="ad.add_svc_name"]')
        input_ad_domain.send_keys(self.aqua_director_add_test_domain)
        input_ad_domain.send_keys(Keys.RETURN)
        time.sleep(RESULT_WAIT_TIME)

        # Cancel input
        input_ad_domain.send_keys(Keys.ESCAPE)

        # Check list
        count_test_domain = 0
        customer_domains = self.driver.find_elements_by_class_name('txt_dns')
        for domain in customer_domains:
            if domain.text == self.aqua_director_add_test_domain:
                count_test_domain += 1
        self.assertTrue(count_test_domain == 1)
