from selenium_test.prism.customer.op.op_config_common import TestOPConfigCommon


class TestOPListTestCase(TestOPConfigCommon):
    def test_b_load_cache_server_part(self):
        self.load_and_create_csorder_no('300022404')

        # Wait to load CS part
        self.WAIT_XPATH('//table[@class="table table-cache-server"]/tbody')
        self.assertTrue(True)
