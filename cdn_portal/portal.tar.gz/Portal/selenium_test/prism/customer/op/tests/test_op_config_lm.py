import time

from selenium.webdriver.common.keys import Keys

from selenium_test.prism.customer.op.op_config_common import TestOPConfigCommon
from selenium_test.prism.customer.op.op_config_common import LOCAL_WAIT_TIME
from selenium_test.prism.customer.op.op_config_common import RESULT_WAIT_TIME


class TestOPConfigLMTestCase(TestOPConfigCommon):
    live_monitoring_add_test = 'live_monitoring_add_test'

    def test_a_load_live_monitoring_part(self):
        self.load_and_create_csorder_no('300022042')

        # Find and Wait table-added-services table.
        self.WAIT_XPATH('//table[@class="table table-live-monitoring"]')
        self.assertTrue(True)

    def test_b_add_publish_point(self):
        # Click Add button
        btn_add_publish_point = self.driver.find_element_by_xpath('//button[@ng-click="click_add_publish_point()"]')
        time.sleep(LOCAL_WAIT_TIME)
        btn_add_publish_point.click()
        time.sleep(LOCAL_WAIT_TIME)

        # input 'live_monitoring_add_test'
        input_publish_point = self.driver.find_element_by_xpath('//input[@ng-model="lm.add_svc_name"]')
        input_publish_point.send_keys(self.live_monitoring_add_test)
        time.sleep(LOCAL_WAIT_TIME)
        input_publish_point.send_keys(Keys.RETURN)
        time.sleep(RESULT_WAIT_TIME)

        # Check list
        publish_points = self.driver.find_elements_by_class_name('txt_publish_point')
        publish_point = publish_points[len(publish_points) - 1]
        self.assertTrue(publish_point.text == self.live_monitoring_add_test)

    def test_c_duplicate_publish_point(self):
        # Click Add button
        btn_add_publish_point = self.driver.find_element_by_xpath('//button[@ng-click="click_add_publish_point()"]')
        time.sleep(LOCAL_WAIT_TIME)
        btn_add_publish_point.click()
        time.sleep(LOCAL_WAIT_TIME)

        # input 'live_monitoring_add_test'
        input_publish_point = self.driver.find_element_by_xpath('//input[@ng-model="lm.add_svc_name"]')
        input_publish_point.send_keys(self.live_monitoring_add_test)
        input_publish_point.send_keys(Keys.RETURN)
        time.sleep(RESULT_WAIT_TIME)

        # Cancel input
        input_publish_point.send_keys(Keys.ESCAPE)

        # Check list
        count_publish_point = 0
        publish_points = self.driver.find_elements_by_class_name('txt_publish_point')
        for publish_point in publish_points:
            if publish_point.text == self.live_monitoring_add_test:
                count_publish_point += 1
        self.assertTrue(count_publish_point == 1)

    def test_d_delete_publish_point(self):
        # Find last delete button
        btn_deletes = self.driver.\
            find_elements_by_xpath('//button[@ng-click="click_delete_publish_point(lm.add_svc_id)"]')
        btn_delete = btn_deletes[len(btn_deletes) - 1]
        btn_delete.click()
        # Click the 'Yes' button
        btn_delete_yes = self.driver.find_element_by_xpath('//div[@ng-click="modal_confirm_ok()"]')
        btn_delete_yes.click()
        time.sleep(RESULT_WAIT_TIME)

        # Check list
        publish_points = self.driver.find_elements_by_class_name('txt_publish_point')
        for publish_point in publish_points:
            self.assertTrue(publish_point.text != self.live_monitoring_add_test)

