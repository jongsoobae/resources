import time

from selenium.webdriver.common.keys import Keys

from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support.expected_conditions import alert_is_present

from selenium_test.prism.customer.op.op_config_common import TestOPConfigCommon
from selenium_test.prism.customer.op.op_config_common import LOCAL_WAIT_TIME
from selenium_test.prism.customer.op.op_config_common import RESULT_WAIT_TIME


class TestOPconfigMSTestCase(TestOPConfigCommon):
    test_add_domain_name = 'test add service domain'
    test_stat_domain_name = 'service domain for testing stat/keyword'
    test_stat_service_name = 'selenium_test_stat_service'
    test_keyword_name = '/selenium_test_keyword_ok/'
    test_live_keyword_name = '/selenium_test_live_keyword'

    def test_a_load_media_server_part(self):
        self.load_and_create_csorder_no('300022036')

        # Find and Wait table-media-server table.
        self.WAIT_XPATH('//table[@class="table table-media-server"]/tbody')
        self.assertTrue(True)

    def test_b_add_service_domain(self):
        # Try to add 'test_add_domain_name'
        btn_service_domain = self.driver.find_element_by_xpath('//button[@ng-click="click_add_service_domain()"]')
        time.sleep(LOCAL_WAIT_TIME)
        btn_service_domain.click()
        time.sleep(LOCAL_WAIT_TIME)
        input_service_domains = self.driver.find_elements_by_xpath('//input[@ng-model="localModel"]')
        input_service_domain = input_service_domains[len(input_service_domains) - 1]    # Select last service domain
        input_service_domain.send_keys(self.test_add_domain_name)
        input_service_domain.send_keys(Keys.RETURN)

        # Wait result of add command
        time.sleep(RESULT_WAIT_TIME)

        # Verify that 'test_add_domain_name' exists
        b_find = False
        service_domains = self.driver.find_elements_by_xpath('//div[@class="hover-text-field ng-binding"]')
        for i, svc_domain in enumerate(service_domains):
            if svc_domain.text == self.test_add_domain_name:
                b_find = True
        self.assertTrue(b_find, 'We don\'t find \'%s\' name in service domain list' % self.test_add_domain_name)

    def test_c_delete_service_domain(self):
        # Try to delete 'test_add_domain_name'
        service_domains = self.driver.find_elements_by_xpath('//div[@class="hover-text-field ng-binding"]')
        for i, svc_domain in enumerate(service_domains):
            if svc_domain.text == self.test_add_domain_name:
                btn_deletes = self.driver.find_elements_by_xpath('//button[@ng-click="delete_svc_domain(domain.svc_domain_id)"]')
                for j, btn_delete in enumerate(btn_deletes):
                    if i == j:
                        btn_delete.click()
                break
        time.sleep(RESULT_WAIT_TIME)

        # Verify that 'test_add_domain_name' doesn't exist
        service_domains = self.driver.find_elements_by_xpath('//div[@class="hover-text-field ng-binding"]')
        for i, svc_domain in enumerate(service_domains):
            self.assertNotEqual(svc_domain.text, self.test_add_domain_name,
                                'We delete \'%s\', so it must not exist.' % self.test_add_domain_name)

    def test_d_add_stat_service(self):
        # Find to exist 'test_stat_domain_name'
        test_index = -1
        svc_domains = self.driver.find_elements_by_xpath('//div[@class="hover-text-field ng-binding"]')
        for i, svc_domain in enumerate(svc_domains):
            if svc_domain.text == self.test_stat_domain_name:
                test_index = i

        # If 'test_stat_domain_name' not exist, we try to add it
        if test_index == -1:
            btn_service_domain = self.driver.find_element_by_xpath('//button[@ng-click="click_add_service_domain()"]')
            time.sleep(LOCAL_WAIT_TIME)
            btn_service_domain.click()
            time.sleep(LOCAL_WAIT_TIME)
            input_service_domains = self.driver.find_elements_by_xpath('//input[@ng-model="localModel"]')
            test_index = len(input_service_domains) - 1
            input_service_domain = input_service_domains[test_index]
            input_service_domain.send_keys(self.test_stat_domain_name)
            input_service_domain.send_keys(Keys.RETURN)
            time.sleep(RESULT_WAIT_TIME)

        # Click edit button
        btn_edits = self.driver.find_elements_by_xpath(
            '//button[@ng-click="open_modal_keyword(domain.svc_domain_id, domain.svc_domain_name)"]')
        btn_edit = btn_edits[test_index]
        btn_edit.click()

        # find to exist 'test_stat_service_name'
        table_stat = self.driver.find_element_by_class_name('table-edit-stat')
        stat_names = table_stat.find_elements_by_class_name('hover-text-field')
        b_find_stat = False
        for stat_name in stat_names:
            if stat_name.text == self.test_stat_service_name:
                b_find_stat = True
                break

        # If 'test_stat_domain_name' not exist, we try to add it
        if not b_find_stat:
            input_svc_name = self.driver.find_element_by_xpath('//input[@ng-model="ng.stat_svc_name"]')
            input_svc_name.send_keys(self.test_stat_service_name)
            btn_add_stat = self.driver.find_element_by_xpath('//button[@ng-click="add_ms_stat_service()"]')
            btn_add_stat.click()
            time.sleep(1)
            btn_confirm_yes = self.driver.find_element_by_xpath('//div[@ng-click="modal_confirm_ok()"]')
            btn_confirm_yes.click()
            time.sleep(RESULT_WAIT_TIME)

        # Check stat list has 'test_stat_domain_name'
        table_stat = self.driver.find_element_by_class_name('table-edit-stat')
        stat_names = table_stat.find_elements_by_class_name('hover-text-field')
        b_find_stat = False
        for stat_name in stat_names:
            if stat_name.text == self.test_stat_service_name:
                b_find_stat = True
                break
        self.assertTrue(b_find_stat, 'We added (%s) stat service, But we don\'t find it.')

    def test_e_empty_stat_service(self):
        input_svc_name = self.driver.find_element_by_xpath('//input[@ng-model="ng.stat_svc_name"]')
        input_svc_name.clear()
        input_svc_name.click()
        btn_check = self.driver.find_element_by_xpath('//button[@ng-click="valid_ms_stat_service(ng.stat_svc_name)"]')
        btn_check.click()

        WebDriverWait(self.driver, 10).until(alert_is_present())
        alert = self.driver.switch_to_alert()

        # Check alert message
        self.assertTrue('Please input' in alert.text, 'We don\'t find expected string.')
        alert.accept()

    def test_f_check_duplicate_stat_service(self):
        input_svc_name = self.driver.find_element_by_xpath('//input[@ng-model="ng.stat_svc_name"]')
        try:
            input_svc_name.send_keys(self.test_stat_service_name)
            btn_check = self.driver.\
                find_element_by_xpath('//button[@ng-click="valid_ms_stat_service(ng.stat_svc_name)"]')
            btn_check.click()

            WebDriverWait(self.driver, 10).until(alert_is_present())
            alert = self.driver.switch_to_alert()

            # Check alert message
            self.assertTrue('Duplicated!' in alert.text, 'We don\'t find expected string(Duplicated!)')
            alert.accept()
        finally:
            input_svc_name.clear()

    def test_g_change_stat_service(self):
        change_stat_service_name = self.test_stat_service_name + "_changing"

        # Try to find 'self.test_stat_service_name'
        table_stat = self.driver.find_element_by_class_name('table-edit-stat')
        stat_names = table_stat.find_elements_by_class_name('hover-text-field')
        test_index = -1
        for i, stat_name in enumerate(stat_names):
            if stat_name.text == self.test_stat_service_name:
                stat_name.click()
                test_index = i
                break
        self.assertTrue(test_index != -1, 'We don\'t find the stat service for testing')

        # stat service name change to 'self.test_stat_service_name + _changing'
        input_stats = table_stat.find_elements_by_class_name('inputText')
        input_stat_service = input_stats[test_index]
        input_stat_service.clear()
        input_stat_service.send_keys(change_stat_service_name)
        input_stat_service.send_keys(Keys.ENTER)
        time.sleep(RESULT_WAIT_TIME)

        # Verify whether stat_service are changed or not.
        table_stat = self.driver.find_element_by_class_name('table-edit-stat')
        stat_names = table_stat.find_elements_by_class_name('hover-text-field')
        for i, stat_name in enumerate(stat_names):
            if test_index == i:
                self.assertTrue(stat_name.text == change_stat_service_name)
                stat_name.click()
                break

        # Recover to 'self.test_stat_service_name'
        input_stats = table_stat.find_elements_by_class_name('inputText')
        input_stat_service = input_stats[test_index]
        input_stat_service.clear()
        input_stat_service.send_keys(self.test_stat_service_name)
        input_stat_service.send_keys(Keys.ENTER)
        time.sleep(RESULT_WAIT_TIME)

        # Verify that stat_service are recovered to 'self.test_stat_service_name'
        stat_names = table_stat.find_elements_by_class_name('hover-text-field')
        for i, stat_name in enumerate(stat_names):
            if test_index == i:
                self.assertTrue(stat_name.text == self.test_stat_service_name)
                break

    def test_h_add_keyword(self):
        # Click 'Edit keyword' button of 'self.test_stat_service_name'
        table_stat = self.driver.find_element_by_class_name('table-edit-stat')
        stat_names = table_stat.find_elements_by_class_name('hover-text-field')
        test_index = -1
        for i, stat_name in enumerate(stat_names):
            if stat_name.text == self.test_stat_service_name:
                test_index = i
                break
        self.assertTrue(test_index != -1, 'We don\'t find the stat service for testing')
        btn_edit_keywords = table_stat.find_elements_by_tag_name('button')
        btn_edit_keyword = btn_edit_keywords[test_index]
        btn_edit_keyword.click()
        time.sleep(LOCAL_WAIT_TIME)

        # Check whether 'self.test_keyword_name' already exists or not.
        trs = self.driver.find_elements_by_xpath('//table[@class="table table-edit-keyword"]/tbody/tr')
        b_find = False
        for i, tr in enumerate(trs):
            if i == 0:
                continue    # i == 0 is <th>
            tds = tr.find_elements_by_tag_name('td')
            if tds[0].text == self.test_keyword_name:
                b_find = True
                break

        # If 'self.test_keyword_name' doesn't exist, create 'self.test_keyword_name' keyword.
        if not b_find:
            input_keyword = self.driver.find_element_by_xpath('//input[@ng-model="ng.keyword_name"]')
            input_keyword.send_keys(self.test_keyword_name)
            btn_add_keyword = self.driver.find_element_by_xpath('//button[@ng-click="add_ms_keyword()"]')
            btn_add_keyword.click()
            time.sleep(RESULT_WAIT_TIME)

        # Verify that 'self.test_keyword_name' keyword was added.
        trs = self.driver.find_elements_by_xpath('//table[@class="table table-edit-keyword"]/tbody/tr')
        b_find = False
        for i, tr in enumerate(trs):
            if i == 0:
                continue  # i == 0 means <th>
            tds = tr.find_elements_by_tag_name('td')
            if tds[0].text == self.test_keyword_name:
                b_find = True
                break
        self.assertTrue(b_find, 'We add new test keyword \'%s\', '
                                'But we don\'t find it on keyword list.' % self.test_keyword_name)

    def test_i_empty_keyword(self):
        input_keyword = self.driver.find_element_by_xpath('//input[@ng-model="ng.keyword_name"]')
        input_keyword.clear()
        input_keyword.click()
        btn_check = self.driver.find_element_by_xpath('//button[@ng-click="valid_ms_keyword(ng.keyword_name)"]')
        btn_check.click()

        WebDriverWait(self.driver, 10).until(alert_is_present())
        alert = self.driver.switch_to_alert()

        # Check alert message
        self.assertTrue('Please input' in alert.text, 'We don\'t find expected string.')
        alert.accept()

    def test_j_duplicate_keyword(self):
        input_keyword = self.driver.find_element_by_xpath('//input[@ng-model="ng.keyword_name"]')
        try:
            input_keyword.send_keys(self.test_keyword_name)
            btn_check = self.driver. \
                find_element_by_xpath('//button[@ng-click="valid_ms_keyword(ng.keyword_name)"]')
            btn_check.click()

            WebDriverWait(self.driver, 10).until(alert_is_present())
            alert = self.driver.switch_to_alert()

            # Check alert message
            self.assertTrue('Duplicated!' in alert.text, 'We don\'t find expected string(Duplicated!)')
            alert.accept()
        finally:
            input_keyword.clear()

    def test_k_delete_keyword(self):
        # Check testing keyword's current status is whether active or delete
        trs = self.driver.find_elements_by_xpath('//table[@class="table table-edit-keyword"]/tbody/tr')
        idx_keyword = -1
        idx_state = -1
        idx_func = -1
        for i, tr in enumerate(trs):
            if i == 0:
                ths = tr.find_elements_by_tag_name('th')
                for k, th in enumerate(ths):
                    if th.text == 'Keyword':
                        idx_keyword = k
                    if th.text == 'State':
                        idx_state = k
                    if th.text == 'Func.':
                        idx_func = k
                continue  # i == 0 is <th>
            tds = tr.find_elements_by_tag_name('td')
            if tds[idx_keyword].text == self.test_keyword_name:
                if tds[idx_state].text == 'Active':
                    btn_delete = tds[idx_func].find_element_by_tag_name('button')
                    btn_delete.click()
                    time.sleep(LOCAL_WAIT_TIME)
                    # Confirm Modal click (Yes I'm sure)
                    confirm_ok = self.driver.find_element_by_xpath('//div[@ng-click="modal_confirm_ok()"]')
                    confirm_ok.click()
                    time.sleep(RESULT_WAIT_TIME)
                else:
                    # If current state is 'delete', we should pass.
                    pass
                break

        # If we don't find (Keyword, State, Func) Strings, We should fail test.
        self.assertFalse(-1 in [idx_keyword, idx_state, idx_func])

        # Check keyword state is 'Deleted'
        trs = self.driver.find_elements_by_xpath('//table[@class="table table-edit-keyword"]/tbody/tr')
        for i, tr in enumerate(trs):
            if i == 0:
                continue    # pass header
            tds = tr.find_elements_by_tag_name('td')
            if tds[idx_keyword].text == self.test_keyword_name:
                self.assertTrue(tds[idx_state].text == 'Deleted')
                break

        # We change again state to Active
        for i, tr in enumerate(trs):
            if i == 0:
                continue    # pass header
            tds = tr.find_elements_by_tag_name('td')
            if tds[idx_keyword].text == self.test_keyword_name:
                btn_active = tds[idx_func].find_element_by_tag_name('button')
                btn_active.click()
                time.sleep(RESULT_WAIT_TIME)
                break

        # Check keyword state is 'Active'
        trs = self.driver.find_elements_by_xpath('//table[@class="table table-edit-keyword"]/tbody/tr')
        for i, tr in enumerate(trs):
            if i == 0:
                continue    # pass header
            tds = tr.find_elements_by_tag_name('td')
            if tds[idx_keyword].text == self.test_keyword_name:
                self.assertTrue(tds[idx_state].text == 'Active')
                break

    def test_l_live_keyword(self):
        # Check whether 'self.test_live_keyword_name' already exists or not.
        trs = self.driver.find_elements_by_xpath('//table[@class="table table-edit-keyword"]/tbody/tr')
        b_find = False
        for i, tr in enumerate(trs):
            if i == 0:
                continue  # i == 0 is <th>
            tds = tr.find_elements_by_tag_name('td')
            if tds[0].text == self.test_live_keyword_name:
                b_find = True
                break

        # If 'Demon type' is 'Streaming', to input live keyword have to failure.
        input_keyword = self.driver.find_element_by_xpath('//input[@ng-model="ng.keyword_name"]')
        input_keyword.send_keys(self.test_live_keyword_name)
        btn_check = self.driver.find_element_by_xpath('//button[@ng-click="valid_ms_keyword(ng.keyword_name)"]')
        btn_check.click()
        WebDriverWait(self.driver, 10).until(alert_is_present())
        alert = self.driver.switch_to_alert()
        self.assertTrue('Keyword MUST' in alert.text, 'Not expected result.')
        alert.accept()
        input_keyword.clear()

        # If 'self.test_live_keyword_name' doesn't exist, create 'self.test_live_keyword_name' keyword.
        if not b_find:
            # Change 'Demon type' from 'Streaming' to 'Live'
            select_daemon_type = self.driver.find_element_by_xpath('//select[@ng-model="ng.daemon_type"]')
            Select(select_daemon_type).select_by_value('L')

            # Try to create 'self.test_live_keyword_name' keyword.
            input_keyword = self.driver.find_element_by_xpath('//input[@ng-model="ng.keyword_name"]')
            input_keyword.send_keys(self.test_live_keyword_name)
            btn_add_keyword = self.driver.find_element_by_xpath('//button[@ng-click="add_ms_keyword()"]')
            btn_add_keyword.click()
            time.sleep(RESULT_WAIT_TIME)

        # Verify that 'self.test_live_keyword_name' keyword was added.
        trs = self.driver.find_elements_by_xpath('//table[@class="table table-edit-keyword"]/tbody/tr')
        b_find = False
        for i, tr in enumerate(trs):
            if i == 0:
                continue  # i == 0 means <th>
            tds = tr.find_elements_by_tag_name('td')
            if tds[0].text == self.test_live_keyword_name:
                b_find = True
                break
        self.assertTrue(b_find, 'We add new test live keyword \'%s\', '
                                'But we don\'t find it on keyword list.' % self.test_live_keyword_name)
