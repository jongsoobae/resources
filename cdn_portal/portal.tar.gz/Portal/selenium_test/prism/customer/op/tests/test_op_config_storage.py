import time

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support.expected_conditions import visibility_of_element_located
from selenium.webdriver.support.expected_conditions import invisibility_of_element_located
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.by import By

from selenium_test.prism.customer.op.op_config_common import TestOPConfigCommon
from selenium_test.prism.customer.op.op_config_common import RESULT_WAIT_TIME


class TestOPListTestCase(TestOPConfigCommon):
    # Start testing
    def test_a_load_storage_part(self):
        self.load_and_create_csorder_no('300022404')

        # Find and Wait result_table_storage
        self.WAIT_XPATH('//table[@id="result_table_storage"]/tbody')
        self.assertTrue(True)

    def test_b_add_storage(self):
        add = self.driver.find_element_by_xpath('//button[@ng-click="modal_add_storage()"]')
        add.click()
        time.sleep(2)
        self.WAIT_XPATH('//select[@id="select_stat_service"]/option[2]')
        select_stat_service = self.driver.find_element_by_xpath('//select[@id="select_stat_service"]')
        Select(select_stat_service).select_by_index(1)
        self.WAIT_XPATH('//select[@id="select_mgmt_server"]/option[2]')
        select_mgmt_server = self.driver.find_element_by_xpath('//select[@id="select_mgmt_server"]')
        Select(select_mgmt_server).select_by_index(2)
        self.WAIT_XPATH('//select[@id="select_service_set"]/option[2]')
        select_service_set = self.driver.find_element_by_xpath('//select[@id="select_service_set"]')
        Select(select_service_set).select_by_index(2)

        # Wait when we select service_set, we request GET upload_server and upload_path by service_set.
        def wait_upload_path(driver):
            upload_path = driver.find_element_by_xpath('//input[@ng-model="ng.upload_path"]')
            value = upload_path.get_attribute('value')
            if value != "":
                return upload_path
            return False
        WebDriverWait(self.driver, 10).until(wait_upload_path)
        save = self.driver.find_element_by_xpath('//div[@ng-click="on_save()"]')
        save.click()
        # Wait until to close modal dialog.
        WebDriverWait(self.driver, 10) \
            .until(invisibility_of_element_located((By.XPATH, '//div[@class="modal-dialog"]')))
        self.assertTrue(True)

    def test_c_edit_storage(self):
        time.sleep(RESULT_WAIT_TIME)
        self.WAIT_XPATH('//button[@ng-click="modal_edit_storage($index)"]')
        edit = self.driver.find_element_by_xpath('//button[@ng-click="modal_edit_storage($index)"]')
        edit.click()

        def wait_upload_path(driver):
            upload_path = driver.find_element_by_xpath('//input[@ng-model="ng.upload_path"]')
            value = upload_path.get_attribute('value')
            if value != "":
                return upload_path
            return False
        WebDriverWait(self.driver, 10).until(wait_upload_path)
        save = self.driver.find_element_by_xpath('//div[@ng-click="on_save()"]')
        save.click()
        # Wait until to close modal dialog.
        WebDriverWait(self.driver, 10) \
            .until(invisibility_of_element_located((By.XPATH, '//div[@class="modal-dialog"]')))
        self.assertTrue(True)

    def test_d_delete_storage(self):
        time.sleep(RESULT_WAIT_TIME)
        self.WAIT_XPATH('//button[@ng-click="set_delete_index($index)"]')
        delete = self.driver.find_element_by_xpath('//button[@ng-click="set_delete_index($index)"]')
        delete.click()
        WebDriverWait(self.driver, 10) \
            .until(visibility_of_element_located((By.XPATH, '//div[@ng-click="modal_delete_storage()"]')))
        yes_delete = self.driver.find_element_by_xpath('//div[@ng-click="modal_delete_storage()"]')
        yes_delete.click()
        WebDriverWait(self.driver, 10) \
            .until(invisibility_of_element_located((By.XPATH, '//div[@ng-click="modal_delete_storage()"]')))
        self.assertTrue(True)
