import time

from selenium_test.shared_components import testcase
from selenium.webdriver.support.ui import Select

RESULT_WAIT_TIME = 2


class TestOPListTestCase(testcase.PrismTestCase):
    @classmethod
    def setUpClass(cls):
        super(TestOPListTestCase, cls).setUpClass()
        cls.direct_to('/customer/op_list/')

    def _click_search(self):
        btn_search = self.driver.find_element_by_xpath('//button[@ng-click="selectPage(1)"]')
        btn_search.click()

    def _get_index_of_table_by_column_name(self, column_name):
        ths = self.driver.find_elements_by_xpath('//table[@id="result_table"]/thead/tr/th')
        for i, th in enumerate(ths):
            if th.text == column_name:
                return i
        return -1

    def _get_content_of_table_by_index(self, index):
        result = []
        trs = self.driver.find_elements_by_xpath('//table[@id="result_table"]/tbody/tr')
        for tr in trs:
            tds = tr.find_elements_by_tag_name('td')
            for i, td, in enumerate(tds):
                if i == index:
                    result.append(td.text)
                    break
        return result

    def _get_contract_regions_by_index(self, index):
        tds = self.driver.find_elements_by_xpath('//table[@id="result_table"]/tbody/tr/td[%d]/div[@class]' % (index+1))
        return [td.get_attribute('class') for td in tds]

    # Start testing
    def test__a_start_page(self):
        #Check default value
        select_status = self.driver.find_element_by_xpath('.//select[@ng-model="ng.status"]')
        selected_value = Select(select_status).first_selected_option
        self.assertEqual(selected_value.text, 'Requested')

        search = self.driver.find_element_by_xpath('//input[@ng-model="ng.name"]')
        placeholder = search.get_attribute('placeholder')
        self.assertEqual(placeholder, 'Enter a account, Contract, Contract No, CS Order No, Platform or Product..')

    def test_a_contract_region(self):
        contract_region = self.driver.find_element_by_xpath('//select[@id="contract_region"]')
        Select(contract_region).select_by_value('1000')
        self._click_search()
        time.sleep(RESULT_WAIT_TIME)

        # Get contract region's class names.
        contract_region_idx = self._get_index_of_table_by_column_name('Contract Region')
        flags = self._get_contract_regions_by_index(contract_region_idx)

        # flags' length must not 0.
        self.assertNotEqual(len(flags), 0, 'Not found contract regions in result')
        for flag in flags:
            self.assertEqual(flag, 'flag-kr')

        # Recovery
        Select(contract_region).select_by_value('')

    def test_b_service_region(self):
        service_region = self.driver.find_element_by_xpath('//select[@id="service_region"]')
        Select(service_region).select_by_value('Local')
        self._click_search()
        time.sleep(RESULT_WAIT_TIME)

        # Get service region's class names.
        service_region_idx = self._get_index_of_table_by_column_name('Service Region')
        regions = self._get_content_of_table_by_index(service_region_idx)

        # regions' length must not 0.
        self.assertNotEqual(len(regions), 0, 'Not found service regions in result')
        for region in regions:
            self.assertEqual(region, 'Local')

        # Recovery
        Select(service_region).select_by_value('')

    def test_c_amsm(self):
        find_text = 'lee'
        amsm = self.driver.find_element_by_xpath('//input[@ng-model="ng.amsm"]')
        try:
            amsm.send_keys(find_text)
            self._click_search()
            time.sleep(RESULT_WAIT_TIME)

            am = self._get_index_of_table_by_column_name('AM')
            sm = self._get_index_of_table_by_column_name('SM')
            ams = self._get_content_of_table_by_index(am)
            sms = self._get_content_of_table_by_index(sm)

            for i in range(0, len(ams)):
                self.assertFalse(find_text not in ams[i].lower() and find_text not in sms[i].lower())
        finally:
            amsm.clear()

    def test_d_requested_time(self):
        select_status = self.driver.find_element_by_xpath('.//select[@ng-model="ng.status"]')
        Select(select_status).select_by_index(0)

        start_date = self.driver.find_element_by_xpath('//input[@ng-model="ng.start_date"]')
        end_date = self.driver.find_element_by_xpath('//input[@ng-model="ng.end_date"]')
        try:
            start_date.click()
            start_date.send_keys('2015-11-01')
            time.sleep(0.5)
            end_date.click()
            end_date.send_keys('2015-11-30')
            end_date.click()
            time.sleep(0.5)
            self._click_search()
            time.sleep(RESULT_WAIT_TIME)

            requested_time_idx = self._get_index_of_table_by_column_name('Requested\nOpening\nTermination')
            requested_times = self._get_content_of_table_by_index(requested_time_idx)

            self.assertNotEqual(len(requested_times), 0, 'No data')

            for rtime in requested_times:
                self.assertTrue(str(rtime).startswith('2015-11-'))
        finally:
            start_date.clear()
            end_date.clear()

    def test_e_status(self):
        select_status = self.driver.find_element_by_xpath('.//select[@ng-model="ng.status"]')
        try:
            Select(select_status).select_by_value('9')
            self._click_search()
            time.sleep(RESULT_WAIT_TIME)

            status_idx = self._get_index_of_table_by_column_name('Status')
            statuses = self._get_content_of_table_by_index(status_idx)

            self.assertNotEqual(len(statuses), 0)

            for status in statuses:
                self.assertEqual(status, 'Confirmed')
        finally:
            Select(select_status).select_by_value('')

    def test_f_account_name(self):
        account_name = 'CDNetworks Product Management'
        search_name = self.driver.find_element_by_xpath('.//input[@ng-model="ng.name"]')
        try:
            search_name.send_keys(account_name)
            self._click_search()
            time.sleep(RESULT_WAIT_TIME)

            account_idx = self._get_index_of_table_by_column_name('Account')
            accounts = self._get_content_of_table_by_index(account_idx)

            self.assertNotEqual(len(accounts), 0)

            for account in accounts:
                self.assertTrue(account_name in account)
        finally:
            search_name.clear()

    def test_g_contract_no(self):
        search_name = self.driver.find_element_by_xpath('.//input[@ng-model="ng.name"]')
        try:
            # We support like search, so If we send '40010' keys, we can get 40010XXX contract.
            search_name.send_keys('40010')
            self._click_search()
            time.sleep(RESULT_WAIT_TIME)

            idx = self._get_index_of_table_by_column_name('Contract No [Item No] / Contract / Product / Platform')
            contracts = self._get_content_of_table_by_index(idx)

            self.assertNotEqual(len(contracts), 0)

            for contract in contracts:
                self.assertTrue('40010' in contract)
        finally:
            search_name.clear()

    def test_h_contract_name(self):
        find_text = 'samsung'
        search_name = self.driver.find_element_by_xpath('.//input[@ng-model="ng.name"]')
        try:
            search_name.send_keys(find_text)
            self._click_search()
            time.sleep(RESULT_WAIT_TIME)

            idx = self._get_index_of_table_by_column_name('Contract No [Item No] / Contract / Product / Platform')
            contracts = self._get_content_of_table_by_index(idx)

            self.assertNotEqual(len(contracts), 0)

            for contract in contracts:
                self.assertTrue(find_text in contract.lower())
        finally:
            search_name.clear()

    def test_i_product_name(self):
        find_text = 'cloud storage'
        search_name = self.driver.find_element_by_xpath('.//input[@ng-model="ng.name"]')
        try:
            search_name.send_keys(find_text)
            self._click_search()
            time.sleep(RESULT_WAIT_TIME)

            idx = self._get_index_of_table_by_column_name('Contract No [Item No] / Contract / Product / Platform')
            contracts = self._get_content_of_table_by_index(idx)

            self.assertNotEqual(len(contracts), 0)

            for contract in contracts:
                self.assertTrue(find_text in contract.lower())
        finally:
            search_name.clear()

    def test_j_platform_name(self):
        find_text = 'cache(cs)'
        search_name = self.driver.find_element_by_xpath('.//input[@ng-model="ng.name"]')
        try:
            search_name.send_keys(find_text)
            self._click_search()
            time.sleep(RESULT_WAIT_TIME)

            idx = self._get_index_of_table_by_column_name('Contract No [Item No] / Contract / Product / Platform')
            contracts = self._get_content_of_table_by_index(idx)

            self.assertNotEqual(len(contracts), 0)

            for contract in contracts:
                self.assertTrue(find_text in contract.lower())
        finally:
            search_name.clear()

    def test_k_assign_sm(self):
        # Remove previous test result
        self._click_search()
        time.sleep(RESULT_WAIT_TIME)

        sm_idx = self._get_index_of_table_by_column_name('SM')
        first_sm_td = self.driver.find_element_by_xpath('//table[@id="result_table"]/tbody/tr/td[%d]' % (sm_idx + 1))
        first_sm_td.click()
        time.sleep(RESULT_WAIT_TIME)

        # Update SM to 'seungho.ryu'
        prime_sm = self.driver.find_element_by_xpath('//select[@ng-model="selected_prime"]')
        sub_sm = self.driver.find_element_by_xpath('//select[@ng-model="selected_sub"]')
        Select(prime_sm).select_by_value('seungho.ryu@cdnetworks.co.kr')
        Select(sub_sm).select_by_value('seungho.ryu@cdnetworks.co.kr')

        # Click save
        btn_save = self.driver.find_element_by_class_name('btn-success')
        btn_save.click()
        time.sleep(RESULT_WAIT_TIME)

        # Check first SM is whether 'seungho' or not
        first_sm_td = self.driver.find_element_by_xpath('//table[@id="result_table"]/tbody/tr/td[%d]' % (sm_idx + 1))
        self.assertTrue('seungho' in first_sm_td.text.lower())


