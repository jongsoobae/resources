import time

from selenium_test.shared_components import testcase
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support.expected_conditions import presence_of_element_located
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.by import By

RESULT_WAIT_TIME = 2
MAX_WAIT_TIME = 10


class TestOPListTestCase(testcase.PrismTestCase):
    @classmethod
    def setUpClass(cls):
        super(TestOPListTestCase, cls).setUpClass()
        cls.direct_to('/customer/storage_service/')

    def _click_search(self):
        btn_search = self.driver.find_element_by_xpath('//button[@ng-click="selectPage(1)"]')
        btn_search.click()

    def _get_index_of_table_by_column_name(self, column_name):
        ths = self.driver.find_elements_by_xpath('//table[@id="result_table"]/thead/tr/th')
        for i, th in enumerate(ths):
            if th.text == column_name:
                return i
        return -1

    def _get_first_content_of_table_by_index(self, index):
        tds = self.driver.find_elements_by_xpath('//table[@id="result_table"]/tbody/tr[1]/td')
        for i, td, in enumerate(tds):
            if i == index:
                return td.text
        return None

    def _get_content_of_table_by_index(self, index):
        result = []
        trs = self.driver.find_elements_by_xpath('//table[@id="result_table"]/tbody/tr')
        for tr in trs:
            tds = tr.find_elements_by_tag_name('td')
            for i, td, in enumerate(tds):
                if i == index:
                    result.append(td.text)
                    break
        return result

    # Start testing
    def test_a_load_mgmt_server(self):
        WebDriverWait(self.driver, MAX_WAIT_TIME).until(
            presence_of_element_located((By.XPATH, '//select[@id="select_mgmt_server"]/option[2]')))

        select_mgmt_server = self.driver.find_element_by_xpath('//select[@id="select_mgmt_server"]')
        self.assertTrue(len(Select(select_mgmt_server).options) > 1)

    def test_b_load_service_set(self):
        # If options length > 1, we assume to success loading mgmt server
        WebDriverWait(self.driver, MAX_WAIT_TIME).until(
            presence_of_element_located((By.XPATH, '//select[@id="select_mgmt_server"]/option[2]')))

        select_mgmt_server = self.driver.find_element_by_xpath('//select[@id="select_mgmt_server"]')

        select_value = 'not_exist_value'
        for opt in Select(select_mgmt_server).options:
            if opt.text != 'ALL':
                select_value = opt.text
                break
        Select(select_mgmt_server).select_by_visible_text(select_value)

        # If options length > 1, we assume to success loading service set
        WebDriverWait(self.driver, MAX_WAIT_TIME).until(
            presence_of_element_located((By.XPATH, '//select[@id="select_service_set"]/option[2]')))

        select_mgmt_server = self.driver.find_element_by_xpath('//select[@id="select_service_set"]')
        self.assertTrue(len(Select(select_mgmt_server).options) > 1)

    def test_c_change_mgmt(self):
        """
        If we change mgmt_server to 'ALL' on the state that service_set is selected,
        the service_set is removed all and its value set 'ALL'
        """
        # Select service set first value
        select_value = 'not_exist_value'
        select_mgmt_server = self.driver.find_element_by_xpath('//select[@id="select_mgmt_server"]')
        select_service_set = self.driver.find_element_by_xpath('//select[@id="select_service_set"]')
        for opt in Select(select_service_set).options:
            if opt.text != 'ALL':
                select_value = opt.text
                break
        Select(select_service_set).select_by_visible_text(select_value)
        # Change mgmt server
        Select(select_mgmt_server).select_by_visible_text('ALL')
        # Check service set count is 1
        self.assertTrue(len(Select(select_service_set).options) == 1)
        # Check selected value is 'ALL'
        self.assertTrue(Select(select_service_set).first_selected_option.text == 'ALL')

    def test_d_change_region(self):
        """
        If we change billing_region to another region ('JP') on the state that mgmt_server and service_set are selected,
        the mgmt_server and service_set are set 'ALL'
        """
        # page refresh
        self.driver.refresh()
        WebDriverWait(self.driver, MAX_WAIT_TIME).until(
            presence_of_element_located((By.XPATH, '//select[@id="select_mgmt_server"]/option[2]')))
        # Select mgmt_server and service set first value
        select_value = 'not_exist_value'
        select_mgmt_server = self.driver.find_element_by_xpath('//select[@id="select_mgmt_server"]')
        select_service_set = self.driver.find_element_by_xpath('//select[@id="select_service_set"]')
        for opt in Select(select_mgmt_server).options:
            if opt.text != 'ALL':
                select_value = opt.text
                break
        Select(select_mgmt_server).select_by_visible_text(select_value)     # Set mgmt_server to first value
        WebDriverWait(self.driver, MAX_WAIT_TIME).until(
            presence_of_element_located((By.XPATH, '//select[@id="select_service_set"]/option[2]')))
        for opt in Select(select_service_set).options:
            if opt.text != 'ALL':
                select_value = opt.text
                break
        Select(select_service_set).select_by_visible_text(select_value)     # Set service_set to first value

        # change billing region from KR to JP
        select_billing_region = self.driver.find_element_by_xpath('//select[@ng-model="ng.region"]')
        Select(select_billing_region).select_by_value('JP')
        WebDriverWait(self.driver, MAX_WAIT_TIME).until(
            presence_of_element_located((By.XPATH, '//select[@id="select_mgmt_server"]/option[2]')))

        # check whether mgmt_server is ALL
        self.assertTrue(Select(select_mgmt_server).first_selected_option.text == 'ALL')

        # check whether service_set is ALL
        self.assertTrue(Select(select_service_set).first_selected_option.text == 'ALL')

    def test_e_search_stat_service(self):
        # page refresh
        self.driver.refresh()
        # Search 'cdn' text in stat_service
        input_stat_service = self.driver.find_element_by_xpath('//input[@ng-model="ng.stat_service"]')
        input_stat_service.send_keys('cdn')
        self._click_search()
        source = self.driver.page_source

        def compare_source(driver):
            try:
                return source != driver.page_source
            except:
                pass
        WebDriverWait(self.driver, MAX_WAIT_TIME).until(compare_source)
        time.sleep(RESULT_WAIT_TIME)

        idx_stat_service = self._get_index_of_table_by_column_name('Stat Service')
        stat_services = self._get_content_of_table_by_index(idx_stat_service)

        for stat_service in stat_services:
            self.assertTrue('cdn' in stat_service.lower())
