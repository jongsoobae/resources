import unittest

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


class DNAMproxyAppDelRelatedTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='hyejun.yim')
    def test_given_user_is_internal_user_when_display_dna_mproxy_app_del_related_then_should_be_shown(self):
        driver = self.driver
        ###########################################################################################################
        driver.find_element(By.XPATH, "//span[contains(text(),'Select a Product')]").click()
        el1 = driver.find_element(By.ID, "leftnav_product_dropdown_chzn")
        el6 = el1.find_element(By.XPATH, ".//input[@type='text']")
        el6.clear()
        el6.send_keys('DNA')
        el6.send_keys(Keys.RETURN)

        driver.find_element(By.XPATH, "//a[contains(@href, '/config/dnaapp/mproxyapp')]").click()

        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, "//a[contains(text(),'mproxy.hjtest.com')]"))
        )

        driver.find_element(By.XPATH, "//a[contains(text(),'mproxy.hjtest.com')]").click()

        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, "//a[contains(text(),'Delete')]"))
        )

        driver.find_element(By.XPATH, "//a[contains(text(),'Delete')]").click()

        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, "//div[@id = 'content-right-wrapper']//a[contains(@href, 'domains')]"))
        )
        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
