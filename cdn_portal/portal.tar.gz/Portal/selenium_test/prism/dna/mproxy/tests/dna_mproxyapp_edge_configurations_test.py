import unittest
from time import sleep

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_constants import PRISM_FE_URL
from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


class DNAMproxyAppEdgeConfigurationsTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

        self.test_mproxyapp = 'mproxy.multirelay.com'
        self.test_mproxyedge = 'mproxy.multirelay.edge.com'

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='hyejun.yim')
    def test_origin_fb_option_is_dna_mproxy_app_edge_configuration(self):
        driver = self.driver
        ###########################################################################################################
        # move to DNA > DNA Apps list page
        driver.get('%s/config/dnaapp/mproxyapp/' % PRISM_FE_URL)

        driver.find_element(By.XPATH, "//a[text() = '" + self.test_mproxyapp + "']").click()

        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.ID, "id_save_mproxyapp"))
        )
        sleep(2)

        # Edge > origin fb Setting : Checked
        driver.find_element(By.XPATH, "//a[contains(text(), '8080,9030,4050')]").click()

        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, "//input[@value='Save']"))
        )

        driver.find_element(By.XPATH, "//fieldset[contains(@id, 'id_Advanced')]/h2/a[text()='Show']").click()
        sleep(1)

        driver.find_element(By.ID, "id_origin_fb").click()
        driver.find_element(By.XPATH, "//input[@value='Save']").click()

        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.ID, "id_save_mproxyapp"))
        )
        sleep(2)

        success_msg = driver.find_element(By.XPATH, "//div[@id='message_box']/ul[@class='messagelist']/li").text
        self.assertEqual(success_msg, 'The MProxy Configuration "' + self.test_mproxyapp + '(' + self.test_mproxyedge + ' -> 3dns_test)" was changed successfully.')

        # rollback
        driver.find_element(By.XPATH, "//a[contains(text(), '8080,9030,4050')]").click()

        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, "//input[@value='Save']"))
        )

        driver.find_element(By.XPATH, "//fieldset[contains(@id, 'id_Advanced')]/h2/a[text()='Show']").click()
        sleep(1)

        driver.find_element(By.ID, "id_origin_fb").click()
        driver.find_element(By.XPATH, "//input[@value='Save']").click()

        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.ID, "id_save_mproxyapp"))
        )
        sleep(2)

        success_msg = driver.find_element(By.XPATH, "//div[@id='message_box']/ul[@class='messagelist']/li").text
        self.assertEqual(success_msg, 'The MProxy Configuration "' + self.test_mproxyapp + '(' + self.test_mproxyedge + ' -> 3dns_test)" was changed successfully.')
        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
