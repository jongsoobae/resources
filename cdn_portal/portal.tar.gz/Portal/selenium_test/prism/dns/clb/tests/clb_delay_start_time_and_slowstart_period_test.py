import time

from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

from selenium_test.shared_components import testcase

class CDNSCLBTestCase(testcase.PrismTestCase):

    backup_delay_start_time = ""
    backup_slowstart_period = ""

    @classmethod
    def setUpClass(cls):
        super(CDNSCLBTestCase, cls).setUpClass()
        cls.direct_to('/dns/zones_list/')

        # find "clb.davidkimtest.com" zone
        test_dns_zone = "clb.davidkimtest.com"
        search_el = cls.driver.find_element(By.ID, "txt_search")
        search_el.clear()
        search_el.send_keys(test_dns_zone)

        cls.driver.find_element(By.ID, "btn_search").click()

        # wait for element and move dns zone page
        WebDriverWait(cls.driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[text()='"+test_dns_zone+"']"))
        )
        cls.driver.find_element(By.XPATH, "//a[text()='"+test_dns_zone+"']").click()

    @classmethod
    def tearDownClass(cls):
        super(CDNSCLBTestCase, cls).tearDownClass()

    def move_to_clb_domain_page(self, driver):
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "zone_name"))
        )
        clb_els = driver.find_elements(By.XPATH, "//span[@data-id='txt_host_name']")[0]
        div_el = clb_els.find_element(By.XPATH, "..//ancestor::div[@class='clear each-records']")
        div_el.find_element(By.XPATH, ".//a[@class='button-to-link']").click()
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//input[@ng-model='_add_clb.host_name']"))
        )
        time.sleep(2)

    def back_to_zone_page(self, driver):
        driver.find_element(By.XPATH, "//a[text()='Manage Zone']").click()

    def check_delay_start_time_and_slowstart_period_field(self, driver):
        # probe is null => If the changes are not saved.
        # probe not null => If the change successful.
        el_delay_start_time = driver.find_element(By.ID, "clb_delay_start_time")
        el_slowstart_period = driver.find_element(By.ID, "clb_slowstart_period")
        self.assertEqual(str(self.backup_delay_start_time), str(el_delay_start_time.get_attribute("value")))
        self.assertEqual(str(self.backup_slowstart_period), str(el_slowstart_period.get_attribute("value")))

class TestCDNSCLBPage(CDNSCLBTestCase):

    def test_clb_delay_start_time_and_slowstart_period_not_probe(self):
        driver = self.driver

        # wait for element and move clb domain page
        self.move_to_clb_domain_page(driver)

        # dealy_start_time, slowstart_period field backup
        el_delay_start_time = driver.find_element(By.ID, "clb_delay_start_time")
        el_slowstart_period = driver.find_element(By.ID, "clb_slowstart_period")
        self.backup_delay_start_time = el_delay_start_time.get_attribute("value")
        self.backup_slowstart_period = el_slowstart_period.get_attribute("value")
        el_delay_start_time.clear()
        el_delay_start_time.send_keys(33)
        el_slowstart_period.clear()
        el_slowstart_period.send_keys(33)

        Select(driver.find_element(By.XPATH, "//select[@ng-model='_add_clb.health_check_rule']")).select_by_visible_text("---------------------")

        driver.find_element(By.ID, "save_btn").click()
        # wait for alert box
        WebDriverWait(driver, 5).until(EC.alert_is_present())
        driver.switch_to_alert().accept()

        # wait for element and move clb domain page
        self.move_to_clb_domain_page(driver)

        # check delay_start_time, slowstart_period
        self.check_delay_start_time_and_slowstart_period_field(driver)

        self.back_to_zone_page(driver)

    def test_clb_delay_start_time_and_slowstart_period_is_probe(self):
        driver = self.driver

        # wait for element and move clb domain page
        self.move_to_clb_domain_page(driver)

        Select(driver.find_element(By.XPATH, "//select[@ng-model='_add_clb.health_check_rule']")).select_by_visible_text("TCP_8080")
        el_delay_start_time = driver.find_element(By.ID, "clb_delay_start_time")
        el_slowstart_period = driver.find_element(By.ID, "clb_slowstart_period")

        # dealy_start_time, slowstart_period field backup
        self.backup_delay_start_time = 22
        self.backup_slowstart_period = 22

        el_delay_start_time.clear()
        el_delay_start_time.send_keys(22)
        el_slowstart_period.clear()
        el_slowstart_period.send_keys(22)
        driver.find_element(By.ID, "save_btn").click()
        # wait for alert box
        WebDriverWait(driver, 5).until(EC.alert_is_present())
        driver.switch_to_alert().accept()

        # wait for element and move clb domain page
        self.move_to_clb_domain_page(driver)

        # check delay_start_time, slowstart_period
        self.check_delay_start_time_and_slowstart_period_field(driver)

        # reset
        el_delay_start_time = driver.find_element(By.ID, "clb_delay_start_time")
        el_slowstart_period = driver.find_element(By.ID, "clb_slowstart_period")
        el_delay_start_time.clear()
        el_delay_start_time.send_keys(2)
        el_slowstart_period.clear()
        el_slowstart_period.send_keys(2)

        driver.find_element(By.ID, "save_btn").click()
        # wait for alert box
        WebDriverWait(driver, 5).until(EC.alert_is_present())
        driver.switch_to_alert().accept()

    def test_clb_delay_start_time_and_slowstart_period_min_max_value(self):
        driver = self.driver

        # wait for element and move clb domain page
        self.move_to_clb_domain_page(driver)

        Select(driver.find_element(By.XPATH, "//select[@ng-model='_add_clb.health_check_rule']")).select_by_visible_text("TCP_8080")
        # dealy_start_time(1~172800), slowstart_period(0~4294967295)
        el_delay_start_time = driver.find_element(By.ID, "clb_delay_start_time")
        el_slowstart_period = driver.find_element(By.ID, "clb_slowstart_period")

        # Min error check
        el_delay_start_time.clear()
        el_delay_start_time.send_keys(0)
        el_slowstart_period.clear()
        el_slowstart_period.send_keys(-1)

        driver.find_element(By.ID, "save_btn").click()
        time.sleep(1)

        err_delay_start_time = driver.find_element(By.ID, "err_delay_start_time")
        err_slowstart_period = driver.find_element(By.ID, "err_slowstart_period")

        self.assertEqual(err_delay_start_time.text, "Ensure this value is greater than or equal to 1.")
        self.assertEqual(err_slowstart_period.text, "Ensure this value is greater than or equal to 0.")

        # Max error check
        el_delay_start_time.clear()
        el_delay_start_time.send_keys(1873444)
        el_slowstart_period.clear()
        el_slowstart_period.send_keys(4294968000)

        driver.find_element(By.ID, "save_btn").click()
        time.sleep(1)

        err_delay_start_time = driver.find_element(By.ID, "err_delay_start_time")
        err_slowstart_period = driver.find_element(By.ID, "err_slowstart_period")

        self.assertEqual(err_delay_start_time.text, "Ensure this value is less than or equal to 172800.")
        self.assertEqual(err_slowstart_period.text, "Ensure this value is less than or equal to 4294967295.")

        self.back_to_zone_page(driver)
