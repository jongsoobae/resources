import unittest

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_constants import PRISM_FE_URL
from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


class CDNSZoneAddCustomerSelectTest(unittest.TestCase):

    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='hyejun.yim')
    def test_select_customer_list_when_adding_zone(self):
        driver = self.driver

        # move to dns zone list page
        driver.get('%s/dns/zones_list/' % PRISM_FE_URL)

        # find add new zone button
        add_new_zone_btn = driver.find_element(By.XPATH, "//a[contains(text(), 'Add New Zone')]")
        add_new_zone_btn.click()

        # move dns zone add page and wait for element
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//label[contains(text(),'Step 1. Add New Zone')]"))
        )

        # select fixture customer
        customer_select_list = driver.find_elements(By.XPATH, "//select[@id = 'select_customer']/option")
        customer_chk = []
        for customer in customer_select_list[1:]: # Exclude "---- Please select ----"
            text = (customer.text.strip())[:-5]  # Exclude "region code(ex: [US])"
            value = customer.get_attribute("value")
            if {text:value} in customer_chk:
                raise
            customer_chk.append({text:value})


if __name__ == '__main__':
    unittest.main()
