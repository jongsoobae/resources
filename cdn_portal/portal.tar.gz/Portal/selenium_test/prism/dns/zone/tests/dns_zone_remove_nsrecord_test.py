import unittest
from datetime import datetime
import hashlib

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_constants import PRISM_FE_URL
from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


class CDNSZonePageTest(unittest.TestCase):

    def setUp(self):

        # test fixture : 88 brothers (customer id -> 3568, valid contract id -> 40010572)
        self.fixture_dns_customer_id = "3568"
        self.fixture_dns_customer_contract_id = "40010572"

        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    def add_dns_zone(self, driver, zone_domain_name):

        # move to dns zone list page
        driver.get('%s/dns/zones_list/' % PRISM_FE_URL)

        # find add new zone button
        add_new_zone_btn = driver.find_element(By.XPATH, "//a[contains(text(), 'Add New Zone')]")
        add_new_zone_btn.click()

        # move dns zone add page and wait for element
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//label[contains(text(),'Step 1. Add New Zone')]"))
        )

        # select fixture customer
        customer_select_box = driver.find_element(By.XPATH, "//select[@id = 'select_customer']")
        Select(customer_select_box).select_by_value(self.fixture_dns_customer_id)

        # select contract
        contract_select_box = driver.find_element(By.XPATH, "//select[@id = 'select_contract']")
        Select(contract_select_box).select_by_value(self.fixture_dns_customer_contract_id)

        # insert domain name
        domain_name_input = driver.find_element(By.XPATH, "//input[@id='id_zone_name']")
        domain_name_input.clear()
        domain_name_input.send_keys(zone_domain_name)

        # click add btn
        domain_add_button = driver.find_element(By.XPATH, "//input[@id='btn_add_domain']")
        domain_add_button.click()

        # wait confirm window
        confirm_zone_btn_xpath = (By.XPATH, "//input[@id='confirm_zone_yes']")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located(confirm_zone_btn_xpath)
        )

        # click confirm btn
        confirm_zone_btn = driver.find_element(*confirm_zone_btn_xpath)
        confirm_zone_btn.click()

        # wait for next page
        dns_zone_phase2_xpath = (By.XPATH, "//label[contains(text(),'Step 2. Add and Review')]")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located(dns_zone_phase2_xpath)
        )

    def remove_dns_zone(self, driver, zone_domain_name):

        # move to dns zone list page query result
        driver.get('%s/dns/zones_list/?q=%s' % (PRISM_FE_URL, zone_domain_name))

        # find dummy zone delete button
        delete_dummy_zone_btn = driver.find_element(By.XPATH, "//a[@data-name='%s']" % zone_domain_name)
        delete_dummy_zone_btn.click()

        # find confirm btn and click to delete dns zone
        delete_confirm_btn = driver.find_element(By.XPATH, "//button[@id='btn_delete_yes']")
        delete_confirm_btn.click()

    def get_dummy_dns_zone_name(self):

        now = datetime.now()

        date = now.strftime('%Y%m%d')
        time_hash = hashlib.sha224(now.strftime('%H:%M:%s')).hexdigest()[:8]

        zone_domain_name = 'se_test-%s-%s-%s' % ('juwonlee', date, time_hash)

        return zone_domain_name

    @catch_exception(author='juwon.lee')
    def test_add_remove_dns_zone(self):
        driver = self.driver

        zone_domain_name = self.get_dummy_dns_zone_name()

        self.add_dns_zone(driver, zone_domain_name)
        self.remove_dns_zone(driver, zone_domain_name)

    @catch_exception(author='juwon.lee')
    def test_zone_ns_record_should_not_remove_when_only_one_exists(self):
        driver = self.driver

        # define test xpath
        ns_record_delete_btn_xpath = (By.XPATH, "//a[contains(text(), 'Delete')]")
        ns_record_delete_confirm_btn_xpath = (By.XPATH, "//input[@id='btn_yes_delete']")
        ns_record_container_xpath = (By.XPATH, "//div[@id='s3_ns']")

        # get dummy dns zone name & create dummy dns zone
        zone_domain_name = self.get_dummy_dns_zone_name()
        self.add_dns_zone(driver, zone_domain_name)

        # Add remove ns record task
        ns_record_div_container = driver.find_element(*ns_record_container_xpath)
        ns_record_items = ns_record_div_container.find_elements_by_class_name('cdns-record')

        # first generated dns zone should have 2 ns record's.
        self.assertEqual(len(ns_record_items), 2)

        # ns record elements should be div element
        for ns_record in ns_record_items:
            self.assertEqual(ns_record.tag_name, 'div')

        # remove first ns record
        first_ns_record_delete_btn = ns_record_items[0].find_element(*ns_record_delete_btn_xpath)
        first_ns_record_delete_btn.click()

        # confirm delete
        delete_confirm_btn = driver.find_element(*ns_record_delete_confirm_btn_xpath)
        delete_confirm_btn.click()

        # refresh current page
        driver.refresh()

        # check ns record container
        ns_record_div_container = driver.find_element(*ns_record_container_xpath)
        ns_record_items = ns_record_div_container.find_elements_by_class_name('cdns-record')
        # ns record should be exists.
        self.assertEqual(len(ns_record_items), 1)

        # find second ns record delete btn
        second_ns_record_delete_btn = ns_record_items[0].find_element(*ns_record_delete_btn_xpath)
        second_ns_record_delete_btn.click()

        delete_confirm_btn = driver.find_element(*ns_record_delete_confirm_btn_xpath)
        delete_confirm_btn.click()

        # if user deletes ns record when only one ns record remains, then show warning box.
        ns_warning_box = driver.find_element(By.XPATH, "//div[@id='wb_ns_form']")
        # check warningbox message
        self.assertEqual(ns_warning_box.text, "You must specify at least one name server.")

        # last ns record should not deleted.
        final_ns_record_items = ns_record_div_container.find_elements_by_class_name('cdns-record')
        self.assertEqual(len(final_ns_record_items), 1)

        # remove after ns record test
        self.remove_dns_zone(driver, zone_domain_name)

if __name__ == '__main__':
    unittest.main()
