
from selenium_test.shared_components.testcase import PrismTestCase


class TestDnsZoneScrollArea(PrismTestCase):

    dns_zone_page_uri = '/dns/zone/11201'

    def setUp(self):
        self.direct_to(self.dns_zone_page_uri)

    def test_dns_zone_field_area_is_scrollable(self):
        dns_zone_field_area = self.driver.find_element_by_xpath('//div[@id="edit_form"]')

        height = dns_zone_field_area.value_of_css_property('height')
        overflow = dns_zone_field_area.value_of_css_property('overflow-y')

        self.assertEqual(height, '600px')
        self.assertEqual(overflow, 'scroll')
