import unittest

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.prism.feo.cluster.cluster import feo_add_new_cluster, feo_delete_cluster
from selenium_test.prism.feo.cluster.location import feo_add_new_location, feo_delete_location
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


class FEOClusterPageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_logged_in_when_display_feo_cluster_page_then_should_be_shown(self):
        driver = self.driver
        ###########################################################################################################
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//span[contains(text(),'Select a Product')]"))
        )

        driver.find_element(By.XPATH, "//span[contains(text(),'Select a Product')]").click()
        el1 = driver.find_element(By.ID, "leftnav_product_dropdown_chzn")
        el6 = el1.find_element(By.XPATH, ".//input[@type='text']")
        el6.clear()
        el6.send_keys('FEO')
        el6.send_keys(Keys.RETURN)

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '#config-wpo')]"))
        )

        driver.find_element(By.XPATH, "//a[contains(@href, '#config-wpo')]").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '/wpo/cluster/')]"))
        )

        driver.find_element(By.XPATH, "//a[contains(@href, '/wpo/cluster/')]").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "h1"))
        )

        page_title = driver.find_element(By.CSS_SELECTOR, "h1").text

        self.assertEqual('FEO Clusters', page_title)
        ###########################################################################################################

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_logged_in_when_add_new_feo_location_with_valid_data_then_should_be_added(self):
        driver = self.driver
        location_name = feo_add_new_location(driver)
        self.assertEqual(location_name, driver.find_element(By.CSS_SELECTOR, "div.wpo_float_wrapper > div > div.ng-scope > div.success_msg.ng-binding > b.ng-binding").text)

        # Delete newly added location.
        self.assertTrue(feo_delete_location(driver, location_name))
        ###########################################################################################################

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_logged_in_when_add_new_feo_cluster_with_valid_data_then_should_be_added(self):
        driver = self.driver
        location_name = feo_add_new_location(driver)
        self.assertEqual(location_name, driver.find_element(By.CSS_SELECTOR, "div.wpo_float_wrapper > div > div.ng-scope > div.success_msg.ng-binding > b.ng-binding").text)
        cluster_name = feo_add_new_cluster(driver, location_name)
        self.assertEqual(cluster_name, driver.find_element(By.CSS_SELECTOR, "div.success_msg.ng-binding > b.ng-binding").text)
        # Delete newly added cluster and location.
        self.assertTrue(feo_delete_cluster(driver, cluster_name))
        self.assertTrue(feo_delete_location(driver, location_name))
        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
