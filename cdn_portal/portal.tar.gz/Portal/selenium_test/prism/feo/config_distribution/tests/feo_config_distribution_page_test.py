import unittest

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


class FEOConfigDistributionPageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_logged_in_when_display_feo_config_distribution_page_then_should_be_shown(self):
        driver = self.driver
        ###########################################################################################################
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//span[contains(text(),'Select a Product')]"))
        )

        driver.find_element(By.XPATH, "//span[contains(text(),'Select a Product')]").click()
        el1 = driver.find_element(By.ID, "leftnav_product_dropdown_chzn")
        el6 = el1.find_element(By.XPATH, ".//input[@type='text']")
        el6.clear()
        el6.send_keys('FEO')
        el6.send_keys(Keys.RETURN)

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '#config-wpo')]"))
        )

        driver.find_element(By.XPATH, "//a[contains(@href, '#config-wpo')]").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '/config/wpo')]"))
        )

        driver.find_element(By.XPATH, "//a[contains(@href, '/config/wpo')]").click()

        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "div.info-panel"))
        )

        info_text = driver.find_element(By.CSS_SELECTOR, "div.info-panel").text

        self.assertTrue('Web Performance Optimization' in info_text)
        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
