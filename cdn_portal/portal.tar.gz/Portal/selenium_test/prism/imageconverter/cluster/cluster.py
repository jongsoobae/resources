import time

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select

from datetime import datetime
from selenium_test.shared_components.conf import settings


def ic_add_new_cluster(driver, location_name):
    driver.get(settings.PRISM_FE_URL + "/")
    ###########################################################################################################
    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.ID, "leftnav_product_dropdown_chzn"))
    )

    driver.find_element(By.ID, "leftnav_product_dropdown_chzn").click()
    product_selector = driver.find_element(By.ID, "leftnav_product_dropdown_chzn")
    product_search_input = product_selector.find_element(By.XPATH, ".//input[@type='text']")
    product_search_input.clear()
    product_search_input.send_keys('Cloud Image Converter')
    product_search_input.send_keys(Keys.RETURN)

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '#config-ic')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '#config-ic')]").click()

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '/ic/cluster/')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '/ic/cluster/')]").click()

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, "h1"))
    )

    WebDriverWait(driver, 120).until(
        EC.invisibility_of_element_located((By.CLASS_NAME, "overlay-loader"))
    )

    WebDriverWait(driver, 120).until(
        EC.element_to_be_clickable((By.XPATH, "//button[@ng-click = 'openModal(forms.cluster, null)']"))
    )

    driver.find_element(By.XPATH, "//button[@ng-click = 'openModal(forms.cluster, null)']").click()

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.NAME, "cluster_name"))
    )

    i = 1
    date_str = datetime.now().strftime('%Y%m%d')
    retry = 20
    while retry:
        cluster_name = "-".join(['cluster', date_str, str(i)])
        driver.find_element(By.NAME, "cluster_name").clear()
        driver.find_element(By.NAME, "cluster_name").send_keys(cluster_name)
        Select(driver.find_element_by_name("wpo_location")).select_by_visible_text(location_name)
        driver.find_element(By.XPATH, "//input[@ng-model = 'cluster.info.description']").clear()
        driver.find_element(By.XPATH, "//input[@ng-model = 'cluster.info.description']").send_keys('test')
        driver.find_element(By.XPATH, "//button[@ng-click = 'clusterDetail(forms.cluster, cluster.info, $event)']").click()

        timeout = 120
        while timeout:
            time.sleep(5)
            try:
                if driver.find_element(By.CSS_SELECTOR, "div.success_msg.ng-binding > b.ng-binding").is_displayed():
                    return cluster_name
                elif any(map(lambda x: x.is_displayed(), driver.find_elements(By.CSS_SELECTOR, "span.wpo_validation_msg.invalid"))):
                    i += 1
                    break
                else:
                    timeout -= 5
                    pass
            except:
                timeout -= 5
                pass

        retry -= 1

    return cluster_name


def ic_delete_cluster(driver, cluster_name):
    driver.get(settings.PRISM_FE_URL + "/")
    ###########################################################################################################
    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.ID, "leftnav_product_dropdown_chzn"))
    )

    driver.find_element(By.ID, "leftnav_product_dropdown_chzn").click()
    product_selector = driver.find_element(By.ID, "leftnav_product_dropdown_chzn")
    product_search_input = product_selector.find_element(By.XPATH, ".//input[@type='text']")
    product_search_input.clear()
    product_search_input.send_keys('Cloud Image Converter')
    product_search_input.send_keys(Keys.RETURN)

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '#config-ic')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '#config-ic')]").click()

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '/ic/cluster/')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '/ic/cluster/')]").click()

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, "h1"))
    )

    WebDriverWait(driver, 120).until(
        EC.invisibility_of_element_located((By.CLASS_NAME, "overlay-loader"))
    )

    WebDriverWait(driver, 120).until(
        EC.element_to_be_clickable((By.XPATH, "//table[@sort-info = 'cluster.sort_params']//td[text() = '" + cluster_name+ "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Delete']"))
    )

    delete_modal_button = driver.find_element(By.XPATH, "//table[@sort-info = 'cluster.sort_params']//td[text() = '" + cluster_name+ "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Delete']")
    delete_modal_button.click()

    WebDriverWait(driver, 120).until(
        EC.element_to_be_clickable((By.XPATH, "//div[@id = 'delete_modal']//div[@class='modal-footer']//button[@ng-click = 'deleteOk(delete_action_target, $event)']"))
    )
    delete_button = driver.find_element(By.XPATH, "//div[@id = 'delete_modal']//div[@class='modal-footer']//button[@ng-click = 'deleteOk(delete_action_target, $event)']")
    delete_button.click()

    try:
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "div.wpo_float_wrapper > div > div.ng-scope > div.success_msg.ng-binding"))
        )
    except:
        return False
    else:
        return True
    ###########################################################################################################
