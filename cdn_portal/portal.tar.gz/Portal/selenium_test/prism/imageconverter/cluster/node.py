import time
import random
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from selenium_test.shared_components.conf import settings


def ic_add_new_node(driver, cluster_name):
    driver.get(settings.PRISM_FE_URL + "/")
    ###########################################################################################################
    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.ID, "leftnav_product_dropdown_chzn"))
    )

    driver.find_element(By.ID, "leftnav_product_dropdown_chzn").click()
    product_selector = driver.find_element(By.ID, "leftnav_product_dropdown_chzn")
    product_search_input = product_selector.find_element(By.XPATH, ".//input[@type='text']")
    product_search_input.clear()
    product_search_input.send_keys('Cloud Image Converter')
    product_search_input.send_keys(Keys.RETURN)

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '#config-ic')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '#config-ic')]").click()

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '/ic/cluster/')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '/ic/cluster/')]").click()

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, "h1"))
    )

    WebDriverWait(driver, 120).until(
        EC.invisibility_of_element_located((By.CLASS_NAME, "overlay-loader"))
    )

    WebDriverWait(driver, 120).until(
        EC.element_to_be_clickable((By.XPATH, "//table[@sort-info = 'cluster.sort_params']//td[text() = '" + cluster_name+ "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Edit']"))
    )

    cluster_edit_button = driver.find_element(By.XPATH, "//table[@sort-info = 'cluster.sort_params']//td[text() = '" + cluster_name+ "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Edit']")
    cluster_edit_button.click()

    WebDriverWait(driver, 120).until(
        EC.element_to_be_clickable((By.XPATH, "//button[@ng-click = 'openModal(forms.node, null)']"))
    )

    WebDriverWait(driver, 120).until(
        EC.invisibility_of_element_located((By.CLASS_NAME, "overlay-loader"))
    )

    driver.find_element(By.XPATH, "//button[@ng-click = 'openModal(forms.node, null)']").click()

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.NAME, "node_type"))
    )

    retry = 20
    while retry:
        Select(driver.find_element_by_name("node_type")).select_by_visible_text('WPO')
        driver.find_element(By.XPATH, "//input[@ng-model = 'node.info.vip_id']").clear()
        driver.find_element(By.XPATH, "//input[@ng-model = 'node.info.vip_id']").send_keys(str(random.randrange(1, 256)))

        try:
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//ul[@id = 'ui-id-1']//li"))
            )
            if driver.find_elements(By.XPATH, "//ul[@id = 'ui-id-1']//li").__len__() > 0:
                vip_count = driver.find_elements(By.XPATH, "//ul[@id = 'ui-id-1']//li").__len__()
                random_index = random.randrange(0, vip_count)
                node_name = driver.find_elements(By.XPATH, "//ul[@id = 'ui-id-1']//li")[random_index].text
                driver.find_elements(By.XPATH, "//ul[@id = 'ui-id-1']//li")[random_index].click()
            else:
                continue
        except:
            continue

        driver.find_element(By.XPATH, "//textarea[@ng-model = 'node.info.description']").clear()
        driver.find_element(By.XPATH, "//textarea[@ng-model = 'node.info.description']").send_keys('test')
        driver.find_element(By.XPATH, "//button[@ng-click = 'saveOk(forms.node, node.info, $event)']").click()

        timeout = 120
        while timeout:
            time.sleep(5)
            try:
                if driver.find_element(By.XPATH, "//span[@ng-show = '!is_able_to_be_activated']").is_displayed():
                    except_count = 1
                else:
                    except_count = 0

                if driver.find_element(By.CSS_SELECTOR, "div.panel-body > div > div.ng-scope > div.success_msg.ng-binding").is_displayed():
                    return node_name
                elif sum(map(lambda x: x.is_displayed(), driver.find_elements(By.CSS_SELECTOR, "span.wpo_validation_msg.invalid"))) > 1 - except_count:
                    break
                else:
                    timeout -= 5
                    pass
            except:
                timeout -= 5
                pass

        retry -= 1

    return node_name


def ic_delete_node(driver, cluster_name, node_name):
    driver.get(settings.PRISM_FE_URL + "/")
    ###########################################################################################################
    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.ID, "leftnav_product_dropdown_chzn"))
    )

    driver.find_element(By.ID, "leftnav_product_dropdown_chzn").click()
    product_selector = driver.find_element(By.ID, "leftnav_product_dropdown_chzn")
    product_search_input = product_selector.find_element(By.XPATH, ".//input[@type='text']")
    product_search_input.clear()
    product_search_input.send_keys('Cloud Image Converter')
    product_search_input.send_keys(Keys.RETURN)

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '#config-ic')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '#config-ic')]").click()

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '/ic/cluster/')]"))
    )

    driver.find_element(By.XPATH, "//a[contains(@href, '/ic/cluster/')]").click()

    WebDriverWait(driver, 120).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, "h1"))
    )

    WebDriverWait(driver, 120).until(
        EC.invisibility_of_element_located((By.CLASS_NAME, "overlay-loader"))
    )

    WebDriverWait(driver, 120).until(
        EC.element_to_be_clickable((By.XPATH, "//table[@sort-info = 'cluster.sort_params']//td[text() = '" + cluster_name+ "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Delete']"))
    )

    cluster_edit_button = driver.find_element(By.XPATH, "//table[@sort-info = 'cluster.sort_params']//td[text() = '" + cluster_name+ "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Edit']")
    cluster_edit_button.click()

    WebDriverWait(driver, 120).until(
        EC.element_to_be_clickable((By.XPATH, "//table[@sort-info = 'node.sort_params']//td[text() = '" + node_name + "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Delete']"))
    )

    WebDriverWait(driver, 120).until(
        EC.invisibility_of_element_located((By.CLASS_NAME, "overlay-loader"))
    )

    delete_modal_button = driver.find_element(By.XPATH, "//table[@sort-info = 'node.sort_params']//td[text() = '" + node_name + "']/following-sibling::td/following-sibling::td/following-sibling::td/following-sibling::td//button[@title = 'Delete']")
    delete_modal_button.click()

    WebDriverWait(driver, 120).until(
        EC.element_to_be_clickable((By.XPATH, "//div[@id = 'delete_modal']//div[@class='modal-footer']//button[@ng-click = 'deleteOk(delete_action_target, $event)']"))
    )
    delete_button = driver.find_element(By.XPATH, "//div[@id = 'delete_modal']//div[@class='modal-footer']//button[@ng-click = 'deleteOk(delete_action_target, $event)']")
    delete_button.click()

    try:
        WebDriverWait(driver, 120).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "div.panel-body > div > div.ng-scope > div.success_msg.ng-binding > b.ng-binding"))
        )
    except:
        return False
    else:
        return True
    ###########################################################################################################
