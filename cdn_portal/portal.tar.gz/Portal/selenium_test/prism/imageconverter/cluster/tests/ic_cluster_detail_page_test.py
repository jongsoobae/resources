import unittest

from selenium.webdriver.common.by import By
from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.prism.imageconverter.cluster.cluster import ic_add_new_cluster, ic_delete_cluster
from selenium_test.prism.imageconverter.cluster.location import ic_add_new_location, ic_delete_location
from selenium_test.prism.imageconverter.cluster.node import ic_add_new_node, ic_delete_node
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


class ICClusterDetailPageTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='jaeik.lee')
    def test_given_user_is_logged_in_when_add_new_ic_node_with_valid_data_then_should_be_added(self):
        driver = self.driver
        location_name = ic_add_new_location(driver)
        self.assertEqual(location_name, driver.find_element(By.CSS_SELECTOR, "div.wpo_float_wrapper > div > div.ng-scope > div.success_msg.ng-binding > b.ng-binding").text)
        cluster_name = ic_add_new_cluster(driver, location_name)
        self.assertEqual(cluster_name, driver.find_element(By.CSS_SELECTOR, "div.success_msg.ng-binding > b.ng-binding").text)
        node_name = ic_add_new_node(driver, cluster_name)
        self.assertEqual(node_name, driver.find_element(By.CSS_SELECTOR, "div.panel-body > div > div.ng-scope > div.success_msg.ng-binding > b.ng-binding").text)

        # Delete newly added cluster and location.
        self.assertTrue(ic_delete_node(driver, cluster_name, node_name))
        self.assertTrue(ic_delete_cluster(driver, cluster_name))
        self.assertTrue(ic_delete_location(driver, location_name))
        ###########################################################################################################

if __name__ == '__main__':
    unittest.main()
