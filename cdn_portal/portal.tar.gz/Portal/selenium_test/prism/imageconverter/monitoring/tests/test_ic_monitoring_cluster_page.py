
import unittest

from selenium.webdriver.common.by import By

from selenium_test.config_constants import PRISM_FE_URL
from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


class TestIcMonitoringClusterPage(unittest.TestCase):

    xpath_cic_monitoring_header = (By.XPATH, '//h3[@class="ic-monitoring-page-title"]')
    xpath_cic_monitoring_cluster_header = (By.XPATH, '//h4[@class="ic-monitoring-cluster-name"]')
    xpath_cic_monitoring_cluster_table = (By.XPATH, '//thead[@class="ic-monitoring-table-header"]')

    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

        self.driver.get('%s/%s' % (PRISM_FE_URL, 'ic/monitoring/'))

    def tearDown(self):
        self.driver.quit()

    def test_user_can_access_to_cluster_page(self):

        cic_monitoring_page_title_element = self.driver.find_element(
            *self.xpath_cic_monitoring_header)

        # monitoring page should be shown
        self.assertIsNotNone(cic_monitoring_page_title_element)
        self.assertEqual(cic_monitoring_page_title_element.text,
            'CIC Cluster Status')

    def test_cluster_page_table_header_should_be_shown(self):

        cic_monitoring_cluster_name_list = self.driver.find_elements(
            *self.xpath_cic_monitoring_cluster_header)

        # monitoring page's cluster list should be shown
        self.assertTrue(len(cic_monitoring_cluster_name_list) > 0)

        cic_monitoring_cluster_table_header = self.driver.find_elements(
            *self.xpath_cic_monitoring_cluster_table)

        # each cluster section has cluster table UI
        self.assertEqual(
            len(cic_monitoring_cluster_name_list),
            len(cic_monitoring_cluster_table_header))

        cic_header_items = cic_monitoring_cluster_table_header[0].find_elements(By.XPATH, './/th')

        # cluster table should have 11 columns
        self.assertEqual(len(cic_header_items), 11)

        header_texts = [
            'Type', 'Hostname', 'IP',
            'Node Status', 'App Status',
            'CPU', 'Mem', 'IOWait', 'Traffic',
            'Base ver.', 'Config ver.'
        ]

        # each column should equals to referenced text
        for header_item, header_text in zip(cic_header_items, header_texts):
            self.assertEqual(header_item.text, header_text)
