
import unittest

from selenium.webdriver.common.by import By

from selenium_test.config_constants import PRISM_FE_URL
from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


class TestIcMonitoringNodeDetailPage(unittest.TestCase):

    xpath_node_detail_page_title = (By.XPATH, '//h3[@class="ic-monitoring-page-title"]')
    xpath_back_to_cluster_status = (By.XPATH, './/a[contains(text(), "Back to Cluster Status")]')
    xpath_node_detail_summary_section = (By.XPATH, '//section[@class="node-detail-status-container"]')
    xpath_summary_subcolumn = (By.XPATH, './/div[@class="col-xs-6"]')
    xpath_summary_column_header = (By.XPATH, './/h6[@class="node-detail-status-header"]')
    xpath_rrd_timerange_button = (By.XPATH, '//button[@ng-model="rrdType"]')
    xpath_rrd_panel_header = (By.XPATH, './/div[@class="panel-heading"]')

    ic_node_fixture_id = 15

    def setUp(self):
        self.driver = get_web_driver()

        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

        node_detail_page_path = 'ic/monitoring/#/node/%s' % self.ic_node_fixture_id
        self.driver.get('%s/%s' % (PRISM_FE_URL, node_detail_page_path))

    def tearDown(self):
        self.driver.quit()

    def test_node_detail_page_should_be_shown(self):

        node_detail_page_title = self.driver.find_element(*self.xpath_node_detail_page_title)

        # node detail page title should be shown
        self.assertTrue(node_detail_page_title.text.find('CIC Node Status') > -1)


    def test_back_to_cluster_status_link_should_be_shown(self):

        node_detail_page_title = self.driver.find_element(*self.xpath_node_detail_page_title)
        back_to_cluster_status_link = node_detail_page_title.find_element(*self.xpath_back_to_cluster_status)

        # back to cluster link should be shown
        self.assertIsNotNone(back_to_cluster_status_link)
        self.assertEqual(back_to_cluster_status_link.get_attribute('href'), '%s/ic/monitoring/#/' % PRISM_FE_URL)

    def test_node_detail_page_summary_section_should_be_shown(self):

        node_detail_summary_section = self.driver.find_element(*self.xpath_node_detail_summary_section)
        self.assertIsNotNone(node_detail_summary_section)

        summary_columns = node_detail_summary_section.find_elements(By.XPATH, './/div[@class="col-xs-4"]')
        self.assertEqual(len(summary_columns), 3)

        vip_name = summary_columns[0].find_element(By.XPATH, './/h3[@class="node-detail-vip ng-binding"]')
        self.assertIsNotNone(vip_name)

        hostname = summary_columns[0].find_element(By.XPATH, './/h4[@class="node-detail-hostname ng-binding"]')
        self.assertIsNotNone(hostname)

        status_columns = summary_columns[1].find_elements(*self.xpath_summary_subcolumn)
        self.assertEqual(len(status_columns), 2)

        node_status_header = status_columns[0].find_element(*self.xpath_summary_column_header)
        self.assertEqual(node_status_header.get_attribute('innerHTML'), 'Node Status')

        app_status_header = status_columns[1].find_element(*self.xpath_summary_column_header)
        self.assertEqual(app_status_header.get_attribute('innerHTML'), 'App Status')

        revision_columns = summary_columns[2].find_elements(*self.xpath_summary_subcolumn)

        base_version_header = revision_columns[0].find_element(*self.xpath_summary_column_header)
        self.assertEqual(base_version_header.get_attribute('innerHTML'), 'Base Version')

        config_version_header = revision_columns[1].find_element(*self.xpath_summary_column_header)
        self.assertEqual(config_version_header.get_attribute('innerHTML'), 'Config Version')

    def test_rrd_section_should_be_shown(self):

        # get rrd panel elements in node detail page
        rrd_panels = self.driver.find_elements(By.XPATH, '//div[@class="panel panel-default ic-monitoring-rrd-panel"]')
        self.assertEqual(len(rrd_panels), 2)

        # system rrd panel is first element. and next is network panel
        system_rrd_panel = rrd_panels[0]
        network_rrd_panel = rrd_panels[1]

        # validate each rrd panel's title text
        system_rrd_panel_header = system_rrd_panel.find_element(*self.xpath_rrd_panel_header)
        self.assertTrue(system_rrd_panel_header.get_attribute('innerHTML').find('System') > -1)

        network_rrd_panel_header = network_rrd_panel.find_element(*self.xpath_rrd_panel_header)
        self.assertTrue(network_rrd_panel_header.get_attribute('innerHTML').find('Network') > -1)

        # get each panel's rrd images
        system_rrd_images = system_rrd_panel.find_elements(By.XPATH, './/img')

        # system rrd should have 6 rrd images
        self.assertEqual(len(system_rrd_images), 6)

        network_rrd_images = network_rrd_panel.find_elements(By.XPATH, './/img')

        # and network rrd panel should have 2 rrd images
        self.assertEqual(len(network_rrd_images), 2)

        system_rrd_type_sequence = [
            'cpu', 'mem', 'loadavg',
            'wait', 'blkcount', 'blkbyte'
        ]

        network_rrd_type_sequence = [
            'net', 'tcp'
        ]

        # for each rrd images, check sequence of rrd sources
        for rrd_element, rrd_type in zip(system_rrd_images, system_rrd_type_sequence):
            self.assertTrue(rrd_element.get_attribute('src').find(rrd_type) > -1)

        for rrd_element, rrd_type in zip(network_rrd_images, network_rrd_type_sequence):
            self.assertTrue(rrd_element.get_attribute('src').find(rrd_type) > -1)

    def test_rrd_panel_should_be_changed_when_time_range_btn_clicked(self):

        rrd_panels = self.driver.find_elements(By.XPATH, '//div[@class="panel panel-default ic-monitoring-rrd-panel"]')
        self.assertEqual(len(rrd_panels), 2)

        system_rrd_panel = rrd_panels[0]
        network_rrd_panel = rrd_panels[1]

        system_rrd_images = system_rrd_panel.find_elements(By.XPATH, './/img')
        self.assertEqual(len(system_rrd_images), 6)

        network_rrd_images = network_rrd_panel.find_elements(By.XPATH, './/img')
        self.assertEqual(len(network_rrd_images), 2)

        default_rrd_timerange = 'day'

        # each rrd image's default type is 'day'
        for rrd_element in system_rrd_images + network_rrd_images:
            self.assertTrue(rrd_element.get_attribute('src').find(default_rrd_timerange) > -1)

        # find timerange buttons
        timerange_buttons = self.driver.find_elements(*self.xpath_rrd_timerange_button)
        self.assertEqual(len(timerange_buttons), 4)

        # check first button element is activated.
        self.assertTrue(timerange_buttons[0].get_attribute('class').find('active') > -1)

        # find week button, and click to change rrd images
        self.assertEqual(timerange_buttons[1].text, 'Week')
        timerange_buttons[1].click()

        # validate timerange button works normally.
        # another inactive button is clicked, then activated button should be inactive status.
        # and clicked button should be activated.
        timerange_buttons = self.driver.find_elements(*self.xpath_rrd_timerange_button)
        self.assertTrue(timerange_buttons[0].get_attribute('class').find('active') == -1)
        self.assertTrue(timerange_buttons[1].get_attribute('class').find('active') > -1)

        system_rrd_images = system_rrd_panel.find_elements(By.XPATH, './/img')
        self.assertEqual(len(system_rrd_images), 6)

        network_rrd_images = network_rrd_panel.find_elements(By.XPATH, './/img')
        self.assertEqual(len(network_rrd_images), 2)

        # check rrd images timerange
        for rrd_element in system_rrd_images + network_rrd_images:
            self.assertTrue(rrd_element.get_attribute('src').find('week') > -1)
