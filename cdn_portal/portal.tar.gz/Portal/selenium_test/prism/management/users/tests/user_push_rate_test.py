import unittest

from selenium_test.config_constants import PRISM_FE_URL
from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

class PrismUserPushRateTest(unittest.TestCase):
    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()

    @catch_exception(author='injune.hwang')
    def test_is_prism_user_push_rate(self):
        driver = self.driver
        driver.get("%s/config/shared_components/userpushratethreshold/2/" % (PRISM_FE_URL))

        el1 = driver.find_element(By.ID, "id_description")
        el1.clear()
        el1.send_keys("user description test by script")
        driver.find_element(By.XPATH, ".//input[@value='Save and continue editing']").click()
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, '//div/ul/li'))
        )
        import re
        src = driver.page_source
        text_found = re.search(r'was changed successfully', src)
        self.assertNotEqual(text_found, None)

if __name__ == '__main__':
    unittest.main()
