import unittest

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_constants import PRISM_FE_URL
from selenium_test.config_user_constants import PRISM_INTERNAL_USER

from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


PAGE_ACCESS_TIMEOUT = 15


class RMSDashboardPageAccessTest(unittest.TestCase):

    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()
        self.driver.quit()

    @catch_exception(author='juwon.lee')
    def test_header_menu(self):
        driver = self.driver
        prism_ui_header_menu_xpath = (By.XPATH, '//div[@id="header-menu"]')

        driver.get(PRISM_FE_URL)
        # find prism ui header menu ui
        header_menu = driver.find_element(*prism_ui_header_menu_xpath)

    @catch_exception(author='juwon.lee')
    def test_header_menu_map_view_link_href(self):
        driver = self.driver

        prism_ui_header_menu_rms_xpath =(By.XPATH, '//div[@id="header-menu"]/ul/li/a[contains(text(), "Monitoring")]')

        # move prism ui home
        driver.get(PRISM_FE_URL)

        # find mapview buttons in header menu
        map_view_link_btn = driver.find_elements(*prism_ui_header_menu_rms_xpath)

        # assert link url
        # header should have 1 link element
        self.assertEqual(len(map_view_link_btn), 1)
        self.assertEqual(
            map_view_link_btn[0].get_attribute('href'),
            '%s/rms/browser/' % PRISM_FE_URL)

    @catch_exception(author='juwon.lee')
    def test_left_nav_rms_map_view_link_href(self):
        driver = self.driver

        prism_ui_left_nav_monitoring_parent_xpath = (By.XPATH, '//div[@id="leftnav"]/ul/li/a[contains(text(), "Monitoring")]')
        prism_ui_left_nav_rms_mapview_xpath =(By.XPATH, '//div[@id="leftnav"]/ul/li/ul/li/a[contains(text(), "Map View")]')

        # using layout list
        # we use 3 almost same layout files... (need to cleanup..)
        # so fix 3 links, and check 3 links.. -_-
        # even these layout has some diferrent dom node.. -_-^^

        target_urls = [
            PRISM_FE_URL,
            '%s/config/domains/' % PRISM_FE_URL,
            '%s/sla/list/' % PRISM_FE_URL,
        ]

        for url in target_urls:
            driver.get(url)

            # expand monitoring parent menu
            monitoring_parent_btn = driver.find_element(*prism_ui_left_nav_monitoring_parent_xpath)
            monitoring_parent_btn.click()

            map_view_link_btn = driver.find_elements(*prism_ui_left_nav_rms_mapview_xpath)
            print map_view_link_btn

            self.assertEqual(len(map_view_link_btn), 1)
            self.assertEqual(
                map_view_link_btn[0].get_attribute('href'),
                '%s/rms/browser/' % PRISM_FE_URL)

    @catch_exception(author='juwon.lee')
    def test_left_nav_rms_datagrid_view_link_href(self):
        driver = self.driver

        prism_ui_left_nav_monitoring_parent_xpath = (By.XPATH, '//div[@id="leftnav"]/ul/li/a[contains(text(), "Monitoring")]')
        prism_ui_left_nav_rms_datagridview_xpath =(By.XPATH, '//div[@id="leftnav"]/ul/li/ul/li/a[contains(text(), "Data Grid View")]')

        # shit..
        target_urls = [
            PRISM_FE_URL,
            '%s/config/domains/' % PRISM_FE_URL,
            '%s/sla/list/' % PRISM_FE_URL,
        ]

        for url in target_urls:
            driver.get(url)

            # expand monitoring parent menu
            monitoring_parent_btn = driver.find_element(*prism_ui_left_nav_monitoring_parent_xpath)
            monitoring_parent_btn.click()

            datagrid_view_link_btn = driver.find_elements(*prism_ui_left_nav_rms_datagridview_xpath)

            self.assertEqual(len(datagrid_view_link_btn), 1)
            self.assertEqual(
                datagrid_view_link_btn[0].get_attribute('href'),
                '%s/rms/browser/#/popgrid' % PRISM_FE_URL)