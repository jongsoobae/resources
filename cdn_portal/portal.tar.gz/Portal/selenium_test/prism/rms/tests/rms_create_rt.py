# # [cjy_todo]
# # Because I can't confirm result of 'Create RT', The following test code is close.
# # The reason why I can't confirm result of 'Create RT' is that PRISM UI doesn't show result of 'Create RT'.
# # The above code should be modified. When this code is modified, The Following test code should be open!
#
# import unittest
#
# from selenium.webdriver.support.wait import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC
# from selenium.webdriver.common.by import By
# from selenium.webdriver.common.keys import Keys
#
# from selenium_test.config_user_constants import PRISM_INTERNAL_USER
# from selenium_test.shared_components.decorators import catch_exception
# from selenium_test.shared_components.login import PrismLogin
# from selenium_test.shared_components.utils import get_web_driver
#
# PAGE_ACCESS_TIMEOUT = 15
#
#
# class RMSCreateRT(unittest.TestCase):
#
#     def setUp(self):
#         self.driver = get_web_driver()
#         PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)
#
#         driver = self.driver
#
#         # Open the RMS Monitoring page.
#         driver.find_element(By.XPATH, "//a[contains(text(),'Monitoring')]").click()
#         WebDriverWait(driver, PAGE_ACCESS_TIMEOUT).until(
#             EC.presence_of_element_located((By.CSS_SELECTOR, ".rms-mapview-container"))
#         )
#
#     def tearDown(self):
#         self.driver.close()
#         self.driver.quit()
#
#     def test_create_rt(self):
#         driver = self.driver
#
#         # Click the SEA mark on the map.
#         point_sea = driver.find_element(By.CSS_SELECTOR, '#rms-iata-SEA')
#         point_sea.click()
#
#         # Wait for the pop list of SEA.
#         WebDriverWait(driver, PAGE_ACCESS_TIMEOUT).until(
#             EC.presence_of_element_located(
#                 (By.XPATH, '/html/body/div/div[4]/div/div/div/div[4]/div[2]/div/div/div/div[2]/div/div/a/strong'))
#         )
#
#         # Click the pop of p1-sea.
#         p1_sea = driver.find_element(By.XPATH,
#                            '/html/body/div/div[4]/div/div/div/div[4]/div[2]/div/div/div/div[2]/div/div/a/strong')
#
#         p1_sea.click()
#
#         # Wait for the detail view of p1-sea.
#         WebDriverWait(driver, PAGE_ACCESS_TIMEOUT).until(
#             EC.presence_of_element_located(
#                 (By.XPATH, '//div[2]/div/div[2]/div/div[2]'))
#         )
#
#         # Click the 'bgp_service' probe
#         chk_bgp_service_probe = driver.find_element(By.XPATH, '//div[2]/div[3]/h5/span')
#         chk_bgp_service_probe.click()
#
#         # Click the 'create RT' Button
#         btn_create_rt = driver.find_element(By.XPATH, '//div[2]/div/div[2]/div/div[2]')
#         btn_create_rt.click()
#
#         # Wati for the 'Create RT Ticket' modal dialog.
#         WebDriverWait(driver, PAGE_ACCESS_TIMEOUT).until(
#             EC.presence_of_element_located(
#                 (By.XPATH, "(//input[@type='text'])[4]"))
#         )
#
#         # Write a subject.
#         txt_subject = driver.find_element(By.XPATH, "(//input[@type='text'])[4]")
#         txt_subject.clear()
#         txt_subject.send_keys('test_create_rt_by_selenium')
#         txt_subject.send_keys(Keys.RETURN)
#
#         # Write a content.
#         txt_subject = driver.find_element(By.XPATH, "//textarea")
#         txt_subject.clear()
#         txt_subject.send_keys('test_create_rt_by_selenium')
#         txt_subject.send_keys(Keys.RETURN)
#
#         # Click the 'Create RT' button.
#         btn_create_rt = driver.find_element(By.CSS_SELECTOR, "div.modal-footer > button.btn.btn-info")
#         btn_create_rt.click()
#
#
# if __name__ == '__main__':
#     unittest.main()
