import unittest

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


PAGE_ACCESS_TIMEOUT = 15


class RMSDashboardPageAccessTest(unittest.TestCase):

    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()
        self.driver.quit()

    @catch_exception(author='juwon.lee')
    def test_access_to_rms_dashboard(self):
        driver = self.driver

        driver.find_element(By.XPATH, "//a[contains(text(),'Monitoring')]").click()
        WebDriverWait(driver, PAGE_ACCESS_TIMEOUT).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".rms-mapview-container"))
        )

    # @catch_exception(author='juwon.lee')
    # def test_access_to_rms_popgrid_page(self):
    #     self.test_access_to_rms_dashboard()
    #
    #     driver = self.driver
    #
    #     driver.find_element(By.LINK_TEXT, "Pop GridView").click()
    #     WebDriverWait(driver, PAGE_ACCESS_TIMEOUT).until(
    #         EC.presence_of_element_located((By.CSS_SELECTOR, ".rms-pop-grid-container"))
    #     )

    @catch_exception(author='juwon.lee')
    def test_access_to_settings_page(self):
        self.test_access_to_rms_dashboard()

        driver = self.driver

        driver.find_element(By.LINK_TEXT, "RMS Settings").click()
        WebDriverWait(driver, PAGE_ACCESS_TIMEOUT).until(
            EC.presence_of_element_located((By.XPATH, "//h1[contains(text(), 'RMS Settings and Alerts for Probes')]"))
        )

if __name__ == '__main__':
    unittest.main()
