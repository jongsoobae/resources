# [PRISMUI-2803]
import unittest

from selenium.common.exceptions import NoSuchElementException

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver

from selenium_test.config_constants import PRISM_FE_URL

import time

PAGE_ACCESS_TIMEOUT = 15


class RMSSettingsFilterTest(unittest.TestCase):

    @classmethod
    def setUpClass(self):
        print('setup class')
        self.filter_items = ['CDNW', 'CUSTOMER', 'RESELLER', 'UNKNOWN']

    @classmethod
    def tearDownClass(self):
        print('tear down class')

    def setUp(self):
        print('setUp')
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

        driver = self.driver

        # Go to the map view.
        driver.get('%s/%s' % (PRISM_FE_URL, 'rms/browser/#/mapview'))

    def tearDown(self):
        print('tearDown')
        self.driver.close()
        self.driver.quit()

    def test_failed_list(self):
        driver = self.driver
        filter_items = self.filter_items

        found_filter_item = None

        for filter_item in filter_items:
            try:
                driver.find_element(By.CSS_SELECTOR, ("span.label.%s" % filter_item))
                found_filter_item = filter_item
                break
            except NoSuchElementException:
                pass

        self.assertIsNotNone(found_filter_item)

        driver.find_element(By.CSS_SELECTOR, ("button.btn.btn-disabled.btn-filter.%s" % found_filter_item)).click()

        try:
            driver.find_element(By.CSS_SELECTOR, ("span.label.%s" % found_filter_item))
            self.assertTrue(False)
        except NoSuchElementException:
            self.assertTrue(True)

    def test_state_list(self):
        driver = self.driver
        filter_items = self.filter_items

        for filter_item in filter_items:
            driver.find_element(By.CSS_SELECTOR, ("button.btn.btn-disabled.btn-filter.%s" % filter_item)).click()

        total_pop_count = int(driver.find_element(By.CSS_SELECTOR, ("span.rms-top-summary > strong.ng-binding")).text)

        self.assertEqual(total_pop_count, 0)

        for filter_item in filter_items:
            btn_type_filter = driver.find_element(By.CSS_SELECTOR, ("button.btn.btn-disabled.btn-filter.%s" % filter_item))
            btn_type_filter.click()

            total_pop_count = int(driver.find_element(By.CSS_SELECTOR, ("span.rms-top-summary > strong.ng-binding")).text)

            type_filter_pop_count = int(btn_type_filter.find_element(By.CSS_SELECTOR, ("span.ng-binding > strong.ng-binding")).text)

            self.assertEqual(total_pop_count, type_filter_pop_count)

            state_pop_count_elements = driver.find_elements(By.CSS_SELECTOR, ("button.btn.btn-disabled.btn-sm.btn-filter > span.ng-binding > strong.ng-binding"))

            self.assertEqual(len(state_pop_count_elements), 6)

            state_pop_count = 0

            for state_pop_count_ele in state_pop_count_elements:
                state_pop_count += int(state_pop_count_ele.text)

            self.assertEqual(type_filter_pop_count, state_pop_count)

            btn_type_filter.click()



if __name__ == '__main__':
    unittest.main()
