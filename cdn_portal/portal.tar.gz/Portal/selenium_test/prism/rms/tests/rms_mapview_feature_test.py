import unittest

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


PAGE_ACCESS_TIMEOUT = 15


class RMSMapviewFeatureTest(unittest.TestCase):

    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()
        self.driver.quit()

    @catch_exception(author='juwon.lee')
    def mapview_fullscreen_test(self):
        driver = self.driver

        driver.find_element(By.XPATH, "//a[contains(text(),'Monitoring')]").click()
        WebDriverWait(driver, PAGE_ACCESS_TIMEOUT).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".rms-mapview-container"))
        )

        driver.find_element(By.XPATH, "//button[contains(@ng-model, 'expandView')]").click()
        WebDriverWait(driver, PAGE_ACCESS_TIMEOUT).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".rms-mapview-container.fullscreen"))
        )

    @catch_exception(author='juwon.lee')
    def mapview_normal_screen_test(self):
        self.mapview_fullscreen_test()

        driver = self.driver

        driver.find_element(By.XPATH, "//button[contains(@ng-model, 'expandView')]").click()
        WebDriverWait(driver, PAGE_ACCESS_TIMEOUT).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".rms-mapview-container"))
        )


if __name__ == '__main__':
    unittest.main()
