import unittest

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


PAGE_ACCESS_TIMEOUT = 15


class GoToRmsSettingsTest(unittest.TestCase):

    def setUp(self):
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

    def tearDown(self):
        self.driver.close()
        self.driver.quit()

    def test_go_to_rms_settings(self):
        driver = self.driver

        driver.find_element(By.XPATH, "//a[contains(text(),'Monitoring')]").click()
        WebDriverWait(driver, PAGE_ACCESS_TIMEOUT).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".rms-mapview-container"))
        )

        txt_find_probe = driver.find_element(By.ID, 'monitoring_find_probe_txt')
        txt_find_probe.send_keys('hyperion_health')
        txt_find_probe.click()

        ele_find_probe_dropdown_item = driver.find_element(By.ID, 'monitoring_find_probe_dropdown')
        ele_find_probe_dropdown_item.click()

        WebDriverWait(driver, PAGE_ACCESS_TIMEOUT).until(
            EC.presence_of_element_located((By.ID, 'monitoring_probe_info_go_to_settings'))
        )

        txt_visual_name_in_monitoring = driver.find_element(By.ID, "monitoring_probe_info_visual_name")
        visual_name_in_monitoring = txt_visual_name_in_monitoring.text

        ele_go_to_settings = driver.find_element(By.ID, 'monitoring_probe_info_go_to_settings')
        ele_go_to_settings.click()

        WebDriverWait(driver, PAGE_ACCESS_TIMEOUT).until(
            EC.presence_of_element_located((By.XPATH,  '//*[@id="content-right"]/fieldset/legend'))
        )

        txt_visual_name = driver.find_element(By.ID, 'id_visual_name')
        visual_name_in_rms_setting = txt_visual_name.get_attribute('value')

        self.assertEqual(visual_name_in_monitoring, visual_name_in_rms_setting)


if __name__ == '__main__':
    unittest.main()
