import unittest

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

from selenium_test.config_user_constants import PRISM_INTERNAL_USER
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver

import time


PAGE_ACCESS_TIMEOUT = 15


class RMSSettingsTest(unittest.TestCase):

    @classmethod
    def setUpClass(self):
        print('setup class')

    @classmethod
    def tearDownClass(self):
        print('tear down class')

    def setUp(self):
        print('setUp')
        self.driver = get_web_driver()
        PrismLogin(self.driver).login_with(PRISM_INTERNAL_USER)

        driver = self.driver

        # Click the 'Settings' menu on the left side of main view.
        driver.find_element(By.XPATH, '//*[@id="leftnav"]/ul[2]/li/a').click()
        WebDriverWait(driver, PAGE_ACCESS_TIMEOUT).until(
            EC.presence_of_element_located((By.XPATH, '//*[@id="leftnav"]/ul[2]/li/ul/li[3]/a'))
        )

        # Click the 'RMS Settings & Alerts' menu on the left side of main view.
        driver.find_element(By.XPATH, '//*[@id="leftnav"]/ul[2]/li/ul/li[3]/a').click()
        WebDriverWait(driver, PAGE_ACCESS_TIMEOUT).until(
            EC.presence_of_element_located((By.XPATH, '//*[@id="rms_selection"]'))
        )

    def tearDown(self):
        print('tearDown')
        self.driver.close()
        self.driver.quit()

    def test_crud_wiki_url(self):
        params = [
            { 'url':'http://www.naver.com', 'valid': True },
            { 'url':'', 'valid': True },
            { 'url': 'adfadf', 'valid': False },
            { 'url': 'test/test', 'valid': False }
        ]

        for param in params:
            url = param['url']
            valid = param['valid']

            # Select the 'BGP_GSLB' option in ListBox.
            self.driver.find_element(By.XPATH, '//*[@id="rms_selection"]/option[2]').click()

            # Remove text of Wiki Url and write wiki url for 'BGP_GSLB' probe alert.
            txtbox_rms_wiki_url = self.driver.find_element(By.XPATH, '//*[@id="id_rms_wiki_url"]')
            txtbox_rms_wiki_url.clear()
            txtbox_rms_wiki_url.send_keys(url)
            txtbox_rms_wiki_url.send_keys(Keys.RETURN)

            # Click 'Add' button
            self.driver.find_element(By.XPATH, '//*[@id="btn_submit_rms"]').click()

            time.sleep(1)

            if valid:
                # Check inputed value of wiki url.
                txtbox_rms_wiki_url = self.driver.find_element(By.XPATH, '//*[@id="id_rms_wiki_url"]')
                value = txtbox_rms_wiki_url.get_attribute('value')

                self.assertEqual(value, url)
            else:
                # Check error message.
                label_error_message = self.driver.find_element(By.XPATH, '//*[@id="container_rms_settings_form"]/ul/li')
                value = label_error_message.text

                self.assertEqual(value, ("Please check url. '%s' is not valid." % url))

    # [PRISMUI-2802]
    def test_max_range_of_position(self):
        position_txtbox = self.driver.find_element(By.ID, 'id_position')
        self.assertEqual(position_txtbox.get_attribute('max'), '120')

    # [PRISMUI-2802]
    def test_warning_msg_of_position(self):

        alert_options = self.driver.find_elements(By.XPATH, '//*[@id="rms_selection"]/option')

        # Select the 'BGP_GSLB' option in ListBox.
        self.driver.find_element(By.XPATH, '//*[@id="rms_selection"]/option[2]').click()

        txt_position = self.driver.find_element(By.ID, 'id_position')
        txt_position.clear()
        txt_position.send_keys('1')
        txt_position.send_keys(Keys.RETURN)

        # Click 'Add' button
        self.driver.find_element(By.XPATH, '//*[@id="btn_submit_rms"]').click()

        time.sleep(1)

        # Check error message.
        label_error_message = self.driver.find_element(By.XPATH, '//*[@id="container_rms_settings_form"]/ul/li')
        positions = label_error_message.text

        positions = positions[positions.index(':') + 2:-1]
        positions = positions.split(',')

        # Because alert_options contains(includes) a separator, I subtract 1 from alert_options at the following code.
        # Also because positions does not contain itself, I add 1 from positions at the following code.
        # These counts must be same.
        self.assertEqual(len(alert_options) - 1, len(positions) + 1)

if __name__ == '__main__':
    unittest.main()
