import requests
import json
from selenium_test.config_user_constants import PRISM_API_USER
from selenium_test.shared_components.conf import settings


class PrismAPIManager(object):
    def __init__(self):
        self.base_url = settings.PRISM_API_URL
        self.credential = "user=%s&pass=%s" % (PRISM_API_USER.get('username'), PRISM_API_USER.get('password'))
        self.auth_info = None
        self.request_headers = {}
        self.timeout = 60

    def request(self,request_uri, method=None, post_data=None, content_type=None, url_parameter=None, output=True):
        method = method.lower().strip() if method else 'get'
        request_uri = request_uri.format(**url_parameter) if url_parameter else request_uri
        full_url = "%s/%s?%s" % (self.base_url, request_uri, self.credential)
        print url_parameter
        response = self._remote_request(full_url, method=method, post_data=post_data)
        print response._content
        return response

    def _remote_request(self, full_url, method=None, post_data=None, content_type=None):
        if method != 'get' and self.request_headers['Content-Type'] == 'application/json':
            post_data = json.dumps(post_data)

        print full_url, method,  post_data
        if method == 'get':
            response = self._get(full_url, post_data, method)
        elif method == 'post':
            if post_data is None:
                raise Exception(
                    "post data parameter input missing for request method %s. " % method)
            response = self._post(full_url, post_data, method)

        elif method == 'put':
            response = self._put(full_url, post_data, method)
        elif method == 'patch':
            response = self._patch(full_url, post_data, method)
        elif method == 'delete':
            response = self._delete(full_url, post_data, method)
        else:
            raise Exception("unsupported request method %s. " % method)

        #print response.status_code, response._content
        return response

    def _get(self, url, params_data, method):
        response = requests.get(url, auth=self.auth_info,
                                headers=self.request_headers,
                                params=params_data)

        return response

    def _post(self, url, post_data, method):
        if self.timeout:
            response = requests.post(url, data=post_data, auth=self.auth_info,
                                     headers=self.request_headers, timeout=self.timeout)
        else:
            response = requests.post(url, data=post_data, auth=self.auth_info,
                                     headers=self.request_headers)
        return response

    def _delete(self, url, post_data, method):
        response = requests.delete(url, data=post_data, auth=self.auth_info, headers=self.request_headers)

        return response

    def _put(self, url, post_data, method):
        if self.timeout:
            response = requests.put(url, data=post_data, auth=self.auth_info,
                                    headers=self.request_headers, timeout=self.timeout)
        else:
            response = requests.put(url, data=post_data, auth=self.auth_info,
                                    headers=self.request_headers)

        return response

    def _patch(self, url, post_data, method):
        if self.timeout:
            response = requests.patch(url, data=post_data, auth=self.auth_info,
                                      headers=self.request_headers, timeout=self.timeout)
        else:
            response = requests.patch(url, data=post_data, auth=self.auth_info,
                                      headers=self.request_headers)

        return response