import unittest
import requests
from selenium_test.config_user_constants import PRISM_API_USER
from selenium_test.shared_components.conf import settings
from selenium_test.shared_components.decorators import catch_exception


class TestConfig(unittest.TestCase):

    def setUp(self):
        self.url = settings.PRISM_API_URL
        self.credential = "user=%s&pass=%s" % (PRISM_API_USER.get('username'), PRISM_API_USER.get('password'))

    @catch_exception(author='injune.hwang')
    def test_get_config_list(self):
        uri = "config/list"
        self.url = "%s/%s?%s" % (self.url, uri, self.credential)
        parameters = {}
        response = requests.get(self.url, params=parameters)
        assert 'OK' in response._content

    @catch_exception(author='injune.hwang')
    def test_get_config_status(self):
        uri = "config/status"
        self.url = "%s/%s?%s" % (self.url, uri, self.credential)
        parameters = {'config_group':'BASE','config_type':'CFG'}
        response = requests.get(self.url, params=parameters)
        assert 'ok' in response._content

    @catch_exception(author='injune.hwang')
    def test_get_config_push(self):
        uri = "config/push"
        self.url = "%s/%s?%s" % (self.url, uri, self.credential)
        parameters = {'config_group':'BASE','config_type':'CFG'}
        response = requests.get(self.url, params=parameters)
        assert 'OK' in response._content

    #@catch_exception(author='injune.hwang')
    #def test_get_svn_diff(self):
    #    uri = "config/svndiff"
    #    self.url = "%s/%s?%s" % (self.url, uri, self.credential)
    #    parameters = {'config_group':'BASE','config_type':'CFG'}
    #    response = requests.get(self.url, params=parameters)
    #    assert 'ok' in response._content


if __name__ == "__main__":
    unittest.main()
