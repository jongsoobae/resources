import unittest
import requests
from selenium_test.config_user_constants import PRISM_API_USER
from selenium_test.shared_components.conf import settings
from selenium_test.shared_components.decorators import catch_exception


class TestContract(unittest.TestCase):

    def setUp(self):
        self.url = settings.PRISM_API_URL
        self.credential = "user=%s&pass=%s" % (PRISM_API_USER.get('username'), PRISM_API_USER.get('password'))

    @catch_exception(author='injune.hwang')
    def test_get_cs_contract(self):
        uri = "customer/contract/cs"
        self.url = "%s/%s?%s" % (self.url, uri, self.credential)
        parameters = {}
        response = requests.get(self.url, params=parameters)
        assert 'OK' in response._content

if __name__ == "__main__":
    unittest.main()
