# -*- coding: utf-8 -*-
import unittest
from selenium_test.prism_api import PrismAPIManager
from selenium_test.shared_components.decorators import catch_exception
import json
import encodings

class TestCustomerUserEdit(unittest.TestCase):

    def setUp(self):
        self.apimanager = PrismAPIManager()

    def get_user_info(self, email):
        uri = "customer/user/read"
        parameters = {'app_name':'aurora','email':email, 'userkey':''}
        response = self.apimanager.request(uri, post_data=parameters)
        data = json.loads(response._content).get('result')[0]
        return data

    @catch_exception(author='injune.hwang')
    def test_edit_customer_ad_user(self):
        email = 'ADM-GVN@square-enix.com'
        user_info = self.get_user_info(email)
        print user_info.get('last_name')
        print user_info.get('first_name')
        uri = 'customer/user/modify'
        parameters = {
            'app_name':'aurora',
            'scope': 'aurora',
            'user_key': user_info.get('user_key'),
            'email': user_info.get('email'),
            'user_name': user_info.get('full_user_name'),
            'first_name': user_info.get('first_name'),
            'last_name':  user_info.get('last_name'),
            #'first_name': 'ご担当者',
            #'last_name': 'アドミニストレーショングループ',
            'phone': user_info.get('phone'),
            'mobile': user_info.get('mobile'),
            'language_cd': user_info.get('language_cd'),
            'locale_cd': user_info.get('locale_cd'),
            'gmt_cd': user_info.get('gmt_cd'),
            'actor': 'injune.hwang'
        }
        #response = self.apimanager.request(uri, params=parameters)
        assert 'OKa' in user_info


if __name__ == "__main__":
    unittest.main()
