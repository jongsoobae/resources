import unittest
import requests
from selenium_test.config_user_constants import PRISM_API_USER
from selenium_test.shared_components.conf import settings
from selenium_test.shared_components.decorators import catch_exception


class TestCustomerUser(unittest.TestCase):

    def setUp(self):
        self.url = settings.PRISM_API_URL
        self.credential = "user=%s&pass=%s" % (PRISM_API_USER.get('username'), PRISM_API_USER.get('password'))

    @catch_exception(author='injune.hwang')
    def test_get_customer_ad_user(self):
        uri = "customer/user/read"
        self.url = "%s/%s?%s" % (self.url, uri, self.credential)
        parameters = {'app_name':'aurora','email':'injune.hwang@gmail.com', 'userkey':''}
        response = requests.get(self.url, params=parameters)
        assert 'OK' in response._content

    @catch_exception(author='injune.hwang')
    def test_search_user(self):
        uri = "customer/user/search"
        self.url = "%s/%s?%s" % (self.url, uri, self.credential)
        parameters = {'scope':'aurora','app_name':'aurora','email':'*naver.com', 'userkey':''}
        response = requests.get(self.url, params=parameters)
        assert 'OK' in response._content

    @catch_exception(author='injune.hwang')
    def test_get_sap_user(self):
        uri = "customer/contactuser/read_sap"
        self.url = "%s/%s?%s" % (self.url, uri, self.credential)
        parameters = {'kunnr':'20036','parnr':'46921'}
        response = requests.get(self.url, params=parameters, timeout=30)
        assert 'OK' in response._content


if __name__ == "__main__":
    unittest.main()
