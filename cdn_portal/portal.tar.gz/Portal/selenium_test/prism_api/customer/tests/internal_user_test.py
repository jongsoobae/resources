import unittest
import requests
import json
from selenium_test.config_user_constants import PRISM_API_USER
from selenium_test.config_constants import PRISM_API_URL

class TestInternalUser(unittest.TestCase):

    def setUp(self):
        self.url = PRISM_API_URL
        #self.credential = "user=%s&pass=%s" % (PRISM_API_USER.get('username'), PRISM_API_USER.get('password'))
        self.request_headers = {
            "Authorization": 'Basic a21zLWFkOmNkbmFkbWlu',
        }
        self.username = 'injune.hwang'


    def test_user_authenticate(self):
        uri = "rest/usermanagement/1/authentication?username=%s" % self.username
        self.url = "%s/%s" % (self.url, uri)
        params = {'value':'@$!@&@@add#'}

        response = requests.post(self.url, data=json.dumps(params), headers=self.request_headers)
        assert self.username in response._content



if __name__ == "__main__":
    unittest.main()