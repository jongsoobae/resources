import unittest
import requests
from selenium_test.config_user_constants import PRISM_API_USER
from selenium_test.shared_components.conf import settings
from selenium_test.shared_components.decorators import catch_exception


class TestDNSZone(unittest.TestCase):

    def setUp(self):
        self.url = settings.PRISM_API_URL
        self.credential = "user=%s&pass=%s" % (PRISM_API_USER.get('username'), PRISM_API_USER.get('password'))

    @catch_exception(author='injune.hwang')
    def test_search_zone(self):
        uri = "dns/zone/search"
        self.url = "%s/%s?%s" % (self.url, uri, self.credential)
        parameters = {'zone':'davidkimtest.com'}
        response = requests.get(self.url, params=parameters)
        assert 'OK' in response._content

if __name__ == "__main__":
    unittest.main()
