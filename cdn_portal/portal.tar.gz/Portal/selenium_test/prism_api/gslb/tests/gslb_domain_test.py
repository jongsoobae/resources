import unittest
from ...gslb import url_constants
from selenium_test import assert_result
from selenium_test.shared_components.decorators import catch_exception
from selenium_test.prism_api import PrismAPIManager

class TestGSLBDomain(unittest.TestCase):

    def setUp(self):
        self.prism_api = PrismAPIManager()

    @catch_exception(author='injune.hwang')
    def test_get_domain_list(self):
        for url,url_parameter, post_data,method,response_format in url_constants.gslb_domain_urls:
            if not url:
                continue

            response = self.prism_api.request(url, method=method, post_data=post_data, url_parameter=url_parameter)
            assert_result(response, response_format)

    #@catch_exception(author='injune.hwang')
    #def test_svn_export_domain_list(self):
    #    uri = "domain/export"
    #    self.url = "%s/%s?%s" % (self.url, uri, self.credential)
    #   parameters = {'config_group':'GSLB','config_type':'CFG', 'domain':'wsvc01.kr.cdnetworks.com'}
    #    response = requests.get(self.url, params=parameters)
    #    #mydata = json.loads(response._content)
    #    #mydata.get('data')[0].get('domain')
    #    assert 'OK' in response._content


if __name__ == "__main__":
    unittest.main()
