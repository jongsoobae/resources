import unittest
import requests
import json
from selenium_test.config_user_constants import PRISM_API_USER
from selenium_test.shared_components.conf import settings
from selenium_test.shared_components.decorators import catch_exception


class TestHost(unittest.TestCase):

    def setUp(self):
        self.url = settings.PRISM_API_URL
        self.credential = "user=%s&pass=%s" % (PRISM_API_USER.get('username'), PRISM_API_USER.get('password'))

    @catch_exception(author='injune.hwang')
    def test_host_list(self):
        uri = "host/list"
        self.url = "%s/%s?%s" % (self.url, uri, self.credential)
        parameters = {'pop':'p0-icn'}
        response = requests.get(self.url, params=parameters)
        assert 'ok' in response._content

    #@catch_exception(author='injune.hwang')
    #def test_host_disable(self):
    #    uri = "host/disable"
    #    self.url = "%s/%s?%s" % (self.url, uri, self.credential)
    #    parameters = {'host':'h0.s2.p0-icn'}
    #    response = requests.get(self.url, params=parameters)
    #    assert 'ok' in response._content

    #@catch_exception(author='injune.hwang')
    #def test_host_enable(self):
    #    uri = "host/enable"
    #    self.url = "%s/%s?%s" % (self.url, uri, self.credential)
    #    parameters = {'host':'h0.s2.p0-icn'}
    #    response = requests.get(self.url, params=parameters)
    #    assert 'ok' in response._content

if __name__ == "__main__":
    unittest.main()
