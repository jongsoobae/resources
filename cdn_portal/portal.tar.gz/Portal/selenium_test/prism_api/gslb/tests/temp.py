import os, sys
from selenium_test.shared_components.utils import read_file
#from selenium_test.prism_api.gslb.url_constants import get_json_schema
def main():
    json_path = os.path.dirname(os.getcwd())
    #file_path = path.abspath(path.join(path.dirname(config_constants.__file__), config_constants.CONFIG_FILE_PATH))
    filepath = os.path.join(json_path, "/json_schema/domain_detail_01.json").replace('\\', '/'),
    data = read_file(filepath)
    #file = get_json_schema("domain_detail_01.json")

if __name__ == '__main__':
    main()