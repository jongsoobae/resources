import os
import json
from selenium_test.prism_api.url_constants import *

def read_file(filename):
    f = open(filename, 'r')
    content = f.read()
    f.close()
    return content

def get_json_schema(schema_name):
    json_path = os.path.abspath(os.path.dirname(os.getcwd()))
    filepath = "%s%s" % (json_path, "/json_schema/%s" % schema_name)
    data = read_file(filepath)
    data = json.loads(data)
    return data

DOMAIN_LIST_01 = "domain_list_01.json"
DOMAIN_LIST_02_MONITORING = "domain_list_02.json"
DOMAIN_DETAIL_01 = "domain_detail_01.json"


#uri, url_parameter, params or post_data, method, response_format(response_code, json schema)
gslb_domain_urls = [
    ('domain/list',{},{},'GET',(200,get_json_schema(DOMAIN_LIST_01))),
    ('domain/list',{},{'mode':'monitoring'},'GET',(200,get_json_schema(DOMAIN_LIST_02_MONITORING))),
    ('domain/list',{},{'domain':'navalny.livejournal.com.cdngm.net'},'GET',(200,get_json_schema(DOMAIN_DETAIL_01))),
]



