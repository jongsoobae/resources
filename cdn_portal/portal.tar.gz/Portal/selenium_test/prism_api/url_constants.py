from selenium_test.url_constants import *

json_list_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "title": "default format",
    "description": "api default json schema",
    "type":'array'
}
json_400_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "title": "default format",
    "description": "api default json schema",
    "type":'object'
}

json_500_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "title": "default format",
    "description": "api default json schema",
    "type":'object',
    "properties":{
        'detail':{'type':'string'},
    }
}
