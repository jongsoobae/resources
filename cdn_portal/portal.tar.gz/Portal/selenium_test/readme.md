## **Documentations for development guide**

1. [Selenium with Python](http://selenium-python.readthedocs.org/)

## **Documentations for Selenium server installation**

1. [Selenium Server Quick Installation Guide](https://wiki.cdnetworks.com/confluence/display/~jaeik.lee/Selenium+Server+Quick+Installation+Guide)

## **Documentations for Selenium IDE tutorial**

1. [Selenium IDE for Python Users (Simple Tutorial)](https://wiki.cdnetworks.com/confluence/pages/viewpage.action?pageId=145033212)

## **Test Suite Naming Convention(class)**

Basically, **TestSuite** name must be **CamelCase**.
And, name format must be like this below.

> {**Action**}({**Page**}|{**Feature**})Test

**[Examples](#test-suite-naming-examples)**

## **Test Case Naming Convention(function)**

Basically, **TestCase** name must be **snake_case**.
And, name format must be like this below.

> test_given\_{**preconditions**}\_when\_{**state_under_test**}\_then\_{**expected_behavior**}

**[Examples](#test-case-naming-examples)**

#### **Test Suite Naming Examples**

> AddUserTest
>
> ViewCATrafficPageTest
> 
> DeleteCLBDomainTest
>
> ImportDNSZoneTest
>
> VerifyLDSInformationTest
>
> EditCustomizedControlGroupTest
>
> PushConfigurationTest


#### **Test Case Naming Examples**

> test_given_user_is_not_authenticated_when_view_index_page_then_url_will_redirect_to_login_url
