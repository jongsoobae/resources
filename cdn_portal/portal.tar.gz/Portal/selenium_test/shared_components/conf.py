from os import path
import imp
from selenium_test import config_constants


class Settings(object):
    pass

settings = Settings()


def get_config(settings):
    """
    Notes:
      Get config variables
    Args:
      file_path
    Returns:
      config dict
    """

    file_path = path.abspath(path.join(path.dirname(config_constants.__file__), config_constants.CONFIG_FILE_PATH))
    try:
        config_object = imp.load_source('*', file_path)
    except:
        config_object = Settings()
    finally:
        for key, value in config_constants.__dict__.iteritems():
            if key.startswith('__'):
                pass
            else:
                if hasattr(config_object, key):
                    setattr(settings, key, getattr(config_object, key))
                else:
                    setattr(settings, key, value)

get_config(settings)






