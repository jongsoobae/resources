from functools import wraps
from selenium_test.shared_components.conf import settings
from selenium_test.shared_components.utils import send_mail
import traceback


def catch_exception(author=None):
    """
    A decorator that catches any exceptions thrown by the decorated function and
    send an email to someone who wrote this decorated function.

    Notes:
      Caught exceptions are re-raised.
    Args:
      author (string):
    Returns:
      A decorator that catches exceptions thrown by decorated functions.
    Raises:
      Nothing. The decorator will re-raise any exception caught by the decorated
      function.
    """
    def test_fail_catch_decorator(func):
        @wraps(func)
        def test_fail_catch_wrapper(self, *args, **kwargs):
            if author is not None:
                receiver = author+'@cdnetworks.com'
            else:
                receiver = settings.PORTAL_TEAM_MAIL_ADDRESS

            try:
                return func(self, *args, **kwargs)
            except AssertionError as e:
                msg = 'Test Case: \'' + func.__name__ + '\' is failed.\n\n' + traceback.format_exc(e)
                send_mail(receiver=receiver,
                          cc=settings.PORTAL_TEAM_MAIL_ADDRESS,
                          title='[Portal Selenium Test] Error occurred while this test runs',
                          msg=msg)
                raise e  # Pass exception to nosetests exception handling module
            except Exception, e:
                msg = traceback.format_exc(e)
                send_mail(receiver=receiver,
                          cc=settings.PORTAL_TEAM_MAIL_ADDRESS,
                          title='[Portal Selenium Test]] Selenium test aborted due to an error',
                          msg=msg)
                raise e  # Pass exception to nosetests exception handling module
        return test_fail_catch_wrapper
    return test_fail_catch_decorator
