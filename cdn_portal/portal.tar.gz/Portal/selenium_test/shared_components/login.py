from selenium.webdriver.common.keys import Keys
from selenium_test.shared_components.conf import settings
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium_test.shared_components.utils import chk_javascript_error_occurred, close_driver


class AuroraLogin:
    def __init__(self, driver):
        """
        Notes:
          Load web driver to login
        Args:
          driver (WebDriver):
        Returns:
          Nothing.
        """
        self.driver = driver

    def login_with(self, user_info):
        """
        Notes:
          Login with username and password.
        Args:
          username (string):
          password (string):
        Returns:
          Nothing.
        """
        if settings.AURORA_FE_URL in settings.BLOCK_URL_LIST:
            close_driver(self.driver)
            raise ValueError('%s can\'t be used for AURORA_FE_URL' % settings.AURORA_FE_URL)

        self.driver.get(settings.AURORA_FE_URL + "/accounts/login/?next=/")
        self.driver.find_element(By.NAME, "username").send_keys(user_info.get('username'))
        self.driver.find_element(By.NAME, "password").send_keys(user_info.get('password'))
        self.driver.find_element(By.NAME, "password").send_keys(Keys.RETURN)
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//input[@value='Logout']"))
        )
        chk_javascript_error_occurred(self.driver)


class PrismLogin:
    def __init__(self, driver):
        """
        Notes:
          Load web driver to login
        Args:
          driver (WebDriver):
        Returns:
          Nothing.
        """
        self.driver = driver

    def login_with(self, user_info):
        """
        Notes:
          Login with username and password.
        Args:
          username (string):
          password (string):
        Returns:
          Nothing.
        """
        if settings.PRISM_FE_URL in settings.BLOCK_URL_LIST:
            close_driver(self.driver)
            raise ValueError('%s can\'t be used for PRISM_FE_URL' % settings.PRISM_FE_URL)

        self.driver.get(settings.PRISM_FE_URL + "/accounts/login/?next=/")
        self.driver.find_element(By.NAME, "username").send_keys(user_info.get('username'))
        self.driver.find_element(By.NAME, "password").send_keys(user_info.get('password'))
        self.driver.find_element(By.NAME, "password").send_keys(Keys.RETURN)
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//strong[contains(text(), 'MESSAGE BOARD FOR OPERATORS')]"))
        )
        chk_javascript_error_occurred(self.driver)
