import os
import time
from datetime import datetime
import requests
import json
from functools import wraps
from selenium_test.config_constants import DEBUG, API_LOCAL_MODE, PROJECT_NAME, SPECTRUMAPI_SERVER_URI, \
    AUTH_SPECTRUMAPI_APPLICATION_USER, AUTH_SPECTRUMAPI_APPLICATION_PASSWORD, AUTH_SPECTRUMAPI_TIMEOUT

log_exceptions = ['getApiKeyList']
def timed_function(fn):
    @wraps(fn)
    def measure_time(*args, **kwargs):
        t1 = time.time()
        result = fn(*args, **kwargs)
        t2 = time.time()
        if len(args) > 0:
            args_list = list(args)
            print ("@timed_fn:" + fn.func_name + " " +args_list[1] +" took " + str(t2 - t1) + " seconds")
        else:
            print ("@timed_fn:" + fn.func_name + " took " + str(t2 - t1) + " seconds")
        return result
    return measure_time
class SpectrumAPIManager(object):
    def __init__(self, base_url=None, request=None, app_name=None, lang=None, content_type=None, accept=None):
        self.init_event_messages = []
        self.init_event_messages.append("")
        self.init_event_messages.append("\r\n%s Spectrum API server request class instance initiated." % (str(datetime.utcnow())))
        self.api_url = base_url if base_url else SPECTRUMAPI_SERVER_URI
        self.app_username = AUTH_SPECTRUMAPI_APPLICATION_USER
        self.app_password = AUTH_SPECTRUMAPI_APPLICATION_PASSWORD
        self.api_auth_token = None
        self.rest_url = self.api_url.rstrip("/")
        self.timeout = AUTH_SPECTRUMAPI_TIMEOUT
        self.default_app_name = "shared_components"
        self.app_name = self.get_app_name(app_name=None)
        self.end_username = ''
        if self.app_name is None:
            self.app_name = self.default_app_name
        if lang is not None:
            self.language = lang
        else:
            self.language = 'en'
        if content_type is not None:
            self.content_type = content_type
        else:
            self.content_type = 'application/json'
        if accept is not None:
            self.accept = accept
        else:
            self.accept = '*/*'
        self.auth_info = requests.auth.HTTPBasicAuth(self.app_username, self.app_password)
        self.request_headers = {
            "Content-Type": self.content_type,
            "Accept": self.accept,
            "Accept-Language": self.language,
            "X-Project-Name": PROJECT_NAME,
            "x-App-Name": self.app_name,
        }
        if request is not None:
            # self.request = request
            self.end_username = request.user.username
            self.set_request_header(request)
        self.init_event_messages.append("%s [%s]: [%s] server request is ready." %
                                   (str(datetime.utcnow()), self.app_name, self.rest_url))
    def __str__(self):
        return "API Server at %s" % self.api_url
    def __repr__(self):
        return "<API server ('%s', '%s', %s')>" % (
            self.api_url, self.app_username, self.app_password)
    def is_authorized(self):
        if self.api_auth_token is not None:
            return True
        else:
            return False
    def force_authorize(self):
        tokens = self.get_spectrumapi_auth_token()
        if tokens is not None:
            try:
                self.api_auth_token = tokens["token"]
                return True
            except Exception as e:
                print e
                return False
        else:
            return False
    def get_app_name(self, app_name):
        if app_name is None:
            try:
                import inspect
                frame = inspect.currentframe()
                frame = frame.f_back.f_back
                code = frame.f_code
                caller_name = code.co_filename.lower()
                if os.name == 'nt':
                    callers = caller_name.split("\\")
                else:
                    callers = caller_name.split("/")
                app_name = callers[callers.index(PROJECT_NAME.lower()) + 1]
            except:
                app_name = None
        return app_name
    def is_local_mode(self):
        try:
            if DEBUG and API_LOCAL_MODE:
                return True
            else:
                return False
        except:
            return False
    def set_request_header(self, request):
        # self.request = request
        xforwarded_for = request.META.get('HTTP_X_FORWARDED_FOR', None)
        xforwarded_ip = request.META.get('HTTP_X_FORWARDED_IP', None)
        remote_ipaddr = request.META.get('REMOTE_ADDR', None)
        remote_addr = request.META.get('HTTP_X_FORWARDED_FOR',
                                       request.META.get('HTTP_X_FORWARDED_IP',
                                                        request.META.get('REMOTE_ADDR', None)))
        try:
            self.request_headers.update({'Accept-Language': request.user.userprofile.language_cd.strip()[0:2]})
        except:
            pass  # prism user does not have language_cd attribute in userprofile
        self.request_headers.update({'X-Enduser': request.user.username})
        self.request_headers.update({'X-Forwarded-For': xforwarded_for})
        self.request_headers.update({'X-Forwarded-IP': xforwarded_ip})
        self.request_headers.update({'X-Remote-IP': remote_ipaddr})
        self.request_headers.update({'X-Remote-Addr': remote_addr})
        context_name = "Request Context for UI server:"
        if context_name not in self.init_event_messages:
            self.init_event_messages.append(context_name)
            self.init_event_messages.append("Username: %s " % (request.user.username))
            self.init_event_messages.append("Client IP: %s " % (remote_addr))
            self.init_event_messages.append("UI server request path: %s" % (self.get_request_context_info(request)))
    def get_spectrumapi_auth_token(self, username=None, password=None):
        if username is None:
            username = self.app_username
        if password is None:
            password = self.app_password
        params = {
            "username": username,
            "password": password,
        }
        url = self.rest_url + "/token/"
        print url
        self.request_headers.update({"Content-Type": "application/json"})
        self.request_headers.update({"Accept": "*/*"})
        self.auth_info = requests.auth.HTTPBasicAuth(self.app_username, self.app_password)
        if self.timeout:
            response = requests.post(url, data=json.dumps(params), auth=self.auth_info,
                                     headers=self.request_headers, timeout=self.timeout)
        else:
            response = requests.post(url, data=json.dumps(params), auth=self.auth_info,
                                     headers=self.request_headers)
        self.request_headers.update({"Content-Type": self.content_type})
        self.request_headers.update({"Accept": self.accept})
        print response._content
        # If authentication failed for any reason return None
        if not response.ok:
            return None
        # Otherwise return the user object
        try:
            ob = json.loads(response.text)
            return ob
        except:
            return None
    def remote_request(self, request_uri, method=None, post_data=None, content_type=None):
        if request_uri.startswith("/"):
            url = self.rest_url + request_uri
        else:
            url = self.rest_url + "/" + request_uri
        if method != 'get' and self.request_headers['Content-Type'] == 'application/json':
            post_data = json.dumps(post_data)
        print url, method,  post_data
        if method == 'get':
            response = self._get(url, post_data, method)
        elif method == 'post':
            if post_data is None:
                raise Exception(
                    "post data parameter input missing for request method %s. " % method)
            response = self._post(url, post_data, method)
        elif method == 'put':
            response = self._put(url, post_data, method)
        elif method == 'patch':
            response = self._patch(url, post_data, method)
        elif method == 'delete':
            response = self._delete(url, post_data, method)
        else:
            raise Exception("unsupported request method %s. " % method)
        print response.status_code, response._content
        return response
    def request(self, request_uri, method=None, post_data=None, content_type=None, url_parameter=None):
        event_messages = []
        event_messages = self.init_event_messages + event_messages
        response = None
        if not method:
            method = 'get'
        else:
            method = method.lower().strip()
        if url_parameter:
            request_uri = request_uri.format(**url_parameter)
        try:
            if not self.is_authorized():
                authorize = self.force_authorize()
                if authorize == False:
                    raise Exception("unable to get auth token from spectrum api server %s." % self.api_url)
            self.auth_info = None  # invalidate basic auth info, use token auth instead.
            self.request_headers.update({'Authorization': 'Token ' + self.api_auth_token})
            if request_uri.startswith("/"):
                url = self.rest_url + request_uri
            else:
                url = self.rest_url + "/" + request_uri
            event_messages.append("%s Request to API server started." % (str(datetime.utcnow())))
            response = self.remote_request(request_uri, method=method,
                                            post_data=post_data,
                                            content_type=content_type)
        except Exception as e:
            print e
        return response
    def _get(self, url, params_data, method):
        response = requests.get(url, auth=self.auth_info,
                                headers=self.request_headers,
                                params=params_data)
        return response
    def _post(self, url, post_data, method):
        if self.timeout:
            response = requests.post(url, data=post_data, auth=self.auth_info,
                                     headers=self.request_headers, timeout=self.timeout)
        else:
            response = requests.post(url, data=post_data, auth=self.auth_info,
                                     headers=self.request_headers)
        return response
    def _delete(self, url, post_data, method):
        response = requests.delete(url, data=post_data, auth=self.auth_info, headers=self.request_headers)
        return response
    def _put(self, url, post_data, method):
        if self.timeout:
            response = requests.put(url, data=post_data, auth=self.auth_info,
                                    headers=self.request_headers, timeout=self.timeout)
        else:
            response = requests.put(url, data=post_data, auth=self.auth_info,
                                    headers=self.request_headers)
        return response
    def _patch(self, url, post_data, method):
        if self.timeout:
            response = requests.patch(url, data=post_data, auth=self.auth_info,
                                      headers=self.request_headers, timeout=self.timeout)
        else:
            response = requests.patch(url, data=post_data, auth=self.auth_info,
                                      headers=self.request_headers)
        return response
    def auth_ping(self):
        """Test that application can authenticate to API server.
        Attempts to authentication the application user against
        the API server. In order for user authentication to
        work, an application must be able to authenticate.
        Returns:
            bool:
                True if the application authentication succeeded.
        """
        url = self.rest_url + "/non-existent/location"
        response = self._get(url, None, None)
        if response.status_code == 401:
            # and response.text.startswith("Application failed to authenticate"):
            return False
        elif response.status_code == 404:
            return True
        else:
            # An error encountered - problem with the API server?
            return False
    def get_local_filename(self, request_uri, method):
        filepath = PROJECT_LOCATION + self.app_name
        if not os.path.isdir(filepath):
            filepath = PROJECT_LOCATION + self.default_app_name
        filepath = filepath + "/fixtures"
        if os.name == 'nt':
            filepath = filepath.replace('/', '\\')
        try:
            if not os.path.isdir(filepath):
                os.makedirs(filepath)
        except Exception as e:
            pass
        check_filename = request_uri.split("?")[0]
        filepath = filepath + "/"
        if os.name == 'nt':
            filepath = filepath.replace('/', '\\')
            filename = check_filename.replace('/', '_')
        else:
            filename = check_filename.replace('/', '_')
        if filename.endswith("_"):
            filename = filepath + filename + method + '.json'
        else:
            filename = filepath + filename + "_" + method + '.json'
        return filename
    def write_file(self, response, filename):
        try:
            if response.ok:
                f = open(filename, "w")
                f.write(response.text)
                f.close()
            else:
                pass
        except:
            pass
    def read_file(self, filename):
        try:
            f = open(filename, 'r')
            content = f.read()
            f.close()
            return content
        except:
            pass
    def get_request_context_info(self, request):
        try:
            result_list = []
            if request is not None:
                host = request.META['HTTP_HOST']
                path = request.META['PATH_INFO']
                result_list.append("URL: %s" % (host.strip() + path.strip()))
                # result_list.append("User: %s" % self.request.user.username)
            return "".join(result_list)
        except:
            return ""