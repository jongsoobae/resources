
import unittest

from selenium_test.config_constants import AURORA_FE_URL
from selenium_test.config_constants import PRISM_FE_URL
from selenium_test.config_constants import NO_SCREENSHOT
from selenium_test.config_user_constants import AURORA_INTERNAL_USER
from selenium_test.config_user_constants import PRISM_INTERNAL_USER

from selenium_test.shared_components.login import AuroraLogin
from selenium_test.shared_components.login import PrismLogin
from selenium_test.shared_components.utils import get_web_driver


class PortalSeleniumTestCase(unittest.TestCase):

    _no_screenshot = NO_SCREENSHOT
    _test_user = None
    _home_url = None
    _login_method = None

    @classmethod
    def setUpClass(cls):
        # when testcase class is created, then login to prism with given user.
        # set 'driver' member variable dynamically when class is instantiated.
        cls.driver = get_web_driver()
        cls._login_method(cls.driver).login_with(cls._test_user)

    @classmethod
    def tearDownClass(cls):
        # when all test is over, then quit selenium session.
        cls.driver.quit()

    def tearDown(self):

        # when each testcase function is ended, then take screenshot.
        if not self._no_screenshot:
            try:
                self.driver.save_screenshot(self.get_screenshot_filename())

            except Exception as _:
                # ignore exception
                pass

    def get_screenshot_filename(self):
        return '%s__%s.png' % (self.__class__.__name__, self._testMethodName)

    @classmethod
    def direct_to(cls, url):
        cls.driver.get(cls._home_url + url)


class PrismTestCase(PortalSeleniumTestCase):

    _test_user = PRISM_INTERNAL_USER
    _home_url = PRISM_FE_URL
    _login_method = PrismLogin


class AuroraTestCase(PortalSeleniumTestCase):

    _test_user = AURORA_INTERNAL_USER
    _home_url = AURORA_FE_URL
    _login_method = AuroraLogin

