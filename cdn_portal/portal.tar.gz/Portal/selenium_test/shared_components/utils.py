import smtplib
from email.mime.text import MIMEText
import os

from selenium import webdriver
from selenium.webdriver import DesiredCapabilities

from selenium_test.shared_components.conf import settings


def send_mail(sender=settings.ADMIN_MAIL_ADDRESS, receiver='', cc='', title='', msg=''):
    s = smtplib.SMTP(host=settings.EMAIL_HOST, port=settings.EMAIL_PORT)
    msg = MIMEText(msg)
    msg['From'] = sender
    msg['To'] = receiver
    msg['Subject'] = title
    msg['Cc'] = cc
    s.sendmail(sender, receiver, msg.as_string())


def get_web_driver(use_remote_selenium_server=None):
    if isinstance(use_remote_selenium_server, bool):
        use_remote_selenium_server = use_remote_selenium_server
    else:
        use_remote_selenium_server = settings.USE_REMOTE_SELENIUM_SERVER

    if os.environ.get('HOSTNAME') == settings.CI_SERVER_HOSTNAME or use_remote_selenium_server is True:
        driver = webdriver.Remote(
            command_executor="http://" + settings.SELENIUM_REMOTE_SERVER_IP + ":" + settings.SELENIUM_REMOTE_SERVER_PORT + "/wd/hub",
            desired_capabilities=DesiredCapabilities.FIREFOX
        )
        driver.implicitly_wait(settings.IMPLICITLY_WAIT)
    else:
        driver = webdriver.Firefox()
        driver.implicitly_wait(settings.IMPLICITLY_WAIT)

    return driver


def chk_javascript_error_occurred(driver):
    """
    Notes:
      Load web driver to login
    Args:
      driver (WebDriver):
    Returns:
      Nothing or raise Exception
    """
    js_error = driver.execute_script("return document.getElementsByTagName('body')[0].getAttribute('JSError');")
    if js_error is not None:
        close_driver(driver)
        raise Exception('JavaScript error occurred: "%s"' % str(js_error))


def close_driver(driver):
    """
    Notes:
      Close web driver
    Args:
      driver (WebDriver):
    Returns:
      Nothing
    """
    if driver.window_handles:
        driver.close()

def read_file(filename):
    f = open(filename, 'r')
    content = f.read()
    f.close()
    return content