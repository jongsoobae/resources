default_json_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "title": "default format",
    "description": "api default json schema",
    "type":'object'
}
