#!/bin/bash

vagrant box add ubutnu-12_04 http://goo.gl/8kWkm

