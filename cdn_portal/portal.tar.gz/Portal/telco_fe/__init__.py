#
# The version of Aurora FE.
#
# This is in the format of:
#
#   (Major, Minor, Patch)
#
# $Id$
#

#VERSION = (1, 2, 15)
import os
VERSION = (1, 2, 20)

def get_package_version():
    version = '%s.%s.%s' % (VERSION[0], VERSION[1], VERSION[2])
    return version

def get_release_version():
    '''
    return release version. this is auto increment number.
    this will replace 'svnversion -n' command within rpm.spec
    And number displayed at UI as fourth version number of package version is not incremented one.
    '''
    filename =  "%s/release_version.txt" % (os.path.abspath(os.path.dirname(__file__)))
    release_version = '0'
    try:
        release_version = read_file(filename)
        #not compatible with python 2.4
        #with open(filename, "r") as f:
        #    release_version = f.readline()
        release_version = release_version.strip()
    except:
        release_version = '0'

    return release_version

def read_file(filename):
    f = open(filename, 'r')
    content = f.read()
    f.close()
    return content

__version__ = get_package_version()
__release_version__ = get_release_version()