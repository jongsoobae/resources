from settings import * 


DEFAULT={
        'NAME':'aurora',
        'ENGINE':'mysql',
        'USER':'root',
        'PASSWORD':'cdnadmin',
        'HOST':'10.10.251.21',
        'PORT':'3306'
    }
STATS={
        'NAME':'stat',
        'ENGINE':'mysql',
        'USER':'root',
        'PASSWORD':'cdnadmin',
        'HOST':'10.10.251.21',
        'PORT':'3306'
    }
DATABASES = {
    'default': DEFAULT,
    'stats':STATS
}

WHITE_LABEL = 'cdnetworks_standalone'

STANDALONE_SITE = True
