# False: points to OCSP dev server /
# True : points to OCSP Production Server
DEBUG = False
OCSP_PROD_HANDLER = False

ADMINS = (
	('ENG-UI', 'eng-ui@cdnetworks.com'),
)
EMAIL_ALERTS = ['eng-ui@cdnetworks.com']

REPORT_MAIL_SENDER = 'Telco (Sender Only) <noreply@cdnetworks.com>'

IS_AD_BINDING = True
LDAP_TIMEOUT = 10

OCSPUS_USER_SYNCH_ENABLED = True  
OCSPKR_USER_SYNCH_ENABLED = True
OCSPJP_USER_SYNCH_ENABLED = True
OCSPCN_USER_SYNCH_ENABLED = True
SAP_USER_SYNCH_ENABLED = True # this is for aurora beta server not updating user info into SAP

if not OCSP_PROD_HANDLER:
	OUITELCO_HOST = 'https://pantherouitelco-dev.cdnetworks.com'
	RT_SERVER = 'http://rtlab.cdnetworks.net/REST/1.0/'
	RT_LOGIN_ID = 'young.park'
	RT_LOGIN_PWD = 'changeme'
	RT_QUEUE = 'US :: Incoming'
	RT_EMAIL = 'young.park@cdnetworks.com' # used for attaching files
else:
	OUITELCO_HOST = 'https://pantherouitelco.cdnetworks.com'
	RT_SERVER = 'https://support.cdnetworks.com/REST/1.0/'
	RT_LOGIN_ID = 'prismapi'
	RT_LOGIN_PWD = 'prismapi95134'
	RT_QUEUE = 'US :: Incoming'
	RT_EMAIL = 'support@cdnetworks.com' # used for attaching files

CACHE_BACKEND = "django.core.cache.backends.memcached.MemcachedCache"
CACHE_LOCATIONS = [
            '127.0.0.1:11211',
        ]
