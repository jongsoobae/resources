# Database settings configuration
import config_constants

if not config_constants.OCSP_PROD_HANDLER:
	DEFAULT={
			'NAME':'aurora',
			'ENGINE':'django.db.backends.mysql',
			'USER':'root',
			'PASSWORD':'cdnadmin',
			'HOST':'61.110.251.235',
			'PORT':'3306'
		}
else :
	DEFAULT={
			'NAME':'aurora',
			'ENGINE':'mysql',
			'USER':'telco_ui',
			'PASSWORD':'Nutr!l!t#TM',
			'HOST':'ngp-db.cdnetworks.net',
			'PORT':'3306'
	}
