# -*- coding: utf-8 -*-
"""
    Copyright (c) 2012 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        User Form 
"""
import re
from django import forms
from django.forms.widgets import CheckboxInput
from django.core.validators import RegexValidator,validate_email,EmailValidator
from django.utils.translation import ugettext_lazy as _
from spectrum_fe.shared_components.utils.regex import REGEX_MOBILE_NUMBER,\
    REGEX_PHONE_NUMBER

from telco_fe.shared_components.utils.common_code import get_common_code_list_light

regex_phone_number = re.compile(REGEX_PHONE_NUMBER)
regex_mobile_number = re.compile(REGEX_MOBILE_NUMBER)

USER_TYPE=(
        (1,_('Telco')),
        (2,_('Var')),
    )

class UserinfoForm(forms.Form):
    email = forms.EmailField(label=_('Email (Login ID)'),
                            required=True,
                            max_length=100,
                            widget=forms.TextInput(attrs={'class':'input-text','placeholder':_("user@email.com")}),
                            validators=[EmailValidator])
    first_name = forms.CharField(label=_('First Name'),
                                required=True,
                                max_length=30,
                                widget=forms.TextInput(attrs={'class':'input-text','placeholder':_("first name")}))
    last_name = forms.CharField(label=_('Last Name'),
                                required=True,
                                max_length=30,
                                widget=forms.TextInput(attrs={'class':'input-text','placeholder':_("Last name")}))
    phone = forms.CharField(label=_('Telephone'),
                                max_length=20,
                                min_length=7,
                                required=True,
                                widget=forms.TextInput(attrs={'class':'input-text','placeholder':_("Telephone")}),
                                help_text='Phone number can be used 7~20 long with numbers. #()-+characters',)
    mobile = forms.CharField(label=_('Mobile'),
                             max_length=20,
                             min_length=7,
                             required=True,
                             widget=forms.TextInput(attrs={'class':'input-text','placeholder':_("mobile")}),
                             help_text='Mobile phone number can be used 7~20 long with numbers. ()-characters',
                             validators=[RegexValidator(REGEX_MOBILE_NUMBER)],
                             error_messages={'invalid': _(u'Mobile phone number can be used 7~20 long with numbers. ()-characters')})
    is_active = forms.BooleanField(label=_('Account Activation'),
                                   initial=True,
                                   required=False,
                                   widget=CheckboxInput())
    is_admin = forms.BooleanField(label=_('Staff'),
                                   required=False,
                                   widget=CheckboxInput())
    
    def __init__(self, *args, **kwargs):
        super(UserinfoForm, self).__init__(*args, **kwargs)

    def clean_phone(self):
        super(UserinfoForm, self).clean()
        phone = self.cleaned_data.get('phone').strip()
        if not regex_phone_number.match(phone):
            raise forms.ValidationError(_(u'Phone number can be used 7~20 long with numbers. #()-+characters.'))
        return phone
   
    def clean_mobile(self):
        super(UserinfoForm, self).clean()
        mobile = self.cleaned_data.get('mobile').strip()
        if not regex_mobile_number.match(mobile):
            raise forms.ValidationError(_(u'Mobile phone number can be used 7~20 long with numbers. ()-characters.'))
        return mobile

class UserinfoEditForm(UserinfoForm):
    p_pw = forms.CharField(label=_('Current Password'),
                            max_length=30,
                            required=False,
                            widget=forms.PasswordInput(attrs={'class':'input-text',"autocomplete":"off",'placeholder':_("Current password")}),
                            help_text='If you want to change password, insert current password.')
    n_pw = forms.CharField(label=_('New Password'),
                            max_length=30,
                            required=False,
                            widget=forms.PasswordInput(attrs={'class':'input-text',"autocomplete":"off",'placeholder':_("New password")}),
                            help_text='Please insert new password')
    c_pw = forms.CharField(label=_('(Confirm) Password'),
                            max_length=30,
                            required=False,
                            widget=forms.PasswordInput(attrs={'class':'input-text',"autocomplete":"off",'placeholder':_("Confirm password")}),
                            help_text='Please re-insert new password')

    def __init__(self, *args, **kwargs):
        super(UserinfoForm, self).__init__(*args, **kwargs)

class UserinfoExtraForm(forms.Form):
    user_time = forms.ChoiceField(label=_('Time Zone'),
                                  widget=forms.Select())
    def __init__(self, *args, **kwargs):
        request = kwargs.pop('request')
        super(UserinfoExtraForm, self).__init__(*args, **kwargs)
        common_code = get_common_code_list_light(request)
        self.fields['user_time'].choices = common_code.get('gmt_list')