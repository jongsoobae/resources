from django.db import models
from django.contrib.auth.models import User

class OcspMappingAuroraUser(models.Model):
    key_id = models.PositiveIntegerField(primary_key=True, db_column='id')
    aurora_user = models.ForeignKey(User, db_column='auth_user_id')
    is_active = models.PositiveSmallIntegerField(default=1, db_column='is_active')
    ocsp_user_id = models.IntegerField(db_column='ocsp_user_id')
    
    class Meta:
        db_table = 'ocsp_us_user'
