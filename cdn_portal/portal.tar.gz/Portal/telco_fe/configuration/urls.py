from django.conf.urls.defaults import *

# Configuration
   
urlpatterns = patterns('telco_fe.configuration.views',
    url(r'^users/$', 'users.main_view', name='member_list'),
    url(r'^users/add/$', 'users.add_view', name='member_add'),
    url(r'^users/update/(?P<telco_user_id>\d+)$', 'users.edit_view', name='member_edit'),
    url(r'^users/active/$', 'users.set_user_active', name='member_set_active'),
    url(r'^users/inactive/$', 'users.set_user_inactive', name='member_set_inactive'),
    url(r'^users/myinfo/$', 'users.redirect_myinfo', name='myinfo'),
    url(r'^users/reset_user_password/$', 'users.ajax_reset_user_password', name='reset_user_password'),

    url(r'^users/accounts/$', 'users.load_customer_accounts', name='get_accounts'),
    url(r'^users/exists/$', 'users.is_exists_email', name='user_exists_check'),
    url(r'^users/save/$', 'users.edit_view', name='member_save'),
    url(r'^users/admin/$', 'users.admin_save', name='admin_save'),
)