from telco_fe import settings   

def get_email_change_token(userkey):
    from spectrum_fe.shared_components.utils.aquacrypto import encrypt
    from django.contrib.auth.models import User
    try:
        user = User.objects.get(pk=userkey)
        token = "email=%s,appname=%s,userkey=%s,loginurl=%s" % (user.username,'aurora',str(userkey),settings.TELCO_URL)
        #import urllib
        #token = urllib.quote(token, safe='/')        
        token = encrypt(token)
    except Exception,e:
        token = ''
    return token