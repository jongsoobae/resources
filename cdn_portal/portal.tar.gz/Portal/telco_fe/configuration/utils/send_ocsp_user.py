import urllib
import urllib2
from django.core.exceptions import ObjectDoesNotExist
from spectrum_fe.shared_components.utils.common import log_error
from telco_fe import settings
from telco_fe.configuration.models.ocsp_mapping_user import OcspMappingAuroraUser

def send_ocsp(request,user):
    try:
        mapping = OcspMappingAuroraUser.objects.get(aurora_user=user)
        ocspkey = mapping.ocsp_user_id
        active = '0'
        url = settings.OCSP_API_URL + "/rest/aurora/user/update?"
        apiUser = settings.OCSP_API_USER
        apiPwd = settings.OCSP_API_PWD
        if user.is_active:
            active = '1'
        if user.get_profile().user_phone:
            phone = user.get_profile().user_phone
        if user.get_profile().user_mobile:
            mobile = user.get_profile().user_mobile
        values = {'user' : apiUser,
                  'pass' : apiPwd,
                  'ocspkey' : ocspkey,
                  'uactive' : active,
                  'uemail': user.username,
                  'upass' : user.password,
                  'fname' : urllib.quote(user.first_name.encode('utf8')),
                  'lname' : urllib.quote(user.last_name.encode('utf8')),
                  'uphone' : phone,
                  'umobile': mobile,
                  'output': 'json'
                  }
#        data = urllib.quote(values, safe='/')
        data = urllib.urlencode(values)
        res = urllib2.urlopen(url, data)
        message = res.read()
    except ObjectDoesNotExist:
        message = 'Only Telco User data'
    except Exception as e:
        log_error(request, "Error in OCSP USER API Send", e=e)
        message = 'error'
    return message