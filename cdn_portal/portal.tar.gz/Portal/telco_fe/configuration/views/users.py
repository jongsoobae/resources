# -*- coding: utf-8 -*-
"""
    Copyright (c) 2012 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Configuration > Telco Portal Users
"""

from datetime import datetime
import re
import traceback
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.core.exceptions import PermissionDenied, ValidationError, \
    ObjectDoesNotExist
from django.core.paginator import Paginator, EmptyPage, InvalidPage, \
    PageNotAnInteger
from django.core.urlresolvers import reverse,resolve
from django.core.validators import validate_email
from django.db.models import Q
from django import forms
from django.forms import ModelForm
from django.forms.formsets import formset_factory
from django.http import HttpResponseRedirect, Http404, HttpResponse
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.utils import simplejson
from django.utils.translation import ugettext as _
from django.views.generic.edit import CreateView
from django.core.mail import send_mail
from spectrum_fe.shared_components.decorators import ajax_login_required
from spectrum_fe.shared_components.models.customer import CustomerAccount
from spectrum_fe.shared_components.models.customer_ldap_user import CustomerLDAPUser
from spectrum_fe.ldap.open_ldap_mgmt import OpenLDAPManager
from spectrum_fe.shared_components.utils.regex import REGEX_MOBILE_NUMBER,\
    REGEX_PHONE_NUMBER

from telco_fe import settings
from telco_fe.shared_components.decorators import is_authorized
from telco_fe.shared_components.middleware.http import Http403
from telco_fe.shared_components.utils.acl_helper import getDefaultAccount
from telco_fe.shared_components.utils.telco_user_helper import *
from telco_fe.configuration.forms.user_form import UserinfoForm,UserinfoEditForm,\
                                            UserinfoExtraForm,USER_TYPE
from telco_fe.configuration.utils.send_ocsp_user import send_ocsp

CONST_LIST_SCALE = 25
CONST_PAGE_SCALE = 10
regex_phone_number = re.compile(REGEX_PHONE_NUMBER)
regex_mobile_number = re.compile(REGEX_MOBILE_NUMBER)

ACTIVE_STATUS=(
        (-1,_('all')),
        (1,_('Active')),
        (0,_('InActive')),
    )

@login_required
def redirect_myinfo(request):
    def_account = getDefaultAccount(request)
    try:
        user = getTelcoUser(request.user, def_account.account_no)
    except:
        if request.user.is_superuser:
            return HttpResponseRedirect(reverse('member_list'))
        else:
            raise Http404()
    return HttpResponseRedirect(reverse('member_edit',args=[user.telco_user]))

@login_required
def main_view(request):
    page = request.GET.get('p',None)
    filter_opts = {}
    is_admin = False

    try:
        page = int(page)
    except:
        page = 1

    if request.user.is_superuser == False:
        def_account = getDefaultAccount(request)
        is_admin = isTelcoAdmin(request.user,def_account.account_no)

    has_user_manage_permit = False

    if request.user.is_superuser:
        has_user_manage_permit = True
    else:
        if is_admin and check_accessable_menu(request) == True:
            has_user_manage_permit = True
        else:
            pass

    if page is None:
        page=1

    try:
        search_name = request.GET.get('search_name',None)
        search_mail = request.GET.get('search_email',None)
        search_status = request.GET.get('search_status',None)

        if search_name:
            filter_opts.update({'search_name':search_name})
        if search_mail:
            filter_opts.update({'search_mail':search_mail})
        if search_status:
            filter_opts.update({'search_status':int(search_status)})
    except:
        pass

    if request.user.is_superuser and not request.session.get('admin_aquired'):
        members = telcoAllMembers(filter_opts)
    else:
        if request.session.get('admin_aquired'):
            account = request.session.get('admin_aquired')
        else:
            account = checkAllowAccount(request.user)
        members = telcoMembers(account,filter_opts)
        if not is_admin and not request.user.is_superuser:
            members = members.filter(user = request.user)
    
    paginator = Paginator(members,CONST_LIST_SCALE)

    try:
        members_page = paginator.page(page)
    except PageNotAnInteger:
        members_page = paginator.page(1) 
    except EmptyPage:
        members_page = paginator.page(paginator.num_pages)

    start_idx = ((page-1)/CONST_PAGE_SCALE)*CONST_PAGE_SCALE
    page_range = members_page.paginator.page_range[start_idx:][:CONST_PAGE_SCALE]

    context = RequestContext(request,{'members':members_page.object_list,
                                    'page' : members_page,
                                    'is_telco_admin' : is_admin,
                                    'has_user_manage_permit' :  has_user_manage_permit,
                                    'page_range' : page_range,
                                    'user_status':ACTIVE_STATUS,
                                    'isSuperUser':request.user.is_superuser,
                                    'requestUser':request.user })
    return render_to_response('user_manage_list.html', context)


@ajax_login_required
def ajax_reset_user_password(request):
    from telco_fe.manage.models.user_info_reset_manager import UserinfoResetManager
    from telco_fe.shared_components.models.telco_user import TelcoUser
    try:
        errmsg = ''
        user_id = request.POST.get('user_id', None) 
        if user_id:
            #user = getUserByUserId(user_id, request.user.username)

            telco_user = TelcoUser.objects.get(user__email=user_id)
            user = telco_user.user
            tokenissued_time = datetime.utcnow()
            tokenvalid_duration = 180
                        
            userinfomanager = UserinfoResetManager()
            userinfomanager.notify_email = user.email
            userinfomanager.app_name = 'aurora'
            userinfomanager.login_url = "%s" % (settings.TELCO_URL)
    
            userinfomanager.user_ip = ''
            userinfomanager.token_valid_minute = tokenvalid_duration
            userinfomanager.time_token_issued = tokenissued_time
            userinfomanager.obj_state =1
            userinfomanager.save(overwrite_lock=True)  #insert # added as an work queue
            
            infomanager2 = UserinfoResetManager.all_objects.get(pk=userinfomanager.pk)
            #validate email by searching appname directory. check if exists
            errmsg = infomanager2.send_password_reset_email(request)
                    
            #password = GenPasswd(15)
            #user.password = password
            
            #if IS_TEST_USER_MAIL:
            #    recive_mail = TEST_MAIL_ACCOUNT
            #else :
            #    recive_mail = [user.username]
                
            #domain = settings.AURORA_URL
            #email_msg = render_to_string("email_template.html",{'title':'CustomerPortal notice to your password.',
            #                                                            'domain':domain,
            #                                                            'contents':'%s\'s password is %s'%(user.username, password)})
            #email = EmailMultiAlternatives(subject=_("Notice to your password"),
            #                                       body=email_msg,
            #                                       from_email=REPORT_MAIL_SENDER,
            #                                       to=recive_mail)
            #email.attach_alternative(email_msg, "text/html")
            #email.send()
            
            #user.save()
            if len(errmsg) ==0:
                json_return = simplejson.dumps({'factor':'success', 'user_email':user.email})
            else:
                json_return = simplejson.dumps({'factor':'failure', 'user_email':user.email})
        else:
            json_return = simplejson.dumps({'factor':'failure', 'user_email':''})
    except Exception as e:
        send_mail('['+settings.PROJECT_NAME+'] User Password reset failed',
                'HTTP HOST: {host}\nSERVER NAME: {server}\n\nUser Password reset failed\n\nStack Trace:\n{trace}'.format(host=request.get_host(),
                                                                                                                        server=request.META['SERVER_NAME'],
                                                                                                                        trace=traceback.format_exc(e)),
                settings.DEFAULT_FROM_EMAIL,
                settings.EMAIL_ALERTS,
                fail_silently=False)
        json_return = simplejson.dumps({'factor':'failure'})
    return HttpResponse(json_return, mimetype='json/application')

@login_required
@is_authorized
def add_view(request):
    is_admin = False # it means telco admin Y or N ( default is N ).
    if request.user.is_superuser:
        accounts = CustomerAccount.objects.filter(telco_type=USER_TYPE[0][0])
        is_admin = True
    else:
        accounts = []
        def_account = getDefaultAccount(request)
        is_admin = isTelcoAdmin(request.user,def_account.account_no)

    if request.user.is_superuser:
        menus = get_menu(request=request)
    else:
        menus = get_menu(request=request,filtered=True)

    has_user_manage_permit = False

    if request.user.is_superuser:
        has_user_manage_permit = True
    else:
        if is_admin and check_accessable_menu(request) == True:
            has_user_manage_permit = True
        else:
            raise Http404()

    user_fields = UserinfoForm()
    optional_fields = UserinfoExtraForm(request=request)
    if request.POST:
        try:

            user_fields = UserinfoForm(request.POST)
            optional_fields = UserinfoExtraForm(request=request,data=request.POST)
            if user_fields.is_valid():
                user_data = user_fields.cleaned_data

            if optional_fields.is_valid():
                user_tz = optional_fields.cleaned_data['user_time']
            else :
                raise ValidationError(_(u'Invalid TimeZone Configuration'))
            
            try:
                new_menus = request.POST.getlist('m[]')
            except:
                new_menus = []

            if request.user.is_superuser:
                try:
                    member_type = request.POST.get('user_type')
                except:
                    raise ValidationError(_('Invalid Partner Information'))

                try:
                    account = long(request.POST.get('customer_account',None))
                    if account is None:
                        raise ValidationError(_('Invalid Partner Information'))
                except:
                    raise ValidationError
            elif is_admin:
                master = isTelcoMember(request.user,def_account.account_no)
                member_type = master.type
                account = def_account.account_no # register's account no.
            else:
                cur = isTelcoMember(request.user,def_account.account_no)
                member_type = cur.type
                account = def_account.account_no

            data = {
                'account': account,
                'first_name': user_data['first_name'],
                'last_name': user_data['last_name'],
                'email': user_data['email'],
                'mobile': user_data['mobile'],
                'phone': user_data['phone'],
                'is_active': user_data['is_active'],
                'is_admin': user_data['is_admin'],
                'type': member_type,
                'tz': user_tz,
            }

            ld = OpenLDAPManager()
            userlist = ld.getUserlistFromldapbyMail('aurora', user_data['email'])
            ld.unbind()

            if len(userlist) > 0:
                customeruser = userlist[0]
                customeruser.insert_telco_user(request,data)
                
                save_user = update_member(data) 
                if is_exists_auth_user(user_data['email']):
                    new_member = mirgrate_member(data)
                else:
                    new_member = create_member(data)
            else:
                customeruser = CustomerLDAPUser()
                save_user = update_member(data) 
                if is_exists_auth_user(user_data['email']):
                    new_member = mirgrate_member(data)
                else:
                    new_member = create_member(data)
                customeruser.user_key = new_member.pk 
                customeruser.save()
                customeruser2 = CustomerLDAPUser.objects.get(pk=customeruser.pk)
                customeruser2.insert_telco_user(request,data)
                customeruser2.obj_state =3
                customeruser2.save()



            if user_data['is_admin']:
                if request.user.is_superuser:
                    proc_result = admin_menu_update(request,new_member, new_menus)
                else:
                    new_menus =[]
                    new_menus.extend(filter_menu_ids(request))
                    proc_result = admin_menu_update(request,new_member, new_menus)
            else :
                proc_result = user_menu_update(request,new_member, new_menus)

            if request.is_ajax():
                pass
            else:
                return HttpResponseRedirect(reverse('member_list'))
        except:
            pass

    isSelf = False

    context = RequestContext(request,{'user_type': USER_TYPE,
                                    'is_telco_admin':is_admin,
                                    'menus' : menus,
                                    'mobile_regexp' : REGEX_MOBILE_NUMBER,
                                    'phone_regexp' : REGEX_PHONE_NUMBER,
                                    'user_fields' : user_fields,
                                    'optional_fields' : optional_fields,
                                    'accounts': accounts,
                                    'isSelf':isSelf})
    return render_to_response('user_manage_edit.html', context)

@login_required
def edit_view(request,telco_user_id):
    def_account = getDefaultAccount(request)
    is_admin = isTelcoAdmin(request.user,def_account.account_no)

    errmsg = ''
    try:
        telco_rel = get_userinfo_by_telco_user_id(telco_user_id)
        member_info = telco_rel.user.get_profile()

        if request.user.is_superuser:
            menus = get_menu(request=request,user=telco_rel.user)
        else:
            menus = get_menu(request=request,user=telco_rel.user,filtered=True)
    except:
        raise Http404()

    if is_admin:
        if request.user.is_superuser:
            accounts = CustomerAccount.objects.filter(telco_type=telco_rel.type)
        else :
            accounts = []
    else:
        try:
            if telco_rel.user == request.user:
                accounts = []
            else:
                raise ObjectDoesNotExist
        except:
            raise Http404()

    user_fields = UserinfoEditForm(initial={'email':telco_rel.user,
                                            'first_name':telco_rel.user.first_name,
                                            'last_name':telco_rel.user.last_name,
                                            'phone': member_info.user_phone,
                                            'mobile': member_info.user_mobile,
                                            'is_active':telco_rel.is_active,
                                            'is_admin':telco_rel.admin_flag})
    if is_admin:
        pass
    else:
        user_fields.fields['is_active'].widget.attrs['disabled']="disabled"

    optional_fields = UserinfoExtraForm(request=telco_rel.user,initial={'user_time':member_info.gmt_cd})
    if request.POST:
        try:
            user_fields = UserinfoEditForm(request.POST)
            optional_fields = UserinfoExtraForm(request=telco_rel.user,data=request.POST)
            need_to_authenticate = False

            if user_fields.is_valid():
                user_data = user_fields.cleaned_data

            if optional_fields.is_valid():
                user_tz = optional_fields.cleaned_data['user_time']
            else :
                raise ValidationError(_(u'Invalid TimeZone Configuration'))

            try:
                if is_admin:
                    is_active = user_data['is_active']
                else:
                    # keep status.
                    is_active = telco_rel.is_active
            except :
                is_active = False

            try:
                is_admin_flag = user_data['is_admin']
            except:
                is_admin_flag = False

            try:
                new_menus = request.POST.getlist('m[]')
            except:
                new_menus = []

            try:
                # check password update.
                older_password = user_data['p_pw']
                newer_password = user_data['n_pw']
                confirm_password = user_data['c_pw']

                if len(older_password.strip()) == 0 and len(newer_password.strip()) == 0:
                    need_to_authenticate = True
                elif len(older_password.strip()) > 0: # and  != u'' and older_password != '':
                    #if telco_rel.user.password != older_password:
                    #    raise ValidationError(_('Password is not correct'))
                    #else:
                    if len(newer_password.strip()) == 0:
                        raise ValidationError(_('New password input missing'))
                    need_to_authenticate = True
                else:
                    raise ValidationError(_('Current password input missing'))
            except Exception,e:
                if hasattr(e, 'messages'):
                    errmsg = '; '.join(e.messages)
                else:
                    errmsg = str(e)
                user_fields.errors.n_pw = '%s' % (errmsg)
                raise e

            if request.user.is_superuser:
                try:
                    member_type = long(request.POST.get('user_type'))
                except:
                    raise ValidationError(_('Invalid Partner Information'))

                try:
                    account = long(request.POST.get('customer_account',None))
                    if account is None:
                        raise ValidationError(_('Invalid Partner Information'))
                except:
                    raise ValidationError()

            elif is_admin:
                master = isTelcoMember(request.user,def_account.account_no)
                member_type = master.type
                account = def_account.account_no
            else:
                cur = isTelcoMember(request.user,def_account.account_no)
                member_type = cur.type
                account = def_account.account_no

            data = {
                'account': account,
                'first_name': user_data['first_name'],
                'last_name': user_data['last_name'],
                'email': user_data['email'],
                'mobile': user_data['mobile'],
                'phone': user_data['phone'],
                'o_pw' : older_password,
                'n_pw' : newer_password,
                'c_pw' : confirm_password,
                'is_active': is_active,
                'is_admin': is_admin_flag,
                'type': member_type,
                'user':telco_rel.user_id,
                'tz': user_tz,
            }

            ld = OpenLDAPManager()
            customeruser = ld.getUserFromldapbyUserkey('aurora', str(telco_rel.user.pk)) 
            if customeruser:
                if need_to_authenticate:
                    if customeruser.is_authenticated_ldap_user(ld, older_password):
                        pass
                    else:
                        ld.unbind()
                        user_fields.errors.p_pw = 'user %s current password not correct' % (customeruser.email)
                        raise ValidationError('user %s current password not correct' % (customeruser.email))
                customeruser.update_telco_user(request,data)
                save_user = update_member(data)
            else:
                #this is hardly the case, ldap is not synched with local db.
                customeruser = CustomerLDAPUser()
                save_user = update_member(data)
                customeruser.user_key = str(telco_rel.user.pk) 
                customeruser.save()
                customeruser2 = CustomerLDAPUser.objects.get(pk=customeruser.pk)  # in order to send email to user as transaction manager, we need customerldapuser pk
                                
                customeruser2.insert_telco_user(request,data)
                customeruser2.obj_state =3
                customeruser2.save()
            ld.unbind()

            if is_admin:
                if is_admin_flag:
                    if request.user.is_superuser:
                        proc_result = admin_menu_update(request,save_user, new_menus)
                    else:
                        new_menus =[]
                        new_menus.extend(filter_menu_ids(request))
                        proc_result = admin_menu_update(request,save_user, new_menus)
                else:
                    proc_result = user_menu_update(request,save_user, new_menus)
            else:
                proc_result = None

            #message = send_ocsp(request,save_user)
            if request.is_ajax():
                pass
            else:
                return HttpResponseRedirect(reverse('member_list',kwargs={}))
        except Exception,e:
            if hasattr(e, 'messages'):
                errmsg = '; '.join(e.messages) 
            else:
                errmsg = str(e)
            

    else:
        pass
    
    isSelf = False
    if telco_rel.user == request.user: 
        isSelf = True
    
    privs = []

    from telco_fe.configuration.utils import get_email_change_token
    email_change_token = get_email_change_token(telco_rel.user.pk)

    context = RequestContext(request,{'user_type': USER_TYPE,
                                    'errmsg': errmsg,
                                    'is_telco_admin':is_admin,
                                    'accounts': accounts,
                                    'menus' : menus,
                                    'user_update_form' : True,
                                    'telco_rel' : telco_rel,
                                    'aurora_url': settings.AURORA_URL,
                                    'email_change_token':email_change_token,
                                    'mobile_regexp' : REGEX_MOBILE_NUMBER,
                                    'phone_regexp' : REGEX_PHONE_NUMBER,
                                    'user_fields' : user_fields,
                                    'optional_fields' : optional_fields,
                                    'member_info':member_info,
                                    'isSelf':isSelf})
    return render_to_response('user_manage_edit.html', context)

@login_required
def is_exists_email(request):
    email = request.POST.get('l',None)
    try:
        validate_email(email)
    except:
        result = {
            'result' : True,
            'message' : _('Invalid E-Mail address format')
        }
        return HttpResponse(simplejson.dumps(result),mimetype='json/application')

    if email:
        try:
            exists_user = User.objects.get(username=email)
            user_profile = exists_user.get_profile()
            
            try:
                member = TelcoUser.objects.get(user=exists_user,account=user_profile.customer.account)
                already_registered = True
            except ObjectDoesNotExist:
                already_registered = False

            if already_registered is False:
                if request.user.is_superuser or (user_profile.customer.account.account_no == request.user.get_profile().customer.account.account_no):
                    filter_type = [i[0] for i in USER_TYPE]
                    if user_profile.customer.account.telco_type in filter_type :
                        data = {
                            'email' : exists_user.username,
                            'first_name':exists_user.first_name,
                            'last_name':exists_user.last_name,
                            'p':user_profile.user_phone,
                            'm':user_profile.user_mobile,
                            'a':user_profile.customer.account.account_no,
                            't':user_profile.customer.account.telco_type,
                        }

                        result = {
                            'result' : False,
                            'message' : _('There is a registered account. continue to registration procedure'),
                            'is_allowed' : True,
                            'data' : data
                        }
                    else:
                        result = {
                            'result' : True,
                            'message' : _('This account is not allowed to register to Partner Portal.)'),
                            'is_allowed' : False
                        }
                else:
                    result = {
                        'result' : True,
                        'message' : _('User is not authorized to register the account to Partner Portal.'),
                        'is_allowed' : False
                    }
            else:
                result = {
                    'result' : True,
                    'message' : _('Already exists E-Mail Address'),
                    'is_allowed' : False
                }
        except ObjectDoesNotExist:
            result = {
                'result' : False,
                'message' : _('E-Mail Address is available'),
                'is_allowed' : False
            }
        except:
            result = {
                'result' : True,
                'message' : _('Unknown Errors'),
                'is_allowed' : False
            }
    else:
        result = {
            'result' : True,
            'message' : _('Please Input E-Mail Address'),
            'is_allowed' : False
        }
    return HttpResponse(simplejson.dumps(result),mimetype='json/application')

@login_required
def set_user_active(request):
    def_account = getDefaultAccount(request)
    is_admin = isTelcoAdmin(request.user,def_account.account_no)

    if is_admin:
        try:
            telco_user_ids = request.POST.getlist('u[]')

            if telco_user_ids.__len__() > 0:
                s = change_user_status(telco_user_ids,True)
                if s:
                    result = {
                        'result': s,
                        'message' : _('SUCCESS')
                    }
                else:
                    result = {
                        'result': s,
                        'message' : _('Failed to account activation')
                    }
            else:
                result = {
                    'result': False,
                    'message' : _('Empty POST data')
                }
        except:
            result = {
                'result': False,
                'message' : _('Invalid Input POST data')
            }
    else:
        result = {
            'result': False,
            'message' : _("Your account is not allowed this operation")
        }
    return HttpResponse(simplejson.dumps(result),mimetype='json/application')

@login_required
def set_user_inactive(request):
    def_account = getDefaultAccount(request)
    is_admin = isTelcoAdmin(request.user,def_account.account_no)

    if is_admin:
        try:
            telco_user_ids = request.POST.getlist('u[]')

            if telco_user_ids.__len__() > 0:
                s = change_user_status(telco_user_ids,False)
                if s:
                    result = {
                        'result': s,
                        'message' : _('SUCCESS')
                    }
                else:
                    result = {
                        'result': s,
                        'message' : _('Failed to account de-activation')
                    }
            else:
                result = {
                    'result': False,
                    'message' : _('Empty POST data')
                }
        except:
            result = {
                'result': False,
                'message' : _('Invalid Input POST data')
            }
    else:
        result = {
            'result': False,
            'message' : _("Your account is not allowed this operation")
        }
    return HttpResponse(simplejson.dumps(result),mimetype='json/application')

@login_required
def load_customer_accounts(request):
    customer_type = request.GET.get('n',None)
    filter_type = [ ct[0] for ct in USER_TYPE]

    try:
        customer_type = int(customer_type)
        if customer_type in filter_type:
            accounts = CustomerAccount.objects.filter(telco_type=customer_type)
            accounts_dict = [(ac.account_no , ac.account_name_local) for ac in accounts]

            result = {
                'result': True,
                'message' : _('SUCCESS'),
                'data' : accounts_dict
            }
        else:
            raise ValidationError
    except:
        result = {
            'result': False,
            'message' : _('Invalid Input Value'),
            'data' : accounts_dict
        }

    if request.is_ajax():
        return HttpResponse(simplejson.dumps(result),mimetype='json/application')
    else:
        return Http403()

@login_required    
def admin_save(request):
    aquire = request.GET.get('aquire','')
    try:
        account_no = int(aquire)            
        request.session['admin_aquired'] = CustomerAccount.objects.get(account_no=account_no)
    except:
        request.session['admin_aquired'] = ''    
    result = {
        'result': True,
        'message' : _('OK')
    }
    return HttpResponse(simplejson.dumps(result),mimetype='json/application')
    