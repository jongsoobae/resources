# coding: utf-8
#from suds import WebFault
#from suds.client import Client
from urllib2 import URLError
import logging
import traceback
import re
import urllib
#import suds.xsd.doctor as dr
import ldap
from django.contrib.auth.models import User, Group, get_hexdigest
from django.conf import settings
from django.utils.encoding import smart_str

from spectrum_fe.shared_components.utils.customer_utils import authenticate_aurora_user
from spectrum_fe.shared_components.utils.common import send_notice_email,send_error_email, \
    log_event,log_error,log_debug,log_critical
from spectrum_fe.shared_components.utils.hashers import check_password as check_sha2_password, \
    make_password as make_sha2_password
from telco_fe.config_constants import LDAP_TIMEOUT
from telco_fe.crowd.crowds import *
#from spectrum_fe.shared_components.requests import *

logger = logging.getLogger(__name__)

class CrowdBackend:
    "Atlassian Crowd Authentication Backend"
    crowdClient = None
    authenticationToken = None
    principalToken = None

    NAME = "NAME"
    RANDOM_NUMBER = "Random-Number"
    REMOTE_ADDRESS = "remote_address"
    REMOTE_HOST = "remote_host"
    USER_AGENT = "User-Agent"
    X_FORWARDED_FOR = "X-Forwarded-For"
    ENCRYPTION_TYPE = "sha1"
    ENCRYPTION_KEY = "cdnzzang"
    
    def __init__(self):    
        pass
    
    def check_usertype_and_return(self,username,password,auth_result):
        '''check where user is internal ad user or customer ad user by probing 'display-name' attribute
        '''
        #case 1:if user is internal ad user, display-name shows full user name
        #case 2:if user is customer ad user, dispaly-name shows [userkey]_[contactno]
        #case 3:if display-name field shows empty, this means customer ad user has not been validated of its email.
        # so in case 3, rdirect to forgot password reset url. And temporarily diable user
        #case 4:if disaply-name field shwos only userkey, then this user not integrated with contact info.
        #in case 4 where you should redirect user to user edit page. this event happens only one time after migration
        #in case 2 where display-name fiedl shows userkey_contactno (with delimeter '_), this user has been integrated with contact info. nothing to do.
        
        displayname = smart_str(auth_result['display-name'])
        is_internal_user = False
        is_validated_user = True
        is_integrated_contact_user = False
        contactno = ""
        if len(displayname.strip()) ==0:
            #case 3, customer ad user, redirect to validation request url
            #temporarily disable user until useremail is validated 
            is_validated_user = False
        else:
            userchecks =displayname.split("_")
            if len(userchecks) > 1:
                # this is case 2: customer ad user integrated. happy case
                try:
                    uid = int(userchecks[0]) # if customer ad user, should be integer
                    if uid == 0:
                        is_validated_user = False
                    is_integrated_contact_user = True
                    contactno = userchecks[1]
                except:
                    # not likely, but internl ad user has integer name
                    is_internal_user = True
                
            elif len(userchecks) == 1:
                # case 1 or 4
                try:
                    uid = int(userchecks[0]) # if customer ad user, should be integer
                    if uid == 0:
                        is_validated_user = False
                except:
                    # case 1 : internal ad user
                    is_internal_user = True   
                
        return self.create_or_update_user(username,password,auth_result,is_internal_user,is_validated_user,is_integrated_contact_user,contactno) 

    def create_or_update_user(self, user_name,password,auth_result, is_internal_user, is_validated_user,is_integrated_contact_user,contactno):
        '''create new or update password info if exists
        '''

        user, created = User.objects.get_or_create(username=user_name)
        if created:
            #user.set_unusable_password()
            if is_internal_user:
                user.is_superuser = True
                user_email = user_name + "@cdnetworks"
                try:
                    user = User.objects.get(username__contains=user_email, is_superuser=1)
                    user.username = user_name
                except:
                    pass
            else:
                user.is_superuser = False
            if is_validated_user:
                user.is_active = True
            else:
                user.is_active = False
            user.username = user_name
            #password override. user.set_password(password)
            #user.set_password(password)
            user.password = make_sha2_password(password) #
            user.email = auth_result['email']
            user.save()
            
            if is_internal_user:
                self.createDefaultSuperUserProfile(user, '00000000000')
        else:
            if is_internal_user:
                user.is_superuser = True
                try:
                    user_profile = user.get_profile()
                except:
                    user_profile = None
                    
                if not user_profile:
                    self.createDefaultSuperUserProfile(user, '00000000000')                
            #user password may have changed according to the internal AD's policy
            #user.set_password(password)
            user.password = make_sha2_password(password)
            user.email = auth_result['email']
            user.save()
            
        user.contactno = contactno
        user.is_integrated_contact_user = is_integrated_contact_user
        user.is_internal_user = is_internal_user
        user.is_validated_user = is_validated_user
        user.isCrowdUser = True
        return user
    
    def createDefaultSuperUserProfile(self,user, user_phone):
        try :
            from telco_fe.shared_components.models import UserProfile
            from spectrum_fe.shared_components.models.customer import CustomerDisplay
            user_profile = UserProfile(user=user)
            customer = CustomerDisplay.objects.get(customer_id=1)
            user_profile.customer = customer
            user_profile.user_phone = user_phone,
            user_profile.user_mobile = user_phone
            user_profile.save()
            return user_profile
        except Exception as e:
            return None
    
    def authenticate(self, username, password=None, authkey=None, sabun=None):
        return self.authenticate_crowdsso(username=username, password=password)

    def authenticate_crowdsso(self, username=None, password=None):
        try:
            # basic password check
            if password == None or password == '':
                return None

            #cs = CrowdServer()
            #success = cs.auth_user(username, password)
            success = authenticate_aurora_user(username,password)
            if success:
                return self.check_usertype_and_return(username,password,success)
            else:
                log_event(username,'failed to authenticate username:'+username,'telco',None)
                
        except URLError as e:
            title='[%s] %s' % (settings.PROJECT_NAME, "Failed to authenticate")
            message = "Could not communicate with Crowd server; Is AUTH_CROWD_SERVER_URI configured correctly?"
            if type(e.reason) is str:
                message += e.reason
            else:
                message += str(type(e.reason)) + ": " + str(e.reason)
            log_error(None,message,e,None,title)
            #try one more time for local cache authentication
            return self.authenticate_localdb(username,password)
        except Exception, e:
            title='[%s] %s' % (settings.PROJECT_NAME, "Failed to authenticate")
            message = "Received error from Crowd server for username '" + username + "'; " + str(e)
            log_error(None,message,e,None,title)
            #try one more time for local cache authentication
            return self.authenticate_localdb(username,password)
        return None
    
    def authenticate_localdb(self,username,password):
        try:
            user = User.objects.get(username=username,is_active=True)
        except User.DoesNotExist:
            title='[%s] %s' % (settings.PROJECT_NAME, "failed to to log in !")
            message='User: {username}\n does not exists at local cache db'.format(username=username)
            log_error(None,message,None,None,title)
            return None

        try:
            #if user and user.check_password(password):
            if user and check_sha2_password(password, user.password):
                #user.is_active = False
                #user.customer =self.get_customer()
                user.save()
                return user
        except Exception,e:
            title='[%s] %s' % (settings.PROJECT_NAME, "Failed to authenticate")
            message = "authentication failed from local db username '" + username + "'; " + str(e)
            log_error(None,message,e,None,title)
        return None

    def get_user(self, user_id):
        user = None
        try:
            user = User.objects.get(pk=user_id)
        except User.DoesNotExist:
            pass

        return user
    
    def get_customer(self):
        return 1    


    def populate_user(self,username,password):
        #self.check_client_and_app_authentication()
        #soap_principal = self.crowdClient.service.findPrincipalByName(self.authenticationToken, user.username)
        # Create a session. The important bit is the token.

                        
        #user.is_active = True
        #for soapAttribute in soap_principal.attributes[0]:
        #    if (soapAttribute.name == "mail"):
        #        user.email = soapAttribute.values[0][0]
        #    if(soapAttribute.name == "givenName"):
        #        user.first_name = soapAttribute.values[0][0]
        #    if(soapAttribute.name == "sn"):
        #        user.last_name = soapAttribute.values[0][0]
        pass

    def populate_groups(self, user):
        pass
        #self.check_client_and_app_authentication()
        #arrayOfGroups = self.crowdClient.service.findGroupMemberships(self.authenticationToken, user.username)
        #user.groups.clear()

        #try:
        #    groups = arrayOfGroups[0]
        #except:
        #    return

        #for crowdgroup in groups:
        #    group, created = Group.objects.get_or_create(name=crowdgroup)
        #    if created:
        #        group.save()

        #    user.groups.add(group)
        #    if (group.name == crowd_settings.AUTH_CROWD_SUPERUSER_GROUP):
        #        user.is_superuser = True
        #    if (group.name == crowd_settings.AUTH_CROWD_STAFF_GROUP):
        #        user.is_staff = True

    def generate_session(self,username,password):
        cs = CrowdServer()
        session = cs.get_session(username, password)
        if session:
            self.principalToken = session['token']
            print 'Created a session, token %s' % session['token']
        else:
            print 'Failed to authenticate.'                
            
    def findUserByToken(self, token):
        "returns the user if the principal token is valid"
        
        # Check that the token is valid (and of course it should be).
        cs = CrowdServer()
        success = cs.validate_session(token)
        if success:
            print 'Authenticated session token.'
        else:
            print 'Failed to authenticate token.'        
        #self.check_client_and_app_authentication()
        #if self.crowdClient.service.isValidPrincipalToken(self.authenticationToken, token, validationFactors):
        #    principal = self.crowdClient.service.findPrincipalByToken(
        #            self.authenticationToken,
        #            token)
        #    self.principalToken = token
        #    return self.create_or_update_user(principal.name)
        #else:
        #    return None


    def getCookieInfo(self):
        pass
        #self.check_client_and_app_authentication()
        #return self.crowdClient.service.getCookieInfo(self.authenticationToken)

class CrowdSettings(object):
    """
    This is a simple class to take the place of the global settings object. An
    instance will contain all of our settings as attributes, with default values
    if they are not specified by the configuration.
    """
    defaults = {
        'AUTH_CROWD_ALWAYS_UPDATE_USER': True,
        'AUTH_CROWD_MIRROR_GROUPS': True,
        'AUTH_CROWD_STAFF_GROUP': 'staff',
        'AUTH_CROWD_SUPERUSER_GROUP': 'superuser',
        'AUTH_CROWD_APPLICATION_USER': 'aurora-ad',
        'AUTH_CROWD_APPLICATION_PASSWORD': 'cdnadmin',
        'AUTH_CROWD_SERVER_URI': 'http://sso.cdnetworks.com:8095/crowd/'
    }

    def __init__(self):
        """
        Loads our settings from django.conf.settings, applying defaults for any
        that are omitted.
        """
        from django.conf import settings

        for name, default in self.defaults.iteritems():
            value = getattr(settings, name, default)
            setattr(self, name, value)


        # Our global settings object

crowd_settings = CrowdSettings()
