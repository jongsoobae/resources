'''
__author__ = 'sannies'


from suds.client import Client
from suds import WebFault
import suds.xsd.doctor as dr

wsdlurl = 'http://testjira.cdnetworks.com:8095/crowd/services/SecurityServer?wsdl'
# The following dictionary has the targetNamespace as the key and a list
# of namespaces that need to be imported as the value for that key
patches = { "urn:SecurityServer": ["http://authentication.integration.crowd.atlassian.com",
    "http://soap.integration.crowd.atlassian.com","http://exception.integration.crowd.atlassian.com",
    "http://rmi.java"] ,
    "http://soap.integration.crowd.atlassian.com": ["urn:SecurityServer"] }

# Create an ImportDoctor to use
doctor = dr.ImportDoctor()

# Patch all the imports into the proper targetNamespaces
for targetNamespace in patches:
    for ns_import in patches[targetNamespace]:
        imp = dr.Import(ns_import)
        imp.filter.add(targetNamespace)
        doctor.add(imp)

# Create the SOAP client, doctoring it to fix imports
client = Client(wsdlurl,doctor=doctor)
print(client)

auth_context = client.factory.create('ns1:ApplicationAuthenticationContext')

auth_context.name = "kms-ad"
auth_context.credential.credential = "cdnadmin"

try:
    token = client.service.authenticateApplication(auth_context)
except WebFault, e:
    print e

principalToken = client.service.authenticatePrincipalSimple(token, 'injune.hwang', 'nitz1234!')
print client.service.findGroupMemberships(token,'injune.hwang')
principal = client.service.findPrincipalByToken(token, principalToken )

a = client.service.getCookieInfo(token)
print client.service.isValidPrincipalToken(token, principalToken)

print a

#for soapAttribute in principal.attributes[0]:
#    print soapAttribute
#pass
'''

