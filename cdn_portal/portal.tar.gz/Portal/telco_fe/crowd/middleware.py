from telco_fe.crowd.backend import CrowdBackend, crowd_settings
from datetime import  datetime, timedelta
from django.contrib.auth import login as auth_login
from django.contrib.auth.models import AnonymousUser
#from suds import WebFault
from urllib2 import URLError
import logging

__author__ = 'sannies'

logger = logging.getLogger(__name__)

class CrowdSSOAuthenticationMiddleware(object):
    crowdBackend = CrowdBackend()
    crowdUserLoggedIn = False

    def process_request(self, request):
        try:
            crowd_token = request.COOKIES["crowd.token_key"]
        except KeyError:
            return None

        if request.user.is_anonymous():
            try:
                pass
                #validationFactors = self.crowdBackend.getValidationFactors(request)
                #crowdUser = self.crowdBackend.findUserByToken(crowd_token, validationFactors)
                #if crowdUser is not None:
                #    crowdUser.backend = "%s.%s" % (self.crowdBackend.__module__, self.crowdBackend.__class__.__name__)
                #    auth_login(request, crowdUser)
                #    self.crowdUserLoggedIn = True
            #except WebFault as e:
            #    if hasattr(e.fault, 'faultstring') and username == e.fault.faultstring:
            #        message = "Likely not a valid user"
            #    else:
            #        message = e.message
            #    logger.error("Received error from Crowd server for username '" + username + "'; " + message)
            #    return None
            except URLError as e:
                #logger.error("Could not communicate with Crowd server; Is AUTH_CROWD_SERVER_URI configured correctly? ('" + crowd_settings.AUTH_CROWD_SERVER_URI + "')")
                if type(e.reason) is str:
                    logger.error(e.reason)
                else:
                    logger.error(str(type(e.reason)) + ": " + str(e.reason))
                return None

            return None
        else:
            if hasattr(request.user, 'isCrowdUser') and request.user.isCrowdUser:
                self.crowdUserLoggedIn = True
            return None


    def process_response(self, request, response):
        try:
            user = request.user
        except AttributeError:
            return response
        try:
            crowd_token = request.COOKIES["crowd.token_key"]
        except KeyError:
            crowd_token = None

        if user.is_authenticated() and crowd_token is None:
            try:
                pass
                #cookieInfo = self.crowdBackend.getCookieInfo()
                #validationFactors = self.crowdBackend.getValidationFactors(request)
                #principalToken = self.crowdBackend.getPrincipalToken(request.user.username, validationFactors)
                #max_age = 30 * 365 * 24 * 60 * 60
                #expires = datetime.strftime(datetime.utcnow() + timedelta(seconds=max_age), "%a, %d-%b-%Y %H:%M:%S GMT")
                #response.set_cookie("crowd.token_key",
                #            principalToken, max_age=max_age,
                #            expires=expires, domain=cookieInfo.domain,
                #            path="/",
                #            secure=cookieInfo.secure)
            #except WebFault as e:
            #    if hasattr(e.fault, 'faultstring') and user.username == e.fault.faultstring:
            #        message = "Likely not a valid user"
            #    else:
            #        message = e.message
            #    logger.error("Received error from Crowd server for username '" + user.username + "'; " + message)
            except URLError as e:
                #logger.error("Could not communicate with Crowd server; Is AUTH_CROWD_SERVER_URI configured correctly? ('" + crowd_settings.AUTH_CROWD_SERVER_URI + "')")
                if type(e.reason) is str:
                    logger.error(e.reason)
                else:
                    logger.error(str(type(e.reason)) + ": " + str(e.reason))
        else:
            pass
            #if user is AnonymousUser and crowd_token is not None and self.crowdUserLoggedIn:
            #    self.crowdBackend.invalidateToken()


        return response