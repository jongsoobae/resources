from django import forms
from django.utils.translation import ugettext_lazy as _, string_concat
import re
from telco_fe.shared_components.models.acl_core import Privilege
from django.forms.widgets import CheckboxInput, Select

REGEX_PHONE_NUMBER = r'^[0-9-+(). ]+$'
regex_phone_number = re.compile(REGEX_PHONE_NUMBER)
USER_PRIVILEGE = [(x.privilege_id,x.privilege_name) for x in Privilege.objects.all()]

class UserManageForm(forms.Form):
    email = forms.EmailField(label=_('Email'),
                                required=True,
                                max_length=255,
                                widget=forms.TextInput(attrs={'class':'input-text','style':'width:300px;'})
                                )
    first_name = forms.CharField(label=_('First Name'),
                                 required=True,
                                 max_length=255,
                                 widget=forms.TextInput(attrs={'class':'input-text'})
                                 )
    last_name = forms.CharField(label=_('Last Name'),
                                 required=True,
                                 max_length=255,
                                 widget=forms.TextInput(attrs={'class':'input-text'})
                                 )
    telephone = forms.CharField(label=_('Telephone'),
                                max_length=255,
                                widget=forms.TextInput(attrs={'class':'input-text'}))
    mobile = forms.CharField(label=_('Mobile'),
                             max_length=255,
                             widget=forms.TextInput(attrs={'class':'input-text'}))
    is_super_user = forms.CharField(label=_('is super user'),
                                        widget=CheckboxInput())
    def __init__(self, *args, **kwargs):
        if kwargs:
            user = kwargs.pop('user')
            super(UserManageForm, self).__init__(*args, **kwargs)
            self.initial['email'] = user.username
            self.initial['first_name'] = user.first_name
            self.initial['last_name'] = user.last_name
            self.initial['telephone'] = user.get_profile().user_phone
            self.initial['mobile'] = user.get_profile().user_mobile
        else:
            super(UserManageForm, self).__init__(*args, **kwargs)
    
    def clean_telephone(self):
        super(UserManageForm, self).clean()
        telephone = self.cleaned_data.get('telephone').strip()
        if not regex_phone_number.match(telephone):
            raise forms.ValidationError(_('Invalid telephone number'))
        return telephone
   
    def clean_mobile(self):
        super(UserManageForm, self).clean()
        mobile = self.cleaned_data.get('mobile').strip()
        if not regex_phone_number.match(mobile):
            raise forms.ValidationError(_('Invalid mobile number'))
        return mobile
    
