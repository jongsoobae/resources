from django import forms
from django.utils.translation import ugettext_lazy as _, string_concat
import re
from telco_fe.shared_components.models.acl_core import Privilege

REGEX_PHONE_NUMBER = r'^[0-9-+(). ]+$'
regex_phone_number = re.compile(REGEX_PHONE_NUMBER)

USER_LANGUAGE = (('en',_('English')),
                 ('cn',_('Chinese')),
                 ('jp',_('Japanes')),
                 ('kr',_('Korean')),
)

USER_LOCATION = (('en_US',_('English(United States)')),
                 ('ko_KR',_('Korean(Korea)')),
)
USER_TIME = ((0,_('(GMT+00:00) Greenwich Mean Time(GMT)')),
             (9,_('(GMT+09:00) Korea Time(GMT+9)')),
)

class UserRole(forms.Form):
    privilege = forms.MultipleChoiceField(label=_('User Role'),
                                          widget=forms.CheckboxSelectMultiple(attrs={}))
    def __init__(self, *args, **kwargs):
        account_privilege = kwargs.pop('account_privilege')
        super(UserRole, self).__init__(*args, **kwargs)
        self.fields['privilege'].choices = [(x.account_privilege_id, x.privilege_name) for x in account_privilege]

class UserProfileForm(forms.Form):
    email = forms.EmailField(label=_('Email'),
                                required=True,
                                max_length=255,
                                widget=forms.TextInput(attrs={'class':'input-text'})
                                )
    first_name = forms.CharField(label=_('First Name'),
                                 required=True,
                                 max_length=255,
                                 widget=forms.TextInput(attrs={'class':'input-text'})
                                 )
    last_name = forms.CharField(label=_('Last Name'),
                                 required=True,
                                 max_length=255,
                                 widget=forms.TextInput(attrs={'class':'input-text'})
                                 )
    old_password = forms.CharField(label=_('Current password'),
                               required=True,
                               max_length=255,
                               widget=forms.PasswordInput(attrs={'class':'input-text'})
                               )
    new_password = forms.CharField(label=_('New Password'),
                                       required=True,
                                       max_length=255,
                                       widget=forms.PasswordInput(attrs={'class':'input-text'})
                                       )
    password_confirm = forms.CharField(label=_('Confirm new password'),
                                   required=True,
                                   max_length=255,
                                   widget=forms.PasswordInput(attrs={'class':'input-text'})
                                   )
    telephone = forms.CharField(label=_('Telephone'),
                                max_length=255,
                                widget=forms.TextInput(attrs={'class':'input-text'}))
    mobile = forms.CharField(label=_('Mobile'),
                             max_length=255,
                             widget=forms.TextInput(attrs={'class':'input-text'}))
    user_language = forms.ChoiceField(label=_('Language'),
                                      choices=USER_LANGUAGE,
                                      widget=forms.Select())
    user_location = forms.ChoiceField(label=_('Location'),
                                      choices=USER_LOCATION,
                                      widget=forms.Select())
    user_time = forms.ChoiceField(label=_('Time'),
                                  choices=USER_TIME,
                                  widget=forms.Select())
    
    def clean_telephone(self):
        super(UserProfileForm, self).clean()
        telephone = self.cleaned_data.get('telephone').strip()
        if not regex_phone_number.match(telephone):
            raise forms.ValidationError(_('Invalid telephone number'))
        return telephone
   
    def clean_mobile(self):
        super(UserProfileForm, self).clean()
        mobile = self.cleaned_data.get('mobile').strip()
        if not regex_phone_number.match(mobile):
            raise forms.ValidationError(_('Invalid mobile number'))
        return mobile
    
    def clean_password_confirm(self):
        if 'new_password' in self.cleaned_data:
            password = self.cleaned_data['new_password']
            password_confirm = self.cleaned_data['password_confirm']
            if password == password_confirm:
                return password_confirm
            raise forms.ValidationError(_('Passwords is not match.'))
        