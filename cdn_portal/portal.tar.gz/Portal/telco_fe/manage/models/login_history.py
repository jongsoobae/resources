from django.db import models
from django.contrib.auth.models import User

class LoginHistory(models.Model):
    ACTION_TYPE_CHOICES = {'login':1, 'logout':2}
                                                 
    history_id = models.AutoField(primary_key=True, db_column='id')                                                  
    action_date = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(User, db_column='user_id')
    user_ip = models.CharField(max_length=30)
    action_type = models.IntegerField(max_length=2, choices=ACTION_TYPE_CHOICES)
    user_browser = models.CharField(max_length=200)
    user_os = models.CharField(max_length=200)
    
    class Meta:
        db_table = 'login_history'
        ordering = ['-action_date']
    