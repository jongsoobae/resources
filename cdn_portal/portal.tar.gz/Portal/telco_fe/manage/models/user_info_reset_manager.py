from telco_fe import settings
from telco_fe.settings import IS_TEST_USER_MAIL, TEST_MAIL_ACCOUNT
from spectrum_fe.shared_components.utils.aquacrypto import decrypt, encrypt
from django.db import models
from django.utils.encoding import smart_str
from spectrum_fe.ldap.open_ldap_mgmt import OpenLDAPManager,CUSTOMER_USER_CLASS
from spectrum_fe.shared_components.utils.common import log_error
from spectrum_fe.shared_components.models import HistoryModel


class UserinfoResetManager(HistoryModel):
    id = models.AutoField(primary_key=True, db_column='id')                                                  
    userkey = models.IntegerField(db_column='user_key', default=0)
    username = models.CharField(db_column='user_name',max_length=100)
    user_ip = models.CharField(db_column='client_ip', max_length=20)
    app_name = models.CharField(max_length=50)
    auth_token = models.CharField(max_length=512)
    reset_url = models.CharField(max_length=512)
    
    login_url = models.CharField(max_length=256)
    notify_email = models.CharField(max_length=100)
    notify_email_result = models.CharField(max_length=100)
    token_valid_minute = models.IntegerField(default='0')
    description = models.CharField(max_length=512)
    obj_state = models.SmallIntegerField(default='1')
    time_token_issued = models.DateTimeField()
    time_created = models.DateTimeField()
    time_updated = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'user_info_reset_manager'
        ordering = ['-time_created']

    class SpectrumMeta:
        allow_delete = True
    
    def send_password_reset_email(self,request):
        ld = OpenLDAPManager()
        customer_user_filter = "(&(objectClass=%s)(mail=%s))" % (CUSTOMER_USER_CLASS,self.notify_email)
        userlists = ld.list_customer_users(self.app_name,customer_user_filter,None)
        ld.unbind()

        if len(userlists) == 0:
            errmsg = 'email: %s does not exist at %s' % (self.notify_email,self.login_url)
        else:
            errmsg = ''
            token = "email=%s,appname=%s,loginurl=%s,id=%s,created=%s,duration=%s" % (self.notify_email,
                                                                                      self.app_name,
                                                                                      self.login_url,
                                                                                      str(self.pk),
                                                                                      str(self.time_token_issued),
                                                                                      str(self.token_valid_minute))
            #import urllib
            #token = urllib.quote(token, safe='/')
            token = encrypt(token)
            reseturl = "%s/manage/user/password_reset?token=%s" % (settings.AURORA_URL,token) 
            self.auth_token = token    
            durationhour = self.token_valid_minute /60        
            try:
                #send mail
                self.notice_customer_password_reset_email(request,self.notify_email,str(durationhour),reseturl,"Cdnetworks Customer Support" )
            except Exception,e:
                self.notify_email_result = str(e)
            
            self.obj_state =2
            self.save() #update 
        return errmsg
            
    def notice_customer_password_reset_email(self,request,email, durationhour,reseturl, company):
        from django.template.loader import render_to_string
        from django.core.mail import send_mail
        from django.core.mail.message import EmailMultiAlternatives
        from telco_fe.config_constants import REPORT_MAIL_SENDER
        try:    
            title = "Reset your password"
            receive_mail = [email]
            contents = []            
            try:
                if IS_TEST_USER_MAIL:
                    contents.append("This email is test mail which was intended to be sent to %s" % str(receive_mail))
                    contents.append("")                        
                    receive_mail = TEST_MAIL_ACCOUNT    
            except:
                pass              


            contents.append("Hello!")
            contents.append("")
            contents.append("To reset your account password, click on the following link. Please note that reset link will expire in %s hours." % (durationhour))
            contents.append("If you didn't issue a password reset, you can safely ignore this email.")
            contents.append("")
            contents.append("<a href='"+reseturl+"'>Click me</a>")
            contents.append("")
            contents.append("")
            contents.append("Best Regards,")
            contents.append("")
            contents.append(company)
            msg = "<br>".join(contents)
            email_msg = render_to_string("email_template.html",{'title':title,
                                                                'domain':settings.TELCO_URL,
                                                                'contents':msg})
    
            email = EmailMultiAlternatives(subject=smart_str(title),
                                           body=email_msg,
                                           from_email=REPORT_MAIL_SENDER,
                                           to=receive_mail)
            email.attach_alternative(email_msg, "text/html")
            email.send()    
        except Exception,e:
            log_error(request, "fail to send password reset email", e=e) 
            raise e       