from django.conf.urls.defaults import *

# Shared Components

urlpatterns = patterns('telco_fe.manage.views',
    url(r'^user_account/$', 'user_account.render_page', name='user_account'),
    url(r'^user_manage/account/(?P<account_no>\d+)/$', 'user_manage.render_page', name='user_manage'),
    url(r'^user_manage/account/(?P<account_no>\d+)/user/(?P<user_id>\d+)/$', 'user_manage.render_page', name='user_manage'),
	url(r'^user_manage_list/$', 'user_manage.render_user_list', name='user_list'),
    url(r'^user_login_history/$', 'user_login_history.render_page', name='user_login_history'),
    url(r'^ajax/user/check_duplicate/$', 'user_profile.ajax_checked_duplicate_email', name='user_duplicate_checked'),
    url(r'^ajax/user/set_active_user/$', 'user_manage.ajax_set_user_active', name='set_active_user'),

)