from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.db.models import Q
from django.contrib.auth.decorators import login_required

@login_required
def render_page(request):
    msg = 'Welcome to the customer portal.  Please use the navigation on the left to continue.'

    context = RequestContext(request, {'msg':msg})
    return render_to_response('user.html', context)
