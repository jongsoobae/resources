from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.db.models import Q
from django.contrib.auth.decorators import login_required
from telco_fe.manage.models.login_history import LoginHistory
from django.core.paginator import Paginator
from telco_fe.shared_components.decorators import menu_authority_required

@login_required
@menu_authority_required
def render_page(request):
    view_per_page = int(request.POST.get('view', 10))
    template_page = 'user_login_history.html'
    user = request.user
    login_history = LoginHistory.objects.filter(user = user)
    paginator = Paginator(login_history, view_per_page)
    history_list = page_num = max_page = min_page = None
    page_num = int(request.POST.get('page','1'))
    max_page = page_num + 3
    min_page = page_num -3
    history_list = paginator.page(page_num)
    
    context = RequestContext(request, {'login_history':history_list,
                                       'min_page':min_page,
                                       'max_page':max_page,
                                       'view_per_page':view_per_page,
                                       'page':page_num
                                       })
    return render_to_response(template_page, context)