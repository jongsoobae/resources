from django.contrib.auth.decorators import login_required
from telco_fe.shared_components.decorators import menu_authority_required
from telco_fe.shared_components.models.acl_core import ControlGroup, \
    AuthUserHasControlGroup, Privilege#, AuthUserHasPrivilege
from django.template.context import RequestContext
from django.shortcuts import render_to_response
from telco_fe.manage.forms.user_profile import UserProfileForm, UserRole
from spectrum_fe.shared_components.utils.user_util import GenPasswd
from telco_fe.shared_components.utils.acl_helper import ControlGroupAclHelper, \
    getDefaultAccount, getControlGroup, getPrivilegeFromControlGroupList, \
    getSelectedAccount
from django.http import HttpResponse
from django.utils import simplejson
#from telco_fe.manage.forms.user_manage import UserManageForm
from django.contrib.auth.models import User
from spectrum_fe.shared_components.models.customer import CustomerDisplay, \
    CustomerAccount
from telco_fe.shared_components.models import UserProfile, create_user_profile
from django.db import transaction
from spectrum_fe.shared_components.mail import send
from django.db.models import Q
from telco_fe.shared_components.models.acl_core import CustomerAccountHasPrivilege, \
    CustomerAccountWrapper, AuthUserPrivilegeBlacklist
from telco_fe.manage.forms.user_manage import UserManageForm
from django.core.paginator import Paginator, EmptyPage, InvalidPage
from spectrum_fe.shared_components.decorators import deprecated

@login_required
@menu_authority_required
@transaction.commit_on_success
def render_page(request, account_no=None, user_id=None):
    template_page = 'user_manage.html'
    account_list = ControlGroupAclHelper(request).getControlGroupList().excute().getAccountList()
    if user_id:
        user = User.objects.get(pk=user_id)
        form = UserManageForm(user=user)
        save_type = 'edit'
    else:
        save_type = 'new'
        form = UserManageForm()
    account = CustomerAccountWrapper.objects.get(pk=account_no)
    pr = None
    role_form = None

    cgl = account.get_control_group()
    privileges = Privilege.objects.all()
    default_account = CustomerAccount.objects.get(pk=account_no)
    dict_control_group = getControlGroup(request, default_account)
    if request.POST:
        data = request.POST

        if data.get('save_type') == 'new':
            password = ""
            customer_ids = CustomerDisplay.objects.filter(account__account_no=data.get('account_list'))
            customer = None
            if len(customer_ids) > 0:
                customer = customer_ids[0]
                for q in customer_ids:
                    if q.ocsp_region == 4000:
                        customer = q
            save_user, create = User.objects.get_or_create(username=data.get('email'), first_name=data.get('first_name'), last_name=data.get('last_name'), password=password, email=data.get('email'))
            #save_user = User(username=data.get('email'),first_name=data.get('first_name'),last_name=data.get('last_name'),password=password,email=data.get('email'))
            #save_user.save()
            user_profile, create_profile = UserProfile.objects.get_or_create(user=save_user,
                                          customer=customer,
                                          user_phone=data.get('telephone'),
                                          user_mobile=data.get('mobile'))

#            create_user_profile(sender=User, instance=save_user, created=user_profile)
#            user_profile.save()

            blacklist_privilege = data.get('blacklist_privilege')
            if blacklist_privilege != "":
                sp = blacklist_privilege.split(',')
                for q in sp:
                    blacklist = AuthUserPrivilegeBlacklist(auth_user_id=save_user, account_has_privilege_id=CustomerAccountHasPrivilege.objects.get(pk=q))
                    blacklist.save(request=request)
#                blacklist = AuthUserPrivilegeBlacklist(auth_user_id=save_user, account_has_privilege_id.privilege_id)

#            for privilege in select_privilege:
#                user_privilege = AuthUserHasPrivilege(auth_user_id=save_user,privilege_id=Privilege.objects.get(pk=privilege))
#                user_privilege.save(request=request)
            select_control_group = data.getlist('control_group')
            for cg in select_control_group:
                user_cg = AuthUserHasControlGroup(auth_user_id=save_user, control_group_id=ControlGroup.objects.get(pk=cg))
                user_cg.save(request=request)
            send.mailSender(sender='aurora@cdnetworks.com', to='dongjun.kim@cdnetworks.co.kr', subject='CustomerPortal Password', text='your password = ' + password, attachs=None)

        elif data.get('save_type') == 'edit':
            user = User.objects.get(pk=user_id)
            user.username = data.get('email')
            user.first_name = data.get('first_name')
            user.last_name = data.get('last_name')
            user.email = data.get('email')
            user.save()
            up = UserProfile.objects.get(user=user_id)
            up.user_phone = data.get('telephone')
            up.user_mobile = data.get('mobile')
            up.save()
            select_control_group = data.getlist('control_group')
            base_cg = ControlGroup.objects.filter(account_no__account_no=data.get('account_list')).values('control_group_id')
            rm_cgl = AuthUserHasControlGroup.objects.filter(auth_user_id=user, control_group_id__in=base_cg)
            rm_cgl.delete()
            for cg in select_control_group:
                user_cg = AuthUserHasControlGroup(auth_user_id=user, control_group_id=ControlGroup.objects.get(pk=cg))
                user_cg.save(request=request)
            rm_privil = AuthUserPrivilegeBlacklist.objects.filter(auth_user_id=user, \
                                                   account_has_privilege_id__in=CustomerAccountHasPrivilege.objects.filter(account_no__account_no=data.get('account_list'))
                                                   )
            rm_privil.delete()
            blacklist_privilege = data.get('blacklist_privilege')
            if blacklist_privilege != "":
                sp = blacklist_privilege.split(',')
                for q in sp:
                    blacklist = AuthUserPrivilegeBlacklist(auth_user_id=user, account_has_privilege_id=CustomerAccountHasPrivilege.objects.get(pk=q))
                    blacklist.save(request=request)
#            for q in data.get('privilege')

#        elif data.get('save_type') =='update':

    return render_to_response(template_page, RequestContext(request, {
                                        'user_control_group_list':request.user.control_group,
                                        'form':form,
                                        'account_list':account_list,
                                        'privileges':privileges,
                                        'role_form':role_form,
                                        'user':request.user,
                                        'account':default_account,
                                        'control_group_list':dict_control_group.get('control_group_list'),
                                        'default_control_group':dict_control_group.get('default'),
                                        'save_type':save_type
                                 }))

@login_required
@menu_authority_required
def render_user_list(request):
    template_page = 'user_manage_list.html'
    account = getDefaultAccount(request)
    dict_control_group = getControlGroup(request, account)
    control_group_list = dict_control_group.get('control_group_list')

    if request.POST:
        data = request.POST
        input_name = data.get('search_name', '')
        input_email = data.get('search_email', '')
        is_active = data.get('status', 1)
        control_group = data.get('control_group_list')
        account_no = data.get('account_val')
        account = getSelectedAccount(request, account_no)
#        account = CustomerAccount.objects.get(pk=account_no)
        control_group_list = ControlGroup.objects.filter(account_no=account)
        if control_group == 'all':
            control_group = control_group_list.values('control_group_id')
            search_id = AuthUserHasControlGroup.objects.filter(control_group_id__in=control_group).values('auth_user_id')
        else:
            search_id = AuthUserHasControlGroup.objects.filter(control_group_id__control_group_id=control_group).values('auth_user_id')
        users_list = User.objects.filter(
                                        Q(first_name__contains=input_name) | Q(last_name__contains=input_name),
                                        id__in=search_id,
                                        username__contains=input_email,
                                        is_active=is_active
                                        )
    else:
        control_group = ControlGroup.objects.filter(account_no=account).values('control_group_id')
        search_id = AuthUserHasControlGroup.objects.filter(control_group_id__in=control_group).values('auth_user_id')
        users_list = User.objects.filter(id__in=search_id)
    view_per_page = int(request.POST.get('view', 10))
    paginator = Paginator(users_list, view_per_page)
    get_page = request.POST.get('page')
    page = int(get_page) if get_page else 1
    page_num = int(request.POST.get('page', '1'))
    max_page = page_num + 9
    min_page = page_num - 9
    try:
        user_list = paginator.page(page_num)
    except (EmptyPage, InvalidPage):
        user_list = paginator.page(paginator.num_pages)

    account_list = ControlGroupAclHelper(request).getControlGroupList().excute().getAccountList()
    return render_to_response(template_page, RequestContext(request, {
                                    'user_list':user_list,
                                    'account_list':account_list,
                                    'account':account,
                                    'control_group_list':control_group_list,
                                    'control_group':control_group,
                                    'page':page,
                                    'min_page':min_page,
                                    'max_page':max_page,
                                    'view_per_page':view_per_page
                             }))

@deprecated
def ajax_get_customer_privilege(request):
    param = request.POST.get('control_group_list')
    sp = param.split(',')
    cgl = []
    for q in sp:
        cgl.append(int(q))

    privileges = getPrivilegeFromControlGroupList(cgl)
    temp_list = []
    for q in privileges:
        temp_list.append(q.privilege_id)
    json_return = simplejson.dumps({'factor':'success', 'controlgroup_privilege':temp_list})
    return HttpResponse(json_return, mimetype='json/application')

def ajax_set_user_active(request):
    if request.POST:
        data = request.POST
        users = data.getlist('user_no')
        active_type = data.get('type')
        for q in users:
            user = User.objects.get(pk=q)
            if active_type == 'Active':
                user.is_active = True
            else:
                user.is_active = False
            user.save()

    json_return = simplejson.dumps({'factor':'success', 'user_id':users, 'type':active_type})
    return HttpResponse(json_return, mimetype='json/application')