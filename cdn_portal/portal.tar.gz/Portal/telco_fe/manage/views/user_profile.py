from django.template.context import RequestContext
from django.shortcuts import render_to_response
from telco_fe.manage.forms.user_profile import UserProfileForm
from django.contrib.auth.models import User
from django.utils import simplejson
from django.http import HttpResponse
from telco_fe.shared_components.utils.common_code import get_common_code_list
from telco_fe.shared_components.decorators import menu_authority_required

@menu_authority_required
def render_page(request):
    template_page = "user_profile.html"
    user_profile = request.user.get_profile()
    common_code = get_common_code_list(request)
    if request.POST:
        user_form = UserProfileForm(request.POST)
        user_form.fields['user_time'].choices = common_code.get('gmt_list')
        user_form.fields['user_language'].choices = common_code.get('language_list')
        user_form.fields['user_location'].choices = common_code.get('locale_list')
    form = UserProfileForm(initial={'email':user_profile.user.username,
                                    'first_name':user_profile.user.first_name,
                                    'last_name':user_profile.user.last_name,
                                    'telephone':user_profile.user_phone,
                                    'mobile':user_profile.user_mobile,
                                    'user_language':user_profile.language_cd,
                                    'user_location':user_profile.locale_cd,
                                    'user_time':user_profile.gmt_cd})
    form.fields['user_time'].choices = common_code.get('gmt_list')
    form.fields['user_language'].choices = common_code.get('language_list')
    form.fields['user_location'].choices = common_code.get('locale_list')
    context = RequestContext(request, {'form':form})
    return render_to_response(template_page, context)

def ajax_checked_duplicate_email(request):
    check_email = request.POST.get('email')
    user = User.objects.filter(username=check_email)
    if len(user) > 0 :
        if(user[0].is_superuser and request.user.is_superuser == False):
            json_context = {"result": "superuser"}
        else:
#            p_list = user[0].userprofile.get_user_privilege()
#            privilege_list = []
#            for q in p_list:
#                if not q.privilege_id.privilege_id in privilege_list:
#                    privilege_list.append(q.privilege_id.privilege_id)
#            user_info = {"first_name":user[0].first_name, 
#                         "last_name":user[0].last_name, 
#                         "user_phone":user[0].userprofile.user_phone, 
#                         "user_mobile":user[0].userprofile.user_mobile,
#                         "privilege_list":privilege_list,
#                         "user_control_group":user[0].userprofile.get_control_group()
#                         }
            json_context = {"result": "duplicate", "user":None}
    else :
        json_context = {"result": "success","check_email":check_email}
    json = simplejson.dumps(json_context)
    return HttpResponse(json,mimetype="application/json")

def ajax_save_profile(request):
    return