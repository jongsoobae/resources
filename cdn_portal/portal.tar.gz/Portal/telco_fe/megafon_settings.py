from settings import * 

ADMINS = (
        ('ENG-UI', 'eng-ui@cdnetworks.com'),
)
EMAIL_ALERTS = ['eng-ui@cdnetworks.com']

DEBUG = False
del AUTHENTICATION_BACKENDS

OCSP_HOST_PREFIX = 'https://dev'
OCSP_PROD_HANDLER = False

MIDDLEWARE_CLASSES = (
    'django.middleware.common.CommonMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    # PROJECT_NAME+'.shared_components.middleware.ocsplogin.AcceptOCSPCookie',
    PROJECT_NAME+'.shared_components.middleware.fakelogin.FakeLogin',
    'django.middleware.locale.LocaleMiddleware',
    PROJECT_NAME+'.shared_components.middleware.set_lang.SetLang',
)

DEFAULT={
        'NAME':'aurora',
        'ENGINE':'mysql',
        'USER':'root',
        'PASSWORD':'admin',
        'HOST':'localhost',
        'PORT':'3306'
    }
STATS={
        'NAME':'stat',
        'ENGINE':'mysql',
        'USER':'root',
        'PASSWORD':'admin',
        'HOST':'localhost',
        'PORT':'3306'
    }
DATABASES = {
    'default': DEFAULT,
    'stats':STATS
}

WHITE_LABEL = 'megafon_standalone'

STANDALONE_SITE = True
