from django.conf.urls.defaults import *

# Configuration
urlpatterns = patterns('telco_fe.monitoring.views',
    url(r'^full_system/$', 'main.render_page', name='full_system'),
    url(r'^traffic/$', 'dwa.traffic', name='dwa_traffic_chart'),
    url(r'^nodes/$', 'dwa.node_overview', name='dwa_nodes'),
    url(r'^node/detail$', 'dwa.node_detail', name='dwa_node_detail'),
    url(r'^tools/$', 'dwa.support_tools', name='dwa_tools'),
    url(r'^flush/$', 'dwa.cache_flush', name='cache_flush'),
    url(r'^auto_size/$', 'dwa.auto_size', name='auto_size'),
)