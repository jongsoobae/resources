# -*- coding: utf-8 -*-
"""
    Copyright (c) 2012 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Monitoring > Full System
"""

from datetime import datetime
from django import forms
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.core.exceptions import PermissionDenied, ValidationError, \
    ValidationError, ObjectDoesNotExist
from django.core.paginator import Paginator, EmptyPage, InvalidPage, \
    PageNotAnInteger
from django.core.urlresolvers import reverse
from django.db.models import Q
from django.forms.formsets import formset_factory
from django.http import HttpResponseRedirect, Http404, HttpResponse
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.utils import simplejson
from django.views.generic.edit import CreateView


from telco_fe import settings
from telco_fe.shared_components.decorators import is_authorized
from telco_fe.shared_components.utils.get_telco_items import get_customer_pops, get_customer_contract_items
from telco_fe.shared_components.utils.telco_user_helper import isTelcoMember
from telco_fe.shared_components.utils.acl_helper import getDefaultAccount
import md5
from telco_fe.shared_components.models.common_code import GMTCD, LanguageCD, LocaleCD

def get_telco_items(request):
    def_account = getDefaultAccount(request)
    telco_user = isTelcoMember(request.user,def_account.account_no)

    rs_pops = get_customer_pops (customer = def_account, use_type=2)
    rs_contract_items = get_customer_contract_items (customer = def_account)

    pop_id = []
    contract_item = []
    pop_ids = ''
    contract_items = ''
    
    if rs_pops != -1:
        for rs in rs_pops:
            if rs.pop.ihms_pop:
                pop_id.append(str(rs.pop.ihms_pop.pop_id))
        pop_ids = ':'.join(pop_id)
        
    if rs_contract_items != -1:
        for rs in rs_contract_items:
            contract_item.append(str(rs.contract.contract_no).zfill(10) + '-' + str(rs.item_no).zfill(6))
        contract_items = ':'.join(contract_item)

    if False:
        pop_ids = '10017'
        contract_items = '0040007770-000010:0040007770-000030'    
        str_parameter = '%s&pop_list=%s&contract_list=%s'%(settings.OUI_MD5_SALT, pop_ids, contract_items)
        str_md5 = md5.new(str_parameter).hexdigest()
    else:
        str_parameter = '%s&pop_list=%s&contract_list=%s'%(settings.OUI_MD5_SALT, pop_ids, contract_items)
        str_md5 = md5.new(str_parameter).hexdigest()
            
    return (pop_ids, contract_items, str_md5)

@login_required
@is_authorized
def auto_size(request):
    pop_ids, contract_items, str_md5 = get_telco_items(request)
    context = RequestContext(request,{})
    return render_to_response('auto_size.html', context)

@login_required
@is_authorized
def traffic(request):
    pop_ids, contract_items, str_md5 = get_telco_items(request)
    target_url = settings.OUITELCO_HOST_PREFIX + '/telco/chartron/'
    # u'GMT_61' request.user.get_profile().gmt_cd
    timezone = '0'
    try:
        gmt_obj = GMTCD.objects.get(gmt_cd = request.user.get_profile().gmt_cd)
        timezone = str(gmt_obj.gmt_hh)
    except:
        pass
    
    context = RequestContext(request,{'iframe_src':target_url, 'pop_ids':pop_ids, 'contract_items':contract_items, 'str_md5':str_md5, 'telco_user_id':request.user.username, 'timezone':timezone})
    return render_to_response('includes/iframe_base.html', context)

@login_required
@is_authorized
def node_overview(request):
    pop_ids, contract_items, str_md5 = get_telco_items(request)
    target_url = settings.OUITELCO_HOST_PREFIX + '/telco/mon/pop/'
    context = RequestContext(request,{'iframe_src':target_url, 'pop_ids':pop_ids, 'contract_items':contract_items, 'str_md5':str_md5, 'telco_user_id':request.user.username})
    return render_to_response('includes/iframe_base.html', context)

@login_required
@is_authorized
def node_detail(request):
    pop_ids, contract_items, str_md5 = get_telco_items(request)
    target_url = '/'
    context = RequestContext(request,{'iframe_src':target_url, 'pop_ids':pop_ids, 'contract_items':contract_items, 'str_md5':str_md5, 'telco_user_id':request.user.username})
    return render_to_response('includes/iframe_base.html', context)

@login_required
@is_authorized
def support_tools(request):
    pop_ids, contract_items, str_md5 = get_telco_items(request)
    
    target_url = settings.OUITELCO_HOST_PREFIX + '/telco/supporttools/'
    
    context = RequestContext(request,{'iframe_src':target_url, 'pop_ids':pop_ids, 'contract_items':contract_items, 'str_md5':str_md5, 'telco_user_id':request.user.username})
    return render_to_response('includes/iframe_base.html', context)

@login_required
@is_authorized
def cache_flush(request):
    pop_ids, contract_items, str_md5 = get_telco_items(request)
    target_url = settings.OUITELCO_HOST_PREFIX + '/telco/flush/'
    context = RequestContext(request,{'iframe_src':target_url, 'pop_ids':pop_ids, 'contract_items':contract_items, 'str_md5':str_md5, 'telco_user_id':request.user.username})
    return render_to_response('includes/iframe_base.html', context)