from django.http import HttpResponse, Http404
from telco_fe.monitoring.models.gslb_rms import RMSVip, RMSVipProbe, RMSPacketLoss, RMSPacketLossHistory
from spectrum_fe.alerting.models.probe import RMSSettings
from django.shortcuts import render_to_response
from django.db import connection, connections #for executing raw SQL query
from django.db.models import Avg, Max, Min
from django.template.context import RequestContext
from django.contrib.auth.decorators import login_required
#from telco_fe.config_constants import RMS_REFRESH_TIME
from telco_fe.shared_components.decorators import is_authorized
from telco_fe.shared_components.utils.acl_helper import getDefaultAccount
from telco_fe.shared_components.utils.get_telco_items import get_customer_pops, get_customer_contract_items
from telco_fe.shared_components.utils.telco_user_helper import isTelcoMember


def complex_query(param_probe_name, pop_names=''):
	cursor = connections['read-only'].cursor()
	try:
		sql = """
				SELECT pop_id, pop_name, probe_id, service_name, `position`, up_count, down_count, case when down_count = 0 then 100 else up_percent end as `up_percent`, avg_val, failing, warning, total_value, display_format, secondary_format, drill_down, probe_name, min_value, max_value, ack_count from (
					SELECT innerq.pop_id, innerq.pop_name,
					innerq.probe_id, innerq.service_name, ifnull(innerq.position,-2) `position`,
					innerq.up_count,

					case when innerq.ack_count > 0 then
						case when innerq.vip_count - innerq.up_count > 0 then
							case when innerq.ack_count - innerq.up_count = 0 then 0
							else innerq.vip_count - innerq.up_count - innerq.ack_count end
						else innerq.vip_count - innerq.up_count end
					else innerq.vip_count - innerq.up_count end `down_count`,

					case when innerq.vip_count > 0 then case when innerq.ack_count > 0 then (innerq.up_count+innerq.ack_count)/innerq.vip_count else innerq.up_count/innerq.vip_count end else 0 end * 100 `up_percent`,
					case when innerq.up_count > 0 then innerq.up_vals/innerq.up_count end `avg_val`,
					case when innerq.vip_count > 0 then case when innerq.ack_count > 0 then (innerq.up_count+innerq.ack_count)/innerq.vip_count else innerq.up_count/innerq.vip_count end else 0 end * 100 < innerq.failure_percent `failing`,
					case when innerq.vip_count > 0 then case when innerq.ack_count > 0 then (innerq.up_count+innerq.ack_count)/innerq.vip_count else innerq.up_count/innerq.vip_count end else 0 end * 100 < innerq.warning_percent `warning`,
					innerq.up_vals `total_value`, innerq.display_format, innerq.secondary_format, innerq.drill_down, innerq.probe_name, innerq.min_value, innerq.max_value, innerq.ack_count
					from (SELECT p.pop_id, p.name `pop_name`,
					min(svc.probe_id) `probe_id`,
					coalesce(dis.visual_name,svc.name) `service_name`,
					dis.display_format, dis.secondary_format,
					dis.priority, case when dis.probe_name = '%s' then -1 else dis.position end position, dis.warning_percent, dis.failure_percent, SUM(IF((m.val is null or m.val<0 or m.expired=1), 0, 1)) `up_count`, SUM(IF((m.val is null or m.val<0 or m.expired=1), 0, m.val)) `up_vals`, MIN(IF((m.val is null or m.val<0 or m.expired=1), 0, m.val)) `min_value`, MAX(IF((m.val is null or m.val<0 or m.expired=1), 0, m.val)) `max_value`, COUNT(distinct v.vip_id) `vip_count`, m.vip_id, svc.vip_probe_id, dis.drill_down, svc.name as probe_name,
					COUNT(DISTINCT(case when (ack.vip_probe_id  and (m.val < 0 or m.expired = 1 or m.val is null)) then ack.vip_probe_id else null end)) as ack_count
					FROM rms_pop p left join rms_server s on (s.pop_id = p.pop_id) left join rms_vip v on (v.server_id = s.server_id)
					left join rms_vip_probe svc on (svc.vip_id = v.vip_id)
					join rms_display_probes dis on (dis.probe_name = svc.name and (dis.for_probe_name = '%s' or dis.probe_name='%s'))
					left join rms_message_expired_view m on (m.vip_id = v.vip_id and m.vip_probe_id = svc.vip_probe_id)
					left join (select distinct vip_probe_id from rms_acknowledge where end_date > NOW()) as ack on (svc.vip_probe_id = ack.vip_probe_id)
					group by p.pop_id, p.name, svc.name ) as innerq
					order by case when case when innerq.ack_count > 0 then innerq.up_count+innerq.ack_count/innerq.vip_count else innerq.up_count/innerq.vip_count end * 100 < innerq.failure_percent then 2 when case when innerq.ack_count > 0 then innerq.up_count+innerq.ack_count/innerq.vip_count else innerq.up_count/innerq.vip_count end * 100 < innerq.warning_percent then 1 else 0 end desc, innerq.priority asc, innerq.up_count/innerq.vip_count * 100 asc, innerq.vip_count desc, innerq.pop_name asc
				) as final
				where  service_name in ('PROBE', 'HTTP') and final.probe_id is not null %s;
		""" %(param_probe_name, param_probe_name, param_probe_name, " and 1 = 2 " if pop_names == '' else " and pop_name in (%s)"%(pop_names))

		cursor.execute(sql)
		
	except:
		pass
	rows = cursor.fetchall()
	return rows

def complex_query_airport(param_probe_name):
	cursor = connections['read-only'].cursor()
	try:
		cursor.execute("""
		SELECT pop_id, pop_name, probe_id, service_name, `position`, up_count, down_count, case when down_count = 0 then 100 else up_percent end as `up_percent`, avg_val, failing, warning, total_value, display_format, secondary_format, drill_down, probe_name, min_value, max_value, ack_count, airport_iata, airport_lat, airport_lng, airport_country, airport_city from (
			SELECT innerq.pop_id, innerq.pop_name,
					innerq.probe_id, innerq.service_name, ifnull(innerq.position,-2) `position`,
					innerq.up_count,

					case when innerq.ack_count > 0 then
						case when innerq.vip_count - innerq.up_count > 0 then
							case when innerq.ack_count - innerq.up_count = 0 then 0
							else innerq.vip_count - innerq.up_count - innerq.ack_count end
						else innerq.vip_count - innerq.up_count end
					else innerq.vip_count - innerq.up_count end `down_count`,

					case when innerq.vip_count > 0 then case when innerq.ack_count > 0 then (innerq.up_count+innerq.ack_count)/innerq.vip_count else innerq.up_count/innerq.vip_count end else 0 end * 100 `up_percent`,
					case when innerq.up_count > 0 then innerq.up_vals/innerq.up_count end `avg_val`,
					case when innerq.vip_count > 0 then case when innerq.ack_count > 0 then (innerq.up_count+innerq.ack_count)/innerq.vip_count else innerq.up_count/innerq.vip_count end else 0 end * 100 < innerq.failure_percent `failing`,
					case when innerq.vip_count > 0 then case when innerq.ack_count > 0 then (innerq.up_count+innerq.ack_count)/innerq.vip_count else innerq.up_count/innerq.vip_count end else 0 end * 100 < innerq.warning_percent `warning`,
					innerq.up_vals `total_value`, innerq.display_format, innerq.secondary_format, innerq.drill_down, innerq.probe_name, innerq.min_value, innerq.max_value, innerq.ack_count, innerq.airport_iata, innerq.airport_lat, innerq.airport_lng, innerq.airport_country, innerq.airport_city
					from (SELECT p.pop_id, p.name `pop_name`,
					min(svc.probe_id) `probe_id`,
					coalesce(dis.visual_name,svc.name) `service_name`,
					dis.display_format, dis.secondary_format,
					dis.priority, case when dis.probe_name = '%s' then -1 else dis.position end position, dis.warning_percent, dis.failure_percent, SUM(IF((m.val is null or m.val<0 or m.expired=1), 0, 1)) `up_count`, SUM(IF((m.val is null or m.val<0 or m.expired=1), 0, m.val)) `up_vals`, MIN(IF((m.val is null or m.val<0 or m.expired=1), 0, m.val)) `min_value`, MAX(IF((m.val is null or m.val<0 or m.expired=1), 0, m.val)) `max_value`, COUNT(distinct v.vip_id) `vip_count`, m.vip_id, svc.vip_probe_id, dis.drill_down, svc.name as probe_name,
					COUNT(DISTINCT(case when (ack.vip_probe_id and (m.val < 0 or m.expired = 1 or m.val is null)) then ack.vip_probe_id else null end)) as ack_count,
					air.airport_iata as airport_iata, air.airport_lat as airport_lat, air.airport_lng as airport_lng, air.airport_country as airport_country, air.airport_city as airport_city
					FROM rms_pop p left join rms_server s on (s.pop_id = p.pop_id) left join rms_vip v on (v.server_id = s.server_id)
					left join rms_vip_probe svc on (svc.vip_id = v.vip_id)
					join rms_display_probes dis on (dis.probe_name = svc.name and (dis.for_probe_name = '%s' or dis.probe_name='%s'))
					left join rms_message_expired_view m on (m.vip_id = v.vip_id and m.vip_probe_id = svc.vip_probe_id)
					left join (select distinct vip_probe_id from rms_acknowledge where end_date > NOW()) ack on (svc.vip_probe_id = ack.vip_probe_id)
					left join airport air on (SUBSTRING_INDEX(p.name, '-', -1) = air.airport_iata)
					group by p.pop_id, p.name, svc.name ) as innerq
					order by case when case when innerq.ack_count > 0 then innerq.up_count+innerq.ack_count/innerq.vip_count else innerq.up_count/innerq.vip_count end * 100 < innerq.failure_percent then 2 when case when innerq.ack_count > 0 then innerq.up_count+innerq.ack_count/innerq.vip_count else innerq.up_count/innerq.vip_count end * 100 < innerq.warning_percent then 1 else 0 end desc, innerq.priority asc, innerq.up_count/innerq.vip_count * 100 asc, innerq.vip_count desc, innerq.pop_name asc
		) as final
		where final.probe_id is not null
		order by final.ack_count desc, final.failing desc, final.warning desc;
		""" % (param_probe_name, param_probe_name, param_probe_name))
	except:
		pass
	rows = cursor.fetchall()
	return rows

# View for main_rms.html
@login_required
@is_authorized
def render_page(request, param_probe_name=''):

	def_account = getDefaultAccount(request)
	telco_user = isTelcoMember(request.user,def_account.account_no)
	rs_pops = get_customer_pops (customer = def_account, use_type=2)
    
	pop_names = ''
	if rs_pops != -1:
		pop_name = []
        pop_name = ['\'%s\''%rs.pop.ihms_pop.pop_code for rs in rs_pops]
        pop_names = ','.join(pop_name)	

	#pop_names = "'p0-cgk', 'p11-nrt', 'p0-bog', 'p0-eze'"
	rows = complex_query(param_probe_name, pop_names)

	class ProbeScore():
		def __init__(self, up_count, down_count, up_percent, avg_value, failing, warning, total_value, max_value, min_value, ack_count):
			self.up_count = up_count
			self.down_count = down_count
			self.up_percent = up_percent
			self.avg_value = avg_value
			self.total_value = total_value
			self.failing = failing
			self.warning = warning
			self.max_value = max_value
			self.min_value = min_value
			self.ack_count = ack_count

	class PoPInfo():
		def __init__(self, pop_id, pop_name, probe_id, avg_value, max_value, min_value):
			self.id = pop_id
			self.name = pop_name
			self.probe_id = probe_id
			self._probes = {}
			self.avg_val = avg_value
			self.max_val = max_value
			self.min_val = min_value
			self.failing = False
			self.warning = False

		def add_probe(self, probe_score, header):
			self._probes[header] = probe_score

		def get_probe(self, header):
			return self._probes.get(header)

		def add_pop_failing(self, failing):
			self.failing = failing

		def add_pop_warning(self, warning):
			self.warning = warning

	class Header():
		def __init__(self, name, probe_id, probe_name, display_format, tooltip_format, drill_down):
			self.name = name
			self.probe_id = probe_id
			self.probe_name = probe_name
			self.display_format = display_format
			self.tooltip_format = tooltip_format
			self.drill_down = drill_down

	rms_pl_to = RMSPacketLoss.objects.filter(probe_agent_vip__host__isnull=False).values('vip__pop__pop_id').annotate(avg_loss=Avg('loss'), max_loss=Max('loss'), min_loss=Min('loss'))

	pops = {}
	pops_ordered = []
	header = [None for i in range(0,33)]

	for row in rows:
		failing_pop = False
		warning_pop = False

		avg_loss=max_loss=min_loss=0
		pop = None
		if row[4] < -1:
			continue
		if not header[row[4]+1]:
			header[row[4]+1] = Header(row[3], row[2], row[15], row[12], row[13], row[14])
		pop = pops.get(row[0])
		if not pop:

			#one direction
			for pl in rms_pl_to:
				if pl['vip__pop__pop_id'] == row[0]:
					avg_loss = pl['avg_loss']
					max_loss = pl['max_loss']
					min_loss = pl['min_loss']
					break

			pop = PoPInfo(row[0], row[1], row[2], avg_loss, max_loss, min_loss)
			pops[row[0]] = pop
			pops_ordered.append(pop)

			if not failing_pop:
				if row[9]:
					failing_pop = True
			if not warning_pop:
				if row[10]:
					warning_pop = True

			pop.add_pop_failing(failing_pop)
			pop.add_pop_warning(warning_pop)

		pop.add_probe(ProbeScore(row[5],row[6],row[7],row[8],row[9],row[10], row[11], row[17], row[16], row[18]), row[3])

	try:
		probe_obj = RMSSettings.objects.get(base_probeconfig__name=param_probe_name)
	except:
		probe_obj = None

	context = RequestContext(request, {
				'screen_mode':request.session.get('big_screen', False),
				'headers':header,
				'pops_ordered':pops_ordered,
				'param_probe_name':param_probe_name,
				'rms_refresh_time':1,
				'probe_obj':probe_obj})
	return render_to_response('main.html', context)