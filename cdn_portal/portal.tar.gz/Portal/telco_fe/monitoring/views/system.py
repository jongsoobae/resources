# -*- coding: utf-8 -*-
"""
    Copyright (c) 2012 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Monitoring > Full System
"""
from datetime import datetime
from django import forms
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.core.exceptions import PermissionDenied, ValidationError, \
    ValidationError, ObjectDoesNotExist
from django.core.paginator import Paginator, EmptyPage, InvalidPage, \
    PageNotAnInteger
from django.core.urlresolvers import reverse
from django.db.models import Q
from django.forms.formsets import formset_factory
from django.http import HttpResponseRedirect, Http404, HttpResponse
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.utils import simplejson
from django.views.generic.edit import CreateView

from telco_fe import settings
from telco_fe.shared_components.decorators import menu_authority_required

def full_view(request):
    target_url = '/'
    context = RequestContext(request,{'iframe_src':target_url})
    return render_to_response('includes/iframe_base.html', context)