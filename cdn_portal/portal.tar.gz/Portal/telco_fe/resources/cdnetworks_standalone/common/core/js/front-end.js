/*
URL : -
Description : UI에 관련 전용
Author : 윤 태건
Email : tg0825@gmail.com
Created : 2012-07-19
*/

(function($){
	function gnbHover(){
		var myTime;
		$('.sub-gnb-layer').hide();
		$('.gnb menu>li>a').mouseenter(
			function(){
				clearTimeout(myTime);
				$(this).parent('li').siblings().find('.sub-gnb-layer').fadeOut(50);
				$(this).parent().find('.sub-gnb-layer').fadeIn(80);
		}).mouseout(
			function(){
				subGnbHide();
			});
		
		$('.gnb menu>li *').mouseover(
			function(){
				clearTimeout(myTime);
		});
		
		$('.sub-gnb-layer').mouseout(function(){
			subGnbHide();
		});
		
		$('.sub-gnb li:only-child a').css({'border-bottom':'0'});

		$('.sub-gnb li a').hover(
		function(){
			$(this).toggleClass('hover');
		});
	
		function subGnbHide(){
			myTime=setTimeout(function(){
				$('.sub-gnb-layer').fadeOut(50);
			},1000);
		}
	}
	
	function telcoGnb(){
		var data = menudata.data;
		var $menu = $('.gnb menu');
		var $depth1, $depth2, $li;
		for(var i=0;i<data.length;i++)
		{
			var depth = data[i].menu_depth;
			if(depth==1)
			{
				idx1 = i;
				$depth1 = $('<li><a href="'+data[i].link_url+'">'+data[i].menu_name+'</a></li>');
				$menu.append($depth1);
			}
			else if(depth==2)
			{
				idx2 = i;
				var $menu2 = $depth1.find('.sub-gnb');
				if($menu2.size() < 1)
				{
					var $m2 = $('<div class="sub-gnb-layer"><span class="arr"><span class="arr-2"></span></span><ul class="sub-gnb"></ul></div>');
					$depth1.append($m2);
					$menu2 = $m2.find('.sub-gnb');
				}

				$depth2 = $('<li><a href="'+data[i].link_url+'">'+data[i].menu_name+'</a></li>');
				$menu2.append($depth2);
			}
			else if(depth==3)
			{
				var $menu3 = $depth2.find('.sub-gnb-2');
				if($menu3.size() < 1)
				{
					$menu3 = $('<ul class="sub-gnb-2"></ul>');
					$depth2.append($menu3);
				}

				$depth3 = $('<li><a href="'+data[i].link_url+'">'+data[i].menu_name+'</a></li>');
				$menu3.append($depth3);
			}
		}
	}
	function bcar(){ // breadcrumbs arrow,
		var breadLi = $('.breadcrumb li');
		if(breadLi.is(':only-child')){
			breadLi.addClass('current'); //
		}else{
			breadLi.not(':last-child').append(' &gt;').parent().find('li:last-child').addClass('current');
		}
	}
	
	function conHeight(){ //  container min-height
		$('.container').css('min-height',$('.gnb-outer').height());
	}
	
	function selectOpen(){ // custom select toggle
		$('.slt-custom .selecting').live('click',function(){
			$(this).siblings('.item-list').toggle();
		});
		$('.slt-custom. .more').live('click',function(){
			$(this).siblings('.item-list').toggle();
		});
	}
	
	function acc(){ // accordion
		$('.dep2').add('.dep3').hide();
		var accor=$('.accordion');
		var accorSpan = accor.find('span');
		accorSpan.live('click',function(){
			accorSpan.removeClass('on');
			$(this).addClass('on');
			$(this).parent().find('ul').toggle();
		});
	}
	
	function calendar(){ // calendar
		$( "#from" ).datepicker({
			defaultDate: "+1w",
			changeMonth: true,
			numberOfMonths: 1,
			onSelect: function( selectedDate ) {
				$( "#to" ).datepicker( "option", "minDate", selectedDate );
			}
		});
		$( "#to" ).datepicker({
			defaultDate: "+1w",
			changeMonth: true,
			numberOfMonths: 1,
			onSelect: function( selectedDate ) {
				$( "#from" ).datepicker( "option", "maxDate", selectedDate );
			}
		});
	}
	
	function nav(){ // navigation
		var speed = 110;
		$('.product-gnb > li').live('click',function(){
			if($(this).find('.product-gnb2').is('.on')){
				$('.product-gnb2').removeClass('on').slideUp(speed);
			}else{
				$('.product-gnb2').removeClass('on').slideUp(speed).add(this).find('.product-gnb2').addClass('on').slideDown(speed);
			}
		});
		$('.sub-gnb li a').live('click',function(){
			$('.sub-gnb li a').removeClass('active');
			$(this).addClass('active');
		});

		var focus = menudata.focus;
		var $contentNav = $('.breadcrumb');
		$contentNav.children().remove();
		for(var menu=1; menu<=2; menu++){
		var $menu = $('#menu'+menu);
		var $depth1, $depth2, $li;
		var idx1, idx2;
		var data = menu==1?menudata.data:menudata.static_data;
		var cls = menu==1?'product':'sub';
		for(var i=0;i<data.length;i++)
		{
			var depth = data[i].menu_depth;
			if(depth==1)
			{
				idx1 = i;
				$depth1 = $('<li><span>'+data[i].menu_name+'</span></li>');
				$menu.append($depth1);
			}
			else if(depth==2)
			{
				idx2 = i;
				var $menu2 = $depth1.find('.'+cls+'-gnb2');
				if($menu2.size() < 1)
				{
					$menu2 = $('<menu class="'+cls+'-gnb2"></menu>');
					$depth1.append($menu2);
				}

				if(data[i].link_url == null)
					$depth2 = $('<li><span>'+data[i].menu_name+'</span></li>');
				else
					$depth2 = $('<li><a href="'+data[i].link_url+'">'+data[i].menu_name+'</a></li>');
				$menu2.append($depth2);
				
				if(focus == data[i].menu_id)
				{
					$depth1.find('span:first').addClass('active');
					$depth2.find('a').addClass('active');
					$menu2.addClass('on').show();
					addContentNav(data[idx1]);
					addContentNav(data[idx2]);
				}
			}
			else if(depth==3)
			{
				var $menu3 = $depth2.find('.'+cls+'-gnb3');
				if($menu3.size() < 1)
				{
					$menu3 = $('<menu class="'+cls+'-gnb3"></menu>');
					$depth2.append($menu3);
				}

				$depth3 = $('<li><a href="'+data[i].link_url+'">'+data[i].menu_name+'</a></li>');
				$menu3.append($depth3);

				if(focus == data[i].menu_id)
				{
					$depth1.find('span:first').addClass('active');
					$depth2.find('span:first').addClass('active');
					$depth3.find('a').addClass('active');
					$menu2.addClass('on').show();
					$menu3.addClass('on').show();
					addContentNav(data[idx1]);
					addContentNav(data[idx2]);
					addContentNav(data[i]);
				}
			}
		}
		$menu.find('li .product-gnb2').hide();
		$('.on').show();
		}
	}

	function addContentNav(data)
	{
		var $contentNav = $('.breadcrumb');
		if($contentNav.children().size() < 1)
			$contentNav.append($('<li><a href="message-board.html">Home</a></li>'));
		$contentNav.append($('<li><span>'+data.menu_name+'</span></li>'));
	}

	function mdlswitch(){ // modal switch
		$('.modalswitch').live('click',function(){
				if($('.mdl-offset').css("display")=="block"){
					$('.mdl-offset').fadeOut('fast');
				}else{
					$('.mdl-offset').fadeIn('fast');
					var position = $('.mdl').height()/1.5;
					$('.mdl').css({'margin-top':-position});
				}
		});
	}
	
	function tooltipTag(){ // tooltip
		var html =	'<span class="">';
		html +=		'<span class="arr">';
		html += 			'<span class="arr-inner"></span>';
		html +=		'</span>';
		html +=		'<p><span class="ic ic-excal2"></span>';
		html +=		'error-messageerror-message'; //error message
		html +=		'</p>';
		html +=	'</span>';
		return html;
	}
	
	function tabs(){ // tabs, tab-content
		$('.tab-btns li button').live('click',function(){
			var tabIndex = $(this).parent().index();
			var self = $(this);
			var Li = self.parent('li');
			Li.siblings().removeClass('on').parents('.tab').find('.tab-contents .tab-content').hide();
			$(this).parent('li').addClass('on').parents('.tab').find('.tab-contents .tab-content:eq('+tabIndex+')').show();
		});
		$('.tab-contents .tab-content').not(':first-child').hide(); //첫번째 탭 켜기
	}
	
	function tableOver(){
		$('.table table tbody tr:odd td, .table table tbody tr:odd th').addClass('oddbg');
		$('.table table tr').hover(
			function(){
				$(this).addClass('hover');
			},
			function(){
				$(this).removeClass('hover');
			}
		);
	}
	
	function treeSwitch(){ // tree switch
		if($('.tree').find('ul').css('display')=='block'){
			$('.tree').find('.toggle-btn').removeClass('plus');
		}
		$('.toggle-btn').live('click',function(){
			if($(this).closest('li').children('ul').css('display')=='none'){
				$(this).removeClass('plus');
				$(this).closest('li').children('ul').show();
			}else{
				$(this).addClass('plus');
				$(this).closest('li').children('ul').hide();
			}
		});
		$('.item-text').hover(
			function(){
				$(this).addClass('hover');
			},
			function(){
				$(this).removeClass('hover');
			}
		);
		$('.tree-check').live('click',function(){
			var $item = $('.item-text');
			if($(this).is(':checked')){
				$li = $(this).siblings($item).closest('li'); 
				$li.find('.tree-check').attr('checked','checked');
				$(this).parents('li').children('.item').children('.tree-check').attr('checked','checked');
			}else{
				$li = $(this).siblings($item).closest('li')
				$li.find('.tree-check').removeAttr('checked');
				
				if($(this).closest('ul').find('.tree-check').is(':checked')==false){
					$(this).parents('li').find('.tree-check').removeAttr('checked');
				}
			}
		});
	}
	
	function selectTooltip(){ //select tooltip
		var selector = $(this);
	 	selector.attr('title',selector.val());
	}
	
	function createMenuItem (data){ // tree
		var $item = $('<li><span class="item"><input type="checkbox" class="tree-check"><span class="item-text">'+data.privilege_name+'</span></span></li>');
		if(data.is_checked)
		{
			$item.find(':checkbox').attr('checked', true);
			$item.find('.item-text').addClass('active');
		}
		$item.data('privilege_id', data.privilege_id);
		$item.data('child', false);
		return $item;
	}
	
	function chartTooltip(){
		var $cell = $('.item-body .table table td');
		$cell.hover(
			function(){
					$self = $(this);
					var textLength = $self.text().length;
					var textW = textLength*8;
					var cellW = $self.width();
					if(textW>=cellW){
						var cellText = $(this).text();
						var positionL = $(this).offset().left;
						var positionT = $(this).offset().top;
						var w = $self.outerWidth()/2;
						$('body').before('<div class="chartTooltip">'+cellText+'</div>');
						$('.chartTooltip').css({'top':positionT,'left':positionL+w});
						var tooltipW = $('.chartTooltip').outerWidth()/2; 
						$('.chartTooltip').css({'margin-left':-tooltipW});
					}
			},
			function(){
			$('.chartTooltip').fadeOut('fast',function(){
				$(this).remove();
			});
		});
	}
	
	// load 후에 실행 되는 함수들. 함수명 검색
	$(document).ready(function(){
		telcoGnb(); // gnb
		gnbHover(); // gnb hover action 
		tableOver(); // table hover bg 
		nav(); // navigation
		bcar(); // breadcrumbs arrow 
		selectOpen(); // custom select toggle
		acc(); // accordion
		conHeight(); // container min height
		calendar(); // calendar 
		//mdlswitch(); //modalswitch
		tabs(); // tab, tab content
		treeSwitch(); // tree switch
		chartTooltip(); // chartTooltip
		//$('.slt select').mouseover(selectTooltip); // select checker
		$('.modalfilter').overlay({ //modal overlay
			  mask: {
			   color: '#000',
			   loadSpeed: 200,
			   opacity: 0.3
			  },
			  fixed:false,
			  top: '10%',
			  closeOnClick: true,
			  closeOnEsc: true
		})
		
		
		$container = $('.tree-dep1'); // json tree
		$container.empty(); // json tree
			for(var i = 0; i < treeData.length; i++){
				var depth = treeData[i].privilege_depth;
				if(depth == 1)
				{
					var $item = createMenuItem(treeData[i]);
					$container.append($item);
				}
				else
				{
					$container.find('li').each(function(){
						if($(this).data('privilege_id') == treeData[i].parent_privilege_id)
						{
							var $item = createMenuItem(treeData[i]);
							if($(this).data('child'))
							{
								$(this).find('ul:first').append($item);
							}
							else
							{
								$(this).append($('<ul></ul>').append($item));
								$(this).find('.item:first').prepend('<button type="button" class="toggle-btn"></button>');
								$(this).data('child', true);
							}
							return false;
							
						}
					});
				}
			}
	});
})(jQuery);

