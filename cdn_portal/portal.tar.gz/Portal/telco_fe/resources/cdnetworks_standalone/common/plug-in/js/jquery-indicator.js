(function($){
    var mask = '<div class="loadmask"><div class="indicator indicator_roller"></div></div>';
    $.fn.mask = function(msg) {
        $.maskElement($(this), msg);
    };

    $.fn.unmask = function() {
        $(this).each(function() {
            $.unmaskElement($(this));
        });
    };

    $.fn.is_masked = function() {
        return this.hasClass('masked');
    };

    $.maskElement = function(element, msg){
        if(element.is_masked()) {
            $.unmaskElement(element);
        }
        element.append(mask);
    };

    $.unmaskElement = function(element){
        element.find(".loadmask").remove();
    };
})(jQuery);