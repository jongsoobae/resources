$(function() {
    $.support.placeholder = (function(){
        var i = document.createElement('input');
        return 'placeholder' in i;
    })();

    if(!$.support.placeholder) {
        var active = document.activeElement;
        $(':text,:password').focus(function () {
            if ($(this).attr('placeholder') != '' && $(this).val() == $(this).attr('placeholder')) {
                $(this).val('').removeClass('hasPlaceholder');
            }
        }).blur(function () {
            if ($(this).attr('placeholder') != '' && ($(this).val() == '' || $(this).val() == $(this).attr('placeholder'))) {
                $(this).val($(this).attr('placeholder')).addClass('placeholder');
            }
        });
        $(':text,:password').blur();
        $(active).focus();
        $('form').submit(function () {
            $(this).find('.placeholder').each(function() { $(this).val(''); });
        });
    }
});