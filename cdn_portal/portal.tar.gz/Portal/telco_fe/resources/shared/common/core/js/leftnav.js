$(function(){

	//expand selected menu on page load
	$('.active').next().show('fast', function(){
		if(!$(this).hasClass('rotated')){
			$('.active > img').rotateRight();
			$('.active > img').css('vertical-align', 'middle');
			$(this).addClass('rotated');
		}
	});
	
	$('.parent-menu').click(function(){
		
		img = $(this).children().eq(0);
		
		if (!$(this).next().hasClass('rotated')) {
			$(this).next().show('fast');
			img.rotateRight();
			img.css('vertical-align', 'middle');
			$(this).next().addClass('rotated');
		} else {
			$(this).next().hide('fast');
			img.rotateLeft();
			img.css('vertical-align', 'middle');
			$(this).next().removeClass('rotated');
		}
	});
});

function set_size(){
	html_height = $(document).height() - ($('#header-top').height() + $('#logo-image').height());
	
	set_height = html_height;
	
	$('#leftnav-wrapper').css('height', set_height);
}
set_size();

if (!$.browser.msie) {
	window.onresize = function(){
		set_size();
	}
}