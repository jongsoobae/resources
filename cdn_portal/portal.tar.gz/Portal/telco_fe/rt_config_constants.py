from django.utils.translation import ugettext as _
from telco_fe.config_constants import OCSP_PROD_HANDLER
if not OCSP_PROD_HANDLER:
    RT_QUEUE = (
        (83, 'Telco Portal'),
    )
    RT_QUEUE_EMAIL = {
                      'Telco Portal' : "telco-support@cdnetworks.com"
                      }
else:
    RT_QUEUE = (
        (84, 'Telco :: Megafon :: Incoming'),
    )
    RT_QUEUE_EMAIL = {
                      'Telco Portal' : "megafon-support@cdnetworks.com"
                      }

RT_OPEN_STATUS = (
    'new',
    'open',
    'ActionCust',
    'ActionSD',
    'ActionINF',
    'ActionEng',
    'ActionAM',
    'ActionSE',
    'FutureCSC',
    'WorkingCSC',
    'CusCommReq',
    'PenConfirm',
    'ActionRFO',
    'WorkingSD'
)
RT_CLOSED_STATUS = (
    'resolved',
)

SUPPORT_TYPE = (
    ('1', 'General Support'),
    ('2', 'New Pop Request'),
    ('3', 'New Server Added'),
    ('4', 'Existing Server'),
)
