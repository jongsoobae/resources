# Django settings for telco_fe project.
import os
import config_db_constants
import config_constants
from config_constants import  CACHE_BACKEND, CACHE_LOCATIONS
import sys
from telco_fe import __version__
from telco_fe.config_constants import OCSP_PROD_HANDLER
ROOT = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, os.path.dirname(ROOT))

DEBUG = config_constants.DEBUG
TEMPLATE_DEBUG = DEBUG

PROJECT_NAME = 'telco_fe'
PROJECT_LOCATION = ROOT + '/'
SPECTRUM_LOCATION = os.path.dirname(ROOT) + '/spectrum_fe/'
SPECTRUM_NAME = 'spectrum_fe'
VERSION_NUMBER = __version__
IS_PRODUCTION = config_constants.OCSP_PROD_HANDLER

DNA_MATERIAL = 1197
DNS_MATERIAL = 1182
CS_MATERIAL = 1028
CLOUD_STORAGE_MATERIAL = 1014
DNS_D_MATERIAL = 1284

HOST_KR = 'pal.kr.cdnetworks.com'
HOST_US = 'pal.us.cdnetworks.com'
HOST_JP = 'pal.jp.cdnetworks.com'
HOST_CN = 'pal.cn.cdnetworks.com'

OUI_MD5_SALT = 'telcointerface@ouiadmin'

IS_AD_BINDING = config_constants.IS_AD_BINDING
if not config_constants.OCSP_PROD_HANDLER:
	CONFIG_SVN_SERVER = "https://svn.cdngp.net/svn"
	CONFIG_SVN_USER = "config"
	CONFIG_SVN_PASS = "config"
	OCSP_HOST_PREFIX = 'https://jericho.'
	CONTROL_HOST_PREFIX = 'http://controldev'
	TELCO_HOST_PREFIX = 'http://telco-dev'	
	AURORA_URL = "http://controldev.cdnetworks.com"	
	TELCO_URL = "http://telco-dev.cdnetworks.com"   
	SAPYML_LOCATION = '/usr/local/cdnet/spectrum/prism/spectrum_fe/sap_dev.yml'
	IS_TEST_USER_MAIL = True
	TEST_MAIL_ACCOUNT = ['byoungin.lim@cdnetworks.com', 'wonho.choi@cdnetworks.co.kr', 'injune.hwang@cdnetworks.com']	
	OCSPKR_SERVER = 'https://ocspdev.kr.cdnetworks.com'
	OCSPUS_SERVER = 'https://ocspdev.us.cdnetworks.com'
	OCSPJP_SERVER = 'https://ocspdev.jp.cdnetworks.com'
	OCSPCN_SERVER = 'https://ocspdev.txnetworks.cn'   
	SAPYML_LOCATION = '/usr/local/cdnet/spectrum/prism/spectrum_fe/sap_dev.yml'
	OCSP_USER_API_URI = '/rest/user/prism/update/'
	OCSP_USER_API_USER = 'test_cop_to_ocsp@cdnetworks.com'
	OCSP_USER_API_PASS = 'test_cdn3twork5' 	
	
	if IS_AD_BINDING:
		CUSTOMER_LDAP_SERVER = 'customerad.cdnetworks.cu'#'10.40.203.37'
		CUSTOMER_LDAP_PORT = 636
		CUSTOMER_LDAP_BASE_USER = "administrator@cdnetworks.cu"
		CUSTOMER_LDAP_BASE_PASS = "infra#@1" 
		CUSTOMER_LDAP_BASE = "ou=cdn_sso,dc=cdnetworks,dc=cu"
		CUSTOMER_LDAP_BINDDN = "administrator@cdnetworks.cu"
		CUSTOMER_LDAP_URL = 'ldaps://%s:%s' % (CUSTOMER_LDAP_SERVER,CUSTOMER_LDAP_PORT)  
		CUSTOMER_USER_CLASS = "cdnUser"  
	else:
		CUSTOMER_LDAP_SERVER = 'testldap.cdnetworks.com'	
		CUSTOMER_LDAP_PORT = 636
		CUSTOMER_LDAP_BASE_USER = "cn=cdn_sso,ou=admingroup,dc=cdnetworks,dc=co,dc=kr"
		CUSTOMER_LDAP_BASE_PASS = "cdnadmin"
		CUSTOMER_LDAP_BASE = "ou=cdn_sso,dc=cdnetworks,dc=co,dc=kr"
		CUSTOMER_LDAP_BINDDN = "cn=cdn_sso,ou=admingroup,dc=cdnetworks,dc=co,dc=kr"
		CUSTOMER_LDAP_URL = 'ldap://%s:%s' % (CUSTOMER_LDAP_SERVER,CUSTOMER_LDAP_PORT)
		CUSTOMER_USER_CLASS = "cdnPerson"	

	AUTH_CROWD_STAFF_GROUP = 'staff'
	AUTH_CROWD_SUPERUSER_GROUP = 'superuser'
	AUTH_CROWD_APPLICATION_USER = 'aurora-ad'
	AUTH_CROWD_APPLICATION_PASSWORD = 'cdnadmin'
	AUTH_CROWD_SERVER_URI = 'http://testjira.cdnetworks.com:8095/crowd/'  	
else:
	CONFIG_SVN_SERVER = "http://10.40.198.206:5555/svn"
	CONFIG_SVN_USER = "config"
	CONFIG_SVN_PASS = "config"
	OCSP_HOST_PREFIX = 'https://ocsp.'
	CONTROL_HOST_PREFIX = 'https://control'	
	TELCO_HOST_PREFIX = 'https://partner'	
	AURORA_URL = "https://control.cdnetworks.com"
	TELCO_URL = "https://partner.cdnetworks.com"	
	SAPYML_LOCATION = '/usr/local/cdnet/spectrum/prism/spectrum_fe/sap.yml'
	IS_TEST_USER_MAIL = False
	TEST_MAIL_ACCOUNT = ['eng-ui@cdnetworks.com']	
	OCSPKR_SERVER = 'https://ocsp.kr.cdnetworks.com'
	OCSPUS_SERVER = 'https://ocsp.us.cdnetworks.com'
	OCSPJP_SERVER = 'https://ocsp.jp.cdnetworks.com'
	OCSPCN_SERVER = 'https://ocsp.txnetworks.cn'
	SAPYML_LOCATION = '/usr/local/cdnet/spectrum/prism/spectrum_fe/sap.yml'
	OCSP_USER_API_URI = '/rest/user/prism/update/'
	OCSP_USER_API_USER = 'cop_to_ocsp@cdnetworks.com'
	OCSP_USER_API_PASS = 'cdn3twork5' 
	
	if IS_AD_BINDING:
		CUSTOMER_LDAP_SERVER = 'customerad.cdnetworks.com'
		CUSTOMER_LDAP_PORT = 636
		CUSTOMER_LDAP_BASE_USER = "made_in_dlsvmfk@customerad.cdnetworks.com"
		CUSTOMER_LDAP_BASE_PASS = "@Windowsrntahsld123" 
		CUSTOMER_LDAP_BASE = "ou=cdn_sso,dc=customerad,dc=cdnetworks,dc=com"
		CUSTOMER_LDAP_BINDDN = "made_in_dlsvmfk@customerad.cdnetworks.com"
		CUSTOMER_LDAP_URL = 'ldaps://%s:%s' % (CUSTOMER_LDAP_SERVER,CUSTOMER_LDAP_PORT) 
		CUSTOMER_USER_CLASS = "cdnUser" 
	else:
		CUSTOMER_LDAP_SERVER = 'customerldap.cdnetworks.com'
		CUSTOMER_LDAP_PORT = 636
		CUSTOMER_LDAP_BASE_USER = "cn=cdn_sso,ou=admingroup,dc=cdnetworks,dc=co,dc=kr"
		CUSTOMER_LDAP_BASE_PASS = "cdnadmin"
		CUSTOMER_LDAP_BASE = "ou=cdn_sso,dc=cdnetworks,dc=co,dc=kr"
		CUSTOMER_LDAP_BINDDN = "cn=cdn_sso,ou=admingroup,dc=cdnetworks,dc=co,dc=kr"
		CUSTOMER_LDAP_URL = 'ldap://%s:%s' % (CUSTOMER_LDAP_SERVER,CUSTOMER_LDAP_PORT)	
		CUSTOMER_USER_CLASS = "cdnPerson"	
	
	AUTH_CROWD_STAFF_GROUP = 'staff'
	AUTH_CROWD_SUPERUSER_GROUP = 'superuser'
	AUTH_CROWD_APPLICATION_USER = 'aurora-ad'
	AUTH_CROWD_APPLICATION_PASSWORD = 'cdnadmin'
	AUTH_CROWD_SERVER_URI = 'http://sso.cdnetworks.com:8095/crowd/'  	

# LDAP
LDAP_TIMEOUT = 5 # seconds
LDAP_PAGE_SIZE = 500

OCSPUS_USER_SYNCH_ENABLED = config_constants.OCSPUS_USER_SYNCH_ENABLED
OCSPKR_USER_SYNCH_ENABLED = config_constants.OCSPKR_USER_SYNCH_ENABLED
OCSPJP_USER_SYNCH_ENABLED = config_constants.OCSPJP_USER_SYNCH_ENABLED
OCSPCN_USER_SYNCH_ENABLED = config_constants.OCSPCN_USER_SYNCH_ENABLED
SAP_USER_SYNCH_ENABLED = config_constants.SAP_USER_SYNCH_ENABLED  #this is for aurora beta server not updating user info into SAP
if os.name == 'nt':
	SAPYML_LOCATION = os.path.dirname(ROOT) +'\\spectrum_fe\\sap_dev.yml'

CUI_HOST_PREFIX = 'https://pantherportal.us.cdnetworks.com'
OUITELCO_HOST_PREFIX = config_constants.OUITELCO_HOST
	

ADMINS = config_constants.ADMINS
EMAIL_ALERTS = config_constants.EMAIL_ALERTS

MANAGERS = ADMINS

DATABASES = {
	'default': config_db_constants.DEFAULT
}

DATABASE_ROUTERS = ["spectrum_fe.shared_components.database_routers.SpectrumRouter"]

# Local time zone for this installation. Choices can be found here:
# http://en.wikipedia.org/wiki/List_of_tz_zones_by_name
# although not all choices may be available on all operating systems.
# On Unix systems, a value of None will cause Django to use the same
# timezone as the operating system.
# If running in a Windows environment this must be set to the same as your
# system time zone.
TIME_ZONE = None

# Language code for this installation. All choices can be found here:
# http://www.i18nguy.com/unicode/language-identifiers.html
LANGUAGE_CODE = 'en-us'

SITE_ID = 1

# If you set this to False, Django will make some optimizations so as not
# to load the internationalization machinery.
USE_I18N = True

_ = lambda s:s
LANGUAGES = (
	('ko_kr', _('Korean')),
	('en_us', _('English')),
)

LOCALE_PATHS = (
	PROJECT_LOCATION+'locale/',
	SPECTRUM_LOCATION+'locale/',
)

# If you set this to False, Django will not format dates, numbers and
# calendars according to the current locale
USE_L10N = True

# Absolute path to the directory that holds media.
# Example: "/home/media/media.lawrence.com/"
MEDIA_ROOT = PROJECT_LOCATION+'resources/'
SPECTRUM_MEDIA_ROOT = SPECTRUM_LOCATION+'resources/'

# URL that handles the media served from MEDIA_ROOT. Make sure to use a
# trailing slash if there is a path component (optional in other cases).
# Examples: "http://media.lawrence.com", "http://example.com/media/"
MEDIA_URL = '/op_media/'

# URL prefix for admin media -- CSS, JavaScript and images. Make sure to use a
# trailing slash.
# Examples: "http://foo.com/media/", "/media/".
ADMIN_MEDIA_PREFIX = '/media/'

# Make this unique, and don't share it with anybody.
SECRET_KEY = 'vej5_kp@r8vk4foju6jmi5zftpi8!hl$hi$kml-$g96hk5xe)t'

PASSWORD_HASHERS = (
    'spectrum_fe.shared_components.utils.hashers.PBKDF2PasswordHasher',
    'spectrum_fe.shared_components.utils.hashers.PBKDF2SHA1PasswordHasher',
    'spectrum_fe.shared_components.utils.hashers.BCryptPasswordHasher',
    'spectrum_fe.shared_components.utils.hashers.SHA1PasswordHasher',
    'spectrum_fe.shared_components.utils.hashers.MD5PasswordHasher',
    'spectrum_fe.shared_components.utils.hashers.CryptPasswordHasher',
)

# List of callables that know how to import templates from various sources.
TEMPLATE_LOADERS = (
	'django.template.loaders.filesystem.Loader',
	'django.template.loaders.app_directories.Loader',
#	 'django.template.loaders.eggs.Loader',
)

MIDDLEWARE_CLASSES = (
	'django.middleware.common.CommonMiddleware',
	'django.contrib.sessions.middleware.SessionMiddleware',
	'django.contrib.auth.middleware.AuthenticationMiddleware',
#	'django.middleware.csrf.CsrfViewMiddleware',
#	'django.middleware.csrf.CsrfResponseMiddleware',
#	PROJECT_NAME+'.shared_components.middleware.ocsplogin.AcceptOCSPCookie',
#	PROJECT_NAME+'.shared_components.middleware.fakelogin.FakeLogin',
	'django.middleware.locale.LocaleMiddleware',
#	PROJECT_NAME+'.shared_components.middleware.set_lang.SetLang',
	PROJECT_NAME+'.shared_components.middleware.http.Http403Middleware',
	PROJECT_NAME+'.crowd.middleware.CrowdSSOAuthenticationMiddleware',	
)

ROOT_URLCONF = PROJECT_NAME+'.urls'


TEMPLATE_CONTEXT_PROCESSORS = (
	'django.core.context_processors.i18n',
	'django.core.context_processors.auth',
	PROJECT_NAME+'.shared_components.context_processors.set_user_menu',
	PROJECT_NAME+'.shared_components.context_processors.set_white_label',
	PROJECT_NAME+'.shared_components.context_processors.set_entity',
	PROJECT_NAME+'.shared_components.context_processors.login_state',
	#PROJECT_NAME+'.shared_components.context_processors.set_standalone_site',
	PROJECT_NAME+'.shared_components.context_processors.set_project_name',
	PROJECT_NAME+'.shared_components.context_processors.set_proxy',
	PROJECT_NAME+'.shared_components.context_processors.set_host_url',
	PROJECT_NAME+'.shared_components.context_processors.get_customer_region',
	PROJECT_NAME+'.shared_components.context_processors.get_customer_language',
	PROJECT_NAME+'.shared_components.context_processors.get_version',
	PROJECT_NAME+'.shared_components.context_processors.get_reseller_footer',
	PROJECT_NAME+'.shared_components.context_processors.set_user_login_url',
	PROJECT_NAME+'.shared_components.context_processors.get_telco_gnb',
	PROJECT_NAME+'.shared_components.context_processors.get_super_account_list',
	PROJECT_NAME+'.shared_components.context_processors.get_super_account',	
)


TEMPLATE_DIRS = (
	# Put strings here, like "/home/html/django_templates" or "C:/www/django/templates".
	# Always use forward slashes, even on Windows.
	# Don't forget to use absolute paths, not relative paths.
	os.path.join(os.path.dirname(__file__), 'templates').replace('\\', '/'),
	PROJECT_LOCATION+'/configuration//templates',
	PROJECT_LOCATION+'/manage/templates',	
	PROJECT_LOCATION+'/monitoring/templates',		
	PROJECT_LOCATION+'/shared_components/templates',
	PROJECT_LOCATION+'/support/templates',
	SPECTRUM_LOCATION+'/rt/templates',
)

INSTALLED_APPS = (
	PROJECT_NAME, # this is required for translation 
	SPECTRUM_NAME, # this is required for translation 
	'django.contrib.auth',
	'django.contrib.sessions',
	'django.contrib.contenttypes',			
	PROJECT_NAME+'.support',
	PROJECT_NAME+'.shared_components',
	PROJECT_NAME+'.manage',
	SPECTRUM_NAME+'.shared_components',
)

PROXY_ALLOWED_PATHS = (
	r'sap/',
	r'dns/',
	r'op_media/',
	r'i18n/',
	r'jsi18n/',
)

AUTH_PROFILE_MODULE = 'shared_components.userprofile'

LOGIN_NOT_REQUIRED = (
	r'^rt_support',
)

SESSION_EXPIRE_AT_BROWSER_CLOSE = True

EMAIL_HOST = 'send.mx.cdnetworks.com'
EMAIL_PORT = 25
#EMAIL_HOST_USER = 'portaladmin'
#EMAIL_HOST_PASSWORD = 'PRiSM$)*'
SERVER_EMAIL = 'portaladmin@cdnetworks.com'
DEFAULT_FROM_EMAIL = 'portaladmin@cdnetworks.com'
#EMAIL_USE_TLS = True
EMAIL_SUBJECT_PREFIX = '['+PROJECT_NAME+'] '

"""
AUTHENTICATION_BACKENDS = (
	PROJECT_NAME+'.shared_components.backends.ocsp.EncryptedAuthBackend',
)
"""


AUTHENTICATION_BACKENDS = (
	#PROJECT_NAME+'.shared_components.backends.ocsp.EncryptedAuthBackend',
	#PROJECT_NAME+'.shared_components.backends.ocspauth.LoginAuth',
	PROJECT_NAME+'.crowd.backend.CrowdBackend',
)

USER_LOGIN_LABEL = "STANDALONE"

LOGIN_URL = '/accounts/login/'

#if server configuration is production, this value must set False
if OCSP_PROD_HANDLER:
    IS_DEV_CONF = False
    OCSP_API_URL = "https://ocsp.us.cdnetworks.com"
    OCSP_API_USER = "cop_to_ocsp@cdnetworks.com"
    OCSP_API_PWD = "cdn3twork5"
    REDIS_SENTINEL_LOCATIONS =  [
                "mymaster://api1.p59-icn.cdngp.net:26379",
                "mymaster://api2.p59-icn.cdngp.net:26379",
                "mymaster://ui2.p59-icn.cdngp.net:26379",
            ]
else:
    IS_DEV_CONF = True
    OCSP_API_URL = "https://jericho.kr.cdnetworks.com"
    OCSP_API_USER = "cop_to_ocsp@cdnetworks.com"
    OCSP_API_PWD = "cdn3twork5"
    REDIS_SENTINEL_LOCATIONS =  [
                "mymaster://127.0.0.1:26379",
                "mymaster://127.0.0.1:26379",
            ]

REDIS_CACHE_BACKEND = "spectrum_fe.shared_components.django_redis.cache.RedisCache"
REDIS_SENTINEL_OPTIONS = {
    "CLIENT_CLASS": "spectrum_fe.shared_components.utils.sentinel.SentinelClient"
}

CACHES = {
    'default': {
        'BACKEND': CACHE_BACKEND,
        'LOCATION': CACHE_LOCATIONS,
    },
    'redis': {
        'BACKEND': REDIS_CACHE_BACKEND,
        'LOCATION': REDIS_SENTINEL_LOCATIONS,
        'OPTIONS': REDIS_SENTINEL_OPTIONS,
    }
}

PUSH_RATE_REDIS_CACHE_TTL = 60 * 60 * 24 #seconds
PUSH_RATE_THRESHOLD_COUNT = 60
PUSH_RATE_THRESHOLD_UNIT = 60 #minutes
REDIS_DEFAULT_TIMEOUT = 60

DEFAULT_THROTTLE_RATES = {
}