from django.contrib.auth.models import User
from django.contrib.auth import login

class LoginAuth(object):
    """
    Authenticates against an encrypted key file
    """
    def authenticate(self, username = None, password = None):
        try:
            user = User.objects.get(username = username, password=password, is_active = True)        
            return user
        except User.DoesNotExist, e:
            return None
            
        """
        try:
            profile = user.get_profile()
            print profile
        except:
            profile = None
        """    
#        if not profile:
#            try:
#                customer = CustomerDisplay.objects.get(account='1',ocsp_region=corporationTextToCode('US'))
#            except:
#                customer = None
#            
#        if not profile or created:
#                if customer:
#                    profile, created_profile = UserProfile.objects.get_or_create(user=user, defaults={'customer':customer})
        return user
              
    def get_user(self, user_id):
        try:
            return User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return None
