from telco_fe import settings, white_label
#from telco_fe.settings import NOT_STANDALONE_URL
from telco_fe.shared_components.utils import get_customer
from telco_fe.shared_components.utils.common import isStandAloneUrl, \
	getSafeSessionValue

from telco_fe.shared_components.utils.telco_user_helper import get_user_menu

from django.utils import simplejson
from django.utils.translation import ugettext as _
from django.contrib.auth.decorators import login_required
from spectrum_fe.shared_components.utils.api import getOptionalParams
from spectrum_fe.shared_components.models.customer import CustomerAccount


def set_project_name(request):
	return {"project_name": _('Partner Portal')}

#def set_entity(request):
#	return {"entity": "cdnetworks"}

def set_user_login_url(request):
	return {'user_login_url': getSafeSessionValue(request, 'user_login_url'), 'aurora_user_login_label': settings.USER_LOGIN_LABEL}
	
			
def set_user_menu(request):
	try :
		try :
			menu_id = request.session["menu_id"]
		except :
			menu_id = -1
			
		return {'menu_id': menu_id, 'menu_list': simplejson.dumps({'focus':menu_id,'data':request.session["data"],'static_data':request.session["static_data"]})}
	except :
		return ""
	
def set_white_label(request):
	hostname = request.META['HTTP_HOST']
	pos = hostname.find(":")
	
	if pos > 0:
		hostname = hostname[:pos]
	
	for i in white_label.WHITE_LABEL_MAPPER :	
		if i.get('domain_name') == hostname :
			return {'whitelabel_css': i.get('css'), 'whitelable_logo': i.get('logo'), 'whitelable_general_info': i.get('general_info'), \
				'whitelable_support_info': i.get('support_info'), 'whitelable_copyright': i.get('copyright').decode('latin1','replace'), 'whitelable_footer': i.get('footer')}
			
	for i in white_label.WHITE_LABEL_MAPPER :
		if i.get('default') == 1 :		
			return {'whitelabel_css': i.get('css'), 'whitelable_logo': i.get('logo'), 'whitelable_general_info': i.get('general_info'), \
				'whitelable_support_info': i.get('support_info'), 'whitelable_copyright': i.get('copyright').decode('latin1','replace'), 'whitelable_footer': i.get('footer')}
			
	return {'whitelabel_css': '', 'whitelable_logo': '', 'whitelable_general_info': '', 'whitelable_support_info': '', 'whitelable_copyright': '', 'whitelable_footer': ''}	
	
	
def set_entity(request):
	if white_label.WHITE_LABEL != None and white_label.WHITE_LABEL != '' and True == isStandAloneUrl(request.path):
		return {"entity": white_label.WHITE_LABEL}
	else:
		return {"entity": "cdnetworks"}

def login_state(request):
	login_label = None
	if request.user.is_authenticated():
		login_label = _('Logout')
		login_msg= 'logout'
		user_email = request.user.username
		user_ip = request.META.get('REMOTE_ADDR')
	else:
		login_label = _('Login')
		login_msg = 'login'
		user_email = ''
		user_ip = ''
	
	return {'login_label': login_label, 'login_msg':login_msg, 'user_email':user_email, 'user_ip':user_ip}

def set_proxy(request):
	proxy = request.session.get('proxy', None)
	return {"proxy":proxy}

def set_host_url(request):	
	original_host = request.META.get('HTTP_HOST')
	#print request
	host_url = settings.OCSP_HOST_PREFIX+original_host[original_host.find('.'):]
	
	return {'host_url':host_url, 'ocsp_host_prefix':settings.OCSP_HOST_PREFIX}

def get_customer_region(request):
	try:
		customer = get_customer(request) # Customer Display Object
		customer_region = customer.ocsp_region
	except:
		customer_region = 4000
	return {'customer_region':customer_region}

def get_customer_language(request):	
	try:
		customer = get_customer(request)
		region = customer.ocsp_region
	except:
		region = None
	
	if region == 1000:
		lang = 'ko-kr'
	elif region == 2000:
		lang = 'ja-jp'
	elif region == 3000:
		lang = 'zh-cn'
	elif region == 4000:
		lang = 'en-us'
	else:
		lang = 'en-us'
	return {'customer_language':lang}

def get_version(request):
	return {'aurora_version':settings.VERSION_NUMBER}

def get_reseller_footer(request):
	""" Gets reseller information from Query-string and sets reseller information in footer """
	reseller = request.GET.get('reseller', None)
	
	copy1 = copy2 = ''
	if reseller == 'Y':
		copy1 = request.GET.get('copy1', '')
		copy2 = request.GET.get('copy2', '')
	return {'reseller':reseller,
			'footer_copy1':copy1,
			'footer_copy2':copy2}


@login_required
def get_telco_gnb(request):
	menu = get_user_menu(request)

	return {'telco_gnb':menu}



def get_super_account_list(request):
	if request.user.is_superuser:
		account_objs = CustomerAccount.objects.filter(telco_type__in = [1,2])
		return {'super_account_list':account_objs}
	else:
		return {'super_account_list':None}


def get_super_account(request):
	if request.user.is_superuser:
		if request.session.get('admin_aquired'):
			retAccount = request.session.get('admin_aquired')
			account_no = retAccount.account_no
			return {'super_account':account_no}		
		else:					
			return {'super_account':''}
	else:
		return {'super_account':None}

