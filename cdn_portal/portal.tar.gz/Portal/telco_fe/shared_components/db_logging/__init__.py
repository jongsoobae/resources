from telco_fe import config_db_constants
from django.utils.encoding import smart_str
import MySQLdb
import logging
import re
import time
import urllib

class MySqlHandler(logging.Handler):    
    initial_sql = """CREATE TABLE IF NOT EXISTS aurora.log(
                        created TEXT,
                        name TEXT,
                        logLevel INT(11),
                        logLevelName TEXT,
                        message TEXT,
                        args TEXT,
                        module TEXT,
                        funcName TEXT,
                        lineNo INT(11),
                        exception TEXT,
                        process INT(11),
                        thread TEXT,
                        threadName TEXT
                )"""
                
    insertion_sql = """INSERT INTO aurora.log \
                    (`created`, `name`, `logLevel`, `logLevelName`, `message`, `args`, `module`, `funcName`, `lineNo`, `exception`, `process`, `thread`, `threadName`) \
                    VALUES \
                    ('%(dbtime)s', '%(name)s', %(levelno)d, '%(levelname)s', '%(msg)s', '%(args)s', '%(module)s', '%(funcName)s', %(lineno)d, '%(exc_text)s', %(process)d, '%(thread)s','%(threadName)s'); \
                    """
    def __init__(self):
        logging.Handler.__init__(self)        
        #self.db = config_db_constants.DEFAULT
        self.dbHost = config_db_constants.DEFAULT.get('HOST')
        self.dbRoot = config_db_constants.DEFAULT.get('USER')
        self.dbPwd = config_db_constants.DEFAULT.get('PASSWORD')
        self.dbName = config_db_constants.DEFAULT.get('NAME')
        # Create table if needed:        
        conn = MySQLdb.connect(self.dbHost, self.dbRoot, self.dbPwd, self.dbName)
        cur = conn.cursor()        
        cur.execute(MySqlHandler.initial_sql)        
        conn.commit()    
        
    def formatDBTime(self, record):        
        record.dbtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(record.created))    
    def emit(self, record):             
        # Use default formatting:        
        self.format(record)        
        # Set the database time up:        
        self.formatDBTime(record)        
        if record.exc_info:            
            record.exc_text = re.escape(logging._defaultFormatter.formatException(record.exc_info))        
        else:            
            record.exc_text = ""        
        # Insert log record:
        sql = MySqlHandler.insertion_sql % record.__dict__
        
        #.get('dbtime'), record.__dict__.get('name'), record.__dict__.get('levelno'), record.__dict__.get('levelname'), record.__dict__.get('msg'),\
        #        record.__dict__.get('args'), record.__dict__.get('module'), record.__dict__.get('funcName'), record.__dict__.get('lineno'), record.__dict__.get('exc_text'),\
        #       record.__dict__.get('process'), record.__dict__.get('thread'), record.__dict__.get('threadName'))
        
        conn = MySQLdb.connect(self.dbHost, self.dbRoot, self.dbPwd, self.dbName)
        cur = conn.cursor()         
        cur.execute(sql)        
        conn.commit()