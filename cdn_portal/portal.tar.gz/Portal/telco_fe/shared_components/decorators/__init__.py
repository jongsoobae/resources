from telco_fe import settings
from telco_fe.shared_components.models.acl_core import AuthUserHasControlGroup
from telco_fe.shared_components.utils import get_customer
from telco_fe.shared_components.utils.menu import getMenuList
from telco_fe.shared_components.utils.telco_user_helper import check_accessable_menu
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect
from spectrum_fe.shared_components.models.customer import CustomerItem
from spectrum_fe.shared_components.utils.api import getOptionalParams



def dns_customer_required(func):
	""" DECORATOR FOR DNS CUSTOMERS (LOGIN CHECK) """
	def _item_exist_check(request, *args, **kwargs):
		customer = get_customer(request)
		if customer:
			items = CustomerItem.objects.filter(material_no=settings.DNS_MATERIAL, 
											contract__account=customer.account, 
											contract__tz_offset=customer.tz_offset)
			if len(items) == 0:
				return HttpResponseRedirect(reverse('error', args=[403]))
			else:
				return func(request, *args, **kwargs)
		else:
			return HttpResponseRedirect(reverse('error', args=[403]))
	return _item_exist_check

def cs_customer_required(func):
	""" DECORATOR FOR CS CUSTOMERS (LOGIN CHECK) """
	def _item_exist_check(request, *args, **kwargs):
		customer = get_customer(request)
		if customer:
			items = CustomerItem.objects.filter(material_no=settings.CS_MATERIAL, 
											contract__account=customer.account, 
											contract__tz_offset=customer.tz_offset)
			if len(items) == 0:
				return HttpResponseRedirect(reverse('error', args=[403]))
			else:
				return func(request, *args, **kwargs)
		else:
			return HttpResponseRedirect(reverse('error', args=[403]))
	return _item_exist_check


def dna_customer_required(func):
	""" DECORATOR FOR DNA CUSTOMERS (LOGIN CHECK) """
	def _item_exist_check(request, *args, **kwargs):
		customer = get_customer(request)
		if customer:
			items = CustomerItem.objects.filter(material_no=settings.DNA_MATERIAL, 
											contract__account=customer.account, 
											contract__tz_offset=customer.tz_offset)
			if len(items) == 0:
				return HttpResponseRedirect(reverse('error', args=[403]))
			else:
				return func(request, *args, **kwargs)
		else:
			return HttpResponseRedirect(reverse('error', args=[403]))
	return _item_exist_check


def menu_authority_required(func):
	def _item_exist_check(request, *args, **kwargs):
		params = getOptionalParams(request)
		#menu_id = kwargs.get('menu_id')
		menu_id = params.get('m', -1)
		
		menu_list = getMenuList(request, menu_id)
		
		if menu_list[2] != True :
			return HttpResponseRedirect(reverse('error', args=[403]))
		#request.user.menu_list = menu_list[0]
		request.session["data"] = menu_list[0]
		request.session["static_data"] = menu_list[1]
		
		control_group_list = AuthUserHasControlGroup.objects.filter(auth_user_id=request.user.pk, use_flag=1)
		cgl = []
		for q in control_group_list:
			cgl.append(q.control_group_id)
		request.user.control_group = cgl
		if menu_id >0 :
			request.session["menu_id"] = menu_id
			request.session["material_no"] = menu_list[3]
		return func(request, *args, **kwargs)
	return _item_exist_check

def is_authorized(func):
	def _has_menu_authorized(request,*args,**kwargs):
		permit = check_accessable_menu(request)
		if permit is True:
			pass
		else:
			return permit
		return func(request, *args, **kwargs)
	return _has_menu_authorized