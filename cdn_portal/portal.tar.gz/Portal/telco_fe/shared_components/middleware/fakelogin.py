from django.contrib.auth import authenticate, login

class FakeLogin(object):
	def process_request(self, request):
		user = authenticate(username='superuser@cdnetworks.com', password='superuser123')
		if user and user.is_active:
			login(request, user)
		return None
