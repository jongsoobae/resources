from django.conf import settings
from django.http import HttpResponseForbidden
from django.template import RequestContext, Template, loader, \
    TemplateDoesNotExist
from django.utils.importlib import import_module

"""
# Middleware to allow the display of a 403.html template when a
# 403 error is raised.
"""

class Http403(Exception):
    pass

class Http403Middleware(object):
    def process_exception(self, request, exception):
        if not isinstance(exception, Http403):
            # Return None so django doesn't re-raise the exception
            return None
        
        t = loader.get_template('403_standalone.html')
        
        # Now use context and render template
        c = RequestContext(request, {
         })

        return HttpResponseForbidden(t.render(c))