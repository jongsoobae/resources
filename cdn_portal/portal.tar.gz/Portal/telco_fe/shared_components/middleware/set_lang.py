from telco_fe.shared_components.utils import get_customer
from telco_fe.shared_components.utils.aquacrypto import decrypt
from telco_fe.shared_components.utils.common import getSafeSessionValue
from django.conf import settings
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect
from django.utils import translation
import re
import urllib

class SetLang(object):
	def process_request(self, request):
		
		#user.get_profile()
		lang = 'en-us'
		
		if getSafeSessionValue(request, 'user_login_url') == settings.USER_LOGIN_LABEL :
			try:
				uProfile = request.user.get_profile()
				lang = uProfile.language_cd
			except:
				lang = 'en-us'
		else :	
			try:
				region = get_customer(request).ocsp_region
			except:
				region = None
			
			if region == 1000:
				lang = 'ko-kr'
			elif region == 2000:
				lang = 'ja-jp'
			elif region == 3000:
				lang = 'zh-cn'
			elif region == 4000:
				lang = 'en-us'
				
			if request.COOKIES.has_key("ocspCookie"):
				encryptedKey = urllib.unquote(request.COOKIES.get("ocspCookie"))
				if encryptedKey:
					decryptedKey = decrypt(urllib.unquote(encryptedKey))
				if decryptedKey:
					ocsp_lang = re.search('language_cd=([a-zA-Z_]+);', decryptedKey).group(1)
					
					if ocsp_lang == 'ko_KR':
						lang = 'ko-kr'
					elif ocsp_lang == 'ja_JP':
						lang = 'ja-jp'
					elif ocsp_lang == 'zh_CN':
						lang = 'zn-cn'
					elif ocsp_lang == 'en_US':
						lang = 'en-us'
		
		translation.activate(lang)
		request.LANGUAGE_CODE = translation.get_language()
