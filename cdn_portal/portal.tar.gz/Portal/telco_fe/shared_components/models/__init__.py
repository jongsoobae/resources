from django.contrib.auth.models import User
from django.db import models
from django.db.models.signals import post_save
from spectrum_fe.shared_components.models import BaseModel
from spectrum_fe.shared_components.models.customer import CustomerDisplay
#from aurora_fe.shared_components.models.acl_core import AuthUserHasPrivilege,\
#	AuthUserHasControlGroup

class UserProfile(models.Model):
	profile_id = models.AutoField(primary_key=True, db_column='profile_id')
	user = models.OneToOneField(User, db_column='user_id',related_name='profile_set')
	customer = models.ForeignKey(CustomerDisplay, db_column='customer_id')
	language_cd = models.CharField(max_length=20,default='en-us')
	locale_cd = models.CharField(max_length=20,default='en_US')
	gmt_cd = models.CharField(max_length=50,default='GMT_61')
	user_phone = models.CharField(max_length=50)
	user_mobile = models.CharField(max_length=50)
	erp_contact_key = models.CharField(max_length=10)
	erp_account_key = models.CharField(max_length=10)
	
	class Meta:
		db_table = 'auth_user_profile'
		
	def __unicode__(self):
		return "%s's profile" % self.user
	
#	def get_user_privilege(self):
#		p_list = AuthUserHasPrivilege.objects.filter(auth_user_id=self.user)
#		return p_list
#	
#	def get_control_group(self):
#		cgl = AuthUserHasControlGroup.objects.filter(auth_user_id=self.user, use_flag=1)
#		ret_cgl = []
#		for q in cgl:
#			ret_cgl.append(q.control_group_id.control_group_id)
#		return ret_cgl
	
def create_user_profile(sender, instance, created, **kwargs):
	if created:
		profile, created = UserProfile.objects.get_or_create(user=instance)
	
	# NEED TO IMPROVE CODE TO GET ACCOUNT_NO STORED IN USER PROFILE
post_save.connect(create_user_profile, sender=User)
