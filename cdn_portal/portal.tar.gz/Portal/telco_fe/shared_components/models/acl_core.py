from django.contrib.auth.models import User
from django.db import models
from spectrum_fe.shared_components.models import BaseModel, StatMaster
from spectrum_fe.shared_components.models.customer import CustomerAccount, \
    CustomerItem, AbstractCustomerAccount
from spectrum_fe.shared_components.models.portal_menu import PortalMenuMaster

class AuroraMenuCD(BaseModel):
    aurora_menu_id = models.AutoField(primary_key=True)
    master_menu_id = models.ForeignKey(PortalMenuMaster, db_column='master_menu_id', unique=True)
    menu_depth = models.PositiveIntegerField()
    sort_order = models.PositiveIntegerField()
    link_url = models.CharField(max_length=200, null=True)
    use_flag = models.SmallIntegerField(default=1)
    privilege_check = models.SmallIntegerField(default=1)
    
    class Meta:
        db_table = 'aurora_menu_cd'
        
class Privilege(BaseModel):
    privilege_id = models.AutoField(primary_key=True)
    privilege_name = models.CharField(max_length=100)
    privilege_desc = models.TextField()
    privilege_depth = models.PositiveSmallIntegerField()
    sort_order = models.PositiveSmallIntegerField()
    parent_privilege_id = models.PositiveSmallIntegerField(null=True, default=None)
    use_flag = models.PositiveSmallIntegerField(default=1)
    admin_flag = models.PositiveSmallIntegerField(default=0)
    aurora_menu_id = models.ManyToManyField(AuroraMenuCD, through='PrivilegeHasAuroraMenu')
    
    class Meta:
        db_table = 'privilege'
    def __unicode__(self):
        return u"%s" % self.privilege_name

class CustomerAccountWrapper(AbstractCustomerAccount):
    privilege_id = models.ManyToManyField(Privilege, through='CustomerAccountHasPrivilege')
    
    def get_control_group(self):
        cgl = ControlGroup.objects.filter(account_no=self.account_no,use_flag=1)
        return cgl
    def get_privilege_list(self):
        pl = Privilege.objects.filter(privilege_id__in=CustomerAccountHasPrivilege.objects.filter(account_no=self.account_no).values('privilege_id'))
        return pl

                    
class PrivilegeHasAuroraMenu(BaseModel):
    id = models.AutoField(primary_key=True)
    privilege_id = models.ForeignKey(Privilege, db_column='privilege_id')
    aurora_menu_id = models.ForeignKey(AuroraMenuCD, db_column='aurora_menu_id')
    
    class Meta:
        db_table = 'privilege_has_aurora_menu'

class CustomerAccountHasPrivilege(BaseModel):
    id = models.AutoField(primary_key=True)
    account_no = models.ForeignKey(CustomerAccountWrapper, db_column='account_no')
    privilege_id = models.ForeignKey(Privilege, db_column='privilege_id')
    
    class Meta:
        db_table = 'customer_account_has_privilege'      

class AuthUserPrivilegeBlacklist(BaseModel):
    id = models.AutoField(primary_key=True)
    auth_user_id = models.ForeignKey(User, db_column='auth_user_id')
    account_has_privilege_id = models.ForeignKey(CustomerAccountHasPrivilege, db_column='account_has_privilege_id')
    
    class Meta:
        db_table = 'auth_user_privilege_blacklist'
        
class ControlGroup(BaseModel):
    control_group_id = models.AutoField(primary_key=True)
    account_no = models.ForeignKey(CustomerAccountWrapper, db_column='account_no')
    item_id = models.ForeignKey(CustomerItem, db_column='item_id', null=True)
    control_group_name = models.CharField(max_length=100)
    parent_account_no = models.ForeignKey(CustomerAccountWrapper, 
                                    db_column='parent_account_no', 
                                    null=True)
    reg_date = models.DateTimeField(auto_now_add=True)
    use_flag = models.PositiveSmallIntegerField(default=1)
    group_type = models.PositiveSmallIntegerField(default=2)
    ckey = models.PositiveSmallIntegerField(null=True)

    #aurora_menu_id = models.ManyToManyField(AuroraMenuCD, through='ControlGroupHasAuroraMenuCD')
    
    class Meta:
        db_table = 'control_group'

    def __unicode__(self):
        return u"%s" % self.control_group_name
    
    def getUserList(self):
        user_list = AuthUserHasControlGroup.objects.filter(control_group_id = self)
        users = []
        if user_list:
            for q in user_list:
                users.append(q.auth_user_id.get_profile())
        return users
    
class AuthUserHasControlGroup(BaseModel):
    id = models.AutoField(primary_key=True)
    auth_user_id = models.ForeignKey(User, db_column='auth_user_id',related_name="user_to_control_group")
    control_group_id = models.ForeignKey(ControlGroup, db_column='control_group_id')
    use_flag = models.PositiveSmallIntegerField(default=1)
    
    class Meta:
        db_table = 'auth_user_has_control_group'
    
class StatItemWhiteList(BaseModel):
    id = models.AutoField(primary_key=True)
    control_group_id = models.ForeignKey(ControlGroup, db_column='control_group_id')
    stat_id = models.ForeignKey(StatMaster,db_column='stat_id')

    class Meta:
        db_table = 'stat_item_whitelist'

class TelcoMenuCD(BaseModel):
    telco_menu_id = models.AutoField(primary_key=True,db_column='menu_id')
    master_menu_id = models.ForeignKey(PortalMenuMaster, db_column='master_menu_id', unique=True)
    menu_depth = models.PositiveIntegerField()
    sort_order = models.PositiveIntegerField()
    link_url = models.CharField(max_length=200, null=True)
    use_flag = models.SmallIntegerField(default=1)
    
    class Meta:
        db_table = 'telco_menu_cd'

class TelcoMenuWhitelist(BaseModel):
    telco_menu_whitelist = models.AutoField(primary_key=True,db_column='telco_menu_whitelist_id')
    user = models.ForeignKey(User,db_column='user_id',
                            related_name='user_menu_set')
    menu = models.ForeignKey(TelcoMenuCD,db_column='menu_id',
                            related_name='menu_set')

    class Meta:
        db_table = 'telco_menu_whitelist'