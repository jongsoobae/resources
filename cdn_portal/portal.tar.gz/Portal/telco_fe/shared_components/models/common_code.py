from django.db import models

class GMTCD(models.Model):
    gmt_cd = models.CharField(primary_key=True, max_length=20)
    gmt_name_en = models.CharField(max_length=100)
    gmt_name_ko = models.CharField(max_length=100)
    gmt_name_ja = models.CharField(max_length=100)
    gmt_name_zh = models.CharField(max_length=100)
    gmt_time = models.IntegerField(max_length=11)
    gmt_hh = models.IntegerField(max_length=11)
    use_flag = models.SmallIntegerField()
    
    class Meta:
        db_table = 'gmt_cd'

class LanguageCD(models.Model):
    language_cd = models.CharField(primary_key=True, max_length=20)
    language_name_en = models.CharField(max_length=30)
    language_name_ko = models.CharField(max_length=30)
    language_name_ja = models.CharField(max_length=30)
    language_name_zh = models.CharField(max_length=30)
    use_flag = models.SmallIntegerField()
    
    class Meta:
        db_table = 'language_cd'

class LocaleCD(models.Model):
    locale_cd = models.CharField(primary_key=True, max_length=20)
    locale_name_en = models.CharField(max_length=50)
    locale_name_ko = models.CharField(max_length=50)
    locale_name_ja = models.CharField(max_length=50)
    locale_name_zh = models.CharField(max_length=50)
    
    class Meta:
        db_table = 'locale_cd'