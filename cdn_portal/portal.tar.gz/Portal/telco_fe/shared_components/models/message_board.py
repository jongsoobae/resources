# -*- coding: utf-8 -*-
"""
    Copyright (c) 2012 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
    	Message Dashboard
"""
import datetime

from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MaxValueValidator, MinValueValidator, \
        RegexValidator, MinLengthValidator, MaxLengthValidator
from django.utils.translation import ugettext as _
from spectrum_fe.shared_components.models import BaseModel, BaseActionHistory

class MessageBoard(models.Model):
	msg = models.AutoField(primary_key=True,db_column='msg_id',verbose_name="message id")
	user = models.ForeignKey(User,null=False,db_column='user_id',verbose_name="User(writer)")
	title = models.CharField(null=True, blank=True,max_length=100,
								verbose_name="Title",
								validators=[MaxLengthValidator(100)],)
	message = models.TextField(null=True, blank=True,max_length=65535,
								verbose_name="message body",
								validators=[MaxLengthValidator(65535)],)
	urgent = models.BooleanField('urgent',default=False,null=False)
	type = models.IntegerField(default=1,null=False)
	time_created = models.DateTimeField(auto_now_add=True,editable=False)
	update_num = models.IntegerField()
	use_flag = models.BooleanField(default=True,null=False)
	
	class Meta:
		app_label='message_board'
		db_table = 'dashboard_msg'
		verbose_name = 'Message board'

	def __unicode__(self):
		return u"%s" % self.message

	def save(self, *args, **kwargs):
		super(MessageBoard,self).save(*args, **kwargs)