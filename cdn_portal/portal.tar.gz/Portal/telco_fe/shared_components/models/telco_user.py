# -*- coding: utf-8 -*-
"""
    Copyright (c) 2012 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Telco Member(User)
"""
from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MaxValueValidator, MinValueValidator, \
        RegexValidator, MinLengthValidator, MaxLengthValidator
from django.utils.translation import ugettext as _
from spectrum_fe.shared_components.models import BaseModel, BaseActionHistory
from spectrum_fe.shared_components.models.customer import CustomerAccount

class TelcoUser(models.Model):
    telco_user = models.AutoField(primary_key=True,db_column="telco_user_id")
    user = models.ForeignKey(User,null=False,db_column="user_id")
    type = models.PositiveSmallIntegerField(null=False,db_column="type")
    admin_flag = models.BooleanField(default=False,
                                    db_column="admin_flag",
                                    null=False)
    account = models.ForeignKey(CustomerAccount,null=False,db_column="account_no")
    is_active = models.BooleanField(default=True,db_column='is_active')
    
    class Meta:
        app_label='telco_user'
        db_table = 'telco_user'
        verbose_name = 'Telco Member'

    def __unicode__(self):
        return u"%s" % self.user