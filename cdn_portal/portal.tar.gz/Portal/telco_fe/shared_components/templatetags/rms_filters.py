from django import template
from telco_fe.monitoring.models.gslb_rms import RMSVipProbe, RMSAcknowledge, RMSMessage
from spectrum_fe.alerting.models.probe import AlertProbeLevel
from datetime import datetime
import random
from spectrum_fe.shared_components.templatetags.encode_decode import encode_id, decode_id  
from django.core.urlresolvers import reverse

register = template.Library()

@register.filter(name='filter_probe')
def filter_probe(value, header):
    return value.get_probe(header.name)

# RMS ACKNOWLEDGEMENT
@register.filter(name='check_acknowledged')
def check_acknowledged(value, page):
    all_ack_types = []
    try:
        if page == 'server':
            level = 2
        elif page == 'host':
            level = 3
        elif page == 'vip':
            level = 4
        elif page == 'vip_probe':
            level = 5
        ack = RMSAcknowledge.objects.filter(vip_probe=RMSVipProbe.objects.get(pk=value), level__lte=level)
        
        if ack.count() > 0:
            for a in ack:
                #if a.vip_probe.message.val < 0 or a.vip_probe.message.expired:
                if not {'ack_type':a.ack_type, 'rt_ticket':a.rt_ticket, 'level':a.level, 'end_date':a.end_date, 'today':datetime.now()} in all_ack_types:
                    all_ack_types.append({'ack_type':a.ack_type, 'rt_ticket':a.rt_ticket, 'level':a.level, 'end_date':a.end_date, 'today':datetime.now()})    
    except:
        pass
    return all_ack_types
    
# RMS ACKNOWLEDGEMENT
@register.filter(name='get_end_date')
def get_end_date(value):
    """ gets end_date for level 5 (vip/probe) """
    try:
        ack = RMSAcknowledge.objects.get(vip_probe=RMSVipProbe.objects.get(pk=value), level=5)
    except:
        ack = None
    
    if ack:
        return ack.end_date
    else:
        return None
    
# RMS ACKNOWLEDGEMENT
@register.filter(name='get_ack_type')
def get_ack_type(value):
    """ gets ack_type for level 5 (vip/probe)"""
    try:
        ack = RMSAcknowledge.objects.get(vip_probe=RMSVipProbe.objects.get(pk=value), level=5)
    except:
        ack = None
        
    if ack:
        return ack.ack_type
    else:
        return None
    
@register.filter(name='level_to_words')
def level_to_words(value):
    if value == 1:
        return "PoP"
    elif value == 2:
        return "Server"
    elif value == 3:
        return "Host"
    elif value == 4:
        return "Vip"
    else:
        return "Vip/Probe"
    
@register.filter(name='slice_pop')
def slice_pop(value):
    return value[value.find('-')+1:]

@register.filter(name='add_random')
def add_random(value):
    return value + random.uniform(0.005, 0.01)

@register.filter(name='convert2tags')
def convert2tags(value):
    splitted = value.split('^*')
    target_css = 'orange-light-bg'
    if splitted[1] == 'rt':
        target_css = 'green-light-bg'
    elif splitted[1] == 'email':
        target_css = 'blue-light-bg'
    generated_string = "<span class='"+target_css+" tag' name='action_tags' id='"+splitted[0]+splitted[3]+"'>"+splitted[3]+"<span class='tag-close'>&nbsp;</span></span><input type='hidden' name='action_tag_"+splitted[0]+"' value='"+splitted[0]+'^*'+splitted[1]+"^*"+splitted[2]+"^*"+splitted[3]+"' />"
    return generated_string 

def render_tag_str(target_css, action, level_class, target_name):
    url = reverse('alerting_ajax_handle_actions', args=[action.pk])
    
    generated_string = "<span class='tag "+target_css+"'><a data-id='"+str(action.pk)+"' href='#edit' data-url='"+url+"' class='edit_action_tag' data-target='"+target_name+"'>"+action.action_name+"</a><span class='tag-close'>&nbsp;</span></span>"
    generated_string += "<input type='hidden' name='action_tag_"+level_class+"' value='"+level_class+"^*"+target_name+"^*"+str(action.pk)+"^*"+action.action_name+"' />"
    return generated_string

@register.filter(name='convert2tags_from_model')
def convert2tags_from_model(value):    
    try:
        level = AlertProbeLevel.objects.get(pk=value)
    except:
        level = None
    
    generated_string = target_css = ''
    level_class = 'warning'
    for action in level.action_rt.all():
        target_css = 'green-light-bg'
        if level.level_class == 2:
            level_class = 'failure'
        generated_string += render_tag_str(target_css, action, level_class, 'rt')
    
    for action in level.action_email.all():
        target_css = 'blue-light-bg'
        if level.level_class == 2:
            level_class = 'failure'
        generated_string += render_tag_str(target_css, action, level_class, 'email')
    
    for action in level.action_iem.all():
        target_css = 'orange-light-bg'
        if level.level_class == 2:
            level_class = 'failure'
        generated_string += render_tag_str(target_css, action, level_class, 'iem')
    
    return generated_string