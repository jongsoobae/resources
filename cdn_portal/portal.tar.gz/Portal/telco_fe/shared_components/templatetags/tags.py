from django import template
from spectrum_fe.shared_components.utils.shared_constants import ACTION_TYPE
register = template.Library()

@register.filter(name='filter_action_type')
def filter_action_type(value):
	action_type = dict(ACTION_TYPE)	
	return action_type.get(value)

@register.filter(name='filter_none')
def filter_none(value):
	if value == None:
		value = 'N/A'
	return value

@register.filter(name='nullToEmpry')
def nullToEmpry(value):
	if value is None:
		return ''
	else:
		return value		
	
	