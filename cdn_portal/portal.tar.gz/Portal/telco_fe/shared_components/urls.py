from django.conf.urls.defaults import *

# Shared Components

#url(r'^accounts/login/$', 'login.render_page', name='login'),
    
urlpatterns = patterns('telco_fe.shared_components.views',
    url(r'^$', 'home.render_page', name='home'),
    url(r'^msg_add/$', 'msgboard.message_add', name='msg_add'),
    url(r'^msg_get/$', 'msgboard.message_get', name='msg_get'),
    url(r'^msg_update/$', 'msgboard.message_update', name='msg_update'),
    url(r'^msg_remove/$', 'msgboard.message_remove', name='msg_remove'),
    url(r'^accounts/login/$', 'login.render_page', name='login'),
)