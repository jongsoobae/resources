from telco_fe import settings
from telco_fe.shared_components.utils.common import getSafeSessionValue
from spectrum_fe.shared_components.models.customer import CustomerAccount, CustomerDisplay

def get_customer(request):
	if request.session.get('customer_account', None):
		try:
			if getSafeSessionValue(request, 'user_login_url') == settings.USER_LOGIN_LABEL :
				try :
					customer = CustomerDisplay.objects.get(account=request.session.get('customer_account').pk, ocsp_region=4000)
				except CustomerDisplay.DoesNotExist:
					customer = CustomerDisplay.objects.get(account=request.session.get('customer_account').pk)
			else :
				customer = CustomerDisplay.objects.get(account=request.session.get('customer_account').pk)
		except:
			customer = None
	else:
		try:
			
			customer = request.user.get_profile().customer
		except:
			customer = None
	return customer