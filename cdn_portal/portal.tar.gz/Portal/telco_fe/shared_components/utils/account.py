from telco_fe.shared_components.models.acl_core import CustomerAccountWrapper, \
    ControlGroup, AuthUserHasControlGroup
from telco_fe.shared_components.utils.common import checkSuperUser
from django.db.models.query_utils import Q
from django.contrib.auth.models import User


def getSubAccountByResellerUser(user_id):
    retValue = []
    
    account = ControlGroup.objects.filter( \
                parent_account_no__in=AuthUserHasControlGroup.objects. \
                    filter(auth_user_id=user_id, use_flag=1, control_group_id__group_type=0, control_group_id__use_flag=1).\
                        values('control_group_id__account_no')).\
            values('account_no').distinct('account_no')
    
    for i in account :
        retValue.append(i['account_no'])
    
    print retValue
    return retValue
 
def getAccountUserHasPrivilege(user_id, menu_id=None):
    # Function to get the account list request.user has privilege for input menu_id
    if isinstance(user_id, User):
        user_id = user_id.id
    account = None
    retValue = []
    
    if checkSuperUser(user_id)==True :
        account = CustomerAccountWrapper.objects.all().order_by('account_name_local')
    else :
        if menu_id == None :
            account = CustomerAccountWrapper.objects.filter( \
                        (Q(account_no__in=ControlGroup.objects.filter( \
                            parent_account_no__in=AuthUserHasControlGroup.objects. \
                                filter(auth_user_id=user_id, use_flag=1, control_group_id__group_type=0, control_group_id__use_flag=1).\
                                    values('control_group_id__account_no')).\
                            values('account_no')) | \
                        Q( account_no__in=ControlGroup.objects.filter( \
                            control_group_id__in=AuthUserHasControlGroup.objects. \
                                filter(auth_user_id=user_id, use_flag=1, control_group_id__use_flag=1).\
                                    values('control_group_id')).\
                            values('account_no')))
                    ).distinct('account_no').order_by('account_name_local')
        else :
            """
            relAcNo = CustomerAccountWrapper.objects.filter( \
                        account_no__in=ControlGroup.objects.filter( \
                            parent_account_no__in=AuthUserHasControlGroup.objects. \
                                filter(auth_user_id=request.user.pk, use_flag=1, control_group_id__group_type=0, control_group_id__use_flag=1).\
                                    values('control_group_id__account_no')).\
                            values('account_no', 'account_no__account_no')).distinct('account_no').\
                            order_by('account_name_local')
            """
            
            relAcNo = ControlGroup.objects.filter( \
                parent_account_no__in=AuthUserHasControlGroup.objects. \
                    filter(auth_user_id=user_id, use_flag=1, control_group_id__group_type=0, control_group_id__use_flag=1).\
                        values('control_group_id__account_no')).\
                values('account_no', 'account_no__account_no', 'account_no__account_name_local', 'parent_account_no__account_name_local').distinct('account_no').\
                order_by('account_no__account_name_local')
                              
            acNo = CustomerAccountWrapper.objects.filter( \
                        account_no__in=ControlGroup.objects.filter( \
                                            control_group_id__in=AuthUserHasControlGroup.objects.filter( \
                                                auth_user_id=user_id, use_flag=1, control_group_id__use_flag=1).values('control_group_id')).\
                                    values('account_no')). \
                    distinct('account_no').order_by('account_name_local')
            
            tmpAcNo = []
            for i in acNo :
                menu = CustomerAccountWrapper.objects.filter(account_no=i.account_no, privilege_id__privilege_id__isnull=False).\
                    extra(where = ["customer_account_has_privilege.privilege_id not in (select account_has_privilege_id from auth_user_privilege_blacklist where auth_user_id=%s)"], params=[user_id]).\
                    values('privilege_id__aurora_menu_id__aurora_menu_id').distinct('privilege_id__aurora_menu_id__aurora_menu_id')
                for j in menu :
                    if int(menu_id) == j['privilege_id__aurora_menu_id__aurora_menu_id'] :
                        print 1111111111
                        tmpAcNo.append(i)
                        break;
            
            for i in tmpAcNo :
                retValue.append([i.account_no, i.account_name_local])
                
            for i in relAcNo :
                retValue.append([i['account_no__account_no'], "[%s][%s]" % (i['parent_account_no__account_name_local'], i['account_no__account_name_local'])])
            
#            print retValue
            return retValue
            
    
    for i in account :
        retValue.append([i.account_no, i.account_name_local])
    
#    print retValue
                
    return retValue  




