from telco_fe.shared_components.models.acl_core import AuthUserHasControlGroup, \
    ControlGroup, AuroraMenuCD, Privilege, StatItemWhiteList, PrivilegeHasAuroraMenu, \
    CustomerAccountWrapper, AuthUserPrivilegeBlacklist
from django.contrib.auth.models import User
from django.db.models.query_utils import Q
from django.utils.encoding import smart_str
from spectrum_fe.shared_components.models import StatMaster
from spectrum_fe.shared_components.models.customer import CustomerDisplay, \
    CustomerAccount
from spectrum_fe.shared_components.models.portal_menu import MaterialGroup
from spectrum_fe.shared_components.decorators import deprecated
import logging

log = logging.getLogger('telco_fe')
                
class MenuObject(object):
    
    aurora_menu_id = None
    master_menu_id = None
    parent_menu_id = None
    menu_name_en = None
    menu_name_ko = None
    menu_name_ja = None
    menu_name_zh = None
    menu_name_ru = None
    menu_depth = None
    link_url = None
    sort_order = None
    material_group_cd = None

    def __init__(self):
        pass    
    
    def __str__(self):
        return "%s, %s, %s, %s, %s, %s, s, %s, %s, %s, %s, %s" % \
                (
                 str(self.aurora_menu_id),
                 str(self.master_menu_id),
                 str(self.parent_menu_id),
                 str(self.menu_name_en),
                 str(self.menu_name_ko),
                 str(self.menu_name_ja),
                 str(self.menu_name_zh),
                 str(self.menu_name_ru),
                 str(self.menu_depth),
                 str(self.link_url),
                 str(self.sort_order),
                 str(self.material_group_cd),
                 )
                                           
class ControlGroupObject(object):
    def __init__(self):
        pass
        
    control_group_id = None
    account_no = None
    account_name = None
    control_group_name = None
    group_type = None
    
    def __str__(self):
        return "%d, %d, %s, %s, %d" % \
                (self.control_group_id,\
                self.account_no,\
                smart_str(self.account_name),\
                smart_str(self.control_group_name),\
                self.group_type)
                
class AclHelper(object):
    request = None
    
    user_id = None
    is_superuser = None
    
    queryBuilder = None
    resultList = None
    
    def __init__(self, request=None):
        if request is not None :
            self.request = request
            self.user_id = request.user.pk
            self.is_superuser = request.user.is_superuser
            
        self.resultList = []
        
    def setUserID(self, user_id):
        self.user_id = user_id
    
    def setIsSuperuser(self, is_superuser):
        self.is_superuser = is_superuser
            
    def convertList(self, target, obj_name):
        result = [i.get(obj_name) for i in target]
            
        return result
    
    def clear(self):
        self.queryBuilder = None
        self.resultList = []
    
    def getAllByList(self):
        return self.resultList
            
    def getQueryBuilder(self):
        return self.queryBuilder
    
    def getAttributeByList(self, eleName):
        retValue = [i.__getattribute__(eleName) for i in self.resultList]
        return retValue
    
    def printDebug(self):
        for i in self.resultList :
            print i
            
    def printQueryBuilder(self):
        print self.queryBuilder.query        
        
class ControlGroupAclHelper(AclHelper):
    
    def __init__(self, request=None):
        super(ControlGroupAclHelper,self).__init__(request)
    
    def getAllAccountByList(self):
        retValue = []
        
        for i in self.resultList :
            if not i.__getattribute__('account_no') in retValue:
                retValue.append(i.__getattribute__('account_no')) 
        return retValue
    
    def getAccountList(self):
        retValue = []
        for i in self.resultList :
            if not [i.__getattribute__('account_no'),i.__getattribute__('account_name')] in retValue:
                retValue.append([i.__getattribute__('account_no'), i.__getattribute__('account_name')])
        return retValue  
                        
    def getControlGroupList(self):
        print self.is_superuser

        if self.is_superuser==True :
            self.queryBuilder = ControlGroup.objects.filter(use_flag=1).values( 
                        'control_group_id',
                        'account_no__account_no',
                        'account_no__account_name_local',
                        'control_group_name',
                        'group_type'
                )
                        
            print self.queryBuilder.query
        else :
            acNo = AuthUserHasControlGroup.objects.filter(auth_user_id=self.user_id, use_flag=1, control_group_id__use_flag=1).values('control_group_id__account_no').distinct()
            cgID = AuthUserHasControlGroup.objects.filter(auth_user_id=self.user_id, use_flag=1, control_group_id__use_flag=1).values('control_group_id')
            
            acList = self.convertList(acNo, 'control_group_id__account_no')
            cgList = self.convertList(cgID, 'control_group_id')
            
            self.queryBuilder = ControlGroup.objects.filter((Q(control_group_id__in=cgList) | Q(parent_account_no__in=acList))).\
                values( 
                        'control_group_id',
                        'account_no__account_no',
                        'account_no__account_name_local',
                        'control_group_name',
                        'group_type'
                ).distinct()
            """
            print self.queryBuilder.query
            
            for i in self.queryBuilder :
                print i.control_group_name
            """
        return self
    
    
    def filterDoNotNeedAclCheck(self):
        defaultGroup = self.queryBuilder.filter(group_type=0).values('account_no').distinct()
        defaultAccList=[i.get('account_no') for i in defaultGroup]
        
        self.queryBuilder = self.queryBuilder.exclude((Q(account_no__in=defaultAccList) & (Q(group_type=1) | Q(group_type=2))))
        
        #self.queryBuilder = self.queryBuilder.ControlGroup.objects.filter(use_flag=1)
        return self
    
    def filterDefaultControlGroup(self, group_type):
        self.queryBuilder = self.queryBuilder.filter(group_type=group_type)
        
        #self.queryBuilder = self.queryBuilder.ControlGroup.objects.filter(use_flag=1)
        return self
        
    def order_by(self, *args):
        self.queryBuilder = self.queryBuilder.order_by(*args)
        return self   
        
    @deprecated
    def filterByMenuAuth(self, aurora_menu_id):
        if self.is_superuser==True :
            pass
        else :
            self.queryBuilder = self.queryBuilder.filter(aurora_menu_id__aurora_menu_id=aurora_menu_id)
        return self
    
    def filterByAccount(self, account_no):
        if self.is_superuser==True :
            self.queryBuilder = self.queryBuilder.filter(account_no=account_no)
        else :
            self.queryBuilder = self.queryBuilder.filter(account_no=account_no)
        
        return self
            
    def excute(self):
        self.printQueryBuilder() 
        
        for i in self.queryBuilder :
            obj = ControlGroupObject()

            obj.control_group_id = i.get('control_group_id')
            obj.account_no = i.get('account_no__account_no')
            obj.account_name = i.get('account_no__account_name_local')
            obj.control_group_name = i.get('control_group_name')
            obj.group_type = i.get('group_type')
            
            self.resultList.append(obj)

        return self;
    
class MenuAclHelper(AclHelper):
    
    def __init__(self, request=None):
        super(MenuAclHelper,self).__init__(request)
          
    def getMenuList(self):
        if self.is_superuser==True :
            self.queryBuilder = AuroraMenuCD.objects.filter(use_flag=1, master_menu_id__use_flag=1).\
            values('aurora_menu_id', 'master_menu_id','master_menu_id__parent_menu_id', 
                   'master_menu_id__menu_name_en', 'master_menu_id__menu_name_ko','master_menu_id__menu_name_ja', 
                   'master_menu_id__menu_name_zh', 'master_menu_id__menu_name_ru',
                   'menu_depth','link_url','sort_order','master_menu_id__material_group_cd'
                   ).distinct()
                   
            print self.queryBuilder.query
        else:
            accIncgl = ControlGroupAclHelper(self.request).getControlGroupList().excute().getAllAccountByList()
            
            menu = CustomerAccountWrapper.objects.filter(account_no__in=accIncgl, privilege_id__privilege_id__isnull=False).\
                    extra(where = ["customer_account_has_privilege.privilege_id not in (select account_has_privilege_id from auth_user_privilege_blacklist where auth_user_id=%s)"], params=[self.user_id]).\
                    values('privilege_id__aurora_menu_id__aurora_menu_id').distinct('privilege_id__aurora_menu_id__aurora_menu_id')

            menuList = []
            
            for i in menu :
                menuList.append(i['privilege_id__aurora_menu_id__aurora_menu_id'])
                
            """
            privilegeList = []
            for i in privilege :
                privilegeList.append(i['privilege_id'])
                
            menuInUser = Privilege.objects.filter(privilege_id__in=privilegeList).values('aurora_menu_id').distinct('aurora_menu_id')
            
            menuSet = set(menuInUser.values_list('aurora_menu_id')) & set(menuInControlGroup.values_list('aurora_menu_id'))
            
            menuList = [i[0] for i in menuSet]
            
            print menuSet
            print menuList
            """
            self.queryBuilder = AuroraMenuCD.objects.filter(use_flag=1, master_menu_id__use_flag=1, aurora_menu_id__in=menuList).\
                    values('aurora_menu_id', 'master_menu_id','master_menu_id__parent_menu_id', 
                           'master_menu_id__menu_name_en', 'master_menu_id__menu_name_ko','master_menu_id__menu_name_ja', 
                           'master_menu_id__menu_name_zh', 'master_menu_id__menu_name_ru',
                           'menu_depth','link_url','sort_order','master_menu_id__material_group_cd'
                           )
                           
        return self
    
    def order_by(self, *args):
        self.queryBuilder = self.queryBuilder.order_by(*args)
        return self
        
    def excute(self):
        self.printQueryBuilder()
        
        for i in self.queryBuilder :
            obj = MenuObject()
            obj.aurora_menu_id = i['aurora_menu_id']
            obj.master_menu_id = i['master_menu_id']
            obj.parent_menu_id = i['master_menu_id__parent_menu_id']
            obj.menu_name_en = i['master_menu_id__menu_name_en']
            
            obj.menu_name_ko = i['master_menu_id__menu_name_ko']
            obj.menu_name_ja = i['master_menu_id__menu_name_ja']
            obj.menu_name_zh = i['master_menu_id__menu_name_zh']
            obj.menu_name_ru = i['master_menu_id__menu_name_ru']
            
            obj.menu_depth = i['menu_depth']
            obj.link_url = i['link_url']
            obj.sort_order = i['sort_order']
            obj.material_group_cd = i['master_menu_id__material_group_cd']
            
            self.resultList.append(obj)
            
        return self;

@deprecated
def getPrivilegeFromControlGroupList(control_group_list =[]):
    menuInControlGroup = ControlGroup.objects.filter(control_group_id__in=control_group_list,use_flag=1).values('aurora_menu_id').distinct('aurora_menu_id')
    menu_ids = []
    for q in menuInControlGroup:
        menu_ids.append(q.get('aurora_menu_id'))
    privilege_list = PrivilegeHasAuroraMenu.objects.filter(aurora_menu_id__in=menu_ids)
    ret_list = []
    for q in privilege_list:
        if not q.privilege_id in ret_list:
            ret_list.append(q.privilege_id)
    return ret_list

def getDefaultAccount(request):
    retAccount = None
    if request.session.has_key('customer_account'):
        retAccount = request.session['customer_account']
#    elif request.user.is_superuser:
#        account = CustomerAccount.objects.get(pk=1000)
#        request.session['account'] = account
#        return account
    else :
        customer_id = request.user.get_profile().customer_id
        customer_display = CustomerDisplay.objects.get(pk = customer_id)
        account = customer_display.account
#        account_key = ControlGroupAclHelper(request).getControlGroupList().excute().getAllAccountByList()[0]    
#        account = CustomerAccount.objects.get(pk=account_key)
        request.session['customer_account'] = account
        retAccount = request.session['customer_account']
        
    if request.session.get('admin_aquired') and request.session.get('admin_aquired') != '':
        retAccount = request.session.get('admin_aquired')
                
    return retAccount

def getSelectedAccount(request,account_no=None):
    account = CustomerAccountWrapper.objects.get(pk=account_no)
    request.session['customer_account'] = account
    return account

def getControlGroup(request, account = None):
    if account == None:
        account = getDefaultAccount(request)
    control_group_list = ControlGroup.objects.filter(account_no= account)
    ret_list = []
    default_control_group = None
    for q in control_group_list:
        if q.group_type == 0:
            default_control_group = q
        ret_list.append(q)
    return {'default':default_control_group, 'control_group_list':ret_list}
