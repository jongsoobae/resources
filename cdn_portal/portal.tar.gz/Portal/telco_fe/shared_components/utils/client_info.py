def getClientOSInfo(strUserAgent):
    if strUserAgent.find('Windows 95') > 0 or strUserAgent.find('Win95') > 0 or strUserAgent.find('Windows_95') > 0:
        return 'Windows 95'
    elif strUserAgent.find('Windows 98') > 0 or strUserAgent.find('Win 9x 4.90') > 0 :
        return 'Windows 98'
    elif strUserAgent.find('Windows NT 5.0') > 0 or strUserAgent.find('Windows 2000') > 0 :
        return 'Windows 2000'
    elif strUserAgent.find('Windows NT 5.1') > 0 or strUserAgent.find('Windows XP') > 0 :
        return 'Windows XP'
    elif strUserAgent.find('Windows NT 5.2') > 0 :
        return 'Windows Server 2003'
    elif strUserAgent.find('Windows NT 6.0') > 0 :
        return 'Windows Vista'
    elif strUserAgent.find('Windows NT 6.1') > 0 :
        return 'Windows 7'
    elif strUserAgent.find('Windows ME') > 0 :
        return 'Windows ME'
    elif strUserAgent.find('Mac_PowerPC') > 0 or strUserAgent.find('Macintosh') > 0 : 
        return 'Mac OS'
    elif strUserAgent.find('Linux') > 0 or strUserAgent.find('X11') > 0 : 
        return 'Linux'
    else :
        return 'unknown'
    
def getClientBrowserInfo(strUserAgent):
    if strUserAgent.find('Chrome/') > 0 :
        return 'Chrome'
    elif strUserAgent.find('Safari/') > 0 :
        return 'Safari'
    elif strUserAgent.find('Navigator/') > 0 or strUserAgent.find('Firefox/0.9.6') > 0 :
        return 'Netscape'
    elif strUserAgent.find('Opera/') > 0 :
        return 'Opera'
    elif strUserAgent.find('Firefox/') > 0 :
        return 'Firefox'
    elif strUserAgent.find('MSIE') > 0 : 
        return 'Explorer'
    else :
        return 'unknown'
