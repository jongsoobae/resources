from telco_fe import settings
#from telco_fe.settings import NOT_STANDALONE_URL
from django.contrib.auth.models import User
from telco_fe.shared_components.models.common_code import GMTCD
def isStandAloneUrl(requestPath):
    #for i in settings.NOT_STANDALONE_URL :
    #    if requestPath.startswith(i) :
    #        return False
    return True

def getSafeSessionValue(request, attr):
    return request.session.get(attr, None)

def checkSuperUser(user_id):
    #check whether superuser or not by user_id
    try :
        obj = User.objects.get(pk=user_id)
        return obj.is_superuser
    except :
        return False

def get_user_timezone(user=None):
    if not isinstance(user, User):
        user = User.objects.get(pk=user)
    tz_cd = user.get_profile().gmt_cd
    gmt_obj = GMTCD.objects.get(pk=tz_cd)
    return gmt_obj.gmt_hh
