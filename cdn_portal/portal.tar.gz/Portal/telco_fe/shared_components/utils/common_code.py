from telco_fe.shared_components.models.common_code import GMTCD, LanguageCD, LocaleCD
def get_common_code_list(request):
    gmtlist = GMTCD.objects.filter(use_flag = 1)
    lan_list = LanguageCD.objects.filter(use_flag = 1)
    locale_list = LocaleCD.objects.all()
    ret_gmt_list = []
    ret_lan_list = []
    ret_loc_list = []
    user_lang = request.user.get_profile().language_cd
    if user_lang == None:
        user_lang = 'en-us'
    
    for q in gmtlist:
        if user_lang[:2] == 'ko' :
            ret_gmt_list.append([q.gmt_cd, q.gmt_name_ko + q.gmt_time])
        elif user_lang[:2] == 'ja' :
            ret_gmt_list.append([q.gmt_cd, q.gmt_name_ja + q.gmt_time])
        elif user_lang[:2] == 'zh' :
            ret_gmt_list.append([q.gmt_cd, q.gmt_name_zh + q.gmt_time])
        else :
            ret_gmt_list.append([q.gmt_cd, q.gmt_name_en + q.gmt_time])
    
    for q in lan_list:
        
        if user_lang[:2] == 'ko' :
            ret_lan_list.append([q.language_cd, q.language_name_ko])
        elif user_lang[:2] == 'ja' :
            ret_lan_list.append([q.language_cd, q.language_name_ja])
        elif user_lang[:2] == 'zh' :
            ret_lan_list.append([q.language_cd, q.language_name_zh])
        else :
            ret_lan_list.append([q.language_cd, q.language_name_en])
    
    for q in locale_list:
        
        if user_lang[:2] == 'ko' :
            ret_loc_list.append([q.locale_cd, q.locale_name_ko])
        elif user_lang[:2] == 'ja' :
            ret_loc_list.append([q.locale_cd, q.locale_name_ja])
        elif user_lang[:2] == 'zh' :
            ret_loc_list.append([q.locale_cd, q.locale_name_zh])
        else :
            ret_loc_list.append([q.locale_cd, q.locale_name_en])
    
    return {'gmt_list':ret_gmt_list, 'language_list':ret_lan_list, 'locale_list':ret_loc_list}

def get_common_code_list_light(user):
    gmtlist = GMTCD.objects.filter(use_flag = 1)
    lan_list = LanguageCD.objects.filter(use_flag = 1)
    locale_list = LocaleCD.objects.all()
    ret_gmt_list = []
    ret_lan_list = []
    ret_loc_list = []
    try:
        user_lang = user.get_profile().language_cd
    except:
        user_lang = None

    if user_lang == None:
        user_lang = 'en-us'
    
    for q in gmtlist:
        if user_lang[:2] == 'ko' :
            ret_gmt_list.append([q.gmt_cd, q.gmt_name_ko + q.gmt_time])
        elif user_lang[:2] == 'ja' :
            ret_gmt_list.append([q.gmt_cd, q.gmt_name_ja + q.gmt_time])
        elif user_lang[:2] == 'zh' :
            ret_gmt_list.append([q.gmt_cd, q.gmt_name_zh + q.gmt_time])
        else :
            ret_gmt_list.append([q.gmt_cd, q.gmt_name_en + q.gmt_time])
    
    for q in lan_list:
        
        if user_lang[:2] == 'ko' :
            ret_lan_list.append([q.language_cd, q.language_name_ko])
        elif user_lang[:2] == 'ja' :
            ret_lan_list.append([q.language_cd, q.language_name_ja])
        elif user_lang[:2] == 'zh' :
            ret_lan_list.append([q.language_cd, q.language_name_zh])
        else :
            ret_lan_list.append([q.language_cd, q.language_name_en])
    
    for q in locale_list:
        
        if user_lang[:2] == 'ko' :
            ret_loc_list.append([q.locale_cd, q.locale_name_ko])
        elif user_lang[:2] == 'ja' :
            ret_loc_list.append([q.locale_cd, q.locale_name_ja])
        elif user_lang[:2] == 'zh' :
            ret_loc_list.append([q.locale_cd, q.locale_name_zh])
        else :
            ret_loc_list.append([q.locale_cd, q.locale_name_en])
    
    return {'gmt_list':ret_gmt_list, 'language_list':ret_lan_list, 'locale_list':ret_loc_list}

