from spectrum_fe.shared_components.models.customer import CustomerContract, CustomerDisplay, CustomerAccount, CustomerItem
from spectrum_fe.configuration.models.clb import CustomerContractPop
from django.http import HttpResponse
from django.utils import simplejson
from datetime import datetime, date

def get_customer_pops(customer, use_type=2):
	try:
		customers = CustomerDisplay.objects.filter(account = customer.account_no)
	except:
		return -1 # no display
		
	pops = CustomerContractPop.objects.filter(customer__in = customers, use_type=use_type)
	
	return pops
	
	

def get_customer_contract_items (customer):
	try:
		account = CustomerAccount.objects.get(account_no = customer.account_no)
	except:
		return -1 # no account
		
	contract_items = CustomerItem.objects.filter(contract__telco_account_no = account.account_no)
	
	return contract_items

	