from django.core.urlresolvers import reverse
from django.utils import translation, simplejson
from spectrum_fe.shared_components.models.portal_menu import MaterialGroup
from telco_fe.shared_components.models.acl_core import TelcoMenuCD,TelcoMenuWhitelist
from telco_fe.shared_components.utils.acl_helper import MenuAclHelper

import logging

log = logging.getLogger('telco_fe')

def getMenuList(request, focus=-1):
    try :
        print 'getMenuListgetMenuListgetMenuListgetMenuListgetMenuListgetMenuListgetMenuListgetMenuListgetMenuListgetMenuListgetMenuList'
        sortMenu = []
        sortStaticMenu = []
        targetMenu = ""
        
        material_list = []
        has_permission = False    
        
        if focus == None or focus<0 : focus = -1
        if focus<0 : has_permission = True
        
        targetMenu = MenuAclHelper(request).getMenuList()
        
        if has_permission == False :
            authCheck = targetMenu.getQueryBuilder().filter(aurora_menu_id=focus).values('master_menu_id__material_group_cd')
            if authCheck.__len__() > 0 :
                has_permission = True
                mg = None
                if authCheck[0]['master_menu_id__material_group_cd'] != "" and authCheck[0]['master_menu_id__material_group_cd'] != None :
                    mg = MaterialGroup.objects.filter(material_group_cd=authCheck[0]['master_menu_id__material_group_cd']).values('material_no')
                
                if mg is not None:    
                    for m in mg :
                        material_list.append(m['material_no'])
                    
        targetMenu = targetMenu.order_by('menu_depth','sort_order').excute().getAllByList()

        def build_nodes(node_parent_id):     
            try:
                subnodes = [node for node in targetMenu if node.parent_menu_id == node_parent_id]     
                #print node_parent_id, subnodes
                if len(subnodes) > 0 :          
                    [build_node(subnode) for subnode in subnodes]         
            except Exception as e:
                print e      
        def build_node(node):
            try:   
                if translation.get_language() == 'en-us' : 
                    if sortStaticMenu.__len__()>0 or node.sort_order>=100 : sortStaticMenu.append({'menu_id':node.aurora_menu_id,'menu_name':node.menu_name_en,'menu_depth':node.menu_depth,'link_url':combineLinkUrl(node.link_url,node.aurora_menu_id)})
                    else : sortMenu.append({'menu_id':node.aurora_menu_id,'menu_name':node.menu_name_en,'menu_depth':node.menu_depth,'link_url':combineLinkUrl(node.link_url,node.aurora_menu_id)})
                if translation.get_language() == 'ko-kr' :           
                    if sortStaticMenu.__len__()>0 or node.sort_order>=100 : sortStaticMenu.append({'menu_id':node.aurora_menu_id,'menu_name':node.menu_name_ko,'menu_depth':node.menu_depth,'link_url':combineLinkUrl(node.link_url,node.aurora_menu_id)})
                    else : sortMenu.append({'menu_id':node.aurora_menu_id,'menu_name':node.menu_name_ko,'menu_depth':node.menu_depth,'link_url':combineLinkUrl(node.link_url,node.aurora_menu_id)})
                if translation.get_language() == 'ja-jp' :
                    if sortStaticMenu.__len__()>0 or node.sort_order>=100 : sortStaticMenu.append({'menu_id':node.aurora_menu_id,'menu_name':node.menu_name_ja,'menu_depth':node.menu_depth,'link_url':combineLinkUrl(node.link_url,node.aurora_menu_id)})
                    else : sortMenu.append({'menu_id':node.aurora_menu_id,'menu_name':node.menu_name_ja,'menu_depth':node.menu_depth,'link_url':combineLinkUrl(node.link_url,node.aurora_menu_id)})
                if translation.get_language() == 'zh-cn' : 
                    if sortStaticMenu.__len__()>0 or node.sort_order>=100 : sortStaticMenu.append({'menu_id':node.aurora_menu_id,'menu_name':node.menu_name_zh,'menu_depth':node.menu_depth,'link_url':combineLinkUrl(node.link_url,node.aurora_menu_id)})
                    else : sortMenu.append({'menu_id':node.aurora_menu_id,'menu_name':node.menu_name_zh,'menu_depth':node.menu_depth,'link_url':combineLinkUrl(node.link_url,node.aurora_menu_id)})
                if translation.get_language() == 'ru-ua' : 
                    if sortStaticMenu.__len__()>0 or node.sort_order>=100 : sortStaticMenu.append({'menu_id':node.aurora_menu_id,'menu_name':node.menu_name_ru,'menu_depth':node.menu_depth,'link_url':combineLinkUrl(node.link_url,node.aurora_menu_id)})
                    else : sortMenu.append({'menu_id':node.aurora_menu_id,'menu_name':node.menu_name_ru,'menu_depth':node.menu_depth,'link_url':combineLinkUrl(node.link_url,node.aurora_menu_id)})
                build_nodes(node.master_menu_id)     
            except Exception as e:
                print e
            
        build_nodes(None)
        
    except Exception as e:
        print e
        log.exception(str(e))
        return ""
    
    #log.info(simplejson.dumps({'focus':focus,'data':sortMenu,'static_data':sortStaticMenu}))
    return [sortMenu, sortStaticMenu,has_permission, material_list]
                
def combineLinkUrl(link_url, aurora_menu_id):

    if link_url == None :
        return link_url
    else :
        return link_url + "?m="+str(aurora_menu_id)
    
def reverse_link(url,url_args=None):
    try:
        if url_args:
            return reverse(url,url_args)
        else:
            return reverse(url)
    except:
        return url