# -*- coding: utf-8 -*-
"""
    Copyright (c) 2012 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Telco Member(User)
"""
from django.contrib.auth.models import User
from django.core.exceptions import PermissionDenied, ValidationError, \
    ValidationError, ObjectDoesNotExist, MultipleObjectsReturned, \
    ImproperlyConfigured
from django.core.urlresolvers import reverse, resolve
from django.db.models import Q
from django.http import HttpResponseRedirect
from django.utils.translation import ugettext as _

from spectrum_fe.shared_components.models.customer import CustomerDisplay, \
    CustomerAccount
from spectrum_fe.shared_components.mail import send
from spectrum_fe.shared_components.utils.user_util import GenPasswd

from telco_fe.shared_components.models import UserProfile, create_user_profile
from telco_fe.shared_components.models.acl_core import TelcoMenuCD, TelcoMenuWhitelist
from telco_fe.shared_components.models.telco_user import TelcoUser
from telco_fe.shared_components.utils.menu import reverse_link
from spectrum_fe.shared_components.utils.hashers import make_password as make_sha2_password

from telco_fe import settings

def check_accessable_menu(request):
    try:
        valid_key = resolve(request.path_info).url_name
    except:
        valid_key = request.path_info

    if has_permit_menu(request.user, valid_key):
        return True
    else:
        return HttpResponseRedirect(reverse('home'))

def has_permit_menu(user, menu_link):
    if user.is_superuser:
        return True

    try:
        link = TelcoMenuWhitelist.objects.select_related('menu').get(menu__link_url=menu_link, user=user)
        return True
    except:
        return True

def checkAllowAccount(user, account_no=None):
    # require request.user
    try:
        if user.is_superuser:
            account_no = account_no
        else:
            account_no = user.get_profile().customer.account.account_no
    except:
        account_no = None

    return account_no

def getTelcoUser(user, account):
    try:
        telco_member = TelcoUser.objects.get(user=user, account=account)
        return telco_member
    except:
        raise ObjectDoesNotExist

def isTelcoMember(user, account):
    try:
        if user.is_superuser:
            return user
        else:
            telco_member = TelcoUser.objects.get(user=user, account=account)
            return telco_member
    except ObjectDoesNotExist:
        raise PermissionDenied
    except MultipleObjectsReturned:
        raise MultipleObjectsReturned
    except:
        raise ImproperlyConfigured

def isTelcoAdmin(user, account):
    if user.is_superuser:
        return True
    try:
        telco_member = TelcoUser.objects.get(user=user, account=account)
        return telco_member.admin_flag
    except:
        return False


def get_userinfo_by_telco_user_id(telco_user_id):
    try:
        telco_user = TelcoUser.objects.get(telco_user=telco_user_id)
        return telco_user
    except ObjectDoesNotExist:
        return None
    except:
        return None

def telcoMembers(account, filter_opts=None):
    members = TelcoUser.objects.select_related('user', 'user_profile')\
                                .filter(account=account)

    try:
        filter_name = filter_opts.get('search_name')
        if filter_name:
            members = members.filter(Q(user__first_name__istartswith=filter_name)
                        | Q(user__last_name__istartswith=filter_name))
    except:
        pass

    try:
        search_mail = filter_opts.get('search_mail')
        if search_mail:
            members = members.filter(user__email__istartswith=search_mail)
    except:
        pass

    try:
        search_status = int(filter_opts.get('search_status'))
        if search_status == 1:
            members = members.filter(is_active=True)
        elif search_status == 0:
            members = members.filter(is_active=False)
    except:
        pass

    return members

def telcoAllMembers(filter_opts=None):
    members = TelcoUser.objects\
                        .select_related('user', 'user_profile')
    try:
        filter_name = filter_opts.get('search_name')
        if filter_name:
            members = members.filter(Q(user__first_name__istartswith=filter_name)
                        | Q(user__last_name__istartswith=filter_name))
    except:
        pass

    try:
        search_mail = filter_opts.get('search_mail')
        if search_mail:
            members = members.filter(user__email__istartswith=search_mail)
    except:
        pass

    try:
        search_status = int(filter_opts.get('search_status'))
        if search_status == 1:
            members = members.filter(is_active=True)
        elif search_status == 0:
            members = members.filter(is_active=False)
    except:
        pass

    return members

def exists_username(username):
    try:
        if username:
            return User.objects.get(username=username)
        else:
            return False
    except:
        return False

def create_member(data):
    try:
        exists_user = exists_username(data.get('email'))
        if exists_user:
            return False

        password = ""
        customer_ids = CustomerDisplay.objects.filter(account__account_no=data.get('account'))
        customer = None
        if len(customer_ids) > 0:
            customer = customer_ids[0]
            for q in customer_ids:
                if q.ocsp_region == 4000:
                    customer = q

        save_user, create = User.objects.get_or_create(username=data.get('email'),
                                                    first_name=data.get('first_name'),
                                                    last_name=data.get('last_name'),
                                                    password=password,
                                                    email=data.get('email'))
        user_profile, create_profile = UserProfile.objects.get_or_create(user=save_user,
                                      customer=customer,
                                      user_phone=data.get('phone'),
                                      user_mobile=data.get('mobile'),
                                      erp_contact_key=99,#this is to prevent login users being directed to user profile edit page
                                      gmt_cd=data.get('tz')
                                      )

        telco_account , create_telco_account = TelcoUser.objects.get_or_create(user=save_user,
                                                                            type=data.get('type'),
                                                                            admin_flag=data.get('is_admin'),
                                                                            is_active=data.get('is_active'),
                                                                            account=customer.account)

        #sendmail action has been replaced by insert_to_ldap function where send user a verification mail instead of password noti mail
        #until email verified, this user won't be able to login
        #send_to = data.get('email')
        #send.mailSender(sender='aurora@cdnetworks.com',
        #                to=send_to,
        #                subject = _('Create User Account Succesfully.'),
        #                text=_('your password is "%s"')%password,
        #                attachs=None)
        return save_user
    except:
        return False

def mirgrate_member(data):
    try:
        customer_ids = CustomerDisplay.objects.filter(account__account_no=data.get('account'))
        customer = None
        if len(customer_ids) > 0:
            customer = customer_ids[0]
            for q in customer_ids:
                if q.ocsp_region == 4000:
                    customer = q
        else:
            raise ObjectDoesNotExist

        try:
            user_profile = UserProfile.objects.select_related('user')\
                                                .get(user__username=data.get('email'))

            exists_user = exists_username(data.get('email'))

            if exists_user:
                if exists_user.id == user_profile.user.id:
                    pass
                else:
                    return False

            user = user_profile.user
            user.username = data.get('email')
            user.first_name = data.get('first_name')
            user.last_name = data.get('last_name')
            user.email = data.get('email')
            user.save()

            user_profile.user_phone = data.get('phone')
            user_profile.user_mobile = data.get('mobile')
            user_profile.customer = customer
            user_profile.gmt_cd = data.get('tz')
            user_profile.save()

            telco_account , create_telco_account = TelcoUser.objects.get_or_create(user=user,
                                                                            type=data.get('type'),
                                                                            admin_flag=data.get('is_admin'),
                                                                            is_active=data.get('is_active'),
                                                                            account=customer.account)
            send_to = data.get('email')
            send.mailSender(sender='aurora@cdnetworks.com',
                            to=send_to,
                            subject=_('User Account Migration to Partner Portal Succesfully.'),
                            text=_('Your account is mirgration complete.\n You can login with your email ( %s ) and password.') % (data.get('email')),
                            attachs=None)

            return user
        except:
            return False
    except:
        return False

def update_member(data):
    try:
        customer_ids = CustomerDisplay.objects.filter(account__account_no=data.get('account'))
        customer = None
        if len(customer_ids) > 0:
            customer = customer_ids[0]
            for q in customer_ids:
                if q.ocsp_region == 4000:
                    customer = q
        else:
            raise ObjectDoesNotExist

        try:
            user_profile = UserProfile.objects.select_related('user')\
                                                .get(user=data.get('user'))

            exists_user = exists_username(data.get('email'))
            if exists_user:
                if exists_user.id == user_profile.user.id:
                    pass
                else:
                    return False

            user = user_profile.user
            user.username = data.get('email')
            user.first_name = data.get('first_name')
            user.last_name = data.get('last_name')
            user.email = data.get('email')

            #if data.get('o_pw'):
            #    if user.password == data.get('o_pw'):
            #        # update password
            #        if data.get('n_pw') == data.get('c_pw'):
            #            user.password = data.get('n_pw')
            #        else:
            #            return False
            #    else:
            #        return False
            #user.set_password(data.get('n_pw'))
            user.password = make_sha2_password(data.get('n_pw'))
            user.save()

            user_profile.user_phone = data.get('phone')
            user_profile.user_mobile = data.get('mobile')
            user_profile.customer = customer
            user_profile.gmt_cd = data.get('tz')
            user_profile.save()

            telco_rel = TelcoUser.objects.get(user=user)
            telco_rel.type = data.get('type')
            telco_rel.admin_flag = data.get('is_admin')
            telco_rel.account = customer.account
            telco_rel.is_active = data.get('is_active')
            telco_rel.save()

            return user
        except:
            return False
    except:
        return False

def change_user_status(telco_user_ids=[], status=True):
    try:
        telco_uids = [long(uid) for uid in telco_user_ids]

        for uid in telco_uids:
            cur = TelcoUser.objects.get(telco_user=uid)
            cur.is_active = status
            cur.save()
        return True
    except:
        return False

def get_user_menu(request):
    nodes = []
    children = {}

    if request.user.is_superuser:
        # get all menu(privs)
        menus = TelcoMenuCD.objects.filter(use_flag=1)
    else:
        menus = [m for m in TelcoMenuCD.objects.filter(use_flag=1, menu_depth=1).order_by('sort_order')]
        opt_menus = [m.menu for m in TelcoMenuWhitelist.objects.select_related('telco_menu_cd') \
                                    .filter(menu__use_flag=1, user=request.user, menu__menu_depth__gt=1)\
                                    .order_by('menu__sort_order')]
        menus = menus + opt_menus
    for menu in menus:
        item = {
            'id' : menu.telco_menu_id,
            'menu_id': menu.master_menu_id.menu_id,
            'menu_name' : menu.master_menu_id.menu_name_en,
            'url' : reverse_link(menu.link_url),
            'leaf' : []
        }

        if request.user:
            try:
                menu_allow = menu.menu_set.get(user=request.user)
                if menu_allow :
                    checked = True
                else:
                    raise ObjectDoesNotExist
            except ObjectDoesNotExist:
                checked = False
        else:
            checked = False

        item.update({'checked': checked})

        if menu.master_menu_id.parent_menu_id:
            try:
                children[menu.master_menu_id.parent_menu_id].extend([item])
            except:
                children[menu.master_menu_id.parent_menu_id] = [item]
        else:
            nodes.extend([item])

    for i, node in enumerate(nodes):
        node_id = node['menu_id']
        nodes[i]['leaf'] = leaf_append(node_id, children)

    return nodes

def get_menu(*args, **kwargs):
    request = kwargs.pop('request', None)
    user = kwargs.pop('user', None)
    filtered = kwargs.pop('filtered', False)

    if filtered:
        # filter by request.user.customer.account
        menus = [m for m in TelcoMenuCD.objects.filter(use_flag=1, menu_depth=1).order_by('sort_order')]
        opt_menus = [m.menu for m in TelcoMenuWhitelist.objects.select_related('telco_menu_cd') \
                                    .filter(menu__use_flag=1, user=request.user, menu__menu_depth__gt=1)\
                                    .order_by('menu__sort_order')]
        menus = menus + opt_menus
    else:
        menus = TelcoMenuCD.objects.select_related('user_menu_set').filter(use_flag=1)
    nodes = []
    children = {}
    for menu in menus:
        item = {
            'id' : menu.telco_menu_id,
            'menu_id': menu.master_menu_id.menu_id,
            'menu_name' : menu.master_menu_id.menu_name_en,
            'url' : reverse_link(menu.link_url),
            'leaf' : []
        }

        if user:
            try:
                menu_allow = menu.menu_set.get(user=user)
                if menu_allow :
                    checked = True
                else:
                    raise ObjectDoesNotExist
            except ObjectDoesNotExist:
                checked = False
        else:
            checked = False

        item.update({'checked': checked})

        if menu.master_menu_id.parent_menu_id:
            try:
                children[menu.master_menu_id.parent_menu_id].extend([item])
            except:
                children[menu.master_menu_id.parent_menu_id] = [item]
        else:
            nodes.extend([item])

    for i, node in enumerate(nodes):
        node_id = node['menu_id']
        nodes[i]['leaf'] = leaf_append(node_id, children)

    return nodes

def leaf_append(node_id , children):
    leaf_nodes = []
    try:
        leaf_nodes = children[node_id]
        for i, leaf in enumerate(leaf_nodes):
            k = leaf['menu_id']
            leaf_nodes[i]['leaf'] = leaf_append(k, children)
    except:
        pass
    return leaf_nodes

def user_menu_update(request, user, newer_menu_ids=[]):
    n_ids = set([long(m.replace('m_', '')) for m in newer_menu_ids])
    o_ids = set([m.menu.telco_menu_id for m in TelcoMenuWhitelist.objects.select_related('telco_menu_cd')\
                                            .filter(menu__use_flag=True, user=user)])
    a_users = TelcoUser.objects.filter(account=user.get_profile().customer.account, admin_flag=1)
    if a_users.count() > 0 and request.POST.get('is_admin') != 'on' and request.user.is_superuser:
        a_ids = set([m.menu.telco_menu_id for m in TelcoMenuWhitelist.objects.select_related('telco_menu_cd')\
                                                .filter(menu__use_flag=True, user=a_users[0].user)])
        n_ids = n_ids & a_ids


    # filter add privs
    append_menu = list(set(n_ids) - set(o_ids))
    detach_menu = list(set(o_ids) - set(n_ids))

    remove_menu = TelcoMenuWhitelist.objects.filter(menu__telco_menu_id__in=detach_menu, user=user)
    remove_menu.delete()

    append_menu_set = TelcoMenuCD.objects.filter(telco_menu_id__in=append_menu)
    for set_menu in append_menu_set:
        m_rel = TelcoMenuWhitelist(menu=set_menu, user=user)
        m_rel.save(request=request)

    return True

def admin_menu_update(request, user, newer_menu_ids=[]):
    # first. Every admin(in same account) have same menus.
    # second. delete whitelist remove menu
    handle_account_no = user.get_profile().customer.account.account_no
    r_mid = [long(menu_id.replace('m_', '')) for menu_id in newer_menu_ids]
    remove_menus = TelcoMenuCD.objects.exclude(telco_menu_id__in=r_mid)

    remove_whitelist = TelcoMenuWhitelist.objects.filter(menu__telco_menu_id__in=remove_menus, \
                                    user__in=TelcoUser.objects.filter(account=handle_account_no).values('user'))
    remove_whitelist.delete()

    admins = TelcoUser.objects.filter(account=handle_account_no, admin_flag=True)
    for admin in admins:
        update_flag = user_menu_update(request, admin.user, newer_menu_ids)

    return True

def is_exists_auth_user(username):
    try:
        user = User.objects.get(username=username)
        return True
    except:
        return False
def filter_menu_ids(request):
    menus = [m.menu for m in TelcoMenuWhitelist.objects.select_related('telco_menu_cd') \
                                .filter(menu__use_flag=1, user=request.user, menu__menu_depth__gt=1)\
                                .order_by('menu__sort_order')]
    for menu_item in menus:
        yield str(menu_item.telco_menu_id)