from telco_fe import settings
from telco_fe.shared_components.middleware.http import Http403
from telco_fe.shared_components.utils.common import getSafeSessionValue
from telco_fe.shared_components.utils.menu import getMenuList
from django.http import Http404, HttpResponseForbidden, HttpResponseServerError, \
	HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.utils.translation import ugettext as _
from spectrum_fe.shared_components.utils.api import getOptionalParams


def render_page(request, error_code):
	if getSafeSessionValue(request, 'user_login_url') == settings.USER_LOGIN_LABEL :
		if error_code == '404': raise Http404()
		if error_code == '403': raise Http403()
	else :
		msg = title = None
		
		if error_code == '403':
			title = _(u'You are not authorized to view these pages.')
			msg = _(u"You are not authorized to view these pages.")+"<br />"+_(u"Please contact support at %(email)s.") % {'email':"<a href='mailto:support@cdnetworks.com'>support@cdnetworks.com</a>"};
		return render_to_response('error.html', RequestContext(request, {'msg':msg, 'title':title}))
	

def handler404(request):
	if getSafeSessionValue(request, 'user_login_url') == settings.USER_LOGIN_LABEL and request.user.is_authenticated():
		context = RequestContext(request)
		return render_to_response('404_standalone.html', context)
	else : 
		return render_to_response('404.html')

def handler403(request):
	if getSafeSessionValue(request, 'user_login_url') == settings.USER_LOGIN_LABEL and request.user.is_authenticated():
		context = RequestContext(request)
		return render_to_response('403_standalone.html', context)
	else : 
		return render_to_response('403.html')
def handler500(request):
	if getSafeSessionValue(request, 'user_login_url') == settings.USER_LOGIN_LABEL and request.user.is_authenticated():
		context = RequestContext(request)
		return render_to_response('500_standalone.html', context)
	else : 
		return render_to_response('500.html')