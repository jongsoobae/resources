from telco_fe import settings
from telco_fe.shared_components.decorators import menu_authority_required
from telco_fe.shared_components.models.acl_core import CustomerAccountWrapper
from telco_fe.shared_components.models.message_board import MessageBoard
from telco_fe.shared_components.utils.common import getSafeSessionValue

from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, EmptyPage, InvalidPage, \
	PageNotAnInteger
from django.shortcuts import render_to_response
from django.template.context import RequestContext
import logging
from msgboard import get_message_type
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse

log = logging.getLogger(__name__)

@login_required
def render_page(request):
    msg = 'Welcome to the customer portal.  Please use the navigation on the left to continue.'
    dashbaord_messages = MessageBoard.objects.filter(type=get_message_type()).order_by('-time_created')
    
    if dashbaord_messages.count() > 0:
        main_dashboard_message = dashbaord_messages[0]
    else :
        main_dashboard_message = None

    CONST_LIST_SCALE = 5
    CONST_PAGE_SCALE = 10
    paginator = Paginator(dashbaord_messages,CONST_LIST_SCALE)
    page = request.GET.get('p')
    
    try:
        page = int(page)
    except:
        page = 1

    try:
        message_items = paginator.page(page)
    except PageNotAnInteger:
        message_items = paginator.page(1)
    except EmptyPage:
        return HttpResponseRedirect(reverse('home')+'?p=%s'%(paginator.num_pages))

    time_format = 'l, F j, Y g:i A'

    start_idx = ((page-1)/CONST_PAGE_SCALE)*CONST_PAGE_SCALE
    page_range = message_items.paginator.page_range[start_idx:][:CONST_PAGE_SCALE]
    return render_to_response('home_standalone.html',
                    RequestContext(request, {'msg':msg,
                                            'dashbaord_messages' : message_items.object_list,
                                            'page' : message_items,
                                            'page_range' : page_range,
                                            'main_dashboard_message' : main_dashboard_message,
                                            'time_format' : time_format}))