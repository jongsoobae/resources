import logging
from django.conf import settings
from django.contrib.auth import logout, authenticate, login
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.utils.translation import ugettext as _
from spectrum_fe.shared_components.utils.api import corporationTextToCode
from telco_fe import settings
from telco_fe.shared_components.utils.acl_helper import getDefaultAccount
from telco_fe.manage.models.login_history import LoginHistory
from telco_fe.shared_components.models import UserProfile
from telco_fe.shared_components.models.acl_core import CustomerAccountWrapper
from telco_fe.shared_components.models.telco_user import TelcoUser
from telco_fe.shared_components.utils.telco_user_helper import isTelcoMember
from telco_fe.shared_components.utils.client_info import getClientBrowserInfo, \
    getClientOSInfo
from spectrum_fe.shared_components.utils.aquacrypto import encrypt
from spectrum_fe.ldap.open_ldap_mgmt import OpenLDAPManager
from spectrum_fe.shared_components.models.customer_ldap_user import CustomerLDAPUser,LDAP_SCOPE_LIST,LOGIN_APP_LIST
from django.core.exceptions import ValidationError

log = logging.getLogger(__name__)

# from prism_fe.shared_components.middleware.aclcore import get_entity_name_by_id
def render_page(request):
    auth_val = None
    user = None
    #need to handle whitelabeling appname and logurl according to sales vender. 
    appname = 'aurora'
    loginurl = '%s.cdnetworks.com' % (settings.TELCO_HOST_PREFIX)
    token = "appname=%s,loginurl=%s" % (appname,loginurl)
    #import urllib
    #token = urllib.quote(token, safe='/')    
    token = encrypt(token)
    reseturl = "%s.cdnetworks.com/manage/user/forgot_password?token=%s" % (settings.CONTROL_HOST_PREFIX, token)    
    # logout
    if request.POST:
        # send post data ...( need some action login or logout )
        if request.POST.get('logout'):
            if request.user:
                user = request.user
                action_type = LoginHistory.ACTION_TYPE_CHOICES.get('logout')
                user_agent = request.META.get('HTTP_USER_AGENT')
                user_browser = getClientBrowserInfo(user_agent)
                user_os = getClientOSInfo(user_agent)
                
                login_history = LoginHistory.objects.create(user=user, 
                                                            action_type=action_type, 
                                                            user_ip=request.META.get('REMOTE_ADDR'), 
                                                            user_browser=user_browser,
                                                            user_os=user_os)
                login_history.save()
            logout(request)
            auth_val = _("You've successfully logged out.")
            return HttpResponseRedirect(reverse('login'))
                                                    
        # login
        elif request.POST.get('login'):
            user = authenticate(username=request.POST['username'], 
                                password=request.POST['password']
                    )
            if user is not None:
                try :
                    if user.is_active:
                        login(request,user)
    
                        request.session['user_login_url'] = settings.USER_LOGIN_LABEL
                        action_type = LoginHistory.ACTION_TYPE_CHOICES.get('login')
                        user_agent = request.META.get('HTTP_USER_AGENT')
                        user_browser = getClientBrowserInfo(user_agent)
                        user_os = getClientOSInfo(user_agent)

                        # check telco user or superuser
                        if user.is_superuser:
                            pass
                        else:
                            #fetch prism api query: get ldap customer type
                            #ld = OpenLDAPManager()
                            #ldapuser = ld.getUserFromldapbyUserkey('aurora', str(user.pk))
                            
                            telco_user = isTelcoMember(user,UserProfile.objects.get(user=user).customer.account)

                            if telco_user.is_active is False:
                                logout(request)
                                auth_val = _('Login Denied: This Account was suspended.<br/>If you have a trouble please contact CDNetworks Customer Support Team.')
                                context = RequestContext(request, {'auth_val': auth_val,'reseturl':reseturl})
                                return render_to_response('login.html', context)
                            elif not user.is_integrated_contact_user:
                                #redirect to user edit page 
                                userprofile = UserProfile.objects.get(user=user)
                                if userprofile.erp_contact_key == None or len(userprofile.erp_contact_key.strip()) == 0:
                                    return HttpResponseRedirect("/configuration/users/myinfo") 
                            elif user.is_integrated_contact_user:
                                try:
                                    userprofile = UserProfile.objects.get(user=user)
                                    userprofile.erp_contact_key = user.contactno
                                    userprofile.save()
                                except:
                                    pass

                        
                        login_history = LoginHistory.objects.create(user=user, 
                                                                    action_type=action_type, 
                                                                    user_ip=request.META.get('REMOTE_ADDR'), 
                                                                    user_browser=user_browser,
                                                                    user_os=user_os)
                        login_history.save()

                        if request.GET.get('next'):
                            return HttpResponseRedirect(request.GET.get('next'))
                        else: 
                            return HttpResponseRedirect("/")
                    else:
                        if not user.is_validated_user:
                            token = "email=%s,appname=%s,loginurl=%s" % (user.email,
                                                                             'aurora',
                                                                             settings.TELCO_URL)                
                            #import urllib
                            #token = urllib.quote(token, safe='/')    
                            token = encrypt(token)
                            verifyurl = "%s.cdnetworks.com/manage/user/verify_email_request?token=%s" % (settings.CONTROL_HOST_PREFIX, token)      
                            return HttpResponseRedirect(verifyurl)                          
                except Exception as e :
                    logout(request)
                    log.exception("User login fail")
                    
                    auth_val = _('You are unable to login at this time. <br />Please try again later.')
            else:
                auth_val = _('Your username and/or password were incorrect.')
        else:
            if user is not None:
                auth_val = _('You are already logged in')

    context = RequestContext(request, {'auth_val': auth_val,'reseturl':reseturl})

    return render_to_response('login.html', context)