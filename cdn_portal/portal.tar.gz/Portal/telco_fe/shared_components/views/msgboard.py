# -*- coding: utf-8 -*-
"""
    Copyright (c) 2012 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Message Dashboard
"""
from telco_fe import settings
from telco_fe.shared_components.models.message_board import MessageBoard
from telco_fe.shared_components.utils.common import getSafeSessionValue
from datetime import datetime, timedelta, tzinfo
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.core.exceptions import PermissionDenied, ValidationError, \
	ValidationError, ObjectDoesNotExist
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect, Http404, HttpResponse
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.utils import simplejson
from django.utils.translation import ugettext as _
from spectrum_fe.shared_components.utils.api import getOptionalParams

#CONST_MSG_DATETIME_FORMAT='%A, %B %d, %Y %I:%M %p %z(%Z)'
CONST_MSG_DATETIME_FORMAT='%A, %B %d, %Y %I:%M %p'

CONST_SINGLECUSTOMER_TYPE=1
CONST_RESELLER_TYPE=2

MESSAGE_BOARD_TITLE_LIMIT_LEN=100
MESSAGE_BOARD_BODY_LIMIT_LEN=65535

def get_message_type():
    """
    aurora_fe (single customer) : 1
    telco_fe ( telco cdn ) : 2
    """
    if settings.PROJECT_NAME == 'telco_fe':
        message_type = CONST_RESELLER_TYPE
    else :
        message_type = CONST_SINGLECUSTOMER_TYPE

    return message_type

@login_required
def message_add(request):
    if request.user.is_superuser:
        title = request.POST.get('msg_title',None)
        msg_body = request.POST.get('msg_body',None)
        urgent = request.POST.get('urgent',False)

        if title is None or title == '':
            result = {
                'result': False,
                'message' : _('Empty Message Title'),
                'data' : None
            }
            return HttpResponse(simplejson.dumps(result),mimetype='json/application')
        else:
            if title.__len__() > MESSAGE_BOARD_TITLE_LIMIT_LEN:
                result = {
                    'result': False,
                    'message' : _('Message board TITLE length should be less than %s bytes.'%MESSAGE_BOARD_TITLE_LIMIT_LEN),
                    'data' : None
                }
                return HttpResponse(simplejson.dumps(result),mimetype='json/application')

        if msg_body is None or msg_body == '':
            result = {
                'result': False,
                'message' : _('Empty Messages.'),
                'data' : None
            }
            return HttpResponse(simplejson.dumps(result),mimetype='json/application')
        else:
            if msg_body.__len__() > MESSAGE_BOARD_BODY_LIMIT_LEN:
                result = {
                    'result': False,
                    'message' : _('Message board Message length should be less than %s bytes.'%MESSAGE_BOARD_BODY_LIMIT_LEN),
                    'data' : None
                }
                return HttpResponse(simplejson.dumps(result),mimetype='json/application')

        if urgent == '1':
            urgent_flag = True
        else :
            urgent_flag = False

        message_type = get_message_type()

        try:
            msg = MessageBoard(user=request.user , title=title, message=msg_body,urgent=urgent_flag,type=message_type)
            msg.save()
            result = {
                'result': True,
                'message' : 'Success',
                'data' : {
                    'msg' : "msg-%s"%msg.pk,
                    'msg_title' : title,
                    'msg_body' : msg_body,
                    'urgent' : urgent_flag,
                    'time_t' : msg.time_created.strftime(CONST_MSG_DATETIME_FORMAT),
                    'user' : request.user.username
                    }
            }
        except Exception ,e:
            result = {
                'result': False,
                'message' : str(e),
                'data' : None
            }
    else:
        result = {
            'result': False,
            'message' : _('You have not a permissions.'),
            'data' : None
        }
    return HttpResponse(simplejson.dumps(result),mimetype='json/application')

@login_required
def message_update(request):
    if request.user.is_superuser:
        msg_id = request.POST.get('msg_id',None)
        title = request.POST.get('msg_title',None)
        msg_body = request.POST.get('msg_body',None)
        urgent = request.POST.get('urgent',False)

        if title is None or title == '':
            result = {
                'result': False,
                'message' : _('Empty Message Title'),
                'data' : None
            }
        if title.__len__() > MESSAGE_BOARD_TITLE_LIMIT_LEN:
            result = {
                'result': False,
                'message' : _('Message board TITLE length should be less than %s bytes.'%MESSAGE_BOARD_TITLE_LIMIT_LEN),
                'data' : None
            }
            return HttpResponse(simplejson.dumps(result),mimetype='json/application')
                        

        if msg_body is None or msg_body == '':
            result = {
                'result': False,
                'message' : _('Empty Messages.'),
                'data' : None
            }

        if urgent == '1':
            urgent_flag = True
        else :
            urgent_flag = False
            
        message_type = get_message_type()

        try:
            msg_id = int(msg_id.replace('msg-',''))
            msg = MessageBoard.objects.get(msg=msg_id)

            msg.user    = request.user
            msg.title   = title
            msg.message = msg_body
            msg.urgent  = urgent_flag
            msg.type    = message_type
            msg.save()

            result = {
                'result': True,
                'message' : _('Success'),
                'data' : {
                    'msg' : "msg-%s"%msg.pk,
                    'msg_title' : title,
                    'msg_body' : msg_body,
                    'urgent' : urgent_flag,
                    'time_t' : msg.time_created.strftime(CONST_MSG_DATETIME_FORMAT),
                    'user' : request.user.username
                    }
            }
        except ObjectDoesNotExist:
            result = {
                'result': False,
                'message' : _('Invalid Message ID(Not exists)'),
                'data' : None
            }
        except:
            result = {
                'result': False,
                'message' : _('Insert Failed'),
                'data' : None
            }
    else:
        result = {
            'result': False,
            'message' : _('You have not a permissions.'),
            'data' : None
        }
    return HttpResponse(simplejson.dumps(result),mimetype='json/application')

@login_required
def message_remove(request):
    if request.user.is_superuser:
        request_id = request.GET.get('msg_id',None)
        try:
            msg_id = int(request_id.replace('remove-',''))

            msg = MessageBoard.objects.get(msg=msg_id)
            msg.delete()
            
            result = {
                'result': True,
                'message' : _('Success'),
                'data' : []
            }
        except ObjectDoesNotExist:
            result = {
                'result': False,
                'message' : _('Message is deleted'),
                'data' : None
            }
        except:
            result = {
                'result': False,
                'message' : _('Invalid Message ID'),
                'data' : None
            }
    else:
        result = {
            'result': False,
            'message' : _('You have not a permissions.'),
            'data' : None
        }

    return HttpResponse(simplejson.dumps(result),mimetype='json/application')

@login_required
def message_get(request):
    request_id = request.GET.get('msg_id',None)
    try:
        msg_id = int(request_id.replace('msg-',''))
        message_type = get_message_type()

        msg = MessageBoard.objects.get(msg=msg_id,type=message_type)
        result = {
            'result': True,
            'message' : 'Success',
            'data' : [{
                'msg' : "msg-%s"%msg.msg,
                'msg_title' : msg.title,
                'msg_body' : msg.message,
                'urgent' : msg.urgent,
                'time_t' : msg.time_created.strftime(CONST_MSG_DATETIME_FORMAT),
                'user': msg.user.username
            }]
        }
    except ObjectDoesNotExist:
        result = {
            'result': False,
            'message' : _('Invalid Message ID(Not exists)'),
            'data' : None
        }
    except:
        result = {
            'result': False,
            'message' : _('Invalid Message ID'),
            'data' : None
        }

    return HttpResponse(simplejson.dumps(result),mimetype='json/application')