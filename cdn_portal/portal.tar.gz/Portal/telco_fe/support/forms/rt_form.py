from django import forms
from django.utils.safestring import mark_safe
from django.utils.translation import ugettext_lazy as _, string_concat
import re
from telco_fe.rt_config_constants import SUPPORT_TYPE

REGEX_PHONE_NUMBER = r'^[0-9-+(). ]+$'
regex_phone_number = re.compile(REGEX_PHONE_NUMBER)

class RTForm(forms.Form):
    subject = forms.CharField(label= _("Subject"),
                max_length=255,
                error_messages={'required':'Subject is required.'},
                widget=forms.TextInput(attrs={'class':'input-text'}))
    support_type = forms.ChoiceField(
                                   label=_('Support Type'),
                                   choices=SUPPORT_TYPE,
                                   widget=forms.Select()
                                   )
    is_this_urgent = forms.BooleanField(required=False,
                                    label="Urgent?",
                                    widget=forms.CheckboxInput())
    
    phone_number = forms.CharField(label= _('Phone number'),
                                widget=forms.TextInput(attrs={'class':'input-text'}))
    
    content = forms.CharField(label=_("Content"), 
                max_length=1000,
                error_messages={'required':'Content is required.'},
                widget=forms.Textarea\
                    (attrs={'style':'width:100%; height:200px;'}))
    
    attachment = forms.FileField(required=False, label=_('Attachment'))
    
    def clean_phone_number(self):
        super(RTForm, self).clean()
        phone_number = self.cleaned_data.get('phone_number').strip()
        if not regex_phone_number.match(phone_number):
            raise forms.ValidationError(_('Invalid phone number.'))
        if phone_number.find('--') >= 0:
            raise forms.ValidationError(_('Invalid phone number.( -- is invalid pattern]'))
        return phone_number

class CreateReplyForm(forms.Form):
    reply_attachment = forms.FileField(label=_('Attachment'), required=False)
    reply_content = forms.CharField(label=mark_safe(string_concat( _('Content'),"<b class='required-field'> *</b>")),
                                    max_length=1000,
                error_messages={'required':_('Content for reply is required')},
                widget=forms.Textarea(attrs={'style':'width:100%; height:200px;'}))