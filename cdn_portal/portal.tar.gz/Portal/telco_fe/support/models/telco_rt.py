# -*- coding: utf-8 -*-
"""
    Copyright (c) 2012 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Telco RT Set
"""
from django.db import models
from spectrum_fe.shared_components.models.customer import CustomerAccount

class TelcoRtSet(models.Model):
    account = models.ForeignKey(CustomerAccount,null=False,db_column="account_no")
    prefix = models.CharField(max_length=255, null=False)
    queue_no = models.PositiveSmallIntegerField(null=False)
    queue_name = models.CharField(max_length=255, null=False)
    email = models.CharField(max_length=100, null=False)
    desc = models.CharField(max_length=255, null=True)
    
    class Meta:
        db_table = 'telco_rt_set'
