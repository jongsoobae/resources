from django import template

register = template.Library()

def showticket(value):
    return value[7:] if value else 0

def rt_content_filter(value):
    return value.replace("No Subject", "")

def tobr(value):
    return value.replace('\n', '<br />')

def get_support_type(value):
    return value.get('cf.{telco support type}', '')

register.filter('showticket', showticket)
register.filter('rt_content_filter', rt_content_filter)
register.filter('tobr', tobr)
register.filter('get_support_type', get_support_type)