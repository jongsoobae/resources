from django.conf.urls.defaults import *

# RT Support
urlpatterns = patterns('telco_fe.support.views',
    url(r'^customers/$', 'customers.customer_list', name='customer_list'),
    url(r'^tickets/$', 'rt_tickets.ticket_list', name='ticket_list'),
    url(r'^tickets/view/(?P<ticket>\d+)/$', 'rt_tickets.ticket_view', name='ticket_view'),
    url(r'^tickets/create/$', 'rt_tickets.create_ticket', name='ticket_create' ),
    url(r'^ajax/file/(?P<ticket>\d+)/$', 'rt_tickets.ajax_file_upload', name='ticket_ajax_file_upload'),
    url(r'^ajax/edit/ticket/(?P<ticket>\d+)/$', 'rt_tickets.ajax_edit_ticket', name='ticket_ajax_edit'),
    url(r'^ajax/change_status/ticket/(?P<ticket>\d+)/$', 'rt_tickets.ajax_change_status', name='ticket_ajax_change_status'),
)

