import cookielib
import urllib2
import urllib
from telco_fe.config_constants import RT_LOGIN_ID, RT_LOGIN_PWD, RT_SERVER
import rfc822
import StringIO
from django.core.mail import send_mail
from django.conf import settings
import traceback
from django.utils.encoding import smart_str
from spectrum_fe.shared_components.utils.common import log_error
from telco_fe.support.models.telco_rt import TelcoRtSet
from django.http import Http404

def prefix_manage(msg, prefix, action='a'):
    it = smart_str(msg).find(smart_str(prefix))
    if it == 0:
        return msg[len(smart_str(prefix))+1:]
    else:
        return msg    

def get_rtObj(def_account):
    retRT = None
    try:
        retRT = TelcoRtSet.objects.get(account=def_account)
    except:
        pass
   
    return retRT

def get_rt_response():
    """ this opens RT connection """
    access_user = RT_LOGIN_ID
    access_password = RT_LOGIN_PWD
    uri = RT_SERVER

    cj = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    urllib2.install_opener(opener)
    data = {'user':access_user, 'pass':access_password}
    ldata = urllib.urlencode(data)
    login = urllib2.Request(uri, ldata)
    response = urllib2.urlopen(login)
    return response

def parsing_return_cc_data(str):
    if str.strip() != '' :
        temp_list = str.splitlines()
        cnt = 0
        middle_str = ''
        begin_str = []
        end_str = []
        cc_start = False
        ret_str = ''
        for q in temp_list:
            if q[:3] == "Cc:":
                cc_start = True
                begin_str = temp_list[:cnt]  
            elif q[:8] == "AdminCc:":
                cc_start = False
                end_str = temp_list[cnt:]
            if cc_start:
                middle_str = middle_str + q.strip()
            cnt = cnt + 1
        for q in begin_str:
            if q != '':
                ret_str = ret_str + q + '\n'
        ret_str = ret_str + middle_str + '\n'
        for q in end_str:
            ret_str = ret_str + q + '\n'
        return ret_str
    else :
        return str
    
def get_rt_list(request, requestor, status, queue, prefix=''):
    try:
        response = get_rt_response()
        queue_set = " OR ".join(["Queue='%s'" % v for k, v in queue] )
        status_set = " OR ".join(["status='%s'"% v for v in status ])
        strquery = "({queues}) AND (Requestors = '{requestor}') AND ({status})"
        data = {'query':strquery.format(queues=queue_set,
                                        requestor=requestor,
                                        status=status_set
                                        ),
                'orderby':'-Created',
                'format':'l'}
        encoded_data = urllib.urlencode(data)
        #print encoded_data
        #print RT_SERVER
        response2 = urllib2.urlopen(RT_SERVER+"search/ticket", encoded_data)
        result = response2.read()
        
        result_list = result.split('--')
        
        result_parsed = []
        for rl in result_list:
            rl_clean = rl[rl.find('id:'):]
            rl_clean = parsing_return_cc_data(rl_clean)
            rl_dict = dict(rfc822.Message(StringIO.StringIO(rl_clean)).items())
            if len(rl_dict) == 0:
                continue            
            rl_dict['subject'] = prefix_manage(rl_dict['subject'], prefix)
            result_parsed.append(rl_dict)
    except Exception as e:
        title= 'Loading RT list page failed due to communication with RT server'
        message='HTTP HOST: {host}\nSERVER NAME: {server}\n\nLoading RT list page failed due to communication with RT server\n\n'.\
                format(host=request.get_host(),server=request.META['SERVER_NAME'])
        log_error(request,message,e,None,title)
    return result_parsed

def create_rt(request, requestor, existing_ticket, queue, subject, content, phone_number, is_urgent, support_type, prefix=''):
    ticket_number = 0
    try:
        response = get_rt_response()
        if not existing_ticket:
            text_field = 'Text: '+smart_str(content).replace('\n', '\n         ')+'\n'
            title_field = smart_str('Subject: '+prefix+' '+subject + '\n') 
        else:
            text_field = ''
            title_field = smart_str('Subject: '+prefix+' '+subject + '\n') 
        params = {'content':'id: ticket/new\nQueue: '+queue+\
                  '\nRequestors: {requestor}\n'.format(requestor=requestor) +\
                  'Status: new\n'+\
                  title_field+\
                  text_field+\
                  'CF.{phone_number_key}: {phone_number}\n'.format(phone_number = phone_number, phone_number_key = "{Phone Number}")+\
                  'CF.{telco_support_type}: {support_type}\n'.format(support_type=support_type,telco_support_type="{telco support type}")+\
                  'CF.{is_urgent_key}: {is_urgent}\n'.format(is_urgent = str(is_urgent), is_urgent_key = "{Is Urgent}")}
        postdata = urllib.urlencode(params)
        if existing_ticket:
            response2 = urllib2.urlopen(RT_SERVER+'ticket/'+existing_ticket+'/edit', postdata)
            ticket_number = response2.read()
        else:
            response2 = urllib2.urlopen(RT_SERVER+'ticket/new', postdata)
            ticket_return = response2.read()
            ticket_number = int(ticket_return[ticket_return.find('Ticket')+7:\
                                              ticket_return.find('created')-1])
    except Exception as e:
        title='Creating RT failed due to communication with RT server'
        message='HTTP HOST: {host}\nSERVER NAME: {server}\n\nCreating RT failed due to communication with RT server\n\nStack Trace:\n{trace}'.format(host=request.get_host(),
                                                                                                                                                      server=request.META['SERVER_NAME'],
                                                                                                                                                      trace=traceback.format_exc(e))
        log_error(request,message,e,None,title)
    return ticket_number

def create_reply(request, ticket, content):
    result = ''
    try:
        response = get_rt_response()
        data = {"content":"id: {ticket}\n".format(ticket=ticket)+\
                "Action: correspond\n"+\
                "Text: " + smart_str(content).replace('\n', '') + "\n"}
        postdata = urllib.urlencode(data)
        response2 = urllib2.urlopen(RT_SERVER + 'ticket/'+ticket+'/comment', postdata)
        result = response2.read()
    except Exception as e:
        title='Creating RT reply failed due to communication with RT server'
        message='HTTP HOST: {host}\nSERVER NAME: {server}\n\nCreating RT reply failed due to communication with RT server\n\nStack Trace:\n{trace}'.format(host=request.get_host(),
                                                                                                                                                      server=request.META['SERVER_NAME'],
                                                                                                                                                      trace=traceback.format_exc(e))
        log_error(request,message,e,None,title)
    return result

def get_rt_detail(request, ticket):
    try:
        response = get_rt_response()
        response_ticket_detail = urllib2.urlopen(RT_SERVER + 'ticket/' + ticket + '/show')
        response_ticket_history = urllib2.urlopen(RT_SERVER + 'ticket/' + ticket + '/history?format=l')
        
        result = response_ticket_detail.read()
        result_history = response_ticket_history.read()
        
        result = result[result.find('id:'):]
        result_history = result_history[result.find('id:'):]
        result_history_list = result_history.split('--')
        result = parsing_return_cc_data(result)
        result_parsed = dict(rfc822.Message(StringIO.StringIO(result)).items())

        result_history_parsed = []
        for rh in result_history_list:
            rh_clean = rh.replace('\n\n\n', '\n').replace('\n\n', '\n')
            rh_clean = rh_clean[rh_clean.find('id:'):]
            if rh_clean.find('Type: Correspond') != -1 or rh_clean.find('Type: Create') != -1:
                rh_clean_obj = dict(rfc822.Message(StringIO.StringIO(rh_clean)).items())
                result_history_parsed.append(rh_clean_obj)
                
    except Exception as e:
        title='Loading RT detail page failed due to communication with RT server'
        message='HTTP HOST: {host}\nSERVER NAME: {server}\n\nLoading RT detail page failed due to communication with RT server\n\n'.format(host=request.get_host(),server=request.META['SERVER_NAME'])
        log_error(request,message,e,None,title)
    return result_parsed, result_history_parsed

def change_status(request,ticket):
    status = request.POST.get('status', '')
    result = None
    try:
        response = get_rt_response()
        data = {"content":"id: {ticket}\n".format(ticket=ticket)+\
                "Status: {status}\n".format(status=status)}
        postdata = urllib.urlencode(data)
        response2 = urllib2.urlopen(RT_SERVER+'ticket/'+ticket+'/edit', postdata)
        result = response2.read()
    except Exception as e:
        title='Changing RT status failed due to communication with RT server'
        message='HTTP HOST: {host}\nSERVER NAME: {server}\n\nChanging RT status failed due to communication with RT server\n\nStack Trace:\n{trace}'.format(host=request.get_host(),
                                                                                                                                                      server=request.META['SERVER_NAME'],
                                                                                                                                                      trace=traceback.format_exc(e))
        log_error(request,message,e,None,title)
    return result