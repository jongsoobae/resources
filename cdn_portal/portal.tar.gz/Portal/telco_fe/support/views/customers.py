# -*- coding: utf-8 -*-
"""
    Copyright (c) 2012 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Support > Customers
"""

from datetime import datetime
from django import forms
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.core.exceptions import PermissionDenied, ValidationError, \
    ValidationError, ObjectDoesNotExist
from django.core.paginator import Paginator, EmptyPage, InvalidPage, \
    PageNotAnInteger
from django.core.urlresolvers import reverse
from django.db.models import Q
from django.forms.formsets import formset_factory
from django.http import HttpResponseRedirect, Http404, HttpResponse
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.utils import simplejson
from django.utils.translation import ugettext as _
from django.views.generic.edit import CreateView

from spectrum_fe.shared_components.models.customer import CustomerContract

from telco_fe import settings
from telco_fe.shared_components.decorators import is_authorized
from telco_fe.shared_components.models import UserProfile
from telco_fe.shared_components.utils.aquacrypto import encrypt
from telco_fe.shared_components.utils.telco_user_helper import isTelcoMember,\
                                                        telcoMembers,checkAllowAccount,\
                                                        telcoAllMembers,create_member

@login_required
@is_authorized
def customer_list(request):
    account = checkAllowAccount(request.user)

    if request.user.is_superuser:
        if request.session.get('admin_aquired') and request.session.get('admin_aquired') != '':
            account = request.session.get('admin_aquired')
            contracts = CustomerContract.objects.filter(telco_account_no=account.account_no)
        else:
            contracts = CustomerContract.objects.filter(telco_account_no__isnull=False)
    else:
        contracts = CustomerContract.objects.filter(telco_account_no=account)
    customer_accounts = set([c.account for c in contracts])
    
    encrypt_username = encrypt(request.user.username)
    encrypt_password = encrypt(request.user.password)
    ocsp={}
    for c in contracts:
        try:
            account = c.account.account_no
            ocsp[account].extend([(get_ocsp_host(c.ocsp_region),get_ocsp_flag(c.ocsp_region))])
        except:
            ocsp[account] = [(get_ocsp_host(c.ocsp_region),get_ocsp_flag(c.ocsp_region))]
    dict_ocsp_link = [{'account': a , 'links': list(set(ocsp[a.account_no]))}for a in customer_accounts]
    context = RequestContext(request,{'customers':customer_accounts,
                                    'ocsp' : dict_ocsp_link,
                                    'login_encrypt_username':encrypt_username,
                                    'login_encrypt_password':encrypt_password})
    return render_to_response('customers.html', context)

def get_ocsp_host(region=4000):
    if settings.DEBUG:
        if region == 1000 :
            ocsp_host = "https://ocspdev.kr.cdnetworks.com"
        elif region == 2000 :
            ocsp_host = "https://ocspdev.jp.cdnetworks.com"
        elif region == 3000 :
            ocsp_host = "https://ocspdev.cn.cdnetworks.com"
        else :
            ocsp_host = "https://ocspdev.us.cdnetworks.com"
    else:
        if region == 1000 :
            ocsp_host = "https://ocsp.kr.cdnetworks.com"
        elif region == 2000 :
            ocsp_host = "https://ocsp.jp.cdnetworks.com"
        elif region == 3000 :
            ocsp_host = "https://ocsp.cn.cdnetworks.com"
        else :
            ocsp_host = "https://ocsp.us.cdnetworks.com"

    return ocsp_host

def get_ocsp_flag(region=1000):
    if region == 1000 :
        ocsp_region = _("kr")
    elif region == 2000 :
        ocsp_region = _("jp")
    elif region == 3000 :
        ocsp_region = _("cn")
    else :
        ocsp_region = _("us")

    return ocsp_region