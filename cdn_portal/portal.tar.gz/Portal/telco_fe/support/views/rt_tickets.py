# -*- coding: utf-8 -*-

from django.contrib.auth.decorators import login_required
from django.core.mail.message import EmailMessage
from django.core.urlresolvers import reverse
from django.http import Http404, HttpResponse, HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.utils import simplejson

from telco_fe.rt_config_constants import RT_OPEN_STATUS, RT_CLOSED_STATUS, \
    SUPPORT_TYPE
from telco_fe.settings import IS_DEV_CONF
from telco_fe.shared_components.decorators import is_authorized
from telco_fe.support.forms.rt_form import RTForm, CreateReplyForm
from telco_fe.support.utils.rt_utils import get_rt_list, create_rt, \
    get_rt_detail, create_reply, change_status, prefix_manage, get_rtObj

from spectrum_fe.shared_components.utils.common import log_error
import traceback

from telco_fe.support.models.telco_rt import TelcoRtSet
from telco_fe.shared_components.utils.acl_helper import getDefaultAccount
from telco_fe.shared_components.middleware.http import Http403

@login_required
@is_authorized
def ticket_list(request):

    status = request.POST.get('status', 'open')
    if status not in ['open', 'resolved']:
        raise Http404
    curr_status = RT_OPEN_STATUS
    if status == 'resolved':
        curr_status = RT_CLOSED_STATUS
    
    def_account = getDefaultAccount(request)  
    obj = get_rtObj(def_account)
    if obj == None:
        raise Http403
    
    q_list = [(obj.queue_no,str(obj.queue_name))]
    
    ticket_list = get_rt_list(request,request.user.username, curr_status, q_list, obj.prefix)

    context = RequestContext(request,{'result':ticket_list,
                                      'status':status
                                      })
    return render_to_response('tickets_list.html', context)

@login_required
def ticket_view(request, ticket):
    result, result_history = get_rt_detail(request,ticket)
    reply_form = CreateReplyForm(label_suffix="")
    is_this_urgent = False
    is_reply_error = False

    def_account = getDefaultAccount(request)
    obj = get_rtObj(def_account)
    
    if request.POST and request.POST.has_key('submit_reply'):
        reply_form = CreateReplyForm(request.POST)
        if reply_form.is_valid():
            result_reply = create_reply(request, 
                                        ticket, 
                                        reply_form.cleaned_data.get('reply_content'))
            
            try:
                if request.FILES.get('reply_attachment'):
                    attach = request.FILES['reply_attachment']
                    if IS_DEV_CONF:
                        rt_email = 'jungho.park@cdnetworks.co.kr'
                    else:
                        rt_email = obj.email
                        #rt_email = RT_QUEUE_EMAIL.get('Telco Portal')
                    email = EmailMessage('[CDNetworks #'+ticket+'] RT Attachment', '', 'portaladmin@cdnetworks.com',[rt_email])
                    email.attach(attach.name, attach.read(), attach.content_type)
                    email.send()
            except Exception as e:
                title='Ticket Tracker Reply add to Attach File failed'
                message='HTTP HOST: {host}\nSERVER NAME: {server}\n\nChanging RT status failed due to communication with RT server\n\nStack Trace:\n{trace}'.format(host=request.get_host(),
                                                                                                                                                      server=request.META['SERVER_NAME'],
                                                                                                                                                      trace=traceback.format_exc(e))
                log_error(request,message,e,None,title)
            return HttpResponseRedirect(reverse('ticket_view', args=[ticket]))
        else:
            is_reply_error = True;
    if result.get('cf.{is urgent}','') == 'True':
        is_this_urgent = True
    dict_support_type = dict((v, k) for k, v in dict(SUPPORT_TYPE).iteritems())
    selected_support_type = dict_support_type.get(result.get('cf.{telco support type}','1'))
    #form = RTForm(initial={'subject':result.get('subject', '')+"1",
    
    
    
    form = RTForm(initial={'subject':prefix_manage(result.get('subject', ''), obj.prefix),
                           'phone_number':result.get('cf.{phone number}', ''),
                           'support_type':selected_support_type,
                           'content':result_history[0].get('content'),
                           'is_this_urgent':is_this_urgent
                           })
    context = RequestContext(request,{'form':form,
                                      'ticket_number':ticket,
                                      'result':result,
                                      'result_history': result_history,
                                      'reply_form':reply_form,
                                      'is_reply_error':is_reply_error
                                      })
    return render_to_response('tickets_view.html', context)

@login_required
@is_authorized
def create_ticket(request):
    ticket_number = None
    if request.POST and request.is_ajax():
        form = RTForm(request.POST, request.FILES)
        if form.is_valid():
            dict_support_type = dict(SUPPORT_TYPE)
            select_support_type = dict_support_type.get(form.cleaned_data.get('support_type'))

            def_account = getDefaultAccount(request)
            obj = get_rtObj(def_account)
            
            q_list = [(obj.queue_no,str(obj.queue_name))]
            
            queue_list = [v for k,v in dict(q_list).iteritems()]
            
            queue = queue_list.pop()
            ticket_number = create_rt(request, 
                                  request.user.username, 
                                  None, 
                                  queue, 
                                  form.cleaned_data.get('subject'),
                                  form.cleaned_data.get('content'),
                                  form.cleaned_data.get('phone_number'),
                                  form.cleaned_data.get('is_this_urgent'),
                                  select_support_type,
                                  prefix=obj.prefix)
            json_str = {'factor':'success', 'ticket':ticket_number}
        else:
            json_str = {'factor':'error','form_json':form._errors}
        json = simplejson.dumps(json_str)
        return HttpResponse(json, mimetype="application/json")
    else:
        form = RTForm()
    return render_to_response('tickets_create.html', RequestContext(request, {'form':form, 
                                                                              'ticket_number':ticket_number} ))

def ajax_file_upload(request, ticket):

    def_account = getDefaultAccount(request)
    obj = get_rtObj(def_account)

    try:
        attach = request.FILES['attachment']
        if IS_DEV_CONF:
            rt_email = 'jungho.park@cdnetworks.co.kr'
        else:
            rt_email = obj.email
        email = EmailMessage('[CDNetworks #'+ticket+'] RT Attachment', '', 'portaladmin@cdnetworks.com',[rt_email])
        email.attach(attach.name, attach.read(), attach.content_type)
        email.send()
        json_context = {'factor':'success'}
    except Exception as e:
        json_context = {'factor':'error'}
    json = simplejson.dumps(json_context)
    return HttpResponse(json, mimetype="text/html") 

def ajax_edit_ticket(request, ticket):
    form = RTForm(request.POST)
    
    def_account = getDefaultAccount(request)
    obj = get_rtObj(def_account)
    
    if form.is_valid():
        dict_support_type = dict(SUPPORT_TYPE)

        queue_list = [str(obj.queue_name)]
        queue = queue_list.pop()
        select_support_type = dict_support_type.get(form.cleaned_data.get('support_type'))
        ticket_number = create_rt(request, 
                                  request.user.username, 
                                  ticket, 
                                  queue, 
                                  form.cleaned_data.get('subject'),
                                  form.cleaned_data.get('content'),
                                  form.cleaned_data.get('phone_number'),
                                  form.cleaned_data.get('is_this_urgent'),
                                  select_support_type,
                                  prefix=obj.prefix)
        json_str = {'factor':'success', 'ticket':ticket_number}
    else:
        json_str = {'factor':'error','form_json':form._errors}
    json = simplejson.dumps(json_str)
    return HttpResponse(json, mimetype="application/json")

def ajax_change_status(request, ticket):
    result = change_status(request,ticket)
    if result:
        json_context = {'factor':'success'}
    else:
        json_context = {'factor':'error'}
    json = simplejson.dumps(json_context)
    return HttpResponse(json, mimetype="application/json")