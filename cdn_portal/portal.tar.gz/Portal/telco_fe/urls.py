###############################################################################
# For any changes needed, please contact ENG-UI@cdnetworks.com
# Approval is needed for any modification
#------------------------------------------------------------------------------
# Note: When creating new application, please add urls.py under your application
# directory and "include" it in this file
###############################################################################

from django.conf import settings
from django.conf.urls.defaults import *

js_info_dict = {
	'packages': ('django.conf',
				'spectrum_fe',
				'telco_fe',)
}

urlpatterns = patterns('',
	(r'^op_media/(?P<entity>[^/]*)/(?P<i18n>[^/]*)/(?P<path>.*)$', 'spectrum_fe.shared_components.views.media_urls', {'document_root': settings.MEDIA_ROOT, 'spectrum_root':settings.SPECTRUM_MEDIA_ROOT}),
	(r'^i18n/', include('django.conf.urls.i18n')),
	(r'^jsi18n/$', 'django.views.i18n.javascript_catalog', js_info_dict),
	url(r'^error_msg/(?P<error_code>\d+)$', 'telco_fe.shared_components.views.error.render_page', name='error'),
)

# Application Urls - ordered alphabetically
urlpatterns += patterns('',
	(r'^configuration/', include('telco_fe.configuration.urls')),
	(r'^rt_support/', include('telco_fe.support.urls')), # Ticket Tracker
	(r'^', include('telco_fe.shared_components.urls')), # Shared Components
	(r'^manage/', include('telco_fe.manage.urls')), #manage
	(r'^monitoring/', include('telco_fe.monitoring.urls')),
	(r'^support/', include('telco_fe.support.urls')),

)

handler404 = 'telco_fe.shared_components.views.error.handler404'
handler500 =  'telco_fe.shared_components.views.error.handler500'
handler403 =  'telco_fe.shared_components.views.error.handler403'
