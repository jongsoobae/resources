# -*- coding: latin-1 -*-

WHITE_LABEL = 'cdnetworks_standalone'

WHITE_LABEL_MAPPER = [
{'default':1, 'domain_name':'aurora-dev2.cdnetworks.com', 'logo':'logo.png', 'css':'',
    'general_info':'<li>+1877-yes 4cdn</li><li><a href="mailto:info@cdnetworks.com">info@cdnetworks.com</a></li>', 
    'support_info':'<li>+1877-yes 4cdn</li><li><a href="mailto:info@cdnetworks.com">info@cdnetworks.com</a></li>', 
    'copyright':'Copyright�2012 CDNetworks Inc. All Rights Reserved',
    'footer':u'Customer Support Center (CSC) : <a href="mailto:support@cdnetworks.com">support@cdnetworks.com</a> +1-408-228-3455'
},
{'domain_name':'auroramegafon-dev2.cdnetworks.com', 'logo':'megafon/logo.png', 'css':'megafon/whitelabel.css',
    'general_info':'<li>megafon +1877-yes 4cdn</li><li><a href="mailto:info@cdnetworks.com">info@cdnetworks.com</a></li>',  
    'support_info':'<li>megafon +1877-yes 4cdn</li><li><a href="mailto:info@cdnetworks.com">info@cdnetworks.com</a></li>', 
    'copyright':'Copyright: 2011 OJSC MegaFon',
    'footer':u'Customer Support Center (CSC) : <a href="mailto:support@cdnetworks.com">support@cdnetworks.com</a>  +1-408-228-3455'
},
]
