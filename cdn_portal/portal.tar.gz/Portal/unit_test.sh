#!/bin/bash

function helpmessage(){
    echo "Usage: $0 -r [ release_num ] -p [ ticket ]"
    echo
    echo "   -h, --help                 help messages"
    echo "   -r, --release              release number"
    echo "   -t, --ticket               ticket"
    exit 0;
}

VENV_DEV=venv_dev
NOSETESTS=$VENV_DEV/bin/nosetests
DIR_NAME='unit_tests'

function nose_tests(){
    filelist=$1
    ticket=$2
    for filepath in $filelist; do
        echo "FILE PATH : $filepath"
        r_filename=`echo $filepath | rev | cut -d/ -f1 | rev`
        test_dir=`echo $filepath | grep "tests"`
        if [ -z "$test_dir" ]
        then
            echo "NO TEST FILE"
            continue
        fi
        parent_path=$(echo $filepath | awk -F / '{ print $1 }')
        result_filepath=$DIR_NAME/$ticket$r_filename".xml"
        echo "RESULT FILE PATH : $result_filepath"
        if [ $parent_path = "spectrum_fe" ]
        then
            $NOSETESTS $filepath --with-xunit --xunit-file=$result_filepath
        else
            $NOSETESTS $filepath --set-env-variables="{'DJANGO_SETTINGS_MODULE':'$parent_path.settings'}" --with-xunit --xunit-file=$result_filepath
        fi
    done
}

key="$1"
RELEASE=""
TICKET=""

case $key in
    -h|--help)
        helpmessage
    shift # past argument
    ;;
    -r|--release)
    if [ "$2" == "" ]
    then
        helpmessage
    fi
    RELEASE="$2"
    shift # past argument
    ;;
    -t|--ticket)
    if [ "$2" == "" ]
    then
        helpmessage
    fi
    TICKET="$2"
    shift # past argument
    ;;
    *)
        helpmessage
    ;;
    esac
    shift


if [ "$RELEASE" == "" ] && [ "$TICKET" != "" ]
then
    echo "== TEST TICKET =="
    echo "TICKET : $TICKET"
    echo "--------------------------"


    # FILELIST=`find . -name $TICKET* | grep -v ".git" | grep -v ".pyc" | grep -v "selenium_test"`
    FILELIST=`fgrep -rl "[$TICKET]" | grep -v ".git" | grep -v ".pyc" | grep -v "selenium_test"`

    if [ -z "$FILELIST" ]
    then
        echo "NO TEST FILES"
        exit 0;
    fi

    mkdir $DIR_NAME > /dev/null 2>&1
    nose_tests "$FILELIST" $TICKET
else
    echo "== TEST RELEASE =="
    RELEASE_TICKET=misc/release_tickets/$RELEASE

    if [ ! -f $RELEASE_TICKET ]
    then
        echo "NO RELEASE TICKET FILE"
        exit 0;
    fi

    TICKET_LIST=`cat $RELEASE_TICKET` > /dev/null 2>&1

    if [ -z "$TICKET_LIST" ]
    then
        echo "RELEASE TICKET FILE IS EMPTY"
        exit 0;
    fi

    echo "=========================="
    echo "RELEASE : $RELEASE"
    echo "=========================="
    echo "TICKET_LIST :"
    echo "$TICKET_LIST"
    echo "=========================="

    for ticket in $TICKET_LIST; do
        echo "TICKET : $ticket"
        echo "--------------------------"
        FILELIST=`fgrep -rl "[$ticket]" | grep -v ".git" | grep -v ".pyc" | grep -v "selenium_test"`
        if [ -z "$FILELIST" ]
        then
            echo "NO TEST FILES"
            continue
        fi
        mkdir $DIR_NAME > /dev/null 2>&1
        echo "FILE LIST : $FILELIST"
        nose_tests "$FILELIST" $ticket
    done
fi

exit 0;

