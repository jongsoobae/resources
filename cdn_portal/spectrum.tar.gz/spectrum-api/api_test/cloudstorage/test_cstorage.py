import time
import unittest
import os,sys
import json
cwd = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, os.path.dirname(cwd))
from api_test.common import SpectrumAPIManager
from api_test.contrib.jsonschema import validate
from api_test import url_constants as base_url_constants
from api_test.cloudstorage import url_constants

def assert_result(response, response_format):
    """
    response_format: (status_code, schema)
    schema = {
        'type':'arrray',
        {
            'type': 'object',
            'properties':{'storage_name': {'type': 'string'}}
        }
    }
    result = validate({'storage_name':'1'}, schema)
    """
    if not response_format:
        status_code = 200
        json_schema = bas_url_constants.default_json_schema
    else:
        status_code = response_format[0]
        json_schema = response_format[1]
    assert response.status_code == status_code
    validate(json.loads(response._content), json_schema)


# [AURORAUI-3061]
class TestCstorage(unittest.TestCase):
    def setUp(self):
        self.spectrum_api = SpectrumAPIManager()

    def test_clb_domain(self):
        for url, url_parameter, post_data, method, response_format in url_constants.cstorage_urls:
            if not url:
                continue
            response = self.spectrum_api.request(url, method=method, post_data=post_data, url_parameter=url_parameter)
            assert_result(response, response_format)



if __name__ == "__main__":
    unittest.main()
