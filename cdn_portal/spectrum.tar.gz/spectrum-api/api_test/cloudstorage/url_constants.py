import os
import json

def read_file(filename):
    f = open(filename, 'r')
    content = f.read()
    f.close()
    return content

def get_json_schema(schema_name):
    json_path = os.path.abspath(os.path.dirname(os.getcwd()))
    filepath = "%s%s" % (json_path, "/cloudstorage/json_schema/%s" % schema_name)
    data = read_file(filepath)
    data = json.loads(data)
    return data

CSTORAGE_SIDS = "cstorage_sids.json"

#uri, url_parameter, params or post_data, method, response_format(response_code, json schema)

customer_id = 1
storage_ids = ['377', '492', '453', '378']
keywords = [
    'synctest',
    'yongmin',
    'TEST2',
    'joonjong1'
]

cstorage_urls = [
    ('cloudstorage/simple_storage_list/?customer_id={customer_id}&page_size=max', {'customer_id': customer_id}, {}, 'get', (200, get_json_schema(CSTORAGE_SIDS))),
    ('cloudstorage/simple_storage_list/?storage_ids={storage_ids}&page_size=max',
      {'storage_ids': ",".join(storage_ids)}, {}, 'get',
     (200, get_json_schema(CSTORAGE_SIDS))),
    ('cloudstorage/simple_storage_list/?storage_keywords={storage_keywords}&page_size=max',
        {'storage_keywords': ",".join(keywords)}, {}, 'get',
        (200, get_json_schema(CSTORAGE_SIDS))),
]

