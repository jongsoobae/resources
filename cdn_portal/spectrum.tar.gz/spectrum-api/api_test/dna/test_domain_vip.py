import os
if os.environ.get('DJANGO_SETTINGS_MODULE') is None:
    os.environ['DJANGO_SETTINGS_MODULE'] = 'spectrum_api.settings'

import unittest
import json
import time

from api_test import url_constants as base_url_constants
from api_test.contrib.jsonschema import validate
from api_test.common import SpectrumAPIManager
from api_test.dna import url_constants

def assert_result(response, response_format):
    """
    response_format : (status_code, schema)
    schema = {
        'type':'array',
        {
            'type':'object',
            'properties':{'sstorage_name': {'type':'string'}}
        }
    }
    result = validate({'storage_name':'1'}, schema)
    """
    if not response_format:
        status_code = 200
        json_schema = base_url_constants.default_json_schema
    else:
        status_code = response_format[0]
        json_schema = response_format[1]
    assert response.status_code == status_code
    validate(json.loads(response._content), json_schema)


# [PRISMUI-2645]
class TestDomainVipValidate(unittest.TestCase):
    def setUp(self):
        self.spectrum_api = SpectrumAPIManager();

        #make domain
        response = self.spectrum_api.request('domains/', method='post', post_data=url_constants.domains_inserst_parameter)
        response_data = json.loads(response._content)

        self.domain_id = response_data['domain_id']
        self.domain_vip_id = 0

    def tearDown(self):
        #delete domain
        self.spectrum_api.request('domains/%s/' % self.domain_id , method='delete')


    def test_doamin_vip_validate(self):
        for url, url_parameter, post_data, method, response_format in url_constants.domains_vips_urls:
            if not url:
                continue

            post_data['domain'] = self.domain_id

            response = self.spectrum_api.request(url, method=method, post_data=post_data, url_parameter={'domain_vip_id':self.domain_vip_id})
            assert_result(response, response_format)

            if method == 'post' and response_format[0] == 201 :
                response_data = json.loads(response.content)
                self.domain_vip_id = response_data['domain_vip_id']


if __name__ == "__main__":
    unittest.main()