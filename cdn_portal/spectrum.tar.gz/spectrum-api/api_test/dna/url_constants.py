import time

response_json_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "title": "default format",
    "description": "spectrum api default json schema",
    "type":'object',
    "required":['domain_vip_id', 'vip', 'domain', 'domain_name', 'vip_name'],
    "properties":{
        'domain_vip_id':{
            'type':'integer'
        },
        'vip':{
            'type':'integer'
        },
        'domain': {
            'type': 'integer'
        },
        'priority':{
            'type':['integer', 'null'],
            'minimum':1,
        }
    }
}

json_400_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "title": "default format",
    "description": "spectrum api default json schema",
    "type":'object'
}

GSLB_DOMIAN = 1
TEST_VIP_IDS = 82379

domains_vips_invalid_insert_parameter = {
    'priority': '0',
    'vip': TEST_VIP_IDS,
}

domains_vips_correct_insert_parameter = {
    'priority': '1',
    'vip': TEST_VIP_IDS,
}

domains_vips_invalid_update_parameter = {
    'priority': '0',
    'vip': TEST_VIP_IDS,
}

domains_vips_correct_update_parameter = {
    'priority': '1',
    'vip': TEST_VIP_IDS,
}

domains_vips_correct_update_parameter_none = {
    'priority': None,
    'vip': TEST_VIP_IDS,
}

domains_inserst_parameter = {
    'name':'testdomain.%s' % time.time(),
    'domain_type':GSLB_DOMIAN
}

domains_vips_urls = [
    ('domains_vips/', '', domains_vips_invalid_insert_parameter ,'post', (400, json_400_schema)),
    ('domains_vips/', '', domains_vips_correct_insert_parameter, 'post', (201, response_json_schema)),
    ('domains_vips/{domain_vip_id}/', '',domains_vips_invalid_update_parameter, 'put', (400, json_400_schema)),
    ('domains_vips/{domain_vip_id}/', '',domains_vips_correct_update_parameter, 'put', (200, response_json_schema)),
    ('domains_vips/{domain_vip_id}/', '',domains_vips_correct_update_parameter_none, 'put', (200, response_json_schema)),
]
