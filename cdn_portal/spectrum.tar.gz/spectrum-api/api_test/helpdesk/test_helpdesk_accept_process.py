import os,sys
if os.environ.get('DJANGO_SETTINGS_MODULE') is None:
    os.environ['DJANGO_SETTINGS_MODULE'] = 'spectrum_api.settings'

import json
import unittest

import url_constants

from api_test.common import SpectrumAPIManager
from api_test.contrib.jsonschema import validate
from api_test.url_constants import default_json_schema

def assert_result(response, response_format):
    """
    response_format: (status_code, schema)
    schema = {'type':'object',
              'properties':{'name':{'type':'string'},},}
    result = validate({'name':'1'}, schema)
    """
    if not response_format:
        status_code = 200
        json_schema = default_json_schema
    else:
        status_code = response_format[0]
        json_schema = response_format[1]
    assert response.status_code == status_code
    validate(json.loads(response._content), json_schema)

# [AURORAUI-3318]
class TestHelpdeskAcceptProcess(unittest.TestCase):
    def setUp(self):
        self.spectrum_api = SpectrumAPIManager()

        ##make helpdesk
        response = self.spectrum_api.request('helpdesk/requests/', method='post', post_data = url_constants.help_desk_insert_param)
        assert_result(response, url_constants.help_desk_response)

        response_data = json.loads(response._content)
        self.help_id = response_data['help_id']

    def tearDown(self):
        #delete helpdesk
        self.spectrum_api.request('helpdesk/requests/%s' % self.help_id, method='delete')

    def test_helpdesk_accept_support_done_process(self):
        for url, method, url_param, response_format in url_constants.help_desk_accept_support_done:
            url_param['help_id'] = self.help_id
            response = self.spectrum_api.request(url, method=method, post_data=url_param)

            assert_result(response, response_format)

            #check customer data(It should be marked)
            response = self.spectrum_api.request('helpdesk/requests/%s'%self.help_id, method='get')
            response_data = json.loads(response._content)

            self.assertIn('*', response_data['result_sms'])
            self.assertIn('*', response_data['end_user_phone'])
            self.assertIn('*', response_data['end_user'])
            self.assertIn('*', response_data['end_user_id'])

    def test_helpdesk_accept_process(self):
        for url, method, url_param, response_format in url_constants.help_desk_accept:
            url_param['help_id'] = self.help_id
            response = self.spectrum_api.request(url, method=method, post_data=url_param)

            assert_result(response, response_format)

            #check customer data(It should not be marked)
            response = self.spectrum_api.request('helpdesk/requests/%s'%self.help_id, method='get')
            response_data = json.loads(response._content)

            self.assertNotIn('*', response_data['result_sms'])
            self.assertNotIn('*', response_data['end_user_phone'])
            self.assertNotIn('*', response_data['end_user'])
            self.assertNotIn('*', response_data['end_user_id'])


if __name__ == "__main__":
    unittest.main()