from spectrum_api.helpdesk.views.helpdesk import RESULT_CODE_EXCEPT_SUPPORT_DONE

help_desk_response = (201,
                      {
                          "$schema": "http://json-schema.org/draft-04/schema#",
                          "title": "default format",
                          "description": "spectrum api default json schema",
                          "type": 'object',
                          "required": ["end_user", "register_case_cd", "os_cd", "cpu_cd", "error_url",
                                       "explorer_cd", "help_id", "hope_time_cd", "account_name", "account_no",
                                       "result_mail", "user_id", "mediaplayer_cd", "help_desc", "result_sms",
                                       "result_inform", "city_cd", "user_name", "latest_updater", "urgency_call",
                                       "end_user_type_cd", "end_user_id", "error_case_cd", "date_modified",
                                       "end_user_phone",
                                       "help_desk_accept", "directx_cd", "memory_cd", "date_created", "user_email"]
                      }
                      )

help_desk_accept_response = (201,
                             {
                                 "$schema": "http://json-schema.org/draft-04/schema#",
                                 "title": "default format",
                                 "description": "spectrum api default json schema",
                                 "type": 'object',
                                 "required": ["help_id", "user_name", "error_cause_cd", "result_cd", "result_desc",
                                              "contact_time_cd", "success_time_cd", "note", "transact_time_cd",
                                              "request_total",
                                              "comm_cd", "place_cd", "owner_cd", "date_created", "date_modified",
                                              "transact_list", "creator", "latest_updater"],
                             }
                             )

help_desk_insert_param = {
    "account_no":"1000",
    "user_id":"10558",
    "user_name":"testtest",
    "user_email":"test7@cdnetworks.co.kr",
    "result_inform":"11",
    "result_mail":"test7@cdnetworks.co.kr",
    "result_sms":"010-1234-4567",
    "error_case_cd":1,
    "register_case_cd":294,
    "end_user":"hong",
    "os_cd":86,
    "mediaplayer_cd":101,
    "directx_cd":95,
    "cpu_cd":72,
    "memory_cd":79,
    "help_desc":"test",
    "error_url":"cdnetworks.com",
    "end_user_phone":"010-1234-4567",
    "end_user_id":"test1234",
    "urgency_call":"0",
    "explorer_cd":91,
    "city_cd":266,
    "end_user_type_cd":227,
    "hope_time_cd":233
}

help_desk_accept_insert_param_support_done = {
    "user_name":"test",
    "error_cause_cd":182,
    "transact_list":[
        {"transact_cd":185}, {"transact_cd":214},
        {"transact_cd":38}, {"transact_cd":190},
    ],
    "comm_cd":247,
    "place_cd":254,
    "owner_cd":261,
    "result_cd":54,
    "note":"test",
    "contact_time_cd":106,
    "success_time_cd":110,
    "transact_time_cd":118,
    "request_total":1,
    "result_desc":"test",
}

help_desk_accept_insert_param = {
    "user_name":"test",
    "error_cause_cd":182,
    "transact_list":[
        {"transact_cd":185}, {"transact_cd":214},
        {"transact_cd":38}, {"transact_cd":190},
    ],
    "comm_cd":247,
    "place_cd":254,
    "owner_cd":261,
    "result_cd":RESULT_CODE_EXCEPT_SUPPORT_DONE['CANNOT_CALL'],
    "note":"test",
    "contact_time_cd":106,
    "success_time_cd":110,
    "transact_time_cd":118,
    "request_total":1,
    "result_desc":"test",
}


help_desk_accept_support_done = [
    ('helpdesk/request_acceptions/', 'post', help_desk_accept_insert_param_support_done, help_desk_accept_response)
]

help_desk_accept = [
    ('helpdesk/request_acceptions/', 'post', help_desk_accept_insert_param, help_desk_accept_response)
]