import time
import unittest
import os,sys
import json
cwd = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, os.path.dirname(cwd))
from api_test.common import SpectrumAPIManager
from api_test.contrib.jsonschema import validate
from api_test import url_constants

def assert_result(response, response_format):
    """
    response_format: (status_code, schema)
    schema = {'type':'object',
              'properties':{'name':{'type':'string'},},}
    result = validate({'name':'1'}, schema)
    """
    if not response_format:
        status_code = 200
        json_schema = url_constants.default_json_schema
    else:
        status_code = response_format[0]
        json_schema = response_format[1]
    assert response.status_code == status_code
    validate(json.loads(response._content), json_schema)

class TestBasePop(unittest.TestCase):
    def setUp(self):
        self.spectrum_api = SpectrumAPIManager()

    def atest_base_pop_info(self):
        for url,url_parameter, post_data,method,response_format in url_constants.base_pop_urls:
            if not url:
                continue
            response = self.spectrum_api.request(url, method=method, post_data=post_data, url_parameter=url_parameter)
            assert_result(response, response_format)

    def atest_base_pop_edit(self):
        for url,url_parameter, post_data,method,response_format in url_constants.base_pop_edit_urls:
            if not url:
                continue
            response = self.spectrum_api.request(url, method=method, post_data=post_data, url_parameter=url_parameter)
            assert_result(response, response_format)

    def atest_base_host_info(self):
        for url,url_parameter, post_data,method,response_format in url_constants.base_host_info_urls:
            if not url:
                continue
            response = self.spectrum_api.request(url, method=method, post_data=post_data, url_parameter=url_parameter)
            assert_result(response, response_format)

    def atest_base_edge_info(self):
        for url,url_parameter, post_data,method,response_format in url_constants.base_edge_info_urls:
            if not url:
                continue
            response = self.spectrum_api.request(url, method=method, post_data=post_data, url_parameter=url_parameter)
            assert_result(response, response_format)

    def atest_base_probe_info(self):
        for url,url_parameter, post_data,method,response_format in url_constants.base_probe_info_urls:
            if not url:
                continue
            response = self.spectrum_api.request(url, method=method, post_data=post_data, url_parameter=url_parameter)
            assert_result(response, response_format)

    def atest_base_probe_edit_info(self):
        for url,url_parameter, post_data,method,response_format in url_constants.base_probe_edit_urls:
            if not url:
                continue
            response = self.spectrum_api.request(url, method=method, post_data=post_data, url_parameter=url_parameter)
            assert_result(response, response_format)

    def test_base_probeagent_info(self):
        for url,url_parameter, post_data,method,response_format in url_constants.base_probeagent_info_urls:
            if not url:
                continue
            response = self.spectrum_api.request(url, method=method, post_data=post_data, url_parameter=url_parameter)
            assert_result(response, response_format)

if __name__ == "__main__":
    unittest.main()