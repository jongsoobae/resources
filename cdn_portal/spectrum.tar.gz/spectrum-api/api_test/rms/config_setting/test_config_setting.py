import unittest
import json

from api_test.common import SpectrumAPIManager
from api_test.contrib.jsonschema import validate, ValidationError, SchemaError


class TestConfigSetting(unittest.TestCase):
    @classmethod
    def setUpClass(self):
        self.spectrum_api = SpectrumAPIManager()
        self.json_schema = json.loads(open('./config_setting_schema.json').read())

    @classmethod
    def tearDownClass(self):
        print 'teardownClass'

    def setUp(self):
        print 'setUp'

    def tearDown(self):
        print 'tearDown'

    def test_get(self):
        response = self.spectrum_api.request('rms/config_setting/')

        try:
            validate(json.loads(response.content), self.json_schema)
        except ValidationError as e:
            self.assertTrue(False, e.message)
        except SchemaError as e:
            self.assertTrue(False, e.message)

        self.assertIsNotNone(response)