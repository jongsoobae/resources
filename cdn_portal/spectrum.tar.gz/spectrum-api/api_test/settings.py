DEBUG = True
API_LOCAL_MODE = False
PROJECT_NAME = 'prism_fe'