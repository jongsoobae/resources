import constants

user_context ={'user':constants.END_USER_EMAIL}

default_json_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "title": "default format",
    "description": "spectrum api default json schema",
    "type":'object'
}
json_list_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "title": "default format",
    "description": "spectrum api default json schema",
    "type":'array'
}
json_400_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "title": "default format",
    "description": "spectrum api default json schema",
    "type":'object'
}

json_500_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "title": "default format",
    "description": "spectrum api default json schema",
    "type":'object',
    "properties":{
        'detail':{'type':'string'},
    }
}

clb_monitor_urls = [('lite/clbalertgroups',{},{'account_no':20036},'',(200,default_json_schema)),
            ('clb/alertdomainstatus',{},{},'',(200,default_json_schema)),
            ('clb/alertdomainfailhistory',{},{'account_no':20036,
                                              'page_size':'500',
                                              'update_time__range':'2017-01-31,2017-02-01',
                                              'group_id':'16,152,17,25,33,34,35',
                                              'o':'-update_time'},'',(200,default_json_schema)),
            ('clb/alertdomainsnapshot',{},{'account_no':20036,'page_size':'max'},'',(200,default_json_schema))]

clb_myinfra_urls = [('myinfra/get_available_probes',{},{'customer':1},'',(200,default_json_schema)),
                    ('myinfra/server_group/simple',{},{'customer':1,'page_size':'max'},'',(200,default_json_schema)),
                    ('myinfra/server_group/{group_id}/',{'group_id':4},{'customer':1},'',(200,default_json_schema)),
                    ('myinfra/server_group/{group_id}/',{'group_id':4},{'customer':1,
                                                                       'region':23,
                                                                       'enable_gslb':1,
                                                                       'group_name':'Location1'},'put',(200,default_json_schema)),
                    ('myinfra/server_group/{group_id}/deletable/',{'group_id':4},{},'',(200,default_json_schema)),
                    ('myinfra/server',{},{'customer':1,'group_id':4,
                                          'o':'server_id',
                                          'page_size':'max'},'',''),
                    ('clb/locationregion',{},{'page_size':'max'},'',(200,default_json_schema))]

server_edit_info =  {"server_id": 46495, "server_name": "test1",
                "server_health_checks": [{"probe": 1000013, "vip_probe_id": 22040},
                                         {"probe": 1000015, "vip_probe_id": 22077}],
                "server_state": 0, "ip": "100.100.100.101", "group_id": 4}
server_add_info = {"ip": "11.22.33.111", "group_id": 9, "server_health_checks": [],
                   "server_name": "test123", "server_state": "1"}
clb_myinfra_server_urls = [('myinfra/server/',{},{'customer':1,
                                                  'group_id':4,
                                                  'o':'server_id',
                                                  'page_size':'max'},'',(200,json_list_schema)),
                    ('myinfra/server/{server_id}/',{'server_id':46495},server_edit_info,'put',(200,default_json_schema)),
                    ('myinfra/server/{server_id}/related/',{'server_id':46495},{},'',(200,default_json_schema)),
                    ('myinfra/server/',{},server_add_info,'post',(400,json_400_schema)),
                    ('myinfra/server/{server_id}/',{'server_id':46495},{},'delete',(500,json_500_schema))]

clb_domain_add_info = {"customer":1, "policies": [], "health_check_rule": "",
                       "policy_type": "dynamic", "clb_dns_zone": "11136",
                       "answer_ttl": 60,  "load_balancing_type": 0, "answer_count": 1,
                       "selected_search_ip": "", "selection_rule": "0", "customer_name": "", "host_name": "test11",
                       "domainvips": [], "selected_status": "", "customer": 1,
                       "selected_server_group": "", "etc_policy": [{"record_type": {"name": "CNAME", "val": "cname"},
                                                                    "actions": [{"answer": [{}], "action_type": 0}],
                                                                    "action_type": "2"}]}
clb_domain_edit_info = {"customer":1, "health_check_rule": "", "vips": [], "answer_ttl": 60,
                        "load_balancing_type": 0, "zone_name": "clb.davidkimtest.com", "domain_id": 13748,
                        "customer_name": "CDNetworks Product Management       [US]", "latest_updater": "injune.hwang",
                        "domain_type_display": "GSLB", "load_balancing_type_display": "GSLB",
                        "selected_search_ip": "", "is_valid": "ok",
                        "status": 0,  "description": "", "clb_dns_zone": "11136", "answer_count": 1,
                        "domain_type": 1, "is_admin": False, "domainvips": [],
                        "selected_status": "", "time_deployed": None, "customer": 1,
                        "etc_policy": [{"record_type": {"name": "CNAME", "val": "cname"},
                                        "actions": [{"answer": [{}], "action_type": 0}], "action_type": 2}],
                        "date_modified": "2017-02-02 14:11:00",
                        "host_name": "test11", "policies": [], "date_created": "2017-02-02 14:11:00",
                        "status_display": "Modified"}

clb_domain_urls = [
    ('geo/',{},{'customer':0},'',(200,default_json_schema)),
    ('clb_heartbeats/',{},{'customer':1},'',(200,json_list_schema)),
    ('clb_domains/{domain_id}/',{'domain_id':7987},{'customer':1},'',(200,default_json_schema)),
    ('servergroups/',{},{'customer':1},'',(200,json_list_schema)),
    ('clb_domains/',{},clb_domain_add_info,'post',(400,json_400_schema)),
    ('clb_domains/',{},clb_domain_edit_info,'put',(202,default_json_schema)),
    ('servers/',{},{'customer':1,'healthchecker':'undefined'},'',(200,json_list_schema)),
]

base_pop_urls = [
    ('baseconfig/pops/',{},{'lite':1,'page_size':'max'},'',(200,json_list_schema)),
    ('baseconfig/pops/{pop_id}',{'pop_id':484},{},'',(200,default_json_schema)),
    ('poplocations/',{},{'page_size':'max'},'',(200,json_list_schema)),
    ('ihmsidcs/',{},{'page_size':'max'},'',(200,json_list_schema)),
    ('lite/customers/',{},{'page_size':'max'},'',(200,json_list_schema)),
    ('probename/',{},{'page_size':'max'},'',(200,json_list_schema)),
    ('probeagentname/',{},{'page_size':'max'},'',(200,json_list_schema)),
    ('popgroups/',{},{'page_size':'max'},'',(200,json_list_schema)),
    ('roles/',{},{'page_size':'max'},'',(200,json_list_schema)),
]

add_pop_info = {"popgroup_info": [], "pktlossserver_info": [{"probeagentvip": "i0-h0-s0.P0-BOM(119.31.255.76)", "probeagent": 37}],
                "rttserver_info": {"probeagentvip": "i"}, "auto_probe": False,
                "probeagent_info": [{"popprobeagentconfig_id": 0, "vip_name": "i0-h0-s0.V0-CEK(46.232.206.172)",
                                     "primary": True, "probeagent": 6}], "uplinkprobe": [], "popgroup": [],
                "pop_name": "P1023-ICN", "pktlossserver": [37], "popinfo": [], "rttserver": 138, "customerpop": [],
                "probeagent": [{"popprobeagentconfig_id": 0, "primary": True, "probeagent": 6}]}

pop_edit_info = {"popgroup_info": [], "host_count": {"disabled": 0, "failure": 0, "enabled": 0},
                 "rttserver_info": {"NIC": "175.41.5.34", "probeagentvip": "i0-h0-s0.P0-BGW(175.41.5.34)",
                                    "hostname": "h0-s0.P0-BGW", "host_id": "8409", "probeagent": "138"},
                 "probeagent_info": [{"popprobeagentconfig_id": 4716, "vip_name": "i0-h0-s0.V0-CEK(46.232.206.172)",
                                      "primary": True, "probeagent": 6}], "auto_probe": False, "pop": 1711,
                 "pktloss_threshold": None, "cost": None, "popinfo": {"idc_id": None, "country": None,
                                                                      "country_id": None, "idc": None, "priority": None},
                 "ihms_pop": None, "customerpop": [], "probeagent": [{"popprobeagentconfig_id": 4716,
                                                                      "primary": True, "probeagent": 6}], "popgroup": [],
                 "pktlossserver": [37], "pop_name_info": "P1023-ICN", "status": 7, "rttserver": 138, "enable_gslb": "",
                 "description": None, "enable_cname_latency": "",
                 "pktlossserver_info": [{"NIC": "119.31.255.76", "probeagentvip": "i0-h0-s0.P0-BOM(119.31.255.76)",
                                         "hostname": "h0-s0.P0-BOM", "host_id": "7471", "probeagent": "37"}], "uplinkprobe": [],
                 "cdnw_pop_id": None, "pop_name": "P1023-ICN", "popinfo_info": {"idc_id": None, "country": None,
                                                                                "country_id": None, "idc": None, "priority": None}}

host_add_info = {"role": [{"role": 29, "hostrole_id": 0}], "system": 30037,
                 "role_info": [{"role_name": "CDNS_STAGING", "hostrole_id": 0, "role_id": 29}], "host_name": "h0"}
host_edit_info = {"system_name": "s0", "is_deletable": True, "enable_gslb": "", "description": "",
                  "role_info": [{"role_name": "CDNS_STAGING", "hostrole_id": 15500, "role_id": 29}],
                  "fullhostname": "h0-s0.P1023-ICN", "system": 30037, "pop": 1711, "pop_name": "P1023-ICN",
                  "host": 30486, "status": 7,
                  "host_name": "h0", "ihms_host": None, "role": [{"role": 29, "hostrole_id": 15500}]}

vip_add_info = {"probeconfig": [], "host": 30486, "edge": [], "vip_addr": "112.112.112.112", "vip_name": "i0", "probegroup": []}

vip_edit_info = {"hyperion_config": [], "probeconfig": [], "vip": 91232, "ihms_vip_information": None,
                 "ihms_vip": None, "vip_addr_info": "112.112.112.112", "vip_name_info": "i0",
                 "vip_addr": "112.112.112.112", "probegroup": [], "is_deletable": True, "enable_gslb": None,
                 "description": "aaa", "gslb_config": [], "probeagent_config": [], "mproxy_shield": False,
                 "host": 30486, "storagenode_config": [], "system_name": "s0.P1023-ICN", "pop_name": "P1023-ICN",
                 "mproxy_outgoing_ip": False, "edge": [], "host_name": "h0-s0.P1023-ICN", "vip_name": "i0"}
host_status_info = {"id": [30486], "save_and_push": 0, "enable_gslb": "1", "description": "test", "src_key": "h0-s0.P1023-ICN_HOST"}
vip_status_info = {"id": [91232], "save_and_push": 0, "enable_gslb": "1", "description": "test", "src_key": "h0-s0.P1023-ICN_HOST"}

base_pop_edit_urls = [
    ('baseconfig/pops/',{},add_pop_info,'post',(400,default_json_schema)),
    ('baseconfig/pops/{pop_id}/',{'pop_id':1711},pop_edit_info,'patch',(200,default_json_schema)),
    ('baseconfig/systems/{system_id}/hosts/',{'system_id':30037},host_add_info,'post',(400,default_json_schema)),
    ('baseconfig/hosts/{host_id}',{'host_id':30486},host_edit_info,'patch',(200,default_json_schema)),
    ('baseconfig/hosts/{host_id}/vips/',{'host_id':30486},vip_add_info,'post',(400,default_json_schema)),
    ('baseconfig/vips/{vip_id}',{'vip_id':91232},vip_edit_info,'patch',(200,default_json_schema)),
    ('status/update/host/',{},host_status_info,'patch',(200,{})),
    ('status/update/vip/',{},vip_status_info,'patch',(200,{})),
]

base_pop_info_urls = [
    ('baseconfig/pops/{pop_id}/',{'pop_id':1711},{},'',(200,default_json_schema)),
    #('relatedhosts/pops/{pop_id}/',{'pop_id':1711},{},'',(200,json_list_schema)),
    ('baseobject/status/pop/{pop_id}/',{'pop_id':1711},{},'',(200,default_json_schema)),
    ('baseinfo/system/',{},{'pop_id':1711,'page_size':'max'},'',(200,json_list_schema)),
    ('relatedhosts/pops/{pop_id}/',{'pop_id':17111},{},'',(404,default_json_schema)),
    ('relatedhosts/pops/{pop_id}/role/{role_id}/',{'pop_id':17111,'role_id':14},{},'',(404,default_json_schema)),
    ('relatededges/pops/{pop_id}/',{'pop_id':17111},{},'',(404,default_json_schema)),
    ('relateddomains/pops/{pop_id}/',{'pop_id':17111},{},'',(404,default_json_schema)),
    ('configdistactionhistory/{pop_alias}/',{'pop_alias':'P1023-ICN_POP'},{'o':'-action_id','page':1, 'page_size':5},'',(200,default_json_schema)),
]

base_host_info_urls = [
    ('baseinfo/host/',{},{'pk':30486},'',(200,json_list_schema)),
    ('baseconfig/hosts/{host_id}/',{'host_id':30486},{},'',(200,default_json_schema)),
    ('baseconfig/hosts/{host_id}/vips/',{'host_id':30486},{'page_size':'max'},'',(200,json_list_schema)),
    ('relatededges/host/{host_id}/',{'host_id':30486},{'lite':True,'page_size':'max'},'',(200,json_list_schema)),
    ('relateddomains/host/{host_id}/',{'host_id':30486},{'lite':True,'page_size':'max'},'',(200,json_list_schema)),
    ('configdistactionhistory/{host_alias}/',{'host_alias':'h0-s0.P1023-ICN_HOST'},{'o':'-action_id','page':1, 'page_size':5},'',(200,default_json_schema)),
]

edge_add_info = {"name": "mytest12", "description": "addd"}

base_edge_info_urls = [
    ('edges/',{},{'page':1,'page_size':100,'o':'-date_modified'},'',(200,default_json_schema)),
    ('edges/',{},edge_add_info,'post',(400,default_json_schema)),
    ('edges/{edge_id}/',{'edge_id':1116},edge_add_info,'put',(200,default_json_schema)),
]

base_probe_info_urls = [
    ('probes/',{},{'page':1,'page_size':100,'o':'-date_modified'},'',(200,default_json_schema)),
    ('customers/',{},{'page_size':100,'o':'customer_name'},'',(200,default_json_schema)),
    ('probes/types/',{},{},'',(200,json_list_schema)),
    ('probes/aggregate/{probe_id}',{'probe_id':1000776},{},'',(200,default_json_schema)),
    ('probes/{probe_id}/deletable/',{'probe_id':1000776},{},'',(200,default_json_schema)),
]

probe_add_info = {"port": "80", "probe_type": 2, "customer_set": [], "probe_type_name": "TCP", "name": "test_probe01"}
probe_agg_add_info = {"name": "test_aggregate01", "probe_type": 0, "aggregate_type": "SUM",
                      "probe_type_name": "AGGREGATE", "customer_set": [],
                      "probes": [{"vip": "", "probe": 24, "$$hashKey": "12R"}, {"probe": 36, "$$hashKey": "12T"}]}
probe_agg_edit_info ={"timespan": None, "aggregate_type": "SUM", "threshold": None, "use_clb": False, "log": 1,
                      "probe_type": 0, "report_other": 1, "step_func": None, "description": None, "scaling": None,
                      "probe_type_name": "AGGREGATE", "report": 1, "ttl_factor": None, "customer_set": [],
                      "probes": [{"$$hashKey": "1CV", "weight": None, "probe": 24, "vip_ip": None, "vip": None,
                                  "vip_full_name": None, "probeconfigaggregateprobe_id": 362,
                                  "probe_name": "5100_GDNS"}, {"$$hashKey": "1CW", "weight": None, "probe": 36,
                                                               "vip_ip": None, "vip": None, "vip_full_name": None,
                                                               "probeconfigaggregateprobe_id": 363, "probe_name": "6501_GDNS"}],
                      "ratio_base": None, "probeconfig_id": 1000776, "name": "test_aggregate01",
                      "date_modified": "2017-02-02 17:37:28", "interval": None,
                      "alert_message": None, "timeout": None, "date_created": "2017-02-02 17:37:28"}
probe_edit_info = {"content_length": None, "timespan": None, "threshold": None, "message": None, "port": 80,
                   "use_clb": False, "regex": "", "log": 1, "probe_type": 2, "report_other": 1, "step_func": None,
                   "description": "ad", "scaling": None, "value_type": None, "probe_type_name": "TCP", "report": 1,
                   "ttl_factor": None, "customer_set": [], "ratio_base": None, "probeconfig_id": 1000775, "name": "test_probe01",
                   "date_modified": "2017-02-02 15:54:22", "interval": None, "alert_message": None,
                   "timeout": None, "date_created": "2017-02-02 15:54:22", "try_count": 1}
base_probe_edit_urls = [
    ('probes/tcp/',{},probe_add_info,'post',(400,default_json_schema)),
    ('probes/tcp/{probe_id}/',{'probe_id':1000775},probe_edit_info,'put',(200,default_json_schema)),
    ('probes/aggregate/',{},probe_agg_add_info,'post',(400,default_json_schema)),
    ('probes/aggregate/{probe_id}/',{'probe_id':1000776},probe_agg_edit_info,'put',(200,default_json_schema)),
]

probeagent_edit_info = {"icmp_echo_pktlen": None, "ftp_max_probes": None, "ftp_delay": None, "rtt_cache_ttl": None,
                        "rtt_max_tcp_probes": None, "tcp_max_probes": None, "rtt_max_tcp_pending": None,
                        "rtt_log_rotate_interval": None, "rtt_dns_udp_port": None, "rtmp_max_probes": None,
                        "pop2pop_log_rotate_interval": None, "ssl_ca_path": None, "log_rotate_interval": None,
                        "report_log_rotate_interval": None, "dns_max_probes": None, "rtt_max_ping_rounds": None,
                        "rtt_trace_udp_port": None, "snmp_delay": None, "probeagent_id": 612, "rtt_echo_pktlen": None,
                        "ssl_delay": None, "rtt_timeout": None, "dns_delay": None, "pktloss_delay": None,
                        "rtt_max_cache_records": None, "reporting_protocol": None, "pktloss_packet_count": None,
                        "tcp_delay": None, "rtt_trace_min_hops": None, "rtt_trace_max_hops": None,
                        "rtt_trace_max_linear_hops": None, "pktloss_port": None, "udp_delay": None, "icmp_delay": None,
                        "pktloss_timeout": None, "rtt_dns_tcp_port": None, "snmp_max_probes": None, "ssl_max_probes": None,
                        "date_modified": "2017-02-02 15:37:55", "rtmp_delay": None, "vip": 23851, "udp_max_probes": None,
                        "icmp_max_probes": None, "pktloss_interval": None, "pktloss_packet_length": None,
                        "debug_timeout": None, "rtt_delay": None, "date_created": "2017-01-25 08:08:23",
                        "debug_port": None, "vip_name": "i26-h0-s82.P21-NRT(14.0.39.220)"}

base_probeagent_info_urls = [
    ('probeagents/',{},{'page':1,'page_size':100,'o':'-date_modified'},'',(200,default_json_schema)),
    ('rttservers/{probeagent_id}/pops/',{'probeagent_id':612},{},'',(200,default_json_schema)),
    ('probeagents/{probeagent_id}/pops/',{'probeagent_id':612},{},'',(200,default_json_schema)),
    ('packetloss/{probeagent_id}/pops/',{'probeagent_id':612},{},'',(200,default_json_schema)),
    ('probeagents/{probeagent_id}/autoprobe_pops/',{'probeagent_id':612},{},'',(200,json_list_schema)),
    #('edges/',{},edge_add_info,'post',(400,default_json_schema)),
    #('edges/{edge_id}/',{'edge_id':1116},edge_add_info,'put',(200,default_json_schema)),
    ('probeagents/{probeagent_id}/',{'probeagent_id':612},probeagent_edit_info,'put',(200,default_json_schema)),
]

gslb_domain_urls = [
    ('domainsall/',{},{'page':1,'page_size':100,'o':'-date_modified'},'',(200,default_json_schema)),
    ('domains_customers/',{},{},'',(200,json_list_schema)),
    ('domains_types/',{},{},'',(200,json_list_schema)),
    ('domains/{domain_id}/related_vips/',{'domain_id':7987},{},'',(200,json_list_schema)),
    ('domains/{domain_id}/',{'domain_id':7987},{},'',(200,default_json_schema)),
    ('domains/{domain_id}/dynamic_relay/',{'domain_id':7987},{'page_size':'max'},'',(200,json_list_schema)),
    ('probename/',{},{'page_size':'max'},'',(200,json_list_schema)),
    ('domains/{domain_id}/vips/',{'domain_id':13751},{'page_size':'max'},'',(200,json_list_schema)),
]
domain_add_info = {"customer": "", "domain_type": "1", "name": "myhello.com"}
domain_edit_info = {"customer": "1", "description": "", "clb_dns_zone": "11136", "answer_ttl": "120",
                         "load_balancing_type": "0", "answer_count": "1", "domain_type": "1", "log_request": "1",
                         "backupanswer": "",
                         "is_admin": "false", "domain_id": "7987", "name": "paul.clb.davidkimtest.com"}

domain_edge_add_info = {"domain": "13751", "weight": "1.0", "probe": "56", "priority": "", "edge": "330",
                        "probe_scaling_factor": "", "probe_increment": ""}
domain_edge_edit_info = {"probe": "56", "domain": "13751", "edge": "330", "weight": "1.0", "domain_edge_id": "2228"}
domain_vip_add_info = {"domain": "13751", "weight": "1.0", "priority": "", "vip": "62667", "probe_increment": "",
                       "probe_scaling_factor": ""}
domain_vip_edit_info = {"domain_vip_id": "58468", "domain": "13751", "vip": "62667", "weight": "1.0"}

domain_static_rule_add_info = {"is_enabled": True, "domainstaticruleactions": [{"action": "ignore", "sequence": "1"}],
                               "invert": None, "condition": "always", "sequence": "1"}

domain_static_rule_edit_info = {"is_enabled": True, "domainstaticruleactions": [{"action": "ignore",
                                                  "domain_staticrule_action_id": 22932, "sequence": 1}],
                                "invert": None, "condition": "always", "sequence": 1}

gslb_domain_edit_urls = [
    ('domains/',{},domain_add_info,'post',(400,default_json_schema)),
    ('domains_edges/',{},domain_edge_add_info,'post',(400,default_json_schema)),
    ('domains_edges/{domain_edge_id}/',{'domain_edge_id':2228},domain_edge_edit_info,'put',(200,default_json_schema)),
    ('domains_edges/{domain_edge_id}/',{'domain_edge_id':2228},{},'',(200,default_json_schema)),
    ('domains/{domain_id}/',{'domain_id':7987},domain_edit_info,'patch',(200,default_json_schema)),
    ('domains_vips/',{},domain_vip_add_info,'post',(400,default_json_schema)),
    ('domains_vips/{domain_vip_id}/',{'domain_vip_id':58468},domain_vip_edit_info,'put',(200,default_json_schema)),
    ('domains/{domain_id}/conditions/',{'domain_id':13751},domain_static_rule_add_info,'post',(400,default_json_schema)),
    ('domains/{domain_id}/conditions/{condition_id}/',{'domain_id':13751,'condition_id':20654},
        domain_static_rule_edit_info,'put',(200,default_json_schema)),
]