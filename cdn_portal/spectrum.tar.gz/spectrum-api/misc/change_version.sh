#!/bin/bash

if [[ -z $1 || -z $2 || -z $3 ]]; then
    echo "change version"
    echo "usage: $0 [MAJOR] [MINOR] [PATCH]"

else
    sed -i "s/^VERSION = .*$/VERSION = ($1, $2, $3)/g" \
        ../spectrum_api/__init__.py
fi
