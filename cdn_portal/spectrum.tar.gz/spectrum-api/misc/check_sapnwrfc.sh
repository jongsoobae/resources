#!/bin/bash

PYTHON=$1
MODULE=$($PYTHON -c 'import sapnwrfc; print sapnwrfc.__name__' 2>&1> /dev/null | grep 'sapnwrfc')

if ! [ "$PYTHON" == "" ] ; then

    if ! [ "$MODULE" == "" ] ; then
        tar -xzvf sapnwrfc-0.19.tar.gz
        cd sapnwrfc-0.19
        $PYTHON setup.py build_ext -I /opt/nwrfcsdk/include/ -L /opt/nwrfcsdk/lib/
        $PYTHON setup.py build
        $PYTHON setup.py install
        cd ..
        rm -rf sapnwrfc-0.19
    else
        echo "sapnwrfc sdk is already installed."
    fi

    exit 0

else
    echo "usage: check_sapnwrfc.sh [python_path]"
    exit 1
fi