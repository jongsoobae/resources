#!/bin/env python

#
# Copyright (c) 2011 CDNetworks Co., Ltd.
# All rights reserved.
#
# $Id: compile.py 2440 2011-05-24 23:31:54Z junsik.park $
#

import compileall
import os
import py_compile
import sys

def main():
    try:
        argc = len(sys.argv)
        if (argc == 1):
            raise Exception, 'Invalid arguments'
        elif (argc == 2):
            py_compile.compile(sys.argv[1], None, None, True)
        else:
            if (sys.argv[1] == '-r'):
                for dirname in sys.argv[2:]:
                    compileall.compile_dir(dirname)
            elif (sys.argv[1] == '-o'):
                if (argc == 4):
                    py_compile.compile(sys.argv[3], sys.argv[2], None, True)
                else:
                    raise Exception, 'Invalid arguments'
            else:
                raise Exception, 'Invalid option'
        os._exit(0)
    except Exception, e:
        print str(e)
        os._exit(-1)

if __name__ == "__main__":
    main()
