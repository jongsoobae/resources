#!/usr/bin/env python
#
# Print spectrum_api version.
#

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from spectrum_api import __release_version__

def increase_version_number():
    cwd = os.path.abspath(os.path.dirname(__file__))
    filepath = os.path.dirname(cwd) + "/spectrum_api/" 
    filename = "%srelease_version.txt" % (filepath)
    try:
        release_version = int(__release_version__)
        release_version = release_version + 1
        write_file(str(release_version),filename)
        #not compatible with python 2.4
        #with open(filename, "w") as f:
        #    f.write(str(release_version))
    except Exception,e:
        pass

def write_file(contents, filename):
    if contents is not None and len(contents) > 0:
        f = open(filename, "w")
        f.write(contents)
        f.close()
    else:
        pass

if __name__ == "__main__":
    print __release_version__
    increase_version_number()
