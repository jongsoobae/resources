#!/usr/bin/env python
#
# Print spectrum_api version.
#

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from spectrum_api import __release_version__

def read_svn_revision_number(proc_str):
    import subprocess
    fd = subprocess.Popen(proc_str, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    fd.stdin.close()
    res = fd.stdout.read()
    fd.stdout.close()
    return res

if __name__ == "__main__":
    svn_revision_number = read_svn_revision_number("svnversion -n")
    if svn_revision_number.find("M") > -1:
        print __release_version__+ "M"
    else:
        print __release_version__
