#!/usr/bin/env python
#
# Print spectrum_api version.
#

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from spectrum_api import __version__

if __name__ == "__main__":
    print __version__
