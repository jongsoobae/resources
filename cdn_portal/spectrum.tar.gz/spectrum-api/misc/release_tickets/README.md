when you register releasenote to this directory, use 'git add --force'.
