from django.db import models

from spectrum_api.shared_components.models import BaseModel, OBJ_STATE_CHOICES
from spectrum_api.shared_components.models.customer import CustomerDisplay
from django.utils.translation import ugettext as _
from spectrum_api.configuration.models.base import BaseProbeConfig
from spectrum_api.rt_config_constants import ALERTING_RT_QUEUES
from django.core.validators import MaxLengthValidator


OBJ_STATES_ALERT = (
    OBJ_STATE_CHOICES[0],
    OBJ_STATE_CHOICES[1],
    (2, _('Draft')),  # instead of Inactive calling draft for alert
)

class AlertParent(BaseModel):
    obj_state = models.SmallIntegerField(default=1, choices=OBJ_STATES_ALERT)
    time_created = models.DateTimeField(auto_now_add=True)
    time_updated = models.DateTimeField(auto_now=True, auto_now_add=True, null=True)

    class Meta:
        abstract = True

class AlertProfile(AlertParent):
    profile_id = models.AutoField(primary_key=True)
    profile_name = models.CharField(_('Profile name'), max_length=100)
    customer = models.ForeignKey(CustomerDisplay, null=True)

    class Meta:
        app_label = 'alerting'
        db_table = "alert_profile"
        ordering = ['profile_name']

    def __unicode__(self):
        return self.profile_name

    def save(self, *args, **kwargs):
        turnoff = kwargs.pop('turnoff', False)
        request = kwargs.get('request', None)

        if turnoff:
            if self.alertprobemaster_set.all().count() == 1:
                self.obj_state = 0
                for each_alert in self.alertprobemaster_set.all():
                    each_alert.obj_state = 0
                    each_alert.save(request=request)
            elif self.alertprobemaster_set.all().count() > 1:
                for each_alert in self.alertprobemaster_set.all():
                    for each_level in each_alert.alertprobelevel_set.all():
                        if each_level.level_class in [1, 2]:
                            each_level.alert.obj_state = 0
                            each_level.alert.save(request=request)

        super(AlertProfile, self).save(*args, **kwargs)

ALERT_TYPES = (
    (1, _('Non-aggregated')),
    (2, _('Aggregated')),
)
ALERT_ALL_TRIGGERS = (
    (1, _('Fails')),
    (2, _('Above value')),
    (3, _('No reports')),
    (4, _('Below percentage')),
    (5, _('Above percentage')),
    (6, _('Average above value')),
)
ALERT_PROBE_TRIGGERS = (
    (1, _('Fails')),
    (2, _('Above value')),
    (3, _('No reports')),
    (4, _('Below percentage')),
    (6, _('Average above value')),
)
ALERT_PROBE_TRIGGERS_THRESHOLD = [2, 4, 6]

ALERT_FREQUENCIES = (
    (1, _('x occurrences in y tries')),
    (2, _('x occurrences in y time periods (in seconds)')),
    (3, _('x% in y time periods (in seconds)')),
    (4, _('x% in y tries')),
)
TIME_UNIT_CHOICES = (
    (0, _('Seconds')),
    (1, _('Minutes')),
    (2, _('Hours')),
)
TARGET_FILTER_CHOICES = (
    (0, _('Exclude')),
    (1, _('Include')),
)
class AlertProbeMaster(AlertParent):
    alert_id = models.AutoField(primary_key=True)
    profile = models.ForeignKey(AlertProfile, null=True)
    type = models.SmallIntegerField(default=1, choices=ALERT_TYPES)
    trigger = models.SmallIntegerField(default=1, choices=ALERT_PROBE_TRIGGERS)
    frequency = models.SmallIntegerField(default=1, choices=ALERT_FREQUENCIES)
    y_value = models.IntegerField(_('Y'), default=1)
    base_probeconfig = models.ManyToManyField(BaseProbeConfig)
    time_unit = models.SmallIntegerField(default=0, choices=TIME_UNIT_CHOICES, null=True)
    target_filter = models.SmallIntegerField(choices=TARGET_FILTER_CHOICES)

    class Meta:
        app_label = 'alerting'
        db_table = 'alert_probe_master'
        ordering = ['time_updated']

IS_REUSABLE_CHOICES = (
    (0, 'Not reusable'),
    (1, 'Reusable'),
)
class AlertProbeActionParent(AlertParent):
    action_name = models.CharField(max_length=30)
    is_reusable = models.SmallIntegerField(default=0, choices=IS_REUSABLE_CHOICES)
    customer = models.ForeignKey(CustomerDisplay, null=True, blank=True)
    message = models.TextField(_('Header'),
                            blank=True,
                            default='',
                            validators=[MaxLengthValidator(5000)])
    footer = models.TextField(_('Optional'),
                            blank=True,
                            default='',
                            validators=[MaxLengthValidator(5000)])

    class Meta:
        abstract = True

    def __unicode__(self):
        return self.action_name

class AlertProbeActionRT(AlertProbeActionParent):
    action_rt_id = models.AutoField(primary_key=True)
    subject = models.CharField(max_length=255, default='')
    queue_name = models.CharField(_('Queue name'), max_length=100, default='', choices=ALERTING_RT_QUEUES)

    class Meta:
        app_label = 'alerting'
        db_table = 'alert_probe_action_rt'

ALERT_IEM_EVENT_LEVELS = (
    (10, _('Notify')),
    (20, _('Warning')),
    (30, _('Critical')),
)

class AlertProbeActionIEM(AlertProbeActionParent):
    action_iem_id = models.AutoField(primary_key=True)
    event_level = models.SmallIntegerField(default=10, choices=ALERT_IEM_EVENT_LEVELS)

    class Meta:
        app_label = 'alerting'
        db_table = 'alert_probe_action_iem'

class AlertProbeActionEmail(AlertProbeActionParent):
    action_email_id = models.AutoField(primary_key=True)
    to = models.CharField(max_length=255)
    cc = models.CharField(max_length=255, null=True, blank=True)
    bcc = models.CharField(max_length=255, null=True, blank=True)
    subject = models.CharField(max_length=255, default='')

    class Meta:
        app_label = 'alerting'
        db_table = 'alert_probe_action_email'

DISPLAY_FORMAT_CHOICES = ((1, 1), (2, 2))  # TODO: add proper descriptions here
SECONDARY_FORMAT_CHOICES = ((1, 1), (2, 2))  # TODO: add proper descriptions here
POSITION_CHOICES = tuple([(i, i) for i in range(1, 32)])  # EC: is a choice field proper or an int field with min/max value?
PERCENT_CHOICES = tuple([(i, i) for i in range(0, 101)])  # EC: is a choice field proper or an int field with min/max value?
PRIORITY_CHOICES = tuple([(i, i) for i in range(0, 101)])

ACTION_ALL_GROUP_CHOICES = (
    (1, _('All')),
    (2, _('Probe Name')),
    (3, _('Customer')),
    (4, _('PoP')),
    (5, _('PoP/Probe Name')),
    (6, _('VIP/Probe Name')),
)

ACTION_NONAGG_GROUP_CHOICES = (
    (1, _('All')),
    (2, _('Probe Name')),
    (4, _('PoP')),
    (5, _('PoP/Probe Name')),
    (6, _('VIP/Probe Name')),
)

ACTION_AGG_GROUP_CHOICES = (
    (1, _('All')),
    (2, _('Probe Name')),
    (4, _('PoP')),
    (5, _('PoP/Probe Name')),
)
LEVEL_TYPE_CHOICES = (
    (0, _('Default')),  # meaning that this level is created from advanced alerting page (not from Simple UI -- RMS Settings)
    (1, _('Warning')),
    (2, _('Failure')),
)
class AlertProbeLevel(AlertParent):
    level_id = models.AutoField(primary_key=True)
    alert = models.ForeignKey(AlertProbeMaster, null=True)
    threshold = models.IntegerField(_('Threshold'), null=True, blank=True)
    x_value = models.IntegerField(_('X'), default=1)
    action_group = models.SmallIntegerField(_('Action group'), choices=ACTION_ALL_GROUP_CHOICES)
    level_class = models.SmallIntegerField(_('Level type'), blank=True, choices=LEVEL_TYPE_CHOICES, default=0)
    action_rt = models.ManyToManyField(AlertProbeActionRT, blank=True)
    action_email = models.ManyToManyField(AlertProbeActionEmail, blank=True)
    action_iem = models.ManyToManyField(AlertProbeActionIEM, blank=True)

    class Meta:
        app_label = 'alerting'
        db_table = 'alert_probe_level'
        ordering = ['x_value']

class RMSSettings(BaseModel):
    rms_settings_id = models.AutoField(primary_key=True)
    parent_base_probeconfig = models.ForeignKey(BaseProbeConfig,
                                related_name='rmssettings_set_a',
                                null=True,
                                blank=True)
    base_probeconfig = models.ForeignKey(BaseProbeConfig,
                            verbose_name=_('Probe Name'),
                            related_name='rmssettings_set_b')
    priority = models.SmallIntegerField(choices=PRIORITY_CHOICES)
    position = models.SmallIntegerField(choices=POSITION_CHOICES)
    visual_name = models.CharField(max_length=45, null=True, default=None, blank=True)
    drill_down = models.BooleanField()
    display_format = models.SmallIntegerField(choices=DISPLAY_FORMAT_CHOICES)
    secondary_format = models.SmallIntegerField(choices=SECONDARY_FORMAT_CHOICES)
    alert = models.ForeignKey(AlertProbeMaster)
    obj_state = models.SmallIntegerField(default=1)

    def __unicode__(self):
        return u'%s -> %s' % (self.visual_name, self.base_probeconfig)

    class Meta:
        app_label = 'alerting'
        db_table = u'rms_settings'
        unique_together = (('parent_base_probeconfig', 'base_probeconfig'),
                        ('parent_base_probeconfig', 'position'))

    def save(self, *args, **kwargs):
        super(RMSSettings, self).save(*args, **kwargs)
