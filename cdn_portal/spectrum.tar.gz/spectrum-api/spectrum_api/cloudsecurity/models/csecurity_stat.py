
from datetime import datetime
from datetime import timedelta

class CSecStat(object):
    from_date = None
    to_date = None
    utc_offset = None

    def __init__(self, *args, **kwargs):
        self.from_date = kwargs.get('from_date')
        self.to_date = kwargs.get('to_date')
        self.utc_offset = kwargs.get('utc_offset')

    def get_utc_from_date(self):
        return get_utc_datetime(self.from_date, self.utc_offset)

    def get_utc_to_date(self):
        return get_utc_datetime(self.to_date, self.utc_offset)

class CSecActionLog(CSecStat):
    pad_id_list = []

    def __init__(self, *args, **kwargs):
        CSecStat.__init__(self, *args, **kwargs)
        self.pad_id_list = kwargs.get('pad_id_list')

    def get_pad_id_list(self):
        if self.pad_id_list:
            return self.pad_id_list.split(',')
        else:
            return []

class CSecTrafficStat(CSecStat):
    stat_interval = None

    def __init__(self, *args, **kwargs):
        CSecStat.__init__(self, *args, **kwargs)
        self.stat_interval = kwargs.get('stat_interval')

class CSecServiceTrafficStat(CSecTrafficStat):
    service_item_id = None

    def __init__(self, *args, **kwargs):
        CSecTrafficStat.__init__(self, *args, **kwargs)
        self.service_item_id = kwargs.get('service_item_id')

def get_utc_datetime(date_instance, utc_offset):
    '''
        @description
            returns utc shifted datetime object.

        @params
            date_instance <date> : date instance.
            utc_offset <number> : utc offset hour.
    '''
    date_string = date_instance.strftime("%Y-%m-%d")
    return datetime.strptime(date_string, "%Y-%m-%d") - timedelta(0, int(utc_offset) * 3600)
