
from django.db import connections, models
from django.db.models import Max

from spectrum_api.shared_components.models import BaseModel

class CSecurityPadServiceActionLog(BaseModel):

    action_id = models.AutoField(primary_key=True)

    # PAD ID
    customer_site_id = models.IntegerField(max_length=10)

    # action occurred time
    action_time = models.DateTimeField(default="1000-01-01 00:00:00")

    # PAD Servicemap ID
    cdn_service_id = models.IntegerField(max_length=10)
    service_state = models.IntegerField(max_length=10)

    obj_state = models.IntegerField(max_length=10)

    # service state constants
    SECURITY_SERVICE_STATE_ARMED = 1
    SECURITY_SERVICE_STATE_RELEASED = 0

    class Meta:
        app_label = 'cloudsecurity'
        db_table = 'csecurity_pad_service_action_log'
        ordering = ['action_id']

def get_latest_action_log_id():

    id_max = CSecurityPadServiceActionLog.objects.all().aggregate(Max('action_id')).get('action_id__max')

    if id_max is None:
        return 0
    else:
        return id_max

def get_latest_oui_action_log_id():
    sql = 'SELECT MAX(`log_id`) FROM use_log_for_cloud_security'

    cursor = connections['centraldb'].cursor()
    cursor.execute(sql)

    query_result = cursor.fetchall()

    return query_result[0][0]

def get_csec_oui_action_log(last_log_id):

    sql = '''SELECT `log_id`, `pad_id`, `cdn_service_id`, `create_time`, `state_flag`
        FROM use_log_for_cloud_security WHERE `log_id` > %s'''

    cursor = connections['centraldb'].cursor()
    cursor.execute(sql, tuple([last_log_id]))
    query_result = cursor.fetchall()

    return query_result
