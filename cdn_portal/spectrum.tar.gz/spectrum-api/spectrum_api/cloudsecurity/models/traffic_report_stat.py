
from datetime import timedelta

from django.db import connections

STAT_INTERVAL = {
    '5m': 1,
    '10m': 2,
    '15m': 3,
    '20m': 4,
    '30m': 6,
    '1h': 12,
    '1d': -1
}

# one_stat's series data fields (except id column)
STAT_FIELDS = [
    'stat_time',
    'e0', 'e1', 'e2', 'e3', 'e4', 'e5',
    'e6', 'e7', 'e8', 'e9', 'e10', 'e11'
]

class CSecTrafficStat(object):

    stat_title = ''
    stat_item_id = None
    stat_interval = '5m'
    stat_from_date = None
    stat_to_date = None
    stat_utc_offset = 0
    stat_series_data = None
    stat_peak_data = None
    stat_unit = 'bps'
    stat_aggregate_method = max

    db_name = 'one_stat'
    table_name = ''
    sql = None

    def __init__(self, *args, **kwargs):

        self.stat_title = kwargs.get('stat_title')
        self.stat_interval = kwargs.get('stat_interval')
        self.stat_from_date = kwargs.get('from_date')
        self.stat_to_date = kwargs.get('to_date') + timedelta(1)
        self.stat_item_id = kwargs.get('item_id')
        self.stat_utc_offset = int(kwargs.get('utc_offset'))
        self.stat_aggregate_method = kwargs.get('aggregate_method', max)

    def _build_sql(self):

        return ''' SELECT %(fields)s FROM %(table_name)s
            WHERE item_id = %(item_id)s
                AND \'%(from_date)s\' <= stat_time
                AND stat_time < \'%(to_date)s\'
            ''' % {
                'fields': ','.join(STAT_FIELDS),
                'table_name': self.table_name,
                'item_id': self.stat_item_id,
                'from_date': self.stat_from_date,
                'to_date': self.stat_to_date
            }

    def get_traffic_report(self):

        self.sql = self._build_sql()
        cursor = connections[self.db_name].cursor()
        cursor.execute(self.sql)
        query_result = cursor.fetchall()

        interval_value = STAT_INTERVAL[self.stat_interval]

        def generate_series_data(stat_query_result, interval):

            '''
                It returns '[ [datetime, value], ... ]' formatted stat list.
                one_stat's stat table schema is
                << item_id, stat_time, e0, e1, ... , e11 >> (e'#' is 5min intervaled data)

                so.. by some methmetical tricks ... combine element,
                generate stat list from one_stat table query.

                very fast :) and easy to use.
            '''

            utc_offset_second = 3600 * self.stat_utc_offset
            utc_timedelta = timedelta(0, utc_offset_second)

            return [[
                str(stat_tuple[0] + timedelta(0, 300 * i * interval) + utc_timedelta), # time
                # series data - aggregate data with interval, then divide to convert bps
                self.stat_aggregate_method(
                    stat_tuple[1 + i * interval : 1 + (1 + i) * interval]) * 8 / 300
            ] for stat_tuple in stat_query_result for i in range(0, int(12 / interval))]

        # if query result exists, then
        # cleans and corrrect stat traffic data (zero fill)
        query_list = list(query_result)
        if len(query_list) > 0:
            cursor_counter = 0
            date_cursor = self.stat_from_date

            while date_cursor < self.stat_to_date:
                # if expected date is not exists ...
                if cursor_counter >= len(query_list) or \
                        int(query_list[cursor_counter][0].strftime('%s')) != int(date_cursor.strftime('%s')):

                    query_list.insert( # then, insert zero data tuple to current cursor
                        cursor_counter, (date_cursor, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L))

                cursor_counter += 1
                date_cursor += timedelta(0, 3600)

            # build up stat traffic series data from query result
            if interval_value == STAT_INTERVAL['1d']:
                '''
                    if interval is '1d', generate series data by '1h' interval.
                    then, combine 24 elements(24 hour) to 1 list element using aggregate method.
                '''
                series_data = generate_series_data(query_list, STAT_INTERVAL['1h'])

                self.stat_series_data = [[
                    series_data[24 * i][0],
                    self.stat_aggregate_method(
                        [value[1] for value in series_data[24 * i : 24 * (i + 1)]]
                    )
                ] for i in range(0, int(len(series_data) / 24))]

            else:
                self.stat_series_data = generate_series_data(query_list, interval_value)

        else:
            self.stat_series_data = []

        return {
            'stat_title': self.stat_title,
            'stat_item_id': self.stat_item_id,
            'series_data': self.stat_series_data,
            'stat_unit': self.stat_unit,
            'stat_interval': self.stat_interval
        }

class CSecOriginTrafficStat(CSecTrafficStat):
    table_name = 'tb_traffic_origin_bytes_item'

class CSecEdgeTrafficStat(CSecTrafficStat):
    table_name = 'tb_traffic_edge_bytes_item'

class CSecAttackTrafficStat(CSecTrafficStat):
    table_name = 'tb_traffic_cloud_security_byte_pop'

    def _build_sql(self):

        return ''' SELECT %(fields)s FROM %(table_name)s
            WHERE \'%(from_date)s\' <= stat_time AND stat_time < \'%(to_date)s\'
            GROUP BY stat_time ''' % {
                'fields': ','.join(STAT_FIELDS),
                'table_name': self.table_name,
                'from_date': self.stat_from_date,
                'to_date': self.stat_to_date
            }
