
import re

from rest_framework import serializers

from spectrum_api.cloudsecurity.models.csecurity_stat import CSecStat
from spectrum_api.cloudsecurity.models.csecurity_stat import CSecTrafficStat
from spectrum_api.cloudsecurity.models.csecurity_stat import CSecServiceTrafficStat
from spectrum_api.cloudsecurity.models.csecurity_stat import CSecActionLog

from spectrum_api.cloudsecurity.models.traffic_report_stat import STAT_INTERVAL

class CSecStatSerializer(serializers.Serializer):
    from_date = serializers.DateField()
    to_date = serializers.DateField()
    utc_offset = serializers.IntegerField()

    def validate(self, attr):

        if attr['from_date'] > attr['to_date']:
            raise serializers.ValidationError('\'from_date\' must less than \'to_date\'')

        return CSecStat(**attr)

class CSecActionLogSerializer(CSecStatSerializer):
    pad_id_list = serializers.CharField()

    def validate(self, attr):
        CSecStatSerializer.validate(self, attr)

        comma_separated_number_regex = re.compile(r'(^(\d*\,?)*$)')
        if not comma_separated_number_regex.match(attr['pad_id_list']):
            raise serializers.NestedValidationError(
                '\'pad_id_list\' must be comma separated number value (ex. \'13,2456,7\')')

        return CSecActionLog(**attr)

class CSecTrafficStatSerializer(CSecStatSerializer):
    stat_interval = serializers.CharField()

    def validate(self, attr):
        CSecStatSerializer.validate(self, attr)

        stat_interval_key_list = STAT_INTERVAL.keys()
        if attr['stat_interval'] not in stat_interval_key_list:
            raise serializers.ValidationError(
                'wrong \'stat_interval\' value. (available keyword: %s)' % ', '.join(stat_interval_key_list))

        return CSecTrafficStat(**attr)

class CSecServiceTrafficStatSerializer(CSecTrafficStatSerializer):
    service_item_id = serializers.IntegerField()

    def validate(self, attr):
        CSecTrafficStatSerializer.validate(self, attr)

        return CSecServiceTrafficStat(**attr)
