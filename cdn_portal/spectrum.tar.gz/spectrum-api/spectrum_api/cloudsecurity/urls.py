
from django.conf.urls.defaults import patterns, url
from rest_framework.urlpatterns import format_suffix_patterns

from spectrum_api.cloudsecurity.views.csecurity_traffic import CSecurityAttackTrafficAPI
from spectrum_api.cloudsecurity.views.csecurity_traffic import CSecurityServiceTrafficAPI
from spectrum_api.cloudsecurity.views.csecurity_pad_service import CSecServiceActionLogAPI
from spectrum_api.cloudsecurity.views.csecurity_pad_service import CSecuritySyncActionLogAPI


restfw_api_urlpatterns = patterns(
    'spectrum_api.cloudsecurity.views',

    # attack traffic
    url(r'^csecurity/attack_traffic/$',
        CSecurityAttackTrafficAPI.as_view(),
        name="csec_attack_traffic"),

    # service traffic
    url(r'^csecurity/service_traffic/$',
        CSecurityServiceTrafficAPI.as_view(),
        name="csec_service_traffic"),

    # pad service action log
    url(r'^csecurity/service_action_log/$',
        CSecServiceActionLogAPI.as_view(),
        name="csec_service_action_log"),

    # sync pad service action log
    url(r'^csecurity/service_action_log/sync/$',
        CSecuritySyncActionLogAPI.as_view(),
        name="csec_sync_service_log"),
)

urlpatterns = format_suffix_patterns(restfw_api_urlpatterns)
