
from datetime import timedelta

from rest_framework.response import Response
from rest_framework.views import APIView

from spectrum_api.cloudsecurity.models.pad_service_action_log import CSecurityPadServiceActionLog
from spectrum_api.cloudsecurity.models.pad_service_action_log import get_latest_action_log_id
from spectrum_api.cloudsecurity.models.pad_service_action_log import get_latest_oui_action_log_id
from spectrum_api.cloudsecurity.models.pad_service_action_log import get_csec_oui_action_log

from spectrum_api.cloudsecurity.views.csecurity_stat import CSecStatAPI
from spectrum_api.cloudsecurity.serializers.csecurity_stat import CSecActionLogSerializer

class CSecServiceActionLogAPI(CSecStatAPI):
    '''
        @url
            csecurity/service_action_log/
    '''
    serializer = CSecActionLogSerializer

    def post(self, request, *args, **kwargs):
        CSecStatAPI.post(self, request, *args, **kwargs)
        instance = self.get_serializer_instance()

        pad_security_service_id_list = CSecurityPadServiceActionLog.objects.filter(
            customer_site_id__in=instance.get_pad_id_list(),
            action_time__range=[
                str(instance.get_utc_from_date()),
                str(instance.get_utc_to_date() + timedelta(1))
            ]
        ).values('customer_site_id', 'service_state', 'action_time')

        last_log = CSecurityPadServiceActionLog.objects.filter(
            customer_site_id__in=instance.get_pad_id_list(),
            action_time__lte=str(instance.get_utc_from_date()))

        if last_log.exists():
            last_state = last_log.latest('action_id').service_state
        else:
            last_state = CSecurityPadServiceActionLog.SECURITY_SERVICE_STATE_RELEASED

        for service_log in pad_security_service_id_list:
            service_log['action_time'] += timedelta(0, 3600 * int(instance.utc_offset))

        response_data = {
            'service_action_log': pad_security_service_id_list,
            'last_state': last_state
        }

        return Response(response_data)

class CSecuritySyncActionLogAPI(APIView):
    '''
        @url
            csecurity/service_action_log/sync/
    '''

    # Implements
    def get(self, request, *args, **kwargs):
        '''
            @description
                Sync Central DB's cloud security action log.
        '''

        response_data = {}
        try:
            # get latest log id from action_log central db.
            latest_oui_log_id = get_latest_oui_action_log_id()

            if latest_oui_log_id:
                # get latest log id from action_log stat db.
                latest_log_id = get_latest_action_log_id()

                if int(latest_oui_log_id) is not latest_log_id:
                    # get security service action log from oui
                    oui_action_log_list = list(get_csec_oui_action_log(latest_log_id))

                    # to sync action log, insert to stat db
                    for oui_action_log in oui_action_log_list:
                        CSecurityPadServiceActionLog(
                            action_id=oui_action_log[0],
                            customer_site_id=oui_action_log[1],
                            cdn_service_id=oui_action_log[2],
                            action_time=oui_action_log[3],
                            service_state=oui_action_log[4],
                            obj_state=1
                        ).save()

                    response_data['msg'] = 'All logs are synced.'
                    response_data['synced_count'] = len(oui_action_log_list)
                    response_data['synced_log_list'] = oui_action_log_list

            else:
                response_data['msg'] = 'There is no logs to sync.'

            response_data['factor'] = 'success'

        except Exception as sync_exception:
            response_data['factor'] = 'fail'
            response_data['msg'] = 'Error occurred when sync service action log.'
            response_data['reason'] = str(sync_exception)

        return Response(response_data)
