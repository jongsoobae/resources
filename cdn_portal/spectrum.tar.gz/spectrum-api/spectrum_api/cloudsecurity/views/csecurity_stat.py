
from rest_framework.status import HTTP_400_BAD_REQUEST
from rest_framework.views import APIView
from rest_framework.exceptions import APIException

from spectrum_api.cloudsecurity.serializers.csecurity_stat import CSecStatSerializer

class CSecStatAPISerializerException(APIException):
    status_code = HTTP_400_BAD_REQUEST

class CSecStatAPI(APIView):
    serializer = CSecStatSerializer
    _serializer_instance = None

    def post(self, request, *args, **kwargs):
        serializer_instance = self.serializer(data=request.DATA)
        if serializer_instance.is_valid():
            self._serializer_instance = serializer_instance.object
        else:
            raise CSecStatAPISerializerException(serializer_instance.errors)

    def get_serializer_instance(self):
        return self._serializer_instance
