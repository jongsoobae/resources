
from rest_framework.response import Response

from spectrum_api.cloudsecurity.models.traffic_report_stat import CSecAttackTrafficStat
from spectrum_api.cloudsecurity.models.traffic_report_stat import CSecOriginTrafficStat
from spectrum_api.cloudsecurity.models.traffic_report_stat import CSecEdgeTrafficStat

from spectrum_api.cloudsecurity.serializers.csecurity_stat import CSecTrafficStatSerializer
from spectrum_api.cloudsecurity.serializers.csecurity_stat import CSecServiceTrafficStatSerializer

from spectrum_api.cloudsecurity.views.csecurity_stat import CSecStatAPI

class CSecurityAttackTrafficAPI(CSecStatAPI):
    '''
        @url
            /api/csecurity/attack_traffic/
    '''
    serializer = CSecTrafficStatSerializer

    def post(self, request, *args, **kwargs):
        CSecStatAPI.post(self, request, *args, **kwargs)
        instance = self.get_serializer_instance()

        response_data = {
            'stat_data': [
                CSecAttackTrafficStat(
                    stat_title='Attack',
                    stat_interval=instance.stat_interval,
                    utc_offset=instance.utc_offset,
                    from_date=instance.get_utc_from_date(),
                    to_date=instance.get_utc_to_date()
                ).get_traffic_report()
            ]
        }

        return Response(response_data)

class CSecurityServiceTrafficAPI(CSecStatAPI):
    '''
        @url
            /api/csecurity/service_traffic/
    '''
    serializer = CSecServiceTrafficStatSerializer

    def post(self, request, *args, **kwargs):
        CSecStatAPI.post(self, request, *args, **kwargs)
        instance = self.get_serializer_instance()

        response_data = {
            'stat_data': [
                CSecOriginTrafficStat(
                    item_id=instance.service_item_id, stat_title='Origin',
                    stat_interval=instance.stat_interval,
                    utc_offset=instance.utc_offset,
                    from_date=instance.get_utc_from_date(),
                    to_date=instance.get_utc_to_date()
                ).get_traffic_report(),

                CSecEdgeTrafficStat(
                    item_id=instance.service_item_id, stat_title='Edge',
                    stat_interval=instance.stat_interval,
                    utc_offset=instance.utc_offset,
                    from_date=instance.get_utc_from_date(),
                    to_date=instance.get_utc_to_date()
                ).get_traffic_report()
            ]
        }

        return Response(response_data)
