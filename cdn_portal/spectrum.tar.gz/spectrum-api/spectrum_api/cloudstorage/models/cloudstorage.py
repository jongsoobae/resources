from django.db import models
from django.db.models import Q
from django.conf import settings
from datetime import datetime, timedelta
from socket import inet_ntoa
from struct import pack
import traceback

from spectrum_api.sap.sap_calls import update_sap_cs_stats, get_connection
from spectrum_api.dna.models.domain import Domain
from spectrum_api.shared_components.models import BaseModel
from spectrum_api.shared_components.models import StatMaster
from spectrum_api.shared_components.models.customer import \
    CustomerDisplay, CustomerContract, CustomerItem, CustomerSfaOrder
from spectrum_api.shared_components.models import ActionHistory
from spectrum_api.shared_components.utils.common import log_error, get_vips_by_ipid
from spectrum_api.configuration.models.base import Vip

STORAGE_DEPLOY_STATUS = (
            (0, 'Modified'),
            (1, 'Pending Testing'),
            (2, 'Sent to Stage'),
            (3, 'Promote to Production'),
            (4, 'In Production'),
            (-2, 'Pending Failed'),
            (-4, 'Production Failed'),
)

STORAGE_STATUS = (
            (0, 'Offline'),
            (1, 'Online'),
            (2, 'Broken'),
            (3, 'unknown'),
)

CLUSTER_ENABLED_STATUS = (
            (0, 'Active'),
            (1, 'Inactive'),
)

STORAGE_NODE_TYPE = (
            (0, 'writer'),
            (1, 'reader'),
            (2, 'storage'),
)

STORAGE_DISK_TYPE = (
            (0, 'metadisk'),
            (1, 'datadisk'),
            (2, 'metabackup'),
)

STORAGE_DISK_PROTOCOL = (
            (0, 'nfs'),
            (1, 'local'),
)

STORAGE_USER_STATUS = (
            (0, 'disabled'),
            (1, 'enabled'),
)

STORAGE_USER_READONLY = (
            (0, 'disabled'),
            (1, 'enabled'),
)

STORAGE_NODE_STATUS = (
            (0, 'FAIL'),
            (1, 'OK'),
)

BOOLEAN_STATUS = (
            (0, 'false'),
            (1, 'true'),
)

CLUSTER_DISK_TYPE = (
            (-1, 'unknown'),
            (0, 'META'),
            (1, 'DATA'),
            (2, 'SUM'),
)

CLUSTER_DISK_STATUS = (
            (-1, 'unknown'),
            (0, 'DOWN'),
            (1, 'OK'),
            (2, 'FAIL'),
)

CONFIG_STATE = (
            (-1, 'N'),
            (0, 'N'),
            (1, 'OK'),
)

class Cluster(BaseModel):
    cluster_id = models.AutoField(primary_key=True)
    cluster_name = models.CharField(max_length=255, unique=True)
    total_blocks = models.BigIntegerField(null=True)
    used_blocks = models.BigIntegerField(default=0)
    block_size = models.PositiveIntegerField(null=True)
    # total_size = models.PositiveIntegerField(null=True)
    description = models.CharField(max_length=1024, null=True)
    max_lock_timeout = models.PositiveIntegerField(null=True)
    file_alloc_algorithm = models.CharField(max_length=50, null=True)
    status = models.PositiveSmallIntegerField(default=0, choices=STORAGE_STATUS)
    is_enabled = models.BooleanField(default=False)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    date_created = models.DateTimeField(null=True)
    obj_state = models.PositiveSmallIntegerField(default=1)
    config_state = models.IntegerField(default=0)

    class Meta:
        db_table = 'storage_cluster'
        ordering = ['cluster_name']

    class SpectrumMeta:
        router = 'default'

    def __unicode__(self):
        return self.cluster_name

    def getUsedSize(self):
        result = 0
        try:
            from django.db.models import Sum
            storagedisks = StorageDisk.objects.filter(node__cluster=self, node__node_type=2)
            if storagedisks.count() > 0:
                results = storagedisks.filter(disk_type=1).values('disk_type').annotate(used_size=Sum('idx', field='used_blocks*block_size'))
                for item in results:
                    result += int(item['used_size'])

            result = round(float(result) / float(1024 * 1024 * 1024), 2)
        except:
            pass
        return result

    def getTotalSize(self):
        result = 0
        try:
            from django.db.models import Sum
            storagedisks = StorageDisk.objects.filter(node__cluster=self, node__node_type=2)
            if storagedisks.count() > 0:
                results = storagedisks.filter(disk_type=1).values('disk_type').annotate(total_size=Sum('idx', field='total_blocks*block_size'))
                for item in results:
                    result += int(item['total_size'])

            result = round(float(result) / float(1024 * 1024 * 1024), 2)
        except:
            pass
        return result

    def getClusterStatus(self):
        result = 'unknown'
        try:
            writer_node = 0
            reader_node = 0
            node_all = 0
            writer_base_status = 0
            reader_base_status = 0
            mount_ok_status = 0
            base_enable_mount_ok = 0
            base_enable_mount_fail = 0
            node_id_chk = []

            cluster_node = StorageNode.objects.filter(cluster=self)
            node_status = StorageNodeStatus.objects.filter(node__cluster=self, node__node_type__in=[1,0])
            node_ips = [(snode.node.ip_id) for snode in node_status]
            node_ips_str = [(inet_ntoa(pack('!L', snode.node.ip_id))) for snode in node_status]
            vips = Vip.objects.filter(Q(vip_addr__in=node_ips_str) | Q(ihms_vip__in=node_ips))

            for nstatus in node_status:
                if node_id_chk is None or nstatus.node_id not in node_id_chk:
                    node_all += 1
                    node_id_chk.append(nstatus.node_id)

                    if nstatus.node.node_type == 0:  # Writer Node
                        writer_node += 1
                    elif  nstatus.node.node_type == 1:  # Reader Node
                        reader_node += 1

                    for vip in vips:
                        if vip.vip_addr == inet_ntoa(pack('!L', nstatus.node.ip_id)) or \
                        (vip.ihms_vip is not None and vip.ihms_vip.ip_id == nstatus.node.ip_id):
                            vip_info = vip

                    if vip_info.enable_gslb:
                        if nstatus.node.node_type == 0:  # Writer Node
                            writer_base_status += 1
                        elif nstatus.node.node_type == 1:  # Reader Node
                            reader_base_status += 1

                        if nstatus.mount_status == 1:
                            base_enable_mount_ok += 1
                        else:
                            base_enable_mount_fail += 1

                    if nstatus.mount_status == 1:
                        mount_ok_status += 1

            if cluster_node.exists():
                if reader_base_status == reader_node and \
                        writer_base_status == writer_node and \
                        mount_ok_status == node_all:
                    result = 'Online'
                elif writer_base_status > 0 and base_enable_mount_ok > 0:
                    result = 'Repairing'
                elif base_enable_mount_fail > 0:
                    result = 'Emergence (Case 2)'
                elif writer_base_status == 0:
                    result = 'Emergence (Case 1)'
                else:
                    result = 'Unknown'
        except:
            result = 'unknown'
        return result

    def getWaitQueue(self):
        result = 0
        try:
            waitqueues = StorageSidWaitQueue.objects.filter(cluster=self)
            for waitqueue in waitqueues:
                result += waitqueue.wait_queue_count
        except:
            pass
        return result

    def getSyncFailCount(self, date):
        result = 0
        try:
            if date == 1 or date == 2:
                default_dt = datetime.now()
                end_date = default_dt.strftime("%Y-%m-%d %H:%M:%S")
                start_date = (default_dt - timedelta(days=date)).strftime("%Y-%m-%d %H:%M:%S")

                result = StorageSyncFail.objects.filter(cluster=self, failed_time__range=(start_date, end_date)).count()
            else:
                result = StorageSyncFail.objects.filter(cluster=self).count()

        except:
            pass
        return result

    def getStatus(self):
        result = 'unknown'
        try:
            result = STORAGE_STATUS[self.status][1]  # # To do : sum leaf node status
            hasNodeAlive = False
            storagenodes = StorageNode.objects.filter(cluster=self)
            if storagenodes and storagenodes.count() > 0:
                for storagenode in storagenodes:
                    try:
                        nodestatus = storagenode.getNodeStatus()
                        if nodestatus == 'Online':
                            hasNodeAlive = True
                        else:
                            result = nodestatus

                    except:
                        pass
            else:
                result = 'N/A'
            if (result == 'Offline' or result == 'Broken') and hasNodeAlive:
                result = 'Broken'
        except:
            result = 'unknown'
        return result

    def getConfigState(self):
        if self.config_state == 1:
            return 'OK'
        else:
            return '-'

    def hasWriterNode(self):
        hasWriterNode = False
        try:
            storagenodes = StorageNode.objects.filter(cluster=self)
            for storagenode in storagenodes:
                if storagenode.node_type == 0:  # writer  ==> upload, master
                    hasWriterNode = True
                    break
        except:
            pass
        return hasWriterNode

class User(BaseModel):
    user_id = models.AutoField(primary_key=True)
    # storage = models.ForeignKey(Storage,db_column='storage_id')
    user_name = models.CharField(max_length=64, unique=True)
    access_path = models.CharField(max_length=256)
    password = models.CharField(max_length=128)
    enc_type = models.CharField(max_length=50)
    ssh_pubkey = models.TextField(max_length=65535, blank=True)
    status = models.PositiveSmallIntegerField(default=1, choices=STORAGE_USER_STATUS)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    date_created = models.DateTimeField(null=True)
    obj_state = models.PositiveSmallIntegerField(default=1)

    class Meta:
        db_table = 'storage_user'
        ordering = ['user_name']

    def __unicode__(self):
        return self.user_name

class Storage(BaseModel):
    storage_id = models.AutoField(primary_key=True)
    storage_name = models.CharField(max_length=64, unique=True)
    description = models.CharField(max_length=1024, null=True)
    user_service_domain = models.CharField(max_length=255, null=True)
    user_origin_domain = models.CharField(max_length=255, null=True)
    user_origin_domain_enabled = models.PositiveSmallIntegerField(default=1)
    user_upload_domain = models.CharField(max_length=255, null=True)
    user_master_domain = models.CharField(max_length=255, null=True)
    data_domain = models.ForeignKey(Domain, db_column='data_domain_id', null=True, on_delete=models.SET_NULL)
    upload_domain = models.ForeignKey(Domain, db_column='upload_domain_id', null=True, on_delete=models.SET_NULL)
    master_domain = models.ForeignKey(Domain, db_column='master_domain_id', null=True, on_delete=models.SET_NULL)
    status = models.PositiveSmallIntegerField(default=0, choices=STORAGE_DEPLOY_STATUS)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    date_created = models.DateTimeField(null=True)
    generate_gslb = models.PositiveSmallIntegerField(default=1)
    use_cdn_origin = models.PositiveSmallIntegerField(default=1)
    cdnw_status = models.PositiveSmallIntegerField(default=0)
    obj_state = models.PositiveSmallIntegerField(default=1)
    config_state = models.IntegerField(default=0)
    clusters = models.ManyToManyField(Cluster, db_table='storage_cluster_storage', related_name='storage_cluster_set')
    users = models.ManyToManyField(User, db_table='storage_user', related_name='user_set')
    customer = models.ForeignKey(CustomerDisplay, db_column='customer_id')
    contract = models.ForeignKey(CustomerContract, db_column='contract_no', null=True)
    # stat = models.ManyToManyField(StatMaster, db_table='storage_stat_master', related_name="%(app_label)s_%(class)s_releated")

    https_origin_domain_name = models.CharField(max_length=255, null=True)
    https_upload_domain_name = models.CharField(max_length=255, null=True)
    https_origin_domain = models.ForeignKey(Domain, db_column='https_origin_domain_id', null=True, on_delete=models.SET_NULL)
    https_upload_domain = models.ForeignKey(Domain, db_column='https_upload_domain_id', null=True, on_delete=models.SET_NULL)

    class Meta:
        db_table = 'storage_storage'
        ordering = ['storage_name']

    class SpectrumMeta:
        allow_delete = True
        track = True

    def __unicode__(self):
        return self.storage_name

    def getConfigState(self):
        if self.config_state == 1:
            return 'OK'
        else:
            return '-'

    def get_cloudstorage_cluster_limit(self, sales_charge):
        try:
            cluster_count = str(sales_charge).upper().strip()

            if cluster_count[-1] == 'P':
                cluster_count_limit = int(cluster_count[:-1])
            else:
                cluster_count_limit = int(cluster_count)
        except:
            cluster_count_limit = 0

        return cluster_count_limit

    def getPremiumContractCheck(self, sales_charge):
        try:
            cluster_count = str(sales_charge).upper().strip()

            if cluster_count[-1] == 'P':
                return 'Premium'
            else:
                return 'Standard'
        except:
            return 'Standard'

    def getCustomerItem(self):
        item = {"item_id":None, "item_no":None, "limit_count":None, "redundancy":"No Contract"}
        try:
            statmasters = StatMaster.objects.get(Q(material_no=settings.CLOUD_STORAGE_MATERIAL),
                                             Q(keyword=self.storage_name),
                                             Q(display_name=self.storage_name),
                                             Q(service_remove_flag__isnull=True) | ~Q(service_remove_flag=1))

            if statmasters:
                customeritem = CustomerItem.objects.get(item_id = statmasters.item.item_id)
                limit_count = self.get_cloudstorage_cluster_limit(customeritem.sales_charge)
                item = {"item_id":customeritem.item_id, "item_no":customeritem.item_no, "limit_count":limit_count
                        , "redundancy":self.getPremiumContractCheck(customeritem.sales_charge)}
        except:
            pass

        return item

    def isConfigPUSHable(self):
        try:
            if self.pk and self.clusters.count() > 0 and self.getActiveUserCount() > 0:
                storageclusters = StorageCluster.objects.filter(storage=self)
                for storagecluster in storageclusters:
                    if storagecluster.cluster.getConfigState() != 'OK':
                        return False
                    else:
                        pass
                return True
            else:
                return False
        except:
            return False

    def getReplicationCluster(self):
        try:
            storagesids = StorageSidConfig.objects.filter(storage=self.pk, param_name='ReplicateData', param_value='YES')
            if storagesids.exists():
                return 'Premium'
        except Exception, e:
            log_error(None, str(e), e)
        return 'Standard'

    def getReplicationCustomer(self):
        customer_replication = ''
        try:
            customer_items = CustomerItem.objects.filter(material_no=settings.CLOUD_STORAGE_MATERIAL)

            if self.contract:
                customer_items = customer_items.filter(contract=self.contract).order_by('-item_id')
            else:
                customer_items = customer_items.filter(contract__account=self.customer.account).order_by('-item_id')

            if customer_items:
                if customer_items.count == 1:
                    cluster_count = str(customer_items[0].sales_charge).upper().strip()
                else:
                    statmasters = StatMaster.objects.filter(material_no=settings.CLOUD_STORAGE_MATERIAL, \
                                                            keyword=self.storage_name, display_name=self.storage_name).order_by('-stat_id')
                    if statmasters:
                        stat_master = statmasters[0]
                        customer_item = customer_items.get(pk=stat_master.item.item_id)
                        cluster_count = str(customer_item.sales_charge).upper().strip()

                if cluster_count[-1] == 'P':
                    customer_replication = 'YES'
                else:
                    customer_replication = 'NO'
        except Exception as e:
            # logging
            log_error(None, str(e), e)

        return customer_replication

    def getStorageWaitQueue(self):
        result = 0
        try:
            waitqueues = StorageSidWaitQueue.objects.filter(storagecluster__storage=self)
            for waitqueue in waitqueues:
                result += waitqueue.wait_queue_count
        except:
            pass
        return result

    def getActiveUserCount(self):
        count = 0
        users = StorageUser.objects.filter(storage=self)
        for user in users:
            if user.status == 1:
                count = count + 1

        return count

    def getClusterUsedSizebySID(self, cluster_id):
        result = 0;
        try:
            storagestats = StorageStat.objects.filter(cluster=int(cluster_id), storage=int(self.storage_id)).order_by('-start_time')[:1]
            if storagestats:
                result = int(storagestats[0].block_number) * 4096  # int(disk.used_blocks*disk.block_size)
            result = round(float(result) / float(1024 * 1024 * 1024), 2)

        except Exception, e:
            log_error(None, str(e), e)
        return result;

    def isAllClusterSynchronized(self):
        try:
            if self.pk and self.clusters.count() > 0 and self.getActiveUserCount() > 0:
                storageclusters = StorageCluster.objects.filter(storage=self)
                clusterSize = -1
                for storagecluster in storageclusters:
                    tempClusterSize = self.getClusterUsedSizebySID(storagecluster.cluster.cluster_id)
                    if clusterSize == -1:
                        clusterSize = tempClusterSize
                    if clusterSize != tempClusterSize:
                        return False
                return True
            else:  # since no configuration there is no need to warn
                return True
        except:
            return False

    def isContractValid(self):
        try:
            today = datetime.today()
            yesterday = today - timedelta(days=1)
            customer_items = CustomerItem.objects.filter(Q(material_no=settings.CLOUD_STORAGE_MATERIAL),
                                                Q(status_code__isnull=True) | Q(status_code=''),
                                                Q(contract__contract_terminate__gte=yesterday,
                                                contract__contract_end__gte=yesterday) | Q(contract__contract_terminate__isnull=True,
                                                                                                contract__contract_end__gte=yesterday))
            if self.contract:
                customer_items = customer_items.filter(contract=self.contract)
            else:
                customer_items = customer_items.filter(contract__account=self.customer.account)

            if customer_items:
                if customer_items.count() == 1:
                    return True
                else:
                    return False  # multiple customer item
            else:
                return False
        except:  # no customer ??
            return False

    def save(self, *args, **kwargs):
        # AURORA: set account number for first time insert
        request = kwargs.get('request', None)
        contract_no = kwargs.pop('contract_no', None)
        item_id = kwargs.pop('item_id', None)

        # try:
        #    if contract_no:
        #        contract = CustomerContract.objects.get(contract_no=contract_no)
        #    else:
        #        contract = None
        # except:
        #    contract = None
        # hasContractChanged = False
        # if contract and self.contract:
        #    if self.contract != contract:
        #        hasContractChanged = True
        if self.isConfigPUSHable():
            self.config_state = 1
        else:
            self.config_state = 0

        super(Storage, self).save(*args, **kwargs)

        if self.obj_state == 1:
            # insert StatMaster
            statmasters = StatMaster.objects.filter(material_no=settings.CLOUD_STORAGE_MATERIAL, keyword=self.storage_name, display_name=self.storage_name)
            if statmasters.exists():
                stat_master = statmasters[0]
                stat_master.keyword = self.storage_name
                stat_master.display_name = self.storage_name
            else:
                stat_master = StatMaster(material_no=settings.CLOUD_STORAGE_MATERIAL, keyword=self.storage_name, display_name=self.storage_name)
            stat_master.customer = self.customer

            today = datetime.today()
            yesterday = today - timedelta(days=1)
            customer_items = CustomerItem.objects.filter(Q(material_no=settings.CLOUD_STORAGE_MATERIAL),
                                                    Q(status_code__isnull=True) | Q(status_code=''),
                                                    Q(contract__contract_terminate__gte=yesterday,
                                                    contract__contract_end__gte=yesterday) | Q(contract__contract_terminate__isnull=True,
                                                                                               contract__contract_end__gte=yesterday))

            if item_id is not None and item_id != '':
                if contract_no:
                    customer_items = customer_items.filter(contract__contract_no=contract_no, item_id=item_id)
                else:
                    customer_items = customer_items.filter(contract__account=self.customer.account, item_id=item_id)

                if customer_items.count() == 1:
                    stat_master.item = customer_items[0]
                    # now mark complete if not complete...
                    orders = CustomerSfaOrder.objects.filter(item=stat_master.item, status=2)
                    for order in orders:
                        conn = get_connection()
                        # make call to SAP to mark complete...
                        try:
                            check_updated = update_sap_cs_stats(request, order.pk, 9, connection=conn)
                            if check_updated:
                                order.status = 9
                                order.save(request=request)
                        except:
                            order.status = -1
                            order.save(request=request)
                else:  # customer item does not exist
                    """ IF ITEM COUNT == 0 DO NOT ALLOW USER TO CREATE ZONE """
                    pass
            else:
                stat_master.item = None

            try:
                stat_master.save(request=kwargs.get('request', None))
                storagestatmasters = StorageStatMaster.objects.filter(storage=self, statmaster=stat_master)
                if storagestatmasters:
                    pass
                else:
                    storagestatmaster = StorageStatMaster(storage=self, statmaster=stat_master)
                    storagestatmaster.save(request=kwargs.get('request', None))

            except Exception, e:
                title = 'SID is created but stat_master is not generated correctly'
                message = 'HTTP HOST: {host}\nSERVER NAME: {server}\n\nSID is created but stat_master is not generated correctly\n\nZone Id: {storage_id}\nStorage Name: {storage_name}\n\nTrace Back:{trace}'.format(host=request.get_host(), server=request.META['SERVER_NAME'], storage_id=self.pk, storage_name=self.storage_name, trace=traceback.format_exc(e))
                log_error(request, message, e, None, title)

    def getPreviousUserServiceDomain(self):
        result = ''
        actions = ActionHistory.objects.filter(action_model='storage_storage', action_pk=self.pk).order_by('-action_id')
        for action in actions:
            previousDomain = action.getjsonitem('user_service_domain')
            if previousDomain != '' and self.user_service_domain != previousDomain:
                result = previousDomain
                break
        return result

    def getPreviousUserOriginDomain(self):
        result = ''
        actions = ActionHistory.objects.filter(action_model='storage_storage', action_pk=self.pk).order_by('-action_id')
        for action in actions:
            previousDomain = action.getjsonitem('user_origin_domain')
            if previousDomain != '' and self.user_origin_domain != previousDomain:
                result = previousDomain
                break
        return result

    def getPreviousUserUploadDomain(self):
        result = ''
        actions = ActionHistory.objects.filter(action_model='storage_storage', action_pk=self.pk).order_by('-action_id')
        for action in actions:
            previousDomain = action.getjsonitem('user_upload_domain')
            if previousDomain != '' and self.user_upload_domain != previousDomain:
                result = previousDomain
                break
        return result

    def getBackupDomain(self):
        return 'backup.' + self.user_origin_domain

    def getServiceGenerated(self):
        try:
            core = self.user_origin_domain.split('.')
            if len(core) > 1:
                if self.use_cdn_origin == 1:
                    return self.user_origin_domain
                else:
                    return self.user_origin_domain + '.sf.cdngp.net'
            else:
                return ''
        except:
            return ''

    def getBackupGenerated(self):
        try:
            core = self.user_service_domain.split('.')
            if len(core) > 1:
                # if self.use_cdn_origin ==1:
                #    return 'backup.origin.'+self.user_service_domain
                # else:
                return 'backup.origin.' + self.user_service_domain + '.sf.cdngp.net'
            else:
                return ''
        except:
            return ''

    def getUploadGenerated(self):
        try:
            core = self.user_upload_domain.split('.')
            if len(core) > 1:
                if self.use_cdn_origin == 1:
                    return self.user_upload_domain
                else:
                    return self.user_upload_domain + '.sf.cdngp.net'
            else:
                return ''
        except:
            return ''

    # deprecated
    def getMasterGenerated(self):
        try:
            core = self.user_service_domain.split('.')
            if len(core) > 1:
                # if self.use_cdn_origin ==1:
                #    return 'master.upload.'+self.user_service_domain
                # else:
                return 'master.upload.' + self.user_service_domain + '.sf.cdngp.net'
            else:
                return ''
        except:
            return ''

    def getUser_origin_domain_enabled(self):
        if self and self.pk and self.user_origin_domain_enabled == 1:
            return 'enabled'
        else:
            return 'disabled'

    def getClusterList(self):
        storage_clusters = StorageCluster.objects.filter(storage=self.storage_id)
        return storage_clusters

    def getUsedSize(self):
        result = 0
        try:
            for z in self.clusters.filter(obj_state=1):
                storagestats = StorageStat.objects.filter(cluster=int(z.cluster_id), storage=int(self.storage_id)).order_by('-start_time')[:1]
                if storagestats.count() > 0:
                    try:
                        if storagestats[0]:
                            result += int(storagestats[0].block_number) * 4096  # int(disk.used_blocks*disk.block_size)
                    except:
                        pass
            result = round(float(result) / float(1024 * 1024 * 1024), 2)

        except Exception, e:
            from spectrum_api.shared_components.utils.common import log_event
            log_event('spectrum_system', str(e), 'cloud storage', e)
        return result

    def getTotalSize(self):
        result = 0
        for z in self.clusters.filter(obj_state=1):
            result += z.getTotalSize()
        return result

    def getUserList(self):
        result = ''
        i = 0;
        for z in self.users.filter(obj_state=1):
            result += z.user_name + ","
            i = i + 1
            if i >= 3:
                result = result[:-1] + "..."
                break
        if result.endswith(',') :
            return result[:-1]
        else:
            return result

    def delete_related(self, request):
        try:
            storageusers = StorageUser.objects.filter(storage=self.pk)
            if storageusers:
                for storageuser in storageusers:
                    storageuser.delete(request=request)

            storagemimes = StorageMimeConfig.objects.filter(storage=self.pk)
            if storagemimes:
                for storagemime in storagemimes:
                    storagemime.delete(request=request)

            storagesids = StorageSidConfig.objects.filter(storage=self.pk)
            if storagesids:
                for storagesid in storagesids:
                    storagesid.delete(request=request)

            storageipacls = StroageIpbasedAcl.objects.filter(storage=self.pk)
            if storageipacls:
                for storageipacl in storageipacls:
                    storageipacl.delete(request=request)
        except Exception, e:
            log_error(request, str(e), e)
            raise e

    def isDeletable(self):
        if  self.clusters.count() > 0:  # self.users.count() > 1 or
            return 'false'
        else:
            return 'true'


class BaseStorageCluster(BaseModel):
    idx = models.AutoField(primary_key=True)
    is_preferred_cluster = models.PositiveSmallIntegerField(default=0)
    backup_order = models.PositiveSmallIntegerField()
    backup_domain = models.ForeignKey(Domain, db_column='backup_domain_id', null=True, on_delete=models.SET_NULL)
    backup_https_domain = models.ForeignKey(Domain, db_column='backup_https_domain_id', null=True, on_delete=models.SET_NULL)
    backup_upload_domain = models.ForeignKey(Domain, db_column='backup_upload_domain_id', null=True, on_delete=models.SET_NULL)
    backup_https_upload_domain = models.ForeignKey(Domain, db_column='backup_https_upload_domain_id', null=True, on_delete=models.SET_NULL)
    status = models.PositiveSmallIntegerField(default=0, choices=STORAGE_DEPLOY_STATUS)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    date_created = models.DateTimeField(null=True)
    obj_state = models.PositiveSmallIntegerField(default=1)

    class Meta:
        db_table = 'storage_cluster_storage'
        abstract = True
        ordering = ['idx']

    def __unicode__(self):
        return str(self.idx)


class StorageCluster(BaseStorageCluster):
    storage = models.ForeignKey(Storage, db_column='storage_id')
    cluster = models.ForeignKey(Cluster, db_column='cluster_id')

    class SpectrumMeta:
        allow_delete = True
        track = True
        # router = 'default'

    def save(self, *args, **kwargs):
        # AURORA: set account number for first time insert
        super(StorageCluster, self).save(*args, **kwargs)


    def getBackupDomain(self):
        # core = self.storage.user_service_domain.split('.')
        # if len(core) > 1:
        #    # if self.storage.use_cdn_origin ==1:
        #    #    servicedomain = 'origin.'+self.storage.user_service_domain
        #    # else:
        servicedomain = 'origin.' + self.storage.user_service_domain + '.sf.cdngp.net'
        # else:
        #    servicedomain = ''
        return 'backup' + str(self.backup_order) + '.' + servicedomain

    def getBackupOrigin(self):
        # core = self.storage.user_service_domain.split('.')
        # if len(core) > 1:
        return 'backup' + str(self.backup_order) + '.' + self.storage.user_origin_domain
        # else:
        #    return ''

    def getMaxBackupOrder(self):
        maxno = 0
        storageclusters = StorageCluster.objects.filter(storage=self.storage)

        for storagecluster in storageclusters:
            if storagecluster.backup_order > maxno:
                maxno = storagecluster.backup_order
            # tempmaxno = int(maxno+1)
            # if storagecluster.backup_order != tempmaxno:
            #    maxno = tempmaxno -1
            # elif storagecluster.backup_order > maxno:
            #    maxno = storagecluster.backup_order
        return maxno + 1

    def getStorageStatsTime(self):
        storagestats = None

        try:
            storagestatsAll = StorageStat.objects.filter(storage=int(self.storage.storage_id)).order_by('-start_time')[:1]

            if storagestatsAll.exists():
                dateStart = storagestatsAll[0].start_time - timedelta(days=1)
                storagestats = StorageStat.objects.filter(cluster=int(self.cluster.cluster_id),
                                                                        storage=int(self.storage.storage_id),
                                                                        start_time__range=(dateStart, storagestatsAll[0].start_time)).order_by('-start_time')[:1]
        except:
            pass

        return storagestats

    def getVirtualHostBackupDomain(self):
        cluster_vhosts = StorageClusterVhosts.objects.filter(sid_cluster=int(self.idx))

        domainlist = []
        for cluster_vhost in cluster_vhosts:
            vhost_domain = Domain.objects.get(domain_id=cluster_vhost.backup_domain.domain_id)
            if vhost_domain:
                domainlist.append(vhost_domain.name)
            else:
                domainlist.append('backup' + str(self.backup_order) + '.')

        return domainlist

    def getVirtualHostBackupOrigin(self):
        cluster_vhosts = StorageClusterVhosts.objects.filter(sid_cluster=int(self.idx))

        domainlist = []
        for cluster_vhost in cluster_vhosts:
            core = cluster_vhost.vhosts.starfs_service_domain.split('.')
            if len(core) > 1:
                domainlist.append('backup' + str(self.backup_order) + '.' + cluster_vhost.vhosts.starfs_service_domain)

        return domainlist

    def get_full_name(self):
        return str(self.storage.storage_name + ' [' + self.cluster.cluster_name + ']')


class StorageStatMaster(BaseModel):
    storagestatmaster_id = models.AutoField(primary_key=True,
        db_column='id')
    storage = models.ForeignKey(Storage)
    statmaster = models.ForeignKey(StatMaster)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    date_created = models.DateTimeField(null=True)
    obj_state = models.PositiveSmallIntegerField(default=1)

    class Meta:
        db_table = 'storage_stat_master'
        ordering = ['storage']

    def __unicode__(self):
        return self.storage.storage_name + " (" + str(self.statmaster.pk) + ")"

# need ip duplication check?
class StroageIpbasedAcl(BaseModel):
    acl_id = models.AutoField(primary_key=True)
    policy = models.CharField(max_length=20)
    protocol = models.CharField(max_length=20)
    permission = models.CharField(max_length=20)
    ipaddr = models.CharField(max_length=15)
    subnet_mask = models.CharField(max_length=15)
    description = models.CharField(max_length=256, blank=True, null=True)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    date_created = models.DateTimeField(null=True)
    obj_state = models.PositiveSmallIntegerField(default=1)
    storage = models.ForeignKey(Storage, db_column='storage_id')
    acl_order = models.IntegerField()

    class Meta:
        db_table = 'storage_ipbased_acl'
        ordering = ['acl_order']

    class SpectrumMeta:
        allow_delete = True
        track = True

    def __unicode__(self):
        return str(self.storage) + ':' + str(self.ipaddr)

class StorageSidConfig(BaseModel):
    sid_config_id = models.AutoField(primary_key=True)
    param_name = models.CharField(max_length=256, unique=True)
    param_value = models.CharField(max_length=128)
    status = models.PositiveSmallIntegerField(default=0, choices=STORAGE_DEPLOY_STATUS)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    date_created = models.DateTimeField(null=True)
    obj_state = models.PositiveSmallIntegerField(default=1)
    storage = models.ForeignKey(Storage, db_column='storage_id')

    class Meta:
        db_table = 'storage_sid_config'
        ordering = ['param_name']

    class SpectrumMeta:
        allow_delete = True
        track = True

    def __unicode__(self):
        return self.param_name

class StorageMimeConfig(BaseModel):
    sid_mimeconfig_id = models.AutoField(primary_key=True)
    param_name = models.CharField(max_length=256, unique=True)
    param_value = models.CharField(max_length=128)
    status = models.PositiveSmallIntegerField(default=0, choices=STORAGE_DEPLOY_STATUS)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    date_created = models.DateTimeField(null=True)
    obj_state = models.PositiveSmallIntegerField(default=1)
    storage = models.ForeignKey(Storage, db_column='storage_id')

    class Meta:
        db_table = 'storage_sid_mimeconfig'
        ordering = ['param_name']

    class SpectrumMeta:
        allow_delete = True
        track = True

    def __unicode__(self):
        return self.param_name

class ClusterConfig(BaseModel):
    idx = models.AutoField(primary_key=True)
    param_name = models.CharField(max_length=256, unique=True)
    param_value = models.CharField(max_length=128)
    status = models.PositiveSmallIntegerField(default=0, choices=STORAGE_DEPLOY_STATUS)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    date_created = models.DateTimeField(null=True)
    obj_state = models.PositiveSmallIntegerField(default=1)
    cluster = models.ForeignKey(Cluster, db_column='cluster_id')

    class Meta:
        db_table = 'storage_config'
        ordering = ['param_name']

    class SpectrumMeta:
        allow_delete = True
        track = True

    def __unicode__(self):
        return self.param_name

    def save(self, *args, **kwargs):
        super(ClusterConfig, self).save(*args, **kwargs)


class GlobalClusterConfig(BaseModel):
    idx = models.AutoField(primary_key=True)
    param_name = models.CharField(max_length=256)
    param_value = models.CharField(max_length=128)
    status = models.PositiveSmallIntegerField(default=0, choices=STORAGE_DEPLOY_STATUS)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    date_created = models.DateTimeField(null=True)
    obj_state = models.PositiveSmallIntegerField(default=1)

    class Meta:
        db_table = 'global_storage_config'
        ordering = ['param_name']

    class SpectrumMeta:
        allow_delete = True
        track = True

    def __unicode__(self):
        return self.param_name

    def save(self, *args, **kwargs):
        super(GlobalClusterConfig, self).save(*args, **kwargs)

class StorageNode(BaseModel):
    node_id = models.AutoField(primary_key=True)
    node_name = models.CharField(max_length=255)
    node_type = models.PositiveSmallIntegerField(default=0, choices=STORAGE_NODE_TYPE)
    node_type_name = models.CharField(max_length=20)
    ip_id = models.IPAddressField()  # models.PositiveIntegerField()
    configuration = models.CharField(max_length=1024, null=True)
    ping_status = models.PositiveSmallIntegerField(default=0, choices=STORAGE_STATUS)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    date_created = models.DateTimeField(null=True)
    obj_state = models.PositiveSmallIntegerField(default=1)
    cluster = models.ForeignKey(Cluster, db_column='cluster_id')

    class Meta:
        db_table = 'storage_node'
        ordering = ['node_type']

    class SpectrumMeta:
        allow_delete = True
        track = True

    def __unicode__(self):
        return '%s(%s)' % (self.cluster, self.getIP())

    def getIP(self):
        return inet_ntoa(pack('!L', self.ip_id))

    def getNodeType(self):
        result = 'unknown'
        try:
            return STORAGE_NODE_TYPE[self.node_type][1]
        except:
            return result

    def getStorageDisks(self):
        return StorageDisk.objects.filter(node=self.node_id)

    def getFullHostName(self):
        result = ''
        try:
            vips = get_vips_by_ipid(self.ip_id)
            if vips.exists():
                result =  vips[0].host.get_fullhostname()
        except:
            pass
        return result

    def getNodeStatus(self):
        result = ''
        try:
            vips = get_vips_by_ipid(self.ip_id)
            if vips.exists():
                if vips[0].enable_gslb:
                    result = 'Up'
                else:
                    result = 'Down'
        except:
            pass
        return result

    def getMountStatus(self):
        result = ''
        try:
            if self.node_type != 2:
                node_status = StorageNodeStatus.objects.filter(node=self)
                if node_status.exists():
                    result = STORAGE_NODE_STATUS[node_status[0].mount_status][1]
        except:
            pass
        return result

    def getBaseVersion(self):
        result = ''
        try:
            node_status = StorageNodeStatus.objects.filter(node=self)
            if node_status.exists():
                result = node_status[0].base_version
        except:
            pass
        return result

    def getConfigVersion(self):
        result = ''
        try:
            node_status = StorageNodeStatus.objects.filter(node=self)
            if node_status.exists():
                result = node_status[0].config_version
        except:
            pass
        return result

class StorageDisk(BaseModel):
    idx = models.AutoField(primary_key=True)
    node = models.ForeignKey(StorageNode, db_column='node_id')
    disk_no = models.PositiveIntegerField()
    disk_type = models.PositiveSmallIntegerField(default=1, choices=STORAGE_DISK_TYPE)
    total_blocks = models.BigIntegerField(null=True)
    used_blocks = models.BigIntegerField(default=0)
    block_size = models.PositiveIntegerField(null=True)
    protocol = models.CharField(max_length=20)
    path = models.CharField(max_length=256)
    description = models.CharField(max_length=1024, null=True)
    is_newfile = models.PositiveSmallIntegerField(default=0)
    status = models.PositiveSmallIntegerField(default=0, choices=BOOLEAN_STATUS)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    date_created = models.DateTimeField(null=True)
    obj_state = models.PositiveSmallIntegerField(default=1)

    class Meta:
        db_table = 'storage_disk'
        ordering = ['disk_no']

    class SpectrumMeta:
        allow_delete = True
        track = True

    # def __unicode__(self):
    #    return self.idx

    def getDiskType(self):
        result = 'unknown'
        try:
            return STORAGE_DISK_TYPE[self.disk_type][1]
        except:
            return result

    def getActiveStatus(self):
        try:
            return BOOLEAN_STATUS[self.status][1]
        except:
            return 'false'

    def getisNewfile(self):
        try:
            return BOOLEAN_STATUS[self.is_newfile][1]
        except:
            return 'false'


class StorageUser(BaseModel):
    user_id = models.AutoField(primary_key=True)
    storage = models.ForeignKey(Storage, db_column='storage_id')
    user_name = models.CharField(max_length=64, unique=True)
    access_path = models.CharField(max_length=256)
    raw_password = models.CharField(max_length=128)
    password = models.CharField(max_length=128)
    enc_type = models.CharField(max_length=50)
    ssh_pubkey = models.TextField(max_length=65535, blank=True)
    status = models.PositiveSmallIntegerField(default=1, choices=STORAGE_USER_STATUS)
    is_readonly = models.PositiveSmallIntegerField(default=0, choices=STORAGE_USER_READONLY)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    date_created = models.DateTimeField(null=True)
    obj_state = models.PositiveSmallIntegerField(default=1)

    class Meta:
        db_table = 'storage_user'
        ordering = ['storage', 'user_name']

    class SpectrumMeta:
        allow_delete = True
        track = True

    def __unicode__(self):
        return self.user_name

    def getUserStatus(self):
        result = 'unknown'
        try:
            return STORAGE_USER_STATUS[self.status][1]
        except:
            return result

    def getSSH_pubkey(self):
        result = ''
        if len(self.ssh_pubkey) > 0:
            result = self.ssh_pubkey
        return result

    def save(self, *args, **kwargs):
        super(StorageUser, self).save(*args, **kwargs)

class StorageStat(models.Model):
    cluster = models.ForeignKey(Cluster, db_column='cluster_id')
    storage = models.ForeignKey(Storage, db_column='storage_id')
    start_time = models.DateTimeField(primary_key=True)
    status = models.CharField()
    block_number = models.BigIntegerField()
    directory_number = models.BigIntegerField()
    file_number = models.BigIntegerField()

    class Meta:
        unique_together = ('start_time', 'storage_id', 'cluster_id')
        ordering = ['start_time']
        db_table = 'storage_stats'
        # get_latest_by = 'start_time'

    class SpectrumMeta:
        read_only = True
        router = 'stats'


class StorageHistory(models.Model):
    cluster = models.ForeignKey(Cluster, db_column='cluster_id')
    start_time = models.DateTimeField()
    disk_no = models.IntegerField()
    disk_type = models.IntegerField()
    disk_status = models.IntegerField()
    total_blocks = models.BigIntegerField()
    used_blocks = models.BigIntegerField()
    block_size = models.IntegerField()
    newfile_flag = models.CharField()

    class Meta:
        unique_together = ('start_time', 'cluster_id', 'disk_no', 'disk_type')
        ordering = ['start_time']
        db_table = 'storage_history'

    class SpectrumMeta:
        router = 'default'

class StorageSnapshotIoEvent(BaseModel):
    id = models.AutoField(primary_key=True)
    cluster_storage_id = models.ForeignKey(StorageCluster, db_column='cluster_storage_id')
    node_id = models.ForeignKey(StorageNode, db_column='node_id')
    event_id = models.CharField()
    io_type = models.CharField()
    dst_cluster_id = models.ForeignKey(Cluster, db_column='dst_cluster_id', on_delete=models.DO_NOTHING)
    start_time = models.DateTimeField()
    error = models.IntegerField()
    objname = models.CharField()
    optname = models.CharField()
    updatetime = models.DateTimeField()
    isValid = models.IntegerField()

    class Meta:
        unique_together = ('cluster_storage_id', 'node_id', 'event_id', 'io_type', 'dst_cluster_id', 'isValid')
        ordering = ['cluster_storage_id', 'event_id', '-start_time']
        db_table = 'storage_snapshot_io_event'

    class SpectrumMeta:
        # read_only = True
        allow_delete = True
        track = True

    def __unicode__(self):
        return "%s %s" % (self.event_id, self.cluster_storage_id)

class StorageSnapshotSyncMismatch(BaseModel):
    id = models.AutoField(primary_key=True)
    cluster_storage_id = models.ForeignKey(StorageCluster, db_column='cluster_storage_id')
    dst_cluster_id = models.ForeignKey(Cluster, db_column='dst_cluster_id', on_delete=models.DO_NOTHING)
    filename = models.CharField()
    filesize = models.IntegerField()
    updatetime = models.DateTimeField()
    isValid = models.IntegerField()

    class Meta:
        unique_together = ('cluster_storage_id', 'dst_cluster_id', 'filename', 'isValid')
        ordering = ['cluster_storage_id', 'dst_cluster_id']
        db_table = 'storage_snapshot_sync_mismatch'

    class SpectrumMeta:
        # read_only = True
        allow_delete = True
        track = True

    def __unicode__(self):
        return "%s %s" % (self.cluster_storage_id, self.dst_cluster_id)


class StorageConfigParameter(BaseModel):
    config_param_id = models.AutoField(primary_key=True)
    param_name = models.CharField(max_length=255, unique=True)
    value_type = models.IntegerField()
    param_desc = models.CharField(max_length=1024, null=True)
    date_created = models.DateTimeField(null=True)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    obj_state = models.PositiveSmallIntegerField(default=1)

    class Meta:
        db_table = 'storage_config_parameter'
        ordering = ['param_name']

    class SpectrumMeta:
        allow_delete = True
        track = True

    def __unicode__(self):
        return self.param_name


class StorageOriginTraffic(models.Model):
    cluster = models.PositiveIntegerField(db_column='cluster_id')
    storagecluster = models.PositiveIntegerField(db_column='cluster_storage_id')
    node = models.PositiveIntegerField(db_column='cluster_node_id')
    start_time = models.DateTimeField(primary_key=True)
    origin_traffic = models.BigIntegerField(default=0)

    class Meta:
        unique_together = ('start_time', 'cluster_id', 'cluster_storage_id', 'cluster_node_id')
        ordering = ['start_time']
        db_table = 'storage_origin_traffic'

    class SpectrumMeta:
        read_only = True
        router = 'stats'

class StorageSyncFail(models.Model):
    cluster = models.PositiveIntegerField(db_column='cluster_id')
    storagecluster = models.PositiveIntegerField(db_column='cluster_storage_id')
    node = models.PositiveIntegerField(db_column='node_id')
    dst_cluster = models.PositiveIntegerField(db_column='dst_cluster_id')
    io_type = models.CharField()
    failed_time = models.DateTimeField(primary_key=True)
    objname = models.CharField()
    optname = models.CharField()

    class Meta:
        unique_together = ('cluster_id', 'cluster_storage_id', 'node_id','dst_cluster_id', 'ip_type', 'objname')
        ordering = ['cluster','storagecluster','failed_time']
        db_table = 'storage_sync_fail'

    class SpectrumMeta:
        read_only = True
        router = 'stats'

class StorageNodeStatus(models.Model):
    node = models.PositiveIntegerField(db_column='node_id')
    start_time = models.DateTimeField(primary_key=True)
    http_session_count = models.BigIntegerField(default=0)
    ftp_session_count = models.BigIntegerField(default=0)
    ssh_session_count = models.BigIntegerField(default=0)
    mount_status = models.PositiveSmallIntegerField(default=1, choices=STORAGE_NODE_STATUS)
    base_version = models.IntegerField()
    config_version = models.IntegerField()

    class Meta:
        unique_together = ('node_id', 'start_time')
        ordering = ['-start_time']
        db_table = 'storage_snapshot_node_status'

    class SpectrumMeta:
        read_only = True
        router = 'stats'

class StorageSidWaitQueue(models.Model):
    cluster = models.PositiveIntegerField(db_column='cluster_id')
    storagecluster = models.PositiveIntegerField(db_column='cluster_storage_id')
    node = models.PositiveIntegerField(db_column='cluster_node_id')
    start_time = models.DateTimeField(primary_key=True)
    wait_queue_count = models.BigIntegerField(default=0)

    class Meta:
        unique_together = ('start_time', 'cluster_id', 'cluster_storage_id', 'cluster_node_id')
        ordering = ['start_time']
        db_table = 'storage_sid_wait_queue'

    class SpectrumMeta:
        read_only = True
        router = 'stats'

class StorageSidVhosts(BaseModel):
    idx = models.AutoField(primary_key=True)
    storage = models.ForeignKey(Storage, db_column='storage_id')
    service_domain = models.CharField(max_length=255, null=True)
    starfs_service_domain = models.CharField(max_length=255, null=True)
    gslb_service_domain = models.ForeignKey(Domain, db_column='gslb_service_domain_id', null=True, on_delete=models.SET_NULL)
    use_cdn_origin_enabled = models.PositiveSmallIntegerField(default=1)
    dcm_root = models.CharField(max_length=255)
    date_created = models.DateTimeField(null=True)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)

    https_service_domain_name = models.CharField(max_length=255, null=True)
    https_service_domain = models.ForeignKey(Domain, db_column='https_service_domain_id', null=True, on_delete=models.SET_NULL)

    class Meta:
        unique_together = ('storage_id', 'service_domain', 'starfs_service_domain', 'gslb_service_domain_id')
        ordering = ['idx']
        db_table = 'storage_sid_vhosts'

    class SpectrumMeta:
        allow_delete = True
        track = True

    def __unicode__(self):
        return "%s %s" % (self.storage, self.service_domain)

    def save(self, *args, **kwargs):
        # AURORA: set account number for first time insert
        super(StorageSidVhosts, self).save(*args, **kwargs)

    def getVhostsGslbServiceUrl(self):
        try:
            core = self.starfs_service_domain.split('.')
            if len(core) > 1:
                if self.use_cdn_origin_enabled == 1:
                    return self.starfs_service_domain
                else:
                    return self.starfs_service_domain + '.sf.cdngp.net'
            else:
                return ''
        except:
            return ''

    def get_full_name(self):
        return str(self.storage.storage_name + ' :: ' + self.service_domain)

class StorageClusterVhosts(BaseModel):
    idx = models.AutoField(primary_key=True)
    vhosts = models.ForeignKey(StorageSidVhosts, db_column='vhosts_id')
    sid_cluster = models.ForeignKey(StorageCluster, db_column='sid_cluster_id')
    backup_domain = models.ForeignKey(Domain, db_column='backup_domain_id', null=True, on_delete=models.SET_NULL)
    backup_https_domain = models.ForeignKey(Domain, db_column='backup_https_domain_id', null=True, on_delete=models.SET_NULL)
    obj_state = models.PositiveSmallIntegerField(default=1)
    date_created = models.DateTimeField(null=True)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)

    class Meta:
        unique_together = ('vhosts_id', 'sid_cluster_id')
        ordering = ['idx']
        db_table = 'storage_cluster_vhosts'

    class SpectrumMeta:
        allow_delete = True
        track = True

    def __unicode__(self):
        return "%s %s" % (self.vhosts, self.backup_domain)

    def save(self, *args, **kwargs):
        # AURORA: set account number for first time insert
        super(StorageClusterVhosts, self).save(*args, **kwargs)

    def get_full_name(self):
        return str(self.sid_cluster.storage.storage_name + '[' + self.sid_cluster.cluster.cluster_name + '] :: ' + self.vhosts.service_domain)


class StorageConfigParameter(BaseModel):
    config_param_id = models.AutoField(primary_key=True)
    param_name = models.CharField(max_length=255, unique=True)
    value_type = models.IntegerField()
    param_desc = models.CharField(max_length=1024, null=True)
    date_created = models.DateTimeField(null=True)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    obj_state = models.PositiveSmallIntegerField(default=1)

    class Meta:
        db_table = 'storage_config_parameter'
        ordering = ['param_name']

    class SpectrumMeta:
        allow_delete = True
        track = True

    def __unicode__(self):
        return self.param_name
