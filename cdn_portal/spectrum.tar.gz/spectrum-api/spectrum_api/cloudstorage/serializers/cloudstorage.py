# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        CloudStorage Serializer
"""
import re
from django.utils.translation import ugettext as _
from rest_framework import serializers
from spectrum_api.cloudstorage.models.cloudstorage import STORAGE_DISK_TYPE, \
    Cluster, Storage, StorageCluster, StorageNode, StorageDisk, \
    StorageOriginTraffic, StorageSidWaitQueue, StorageSyncFail, \
    StorageUser, StorageSidVhosts, StorageConfigParameter, \
    StorageSidConfig, StorageMimeConfig, StroageIpbasedAcl


class SubStorageNodeSerializer(serializers.ModelSerializer):
    ip = serializers.SerializerMethodField("get_ip")

    class Meta:
        model = StorageNode
        fields = ("node_id",
                  "node_type",
                  "node_type_name",
                  "ip_id",
                  "ip"
                  )

    def get_ip(self, obj):
        try:
            return obj.getIP()
        except:
            return ''

class SubStorageDiskSerializer(serializers.ModelSerializer):
    disk_id = serializers.RelatedField(source='idx')
    disk_type_name = serializers.SerializerMethodField('get_disk_type_name')

    class Meta:
        model = StorageDisk
        fields = ("disk_id",
                  "disk_no",
                  "disk_type",
                  "disk_type_name",
                  "total_blocks",
                  "used_blocks",
                  "block_size"
                  )

    def get_disk_type_name(self, data):
        if data:
            return STORAGE_DISK_TYPE[data.disk_type][1]
        else:
            return ''

class ClusterAllSerializer(serializers.ModelSerializer):
    storagenodes = SubStorageNodeSerializer(many=True, source="storagenode_set", required=False)

    class Meta:
        model = Cluster
        fields = ("cluster_id",
                  "cluster_name",
                  "storagenodes"
                  )

class ClusterSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cluster
        fields = ("cluster_id",
                  "cluster_name",
                  "date_created",
                  "date_modified"
                  )

class ClusterNodeDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = StorageNode
        fields = ("node_id",
                  "node_type",
                  "node_type_name",
                  "ip_id"
                  )

class ClusterNodeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cluster
        fields = ("cluster_id",
                  "cluster_name"
              )

class StorageOriginTrafficSerializer(serializers.ModelSerializer):
    class Meta:
        model = StorageOriginTraffic
        fields = ("cluster",
                    "storagecluster",
                    "node",
                    "origin_traffic",
                    "start_time"
                  )

class StorageWaitQueueSerializer(serializers.ModelSerializer):
    class Meta:
        model = StorageSidWaitQueue
        fields = ("cluster",
                    "storagecluster",
                    "node",
                    "wait_queue_count",
                    "start_time"
                  )

class SubStorageSyncClusterSerializer(serializers.ModelSerializer):
    cluster_name = serializers.RelatedField(source="cluster", read_only=True)
    storage_usage = serializers.SerializerMethodField("get_usage")

    class Meta:
        model = StorageCluster
        fields = ("cluster",
                    "cluster_name",
                    "storage_usage",
                    "is_preferred_cluster"
                  )

    def get_usage(self, obj):
        return obj.storage.getClusterUsedSizebySID(obj.cluster.cluster_id)

class StorageClusterSerializer(serializers.ModelSerializer):
    customer_name = serializers.RelatedField(source="customer.account.account_name_local", read_only=True)
    customer_region = serializers.SerializerMethodField("get_region_name")
    sync_clusters = SubStorageSyncClusterSerializer(many=True, source="storagecluster_set", required=False)

    class Meta:
        model = Storage
        fields = ("storage_id",
                    "storage_name",
                    "date_created",
                    "customer",
                    "customer_name",
                    "customer_region",
                    "sync_clusters"
                  )

    def get_region_name(self, obj):
        return obj.customer.getRegionName()

class StorageSyncFailSerializer(serializers.ModelSerializer):
    class Meta:
        model = StorageSyncFail
        fields = ("cluster",
                    "storagecluster",
                    "node",
                    "dst_cluster",
                    "io_type",
                    "objname",
                    "optname",
                    "failed_time"
                  )

# Prism Cloud Storage Refactoring
class SubStorageUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = StorageUser
        fields = ("user_id",
                  "user_name"
                  )

class StorageListSerializer(serializers.ModelSerializer):
    customer_name = serializers.RelatedField(source="customer", read_only=True)
    contract_name = serializers.RelatedField(source="contract", read_only=True)

    class Meta:
        model = Storage
        fields = ("storage_id",
                  "storage_name",
                  "customer",
                  "customer_name",
                  "contract",
                  "contract_name",
                  "date_created",
                  "date_modified",
                  "config_state"
                  )

class StorageSerializer(serializers.ModelSerializer):
    item = serializers.SerializerMethodField("get_customer_item")

    class Meta:
        model = Storage
        fields = ("storage_id",
                  "storage_name",
                  "customer",
                  "contract",
                  "item",
                  "description",
                  "data_domain",
                  "user_origin_domain",
                  "upload_domain",
                  "user_upload_domain",
                  "status",
                  "cdnw_status",
                  "date_modified",
                  "date_created",
                  "cdnw_status",
                  "config_state",
                  "https_origin_domain",
                  "https_origin_domain_name",
                  "https_upload_domain",
                  "https_upload_domain_name"
                  )

    def get_customer_item(self, obj):
        return obj.getCustomerItem()

class StarfsDomainsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Storage
        fields = ("storage_id",
                  "storage_name",
                  "data_domain",
                  "user_origin_domain",
                  "upload_domain",
                  "user_upload_domain",
                  "https_origin_domain",
                  "https_origin_domain_name",
                  "https_upload_domain",
                  "https_upload_domain_name"
                  )

class StroageVhostsSerializer(serializers.ModelSerializer):
    class Meta:
        model = StorageSidVhosts
        fields = ()

class StroageClustersSerializer(serializers.ModelSerializer):
    cluster_name = serializers.RelatedField(source="cluster", read_only=True)
    is_enabled = serializers.SerializerMethodField("get_config_state")
    backup_domain_name = serializers.RelatedField(source="backup_domain", read_only=True)
    backup_https_domain_name = serializers.RelatedField(source="backup_https_domain", read_only=True)
    backup_upload_domain_name = serializers.RelatedField(source="backup_upload_domain", read_only=True)
    backup_https_upload_domain_name = serializers.RelatedField(source="backup_https_upload_domain", read_only=True)
    cluster_size = serializers.SerializerMethodField("get_total_size")

    class Meta:
        model = StorageCluster
        fields = ("idx",
                  "cluster",
                  "cluster_name",
                  "is_enabled",
                  "is_preferred_cluster",
                  "cluster_size",
                  "backup_order",
                  "backup_domain",
                  "backup_domain_name",
                  "backup_https_domain",
                  "backup_https_domain_name",
                  "backup_upload_domain",
                  "backup_upload_domain_name",
                  "backup_https_upload_domain",
                  "backup_https_upload_domain_name",
                  "obj_state"
                  )

    def get_config_state(self, obj):
        return obj.cluster.getConfigState()

    def get_total_size(self, obj):
        return obj.cluster.getTotalSize()

class StroageUsersSerializer(serializers.ModelSerializer):
    class Meta:
        model = StorageUser
        fields = ()

class ClusterSimpleSerializer(serializers.ModelSerializer):
    config_state_display = serializers.SerializerMethodField("get_config_state")

    class Meta:
        model = Cluster
        fields = ("cluster_id",
                  "cluster_name",
                  "config_state",
                  "config_state_display",
                  "description"
                  )

    def get_config_state(self, obj):
        return obj.getConfigState()

class StorageConfigListSerializer(serializers.ModelSerializer):
    class Meta:
        model = StorageConfigParameter
        fields = ()

class StorageSidConfigSerializer(serializers.ModelSerializer):
    class Meta:
        model = StorageSidConfig
        fields = ()

class StorageSidMimeConfigSerializer(serializers.ModelSerializer):
    class Meta:
        model = StorageMimeConfig
        fields = ()

class StroageSidIpbasedAclSerializer(serializers.ModelSerializer):
    class Meta:
        model = StroageIpbasedAcl
        fields = ()

