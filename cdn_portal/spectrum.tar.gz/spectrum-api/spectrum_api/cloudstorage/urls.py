# -*- coding: utf-8 -*-

from django.conf.urls.defaults import patterns, url
from rest_framework.urlpatterns import format_suffix_patterns

from spectrum_api.cloudstorage.views.monitoring import ClusterAllAPI, ClusterAPI, \
    ClusterNodeAPI, ClusterDetailAPI, ClusterOriginTrafficAPI, ClusterWaitQueueAPI, \
    StorageClusterAPI, StorageOriginTrafficAPI, ClusterSyncFailAPI, \
    StorageSyncFailSimpleListAPI, ClusterNodeDetailAPI
from spectrum_api.cloudstorage.views.cloudstorage import StorageListAPI, \
    StorageDetailAPI, StorageAPI, StarfsDomainsAPI, StorageActionHistoryAPI, \
    StorageVhostsAPI, StorageVhostsDetailAPI, StorageClusterAPI as StorageClsuterStorageAPI, \
    StorageClusterDetailAPI, StorageUsersAPI, StorageUserDetailAPI, ClusterListAPI, \
    StorageConfigListAPI, StorageSidConfigAPI, StorageSidConfigDetailAPI, \
    StorageSidMimeConfigAPI, StorageSidMimeConfigDetailAPI, \
    StroageSidIpbasedAclAPI, StroageSidIpbasedAclDetailAPI, StorageIpbasedAclOrderAPI, \
    StorageCdnwUpdateAPI, SimpleStorageListAPI


restfw_api_urlpatterns = patterns('spectrum_api.cloudstorage.views',

    url(r'^cluster_all/$', ClusterAllAPI.as_view(), name="cluster_all"),
    url(r'^clusters/$', ClusterAPI.as_view(), name="clusters"),
    url(r'^cluster_nodes/$', ClusterNodeAPI.as_view(), name="cluster_nodes"),
    url(r'^clusters/(?P<cluster_id>[0-9]+)/$', ClusterDetailAPI.as_view(), name="cluster_detail"),
    url(r'^clusters/(?P<cluster_id>[0-9]+)/origin_traffic/$', ClusterOriginTrafficAPI.as_view(), name="cluster_origin_traffic"),
    url(r'^clusters/(?P<cluster_id>[0-9]+)/wait_queue/$', ClusterWaitQueueAPI.as_view(), name="cluster_wait_queue"),
    url(r'^clusters/(?P<cluster_id>[0-9]+)/storages/$', StorageClusterAPI.as_view(), name="storage_clusters"),
    url(r'^clusters/(?P<cluster_id>[0-9]+)/storages/(?P<storage_id>[0-9]+)/origin_traffic/$', StorageOriginTrafficAPI.as_view(), name="storage_origin_traffic"),
    url(r'^clusters/(?P<cluster_id>[0-9]+)/sync_fail/$', ClusterSyncFailAPI.as_view(), name="cluster_sync_fail"),
    url(r'^clusters/(?P<cluster_id>[0-9]+)/storage_list/$', StorageSyncFailSimpleListAPI.as_view(), name="storage_simple_list"),
    url(r'^cluster_nodes/(?P<node_id>[0-9]+)/$', ClusterNodeDetailAPI.as_view(), name="cluster_node_detail"),

    # Cloud Storage Refactoring
    url(r'^cloudstorage/cluster_list/$', ClusterListAPI.as_view(), name="cluster_list"),
    url(r'^cloudstorage/storage_list/$', StorageListAPI.as_view(), name="storage_list"),
    url(r'^cloudstorage/simple_storage_list/$', SimpleStorageListAPI.as_view(), name="simple_storage_list"),
    url(r'^cloudstorage/storage/$', StorageAPI.as_view(), name="storage"),
    url(r'^cloudstorage/storage/(?P<storage_id>[0-9]+)/$', StorageDetailAPI.as_view(), name="storage_detail"),
    url(r'^cloudstorage/storage/starfs_domains/(?P<storage_id>[0-9]+)/$', StarfsDomainsAPI.as_view(), name="starfs_domains"),
    url(r'^cloudstorage/storage/action_history/(?P<storage_id>[0-9]+)/$', StorageActionHistoryAPI.as_view(), name="storage_action_history"),
    url(r'^cloudstorage/storage/(?P<storage_id>[0-9]+)/vhosts/$', StorageVhostsAPI.as_view(), name="storage_vhosts"),
    url(r'^cloudstorage/storage/(?P<storage_id>[0-9]+)/vhosts/(?P<vhosts_id>[0-9]+)/$', StorageVhostsDetailAPI.as_view(), name="storage_vhosts_detail"),
    url(r'^cloudstorage/storage/(?P<storage_id>[0-9]+)/clusters/$', StorageClsuterStorageAPI.as_view(), name="storage_cluster_storage"),
    url(r'^cloudstorage/storage/(?P<storage_id>[0-9]+)/clusters/(?P<storage_cluster_id>[0-9]+)/$', StorageClusterDetailAPI.as_view(), name="storage_cluster_detail"),
    url(r'^cloudstorage/storage/(?P<storage_id>[0-9]+)/users/$', StorageUsersAPI.as_view(), name="storage_users"),
    url(r'^cloudstorage/storage/(?P<storage_id>[0-9]+)/users/(?P<user_id>[0-9]+)/$', StorageUserDetailAPI.as_view(), name="storage_user_detail"),
    url(r'^cloudstorage/storage/(?P<storage_id>[0-9]+)/config_list/$', StorageConfigListAPI.as_view(), name="storage_config_list"),
    url(r'^cloudstorage/storage/(?P<storage_id>[0-9]+)/sid_config/$', StorageSidConfigAPI.as_view(), name="sid_config"),
    url(r'^cloudstorage/storage/(?P<storage_id>[0-9]+)/sid_config/(?P<sid_config_id>[0-9]+)/$', StorageSidConfigDetailAPI.as_view(), name="sid_config_detail"),
    url(r'^cloudstorage/storage/(?P<storage_id>[0-9]+)/sid_mimeconfig/$', StorageSidMimeConfigAPI.as_view(), name="sid_mimeconfig"),
    url(r'^cloudstorage/storage/(?P<storage_id>[0-9]+)/sid_mimeconfig/(?P<sid_mimeconfig_id>[0-9]+)/$', StorageSidMimeConfigDetailAPI.as_view(), name="sid_mimeconfig_detail"),
    url(r'^cloudstorage/storage/(?P<storage_id>[0-9]+)/sid_ipbased_acl/$', StroageSidIpbasedAclAPI.as_view(), name="sid_ipbased_acl"),
    url(r'^cloudstorage/storage/(?P<storage_id>[0-9]+)/sid_ipbased_acl/(?P<acl_id>[0-9]+)/$', StroageSidIpbasedAclDetailAPI.as_view(), name="sid_ipbased_acl_detail"),
    url(r'^cloudstorage/storage/(?P<storage_id>[0-9]+)/acl_order/(?P<acl_id>[0-9]+)/$', StorageIpbasedAclOrderAPI.as_view(), name="sid_ipbased_acl_order"),
    url(r'^cloudstorage/storage/(?P<storage_id>[0-9]+)/cdnw_update/$', StorageCdnwUpdateAPI.as_view(), name="sid_cdnw_update"),
)
urlpatterns = format_suffix_patterns(restfw_api_urlpatterns)
