import re
from django.db.models import Q
from django.utils.translation import ugettext as _
from spectrum_api.shared_components.utils.regex import REGEX_DOMAIN_NAME, REGEX_STORAGE_NAME_RENEW, \
    REGEX_PATH_NAME, REGEX_USER_NAME, regex_ipv4
from spectrum_api.cloudstorage.models.cloudstorage import Storage, StorageSidVhosts, StorageUser
from spectrum_api.dna.models.domain import Domain

re_domain_name = re.compile(REGEX_DOMAIN_NAME)
re_storage_name = re.compile(REGEX_STORAGE_NAME_RENEW)
re_path_name = re.compile(REGEX_PATH_NAME)
re_user_name = re.compile(REGEX_USER_NAME)


def validate_sf_doamin_name(prefix, storage_name, target_domain):
    ''' SF Domain Rule

    @description

        1. Legacy SF Domain (5 level domain)
            SF_DOMAIN = PREFIX['origin', 'upload' ] . STORAGE_NAME . DOMAIN_SUFFIX[ 'sf.cdngp.net' ]

        2. Dash Saperated Domain (4 level domain)
            SF_DOMAIN = PREFIX['origin', 'upload' ] - STORAGE_NAME . DOMAIN_SUFFIX[ 'sf.cdngp.net' ]

    @params

        - prefix <string> : can be 'origin', 'upload'
        - storage_name <string> : storage name
        - target_domain <string> : validation target domain

    @returns

        <integer> : validation type
            -1 : invalid sf domain name
            1 : legacy type (5 level domain)
            2 : cstorage 2.7 sf domain (4 level domain)
    '''
    sf_domain_suffix = 'sf.cdngp.net'

    domain_sequence = (prefix, storage_name, sf_domain_suffix)

    legacy_sf_domain_format = '%s.%s.%s'
    level4_sf_domain_format = '%s-%s.%s'

    # Check 4 Level Domain
    if target_domain == level4_sf_domain_format % domain_sequence:
        return True

    # Check Legacy SF Domain
    elif target_domain == legacy_sf_domain_format % domain_sequence:
        return True

    else:
        return False

def storage_validate(request, type, storage_id=None):
    storage_name = request.DATA.get("storage_name", None)
    if type != 'add':
        storage_name = Storage.objects.get(pk=int(storage_id)).storage_name

    customer_id = request.DATA.get("customer_id", None)
    contract_no = request.DATA.get("contract_no", None)
    item_id = request.DATA.get("item_id", None)
    origin_domain = request.DATA.get('origin_domain', None)
    upload_domain = request.DATA.get('upload_domain', None)

    if type == 'add':
        if storage_name == None or storage_name == '':
            raise Exception(_(u"Storage Name(SID) is required."))
        else:
            storage_name = storage_name.strip()
            if re_storage_name.match(storage_name) is None:
                raise Exception(_(u"'%(storage_name)s' is not valid."% {"storage_name": storage_name}))
            else:
                if len(storage_name) > 63:
                    raise Exception(_(u"Invalid '%(storage_name)s' Value Size(allow : ~255)."% {"storage_name": storage_name}))

    if customer_id == None or customer_id == '':
        raise Exception(_(u"Customer ID is required."))

    if contract_no == None or contract_no == '':
        raise Exception(_(u"Contract No is required."))

    if item_id == None or item_id == '':
        raise Exception(_(u"Item ID is required."))
    try:
        int_item = int(item_id)
    except:
        raise Exception(_(u"Item ID is invalid."))

    if origin_domain == None or origin_domain == '':
        raise Exception(_(u"STARFS Service URL is required."))
    else:
        origin_domain = origin_domain.strip()
        if storage_name != None or storage_name != '':
            if not validate_sf_doamin_name("origin", storage_name, origin_domain):
                raise Exception(_(u"'%(origin_domain)s' is not valid."% {"origin_domain": origin_domain}))
            elif re_domain_name.match(origin_domain) is None:
                raise Exception(_(u"'%(origin_domain)s' is not valid."% {"origin_domain": origin_domain}))
            else:
                if len(origin_domain) > 255:
                    raise Exception(_(u"Invalid '%(origin_domain)s' Value Size(allow : ~255)."% {"origin_domain": origin_domain}))

    if upload_domain == None or upload_domain == '':
        raise Exception(_(u"Upload STARFS URL is required."))
    else:
        upload_domain = upload_domain.strip()
        if storage_name != None or storage_name != '':
            if not validate_sf_doamin_name("upload", storage_name, upload_domain):
                raise Exception(_(u"'%(upload_domain)s' is not valid."% {"upload_domain": upload_domain}))
            elif re_domain_name.match(upload_domain) is None:
                raise Exception(_(u"'%(upload_domain)s' is not valid."% {"upload_domain": upload_domain}))
            else:
                if len(upload_domain) > 255:
                    raise Exception(_(u"Invalid '%(upload_domain)s' Value Size(allow : ~255)."% {"upload_domain": upload_domain}))

    return True

def vhosts_validate(request, type, vhosts_id=None):
    virtual_host = request.DATA.get("virtual_host", None)
    if type != 'add':
        virtual_host = StorageSidVhosts.objects.get(pk=int(vhosts_id)).service_domain

    origin_domain = request.DATA.get('starfs_service_domain', None)
    dcm_root = request.DATA.get('dcm_root', None)

    if type == 'add':
        if virtual_host == None or virtual_host == '':
            raise Exception(_(u"Virtual Host is required."))
        else:
            virtual_host = virtual_host.strip()
            if re_storage_name.match(virtual_host) is None:
                raise Exception(_(u"'%(virtual_host)s' is not valid."% {"virtual_host": virtual_host}))
            else:
                if len(virtual_host) > 255:
                    raise Exception(_(u"Invalid '%(virtual_host)s' Value Size(allow : ~255)."% {"virtual_host": virtual_host}))

    if origin_domain == None or origin_domain == '':
        raise Exception(_(u"STARFS Service URL is required."))
    else:
        origin_domain = origin_domain.strip()
        if virtual_host != None or virtual_host != '':
            if not validate_sf_doamin_name("origin", virtual_host, origin_domain):
                raise Exception(_(u"'%(origin_domain)s' is not valid."% {"origin_domain": origin_domain}))
            elif re_domain_name.match(origin_domain) is None:
                raise Exception(_(u"'%(origin_domain)s' is not valid."% {"origin_domain": origin_domain}))
            else:
                if len(origin_domain) > 255:
                    raise Exception(_(u"Invalid '%(origin_domain)s' Value Size(allow : ~255)."% {"origin_domain": origin_domain}))

    if dcm_root == None or dcm_root == '':
        raise Exception(_(u"Document Root is required.(default path = '/')"))
    else:
        dcm_root = dcm_root.strip()
        if re_path_name.match(dcm_root) is None:
            raise Exception(_(u"'%(dcm_root)s' is not valid."% {"dcm_root": dcm_root}))

    return True


def validate_user_origin_domain(request, storage, input_domain_name):
    gslbdomains = Domain.objects.filter(name=input_domain_name)
    origin_storage_exists = None
    other_storage_exists = Storage.objects.filter(Q(user_service_domain=input_domain_name) \
        | Q(user_upload_domain=input_domain_name))
    if other_storage_exists.exists():
        other_sids = other_storage_exists[0].storage_name
        raise Exception(_(u'User origin domain %s is duplicated. Check SID: %s ' % (input_domain_name, other_sids)))

    if storage:
        origin_storage_exists = Storage.objects.filter(user_origin_domain=input_domain_name).exclude(pk=storage.pk)
    else:
        origin_storage_exists = Storage.objects.filter(user_origin_domain=input_domain_name)

    if origin_storage_exists.exists():
        other_sids = origin_storage_exists[0].storage_name
        raise Exception(_(u'User origin domain %s is duplicated. Check SID: %s ' % (input_domain_name, other_sids)))

    if gslbdomains.exists():
        if gslbdomains.count() > 1:
            raise Exception(_(u'User origin domain ' + input_domain_name + ' is duplicated. Check GSLB Domain.'))

def validate_user_upload_domain(request, storage, input_domain_name):
    gslbdomains = Domain.objects.filter(name=input_domain_name)
    upload_storage_exists = None
    other_storage_exists = Storage.objects.filter(Q(user_service_domain=input_domain_name) \
        | Q(user_origin_domain=input_domain_name))  # | Q(user_master_domain=input_domain_name)
    if other_storage_exists.exists():
        other_sids = other_storage_exists[0].storage_name
        raise Exception(_(u'User upload domain %s is duplicated. Check SID: %s ' % (input_domain_name, other_sids)))

    if storage:
        upload_storage_exists = Storage.objects.filter(user_upload_domain=input_domain_name).exclude(pk=storage.pk)
    else:
        upload_storage_exists = Storage.objects.filter(user_upload_domain=input_domain_name)

    if upload_storage_exists.exists():
        other_sids = upload_storage_exists[0].storage_name
        raise Exception(_(u'User upload domain %s is duplicated. Check SID: %s ' % (input_domain_name, other_sids)))

    if gslbdomains:
        if gslbdomains.count() > 1:
            raise Exception(_(u'User upload domain ' + input_domain_name + ' is duplicated. Check GSLB Domain.'))

def validate_vhosts_service_domain(request, storageSidVhosts, input_domain_name):
    gslbdomains = Domain.objects.filter(name=input_domain_name)
    service_vhosts_exists = None
    other_vhosts_exists = StorageSidVhosts.objects.filter(starfs_service_domain=input_domain_name)
    if other_vhosts_exists.exists():
        if other_vhosts_exists.count() >= 1:
            other_sids = other_vhosts_exists[0].storage.storage_name
            raise Exception('Virtual Host Service domain %s is duplicated. Check SID: %s ' % (input_domain_name, other_sids))

    if storageSidVhosts:
        service_vhosts_exists = StorageSidVhosts.objects.filter(service_domain=input_domain_name).exclude(pk=storageSidVhosts.pk)
    else:
        service_vhosts_exists = StorageSidVhosts.objects.filter(service_domain=input_domain_name)

    if service_vhosts_exists.exists():
        other_sids = service_vhosts_exists[0].storage.storage_name + ', '
        raise Exception('Virtual Host Service domain %s is duplicated. Check SID: %s ' % (input_domain_name, other_sids))

    if gslbdomains:
        if gslbdomains.count() > 1:
            raise Exception('GSLB domain ' + input_domain_name + ' is duplicated. Check GSLB Domain.')

def validate_vhosts_starfs_domain(request, storageSidVhosts, input_domain_name):
    gslbdomains = Domain.objects.filter(name=input_domain_name)
    starfs_vhosts_exists = None
    other_vhosts_exists = StorageSidVhosts.objects.filter(service_domain=input_domain_name)
    if other_vhosts_exists.exists():
        other_sids = other_vhosts_exists[0].storage.storage_name + ', '
        raise Exception('Virtual Host STARFS domain %s is duplicated. Check SID: %s ' % (input_domain_name, other_sids))

    if storageSidVhosts:
        starfs_vhosts_exists = StorageSidVhosts.objects.filter(starfs_service_domain=input_domain_name).exclude(pk=storageSidVhosts.pk)
    else:
        starfs_vhosts_exists = StorageSidVhosts.objects.filter(starfs_service_domain=input_domain_name)

    if starfs_vhosts_exists.exists():
        other_sids = starfs_vhosts_exists[0].storage.storage_name + ', '
        raise Exception('Virtual Host STARFS domain %s is duplicated. Check SID: %s ' % (input_domain_name, other_sids))

    if gslbdomains:
        if gslbdomains.count() > 1:
            raise Exception('Virtual Host STARFS domain ' + input_domain_name + ' is duplicated. Check GSLB Domain.')


def storage_user_validate(request, type, storage_name):
    user_name = request.DATA.get('user_name', None)
    access_path = request.DATA.get('access_path', None)
    password = request.DATA.get('password', None)

    if type == 'add':
        if user_name == None or user_name == '':
            raise Exception(_(u'User Name is required.'))
        else:
            user_name = user_name.strip()
            if re_user_name.match(user_name) is None:
                raise Exception(_(u"User Name '%(user_name)s' is not valid."% {"user_name": user_name}))

            save_user_name = user_name + "_" + storage_name
            duplicated_user = StorageUser.objects.filter(user_name=save_user_name)
            if duplicated_user.exists():
                raise Exception(_("Same username '%(user_name)s' exists with SID '%(storage_name)s'"
                                  % {"user_name":save_user_name, "storage_name":storage_name}))

    if password == None or password == '':
        raise Exception(_(u'Password is required.'))

    if access_path == None or access_path == '':
        raise Exception(_(u'Access Path is required.'))
    else:
        access_path = access_path.strip()
        if re_path_name.match(access_path) is None:
            raise Exception(_(u"Access Path '%(access_path)s' is not valid."% {"access_path": access_path}))

    return True

def storage_config_validate(request):
    param_name = request.DATA.get('param_name', None)
    param_value = request.DATA.get('param_value', None)

    if param_name == None or param_name == '':
        raise Exception(_(u'Param Name is required.'))

    if param_value == None or param_value == '':
        raise Exception(_(u'Param Value is required.'))

    return True

def storage_ipbased_acl_validate(request):
    policy = request.DATA.get('policy', None)
    ipaddr = request.DATA.get('ipaddr', None)
    subnet_mask = request.DATA.get('subnet_mask', None)

    if policy == None or policy == '':
        raise Exception(_(u'Policy is required.'))

    if ipaddr is not None and ipaddr != '':
        if regex_ipv4.match(ipaddr) is None:
            raise Exception(_(u"IP Address '%(ipaddr)s' is not valid."% {"ipaddr": ipaddr}))

    if subnet_mask == None or subnet_mask == '':
        raise Exception(_(u'Subnet Mask is required.'))
    else:
        if regex_ipv4.match(subnet_mask) is None:
            raise Exception(_(u"Subnet Mask '%(subnet_mask)s' is not valid."% {"subnet_mask": subnet_mask}))

    return True


