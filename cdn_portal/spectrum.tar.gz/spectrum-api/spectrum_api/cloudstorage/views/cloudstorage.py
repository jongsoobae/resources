# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Rest API
"""
import hashlib
import re
import itertools
from datetime import datetime, timedelta, date
from django.conf import settings
from django.utils import simplejson
from django.utils.encoding import smart_str
from django.utils.translation import ugettext as _
from django.db import connections, transaction
from django.db.models import Q
from rest_framework.status import HTTP_400_BAD_REQUEST, HTTP_202_ACCEPTED
from rest_framework.exceptions import APIException
from rest_framework.response import Response

from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.mixins import ListModelMixin, RetrieveModelMixin, \
    CreateModelMixin, UpdateModelMixin, DestroyModelMixin
from spectrum_api.shared_components.models import StatMaster, ActionHistory
from spectrum_api.shared_components.models.prism import AuroraActionHistory
from spectrum_api.shared_components.models.customer import CustomerItem, CustomerDisplay, CustomerContract
from spectrum_api.shared_components.utils.common import get_vips_by_ipid
from spectrum_api.shared_components.utils.crypt import crypt
from spectrum_api.dna.models.domain import Domain, DomainVip
from spectrum_api.configuration.models.base import BaseProbeConfig
from spectrum_api.cloudstorage.models.cloudstorage import Storage, StorageCluster, \
    StorageNode, StorageUser, StorageSidConfig, StorageMimeConfig, Cluster, \
    StroageIpbasedAcl, StorageSidVhosts, StorageClusterVhosts, StorageStatMaster, \
    StorageConfigParameter, StorageSnapshotIoEvent, StorageSnapshotSyncMismatch
from spectrum_api.cloudstorage.serializers.cloudstorage import StorageListSerializer, \
    StorageSerializer, StarfsDomainsSerializer, StroageVhostsSerializer, \
    StroageClustersSerializer, StroageUsersSerializer, ClusterSimpleSerializer, \
    StorageConfigListSerializer, StorageSidConfigSerializer, StorageSidMimeConfigSerializer, \
    StroageSidIpbasedAclSerializer
from spectrum_api.cloudstorage.utils.validate_cloudstorage import storage_validate, vhosts_validate, \
    validate_user_origin_domain, validate_user_upload_domain, validate_vhosts_service_domain, \
    validate_vhosts_starfs_domain, storage_user_validate, storage_config_validate, \
    storage_ipbased_acl_validate

__STORAGE_URL_LOOKUP_KEY__ = "storage_id"
__CLUSTER_URL_LOOKUP_KEY__ = "cluster_id"
__VHOSTS_URL_LOOKUP_KEY__ = "vhosts_id"
__STORAGE_CLUSTER_URL_LOOKUP_KEY__ = 'storage_cluster_id'

POLICIES = (('0', 'ALLOW'), ('1', 'DENY'))
PROTOCOLS = (('0', 'ALL'), ('1', 'FTP'), ('2', 'SFTP'), ('3', 'RSYNC'), ('4', 'HTTP'))
PERMISSIONS = (('0', 'Super'), ('1', 'Write'), ('2', 'Read'), ('3', 'None'))

GSLB_DOMAIN = 1

class StorageAPIException(APIException):
    def __init__(self, status_code, detail):
        self.status_code = status_code
        super(StorageAPIException, self).__init__(detail=detail)

class AccessInvalidStorageID(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = 'Storage ID Missing'

class AccessInvalidClusterID(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = 'Cluster ID Missing'

class AccessInvalidItemID(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = 'Item ID Missing'

def get_config_replication(storage_list):
    storage_info = {}

    if len(storage_list) <= 0:
        return storage_info

    sql = """
            select ss.storage_id,
                    if(sc.param_value = 'YES', 'Replicated', 'None') as replication
            from
                storage_storage ss
                left join storage_sid_config sc on ss.storage_id = sc.storage_id and sc.param_name = 'ReplicateData'
            where ss.storage_id in (%s)
            """
    format_strings = ','.join(map(lambda x: '%s', storage_list))
    sql = sql % (format_strings)
    params = []
    params.extend(storage_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, tuple(params))
    obj = cursor.fetchone()

    try:
        while obj is not None:
            storage_info[obj[0]] = {"storage_id":obj[0],
                                "replication":obj[1]
                                }
            obj = cursor.fetchone()
    finally:
        cursor.close()
        connections['default'].close()

    return storage_info

def get_storage_redundancy(storage_list):
    storage_info = {}

    if len(storage_list) <= 0:
        return storage_info

    sql = """
            select
                ss.storage_id,
                if(isnull(sm.stat_id), 'No Contract',
                    if(right(ci.sales_charge,1)='P', 'Premium', 'Standard')) as redundancy,
                ci.item_id,
                ci.item_no
            from
                storage_storage ss
                left join storage_stat_master ssm on ss.storage_id = ssm.storage_id
                left join stat_master sm on ssm.statmaster_id = sm.stat_id
                left join customer_item ci on sm.item_id = ci.item_id
            where ss.storage_id in (%s)
                and ss.obj_state = 1 and (sm.service_remove_flag <> 1 or sm.service_remove_flag is null)
            order by ss.storage_id
            """
    format_strings = ','.join(map(lambda x: '%s', storage_list))
    sql = sql % (format_strings)
    params = []
    params.extend(storage_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, tuple(params))
    obj = cursor.fetchone()

    try:
        while obj is not None:
            storage_info[obj[0]] = {"storage_id":obj[0],
                                "redundancy":obj[1],
                                "item_id":obj[2],
                                "item_no":obj[3]
                                }
            obj = cursor.fetchone()
    finally:
        cursor.close()
        connections['default'].close()

    return storage_info

def getStroageClusterList(storage_id):
    storage_info = []

    if storage_id is not None:
        try:
            int(storage_id)
        except ValueError:
            raise Exception(_(u'invalid storage_id input format'))
    else:
        return storage_info

    sql = """
            select
                scs.cluster_id, sc.cluster_name,
                scs.idx, scs.backup_domain_id, scs.backup_https_domain_id, 
                scs.backup_upload_domain_id, scs.backup_https_upload_domain_id,
                (select `name` from gslb_domain where domain_id = scs.backup_domain_id) as backup_domain_name,
                (select `name` from gslb_domain where domain_id = scs.backup_https_domain_id) as backup_https_domain_name,
                (select `name` from gslb_domain where domain_id = scs.backup_upload_domain_id) as backup_upload_domain_name,
                (select `name` from gslb_domain where domain_id = scs.backup_https_upload_domain_id) as backup_https_upload_domain_name
            from storage_cluster_storage scs
                left join storage_cluster sc on scs.cluster_id = sc.cluster_id
            where scs.storage_id = %s
            """
    cursor = connections['default'].cursor()
    cursor.execute(sql, [int(storage_id)])
    fieldnames = [name[0] for name in cursor.description]
    rs = cursor.fetchall()

    for obj in rs:
        rowset = []
        for field in zip(fieldnames, obj):
            rowset.append((field[0], field[1]))
        storage_info.append(dict(rowset))

    return storage_info

def getStorageVhostsClusterList(storage_id):
    storage_info = []

    if storage_id is not None:
        try:
            int(storage_id)
        except ValueError:
            raise Exception(_(u'invalid storage_id input format'))
    else:
        return storage_info

    sql = """
            select
                ssv.idx as vhosts_id, sc.cluster_id, sc.cluster_name,
                ssv.service_domain, ssv.starfs_service_domain, ssv.gslb_service_domain_id,
                ssv.https_service_domain_name, ssv.https_service_domain_id,
                scv.backup_domain_id, scv.backup_https_domain_id,
                (select `name` from gslb_domain where domain_id = scv.backup_domain_id) as backup_domain_name,
                (select `name` from gslb_domain where domain_id = scv.backup_https_domain_id) as backup_https_domain_name
            from storage_sid_vhosts ssv
                left join storage_cluster_vhosts scv on ssv.idx = scv.vhosts_id
                left join storage_cluster_storage scs on scv.sid_cluster_id = scs.idx
                left join storage_cluster sc on scs.cluster_id = sc.cluster_id
            where ssv.storage_id = %s
            order by ssv.idx
            """
    cursor = connections['default'].cursor()
    cursor.execute(sql, [int(storage_id)])
    fieldnames = [name[0] for name in cursor.description]
    rs = cursor.fetchall()

    for obj in rs:
        list_len = len(storage_info)
        if list_len > 0:
            # duplicate vhosts check
            if storage_info[list_len-1]['vhosts_id'] == obj[0]:
                storage_info[list_len-1]['vhost_clusters'].append({
                        'cluster_id':obj[1],
                        'cluster_name':obj[2],
                        'backup_domain_id':obj[8],
                        'backup_domain_name':obj[10],
                        'backup_https_domain_id':obj[9],
                        'backup_https_domain_name':obj[11]
                        })
            else:
                storage_info.append({
                                    "vhosts_id":obj[0],
                                    "virtual_host":obj[3],
                                    "gslb_service_domain_id":obj[5],
                                    "starfs_service_domain":obj[4],
                                    "https_service_domain_id":obj[7],
                                    "https_service_domain_name":obj[6],
                                    "vhost_clusters":[{
                                            'cluster_id':obj[1],
                                            'cluster_name':obj[2],
                                            'backup_domain_id':obj[8],
                                            'backup_domain_name':obj[10],
                                            'backup_https_domain_id':obj[9],
                                            'backup_https_domain_name':obj[11]
                                            }]
                                    })
        else:
            storage_info.append({
                                "vhosts_id":obj[0],
                                "virtual_host":obj[3],
                                "gslb_service_domain_id":obj[5],
                                "starfs_service_domain":obj[4],
                                "https_service_domain_id":obj[7],
                                "https_service_domain_name":obj[6],
                                "vhost_clusters":[{
                                        'cluster_id':obj[1],
                                        'cluster_name':obj[2],
                                        'backup_domain_id':obj[8],
                                        'backup_domain_name':obj[10],
                                        'backup_https_domain_id':obj[9],
                                        'backup_https_domain_name':obj[11]
                                        }]
                                })

    return storage_info

def get_simple_storage_redundancy(storage_list):
    storage_info = {}

    if len(storage_list) <= 0:
        return storage_info

    sql = """
            SELECT      ss.storage_id,
                        if(isnull(sm.stat_id), 'No Contract',
                            if(right(ci.sales_charge,1)='P', 'Premium', 'Standard')) as redundancy
            FROM        storage_storage ss
            LEFT JOIN   storage_stat_master ssm ON ss.storage_id = ssm.storage_id
            LEFT JOIN   stat_master sm ON ssm.statmaster_id = sm.stat_id
            LEFT JOIN   customer_item ci ON sm.item_id = ci.item_id
            WHERE       ss.storage_id IN %(storage_ids)s
            AND         ss.obj_state = 1 AND (sm.service_remove_flag <> 1 OR sm.service_remove_flag is null)
            ORDER BY    ss.storage_id
            """
    if len(storage_list) == 1:
        params = {'storage_ids': '(%s)' % storage_list[0]}
    else:
        params = {'storage_ids': tuple(storage_list)}
    sql = sql % params

    cursor = connections['default'].cursor()
    cursor.execute(sql)
    results = cursor.fetchall()

    try:
        for obj in results:
            storage_info[obj[0]] = obj[1]
    finally:
        cursor.close()
        connections['default'].close()

    return storage_info

def get_simple_storage_clusters_list(storage_list):
    storage_info = {}

    if len(storage_list) <= 0:
        return storage_info

    sql = """
            SELECT
                ss.storage_id,
                GROUP_CONCAT(sc.cluster_name SEPARATOR ', ') as cluster_names,
                max(if(isnull(sst.block_number), 0, round((sst.block_number * 4096) /
                (1024*1024*1024), 2))) as storage_usage
            FROM storage_storage ss
            LEFT JOIN storage_cluster_storage scs ON ss.storage_id = scs.storage_id
            LEFT JOIN storage_cluster sc ON scs.cluster_id = sc.cluster_id
            LEFT JOIN (
                SELECT      a.storage_id, a.cluster_id, a.block_number
                FROM        stat.storage_stats a
                JOIN (
                    SELECT      storage_id, cluster_id, max(start_time) as start_time
                    FROM        stat.storage_stats
                    WHERE       storage_id in %(storage_ids)s
                    AND         start_time >= %(where_date)s
                    GROUP BY    storage_id, cluster_id
                    ) b ON a.storage_id = b.storage_id AND a.cluster_id = b.cluster_id
                    AND a.start_time = b.start_time
                ORDER BY a.storage_id, a.cluster_id, a.start_time DESC
            ) sst ON sst.storage_id = ss.storage_id AND sst.cluster_id = sc.cluster_id
            WHERE       ss.obj_state = 1 AND sc.obj_state=1 AND ss.storage_id in %(storage_ids)s
            GROUP BY    ss.storage_id
            """
    if len(storage_list) == 1:
        params = {'storage_ids': '(%s)' % storage_list[0]}
    else:
        params = {'storage_ids': tuple(storage_list)}

    where_date = "'%s 00:00:00'" % (date.today() - timedelta(3 * 365/12)).isoformat()
    params['where_date'] = where_date

    sql = sql % params
    cursor = connections['default'].cursor()
    cursor.execute(sql)
    results = cursor.fetchall()

    try:
        for obj in results:
            storage_info[obj[0]]  = {
                "cluster_names": obj[1],
                "storage_usage": round(obj[2], 2)
             }
    finally:
        cursor.close()
        connections['default'].close()

    return storage_info


def getStorageClustersList(storage_list):
    storage_info = {}

    if len(storage_list) <= 0:
        return storage_info

    sql = """
            select
                ss.storage_id,
                scs.cluster_id, sc.cluster_name, scs.is_preferred_cluster,
                if(isnull(sst.block_number), 0, round((sst.block_number * 4096) / (1024*1024*1024), 2)) as storage_usage
            from storage_storage ss
                left join storage_cluster_storage scs on ss.storage_id = scs.storage_id
                left join storage_cluster sc on scs.cluster_id = sc.cluster_id
                left join (
                    select a.storage_id, a.cluster_id, a.block_number
                    from stat.storage_stats a
                        join (
                            select storage_id, cluster_id, max(start_time) as start_time
                            from stat.storage_stats
                            group by storage_id, cluster_id
                        ) b on a.storage_id = b.storage_id and a.cluster_id = b.cluster_id and a.start_time = b.start_time
                    order by a.storage_id, a.cluster_id, a.start_time desc
                ) sst on sst.storage_id = ss.storage_id and sst.cluster_id = sc.cluster_id
            where ss.obj_state = 1 and sc.obj_state=1 and ss.storage_id in (%s)
            """

    format_strings = ','.join(map(lambda x: '%s', storage_list))
    sql = sql % (format_strings)
    params = []
    params.extend(storage_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, tuple(params))
    obj = cursor.fetchone()

    try:
        while obj is not None:
            try:
                storage_info[obj[0]].append({"cluster":obj[1],
                                             "cluster_name":obj[2],
                                             "is_preferred_cluster":obj[3],
                                             "storage_usage":round(obj[4], 2)
                                            })
            except KeyError:
                storage_info[obj[0]] = []
                storage_info[obj[0]].append({"cluster":obj[1],
                                             "cluster_name":obj[2],
                                             "is_preferred_cluster":obj[3],
                                             "storage_usage":round(obj[4], 2)
                                            })
            obj = cursor.fetchone()
    finally:
        cursor.close()
        connections['default'].close()

    return storage_info

def getStorageUserCount(storage_list):
    storage_info = {}

    if len(storage_list) <= 0:
        return storage_info

    sql = """
            select
                ss.storage_id,
                count(su.user_id) as user_count
            from storage_storage ss
                left join storage_user su on su.storage_id = ss.storage_id
            where ss.obj_state = 1 and su.obj_state = 1 and su.`status` = 1 
                and ss.storage_id in (%s)
            group by ss.storage_id
            """
    format_strings = ','.join(map(lambda x: '%s', storage_list))
    sql = sql % (format_strings)
    params = []
    params.extend(storage_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, tuple(params))
    obj = cursor.fetchone()

    try:
        while obj is not None:
            storage_info[obj[0]] = {"storage_id":obj[0],
                                "user_count":obj[1]
                                }
            obj = cursor.fetchone()
    finally:
        cursor.close()
        connections['default'].close()

    return storage_info


class SimpleStorageListAPI(ListModelMixin, SpectrumGenericAPIView):
    s_ids = []
    storage_ids = []
    storage_keywords = None
    customer_id = None
    queryset = Storage.objects.all()
    serializer_class = StorageListSerializer
    lookup_url_kwarg = __STORAGE_URL_LOOKUP_KEY__
    ordering = 'storage_name'
    search_fields = ('storage_name',)
    filter_fields = ('customer', 'contract', 'storage_id',)

    def get_queryset(self):
        self.s_ids = self.request.GET.get('storage_ids', None)
        if self.s_ids:
            self.storage_ids = self.s_ids.split(',')
            try:
                self.queryset = self.queryset.filter(storage_id__in=self.storage_ids)
            except:
                pass

        self.customer_id = self.request.GET.get('customer_id', None)
        if self.customer_id:
            try:
                customer = CustomerDisplay.all_objects.get(customer_id=self.customer_id)
                self.queryset = self.queryset.filter(customer=customer)
            except:
                pass

        self.storage_keywords = self.request.GET.get('storage_keywords', None)
        if self.storage_keywords:
            try:
                self.queryset = self.queryset.filter(
                        storage_name__in=tuple(self.storage_keywords.split(',')))
            except:
                pass
        return self.queryset

    def get(self, request, *args, **kwargs):
        ret = super(SimpleStorageListAPI, self).list(request, *args, **kwargs)
        if isinstance(ret.data, list):
            org_results = ret.data
        else:
            org_results = ret.data['results']

        storage_ids = [ int(i['storage_id']) for i in org_results ]
        redundancy_info = get_simple_storage_redundancy(storage_ids)
        clusters_info = get_simple_storage_clusters_list(storage_ids)

        for result in org_results:
            usage_list = []
            user_count = 0
            if clusters_info.has_key(result['storage_id']):
                cluster_info = clusters_info[result['storage_id']]
                result['sync_clusters'] = cluster_info['cluster_names']
                result['usage'] = cluster_info['storage_usage']
            else:
                result['sync_clusters'] = ""
                result['usage'] = round(0, 2)


            if redundancy_info.has_key(result['storage_id']):
                result['redundancy'] = redundancy_info[result['storage_id']]
            else:
                result['redundancy'] = 'Standard'

        return ret


class StorageListAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = Storage.objects.all()
    serializer_class = StorageListSerializer
    lookup_url_kwarg = __STORAGE_URL_LOOKUP_KEY__
    ordering = 'storage_name'
    search_fields = ('storage_name',)
    filter_fields = ('customer','contract',)

    def get_queryset(self):
        item_id = self.request.GET.get('item', None)

        if item_id:
            try:
                customer_item = CustomerItem.objects.get(item_id=item_id, material_no=1202)
                self.queryset = self.queryset.filter(contract=customer_item.contract)
            except:
                pass

        return self.queryset

    def get(self, request, *args, **kwargs):
        ret = super(StorageListAPI, self).list(request, *args, **kwargs)

        if isinstance(ret.data, list):
            org_results = ret.data
        else:
            org_results = ret.data['results']

        storage_list = []
        for result in org_results:
            storage_list.append(str(result['storage_id']))

        replication_info = get_config_replication(storage_list)
        redundancy_info = get_storage_redundancy(storage_list)
        clusters_info = getStorageClustersList(storage_list)
        user_count_info = getStorageUserCount(storage_list)

        for result in org_results:
            usage_list = []
            user_count = 0
            if clusters_info.has_key(result['storage_id']):
                cluster_info = clusters_info[result['storage_id']]
                result['sync_clusters'] = cluster_info
                result['usage'] = round(sum(info.get('storage_usage') for info in cluster_info),2)

                usage_list = [info.get('storage_usage') for info in cluster_info]
                if user_count_info.has_key(result['storage_id']):
                    user_count = user_count_info[result['storage_id']]['user_count']
                    if user_count > 0 and len(usage_list) > 0:
                        result['usage_check'] = all(map(lambda x: x == usage_list[0], usage_list))
                    else:
                        result['usage_check'] = True
                else:
                    result['usage_check'] = True
            else:
                result['sync_clusters'] = []
                result['usage'] = round(0,2)
                result['usage_check'] = True

            if replication_info.has_key(result['storage_id']):
                result['replication'] = replication_info[result['storage_id']]['replication']
            else:
                result['replication'] = 'None'

            if redundancy_info.has_key(result['storage_id']):
                result['redundancy'] = redundancy_info[result['storage_id']]['redundancy']
                result['item_id'] = redundancy_info[result['storage_id']]['item_id']
                result['item_no'] = redundancy_info[result['storage_id']]['item_no']
            else:
                result['redundancy'] = 'Standard'
                result['item_id'] = None
                result['item_no'] = None

        return ret

class StorageAPI(RetrieveModelMixin, SpectrumGenericAPIView):
    queryset = Storage.objects.all()
    serializer_class = StorageSerializer
    lookup_url_kwarg = __STORAGE_URL_LOOKUP_KEY__

    @transaction.commit_manually
    def post(self, request, *args, **kwargs):
        try:
            #parameter value validaion
            storage_validate(self.request, 'add')

            storage_name = self.request.DATA.get("storage_name")
            customer_id = self.request.DATA.get("customer_id")
            contract_no = self.request.DATA.get("contract_no")
            item_id = self.request.DATA.get("item_id")
            user_origin_domain = self.request.DATA.get('origin_domain')
            user_upload_domain = self.request.DATA.get('upload_domain')

            # temporarily lower case
            storage_name = storage_name.lower()
            user_origin_domain = user_origin_domain.lower()
            user_upload_domain = user_upload_domain.lower()
            if customer_id:
                customer = CustomerDisplay.all_objects.get(customer_id=customer_id)
            else:
                raise Exception('Customer not selected.')

            if contract_no:
                contract = CustomerContract.objects.get(contract_no=contract_no)
                if not contract.is_valid_contract(settings.CLOUD_STORAGE_MATERIAL):
                    raise Exception('Contract has not been set yet or expired.')

                item_ids = CustomerItem.objects.filter(contract=contract, material_no=settings.CLOUD_STORAGE_MATERIAL) \
                                               .values_list('item_id', flat=True)
                if int(item_id) not in item_ids:
                    raise Exception('Item does not belong to the Contract.')
            else:
                raise Exception('Contract not selected.')

            storages = Storage.all_objects.filter(storage_name=storage_name)
            if storages.exists():  # update obj_state = 1
                raise Exception('Storage name(SID) ' + storage_name + ' is duplicated.')
            else:
                user_https_domain = False
                if user_origin_domain[0:7] == "origin-":
                    user_https_domain = True

                storage = Storage()
                storage.customer = customer
                storage.contract = contract
                storage.storage_name = storage_name  # temporarily lower case
                storage.generate_gslb = 1
                storage.use_cdn_origin = 1
                if user_https_domain:
                    storage.https_origin_domain_name = user_origin_domain
                    storage.https_upload_domain_name = user_upload_domain
                else:
                    storage.user_origin_domain = user_origin_domain
                    storage.user_upload_domain = user_upload_domain
                storage.user_origin_domain_enabled = 1

                if len(user_origin_domain) > 0:
                    validate_user_origin_domain(request, storage, user_origin_domain)
                if len(user_upload_domain) > 0:
                    validate_user_upload_domain(request, storage, user_upload_domain)

                origin_domain = set_user_gslb_domain(request, storage, user_origin_domain, customer, 'origin domain')
                upload_domain = set_user_gslb_domain(request, storage, user_upload_domain, customer, 'upload domain')
                set_cluster_vip(request, storage, origin_domain, upload_domain)

                if user_https_domain:
                    storage.https_origin_domain = origin_domain
                    storage.https_upload_domain = upload_domain
                else:
                    storage.data_domain = origin_domain
                    storage.upload_domain = upload_domain

                storage.save(request=request, contract_no=contract_no, item_id=item_id)

                # insert default sid user
                insert_default_storage_user(request, storage)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'Added.'), "storage_id":storage.pk}, status=HTTP_202_ACCEPTED)

class StorageDetailAPI(RetrieveModelMixin, SpectrumGenericAPIView):
    queryset = Storage.objects.all()
    serializer_class = StorageSerializer
    lookup_url_kwarg = __STORAGE_URL_LOOKUP_KEY__

    def get(self, request, *args, **kwargs):
        return super(StorageDetailAPI, self).retrieve(request, *args, **kwargs)

    @transaction.commit_manually
    def patch(self, request, *args, **kwargs):
        try:
            storage_id = self.kwargs.get(self.lookup_url_kwarg)
            if not storage_id:
                raise Exception('Storage ID Missing')

            #parameter value validaion
            storage_validate(self.request, 'edit', storage_id)

            customer_id = self.request.DATA.get("customer_id")
            contract_no = self.request.DATA.get("contract_no")
            item_id = self.request.DATA.get("item_id")
            user_origin_domain = self.request.DATA.get('origin_domain')
            user_upload_domain = self.request.DATA.get('upload_domain')

            # temporarily lower case
            user_origin_domain = user_origin_domain.lower()
            user_upload_domain = user_upload_domain.lower()

            if customer_id:
                customer = CustomerDisplay.all_objects.get(customer_id=customer_id)
            else:
                raise Exception('Customer not selected.')

            if contract_no:
                contract = CustomerContract.objects.get(contract_no=contract_no)
                if not contract.is_valid_contract(settings.CLOUD_STORAGE_MATERIAL):
                    raise Exception('Contract has not been set yet or expired.')

                item_ids = CustomerItem.objects.filter(contract=contract, material_no=settings.CLOUD_STORAGE_MATERIAL) \
                                           .values_list('item_id', flat=True)
                if int(item_id) not in item_ids:
                    raise Exception('Item does not belong to the Contract.')
            else:
                raise Exception('Contract not selected.')

            storage = Storage.objects.get(storage_id=storage_id)
            if storage:
                user_https_domain = False
                if user_origin_domain[0:7] == "origin-":
                    user_https_domain = True

                if len(user_origin_domain) > 0:
                    validate_user_origin_domain(request, storage, user_origin_domain)
                if len(user_upload_domain) > 0:
                    validate_user_upload_domain(request, storage, user_upload_domain)

                db_origin_domain = None
                db_upload_domain = None
                if user_https_domain:
                    if storage.user_origin_domain and storage.user_origin_domain != '':
                        db_origin_domain = set_user_gslb_domain(request, storage, storage.user_origin_domain, customer, 'origin domain')
                        db_upload_domain = set_user_gslb_domain(request, storage, storage.user_upload_domain, customer, 'upload domain')
                else:
                    if storage.https_origin_domain_name and storage.https_origin_domain_name != '':
                        db_origin_domain = set_user_gslb_domain(request, storage, storage.https_origin_domain_name, customer, 'origin domain')
                        db_upload_domain = set_user_gslb_domain(request, storage, storage.https_upload_domain_name, customer, 'upload domain')

                origin_domain = set_user_gslb_domain(request, storage, user_origin_domain, customer, 'origin domain')
                upload_domain = set_user_gslb_domain(request, storage, user_upload_domain, customer, 'upload domain')

                master_writer_vips = []
                temp_data_clusters_vips = []
                temp_upload_clusters_vips = []
                storage_clusters = StorageCluster.all_objects.filter(storage=storage)
                if storage_clusters.exists():
                    for storage_cluster in storage_clusters:
                        try:
                            delete_gslbdomain_vip(request, storage_cluster.backup_domain)
                        except:
                            storage_cluster.backup_domain = None
                        try:
                            delete_gslbdomain_vip(request, storage_cluster.backup_https_domain)
                        except:
                            storage_cluster.backup_https_domain = None
                        try:
                            delete_gslbdomain_vip(request, storage_cluster.backup_upload_domain)
                        except:
                            storage_cluster.backup_upload_domain = None
                        try:
                            delete_gslbdomain_vip(request, storage_cluster.backup_https_upload_domain)
                        except:
                            storage_cluster.backup_https_upload_domain = None

                        backup_origin_domain_name = 'backup' + str(storage_cluster.backup_order) + get_connection_character(user_https_domain) + origin_domain.name
                        backup_upload_domain_name = 'backup' + str(storage_cluster.backup_order) + get_connection_character(user_https_domain) + upload_domain.name
                        backup_origin_domain = set_backup_gslb_domain(request, backup_origin_domain_name, customer)
                        backup_upload_domain = set_backup_gslb_domain(request, backup_upload_domain_name, customer)
                        if db_origin_domain:
                            backup_db_origin_name = 'backup' + str(storage_cluster.backup_order) + get_connection_character(not user_https_domain) + db_origin_domain.name
                            backup_db_upload_name = 'backup' + str(storage_cluster.backup_order) + get_connection_character(not user_https_domain) + db_upload_domain.name
                            backup_db_origin_domain = set_backup_gslb_domain(request, backup_db_origin_name, customer)
                            backup_db_upload_domain = set_backup_gslb_domain(request, backup_db_upload_name, customer)
                        else:
                            backup_db_origin_domain = None
                            backup_db_upload_domain = None

                        if storage_cluster.cluster:
                            storagenodes = StorageNode.objects.filter(cluster=storage_cluster.cluster)
                            for storagenode in storagenodes:
                                vips = get_vips_by_ipid(storagenode.ip_id)
                                if vips:  # all ==> data , backup
                                    if storagenode.node_type == 0 or storagenode.node_type == 1:  # writer,reader
                                        set_gslbdomain_vip(request, backup_origin_domain, vips)
                                        if backup_db_origin_domain:
                                            set_gslbdomain_vip(request, backup_db_origin_domain, vips)

                                        if storagenode.node_type == 0:  # writer
                                            temp_data_clusters_vips.append(vips[0])
                                            temp_upload_clusters_vips.append(vips[0])

                                            set_gslbdomain_vip(request, backup_upload_domain, vips)
                                            if backup_db_upload_domain:
                                                set_gslbdomain_vip(request, backup_db_upload_domain, vips)

                                            if storage_cluster.is_preferred_cluster == 1:
                                                master_writer_vips.append(vips[0])
                                        else:  # reader
                                            temp_data_clusters_vips.append(vips[0])

                        if user_https_domain:
                            storage_cluster.backup_https_domain = backup_origin_domain
                            storage_cluster.backup_https_upload_domain = backup_upload_domain
                            if db_origin_domain:
                                storage_cluster.backup_domain = backup_db_origin_domain
                                storage_cluster.backup_upload_domain = backup_db_upload_domain
                        else:
                            storage_cluster.backup_domain = backup_origin_domain
                            storage_cluster.backup_upload_domain = backup_upload_domain
                            if db_origin_domain:
                                storage_cluster.backup_https_domain = backup_db_origin_domain
                                storage_cluster.backup_https_upload_domain = backup_db_upload_domain
                        storage_cluster.save(request=request)

                    try:
                        delete_gslbdomain_vips_notin(request, origin_domain, temp_data_clusters_vips)
                    except:
                        origin_domain = None
                    try:
                        delete_gslbdomain_vips_notin(request, db_origin_domain, temp_data_clusters_vips)
                    except:
                        db_origin_domain = None
                    try:
                        delete_gslbdomain_vips_notin(request, upload_domain, temp_upload_clusters_vips)
                    except:
                        upload_domain = None
                    try:
                        delete_gslbdomain_vips_notin(request, db_upload_domain, temp_upload_clusters_vips)
                    except:
                        db_upload_domain = None

                set_cluster_vip(request, storage, origin_domain, upload_domain)  # ,master_domain
                if db_origin_domain:
                    set_cluster_vip(request, storage, db_origin_domain, db_upload_domain)

                storage.customer = customer
                storage.contract = contract
                storage.generate_gslb = 1
                storage.use_cdn_origin = 1
                if user_https_domain:
                    storage.https_origin_domain = origin_domain
                    storage.https_upload_domain = upload_domain
                    storage.https_origin_domain_name = user_origin_domain
                    storage.https_upload_domain_name = user_upload_domain
                    if db_origin_domain:
                        storage.data_domain = db_origin_domain
                        storage.upload_domain = db_upload_domain
                        storage.user_origin_domain = db_origin_domain.name
                        storage.user_upload_domain = db_upload_domain.name
                else:
                    storage.data_domain = origin_domain
                    storage.upload_domain = upload_domain
                    storage.user_origin_domain = user_origin_domain
                    storage.user_upload_domain = user_upload_domain
                    if db_origin_domain:
                        storage.https_origin_domain = db_origin_domain
                        storage.https_upload_domain = db_upload_domain
                        storage.https_origin_domain_name = db_origin_domain.name
                        storage.https_upload_domain_name = db_upload_domain.name
                storage.user_origin_domain_enabled = 1

                storage.obj_state = 1
                storage.save(request=request, contract_no=contract_no, item_id=item_id)  # need to set contract_no

                storageusers = StorageUser.objects.filter(storage=storage)
                if storageusers.count() == 0:
                    insert_default_storage_user(request, storage)

                # vip priority set
                if storage_clusters.exists():
                    for storage_cluster in storage_clusters:
                        if storage.upload_domain and storage.upload_domain != '':
                            set_gslbdomain_vips_priority(request, storage.upload_domain, master_writer_vips, 1)
                            if len(master_writer_vips) > 0:
                                set_gslbdomain_vips_priority_others(request, storage.upload_domain, master_writer_vips, 2)
                            else:
                                set_gslbdomain_vips_priority_others(request, storage.upload_domain, master_writer_vips, 1)

                        if storage.https_upload_domain and storage.https_upload_domain != '':
                            set_gslbdomain_vips_priority(request, storage.https_upload_domain, master_writer_vips, 1)
                            if len(master_writer_vips) > 0:
                                set_gslbdomain_vips_priority_others(request, storage.https_upload_domain, master_writer_vips, 2)
                            else:
                                set_gslbdomain_vips_priority_others(request, storage.https_upload_domain, master_writer_vips, 1)

        except Storage.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Storage data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'Updated'), "storage_id":storage.pk}, status=HTTP_202_ACCEPTED)

    @transaction.commit_manually
    def delete(self, request, *args, **kwargs):
        try:
            storage_id = self.kwargs.get(self.lookup_url_kwarg)
            if not storage_id:
                raise Exception('Storage ID Missing')

            storage = Storage.all_objects.get(storage_id=storage_id)
            if storage:
                try:
                    item_id = getStatMasterItem(storage)
                except:
                    item_id = None
                # virturl host delete
                storage_sid_vhosts = StorageSidVhosts.objects.filter(storage=storage)
                if storage_sid_vhosts.exists():
                    for sid_vhost in storage_sid_vhosts:
                        if sid_vhost.gslb_service_domain:
                            sid_vhost.gslb_service_domain.delete_all_related(request)
                        if sid_vhost.https_service_domain:
                            sid_vhost.https_service_domain.delete_all_related(request)

                        sid_vhost.delete(request=request)

                storage.delete_related(request=request)

                storage.obj_state = 0
                storage.storage_name = storage.storage_name + '_deleted_' + str(storage.pk)
                if storage.contract:
                    storage.save(request=request, contract_no=storage.contract.contract_no, item_id=item_id)
                else:
                    storage.save(request=request, item_id=item_id)

                # delete gslb domain
                if storage.data_domain:
                    storage.data_domain.delete_all_related(request)
                if storage.https_origin_domain:
                    storage.https_origin_domain.delete_all_related(request)
                if storage.upload_domain:
                    storage.upload_domain.delete_all_related(request)
                if storage.https_upload_domain:
                    storage.https_upload_domain.delete_all_related(request)
                if storage.master_domain:
                    storage.master_domain.delete_all_related(request)
                # set stat_master's obj_state to 2
                storagestatmasters = StorageStatMaster.objects.filter(storage=storage)
                if storagestatmasters:
                    for storagestatmaster in storagestatmasters:
                        statmaster = storagestatmaster.statmaster
                        statmaster.obj_state = 2
                        statmaster.service_remove_flag = 1
                        statmaster.save(request=request)
            else:
                raise Exception(_(u"None deleted!"))
        except Storage.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Storage data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'Deleted.')}, status=HTTP_202_ACCEPTED)

class StarfsDomainsAPI(RetrieveModelMixin, SpectrumGenericAPIView):
    queryset = Storage.objects.all()
    serializer_class = StarfsDomainsSerializer
    lookup_url_kwarg = __STORAGE_URL_LOOKUP_KEY__

    def get(self, request, *args, **kwargs):
        ret = super(StarfsDomainsAPI, self).retrieve(request, *args, **kwargs)

        try:
            storage_id = self.kwargs.get(self.lookup_url_kwarg)
        except KeyError:
            raise AccessInvalidStorageID

        org_results = ret.data

        storage_clusters = getStroageClusterList(storage_id)
        storagevhosts_Clusters = getStorageVhostsClusterList(storage_id)

        if len(storage_clusters) > 0:
            org_results['sync_clusters'] = storage_clusters
        else:
            org_results['sync_clusters'] = []

        if len(storagevhosts_Clusters) > 0:
            org_results['vhosts'] = storagevhosts_Clusters
        else:
            org_results['vhosts'] = []

        ret.data = org_results

        return ret

class StorageActionHistoryAPI(ListModelMixin, SpectrumGenericAPIView):
    def get(self, request, *args, **kwargs):
        try:
            storage_id = self.kwargs.get("storage_id")

            action_history = None
            aurora_action_history = None

            storage_name = Storage.all_objects.get(pk=int(storage_id)).storage_name

            action_history = ActionHistory.objects.filter(Q(action_obj__contains='"storage_name": "' + storage_name + '",') | 
                                   Q(action_obj__contains='"storage": "' + storage_name + '",')) \
                           .order_by('-action_time')[:50]
            aurora_action_history = AuroraActionHistory.objects.filter(Q(action_obj__contains='"storage_name": "' + storage_name + '",') | 
                                                                       Q(action_obj__contains='"storage": "' + storage_name + '",')) \
                                                               .order_by('-action_time')[:50]

            history_list = []
            for ah in itertools.chain(action_history, aurora_action_history):
                json_action_obj = simplejson.loads(ah.action_obj)
                try:
                    history_list.append({'action_time':smart_str(ah.action_time),
                            'action_model':ah.action_model,
                            'action_type':ah.get_action_type_display(),
                            'user':ah.user.username if ah._meta.db_table == 'core_action_history' else "Aurora User ({user})".format(user=ah.user.username),
                            'time_updated':json_action_obj.get('time_updated', None),
                            'data':ah.getjsondata()})
                except Exception, e:
                    pass

        except Exception, e:
            raise APIException(detail=_(u"%s" %e))

        return Response(history_list)

class StorageVhostsAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = StorageSidVhosts.objects.all()
    serializer_class = StroageVhostsSerializer
    lookup_url_kwarg = __VHOSTS_URL_LOOKUP_KEY__
    ordering = 'date_created'

    def get_queryset(self):
        storage_id = self.kwargs.get("storage_id", None)
        if storage_id is not None and storage_id != '':
            self.queryset = self.queryset.filter(storage__pk=int(storage_id))
        else:
            raise AccessInvalidStorageID

        return self.queryset

    def get(self, request, *args, **kwargs):
        return super(StorageVhostsAPI, self).list(request, *args, **kwargs)

    @transaction.commit_manually
    def post(self, request, *args, **kwargs):
        try:
            storage_id = self.kwargs.get('storage_id', None)
            if storage_id is None or storage_id == '':
                raise Exception('Storage ID is required.')

            #parameter value validaion
            vhosts_validate(self.request, 'add')

            service_domain = request.DATA.get("virtual_host")
            starfs_service_domain = request.DATA.get('starfs_service_domain')
            dcm_root = request.DATA.get('dcm_root')

            duplicated_gslb_domain = Domain.objects.filter(name=starfs_service_domain)
            duplicated_vhosts = StorageSidVhosts.objects.filter(Q(starfs_service_domain=starfs_service_domain) |
                                                                Q(https_service_domain_name=starfs_service_domain))
            if duplicated_vhosts.exists() or duplicated_gslb_domain.exists():
                if duplicated_vhosts.exists():
                    storage = Storage.all_objects.get(storage_id=duplicated_vhosts[0].storage.storage_id)
                    transaction.rollback()
                    raise Exception('Same Virtual HOST Address ' + service_domain + ' exists with SID ' + storage.storage_name)
                else:
                    transaction.rollback()
                    raise Exception('GSLB Service URL name ' + starfs_service_domain + ' is duplicated.')
            else:
                storage = Storage.all_objects.get(storage_id=storage_id)
                user_https_domain = False
                conn_char = '.'
                if starfs_service_domain[0:7] == "origin-":
                    user_https_domain = True
                    conn_char = '-'

                storageSidVhosts = StorageSidVhosts()
                storageSidVhosts.storage = storage
                storageSidVhosts.service_domain = service_domain
                if user_https_domain:
                    storageSidVhosts.https_service_domain_name = starfs_service_domain
                else:
                    storageSidVhosts.starfs_service_domain = starfs_service_domain
                storageSidVhosts.use_cdn_origin_enabled = 1
                storageSidVhosts.dcm_root = dcm_root

                validate_vhosts_service_domain(request, storageSidVhosts, service_domain)
                validate_vhosts_starfs_domain(request, storageSidVhosts, starfs_service_domain)

                data_domain = set_user_gslb_domain(request, storage, starfs_service_domain, storage.customer, 'starfs service url')
                set_cluster_vip(request, storage, data_domain)
                if user_https_domain:
                    storageSidVhosts.https_service_domain = data_domain
                else:
                    storageSidVhosts.gslb_service_domain = data_domain

                storageSidVhosts.save(request=request)

                # backup_domain created
                temp_data_clusters_vips = []
                storage_clusters = StorageCluster.all_objects.filter(storage=storage)
                if storage_clusters.exists():
                    for storage_cluster in storage_clusters:
                        backup_domain_name = 'backup' + str(storage_cluster.backup_order) + conn_char + data_domain.name
                        backup_domain = set_backup_gslb_domain(request, backup_domain_name, storage.customer)
                        if storage_cluster.cluster:
                            storagenodes = StorageNode.objects.filter(cluster=storage_cluster.cluster)
                            for storagenode in storagenodes:
                                vips = get_vips_by_ipid(storagenode.ip_id)
                                if vips:  # all ==> data , backup
                                    if storagenode.node_type == 0 or storagenode.node_type == 1:  # writer,reader
                                        set_gslbdomain_vip(request, backup_domain, vips)
                                        temp_data_clusters_vips.append(vips[0])

                            storageClusterVhosts = StorageClusterVhosts()
                            storageClusterVhosts.vhosts = storageSidVhosts
                            storageClusterVhosts.sid_cluster = storage_cluster
                            if user_https_domain:
                                storageClusterVhosts.backup_https_domain = backup_domain
                            else:
                                storageClusterVhosts.backup_domain = backup_domain

                            storageClusterVhosts.save(request=request)
                    try:
                        delete_gslbdomain_vips_notin(request, data_domain, temp_data_clusters_vips)
                    except:
                        data_domain = None

        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'Added.')}, status=HTTP_202_ACCEPTED)

class StorageVhostsDetailAPI(RetrieveModelMixin, SpectrumGenericAPIView):
    queryset = StorageSidVhosts.objects.all()
    serializer_class = StroageVhostsSerializer
    lookup_url_kwarg = __VHOSTS_URL_LOOKUP_KEY__

    def get(self, request, *args, **kwargs):
        return super(StorageVhostsDetailAPI, self).retrieve(request, *args, **kwargs)

    @transaction.commit_manually
    def patch(self, request, *args, **kwargs):
        try:
            storage_id = self.kwargs.get('storage_id', None)
            vhosts_id = self.kwargs.get(self.lookup_url_kwarg, None)

            if storage_id is None or storage_id == '':
                raise Exception('Storage ID is required.')
            if vhosts_id is None or storage_id == '':
                raise Exception('Vhosts ID is required.')

            #parameter value validaion
            vhosts_validate(self.request, 'edit', vhosts_id)

            service_domain = request.DATA.get("virtual_host")
            starfs_service_domain = request.DATA.get('starfs_service_domain')
            dcm_root = request.DATA.get('dcm_root')

            storage = Storage.objects.get(storage_id=storage_id)
            if storage:
                user_https_domain = False
                if starfs_service_domain[0:7] == "origin-":
                    user_https_domain = True

                storageSidVhosts = StorageSidVhosts.all_objects.get(idx=vhosts_id)

                if storageSidVhosts:
                    validate_vhosts_service_domain(request, storageSidVhosts, service_domain)
                    validate_vhosts_starfs_domain(request, storageSidVhosts, starfs_service_domain)

                    db_data_domain = None
                    if user_https_domain:
                        if storageSidVhosts.starfs_service_domain and storageSidVhosts.starfs_service_domain != '':
                            db_data_domain = set_user_gslb_domain(request, storage, 
                                                                     storageSidVhosts.starfs_service_domain, 
                                                                     storage.customer, 'origin domain')
                    else:
                        if storageSidVhosts.https_service_domain_name and storageSidVhosts.https_service_domain_name != '':
                            db_data_domain = set_user_gslb_domain(request, storage, 
                                                                     storageSidVhosts.https_service_domain_name, 
                                                                     storage.customer, 'origin domain')
                    data_domain = set_user_gslb_domain(request, storage, 
                                                       starfs_service_domain, 
                                                       storage.customer, 'origin domain')

                    temp_data_clusters_vips = []
                    storage_clusters = StorageCluster.all_objects.filter(storage=storage)
                    if storage_clusters.exists():
                        for storage_cluster in storage_clusters:
                            vhostsClusters = StorageClusterVhosts.all_objects.filter(sid_cluster=storage_cluster, vhosts=storageSidVhosts)
                            for vhostsCluster in vhostsClusters:
                                try:
                                    delete_gslbdomain_vip(request, vhostsCluster.backup_domain)
                                except:
                                    vhostsCluster.backup_domain = None
                                try:
                                    delete_gslbdomain_vip(request, vhostsCluster.backup_https_domain)
                                except:
                                    vhostsCluster.backup_https_domain = None

                                backup_domain_name = 'backup' + str(storage_cluster.backup_order) + get_connection_character(user_https_domain) + data_domain.name
                                backup_domain = set_backup_gslb_domain(request, backup_domain_name, storage.customer)
                                if db_data_domain:
                                    backup_db_domain_name = 'backup' + str(storage_cluster.backup_order) + get_connection_character(not user_https_domain) + db_data_domain.name
                                    backup_db_domain = set_backup_gslb_domain(request, backup_db_domain_name, storage.customer)
                                else:
                                    backup_db_domain = None

                                if storage_cluster.cluster:
                                    storagenodes = StorageNode.objects.filter(cluster=storage_cluster.cluster)
                                    for storagenode in storagenodes:
                                        vips = get_vips_by_ipid(storagenode.ip_id)
                                        if vips:  # all ==> data , backup
                                            if storagenode.node_type == 0 or storagenode.node_type == 1:  # writer,reader
                                                set_gslbdomain_vip(request, backup_domain, vips)
                                                if backup_db_domain:
                                                    set_gslbdomain_vip(request, backup_db_domain, vips)
                                                temp_data_clusters_vips.append(vips[0])

                                if user_https_domain:
                                    vhostsCluster.backup_https_domain = backup_domain
                                    if db_data_domain:
                                        vhostsCluster.backup_domain = backup_db_domain
                                else:
                                    vhostsCluster.backup_domain = backup_domain
                                    if db_data_domain:
                                        vhostsCluster.backup_https_domain = backup_db_domain
                                vhostsCluster.save(request=request)

                        try:
                            delete_gslbdomain_vips_notin(request, data_domain, temp_data_clusters_vips)
                        except:
                            data_domain = None
                        try:
                            delete_gslbdomain_vips_notin(request, db_data_domain, temp_data_clusters_vips)
                        except:
                            db_data_domain = None

                    set_cluster_vip(request, storage, data_domain)
                    if db_data_domain:
                        set_cluster_vip(request, storage, db_data_domain)

                    storageSidVhosts.service_domain = service_domain
                    if user_https_domain:
                        storageSidVhosts.https_service_domain = data_domain
                        storageSidVhosts.https_service_domain_name = starfs_service_domain
                        if db_data_domain:
                            storageSidVhosts.gslb_service_domain = db_data_domain
                            storageSidVhosts.starfs_service_domain = db_data_domain.name
                    else:
                        storageSidVhosts.gslb_service_domain = data_domain
                        storageSidVhosts.starfs_service_domain = starfs_service_domain
                        if db_data_domain:
                            storageSidVhosts.https_service_domain = db_data_domain
                            storageSidVhosts.https_service_domain_name = db_data_domain.name

                    storageSidVhosts.use_cdn_origin_enabled = 1
                    storageSidVhosts.dcm_root = dcm_root
                    storageSidVhosts.save(request=request)

        except Storage.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Storage data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'Updated.')}, status=HTTP_202_ACCEPTED)

    @transaction.commit_manually
    def delete(self, request, *args, **kwargs):
        try:
            storage_id = self.kwargs.get('storage_id', None)
            vhosts_id = self.kwargs.get(self.lookup_url_kwarg, None)

            if storage_id is None or storage_id == '':
                raise Exception('Storage ID is required.')
            if vhosts_id is None or storage_id == '':
                raise Exception('Vhosts ID is required.')

            storage_sid_vhosts = StorageSidVhosts.objects.get(idx=vhosts_id)
            if storage_sid_vhosts:
                if storage_sid_vhosts.gslb_service_domain:
                    storage_sid_vhosts.gslb_service_domain.delete_all_related(request)
                if storage_sid_vhosts.https_service_domain:
                    storage_sid_vhosts.https_service_domain.delete_all_related(request)

                vhosts_clusters = StorageClusterVhosts.all_objects.filter(vhosts=storage_sid_vhosts)
                for vhosts_cluster in vhosts_clusters:
                    if vhosts_cluster.backup_domain:
                        vhosts_cluster.backup_domain.delete_all_related(request)
                    if vhosts_cluster.backup_https_domain:
                        vhosts_cluster.backup_https_domain.delete_all_related(request)

                    vhosts_cluster.delete(request=request)

                storage_sid_vhosts.delete()
            else:
                raise Exception(_(u"vhosts not exist. None deleted."))
        except StorageSidVhosts.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Virtual SID data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'Deleted.')}, status=HTTP_202_ACCEPTED)

class ClusterListAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = Cluster.objects.all()
    serializer_class = ClusterSimpleSerializer
    lookup_url_kwarg = 'cluster_id'
    ordering = 'cluster_name'

    def get(self, request, *args, **kwargs):
        return super(ClusterListAPI, self).list(request, *args, **kwargs)

class StorageClusterAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = StorageCluster.objects.all()
    serializer_class = StroageClustersSerializer
    lookup_url_kwarg = __STORAGE_CLUSTER_URL_LOOKUP_KEY__
    ordering = 'backup_order'
 
    def get_queryset(self):
        storage_id = self.kwargs.get("storage_id", None)
        if storage_id is not None and storage_id != '':
            self.queryset = self.queryset.filter(storage__pk=int(storage_id))
        else:
            raise AccessInvalidStorageID
 
        return self.queryset
 
    def get(self, request, *args, **kwargs):
        return super(StorageClusterAPI, self).list(request, *args, **kwargs)

    @transaction.commit_manually
    def post(self, request, *args, **kwargs):
        storage_id = self.kwargs.get('storage_id', None)
        cluster_id = request.DATA.get("cluster_id", None)
        if storage_id is None or storage_id == '':
            raise Exception('Storage ID is required.')
        if cluster_id is None or cluster_id == '':
            raise Exception('Cluster ID is required.')

        preferred = request.DATA.get("preferred", '0')

        try:
            storage = Storage.objects.get(storage_id=storage_id)
            cluster = Cluster.objects.get(cluster_id=cluster_id)
            item_id = getStatMasterItem(storage)

            if not cluster.config_state:
                raise Exception('Can not be registered because the cluster was not fully configured for service.')

            cluster_count_limit = 0
            customer_item = CustomerItem.objects.get(item_id=item_id)
            if customer_item:
                try:
                    cluster_count_limit = customer_item.get_cloudstorage_cluster_limit()
                except:
                    pass

            storageclusters = StorageCluster.objects.filter(storage=storage)
            if customer_item.contract.is_valid_contract(settings.CLOUD_STORAGE_MATERIAL):
                if storageclusters.count() >= cluster_count_limit:
                    raise Exception ('Contract %s has been granted clusters within %s count.' 
                                     % (customer_item.contract.getFullName(), str(cluster_count_limit)))
            else:
                raise Exception ('Contract has not been set yet or expired.')

            if cluster and preferred == '1':
                if not cluster.hasWriterNode():
                    raise Exception('Cluster ' + cluster.cluster_name + ' has no writer node. need to have writer node to be preferred.')

            # Storage Cluster/ Vhosts Cluster Created
            set_storage_cluster_vhosts(request, storage, cluster, item_id, preferred)

        except Storage.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Storage data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except Cluster.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Cluster data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'Cluster Added.')}, status=HTTP_202_ACCEPTED)

class StorageClusterDetailAPI(RetrieveModelMixin, SpectrumGenericAPIView):
    queryset = StorageCluster.objects.all()
    serializer_class = StroageClustersSerializer
    lookup_url_kwarg = __STORAGE_CLUSTER_URL_LOOKUP_KEY__

    def get(self, request, *args, **kwargs):
        return super(StorageClusterDetailAPI, self).retrieve(request, *args, **kwargs)

    @transaction.commit_manually
    def patch(self, request, *args, **kwargs):
        try:
            storage_id = self.kwargs.get('storage_id', None)
            cluster_id = request.DATA.get("cluster_id", None)
            if storage_id is None or storage_id == '':
                raise Exception('Storage ID is required.')
            if cluster_id is None or cluster_id == '':
                raise Exception('Cluster ID is required.')
            preferred = request.DATA.get("preferred", '0')

            storage = Storage.objects.get(storage_id=storage_id)
            cluster = Cluster.objects.get(cluster_id=cluster_id)
            item_id = getStatMasterItem(storage)

            if not cluster.config_state:
                raise Exception('Can not be registered because the cluster was not fully configured for service.')

            cluster_count_limit = 0
            customer_item = CustomerItem.objects.get(item_id=item_id)
            if customer_item:
                try:
                    cluster_count_limit = customer_item.get_cloudstorage_cluster_limit()
                except:
                    pass

            storageclusters = StorageCluster.objects.filter(storage=storage)
            if customer_item.contract.is_valid_contract(settings.CLOUD_STORAGE_MATERIAL):
                if storageclusters.count() > cluster_count_limit:
                    raise Exception ('Contract %s has been granted clusters within %s count.' 
                                     % (customer_item.contract.getFullName(), str(cluster_count_limit)))
            else:
                raise Exception ('Contract has not been set yet or expired.')

            if cluster and preferred == '1':
                if not cluster.hasWriterNode():
                    raise Exception('Cluster ' + cluster.cluster_name + ' has no writer node. need to have writer node to be preferred.')

            # Storage Cluster/ Vhosts Cluster Modified
            set_storage_cluster_vhosts(request, storage, cluster, item_id, preferred)

        except Storage.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Storage data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except Cluster.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Cluster data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'Cluster Updated.')}, status=HTTP_202_ACCEPTED)

    @transaction.commit_manually
    def delete(self, request, *args, **kwargs):
        try:
            storage_cluster_id = self.kwargs.get(self.lookup_url_kwarg, None)
            if storage_cluster_id is None or storage_cluster_id == '':
                raise Exception('Storage Cluster ID(idx) is required.')

            storage_cluster = StorageCluster.all_objects.get(idx=storage_cluster_id)
            item_id = getStatMasterItem(storage_cluster.storage)

            if storage_cluster:
                storage_cluster.obj_state = 0

                storage_backup_domain = storage_cluster.backup_domain
                storage_backup_https_domain = storage_cluster.backup_https_domain
                storage_backup_upload_domain = storage_cluster.backup_upload_domain
                storage_backup_https_upload_domain = storage_cluster.backup_https_upload_domain

                storage_cluster_storage = storage_cluster.storage
                storage_contract_no = storage_cluster.storage.contract.contract_no
                storage_cluster_clusters_cnt = storage_cluster.storage.clusters.count()

                temp_data_clusters_vips = []
                temp_upload_clusters_vips = []
                storagenodes = StorageNode.objects.filter(cluster=storage_cluster.cluster)
                for storagenode in storagenodes:
                    vips = get_vips_by_ipid(storagenode.ip_id)
                    if vips.exists():  # all ==> data , backup
                        if storagenode.node_type == 0 or storagenode.node_type == 1:  # writer,reader
                            temp_data_clusters_vips.append(vips[0])
                            if storagenode.node_type == 0:  # writer
                                temp_upload_clusters_vips.append(vips[0])

                try:
                    delete_gslbdomain_vips_now(request, storage_cluster.storage.data_domain, temp_data_clusters_vips)
                except:
                    storage_cluster.storage.data_domain = None
                try:
                    delete_gslbdomain_vips_now(request, storage_cluster.storage.https_origin_domain, temp_data_clusters_vips)
                except:
                    storage_cluster.storage.https_origin_domain = None
                try:
                    delete_gslbdomain_vips_now(request, storage_cluster.storage.upload_domain, temp_upload_clusters_vips)
                except:
                    storage_cluster.storage.upload_domain = None
                try:
                    delete_gslbdomain_vips_now(request, storage_cluster.storage.https_upload_domain, temp_upload_clusters_vips)
                except:
                    storage_cluster.storage.https_upload_domain = None

                # Virtual HOST
                storage_sid_vhosts = StorageSidVhosts.all_objects.filter(storage=storage_cluster.storage)
                for sid_vhosts in storage_sid_vhosts:
                    try:
                        delete_gslbdomain_vips_now(request, sid_vhosts.gslb_service_domain, temp_data_clusters_vips)
                    except:
                        sid_vhosts.gslb_service_domain = None
                    try:
                        delete_gslbdomain_vips_now(request, sid_vhosts.https_service_domain, temp_data_clusters_vips)
                    except:
                        sid_vhosts.https_service_domain = None

                    storage_cluster_vhosts = StorageClusterVhosts.all_objects.filter(vhosts=sid_vhosts, sid_cluster=storage_cluster)
                    if storage_cluster_vhosts.exists():
                        if storage_cluster_vhosts[0].backup_domain:
                            delete_gslbdomain_vip(request, storage_cluster_vhosts[0].backup_domain)
                        if storage_cluster_vhosts[0].backup_https_domain:
                            delete_gslbdomain_vip(request, storage_cluster_vhosts[0].backup_https_domain)
                        storage_cluster_vhosts[0].delete(request=request)

                snapshot_io_events = StorageSnapshotIoEvent.objects.filter(cluster_storage_id=storage_cluster.idx)
                for io_event in snapshot_io_events:
                    io_event.delete()
                snapshot_sync_mismatch = StorageSnapshotSyncMismatch.objects.filter(cluster_storage_id=storage_cluster.idx)
                for sync_mismatch in snapshot_sync_mismatch:
                    sync_mismatch.delete()

                storage_cluster.delete(request=request)
                if storage_backup_domain:
                    delete_gslbdomain_vip(request, storage_backup_domain)
                if storage_backup_https_domain:
                    delete_gslbdomain_vip(request, storage_backup_https_domain)
                if storage_backup_upload_domain:
                    delete_gslbdomain_vip(request, storage_backup_upload_domain)
                if storage_backup_https_upload_domain:
                    delete_gslbdomain_vip(request, storage_backup_https_upload_domain)

                reorder_storage_clusters(request, storage_cluster_storage, storage_cluster_id)
                reorder_vhosts_clusters(request, storage_cluster_storage, storage_cluster_id)

                # storage = Storage.objects.filter(storage_id=storage_cluster.storage.pk)
                if storage_cluster_clusters_cnt >= 0:  # enable/disable config state
                    storage_cluster.storage.save(request=request, contract_no=storage_contract_no, item_id=item_id)

                # master cluster check
                storageclusters = StorageCluster.objects.filter(
                                        storage__storage_id=storage_cluster.storage.storage_id, is_preferred_cluster=1)
                if storageclusters.exists():
                    pass
                else:
                    domainvips = DomainVip.objects.filter(Q(domain=storage_cluster.storage.upload_domain) |
                                                          Q(domain=storage_cluster.storage.https_upload_domain))
                    if domainvips.exists():
                        for domainvip in domainvips:
                            domainvip.priority = 1
                            domainvip.save(request=request)
            else:
                raise Exception(_(u"storage cluster not exist. None deleted."))
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'Deleted.')}, status=HTTP_202_ACCEPTED)

class StorageUsersAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = StorageUser.objects.all()
    serializer_class = StroageUsersSerializer
    lookup_url_kwarg = 'user_id'
    ordering = 'date_created'
 
    def get_queryset(self):
        storage_id = self.kwargs.get("storage_id", None)
        if storage_id is not None and storage_id != '':
            self.queryset = self.queryset.filter(storage__pk=int(storage_id))
        else:
            raise AccessInvalidStorageID
 
        return self.queryset
 
    def get(self, request, *args, **kwargs):
        return super(StorageUsersAPI, self).list(request, *args, **kwargs)

    @transaction.commit_manually
    def post(self, request, *args, **kwargs):
        try:
            storage_id = self.kwargs.get('storage_id', None)
            if storage_id is None or storage_id == '':
                raise Exception('Storage ID is required.')

            storage = Storage.all_objects.get(storage_id=storage_id)
            #parameter value validaion
            storage_user_validate(self.request, 'add', storage.storage_name)

            user_name = request.DATA.get("user_name")
            password = request.DATA.get('password')
            access_path = request.DATA.get('access_path')

            user_status = request.DATA.get('status', 1)
            user_readonly = request.DATA.get('is_readonly', 0)
            enc_type = request.DATA.get('enc_type', 0)
            ssh_pubkey = request.DATA.get('ssh_pubkey', None)

            if int(enc_type) == 0:  # md5
                new_password = get_md5_password(password)
            else:  # linux cript
                new_password = get_linux_crypt_password(password)

            storage_user = StorageUser()
            storage_user.storage = storage
            storage_user.user_name = user_name + '_' + storage.storage_name
            storage_user.status = user_status
            storage_user.is_readonly = user_readonly
            storage_user.access_path = access_path
            storage_user.enc_type = enc_type
            storage_user.raw_password = password
            storage_user.password = new_password
            storage_user.ssh_pubkey = ssh_pubkey
            storage_user.save(request=request)

        except Storage.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Storage data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'Storage User Added.')}, status=HTTP_202_ACCEPTED)

class StorageUserDetailAPI(RetrieveModelMixin, SpectrumGenericAPIView):
    queryset = StorageUser.objects.all()
    serializer_class = StroageUsersSerializer
    lookup_url_kwarg = 'user_id'

    def get(self, request, *args, **kwargs):
        return super(StorageUserDetailAPI, self).retrieve(request, *args, **kwargs)

    @transaction.commit_manually
    def patch(self, request, *args, **kwargs):
        try:
            user_id = self.kwargs.get(self.lookup_url_kwarg, None)
            if user_id is None or user_id == '':
                raise Exception('Storage User ID is required.')

            storage_user = StorageUser.all_objects.get(user_id=user_id)
            before_password = storage_user.raw_password

            #parameter value validaion
            storage_user_validate(self.request, 'edit', storage_user.storage.storage_name)

            password = request.DATA.get('password')
            access_path = request.DATA.get('access_path')
            user_status = request.DATA.get('status', 1)
            user_readonly = request.DATA.get('is_readonly', 0)
            enc_type = request.DATA.get('enc_type', 0)
            ssh_pubkey = request.DATA.get('ssh_pubkey', None)

            storage_user.access_path = access_path
            storage_user.status = user_status
            storage_user.is_readonly = user_readonly
            storage_user.enc_type = enc_type

            if int(storage_user.enc_type) == 0:  # md5
                if get_md5_password(before_password) != password:
                    storage_user.raw_password = password
                    new_hashed_password = get_md5_password(password)
                    storage_user.password = new_hashed_password
            else:  # linux cript
                if get_linux_crypt_password(before_password) != password:
                    storage_user.raw_password = password
                    new_hashed_password = get_linux_crypt_password(password)
                    storage_user.password = new_hashed_password

            storage_user.ssh_pubkey = ssh_pubkey
            storage_user.save(request=request)

        except StorageUser.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Storage User data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'Storage User Updated.')}, status=HTTP_202_ACCEPTED)

    @transaction.commit_manually
    def delete(self, request, *args, **kwargs):
        try:
            user_id = self.kwargs.get(self.lookup_url_kwarg, None)
            if user_id is None or user_id == '':
                raise Exception('Storage User ID is required.')

            storage_user = StorageUser.objects.get(user_id=user_id)
            if storage_user:
                if storage_user.user_name != storage_user.storage.storage_name:
                    storage_user.obj_state = 0
                    storage_user.delete(request=request)
                else:
                    raise Exception(_(u"Can not delete the same User Name(Default User) as SID Name."))
            else:
                raise Exception(_(u"Storage User not exist. None deleted."))
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'Deleted.')}, status=HTTP_202_ACCEPTED)

class StorageConfigListAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = StorageConfigParameter.objects.all()
    serializer_class = StorageConfigListSerializer
    lookup_url_kwarg = 'config_param_id'
    ordering = 'param_name'

    def get(self, request, *args, **kwargs):
        return super(StorageConfigListAPI, self).list(request, *args, **kwargs)

class StorageSidConfigAPI(ListModelMixin,
                          SpectrumGenericAPIView):
    queryset = StorageSidConfig.objects.all()
    serializer_class = StorageSidConfigSerializer
    lookup_url_kwarg = 'sid_config_id'
    ordering = 'param_name'

    def get_queryset(self):
        storage_id = self.kwargs.get("storage_id", None)
        if storage_id is not None and storage_id != '':
            self.queryset = self.queryset.filter(storage__pk=int(storage_id))
        else:
            raise AccessInvalidStorageID

        return self.queryset

    def get(self, request, *args, **kwargs):
        return super(StorageSidConfigAPI, self).list(request, *args, **kwargs)

    @transaction.commit_manually
    def post(self, request, *args, **kwargs):
        try:
            storage_id = self.kwargs.get('storage_id', None)
            if storage_id is None or storage_id == '':
                raise Exception('Storage ID is required.')
            storage = Storage.objects.get(storage_id=storage_id)

            #parameter value validaion
            storage_config_validate(self.request)

            param_name = request.DATA.get("param_name")
            param_value = request.DATA.get('param_value')
            # param name duplicated check
            storage_configs = StorageSidConfig.objects.filter(param_name=param_name, storage=int(storage_id))
            if storage_configs.exists():
                raise Exception('Same param name %s exists' % (param_name))

            storageconfig = StorageSidConfig()
            storageconfig.storage_id = int(storage_id)
            storageconfig.param_name = param_name
            storageconfig.param_value = param_value
            storageconfig.save(request=request)

        except Storage.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Storage data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'Config Parameters Added.')}, status=HTTP_202_ACCEPTED)

class StorageSidConfigDetailAPI(RetrieveModelMixin, 
                               DestroyModelMixin,
                               SpectrumGenericAPIView):
    queryset = StorageSidConfig.objects.all()
    serializer_class = StorageSidConfigSerializer
    lookup_url_kwarg = 'sid_config_id'

    def get(self, request, *args, **kwargs):
        return super(StorageSidConfigDetailAPI, self).retrieve(request, *args, **kwargs)

    @transaction.commit_manually
    def patch(self, request, *args, **kwargs):
        try:
            sid_config_id = self.kwargs.get(self.lookup_url_kwarg, None)
            storage_id = self.kwargs.get('storage_id', None)
            if sid_config_id is None or sid_config_id == '':
                raise Exception('Storage Config ID is required.')
            if storage_id is None or storage_id == '':
                raise Exception('Storage ID is required.')
            storage = Storage.objects.get(storage_id=storage_id)

            #parameter value validaion
            storage_config_validate(self.request)

            param_name = request.DATA.get("param_name")
            param_value = request.DATA.get('param_value')

            # param name duplicated check
            storage_configs = StorageSidConfig.objects.filter(param_name=param_name, storage=int(storage_id))\
                            .exclude(pk=int(sid_config_id))
            if storage_configs.exists():
                raise Exception('Same param name %s exists' % (param_name))

            storageconfig = StorageSidConfig.objects.get(pk=int(sid_config_id))
            storageconfig.param_name = param_name
            storageconfig.param_value = param_value
            storageconfig.save(request=request)

        except Storage.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Storage data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except StorageSidConfig.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Storage Config data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'Config Parameters Updated.')}, status=HTTP_202_ACCEPTED)

    def delete(self, request, *args, **kwargs):
        return super(StorageSidConfigDetailAPI, self).destroy(request, *args, **kwargs)


class StorageSidMimeConfigAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = StorageMimeConfig.objects.all()
    serializer_class = StorageSidMimeConfigSerializer
    lookup_url_kwarg = 'sid_mimeconfig_id'
    ordering = 'param_name'

    def get_queryset(self):
        storage_id = self.kwargs.get("storage_id", None)
        if storage_id is not None and storage_id != '':
            self.queryset = self.queryset.filter(storage__pk=int(storage_id))
        else:
            raise AccessInvalidStorageID

        return self.queryset

    def get(self, request, *args, **kwargs):
        return super(StorageSidMimeConfigAPI, self).list(request, *args, **kwargs)

    @transaction.commit_manually
    def post(self, request, *args, **kwargs):
        try:
            storage_id = self.kwargs.get('storage_id', None)
            if storage_id is None or storage_id == '':
                raise Exception('Storage ID is required.')
            storage = Storage.objects.get(storage_id=storage_id)

            #parameter value validaion
            storage_config_validate(self.request)

            param_name = request.DATA.get("param_name")
            param_value = request.DATA.get('param_value')
            # param name duplicated check
            storage_configs = StorageMimeConfig.objects.filter(param_name=param_name, storage=int(storage_id))
            if storage_configs.exists():
                raise Exception('Same param name %s exists' % (param_name))

            storageconfig = StorageMimeConfig()
            storageconfig.storage_id = int(storage_id)
            storageconfig.param_name = param_name
            storageconfig.param_value = param_value
            storageconfig.save(request=request)

        except Storage.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Storage data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'MimeConfig Parameters Added.')}, status=HTTP_202_ACCEPTED)

class StorageSidMimeConfigDetailAPI(RetrieveModelMixin, 
                               DestroyModelMixin,
                               SpectrumGenericAPIView):
    queryset = StorageMimeConfig.objects.all()
    serializer_class = StorageSidMimeConfigSerializer
    lookup_url_kwarg = 'sid_mimeconfig_id'

    def get(self, request, *args, **kwargs):
        return super(StorageSidMimeConfigDetailAPI, self).retrieve(request, *args, **kwargs)

    @transaction.commit_manually
    def patch(self, request, *args, **kwargs):
        try:
            sid_mimeconfig_id = self.kwargs.get(self.lookup_url_kwarg, None)
            storage_id = self.kwargs.get('storage_id', None)
            if sid_mimeconfig_id is None or sid_mimeconfig_id == '':
                raise Exception('Storage MimeConfig ID is required.')
            if storage_id is None or storage_id == '':
                raise Exception('Storage ID is required.')
            storage = Storage.objects.get(storage_id=storage_id)

            #parameter value validaion
            storage_config_validate(self.request)

            param_name = request.DATA.get("param_name")
            param_value = request.DATA.get('param_value')

            # param name duplicated check
            storage_configs = StorageMimeConfig.objects.filter(param_name=param_name, storage=int(storage_id))\
                            .exclude(pk=int(sid_mimeconfig_id))
            if storage_configs.exists():
                raise Exception('Same param name %s exists' % (param_name))

            storageconfig = StorageMimeConfig.objects.get(pk=int(sid_mimeconfig_id))
            storageconfig.param_name = param_name
            storageconfig.param_value = param_value
            storageconfig.save(request=request)

        except Storage.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Storage data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except StorageMimeConfig.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Storage MimeConfig data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'MimeConfig Parameters Updated.')}, status=HTTP_202_ACCEPTED)

    def delete(self, request, *args, **kwargs):
        return super(StorageSidMimeConfigDetailAPI, self).destroy(request, *args, **kwargs)


class StroageSidIpbasedAclAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = StroageIpbasedAcl.objects.all()
    serializer_class = StroageSidIpbasedAclSerializer
    lookup_url_kwarg = 'acl_id'
    ordering = 'acl_order'

    def get_queryset(self):
        storage_id = self.kwargs.get("storage_id", None)
        if storage_id is not None and storage_id != '':
            self.queryset = self.queryset.filter(storage__pk=int(storage_id))
        else:
            raise AccessInvalidStorageID

        return self.queryset

    def get(self, request, *args, **kwargs):
        return super(StroageSidIpbasedAclAPI, self).list(request, *args, **kwargs)

    @transaction.commit_manually
    def post(self, request, *args, **kwargs):
        try:
            storage_id = self.kwargs.get('storage_id', None)
            if storage_id is None or storage_id == '':
                raise Exception('Storage ID is required.')
            storage = Storage.objects.get(storage_id=storage_id)

            #parameter value validaion
            storage_ipbased_acl_validate(self.request)

            policy = request.DATA.get("policy", None)
            protocol = request.DATA.get('protocol', None)
            permission = request.DATA.get('permission', None)
            ipaddr = request.DATA.get('ipaddr', None)
            subnet_mask = request.DATA.get('subnet_mask', None)

            policy_str = POLICIES[int(policy)][1]
            protocol_str = PROTOCOLS[int(protocol)][1]
            permission_str = PERMISSIONS[int(permission)][1]

            # duplicated check
            storageIpbasedAcls = StroageIpbasedAcl.all_objects.filter(ipaddr=ipaddr, subnet_mask=subnet_mask, 
                                                                      protocol=protocol_str, storage=storage_id, 
                                                                      permission=permission_str)
            if storageIpbasedAcls.exists():
                raise Exception('ipaddr %s, protocol %s exist.' % (ipaddr, protocol_str))

            from django.db.models import Max
            max_order = StroageIpbasedAcl.objects.all().aggregate(Max('acl_order'))['acl_order__max']
            ipacl = StroageIpbasedAcl()
            ipacl.policy = policy_str
            ipacl.protocol = protocol_str
            ipacl.permission = permission_str
            ipacl.ipaddr = ipaddr
            ipacl.subnet_mask = subnet_mask
            ipacl.storage_id = int(storage_id)
            try:
                ipacl.acl_order = int(max_order) + 1
            except:
                ipacl.acl_order = 1
            ipacl.save(request=request)

        except Storage.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Storage data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'Ipbased ACL Added.')}, status=HTTP_202_ACCEPTED)

class StroageSidIpbasedAclDetailAPI(RetrieveModelMixin, 
                               DestroyModelMixin,
                               SpectrumGenericAPIView):
    queryset = StroageIpbasedAcl.objects.all()
    serializer_class = StroageSidIpbasedAclSerializer
    lookup_url_kwarg = 'acl_id'

    def get(self, request, *args, **kwargs):
        return super(StroageSidIpbasedAclDetailAPI, self).retrieve(request, *args, **kwargs)

    @transaction.commit_manually
    def patch(self, request, *args, **kwargs):
        try:
            acl_id = self.kwargs.get(self.lookup_url_kwarg, None)
            storage_id = self.kwargs.get('storage_id', None)
            if acl_id is None or acl_id == '':
                raise Exception('ACL ID is required.')
            if storage_id is None or storage_id == '':
                raise Exception('Storage ID is required.')
            storage = Storage.objects.get(storage_id=storage_id)

            #parameter value validaion
            storage_ipbased_acl_validate(self.request)

            policy = request.DATA.get("policy", None)
            protocol = request.DATA.get('protocol', None)
            permission = request.DATA.get('permission', None)
            ipaddr = request.DATA.get('ipaddr', None)
            subnet_mask = request.DATA.get('subnet_mask', None)

            policy_str = POLICIES[int(policy)][1]
            protocol_str = PROTOCOLS[int(protocol)][1]
            permission_str = PERMISSIONS[int(permission)][1]

            # duplicated check
            storageIpbasedAcls = StroageIpbasedAcl.all_objects.filter(ipaddr=ipaddr, subnet_mask=subnet_mask, 
                                                                      protocol=protocol_str, storage=storage_id, 
                                                                      permission=permission_str) \
                                                              .exclude(pk=int(acl_id))
            if storageIpbasedAcls.exists():
                raise Exception('ipaddr %s, protocol %s exist.' % (ipaddr, protocol_str))

            ipacl = StroageIpbasedAcl.objects.get(pk=int(acl_id))
            ipacl.policy = policy_str
            ipacl.protocol = protocol_str
            ipacl.permission = permission_str
            ipacl.ipaddr = ipaddr
            ipacl.subnet_mask = subnet_mask
            ipacl.storage_id = int(storage_id)
            ipacl.save(request=request)

        except Storage.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Storage data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except StroageIpbasedAcl.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Storage Ipbased ACL data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'Ipbased ACL Updated.')}, status=HTTP_202_ACCEPTED)

    def delete(self, request, *args, **kwargs):
        return super(StroageSidIpbasedAclDetailAPI, self).destroy(request, *args, **kwargs)


class StorageIpbasedAclOrderAPI(SpectrumGenericAPIView):
    queryset = StroageIpbasedAcl.objects.all()
    serializer_class = StroageSidIpbasedAclSerializer
    lookup_url_kwarg = 'acl_id'

    @transaction.commit_manually
    def put(self, request, *args, **kwargs):
        ipacl = self.get_queryset()

        try:
            acl_id = self.kwargs.get(self.lookup_url_kwarg, None)
            storage_id = self.kwargs.get('storage_id', None)
            if acl_id is None or acl_id == '':
                raise Exception('ACL ID is required.')
            if storage_id is None or storage_id == '':
                raise Exception('Storage ID is required.')

            order_type = request.DATA.get("order_type", 'up')
            order_first = request.DATA.get('order_first', False)

            ipacl = StroageIpbasedAcl.objects.get(pk=int(acl_id))
            if ipacl:
                if order_type.lower() == 'up':
                    ipacls = StroageIpbasedAcl.objects.filter(
                        storage=storage_id,
                        acl_order__lt=int(ipacl.acl_order)).order_by('-acl_order')
                else:
                    ipacls = StroageIpbasedAcl.objects.filter(
                        storage=storage_id,
                        acl_order__gt=int(ipacl.acl_order)).order_by('acl_order')

                if ipacls and ipacls[0]:
                    if not order_first:
                        temp_order = ipacls[0].acl_order
                        tempacl = StroageIpbasedAcl.objects.get(pk=ipacls[0].pk)
                        tempacl.acl_order = ipacl.acl_order
                        tempacl.save(request=request)
                        ipacl.acl_order = temp_order
                        ipacl.save(request=request)
                    else:
                        temp_order = ipacl.acl_order
                        for acl in ipacls:
                            tempacl = StroageIpbasedAcl.objects.get(pk=acl.pk)
                            tempacl.acl_order = temp_order
                            temp_order = acl.acl_order
                            tempacl.save(request=request)
                        ipacl.acl_order = temp_order
                        ipacl.save(request=request)

        except StroageIpbasedAcl.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Storage Ipbased ACL data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'Ipbased ACL Order Updated.')}, status=HTTP_202_ACCEPTED)

class StorageCdnwUpdateAPI(SpectrumGenericAPIView):
    lookup_url_kwarg = __STORAGE_URL_LOOKUP_KEY__

    @transaction.commit_manually
    def put(self, request, *args, **kwargs):
        try:
            storage_id = self.kwargs.get(self.lookup_url_kwarg)
            if not storage_id:
                raise Exception('Storage ID Missing')

            storage = Storage.objects.get(storage_id=storage_id)
            if not storage.contract:
                raise Exception('Contract not selected.')

            item_id = getStatMasterItem(storage)
            cdnw_status = self.request.DATA.get('cdnw_status', '0')

            storage.cdnw_status = cdnw_status
            storage.save(request=request, contract_no=storage.contract.contract_no, item_id=item_id)

        except Storage.DoesNotExist:
            transaction.rollback()
            return Response({"detail": _(u"%s" % _(u'Storage data not found.'))}, status=HTTP_400_BAD_REQUEST)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response({'detail':_(u'Saved.'), "storage_id":storage.pk}, status=HTTP_202_ACCEPTED)


# Common Functions
def get_md5_password(password):
    return hashlib.md5(password).hexdigest()
def get_linux_crypt_password(password):
    return crypt(password, '$S')
def get_connection_character(chk):
    # chk = True, False
    if chk:
        return "-"
    else:
        return "."

def set_storage_cluster_vhosts(request, storage, cluster, item_id, preferred):
    try:
        storage_cluster = StorageCluster.all_objects.filter(storage=storage, cluster=cluster)
        # If you have made a Deleted data is changed to "obj_state = 1".
        if storage_cluster:  # update
            storage_cluster = StorageCluster.all_objects.get(storage=storage, cluster=cluster)
            storage_cluster.is_preferred_cluster = preferred
            storage_cluster.obj_state = 1
        else:  # insert cluster
            storage_cluster = StorageCluster()
            storage_cluster.storage = storage
            storage_cluster.cluster = cluster
            storage_cluster.is_preferred_cluster = preferred
            storage_cluster.backup_order = storage_cluster.getMaxBackupOrder()

        master_writer_vips = []
        backup_domain = None
        backup_upload_domain = None
        backup_https_domain = None
        backup_https_upload_domain = None

        if storage.data_domain:
            backup_domain_name = 'backup' + str(storage_cluster.backup_order) + '.' + storage.data_domain.name
            backup_domain = set_backup_gslb_domain(request, backup_domain_name, storage.customer)
        if storage.upload_domain:
            backup_upload_domain_name = 'backup' + str(storage_cluster.backup_order) + '.' + storage.upload_domain.name
            backup_upload_domain = set_backup_gslb_domain(request, backup_upload_domain_name, storage.customer)
        if storage.https_origin_domain:
            backup_https_domain_name = 'backup' + str(storage_cluster.backup_order) + '-' + storage.https_origin_domain.name
            backup_https_domain = set_backup_gslb_domain(request, backup_https_domain_name, storage.customer)
        if storage.https_upload_domain:
            backup_https_upload_domain_name = 'backup' + str(storage_cluster.backup_order) + '-' + storage.https_upload_domain.name
            backup_https_upload_domain = set_backup_gslb_domain(request, backup_https_upload_domain_name, storage.customer)

        storagenodes = StorageNode.objects.filter(cluster=cluster)
        for storagenode in storagenodes:
            # vip = Vip.objects.filter(ihms_vip=storagenode.ip_id)
            # set_gslbdomain_vip(request,backup_domain,vip)
            vips = get_vips_by_ipid(storagenode.ip_id)
            if vips.exists():  # all ==> data , backup
                if storagenode.node_type == 0 or storagenode.node_type == 1:  # writer,reader
                    if storagenode.node_type == 0:
                        master_writer_vips.append(vips[0])
                        if storage.upload_domain:
                            set_gslbdomain_vip(request, storage.upload_domain, vips)
                            set_gslbdomain_vip(request, backup_upload_domain, vips)
                        if storage.https_upload_domain:
                            set_gslbdomain_vip(request, storage.https_upload_domain, vips)
                            set_gslbdomain_vip(request, backup_https_upload_domain, vips)

                    if storage.data_domain:
                        set_gslbdomain_vip(request, storage.data_domain, vips)
                        set_gslbdomain_vip(request, backup_domain, vips)
                    if storage.https_origin_domain:
                        set_gslbdomain_vip(request, storage.https_origin_domain, vips)
                        set_gslbdomain_vip(request, backup_https_domain, vips)

        if backup_domain:
            storage_cluster.backup_domain = backup_domain
        if backup_upload_domain:
            storage_cluster.backup_upload_domain = backup_upload_domain
        if backup_https_domain:
            storage_cluster.backup_https_domain = backup_https_domain
        if backup_https_upload_domain:
            storage_cluster.backup_https_upload_domain = backup_https_upload_domain

        if preferred and preferred == '1':
            storageclusters = StorageCluster.objects.filter(storage=storage).exclude(cluster=cluster)
            if storageclusters.exists():
                storageclusters.update(is_preferred_cluster=0)

            if storage.upload_domain:
                set_gslbdomain_vips_priority(request, storage.upload_domain, master_writer_vips, 1)
                set_gslbdomain_vips_priority_others(request, storage.upload_domain, master_writer_vips, 2)
            if storage.https_upload_domain:
                set_gslbdomain_vips_priority(request, storage.https_upload_domain, master_writer_vips, 1)
                set_gslbdomain_vips_priority_others(request, storage.https_upload_domain, master_writer_vips, 2)
        else:
            storageclusters = StorageCluster.objects.filter(storage=storage, is_preferred_cluster=1).exclude(cluster=cluster)
            if storageclusters.exists():
                if storage.upload_domain:
                    set_gslbdomain_vips_priority(request, storage.upload_domain, master_writer_vips, 2)
                if storage.https_upload_domain:
                    set_gslbdomain_vips_priority(request, storage.https_upload_domain, master_writer_vips, 2)
            else:
                if storage.upload_domain:
                    set_gslbdomain_vips_priority(request, storage.upload_domain, master_writer_vips, 1)
                    set_gslbdomain_vips_priority_others(request, storage.upload_domain, master_writer_vips, 1)
                if storage.https_upload_domain:
                    set_gslbdomain_vips_priority(request, storage.https_upload_domain, master_writer_vips, 1)
                    set_gslbdomain_vips_priority_others(request, storage.https_upload_domain, master_writer_vips, 1)

        storage_cluster.save(request=request)

        # Vhosts Cluster Created
        storage_sid_vhosts = StorageSidVhosts.all_objects.filter(storage=storage)
        for storage_sid_vhost in storage_sid_vhosts:
            storage_cluster_vhosts = StorageClusterVhosts.all_objects.filter(vhosts=storage_sid_vhost, sid_cluster=storage_cluster)
            if storage_cluster_vhosts.exists():  # update
                storage_cluster_vhosts = StorageClusterVhosts.all_objects.get(vhosts=storage_sid_vhost, sid_cluster=storage_cluster)
                storage_cluster_vhosts.obj_state = 1
            else:  # insert vhosts cluster
                storage_cluster_vhosts = StorageClusterVhosts()
                storage_cluster_vhosts.vhosts = storage_sid_vhost
                storage_cluster_vhosts.sid_cluster = storage_cluster

            vhosts_backup_domain = None
            vhosts_backup_https_domain = None
            if storage_sid_vhost.gslb_service_domain:
                vhosts_backup_domain_name = 'backup' + str(storage_cluster.backup_order) + '.' + storage_sid_vhost.gslb_service_domain.name
                vhosts_backup_domain = set_backup_gslb_domain(request, vhosts_backup_domain_name, storage.customer)
            if storage_sid_vhost.https_service_domain:
                vhosts_backup_https_domain_name = 'backup' + str(storage_cluster.backup_order) + '-' + storage_sid_vhost.https_service_domain.name
                vhosts_backup_https_domain = set_backup_gslb_domain(request, vhosts_backup_https_domain_name, storage.customer)

            storagenodes = StorageNode.objects.filter(cluster=cluster)
            for storagenode in storagenodes:
                vips = get_vips_by_ipid(storagenode.ip_id)
                if vips.exists():  # all ==> data , backup
                    if storagenode.node_type == 0 or storagenode.node_type == 1:  # writer,reader
                        if vhosts_backup_domain:
                            set_gslbdomain_vip(request, storage_sid_vhost.gslb_service_domain, vips)
                            set_gslbdomain_vip(request, vhosts_backup_domain, vips)
                        if vhosts_backup_https_domain:
                            set_gslbdomain_vip(request, storage_sid_vhost.https_service_domain, vips)
                            set_gslbdomain_vip(request, vhosts_backup_https_domain, vips)

            if vhosts_backup_domain:
                storage_cluster_vhosts.backup_domain = vhosts_backup_domain
            if vhosts_backup_https_domain:
                storage_cluster_vhosts.backup_https_domain = vhosts_backup_https_domain

            storage_cluster_vhosts.save(request=request)

        if storage_cluster.storage.clusters.count() > 0:  # enable config state
            storage_cluster.storage.save(request=request, contract_no=storage.contract.contract_no, item_id=item_id)

    except Exception, e:
        raise Exception('%s' %e)

def getStatMasterItem(storage):
    stat_master = None

    try:
        stat_master = StatMaster.objects.get(Q(material_no=settings.CLOUD_STORAGE_MATERIAL), 
                                             Q(keyword=storage.storage_name), 
                                             Q(display_name=storage.storage_name),
                                             Q(service_remove_flag__isnull=True) | ~Q(service_remove_flag=1))
    except:
        raise Exception('Contract has not been set yet.')

    return stat_master.item_id

def set_user_gslb_domain(request, storage, service_domain_name, customer, domain_type):
    keynames = service_domain_name.split('.')
    if len(keynames) > 1:
        domain_name = service_domain_name
    else:
        raise Exception(_(u'invalid %s name' %(domain_type)))

    gslbdomains = Domain.objects.filter(name=domain_name)
    return set_gslb_domain(request, domain_name, customer, gslbdomains)

def set_backup_gslb_domain(request, backup_domain_name, customer):
    gslbdomains = Domain.objects.filter(name=backup_domain_name)
    return set_gslb_domain(request, backup_domain_name, customer, gslbdomains)

def set_gslb_domain(request, domain_name, customer, gslbdomains):
    # gslbdomains = Domain.objects.filter(name = domain_name)
    if gslbdomains.exists():
        gslbdomain = gslbdomains[0]
        probeconfig = BaseProbeConfig.objects.get(name='starfs')
        gslbdomain.probe = probeconfig
        gslbdomain.update_domain_config_status(request)
        pass  # already exists
    else:
        gslbdomain = Domain()
        gslbdomain.name = domain_name  # unique check
        gslbdomain.customer = customer
        gslbdomain.cutoff = 0
        gslbdomain.domain_type = GSLB_DOMAIN
        probeconfig = BaseProbeConfig.objects.get(name='starfs')
        gslbdomain.probe = probeconfig
        gslbdomain.update_domain_config_status(request)

    gslbdomain = Domain.objects.get(name=domain_name)
    return gslbdomain

def set_gslbdomain_vip(request, domain, vip):
    domainvips = DomainVip.objects.filter(domain=domain, vip=vip)
    if domainvips.exists():
        pass
    else:
        if vip:
            domainvip = DomainVip(domain=domain, vip=vip[0])
            # domainvip.weight = 0
            domainvip.save(request=request)
            domain.update_domain_config_status(request)

def set_gslbdomain_vips_priority(request, domain, vips, priority):
    domainvips = DomainVip.objects.filter(domain=domain, vip__in=vips)
    if domainvips.exists():
        for domainvip in domainvips:
            domainvip.priority = priority
            domainvip.save(request=request)

def set_gslbdomain_vips_priority_others(request, domain, vips, priority):
    domainvips = DomainVip.objects.filter(domain=domain).exclude(vip__in=vips)
    if domainvips.exists():
        for domainvip in domainvips:
            domainvip.priority = priority
            domainvip.save(request=request)

def set_cluster_vip(request, storage, data_domain, upload_domain=None):  # , master_domain
    storageclusters = StorageCluster.objects.filter(storage=storage)
    for storagecluster in storageclusters:
        storagenodes = StorageNode.objects.filter(cluster=storagecluster.cluster)
        for storagenode in storagenodes:
            vips = get_vips_by_ipid(storagenode.ip_id)
            if vips:  # all ==> data , backup
                if storagenode.node_type == 0 or storagenode.node_type == 1:  # writer,reader
                    set_gslbdomain_vip(request, data_domain, vips)
                if storagenode.node_type == 0:  # writer  ==> upload, master
                    if upload_domain:
                        set_gslbdomain_vip(request, upload_domain, vips)

def delete_gslbdomain_vip(request, domain):
    try:
        if domain:
            domain.delete_all_related(request)
    except Exception, e:
        log_error(request, str(e), e)

def delete_gslbdomain_vips_notin(request, domain, vips):
    domainvips = DomainVip.objects.filter(domain=domain).exclude(vip__in=vips)
    try:
        if domainvips.exists():
            for domainvip in domainvips:
                domainvip.delete(request=request)
    except Exception, e:
        log_error(request, str(e), e)

def delete_gslbdomain_vips_now(request, domain, vips):
    domainvips = DomainVip.objects.filter(domain=domain, vip__in=vips)
    try:
        if domainvips.exists():
            for domainvip in domainvips:
                domainvip.delete(request=request)
    except Exception, e:
        log_error(request, str(e), e)

def insert_default_storage_user(request, storage):
    try:
        storage_user = StorageUser()
        storage_user.storage = storage
        storage_user.user_name = storage.storage_name
        storage_user.enc_type = 0
        storage_user.password = hashlib.md5('password').hexdigest()  # default 1234
        storage_user.access_path = ''
        storage_user.save(request=request)
        return storage_user
    except Exception, e:
        log_error(request, str(e), e)
        return None

def reorder_storage_clusters(request, storage, storage_cluster_id):
    storageclusters = StorageCluster.objects.filter(storage=storage).exclude(idx=storage_cluster_id)

    if storageclusters:
        backup_order = 0
        for storagecluster in storageclusters:
            storagecluster.backup_order = backup_order + 1
            try:
                backup_domain_name = ''
                backup_upload_domain_name = ''
                backup_https_domain_name = ''
                backup_https_upload_domain_name = ''

                if storage.data_domain and storage.data_domain != '':
                    backup_domain_name = 'backup' + str(storagecluster.backup_order) + '.' + storage.data_domain.name
                if storage.upload_domain and storage.upload_domain != '':
                    backup_upload_domain_name = 'backup' + str(storagecluster.backup_order) + '.' + storage.upload_domain.name
                if storage.https_origin_domain and storage.https_origin_domain != '':
                    backup_https_domain_name = 'backup' + str(storagecluster.backup_order) + '-' + storage.https_origin_domain.name
                if storage.https_upload_domain and storage.https_upload_domain != '':
                    backup_https_upload_domain_name = 'backup' + str(storagecluster.backup_order) + '-' + storage.https_upload_domain.name

                if storagecluster.backup_domain or storagecluster.backup_https_domain:
                    if (storagecluster.backup_domain and storagecluster.backup_domain.name == backup_domain_name) \
                        or (storagecluster.backup_https_domain and storagecluster.backup_https_domain.name == backup_https_domain_name):
                        backup_order = backup_order + 1
                        continue
                    else:
                        is_exists_domain = Domain.objects.filter(name=backup_domain_name)
                        is_exists_https_domain = Domain.objects.filter(name=backup_https_domain_name)

                        if is_exists_domain.exists() or is_exists_https_domain.exists():
                            if backup_domain_name != '':
                                backup_domain = set_backup_gslb_domain(request, backup_domain_name, storage.customer)
                                storagecluster.backup_domain = backup_domain
                            if backup_upload_domain_name != '':
                                backup_upload_domain = set_backup_gslb_domain(request, backup_upload_domain_name, storage.customer)
                                storagecluster.backup_upload_domain = backup_upload_domain
                            if backup_https_domain_name != '':
                                backup_https_domain = set_backup_gslb_domain(request, backup_https_domain_name, storage.customer)
                                storagecluster.backup_https_domain = backup_https_domain
                            if backup_https_upload_domain_name != '':
                                backup_https_upload_domain = set_backup_gslb_domain(request, backup_https_upload_domain_name, storage.customer)
                                storagecluster.backup_https_upload_domain = backup_https_upload_domain
                        else:
                            if backup_domain_name != '':
                                storagecluster.backup_domain.name = backup_domain_name
                                storagecluster.backup_domain.save(request=request)
                            if backup_upload_domain_name != '':
                                storagecluster.backup_upload_domain.name = backup_upload_domain_name
                                storagecluster.backup_upload_domain.save(request=request)
                            if backup_https_domain_name != '':
                                storagecluster.backup_https_domain.name = backup_https_domain_name
                                storagecluster.backup_https_domain.save(request=request)
                            if backup_https_upload_domain_name != '':
                                storagecluster.backup_https_upload_domain.name = backup_https_upload_domain_name
                                storagecluster.backup_https_upload_domain.save(request=request)
                else:
                    if backup_domain_name != '':
                        backup_domain = set_backup_gslb_domain(request, backup_domain_name, storage.customer)
                        storagecluster.backup_domain = backup_domain
                    if backup_upload_domain_name != '':
                        backup_upload_domain = set_backup_gslb_domain(request, backup_upload_domain_name, storage.customer)
                        storagecluster.backup_upload_domain = backup_upload_domain
                    if backup_https_domain_name != '':
                        backup_https_domain = set_backup_gslb_domain(request, backup_https_domain_name, storage.customer)
                        storagecluster.backup_https_domain = backup_https_domain
                    if backup_https_upload_domain_name != '':
                        backup_https_upload_domain = set_backup_gslb_domain(request, backup_https_upload_domain_name, storage.customer)
                        storagecluster.backup_https_upload_domain = backup_https_upload_domain

                storagecluster.save(request=request)
            except:  # storage.data_domain throws does not exist if not exists
                backup_https_domain_name = 'origin-' + storage.storage_name + '.sf.cdngp.net'
                backup_https_domain = set_backup_gslb_domain(request, backup_https_domain_name, storage.customer)
                storagecluster.backup_https_domain = backup_https_domain
                storagecluster.save(request=request)

            backup_order = backup_order + 1


def reorder_vhosts_clusters(request, storage, storage_cluster_id):
    storagesidvhosts = StorageSidVhosts.all_objects.filter(storage=storage)

    if storagesidvhosts.exists():
        for storagesidvhost in storagesidvhosts:
            vhostsclusters = StorageClusterVhosts.objects.filter(vhosts=storagesidvhost).exclude(sid_cluster__idx=storage_cluster_id)
            if vhostsclusters.exists():
                backup_order = 0
                for vhostscluster in vhostsclusters:
                    str_backup_order = str(backup_order + 1)
                    try:
                        backup_vhosts_name = ''
                        backup_https_vhosts_name = ''
                        if storagesidvhost.gslb_service_domain and storagesidvhost.gslb_service_domain != '':
                            backup_vhosts_name = 'backup' + str_backup_order + '.' + storagesidvhost.gslb_service_domain.name
                        if storagesidvhost.https_service_domain and storagesidvhost.https_service_domain != '':
                            backup_https_vhosts_name = 'backup' + str_backup_order + '-' + storagesidvhost.https_service_domain.name

                        if vhostscluster.backup_domain or vhostscluster.backup_https_domain:
                            if (vhostscluster.backup_domain and vhostscluster.backup_domain.name == backup_vhosts_name) \
                               or (vhostscluster.backup_https_domain and vhostscluster.backup_https_domain.name == backup_https_vhosts_name):
                                backup_order = backup_order + 1
                                continue
                            else:
                                is_exists_vhosts = Domain.objects.filter(name=str(backup_vhosts_name))
                                is_exists_https_vhosts = Domain.objects.filter(name=str(backup_https_vhosts_name))

                                if is_exists_vhosts.exists() or is_exists_https_vhosts.exists():
                                    if backup_vhosts_name != '':
                                        backup_domain = set_backup_gslb_domain(request, backup_vhosts_name, storage.customer)
                                        vhostscluster.backup_domain = backup_domain
                                    if backup_https_vhosts_name != '':
                                        backup_https_domain = set_backup_gslb_domain(request, backup_https_vhosts_name, storage.customer)
                                        vhostscluster.backup_https_domain = backup_https_domain
                                else:
                                    if backup_vhosts_name != '':
                                        vhostscluster.backup_domain.name = backup_vhosts_name
                                        vhostscluster.backup_domain.save(request=request)
                                    if backup_https_vhosts_name != '':
                                        vhostscluster.backup_https_domain.name = backup_https_vhosts_name
                                        vhostscluster.backup_https_domain.save(request=request)
                        else:
                            if backup_vhosts_name != '':
                                backup_domain = set_backup_gslb_domain(request, backup_vhosts_name, storage.customer)
                                vhostscluster.backup_domain = backup_domain
                            if backup_https_vhosts_name != '':
                                backup_https_domain = set_backup_gslb_domain(request, backup_https_vhosts_name, storage.customer)
                                vhostscluster.backup_https_domain = backup_https_domain

                        vhostscluster.save(request=request)
                    except:
                        # storage_sid_vhosts.gslb_service_domain and storage_sid_vhosts.https_service_domain throws does not exist if not exists
                        backup_vhosts_name = 'origin-' + storagesidvhost.service_domain + '.sf.cdngp.net'
                        backup_https_domain = set_backup_gslb_domain(request, backup_vhosts_name, storage.customer)
                        vhostscluster.backup_https_domain = backup_https_domain
                        vhostscluster.save(request=request)

                    backup_order = backup_order + 1
