# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Rest API
"""
from datetime import datetime, timedelta
from django.utils.translation import ugettext as _
from django.db import connections
from rest_framework.status import HTTP_400_BAD_REQUEST
from rest_framework.exceptions import APIException
from rest_framework.response import Response

from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.mixins import ListModelMixin, RetrieveModelMixin

from spectrum_api.cloudstorage.models.cloudstorage import Cluster, Storage, \
    StorageCluster, StorageNode, StorageOriginTraffic, StorageSidWaitQueue, StorageSyncFail
from spectrum_api.cloudstorage.serializers.cloudstorage import ClusterAllSerializer, ClusterSerializer, \
    ClusterNodeSerializer, StorageOriginTrafficSerializer, StorageWaitQueueSerializer, \
    StorageClusterSerializer, StorageSyncFailSerializer, ClusterNodeDetailSerializer

__STORAGE_CLUSTER_URL_LOOKUP_KEY__ = "cluster_id"
__STORAGE_NODE_URL_LOOKUP_KEY__ = "node_id"
__STORAGE_URL_LOOKUP_KEY__ = "storage_id"

class AccessInvalidClusterID(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = 'Cluster ID Missing'

class AccessInvalidNodeID(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = 'Node ID Missing'

class AccessInvalidStorageID(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = 'Storage ID Missing'

class AccessInvalidID(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = 'Storage or Cluster ID Missing'

class AccessInvalidDate(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = _(u'Start_date or End_date value Missing')


def get_cluster_usage_capacity(cluster_list):
    cluster_info = {}

    if len(cluster_list) <= 0:
        return cluster_info

    sql = """
            select
                sc.cluster_id,
                ifnull(round(sum(sd.`usage`)/(1024*1024*1024), 2), 0) as `usage`,
                ifnull(round(sum(sd.capacity)/(1024*1024*1024), 2), 0) as capacity
            from
                storage_cluster sc
                left join storage_node sn on sc.cluster_id = sn.cluster_id
                left join (
                select idx, node_id, sum(used_blocks*block_size) as `usage`, sum(total_blocks*block_size) as capacity
                    from storage_disk
                    where disk_type = 1
                    group by disk_type, idx
                ) sd on sn.node_id = sd.node_id
            where sc.cluster_id in (%s) and sc.obj_state = 1 and sn.node_type = 2
            group by sc.cluster_id
            """
    format_strings = ','.join(map(lambda x: '%s', cluster_list))
    sql = sql % (format_strings)
    params = []
    params.extend(cluster_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, tuple(params))
    obj = cursor.fetchone()

    try:
        while obj is not None:
            cluster_info[obj[0]] = {"cluster_id":obj[0],
                                "usage":obj[1],
                                "capacity":obj[2]
                                }
            obj = cursor.fetchone()
    finally:
        cursor.close()
        connections['default'].close()

    return cluster_info

def get_cluster_sync_fail(cluster_list):
    cluster_info = {}

    if len(cluster_list) <= 0:
        return cluster_info

    start_date_1 = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")
    start_date_2 = (datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d %H:%M:%S")

    sql = """
            select
                sc.cluster_id,
                ifnull(ssf.sync_fail_1day,0) as sync_fail_1day,
                ifnull(ssf.sync_fail_2day,0) as sync_fail_2day,
                ifnull(ssf.sync_fail_3day,0) as sync_fail_3day
            from
                storage_cluster sc
                left join
                    (select cluster_id,
                        count(if(failed_time >= %s, cluster_id, null)) as sync_fail_1day,
                        count(if(failed_time >= %s, cluster_id, null)) as sync_fail_2day,
                        count(cluster_id) as sync_fail_3day
                    from storage_sync_fail
                    group by cluster_id
                    ) ssf on sc.cluster_id = ssf.cluster_id
            where sc.cluster_id in (%s) and sc.obj_state = 1
        """
    format_strings = ','.join(map(lambda x: '%s', cluster_list))
    sql = sql % ('%s', '%s', format_strings)
    params = []
    params.append(start_date_1)
    params.append(start_date_2)
    params.extend(cluster_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, tuple(params))
    obj = cursor.fetchone()
    try:
        while obj is not None:
            cluster_info[obj[0]] = {"cluster_id":obj[0],
                                "sync_fail_1day":obj[1],
                                "sync_fail_2day":obj[2],
                                "sync_fail_3day":obj[3]
                                }
            obj = cursor.fetchone()
    finally:
        cursor.close()
        connections['default'].close()

    return cluster_info

def get_cluster_wait_queues(cluster_list):
    cluster_info = {}

    if len(cluster_list) <= 0:
        return cluster_info

    sql = """
            select
                sc.cluster_id,
                if(isnull(sswq.wait_queues),0,sswq.wait_queues) as wait_queues
            from
                storage_cluster sc
                left join
                    (select cluster_id, sum(wait_queue_count) as wait_queues
                        from stat.storage_snapshot_sid_wait_queue
                        group by cluster_id) sswq on sc.cluster_id = sswq.cluster_id
            where sc.cluster_id in (%s) and sc.obj_state = 1
        """
    format_strings = ','.join(map(lambda x: '%s', cluster_list))
    sql = sql % (format_strings)
    params = []
    params.extend(cluster_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, tuple(params))
    obj = cursor.fetchone()

    try:
        while obj is not None:
            cluster_info[obj[0]] = {"cluster_id":obj[0],
                                "wait_queues":obj[1]
                                }
            obj = cursor.fetchone()
    finally:
        cursor.close()
        connections['default'].close()

    return cluster_info

def get_all_cluster_status(cluster_list):
    cluster_info = {}

    if len(cluster_list) <= 0:
        return cluster_info

    sql = """
            /*
            *  Cluster status

            *  If there is no node in the cluster : Unknown
            *  Reader&Writer node base status all enable + Reader&Writer Mount Status all OK(Null) : Online
            *  Writer node base status enable count > 0 + Mount Status(Enable the Base Status for the Node OK) : Repairing
            *  Mount Status(Enable the Base Status for the Node Fail) : Emergence (Case 2)
            *  Writer Node Base Status all disable : Emergence (Case 1)
            *  ETC : Unknown
            */
            select
                fin.cluster_id,
                if(fin.all_node=0, 'Unknown',
                    if(fin.writer_node=fin.writer_gslb
                        and fin.reader_node=fin.reader_gslb
                        and fin.mount_status_ok=fin.all_node, 'Online',
                            if(fin.writer_gslb>0 and fin.gslb_mount_status_ok>0, 'Repairing',
                                if(fin.gslb_mount_status_fail>0, 'Emergence (Case 2)',
                                    if(fin.writer_gslb=0, 'Emergence (Case 1)', 'Unknown'))))) as cluster_status
            from (
                /*
                *  "fin"
                *  To determine a cluster status value,
                *  It obtains the required value, as follows.

                *  writer_node : node_type=0(wirtier node) count
                *  reader_node : node_type=1(reader node) count
                *  all_node : node_type=0,1 node count
                *  writer_gslb : node_type=0(writer node) and enable_gslb=1 count
                *  reader_gslb : node_type=1(reader node) and enable_glsb=1 count
                *  gslb_mount_status_ok : enable_gslb=1 and mount_statue=1(null) count
                *  gslb_mount_status_fail : enable_gslb=1 and mount_status=0 count
                *  mount_status_ok : mount_status=1(null) count
                */
                select
                    sid.cluster_id,
                    sum(if(sid.node_type=0,1,0)) as writer_node,                         -- node_type=0(wirter_node) all count
                    sum(if(sid.node_type=1,1,0)) as reader_node,                         -- node_type=1)reader_node) all count
                    count(sid.node_id) as all_node,                                      -- cluster all node count
                    sum(if(sid.enable_gslb=1 and sid.node_type=0,1,0)) as writer_gslb,
                    sum(if(sid.enable_gslb=1 and sid.node_type=1,1,0)) as reader_gslb,
                    sum(if(sid.enable_gslb=1 and (isnull(sid.mount_status) or sid.mount_status=1),1,0)) as gslb_mount_status_ok,
                    sum(if(sid.enable_gslb=1 and sid.mount_status=0,1,0)) as gslb_mount_status_fail,
                    sum(if(isnull(sid.mount_status),1,if(sid.mount_status=1,1,0))) as mount_status_ok
                from (
                    /*
                    *  "sid"
                    *  Based on the 'storage_cluster' table,
                    *  it makes a call to join the value in the 'a' and 'b'.
                    */
                    select
                        b.cluster_id, b.vip_id, b.ihms_vip_id, b.vip_addr, b.enable_gslb,
                        a.node_id, b.node_type, a.mount_status
                    from
                        /*
                        *  "a"
                        *  Get the most up-to-date 'mount_status' value from the 'storage_snapshot_node_status' table.
                        */
                        (select sn.node_id, if(isnull(sns.mount_status), null, sns.mount_status) as mount_status
                            from storage_node sn
                                left join (
                                    select *
                                    from (
                                        select
                                            node_id, max(start_time) as start_time
                                        from storage_snapshot_node_status
                                        group by node_id
                                    ) as x join storage_snapshot_node_status using (node_id, start_time)
                                ) sns on sns.node_id = sn.node_id
                            where sn.node_type in (0,1)
                        ) as a

                        inner join

                        /*
                        *  "b"
                        *  Get the 'enable_gslb' value from the 'base_vip' table.
                        */
                        (select
                            sc.cluster_id,
                            sn.node_id, sn.node_type,
                            bv.vip_id, bv.ihms_vip_id, bv.vip_addr, bv.enable_gslb
                        from storage_node sn
                            inner join base_vip bv on (sn.ip_id = INET_ATON(bv.vip_addr) or sn.ip_id = bv.ihms_vip_id)
                            left join storage_cluster sc on sn.cluster_id = sc.cluster_id
                        where sc.cluster_id in (%s)
                        ) as b on a.node_id = b.node_id
                    order by b.cluster_id, b.node_type
                ) sid
                group by sid.cluster_id
            ) fin
            """
    format_strings = ','.join(map(lambda x: '%s', cluster_list))
    sql = sql % (format_strings)
    params = []
    params.extend(cluster_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, tuple(params))
    obj = cursor.fetchone()

    try:
        while obj is not None:
            cluster_info[obj[0]] = {"cluster_id":obj[0],
                                "cluster_status":obj[1]
                                }
            obj = cursor.fetchone()
    finally:
        cursor.close()
        connections['default'].close()

    return cluster_info

def get_config_replication(storage_list):
    storage_info = {}

    if len(storage_list) <= 0:
        return storage_info

    sql = """
            select ss.storage_id,
                    if(sc.param_value = 'YES', 'YES', 'NO') as replication
            from
                storage_storage ss
                left join storage_sid_config sc on ss.storage_id = sc.storage_id and sc.param_name = 'ReplicateData'
            where ss.storage_id in (%s)
            """
    format_strings = ','.join(map(lambda x: '%s', storage_list))
    sql = sql % (format_strings)
    params = []
    params.extend(storage_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, tuple(params))
    obj = cursor.fetchone()

    try:
        while obj is not None:
            storage_info[obj[0]] = {"storage_id":obj[0],
                                "replication":obj[1]
                                }
            obj = cursor.fetchone()
    finally:
        cursor.close()
        connections['default'].close()

    return storage_info

def get_storage_redundancy(storage_list):
    storage_info = {}

    if len(storage_list) <= 0:
        return storage_info

    sql = """
            select
                ss.storage_id,
                if(isnull(sm.stat_id),
                    if(cd.contract_count > 1, 'NO',
                        if(right(cd.sales_charge,1)='P', 'Premium', 'Standard')),
                    if(right(sm.sales_charge,1)='P', 'Premium', 'Standard')) as redundancy
            from
                storage_storage ss
                left join (
                    select sm_a.stat_id, sm_a.keyword, sm_a.display_name,
                        ci_a.item_id, ci_a.item_no, ci_a.sales_charge
                    from stat_master sm_a
                        left join customer_item ci_a on sm_a.item_id = ci_a.item_id
                    where sm_a.material_no = 1202
                ) sm on (ss.storage_name = sm.keyword and ss.storage_name = sm.display_name)
                left join (
                    select cd_b.customer_id, cc_b.contract_no,
                        ci_b.item_id, ci_b.item_no, ci_b.sales_charge,
                        count(cc_b.contract_no) as contract_count
                    from customer_display cd_b
                        left join customer_contract cc_b on cd_b.account_no = cc_b.account_no and cd_b.tz_offset = cc_b.tz_offset
                        left join customer_item ci_b on cc_b.contract_no = ci_b.contract_no
                    where cd_b.obj_state = 1 and ci_b.material_no = 1202
                    group by cc_b.contract_no
                ) cd on if(isnull(ss.contract_no), ss.contract_no = cd.contract_no, ss.customer_id = cd.customer_id)
            where ss.storage_id in (%s) and ss.obj_state = 1
            group by ss.storage_name
            """
    format_strings = ','.join(map(lambda x: '%s', storage_list))
    sql = sql % (format_strings)
    params = []
    params.extend(storage_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, tuple(params))
    obj = cursor.fetchone()

    try:
        while obj is not None:
            storage_info[obj[0]] = {"storage_id":obj[0],
                                "redundancy":obj[1]
                                }
            obj = cursor.fetchone()
    finally:
        cursor.close()
        connections['default'].close()

    return storage_info

def get_storage_sync_fail(storage_list, cluster_id):
    storage_info = {}

    if len(storage_list) <= 0:
        return storage_info

    if cluster_id is not None:
        try:
            int(cluster_id)
        except ValueError:
            raise Exception(_(u'invalid cluster_id input format'))
    else:
        return storage_info

    start_date_1 = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")
    start_date_2 = (datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d %H:%M:%S")

    sql = """
            select
                ss.storage_id,
                (select IFNULL(sum(b.wait_queue_count), 0)
                    from storage_cluster_storage a
                        left join stat.storage_snapshot_sid_wait_queue b on a.idx = b.cluster_storage_id
                     where a.storage_id = ss.storage_id and b.cluster_id = %s) as wait_queues,
                count(if(ssf.failed_time >= %s, ssf.cluster_id, null)) as sync_fail_1day,
                count(if(ssf.failed_time >= %s, ssf.cluster_id, null)) as sync_fail_2day,
                count(ssf.cluster_id) as sync_fail_3day
            from
                storage_storage ss
                left join storage_cluster_storage scs on ss.storage_id = scs.storage_id
                left join storage_sync_fail ssf on scs.idx = ssf.cluster_storage_id
            where scs.cluster_id = %s and ss.storage_id in (%s)
            group by ss.storage_id
            """
    format_strings = ','.join(map(lambda x: '%s', storage_list))
    sql = sql % ('%s', '%s', '%s', '%s', format_strings)
    params = []
    params.append(cluster_id)
    params.append(start_date_1)
    params.append(start_date_2)
    params.append(cluster_id)
    params.extend(storage_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, tuple(params))
    obj = cursor.fetchone()

    try:
        while obj is not None:
            storage_info[obj[0]] = {"storage_id":obj[0],
                                "wait_queues":obj[1],
                                "sync_fail_1day":obj[2],
                                "sync_fail_2day":obj[3],
                                "sync_fail_3day":obj[4]
                                }
            obj = cursor.fetchone()
    finally:
        cursor.close()
        connections['default'].close()

    return storage_info

def get_simple_storage_list(cluster_id):
    storage_info = []

    if cluster_id is not None:
        try:
            int(cluster_id)
        except ValueError:
            raise Exception(_(u'invalid cluster_id input format'))
    else:
        return storage_info

    sql = """
            select
                ss.storage_id, ss.storage_name,
                sc.cluster_id
            from
                storage_sync_fail syf
                left join storage_cluster_storage scs on scs.idx = syf.cluster_storage_id
                left join storage_storage ss on scs.storage_id = ss.storage_id
                left join storage_cluster sc on syf.cluster_id = sc.cluster_id
            where sc.cluster_id = %s and ss.obj_state = 1
            group by ss.storage_id
            """
    cursor = connections['default'].cursor()
    cursor.execute(sql, [cluster_id])
    obj = cursor.fetchone()

    try:
        while obj is not None:
            storage_info.append({
                                    "storage":obj[0],
                                    "storage_name":obj[1],
                                    "cluster_id":obj[2]
                                    })
            obj = cursor.fetchone()
    finally:
        cursor.close()
        connections['default'].close()

    return storage_info

def get_storage_node_list(cluster_list):
    node_info = {}

    if len(cluster_list) <= 0:
        return node_info

    sql = """
            select
                sc.cluster_id,
                sn.node_id, sn.node_type, sn.node_type_name, sn.ip_id,
                INET_NTOA(sn.ip_id) as ip,
                vs.full_host_name as hostname,
                if(v.enable_gslb = 1, 'Up', 'Down') as base_status,
                if(isnull(sns.mount_status), '',
                    if(sn.node_type <> 2, if(sns.mount_status = 0, 'FAIL', 'OK'), '')) as mount_status,
                if(sn.node_type = 0 or sn.node_type = 1,
                     if((
                         select count(*)
                         from
                             base_vip a
                            left join base_vip_probe b on a.vip_id = b.vip_id
                            left join base_probeconfig c on b.probe_id = c.probeconfig_id
                        where a.vip_id = v.vip_id and c.name = 'starfs_l7_80'
                     ) > 0, 'OK', 'FAIL'), '') as L7,
                if(sn.node_type = 0 or sn.node_type = 1,
                     if((
                         select count(*)
                         from
                             base_vip a
                            left join base_vip_probe b on a.vip_id = b.vip_id
                            left join base_probeconfig c on b.probe_id = c.probeconfig_id
                        where a.vip_id = v.vip_id and c.name = 'starfs_egde_http_80'
                     ) > 0, 'OK', 'FAIL'), '') as Http,
                if(isnull(sns.http_session_count), 0, sns.http_session_count) as http_session_count,
                if(sn.node_type = 0,
                     if((
                         select count(*)
                         from
                             base_vip a
                            left join base_vip_probe b on a.vip_id = b.vip_id
                            left join base_probeconfig c on b.probe_id = c.probeconfig_id
                        where a.vip_id = v.vip_id and c.name = 'starfs_egde_ftp_21'
                     ) > 0, 'OK', 'FAIL'), '') as Ftp,
                if(isnull(sns.ftp_session_count), 0, sns.ftp_session_count) as ftp_session_count,
                if(sn.node_type = 0,
                     if((
                         select count(*)
                         from
                             base_vip a
                            left join base_vip_probe b on a.vip_id = b.vip_id
                            left join base_probeconfig c on b.probe_id = c.probeconfig_id
                        where a.vip_id = v.vip_id and c.name = 'starfs_egde_ssh_2022'
                     ) > 0, 'OK', 'FAIL'), '') as SSH,
                if(isnull(sns.ssh_session_count), 0, sns.ssh_session_count) as ssh_session_count,
                if(isnull(sns.base_version), '', sns.base_version) as base_version,
                if(isnull(sns.config_version), '', sns.config_version) as config_version
            from
                storage_cluster sc
                left join storage_node sn on sc.cluster_id = sn.cluster_id
                left join base_vip v on (inet_ntoa(sn.ip_id) = v.vip_addr or sn.ip_id = v.ihms_vip_id)
                left join prism.base_vip_search vs on v.vip_id = vs.vip_id
                left join (
                    select *
                    from
                        (select node_id, max(start_time) as start_time
                        from storage_snapshot_node_status group by node_id
                        ) as x join storage_snapshot_node_status using (node_id, start_time)
                    ) sns on sn.node_id = sns.node_id
            where sc.obj_state = 1 and sn.obj_state = 1 and sc.cluster_id in (%s)
            group by sn.node_id
            order by sc.cluster_id, sn.node_type, sn.node_id
            """
    format_strings = ','.join(map(lambda x: '%s', cluster_list))
    sql = sql % (format_strings)
    params = []
    params.extend(cluster_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, tuple(params))
    obj = cursor.fetchone()

    try:
        while obj is not None:
            try:
                node_info[obj[0]][obj[1]] = {"node_id":obj[1],
                                                "node_type":obj[2],
                                                "node_type_name":obj[3],
                                                "ip_id":obj[4],
                                                "ip":obj[5],
                                                "hostname":obj[6],
                                                "base_status":obj[7],
                                                "mount_status":obj[8],
                                                "L7":obj[9],
                                                "Http":obj[10],
                                                "http_session_count": obj[11],
                                                "Ftp":obj[12],
                                                "ftp_session_count": obj[13],
                                                "SSH":obj[14],
                                                "ssh_session_count": obj[15],
                                                "base_version":obj[16],
                                                "config_version":obj[17]
                                                }
            except KeyError:
                node_info[obj[0]] = {}
                node_info[obj[0]][obj[1]] = {"node_id":obj[1],
                                            "node_type":obj[2],
                                            "node_type_name":obj[3],
                                            "ip_id":obj[4],
                                            "ip":obj[5],
                                            "hostname":obj[6],
                                            "base_status":obj[7],
                                            "mount_status":obj[8],
                                            "L7":obj[9],
                                            "Http":obj[10],
                                            "http_session_count": obj[11],
                                            "Ftp":obj[12],
                                            "ftp_session_count": obj[13],
                                            "SSH":obj[14],
                                            "ssh_session_count": obj[15],
                                            "base_version":obj[16],
                                            "config_version":obj[17]
                                            }
            obj = cursor.fetchone()
    finally:
        cursor.close()
        connections['default'].close()

    return node_info

def get_storage_node_detail(node_id):
    node_info = {}

    if node_id is not None:
        try:
            int(node_id)
        except ValueError:
            raise Exception(_(u'invalid node_id input format'))
    else:
        return node_info

    sql = """
            select
                sn.node_id,
                INET_NTOA(sn.ip_id) as ip,
                vs.full_host_name as hostname,
                if(v.enable_gslb = 1, 'Up', 'Down') as base_status,
                if(isnull(sns.mount_status), '',
                    if(sn.node_type <> 2, if(sns.mount_status = 0, 'FAIL', 'OK'), '')) as mount_status,
                if(sn.node_type = 0 or sn.node_type = 1,
                     if((
                         select count(*)
                         from
                             base_vip a
                            left join base_vip_probe b on a.vip_id = b.vip_id
                            left join base_probeconfig c on b.probe_id = c.probeconfig_id
                        where a.vip_id = v.vip_id and c.name = 'starfs_l7_80'
                     ) > 0, 'OK', 'FAIL'), '') as L7,
                if(sn.node_type = 0 or sn.node_type = 1,
                     if((
                         select count(*)
                         from
                             base_vip a
                            left join base_vip_probe b on a.vip_id = b.vip_id
                            left join base_probeconfig c on b.probe_id = c.probeconfig_id
                        where a.vip_id = v.vip_id and c.name = 'starfs_egde_http_80'
                     ) > 0, 'OK', 'FAIL'), '') as Http,
                if(sn.node_type = 0,
                     if((
                         select count(*)
                         from
                             base_vip a
                            left join base_vip_probe b on a.vip_id = b.vip_id
                            left join base_probeconfig c on b.probe_id = c.probeconfig_id
                        where a.vip_id = v.vip_id and c.name = 'starfs_egde_ftp_21'
                     ) > 0, 'OK', 'FAIL'), '') as Ftp,
                if(sn.node_type = 0,
                     if((
                         select count(*)
                         from
                             base_vip a
                            left join base_vip_probe b on a.vip_id = b.vip_id
                            left join base_probeconfig c on b.probe_id = c.probeconfig_id
                        where a.vip_id = v.vip_id and c.name = 'starfs_egde_ssh_2022'
                     ) > 0, 'OK', 'FAIL'), '') as SSH,
                if(isnull(sns.base_version), '', sns.base_version) as base_version,
                if(isnull(sns.config_version), '', sns.config_version) as config_version
            from
                storage_node sn
                left join base_vip v on (inet_ntoa(sn.ip_id) = v.vip_addr or sn.ip_id = v.ihms_vip_id)
                left join base_vip_search vs on v.vip_id = vs.vip_id
                left join (
                    select *
                    from
                        (select node_id, max(start_time) as start_time
                        from storage_snapshot_node_status group by node_id
                        ) as x join storage_snapshot_node_status using (node_id, start_time)
                    ) sns on sn.node_id = sns.node_id
            where sn.obj_state = 1 and sn.node_id = %s
            group by sn.node_id
            """
    cursor = connections['default'].cursor()
    cursor.execute(sql, [node_id])
    obj = cursor.fetchone()
    try:
        while obj is not None:
            node_info = {"node_id":obj[0],
                                "ip":obj[1],
                                "hostname":obj[2],
                                "base_status":obj[3],
                                "mount_status":obj[4],
                                "L7":obj[5],
                                "Http":obj[6],
                                "Ftp":obj[7],
                                "SSH":obj[8],
                                "base_version":obj[9],
                                "config_version":obj[10]
                            }
            obj = cursor.fetchone()
    finally:
        cursor.close()
        connections['default'].close()

    return node_info

def get_name_info(cluster_id):
    cluster_info = {}
    storage_info = {}
    node_info = {}

    if cluster_id is not None:
        try:
            cluster_id = int(cluster_id)
        except ValueError:
            raise Exception(_(u'invalid cluster_id input format'))
    else:
        return (cluster_info, storage_info, node_info)

    sql = """
        SELECT
            sc.cluster_id, sc.cluster_name,
            scs.idx,
            ss.storage_id, ss.storage_name,
            sn.node_id, sn.node_type_name
        FROM storage_cluster sc
            LEFT JOIN storage_cluster_storage scs on scs.cluster_id  = sc.cluster_id
            LEFT JOIN storage_storage ss on scs.storage_id = ss.storage_id
            LEFT JOIN storage_node sn on sc.cluster_id = sn.cluster_id
        WHERE sc.cluster_id = %s
        """

    cursor = connections['default'].cursor()
    cursor.execute(sql, [cluster_id])
    obj = cursor.fetchone()

    try:
        while obj is not None:
            try:
                cluster_info[obj[0]] = {'cluster' :obj[0], 'cluster_name':obj[1]}
            except KeyError:
                cluster_info[obj[0]] = {}
                cluster_info[obj[0]] = {'cluster' :obj[0], 'cluster_name':obj[1]}

            try:
                storage_info[obj[2]] = {'storagecluster' :obj[2], 'storage_id' :obj[3], 'storage_name':obj[4]}
            except KeyError:
                storage_info[obj[2]] = {}
                storage_info[obj[2]] = {'storagecluster' :obj[2], 'storage_id' :obj[3], 'storage_name':obj[4]}

            try:
                node_info[obj[5]] = {'node' :obj[5], 'node_type_name':obj[6]}
            except KeyError:
                node_info[obj[5]] = {}
                node_info[obj[5]] = {'node' :obj[5], 'node_type_name':obj[6]}

            obj = cursor.fetchone()
    finally:
        cursor.close()
        connections['default'].close()

    return (cluster_info, storage_info, node_info)

def get_s_name_info(cluster_id):
    cluster_info = {}
    dst_cluster_info = {}
    storage_info = {}
    node_info = {}

    if cluster_id is not None:
        try:
            int(cluster_id)
        except ValueError:
            raise Exception(_(u'invalid cluster_id input format'))
    else:
        return (cluster_info, dst_cluster_info, storage_info, node_info)

    sql = """
        select
            sf.cluster_id, sc.cluster_name,
            sf.dst_cluster_id,
            (select cluster_name from storage_cluster where cluster_id = sf.dst_cluster_id) as dst_cluster_name,
            sf.cluster_storage_id,
            ss.storage_id, ss.storage_name, ss.customer_id, ca.account_name_local,
            sf.node_id, INET_NTOA(sn.ip_id) as ip
        from storage_sync_fail sf
            left join storage_cluster_storage scs on sf.cluster_storage_id = scs.idx
            left join storage_storage ss on scs.storage_id = ss.storage_id
            left join customer_display cd on ss.customer_id = cd.customer_id
            left join customer_account ca on cd.account_no = ca.account_no
            left join storage_cluster sc on sf.cluster_id = sc.cluster_id
            left join storage_node sn on sf.node_id = sn.node_id
        where sf.cluster_id = %s
        """

    cursor = connections['default'].cursor()
    cursor.execute(sql, [cluster_id])
    obj = cursor.fetchone()

    try:
        while obj is not None:
            try:
                cluster_info[obj[0]] = {'cluster' :obj[0], 'cluster_name':obj[1]}
            except KeyError:
                cluster_info[obj[0]] = {}
                cluster_info[obj[0]] = {'cluster' :obj[0], 'cluster_name':obj[1]}

            try:
                dst_cluster_info[obj[2]] = {'dst_cluster' :obj[2], 'dst_cluster_name':obj[3]}
            except KeyError:
                dst_cluster_info[obj[2]] = {}
                dst_cluster_info[obj[2]] = {'dst_cluster' :obj[2], 'dst_cluster_name':obj[3]}

            try:
                storage_info[obj[4]] = {'storagecluster' :obj[4],
                                    'storage' :obj[5],
                                    'storage_name':obj[6],
                                    'customer':obj[7],
                                    'customer_name':obj[8]
                                    }
            except KeyError:
                storage_info[obj[4]] = {}
                storage_info[obj[4]] = {'storagecluster' :obj[4],
                                        'storage' :obj[5],
                                        'storage_name':obj[6],
                                        'customer':obj[7],
                                        'customer_name':obj[8]
                                        }

            try:
                node_info[obj[9]] = {'node' :obj[9], 'node_ip':obj[10]}
            except KeyError:
                node_info[obj[9]] = {}
                node_info[obj[9]] = {'node' :obj[9], 'node_ip':obj[10]}

            obj = cursor.fetchone()
    finally:
        cursor.close()
        connections['default'].close()

    return (cluster_info, dst_cluster_info, storage_info, node_info)

def get_cluster_origin_traffic(cluster_id, date_from, date_to):
    cluster_info = []

    if cluster_id is not None:
        try:
            int(cluster_id)
        except ValueError:
            raise Exception(_(u'invalid cluster_id input format'))
    else:
        return cluster_info

    sql = """
            select
                sot.cluster_id as cluster, sc.cluster_name,
                sot.cluster_storage_id as storagecluster, ss.storage_id, ss.storage_name,
                sot.cluster_node_id as node, sn.node_type_name,
                sot.start_time, sot.origin_traffic
            from storage_origin_traffic sot
                left join storage_cluster sc on sot.cluster_id = sc.cluster_id
                left join storage_cluster_storage scs on sot.cluster_storage_id = scs.idx
                left join storage_storage ss on scs.storage_id = ss.storage_id
                left join storage_node sn on sot.cluster_node_id = sn.node_id
            where sot.cluster_id = %s
                and (sot.start_time >= %s and sot.start_time <= %s)
            order by sot.start_time
            """
    cursor = connections['default'].cursor()
    cursor.execute(sql, [cluster_id, date_from, date_to])
    fieldnames = [name[0] for name in cursor.description]
    rs = cursor.fetchall()

    try:
        for obj in rs:
            rowset = []
            for field in zip(fieldnames, obj):
                rowset.append((field[0], field[1]))
            cluster_info.append(dict(rowset))
    finally:
        cursor.close()
        connections['default'].close()

    return cluster_info

def get_cluster_wait_queue(cluster_id, date_from, date_to):
    cluster_info = []

    if cluster_id is not None:
        try:
            int(cluster_id)
        except ValueError:
            raise Exception(_(u'invalid cluster_id input format'))
    else:
        return cluster_info

    sql = """
            select
                swq.cluster_id as cluster, sc.cluster_name,
                swq.cluster_storage_id as storagecluster, ss.storage_id, ss.storage_name,
                swq.cluster_node_id as node, sn.node_type_name,
                swq.start_time, swq.wait_queue_count
            from storage_sid_wait_queue swq
                left join storage_cluster sc on swq.cluster_id = sc.cluster_id
                left join storage_cluster_storage scs on swq.cluster_storage_id = scs.idx
                left join storage_storage ss on scs.storage_id = ss.storage_id
                left join storage_node sn on swq.cluster_node_id = sn.node_id
            where swq.cluster_id = %s
                and (swq.start_time >= %s and swq.start_time <= %s)
            order by swq.start_time
            """
    cursor = connections['default'].cursor()
    cursor.execute(sql, [cluster_id, date_from, date_to])
    fieldnames = [name[0] for name in cursor.description]
    rs = cursor.fetchall()

    try:
        for obj in rs:
            rowset = []
            for field in zip(fieldnames, obj):
                rowset.append((field[0], field[1]))
            cluster_info.append(dict(rowset))
    finally:
        cursor.close()
        connections['default'].close()

    return cluster_info


class ClusterAllAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = Cluster.objects.all()
    serializer_class = ClusterAllSerializer
    lookup_url_kwarg = __STORAGE_CLUSTER_URL_LOOKUP_KEY__
    ordering = 'cluster_name'

    def get(self, request, *args, **kwargs):
        return super(ClusterAllAPI, self).list(request, *args, **kwargs)

class ClusterAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = Cluster.objects.all()
    serializer_class = ClusterSerializer
    lookup_url_kwarg = __STORAGE_CLUSTER_URL_LOOKUP_KEY__
    ordering = 'cluster_name'

    def get(self, request, *args, **kwargs):
        ret = super(ClusterAPI, self).list(request, *args, **kwargs)

        if isinstance(ret.data, list):
            org_results = ret.data
        else:
            org_results = ret.data['results']
        cluster_list = []
        for result in org_results:
            cluster_list.append(str(result['cluster_id']))

        usage_capacity_info = get_cluster_usage_capacity(cluster_list)
        sync_fail_info = get_cluster_sync_fail(cluster_list)
        wait_queues_info = get_cluster_wait_queues(cluster_list)
        cluster_status_info = get_all_cluster_status(cluster_list)

        for result in org_results:
            if usage_capacity_info.has_key(result['cluster_id']):
                result['usage'] = round(usage_capacity_info[result['cluster_id']]['usage'],2)
                result['capacity'] = round(usage_capacity_info[result['cluster_id']]['capacity'],2)
            else:
                result['usage'] = 0
                result['capacity'] = 0

            if sync_fail_info.has_key(result['cluster_id']):
                result['sync_fail_1day'] = sync_fail_info[result['cluster_id']]['sync_fail_1day']
                result['sync_fail_2day'] = sync_fail_info[result['cluster_id']]['sync_fail_2day']
                result['sync_fail_3day'] = sync_fail_info[result['cluster_id']]['sync_fail_3day']
            else:
                result['sync_fail_1day'] = 0
                result['sync_fail_2day'] = 0
                result['sync_fail_3day'] = 0

            if wait_queues_info.has_key(result['cluster_id']):
                result['wait_queues'] = wait_queues_info[result['cluster_id']]['wait_queues']
            else:
                result['wait_queues'] = 0

            if cluster_status_info.has_key(result['cluster_id']):
                result['cluster_status'] = cluster_status_info[result['cluster_id']]['cluster_status']
            else:
                result['cluster_status'] = 'Unknown'

        if isinstance(ret.data, list):
            ret.data = org_results
        else:
            ret.data['results'] = org_results

        return ret

class ClusterNodeAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = Cluster.objects.all()
    serializer_class = ClusterNodeSerializer
    lookup_url_kwarg = __STORAGE_CLUSTER_URL_LOOKUP_KEY__
    ordering = 'cluster_name'

    def get(self, request, *args, **kwargs):
        ret = super(ClusterNodeAPI, self).list(request, *args, **kwargs)

        if isinstance(ret.data, list):
            org_results = ret.data
        else:
            org_results = ret.data['results']

        cluster_list = []
        for result in org_results:
            cluster_list.append(str(result['cluster_id']))

        node_info = get_storage_node_list(cluster_list)

        for result in org_results:
            if node_info.has_key(result['cluster_id']):
                storagenodes = node_info[result['cluster_id']].values()
                storagenodes = sorted([k for k in storagenodes], key=lambda b:(b['node_type'],b['node_id']))
                result['storagenodes'] = storagenodes
            else:
                result['storagenodes'] = []

        if isinstance(ret.data, list):
            ret.data = org_results
        else:
            ret.data['results'] = org_results

        return ret

class ClusterDetailAPI(RetrieveModelMixin, SpectrumGenericAPIView):
    queryset = Cluster.objects.all()
    serializer_class = ClusterSerializer
    lookup_url_kwarg = __STORAGE_CLUSTER_URL_LOOKUP_KEY__

    def get(self, request, *args, **kwargs):
        ret = super(ClusterDetailAPI, self).retrieve(request, *args, **kwargs)

        try:
            cluster_id = self.kwargs.get(self.lookup_url_kwarg)
        except KeyError:
            raise AccessInvalidClusterID

        org_results = ret.data

        usage_capacity_info = get_cluster_usage_capacity([str(cluster_id)])[int(cluster_id)]
        cluster_status_info = get_all_cluster_status([str(cluster_id)])[int(cluster_id)]

        if len(usage_capacity_info) > 0:
            org_results['usage'] = round(usage_capacity_info['usage'], 2)
            org_results['capacity'] = round(usage_capacity_info['capacity'], 2)
        else:
            org_results['usage'] = 0
            org_results['capacity'] = 0

        if len(cluster_status_info) > 0:
            org_results['cluster_status'] = cluster_status_info['cluster_status']
        else:
            org_results['cluster_status'] = 'Unknown'

        ret.data = org_results

        return ret

class ClusterOriginTrafficAPI(ListModelMixin, SpectrumGenericAPIView):
    def get(self, request, *args, **kwargs):
        try:
            cluster_id = self.kwargs.get('cluster_id')
            start_time = self.request.GET.get('start_time__range', None)
            date_from = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
            date_to = (datetime.now()).strftime("%Y-%m-%d")

            if start_time is not None:
                timerange = self.request.GET.get('start_time__range').split(',')
                date_from = str(timerange[0])
                date_to = str(timerange[1])

            cluster_info = []
            origin_traffic_list = get_cluster_origin_traffic(cluster_id, date_from, date_to)

            if len(origin_traffic_list) > 0:
                cluster_info = [{'cluster' : origin_traffic['cluster'],
                                 'cluster_name' : origin_traffic['cluster_name'],
                                 'storagecluster' : origin_traffic['storagecluster'],
                                 'storage_id' : origin_traffic['storage_id'],
                                 'storage_name' : origin_traffic['storage_name'],
                                 'node' : origin_traffic['node'],
                                 'node_type_name' : origin_traffic['node_type_name'],
                                 'start_time' : str(origin_traffic['start_time']),
                                 'origin_traffic' : origin_traffic['origin_traffic']
                                 } for origin_traffic in origin_traffic_list]

            return Response(cluster_info)
        except KeyError:
            raise AccessInvalidClusterID
        except:
            raise APIException(detail=_(u"Occured system failure"))

class ClusterWaitQueueAPI(ListModelMixin, SpectrumGenericAPIView):
    def get(self, request, *args, **kwargs):
        try:
            cluster_id = self.kwargs.get('cluster_id')
            start_time = self.request.GET.get('start_time__range', None)
            date_from = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
            date_to = (datetime.now()).strftime("%Y-%m-%d")

            if start_time is not None:
                timerange = self.request.GET.get('start_time__range').split(',')
                date_from = str(timerange[0])
                date_to = str(timerange[1])

            cluster_info = []
            wait_queue_list = get_cluster_wait_queue(cluster_id, date_from, date_to)

            if len(wait_queue_list) > 0:
                cluster_info = [{'cluster' : wait_queue['cluster'],
                                 'cluster_name' : wait_queue['cluster_name'],
                                 'storagecluster' : wait_queue['storagecluster'],
                                 'storage_id' : wait_queue['storage_id'],
                                 'storage_name' : wait_queue['storage_name'],
                                 'node' : wait_queue['node'],
                                 'node_type_name' : wait_queue['node_type_name'],
                                 'start_time' : str(wait_queue['start_time']),
                                 'wait_queue_count' : wait_queue['wait_queue_count']
                                 } for wait_queue in wait_queue_list]

            return Response(cluster_info)
        except KeyError:
            raise AccessInvalidClusterID
        except:
            raise APIException(detail=_(u"Occured system failure"))

class StorageClusterAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = Storage.objects.all()
    serializer_class = StorageClusterSerializer
    lookup_url_kwarg = __STORAGE_URL_LOOKUP_KEY__

    def get_queryset(self):
        try:
            cluster_id = self.kwargs.get(__STORAGE_CLUSTER_URL_LOOKUP_KEY__)
            # valid check
            int(cluster_id)

            if cluster_id:
                storage_cluster = StorageCluster.objects.filter(cluster=cluster_id)
                storage_list = []
                for data in storage_cluster:
                    storage_list.append(data.storage.storage_id)

                if len(storage_list) > 0:
                    self.queryset = self.queryset.filter(storage_id__in=storage_list)
        except KeyError:
            raise AccessInvalidClusterID
        except ValueError:
            raise Exception(_(u'invalid cluster_id input format'))

        return self.queryset

    def get(self, request, *args, **kwargs):
        ret = super(StorageClusterAPI, self).list(request, *args, **kwargs)

        try:
            cluster_id = self.kwargs.get(__STORAGE_CLUSTER_URL_LOOKUP_KEY__)
        except KeyError:
            raise AccessInvalidClusterID

        if isinstance(ret.data, list):
            org_results = ret.data
        else:
            org_results = ret.data['results']
        storage_list = []
        for result in org_results:
            storage_list.append(str(result['storage_id']))

        replication_info = get_config_replication(storage_list)
        redundancy_info = get_storage_redundancy(storage_list)
        sync_fail_info = get_storage_sync_fail(storage_list, cluster_id)

        for result in org_results:
            if replication_info.has_key(result['storage_id']):
                result['replication'] = replication_info[result['storage_id']]['replication']
            else:
                result['replication'] = 'Standard'

            if redundancy_info.has_key(result['storage_id']):
                result['redundancy'] = redundancy_info[result['storage_id']]['redundancy']
            else:
                result['redundancy'] = 'NO'

            if sync_fail_info.has_key(result['storage_id']):
                result['wait_queues'] = sync_fail_info[result['storage_id']]['wait_queues']
                result['sync_fail_1day'] = sync_fail_info[result['storage_id']]['sync_fail_1day']
                result['sync_fail_2day'] = sync_fail_info[result['storage_id']]['sync_fail_2day']
                result['sync_fail_3day'] = sync_fail_info[result['storage_id']]['sync_fail_3day']
            else:
                result['wait_queues'] = 0
                result['sync_fail_1day'] = 0
                result['sync_fail_2day'] = 0
                result['sync_fail_3day'] = 0

        if isinstance(ret.data, list):
            ret.data = org_results
        else:
            ret.data['results'] = org_results

        return ret

class StorageOriginTrafficAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = StorageOriginTraffic.objects.all()
    serializer_class = StorageOriginTrafficSerializer
    lookup_url_kwarg = __STORAGE_URL_LOOKUP_KEY__
    filter_fields = ('start_time',)

    def get_queryset(self):
        try:
            cluster_id = self.kwargs.get(__STORAGE_CLUSTER_URL_LOOKUP_KEY__)
            storage_id = self.kwargs.get(self.lookup_url_kwarg)
            # valid check
            int(cluster_id)
            int(storage_id)

            storage_clusters = StorageCluster.objects.filter(storage__pk=storage_id).values_list('idx', flat=True)
            self.queryset = self.queryset.using('default').filter(cluster=cluster_id).filter(storagecluster__in=storage_clusters)

        except KeyError:
            raise AccessInvalidID
        except ValueError:
            raise Exception(_(u'invalid id input format'))

        return self.queryset

    def get(self, request, *args, **kwargs):
        return super(StorageOriginTrafficAPI, self).list(request, *args, **kwargs)

class ClusterSyncFailAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = StorageSyncFail.objects.all()
    serializer_class = StorageSyncFailSerializer
    lookup_url_kwarg = __STORAGE_CLUSTER_URL_LOOKUP_KEY__
    search_fields = ('objname',)
    filter_fields = ({'storage_id':'storagecluster__storage__pk'},'failed_time','objname',)

    def get_queryset(self):
        try:
            cluster_id = self.kwargs.get(self.lookup_url_kwarg)
            # valid check
            int(cluster_id)

            self.queryset = self.queryset.filter(cluster=cluster_id)
        except KeyError:
            raise AccessInvalidClusterID
        except ValueError:
            raise Exception(_(u'invalid cluster_id input format'))

        return self.queryset

    def get(self, request, *args, **kwargs):
        ret = super(ClusterSyncFailAPI, self).list(request, *args, **kwargs)

        try:
            cluster_id = self.kwargs.get(self.lookup_url_kwarg)
        except KeyError:
            raise AccessInvalidClusterID

        if isinstance(ret.data, list):
            org_results = ret.data
        else:
            org_results = ret.data['results']

        cluster_info, dst_cluster_info, storage_info, node_info = get_s_name_info(cluster_id)

        for result in org_results:
            if cluster_info.has_key(result['cluster']):
                result['cluster_name'] = cluster_info[result['cluster']]['cluster_name']
            if dst_cluster_info.has_key(result['dst_cluster']):
                result['dst_cluster_name'] = dst_cluster_info[result['dst_cluster']]['dst_cluster_name']
            if storage_info.has_key(result['storagecluster']):
                result['storage'] = storage_info[result['storagecluster']]['storage']
                result['storage_name'] = storage_info[result['storagecluster']]['storage_name']
                result['customer'] = storage_info[result['storagecluster']]['customer']
                result['customer_name'] = storage_info[result['storagecluster']]['customer_name']
            if node_info.has_key(result['node']):
                result['node_ip'] = node_info[result['node']]['node_ip']

        if isinstance(ret.data, list):
            ret.data = org_results
        else:
            ret.data['results'] = org_results

        return ret

class StorageSyncFailSimpleListAPI(ListModelMixin, SpectrumGenericAPIView):
    lookup_url_kwarg = __STORAGE_CLUSTER_URL_LOOKUP_KEY__

    def get(self, request, *args, **kwargs):
        try:
            cluster_id = self.kwargs.get(self.lookup_url_kwarg)
            storage_items = get_simple_storage_list(cluster_id)

            storage_list = [{'storage':items['storage'], 'storage_name':items['storage_name']} for items in storage_items]

            return Response(storage_list)
        except KeyError:
            raise AccessInvalidClusterID
        except:
            raise APIException(detail=_(u"Occured system failure"))

class ClusterNodeDetailAPI(RetrieveModelMixin, SpectrumGenericAPIView):
    queryset = StorageNode.objects.all()
    serializer_class = ClusterNodeDetailSerializer
    lookup_url_kwarg = __STORAGE_NODE_URL_LOOKUP_KEY__

    def get(self, request, *args, **kwargs):
        ret = super(ClusterNodeDetailAPI, self).retrieve(request, *args, **kwargs)

        try:
            node_id = self.kwargs.get(self.lookup_url_kwarg)
        except KeyError:
            raise AccessInvalidNodeID

        org_results = ret.data
        node_info = get_storage_node_detail(str(node_id))

        if len(node_info) > 0:
            org_results['ip'] = node_info['ip']
            org_results['hostname'] = node_info['hostname']
            org_results['base_status'] = node_info['base_status']
            org_results['mount_status'] = node_info['mount_status']
            org_results['L7'] = node_info['L7']
            org_results['Http'] = node_info['Http']
            org_results['Ftp'] = node_info['Ftp']
            org_results['SSH'] = node_info['SSH']
            org_results['base_version'] = node_info['base_version']
            org_results['config_version'] = node_info['config_version']
        else:
            org_results['ip'] = ''
            org_results['hostname'] = ''
            org_results['base_status'] = ''
            org_results['mount_status'] = ''
            org_results['L7'] = ''
            org_results['Http'] = ''
            org_results['Ftp'] = ''
            org_results['SSH'] = ''
            org_results['base_version'] = ''
            org_results['config_version'] = ''

        ret.data = org_results

        return ret
