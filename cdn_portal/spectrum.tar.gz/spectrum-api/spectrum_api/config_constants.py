# -*- coding: utf-8 -*-
# conditional value for standalone mode

# True : points to Production Server,False: points to dev server
IS_PRODUCTION = False
DEBUG = False

if IS_PRODUCTION:
    ADMINS = (
            ('ENG-UI', 'eng-ui@cdnetworks.com'),
    )
    EMAIL_ALERTS = ['eng-ui@cdnetworks.com']
    # MSSQL databases
    DATABASES = {
        'cop': {
            'code': '0',
            'host': 'copdb.cdnetworks.com,20302',
            'user':'cop',
            'password': 'cop$gurtls!',
            'database': 'COP'
        }
    }
    CACHE_LOCATIONS = [
                'api1.p59-icn.cdngp.net:11211',
                'api2.p59-icn.cdngp.net:11211',
            ]
    # AQUA API CONSTANTS
    AQUA_API_URL_PREFIX = 'http://authconfig.krhttpvod3.nefficient.co.kr:8080/AquaAuth/services/AquaAuthAPI'
    AQUA_API_USER = 'cdn@cdnetworks.kr'
    AQUA_API_PASSWORD = 'cdnaqua'

    LOCATION_SEARCH_API_INFO = {
        'url': 'https://contentsearch.cdnetworks.com:444',
        'timeout': 300,
        'api_key': 'apiinterface@apiadmin'
    }

else:
    ADMINS = (
            ('ENG-CLOUD', 'eng-cloud@cdnetworks.com'),
    )
    EMAIL_ALERTS = ['eng-cloud@cdnetworks.com']
    # MSSQL databases
    DATABASES = {
        'cop': {
            'code': '0',
            'host': 'devcopdb.cdnetworks.com\CDNSQL,20302',
            'user':'cop',
            'password': 'cop$gurtls!',
            'database': 'COP'
        }
    }
    CACHE_LOCATIONS = [
            '127.0.0.1:11211',
        ]
    # AQUA API CONSTANTS
    AQUA_API_URL_PREFIX = 'http://10.40.210.133:8080/AquaAuth/services/AquaAuthAPI'
    AQUA_API_USER = 'cdn@cdnetworks.kr'
    AQUA_API_PASSWORD = 'cdnaqua'

    LOCATION_SEARCH_API_INFO = {
        'url': 'https://contentsearch.cdnetworks.com:444',
        'timeout': 10,
        'api_key': 'apiinterface@apiadmin'
    }

CACHE_BACKEND = "django.core.cache.backends.memcached.MemcachedCache"

INTERNAL_AD_PROTOCOL = 'ldaps'
INTERNAL_AD_SERVER = 'adlap.cdnetworks.com'
INTERNAL_AD_PORT = '3269'
INTERNAL_AD_BASE = 'DC=cdnetworks,DC=kr'
INTERNAL_AD_LOGIN_ID = 'ihms_api'
INTERNAL_AD_LOGIN_PWD = 'ihms#$admin'

SUPPORT_CENTER_TEL_NUMBER = '0234410596'
REPORT_MAIL_SENDER = 'CDNetworks (Sender Only) <noreply@cdnetworks.com>'

HOST_PAL_KR = 'pal.kr.cdnetworks.com'
HOST_PAL_US = 'pal.us.cdnetworks.com'
HOST_PAL_JP = 'pal.jp.cdnetworks.com'
HOST_PAL_CN = 'pal.cn.cdnetworks.com'
HOST_PAL_SG = 'pal.us.cdnetworks.com'
HOST_PAL_UK = 'pal.us.cdnetworks.com'
