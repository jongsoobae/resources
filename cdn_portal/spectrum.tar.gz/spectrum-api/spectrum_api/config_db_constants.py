# -*- coding: utf-8 -*-
# Database settings configuration

DEFAULT = {
        'NAME':'prism',
        'ENGINE':'django.db.backends.mysql',
        'USER':'spectrum_api',
        'PASSWORD':'669#fC&8b8C&5#f3l@#2',
        'HOST':'ngpdb.cdnetworks.com',
        'PORT':'3306'
    }
AURORA = {
        'NAME':'aurora',
        'ENGINE':'django.db.backends.mysql',
        'USER':'spectrum_api',
        'PASSWORD':'669#fC&8b8C&5#f3l@#2',
        'HOST':'ngpdb.cdnetworks.com',
        'PORT':'3306'
    }
READONLY = {
        'NAME':'rms',
        'ENGINE':'django.db.backends.mysql',
        'USER':'aurora_ui',
        'PASSWORD':'669#fC&8b8C&5#f3l@#2',
        'HOST':'ngpdb.cdnetworks.com',
        'PORT':'3306',
    }
STATS = {
        'NAME':'stat',
        'ENGINE':'django.db.backends.mysql',
        'USER':'spectrum_api',
        'PASSWORD':'669#fC&8b8C&5#f3l@#2',
        'HOST':'ngpdb.cdnetworks.com',
        'PORT':'3306'
    }
CENTRALDB = {
        'NAME':'centraldb',
        'ENGINE':'django.db.backends.mysql',
        'USER':'spectrum_ro',
        'PASSWORD':'669#fC&8b8C&5#f3l@#2',
        'HOST':'cdb.cdnetworks.com',
        'PORT':'3306'
}
FULMENDB = {
        'NAME':'fulmen',
        'ENGINE':'django.db.backends.mysql',
        'USER':'ngp-ro',
        'PASSWORD':'669#fC&8b8C&5#f3l@#2',
        'HOST':'statdb.cdnetworks.com',
        'PORT':'3306'
}
SPECTRUM = {
        'NAME':'spectrum',
        'ENGINE':'django.db.backends.mysql',
        'USER':'spectrum_api',
        'PASSWORD':'669#fC&8b8C&5#f3l@#2',
        'HOST':'ngpdb.cdnetworks.com',
        'PORT':'3306'
}
ONE_STAT = {
        'NAME':'one_stat',
        'ENGINE':'django.db.backends.mysql',
        'USER':'spectrum-api',
        'PASSWORD':'669#fC&8b8C&5#f3l@#2',
        'HOST':'statdb.cdnetworks.com',
        'PORT':'3306'
}
LEGACY_STAT = {
        'NAME':'legacy_stat',
        'ENGINE':'django.db.backends.mysql',
        'USER':'spectrum-api',
        'PASSWORD':'669#fC&8b8C&5#f3l@#2',
        'HOST':'statdb.cdnetworks.com',
        'PORT':'3306'
}
