#
# Copyright (c) 2011 CDNetworks Co., Ltd.
# All rights reserved.
#
# $Id$
#

from django.utils.safestring import mark_safe
from django.db import models
from spectrum_api.shared_components.models import BaseModel

class Model(BaseModel):
    class Meta:
        abstract = True

    class SpectrumMeta:
        track = True

    def admin_link(self):
        if self.pk:
            return mark_safe(u'<a href="/config/%s/%s/%s/">%s</a>' % (self._meta.app_label,
                self._meta.object_name.lower(), self.pk, self))
        else:
            return mark_safe(u'')

class InterimModel(BaseModel):
    class Meta:
        abstract = True
        ordering = ['-obj_state']

    class SpectrumMeta:
        track = False

    def delete(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        if request:
            if not request.user:
                raise Exception("Authenticated user required to delete")
            self.update_history(request, 3)
            self.delete()
        else:
            super(BaseModel, self).delete(*args, **kwargs)
