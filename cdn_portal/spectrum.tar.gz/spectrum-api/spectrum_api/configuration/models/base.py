#
# Copyright (c) 2011 CDNetworks Co., Ltd.
# All rights reserved.
#
# $Id: base.py 12208 2014-02-20 01:39:10Z injune.hwang $
#

from datetime import datetime, timedelta

from django.core.exceptions import ValidationError, ObjectDoesNotExist
from django.core.validators import MaxValueValidator, MinValueValidator, \
    RegexValidator, MinLengthValidator, MaxLengthValidator
from django.db import models
from django.db.models import Count, Q
from django.utils.encoding import force_unicode
from django.utils.translation import ugettext as _

from spectrum_api.configuration.models import Model, InterimModel
from spectrum_api.shared_components.models import HistoryModel
from spectrum_api.configuration.models.config import ConfigPhase
from spectrum_api.configuration.models.help_msg import H_POPGROUP, H_IHMSPOP, \
    H_POPNAME, H_RTT_SERVER, H_PKTLOSS_SERVER, H_PKTLOSS, H_COST, \
    H_ENABLE_GSLB_POP, H_POP_ENABLE_CNAME_LATENCY, H_SYSTEM, \
    H_CUSTOMER_SYSTEMNAME, H_SERVER_MANAGE_IP, H_ENABLE_GSLB, H_HOST, \
    H_CUSTOMER_HOSTNAME, H_EDGE_NAME, H_VIP, H_CUSTOMER_VIPNAME, \
    H_CUSTOMER_VIPADDR, H_MPROXY_SHIELD, H_MPROXY_OUTGOING_IP, H_PROBEAGENT, \
    H_PROBEAGENT_PRIMARY, H_PROBE_NAME, H_PROBE_DESC, H_PROBE_INTERVAL, \
    H_PROBE_TTL_FACTOR, H_PROBE_THESHOLD, H_PROBE_REPORT, H_PROBE_REPORTOTHER, \
    H_PROBE_LOG, H_PROBE_TIMEOUT, H_PROBE_TRY_COUNT, H_PROBE_SCALING, H_PROBE_RATEFUNC, \
    H_PROBE_RATIO_BASE, H_PROBE_STEPFUNC, H_ICMP_TYPE, H_ICMP_VALUE, \
    H_SNMP_VERSION, H_SNMP_PORT, H_SNMP_OID_TYPE, H_SNMP_OID, H_SNMP_COMMUNITY, \
    H_SNMP_USERNAME, H_SNMP_SECURITY_LEVEL, H_SNMP_AUTH_PROTOCOL, H_SNMP_AUTH_PW, \
    H_SNMP_PRIV_PROTOCOL, H_SNMP_PRIV_PW, H_SNMP_CONTEXT, H_SNMP_VALUE, \
    H_TCP_PORT, H_MESSAGE, H_TCP_CONTENT_LENGTH, H_TCP_VALUE, H_TCP_REGEX, \
    H_SSL_VERIFY_SERVER, H_SSL_PORT, H_SSL_MESSAGE, H_SSL_CONTENT_LENGTH, \
    H_SSL_VALUE, H_SSL_REGEX, H_UDP_PORT, H_UDP_MESSAGE, H_UDP_CONTENT_LENGTH, \
    H_UDP_VALUE, H_UDP_REGEX, H_FTP_PORT, H_FTP_USERNAME, H_FTP_PW, H_FTP_PATH, \
    H_FTP_CONTENT_LENGTH, H_FTP_VALUE, H_FTP_REGEX, H_RTMP_PORT, \
    H_RTMP_ENCRIPTED, H_RTMP_VERIFY, H_RTMP_APP, H_RTMP_TCURL, H_RTMP_FLASHVER, \
    H_RTMP_STREAM, H_RTMP_VALUE, H_DNS_DOMAIN, H_DNS_CLASS, H_DNS_TYPE, \
    H_DNS_PORT, H_DNS_VALUE, H_DNS_CODEMATCH, H_PROBE_AGGRE_TYPE, \
    H_PROBE_AGGRE_SUBPROBE, H_PROBE_AGGRE_WEIGHT, H_PROBE_AGGRE_VIP, \
    H_OVERRIDE_THRESHOLD, H_OVERRIDE_STEPFUNC, H_OVERRIDE_TIMEOUT
from spectrum_api.configuration.models.ihms import IhmsPop, IhmsSystem, IhmsHost, IhmsVip, IhmsIdc, IhmsCountry
from spectrum_api.shared_components.utils.common import getIPidbyipaddr
from spectrum_api.shared_components.utils.common import is_ihms_sync_running
from spectrum_api.shared_components.utils.common import log_error
from spectrum_api.shared_components.utils.regex import REGEX_POP_GROUP_NAME, \
    REGEX_POP_NAME, customersystem_rex, customerhost_rex, edge_name_rex, \
    customer_vip_rex, probe_name_rex, stepfunc_rex, oid_rex, default_name_rex, \
    path_rex, rtmp_app_rex, rtmp_flashver_rex, rtmp_stream_name_rex, \
    gslb_domain_rex
from spectrum_api.shared_components.utils.role_define import MPROXY_ROLE


TIMEOUT = 30  # minutes
DEV_LOCK_TIMEOUT = 30
BOOL_TYPES = (
    (0, 'False'),
    (1, 'True'),
)

SELECT_TYPES = (
    (0, 'False'),
    (1, 'True'),
)

POP_STATUS = (
    (0, 'Modified'),
    (1, 'Pending Testing'),
    (2, 'Sent to Stage'),
    (3, 'Promote to Production'),
    (4, 'In Production'),
    (-2, 'Pending Failed'),
    (-4, 'Production Failed'),
)

PROBE_TYPES = (
    (0, 'AGGREGATE'),
    (1, 'SNMP'),
    (2, 'TCP'),
    (3, 'UDP'),
    (4, 'SSL'),
    (5, 'FTP'),
    (6, 'RTMP'),
    (7, 'DNS'),
    (8, 'ICMP'),
)
DSP_DEPS_LIMIT = 10


class PopGroup(Model):
    popgroup_id = models.AutoField("Id", primary_key=True)
    name = models.CharField('Name',
                            unique=True,
                            max_length=63,
                            validators=[RegexValidator(REGEX_POP_GROUP_NAME)],
                            help_text=H_POPGROUP)
    description = models.CharField(
        'Description',
        max_length=1024,
        blank=True)
    date_created = models.DateTimeField('Date Created',
                                        auto_now_add=True)
    date_modified = models.DateTimeField('Date Modified',
                                         auto_now=True)

    def __unicode__(self):
        return force_unicode(self.name)

    class Meta:
        app_label = 'configuration'
        db_table = 'base_popgroup'
        verbose_name = 'Pop Group'

    class SpectrumMeta:
        allow_delete = True


class Pop(HistoryModel):
    pop = models.AutoField('id',
                           primary_key=True,
                           db_column='pop_id')
    ihms_pop = models.ForeignKey(
        IhmsPop,
        verbose_name="Pop",
        related_name='ihmspop_set',
        help_text=H_IHMSPOP,
        blank=True,
        null=True)
    pop_name = models.CharField('Pop name',
                                max_length=63,
                                unique=True,
                                validators=[RegexValidator(REGEX_POP_NAME)],
                                help_text=H_POPNAME)
    popgroup = models.ManyToManyField(
        'PopGroup',
        related_name="popgroup_set",
        blank=True)
    probeagent = models.ManyToManyField('ProbeAgent',
                                        through='PopProbeAgentConfig',
                                        related_name='probeagent_set')
    rttserver = models.ForeignKey(
        'ProbeAgent', on_delete=models.SET_NULL,
        related_name='rtt_server_set',
        blank=True,
        null=True,
        help_text=H_RTT_SERVER)
    pktlossserver = models.ManyToManyField(
        'ProbeAgent',
        related_name='pktloss_server_set',
        blank=True,
        help_text=H_PKTLOSS_SERVER)
    description = models.CharField('Description',
                                   max_length=1024, blank=True, null=True)
    date_created = models.DateTimeField('Date Created',
                                        auto_now_add=True)
    date_modified = models.DateTimeField('Date Modified',
                                         auto_now=True)
    pktloss_threshold = models.FloatField("Pktloss Threshold",
                                          blank=True,
                                          null=True,
                                          validators=[MinValueValidator(0), MaxValueValidator(100)],
                                          help_text=H_PKTLOSS)
    cost = models.FloatField("Cost",
                             blank=True,
                             null=True,
                             validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
                             help_text=H_COST)
    enable_gslb = models.SmallIntegerField("Enable GSLB",
                                           null=True,
                                           blank=True,
                                           choices=BOOL_TYPES,
                                           help_text=H_ENABLE_GSLB_POP)
    status = models.PositiveSmallIntegerField(default=0, editable=False, choices=POP_STATUS)
    time_deployed = models.DateTimeField(editable=False, null=True)
    obj_state = models.BooleanField("State", editable=False, default=True)
    enable_cname_latency = models.SmallIntegerField(
        choices=SELECT_TYPES,
        blank=True,
        null=True,
        help_text=H_POP_ENABLE_CNAME_LATENCY
    )
    auto_probe = models.BooleanField(default=False)


    class Meta:
        app_label = 'configuration'
        db_table = 'base_pop'
        verbose_name = 'Pop'
        ordering = ['ihms_pop', 'pop_name']

    class SpectrumMeta:
        allow_delete = True
        keep_latest_change_action_id = True
        log_diff_skip_fields = ['status']

    def generate_new_customer_system_name(self):
        """
        return next indexed system name for customer system, for example clb my infra customer
        """
        system_objs = System.all_objects.filter(pop=self).order_by('-system_name')  # s999
        if not system_objs.exists():
            nex_system_name = 's0'
        else:
            system_obj = system_objs[0]
            cur_max = system_obj.system_name[1:len(system_obj.system_name)]  # 999
            nex_system_name = 's' + str(int(cur_max) + 1)

        return nex_system_name

    def create_new_customer_system(self, request):
        try:
            nex_system_name = self.generate_new_customer_system_name()
            system_obj = System(pop=self, system_name=nex_system_name)
            system_obj.save(request=request)
            return system_obj
        except Exception, e:
            log_error(request, str(e), e)
            raise e

    def delete(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        is_clb = self.is_clb_pop()
        self.delete_related(request=request)
        if is_clb:
            super(Pop, self).delete()
        else:
            self.obj_state = 0
            self.save(request=request)

    def __unicode__(self):
        return self.get_popname()

    def get_popname(self):
        if self.ihms_pop:
            return '%s' % (self.ihms_pop.pop_code)
        else:
            if self.obj_state == 0:
                return '%s:%s' % (self.pop_name.upper(), 'Deleted')
            else:
                return '%s' % (self.pop_name.upper())

    def save(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        if self.pk and self.is_modifiable():
            self.status = 0

        super(Pop, self).save(request=request)

        if self.pop_name == "" and self.ihms_pop is None:
            title = "[Spectrum] Base name validation error"
            if is_ihms_sync_running():
                log_error(request, 'ihms sync running. POP name is Empty', None, None, title)
            else:
                log_error(request, 'POP name is Empty', None, None, title)

            raise ValidationError('POP name is Empty')

    def is_modifiable(self):
        '''if pop deploy status is 'pending' or 'locked', it won't be modifiable
        '''
        self.status = int(self.status)
        if self.status == 1 or self.status == 3:  # pending to stage, pending to production
            # if self.obj_state != 0 and settings.DEBUG and self.get_timeout():
            # this generally not happen at production servers where be_config running all the time.
            # But in dev environment where be_config not running, this needs to be accounted.
            # return True
            # else:
            return False
        else:
            return True

    def get_status(self):
        if self.obj_state == 0:
            return 'Deleted'
        else:
            return self.get_deploy_status()

    def get_related_zone_deploy_status_text(self):
        msg = ''

        is_related_zone_stage_pending, is_related_zone_production_pending, zone_deploy_status, deploy_failed, failed_zones, failed_clb_domains = self.has_related_clb_zone_deploy_failed()

        if zone_deploy_status < 0:  # commented code block because long text cropped into iframe at aurora
            msg = "(related zone deploy failed)"

        if self.is_related_clb_zone_domain_pending():  # commented code block because long text cropped into iframe at aurora
            msg = "(related zone deploy pending)"
        return msg

    def get_deploy_status(self):
        return POP_STATUS[self.status][1]

    def get_deploy_status_text(self):
        msg = 'unknown'
        is_related_zone_stage_pending, is_related_zone_production_pending, \
        zone_deploy_status, deploy_failed, failed_zones, failed_clb_domains = self.has_related_clb_zone_deploy_failed()
        if self.status < 0:
            if self.status == -2:
                msg = 'Failed (to staging server)'
            if self.status == -4:
                msg = 'Failed (to production)'
        else:
            if self.status == 0:
                if not self.time_deployed:
                    msg = 'New'
                else:
                    msg = 'Modified'

                if zone_deploy_status < 0:
                    msg += " (related zone deploy failed)"
            if self.status == 1 or self.status == 3:
                if self.get_timeout():
                    if self.status == 1:
                        msg = 'Failed (timeout) (to staging server)'
                    else:
                        msg = 'Failed (timeout) (to production)'
                else:
                    msg = 'pending'

                if zone_deploy_status < 0:
                    msg += " (related zone deploy failed)"
            if self.status == 2:
                msg = 'On staging server'

                if self.is_related_clb_zone_domain_stage_pending():
                    msg += " (related zone deploy pending)"
                if zone_deploy_status < 0:
                    msg += " (related zone deploy failed)"
            if self.status == 4:
                msg = 'Production'

                if self.is_related_clb_zone_domain_production_pending():
                    msg += " (related zone deploy pending)"
                if zone_deploy_status < 0:
                    msg += " (related zone deploy failed)"
        return msg

    def is_clb_pop(self):
        from spectrum_api.configuration.models.clb import CustomerContractPop

        clb_customer_pops = CustomerContractPop.all_objects.filter(pop=self)
        if clb_customer_pops.exists():
            return True
        else:
            return False

    def get_related_clb_customer(self):
        from spectrum_api.configuration.models.clb import CustomerContractPop

        clb_customer_pops = CustomerContractPop.all_objects.filter(pop=self)
        if clb_customer_pops.exists():
            return clb_customer_pops[0].customer
        else:
            return None

    def get_vips(self):
        systems = System.objects.filter(pop=self).values('system')
        hosts = Host.objects.filter(system__in=systems).values('host')
        vips = Vip.objects.filter(host__in=hosts)
        return vips

    def set_pkloss_servers(self, request, pop_arr):
        pakloss_agent_arr = []
        for p_obj in pop_arr:
            pakloss_server_set = p_obj.pktlossserver.select_related('pakloss_server_set')
            for obj in pakloss_server_set:
                if not obj in pakloss_agent_arr:
                    pakloss_agent_arr.append(obj)

        for obj in pakloss_agent_arr:
            self.pktlossserver.add(obj)
        self.save(request=request)

    def mapping_probeagent_for_clb_region_pop(self, request, pop_arr, primary_pop):
        probeagent_arr = []
        pri_agent_for_pop = None
        for p_obj in pop_arr:
            probeagent_set = p_obj.probeagent.select_related('probeagent_set')

            try:
                agent_config = PopProbeAgentConfig.all_objects.get(pop=primary_pop, primary=True)
                pri_agent_for_pop = agent_config.probeagent
            except PopProbeAgentConfig.DoesNotExist:
                pri_agent_for_pop = None

            for obj in probeagent_set:
                if not obj in probeagent_arr:
                    probeagent_arr.append(obj)

        for obj in probeagent_arr:
            if obj == pri_agent_for_pop and pri_agent_for_pop is not None:
                popagentconf = PopProbeAgentConfig(pop=self, probeagent=obj, primary=True)
            else:
                popagentconf = PopProbeAgentConfig(pop=self, probeagent=obj)
            popagentconf.save(request=request)

    def _get_snapshot_relation(self, is_status=None):
        from spectrum_api.dna.models.domain import BasePopDNSZoneRelation
        snapshot_zones = BasePopDNSZoneRelation.objects.filter(pop=self)
        if is_status:
            if hasattr(is_status, "__iter__"):
                snapshot_zones = snapshot_zones.filter(zone__status__in=is_status)
            else:
                snapshot_zones = snapshot_zones.filter(zone__status=is_status)

        return snapshot_zones

    def get_related_clb_zones(self):
        vips = self.get_vips()
        clb_zonelist = []
        if self.is_clb_pop():
            for vip in vips:
                clb_domains = vip.get_clb_domains()
                for clb_domain in clb_domains:
                    clb_zone = clb_domain.clb_dns_zone
                    if clb_zone not in clb_zonelist:
                        clb_zonelist.append(clb_zone)

            snapshot_zones = self._get_snapshot_relation()
            if snapshot_zones.exists():
                snapshot_zone_ids = [s_zone.zone for s_zone in snapshot_zones]
                clb_zonelist = list(set(clb_zonelist + snapshot_zone_ids))
        return clb_zonelist

    def get_related_pending_clb_zones(self):
        vips = self.get_vips()
        clb_zonelist = []
        if self.is_clb_pop():
            for vip in vips:
                clb_domains = vip.get_clb_domains()
                for clb_domain in clb_domains:
                    clb_zone = clb_domain.clb_dns_zone
                    zone_status = int(clb_zone.status)
                    clb_zone_name = clb_domain.clb_dns_zone.domain_name
                    if clb_zone_name not in clb_zonelist:
                        if zone_status == 1 or zone_status == 3:
                            clb_zonelist.append(clb_zone_name)

            snapshot_zones = self._get_snapshot_relation(is_status=[1, 3])
            if snapshot_zones.exists():
                snapshot_zone_names = [s_zone.zone.domain_name for s_zone in snapshot_zones]
                clb_zonelist = list(set(clb_zonelist+snapshot_zone_names))

        return ','.join(clb_zonelist)

    def get_related_stage_pending_clb_zones(self):
        vips = self.get_vips()
        clb_zonelist = []
        if self.is_clb_pop():
            for vip in vips:
                clb_domains = vip.get_clb_domains()
                for clb_domain in clb_domains:
                    clb_zone = clb_domain.clb_dns_zone
                    zone_status = int(clb_zone.status)
                    clb_zone_name = clb_domain.clb_dns_zone.domain_name
                    if clb_zone_name not in clb_zonelist:
                        if zone_status == 1:
                            clb_zonelist.append(clb_zone_name)

            snapshot_zones = self._get_snapshot_relation(is_status=1)
            if snapshot_zones.exists():
                snapshot_zone_names = [s_zone.zone.domain_name for s_zone in snapshot_zones]
                clb_zonelist = list(set(clb_zonelist+snapshot_zone_names))

        return ','.join(clb_zonelist)

    def get_related_push_failed_clb_zones(self):
        vips = self.get_vips()
        clb_zonelist = []
        if self.is_clb_pop():
            for vip in vips:
                clb_domains = vip.get_clb_domains()
                for clb_domain in clb_domains:
                    clb_zone = clb_domain.clb_dns_zone
                    zone_status = int(clb_zone.status)
                    clb_zone_name = clb_domain.clb_dns_zone.domain_name
                    if clb_zone_name not in clb_zonelist:
                        if zone_status < 0:
                            clb_zonelist.append(clb_zone_name)

            snapshot_zones = self._get_snapshot_relation(is_status=[-2, -4])
            if snapshot_zones.exists():
                snapshot_zone_names = [s_zone.zone.domain_name for s_zone in snapshot_zones]
                clb_zonelist = list(set(clb_zonelist+snapshot_zone_names))

        return ','.join(clb_zonelist)

    def check_auto_probe_condition(self):
        if self.pk:
            from spectrum_api.configuration.models.probeagent import ProbeAgent

            systems = System.objects.filter(pop=self) \
                                    .filter(Q(enable_gslb=1) | Q(enable_gslb__isnull=True)).values('system')
            hosts = Host.objects.filter(system__in=systems, role__role_name='PROBE') \
                                .filter(Q(enable_gslb=1) | Q(enable_gslb__isnull=True)).values('host')
            vips = Vip.objects.filter(host__in=hosts, probeconfigs__name='probe_health') \
                              .filter(Q(enable_gslb=1) | Q(enable_gslb__isnull=True))

            vips.query.group_by = ['host_id']
            vips_id = [obj.vip for obj in vips]
            probeagents = ProbeAgent.objects.filter(vip__in=vips_id)

            if probeagents.count() > 1:
                return True

        return False

    def check_auto_probeagents(self, id, base_type):
        if self.pk:
            from spectrum_api.configuration.models.probeagent import ProbeAgent

            try:
                systems = System.objects.filter(pop=self) \
                                        .filter(Q(enable_gslb=1) | Q(enable_gslb__isnull=True)).values('system')
                if base_type == 'system':
                    systems = systems.exclude(pk=int(id))
                hosts = Host.objects.filter(system__in=systems, role__role_name='PROBE') \
                                    .filter(Q(enable_gslb=1) | Q(enable_gslb__isnull=True)).values('host')
                if base_type == 'host':
                    hosts = hosts.exclude(pk=int(id))
                vips = Vip.objects.filter(host__in=hosts, probeconfigs__name='probe_health') \
                                  .filter(Q(enable_gslb=1) | Q(enable_gslb__isnull=True))
                if base_type == 'vip':
                    vips = vips.exclude(pk=int(id))

                vips.query.group_by = ['host_id']
                vips_id = [obj.vip for obj in vips]
                probeagents = ProbeAgent.objects.filter(vip__in=vips_id)

                if probeagents.count() < 2:
                    return False
            except:
                pass

        return True

    def is_related_clb_zone_pending(self):
        clb_zonelist = self.get_related_clb_zones()
        for clb_zone in clb_zonelist:
            zone_status = int(clb_zone.status)
            if zone_status == 1 or zone_status == 3:
                return True
        return False

    def is_related_clb_zone_domain_stage_pending(self):
        clb_zonelist = self.get_related_clb_zones()
        for clb_zone in clb_zonelist:
            clb_zone_deploy_status, failed_clb_domains = clb_zone.get_deploy_status()
            # zone_status = int(clb_zone.status)
            if clb_zone_deploy_status == 1:
                return True
        return False

    def is_related_clb_zone_domain_production_pending(self):
        clb_zonelist = self.get_related_clb_zones()
        for clb_zone in clb_zonelist:
            clb_zone_deploy_status, failed_clb_domains = clb_zone.get_deploy_status()
            # zone_status = int(clb_zone.status)
            if clb_zone_deploy_status == 3:
                return True
        return False

    def is_related_clb_zone_domain_pending(self):
        clb_zonelist = self.get_related_clb_zones()
        for clb_zone in clb_zonelist:
            clb_zone_deploy_status, failed_clb_domains = clb_zone.get_deploy_status()
            # zone_status = int(clb_zone.status)
            if clb_zone_deploy_status == 1 or clb_zone_deploy_status == 3:
                return True
        return False

    def is_related_clb_zone_push_failed(self):
        clb_zonelist = self.get_related_clb_zones()
        for clb_zone in clb_zonelist:
            zone_status = int(clb_zone.status)
            if zone_status < 0:
                return True
        return False

    def has_related_clb_zone_deploy_failed(self):
        '''return is_related_zone_stage_pending,is_related_zone_production_pending,zone_deploy_status,deploy_failed,failed_zones,failed_clb_domains
        '''
        zone_deploy_status = 4
        deploy_failed = False
        stage_deploy_failed = False
        clb_zonelist = self.get_related_clb_zones()
        failed_clb_domains = []
        failed_zones = []
        is_related_zone_stage_pending = False
        is_related_zone_production_pending = False

        for clb_zone in clb_zonelist:
            zone_deploy_status = 4  # initailize with every loop
            clb_zone_deploy_status, failed_clb_domains = clb_zone.get_deploy_status()
            zone_status = int(clb_zone_deploy_status)

            if zone_deploy_status > zone_status:
                zone_deploy_status = zone_status
            if zone_deploy_status < 0:
                deploy_failed = True
                failed_zones.append(clb_zone.domain_name)
            if zone_status == -2:
                stage_deploy_failed = True

            if zone_status == 1:
                is_stage_pending = True
            if zone_status == 3:
                is_production_pending = True
        if stage_deploy_failed:
            zone_deploy_status = -2

        return is_related_zone_stage_pending, is_related_zone_production_pending, zone_deploy_status, deploy_failed, failed_zones, failed_clb_domains

    def get_timeout(self):
        # compare time
        right_now = datetime.now()
        date_updated = self.date_modified
        # if settings.DEBUG:
        # time2compare = timedelta(minutes=DEV_LOCK_TIMEOUT)
        # else:
        time2compare = timedelta(minutes=TIMEOUT)

        timeout = False
        if (right_now - date_updated) > time2compare:
            timeout = True

        return timeout

    def getGslbStatus(self):
        if self.enable_gslb == 1:
            return 'UP'
        elif self.enable_gslb == 0:
            return 'DOWN'
        else:
            return 'UP'

    def releaseFromIHMS(self, request, ihms_pop):
        self.ihms_pop = None
        self.pop_name = ihms_pop.pop_code
        self.save(request=request)

    def clean(self):
        from spectrum_api.dna.models.domain import DomainVip, DomainEdge

        if self.pop_name:
            try:
                self.pop_name = self.pop_name.upper()
                pop_name = Pop.all_objects.get(pop_name=self.pop_name)
            except:
                pop_name = None

            if pop_name:
                if self.pk and int(pop_name.pk) != int(self.pk):
                    raise ValidationError({"pop_name":
                                               [_("This pop name is already exist")]})
                if not self.pk:
                    raise ValidationError({"pop_name":
                                               [_("This pop name is already exist")]})

            try:
                self.pop_name = self.pop_name.upper()
                pop_name = IhmsPop.objects.get(pop_code=self.pop_name)
            except:
                pop_name = None
            if pop_name:
                raise ValidationError({"pop_name":
                                           [_("This pop name is already exist as ihms_pop")]})

        if self.pk and not self.is_modifiable():
            raise ValidationError({'__all__': [_(
                "This Pop is locked(pending status). Please wait until the lock is released. status: %s." % (
                self.get_deploy_status()))]})

        if self.pk and self.is_clb_pop():
            if self.is_related_clb_zone_pending():
                raise ValidationError({'__all__': [_(
                    "Related zone '%s' is locked(pending status). Please wait until the lock is released." % (
                    self.get_related_pending_clb_zones()))]})

        # if exist related domain, this pop must have rttserver
        if not self.rttserver:
            system_list = System.objects.filter(pop=self)
            for system in system_list:
                host_list = Host.objects.filter(system=system)
                for host in host_list:
                    vip_list = Vip.objects.filter(host=host)
                    for vip in vip_list:
                        if DomainVip.objects.filter(vip=vip).exists():
                            raise ValidationError({"rttserver":
                                                       ["This pop must have rttserver cause\
                                related vip used by domain"]})
                        for edge in vip.edge.all():
                            if DomainEdge.objects.filter(edge=edge).exists():
                                raise ValidationError({"rttserver":
                                                           ["This pop must have rttserver cause\
                                    related vip used by domain"]})

    def is_deletable(self):
        '''method should be allowd from prism_fe,aurora_fe,prism_api,aurora_api
        Auroraui-818
        '''
        if self.is_clb_pop():
            vips = self.get_vips()
            if vips.exists():
                return False
            else:
                if not self.time_deployed and int(self.status) == 0:
                    return True
                elif int(self.status) == 4:
                    return True
                else:
                    return False
        else:
            # from spectrum_api.configuration.models.clb import CustomerContractPop
            # DSP_DEPS_LIMIT = 1
            #
            # cpquery = CustomerContractPop.objects.filter(pop=self)
            # if cpquery.exists():
            # return False
            if System.objects.filter(pop=self).exists():
                return False
            if self.popgroup.all().exists():
                return False
            else:
                return True

    def get_related_objects(self):
        # from spectrum_api.configuration.models.base import PopProbeAgentConfig,PopPacketlossProbeAgentConfig,PopUplinkProbeConfigs
        from spectrum_api.configuration.models.clb import CustomerContractPop, CLBLocationRegionBasePop

        DSP_DEPS_LIMIT = 10
        return ((System, System.objects.filter(pop=self)[:DSP_DEPS_LIMIT]),
                (PopGroup, self.popgroup.all()[:DSP_DEPS_LIMIT]),
                (PopProbeAgentConfig, PopProbeAgentConfig.objects.filter(pop=self)[:DSP_DEPS_LIMIT]),
                (
                PopPacketlossProbeAgentConfig, PopPacketlossProbeAgentConfig.objects.filter(pop=self)[:DSP_DEPS_LIMIT]),
                (PopUplinkProbeConfigs, PopUplinkProbeConfigs.objects.filter(pop=self)[:DSP_DEPS_LIMIT]),
                (CustomerContractPop, CustomerContractPop.all_objects.filter(pop=self)[:DSP_DEPS_LIMIT]),
                (CLBLocationRegionBasePop, CLBLocationRegionBasePop.objects.filter(pop=self)[:DSP_DEPS_LIMIT]),)

    def delete_related(self, request):
        try:
            # from spectrum_api.configuration.models.base import PopProbeAgentConfig,PopPacketlossProbeAgentConfig,PopUplinkProbeConfigs
            from spectrum_api.configuration.models.clb import CustomerContractPop, CLBLocationRegionBasePop
            #
            pop_probeagents = PopProbeAgentConfig.objects.filter(pop=self)
            pop_packetloss_probeagents = PopPacketlossProbeAgentConfig.objects.filter(pop=self)
            pop_uplink_probes = PopUplinkProbeConfigs.objects.filter(pop=self)
            contract_pops = CustomerContractPop.all_objects.filter(pop=self)
            # pop_probeagents.delete()
            for pop_probeagent in pop_probeagents:
                pop_probeagent.delete(request=request)

            for pop_packetloss_probeagent in pop_packetloss_probeagents:
                pop_packetloss_probeagent.delete(request=request)

            for pop_uplink_probe in pop_uplink_probes:
                pop_uplink_probe.delete(request=request)

            for contract_pop in contract_pops:
                contract_pop.delete(request=request)

            for clb_pop in CLBLocationRegionBasePop.objects.filter(pop=self):
                clb_pop.delete(request=request)

        except Exception, e:
            raise e


class System(HistoryModel):
    system = models.AutoField(primary_key=True,
                              db_column='system_id')
    pop = models.ForeignKey(Pop,
                            db_column='pop_id')
    ihms_system = models.ForeignKey(
        IhmsSystem,
        verbose_name='System',
        db_column='ihms_system_id',
        null=True,
        blank=True,
        help_text=H_SYSTEM)
    system_name = models.CharField('System name',
                                   max_length=63,
                                   validators=[RegexValidator(customersystem_rex)],
                                   help_text=H_CUSTOMER_SYSTEMNAME)
    description = models.CharField(
        'Description',
        max_length=1024,
        blank=True)
    vip = models.ForeignKey('Vip',
                            verbose_name='Server Management IP',
                            blank=True,
                            null=True,
                            help_text=H_SERVER_MANAGE_IP)
    enable_gslb = models.SmallIntegerField(
        null=True,
        blank=True,
        choices=BOOL_TYPES,
        help_text=H_ENABLE_GSLB)
    date_created = models.DateTimeField('Date Created',
                                        auto_now_add=True)
    date_modified = models.DateTimeField('Date Modified',
                                         auto_now=True)
    obj_state = models.BooleanField("State", editable=False, default=True)

    class Meta:
        app_label = 'configuration'
        unique_together = ('system_name', 'pop')
        db_table = 'base_system'
        verbose_name = 'System'
        ordering = ['pop', 'system_name', 'ihms_system']

    class SpectrumMeta:
        allow_delete = True
        keep_latest_change_action_id = True

    def delete(self, *args, **kwargs):
        request = kwargs.pop('request', None)

        if self.pop.is_clb_pop():
            self.pop.status = 0
            self.pop.save(request=request)

        self.delete_related(request=request)
        super(System, self).delete()

    def clean(self):
        # if self._adding:
        if self.pk is None:
            if self.getsystembyfullname():
                raise ValidationError({'system_name': [_('this system name already exist.')]})
        else:
            if self.pop.is_clb_pop():
                if not self.pop.is_modifiable():
                    raise ValidationError(
                        "This system's CLB pop is pending status. Please wait until the lock is released.")

            if self.ihms_system:
                pass
            else:
                pop = Pop.objects.filter(pk=self.pop.pk)
                if pop:
                    system_name = System.all_objects.filter(system_name=self.system_name, pop=pop[0])
                    if system_name and self.pk and not int(self.pk) in [obj.pk for obj in system_name]:
                        raise ValidationError(
                            {'system_name': [_('modification duplicated. this system name already exist.')]})

                ihmspop = IhmsPop.objects.filter(pop_code=self.pop)
                if ihmspop:
                    ihmssystems = IhmsSystem.objects.filter(system_name=self.system_name, pop=int(ihmspop[0].pk))
                else:
                    ihmssystems = None

                if ihmssystems is not None and ihmssystems.exists():
                    systems = System.objects.filter(ihms_system=ihmssystems[0])
                else:
                    systems = None
                if systems is not None and systems.exists():
                    raise ValidationError(
                        {'system_name': [_('modification duplicated. this system name already exist as ihms system.')]})

    def save(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        super(System, self).save(request=request)
        if self.pk:
            try:
                if self.pop.is_clb_pop():
                    self.pop.status = 0
                    self.pop.save(request=request)
            except:
                pass
        if self.system_name is None and self.ihms_system is None:
            title = "[Spectrum] Base name validation error"
            if is_ihms_sync_running():
                log_error(request, 'ihms sync running. SYSTEM name is Empty', None, None, title)
            else:
                log_error(request, 'SYSTEM name is Empty', None, None, title)

            raise ValidationError('SYSTEM name is Empty')

    def __unicode__(self):
        if self.system_name:
            return '%s.%s' % (self.system_name, self.pop)
        else:
            return '%s' % self.ihms_system
            # if self.ihms_system:
            # return '%s' % self.ihms_system
            # else:
            #    return '%s.%s' % (self.system_name,self.pop)

    def getGslbStatus(self):
        if self.enable_gslb == 1:
            return 'UP'
        elif self.enable_gslb == 0:
            return 'DOWN'
        else:  # default
            return 'UP'

    def get_status_enabled(self):
        '''used by mproxy general purposes defined by prism 2.0'''
        if self.enable_gslb == 1:
            return 'enabled'
        elif self.enable_gslb == 0:
            return 'disabled'
        else:  # default value
            return 'enabled'

    def getsystembyfullname(self):
        from spectrum_api.shared_components.utils.common import getsystemsbysystemname

        try:
            return getsystemsbysystemname(self.get_fullsystemname())
        except:
            return None

    def get_fullsystemname(self):
        if self.ihms_system:
            return '%s' % self.ihms_system
        else:
            return '%s.%s' % (self.system_name, self.pop)

    def hasHostName(self, hostname):
        hosts = Host.objects.filter(system=self.pk)
        for host in hosts:
            if host.ihms_host:
                host_name = host.ihms_host.host_name
            else:
                host_name = host.host_name

            if host_name == hostname:
                return True

        return False

    def gethosts(self):
        hosts = Host.objects.filter(system=self.pk)
        return hosts

    def getvips(self):
        vips = Vip.objects.filter(host__in=self.gethosts().values('host'))
        return vips

    def generate_new_customer_hostname(self):
        '''return next indexed host name for customer system, for example clb my infra customer
        '''
        host_objs = Host.all_objects.filter(system=self).order_by('-host_name')  # h0
        if not host_objs.exists():
            nex_host_name = 'h0'
        else:
            host_obj = host_objs[0]
            cur_host_max = host_obj.host_name[1:len(host_obj.host_name)]  # 0
            nex_host_name = 'h' + str(int(cur_host_max) + 1)
        return nex_host_name

    def create_new_customer_host(self, request):
        try:
            nex_host_name = self.generate_new_customer_hostname()
            host_obj = Host(system=self, host_name=nex_host_name)
            host_obj.save(request=request)
            return host_obj
        except Exception, e:
            log_error(request, str(e), e)
            raise e

    def releaseFromIHMS(self, request, system_name):
        self.ihms_system = None
        self.system_name = system_name
        self.save(request=request)

    def get_related_objects(self):
        DSP_DEPS_LIMIT = 10
        return ((Host, Host.objects.filter(system=self)[:DSP_DEPS_LIMIT]),)

    def delete_related(self, request):
        try:
            hosts = Host.objects.filter(system=self.pk)
            for host in hosts:
                if host.is_deletable():
                    host.delete_related(request=request)
                    # host.update_history(request,3)
                    host.delete(request=request)
                else:
                    raise Exception("host %s is not deletable." % (host.get_fullhostname()))
        except Exception, e:
            raise e

    def is_deletable(self):
        try:
            vips = self.getvips()
            for vip in vips:
                if vip.is_deletable():
                    pass
                else:
                    return False
        except Exception, e:
            return True
        return True

class Host(HistoryModel):
    host = models.AutoField(primary_key=True,
                            db_column='host_id')
    system = models.ForeignKey(System)
    ihms_host = models.ForeignKey(
        IhmsHost,
        verbose_name='Host',
        help_text=H_HOST,
        blank=True,
        null=True
    )
    host_name = models.CharField('Host name',
                                 max_length=63,
                                 validators=[RegexValidator(customerhost_rex)],
                                 help_text=H_CUSTOMER_HOSTNAME)
    description = models.CharField(
        'Description',
        max_length=1024,
        blank=True)
    date_created = models.DateTimeField('Date Created',
                                        auto_now_add=True)
    date_modified = models.DateTimeField('Date Modified',
                                         auto_now=True)
    enable_gslb = models.SmallIntegerField(
        null=True,
        blank=True,
        choices=BOOL_TYPES,
        help_text=H_ENABLE_GSLB)
    obj_state = models.BooleanField("State", editable=False, default=True)
    role = models.ManyToManyField('Role', through='HostRole')

    def delete(self, *args, **kwargs):
        request = kwargs.pop('request', None)

        if self.system.pop.is_clb_pop():
            self.system.pop.status = 0
            self.system.pop.save(request=request)

        self.delete_related(request=request)
        super(Host, self).delete()

    class Meta:
        app_label = 'configuration'
        db_table = 'base_host'
        unique_together = ('host_name', 'system')
        ordering = ['system', 'ihms_host', 'host_name']

    class SpectrumMeta:
        allow_delete = True
        keep_latest_change_action_id = True

    def clean(self):
        # if self._adding:
        if self.pk is None:
            if self.gethostbyfullname():
                raise ValidationError({'host_name': [_('this host name already exist.')]})
        else:
            if self.system.pop.is_clb_pop():
                if not self.system.pop.is_modifiable():
                    raise ValidationError(
                        "This host's CLB pop is pending status. Please wait until the lock is released.")
            if self.ihms_host:
                pass
            else:
                system = System.objects.filter(pk=self.system.pk)
                if system:
                    host_name = Host.all_objects.filter(host_name=self.host_name, system=system[0])
                    if host_name and self.pk and not int(self.pk) in [obj.pk for obj in host_name]:
                        raise ValidationError(
                            {'host_name': [_('modification duplicated. this host name already exist.')]})

                if self.system.ihms_system:
                    systemname = self.system.ihms_system.system_name
                else:
                    systemname = self.system.system_name
                ihmspop = IhmsPop.objects.filter(pop_code=self.system.pop)
                if ihmspop:
                    ihmssystems = IhmsSystem.objects.filter(system_name=systemname, pop=int(ihmspop[0].pk))
                else:
                    ihmssystems = None

                if ihmssystems is not None and ihmssystems.exists():
                    systems = System.objects.filter(ihms_system=ihmssystems[0])
                else:
                    systems = None

                if ihmssystems is not None and ihmssystems.exists():
                    ihmshosts = IhmsHost.objects.filter(host_name=self.host_name, system=ihmssystems[0])
                else:
                    ihmshosts = None

                if ihmshosts is not None and ihmshosts.exists():
                    hosts = Host.objects.filter(ihms_host=ihmshosts[0])
                else:
                    hosts = None

                if hosts is not None and hosts.exists():
                    raise ValidationError(
                        {'host_name': [_('modification duplicated. this host name already exist as ihms host.')]})

    def save(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        try:
            oid = request.GET.get('system', None)
            if oid:
                self.system = System.objects.get(pk=oid)
            else:
                pass
        except:
            pass

        #moved validation logic before save since transaction middleware is not working.
        if (self.host_name is None or self.host_name == "") and self.ihms_host is None:
            title = "[Spectrum] Base name validation error"
            if is_ihms_sync_running():
                log_error(request, 'ihms sync running. HOST name is None', None, None, title)
            else:
                log_error(request, 'HOST name is Empty', None, None, title)
            raise ValidationError('HOST name data is corrupted. please wait until ihms sync job finished.')

        super(Host, self).save(request=request)
        if self.pk:
            try:
                if self.system.pop.is_clb_pop():
                    self.system.pop.status = 0
                    self.system.pop.save(request=request)
            except:
                pass

    def __unicode__(self):
        if self.ihms_host:
            return '%s' % (self.ihms_host)
        else:
            return '%s-%s' % (self.host_name, self.system)

    def get_fullhostname(self):
        if self.ihms_host:
            return '%s' % (self.ihms_host)
        else:
            return '%s-%s' % (self.host_name, self.system.get_fullsystemname())

    def gethostbyfullname(self):
        from spectrum_api.shared_components.utils.common import gethostsbyhostname

        try:
            return gethostsbyhostname(self.get_fullhostname())
        except:
            return None

    def getGslbStatus(self):
        if self.enable_gslb == 1:
            return 'UP'
        elif self.enable_gslb == 0:
            return 'DOWN'
        else:
            return 'UP'  # self.system.getGslbStatus()

    def get_status_enabled(self):
        '''used by mproxy general purposes defined by prism 2.0'''
        if self.enable_gslb == 1:
            return 'enabled'
        elif self.enable_gslb == 0:
            return 'disabled'
        else:  # default value
            return 'enabled'  # self.system.get_status_enabled()

    def releaseFromIHMS(self, request, host_name):
        self.ihms_host = None
        self.host_name = host_name
        self.save(request=request)

    def getvips(self):
        vips = Vip.objects.filter(host=self.pk)
        return vips

    def moveRolesTo(self, request, new_host):
        hostroles = HostRole.objects.filter(host=self)
        if hostroles.exists():
            new_hostroles = HostRole.objects.filter(host=new_host)

            if new_hostroles:
                pass
            else:
                for hostrole in hostroles:
                    hostrole.host = new_host
                    hostrole.update_history(request, 2)
                    hostrole.save()

    def is_deletable(self):
        try:
            vips = Vip.objects.filter(host=self.pk)
            # host_roles = HostRole.objects.filter(host=self.pk)
            # if host_roles:
            # return False
            for vip in vips:
                if vip.is_deletable():
                    pass
                else:
                    return False
        except Exception, e:
            return True
        return True


    def get_related_objects(self):
        DSP_DEPS_LIMIT = 10
        host_roles = HostRole.objects.filter(host=self)
        return ((HostRole, HostRole.objects.filter(host=self)),
                (Vip, Vip.objects.filter(host=self)[:DSP_DEPS_LIMIT]),)

    def delete_related(self, request):
        try:
            host_roles = HostRole.objects.filter(host=self)
            if host_roles.exists():
                for hostrole in host_roles:
                    hostrole.update_history(request, 3)
                host_roles.delete()
            vips = Vip.objects.filter(host=self.pk)
            for vip in vips:
                if vip.is_deletable():
                    vip.delete_related(request=request)
                    # vip.update_history(request,3)
                    vip.delete(request=request)
                else:
                    raise Exception("vip %s is not deletable." % (vip.get_fullvipname()))
        except Exception, e:
            raise e

    def get_next_vip_name(self):
        vip_obj = Vip.all_objects.filter(host=self).order_by('-vip_name')# h0
        if not vip_obj.exists():
            next_vip_name = 'i0'
            return 'i0'

        name_arr = []
        for obj in vip_obj:
            try:
                vip_num = int(obj.vip_name[1:len(obj.vip_name)])
            except:
                continue
            name_arr.append(vip_num)
        try:
            name_arr.sort()
            # cur_vip_max = vip_obj[0].vip_name[1:len(vip_obj[0].vip_name)] # 0
            cur_vip_max = max(name_arr)# 0
            next_vip_name = 'i' + str(int(cur_vip_max) + 1)
        except:
            next_vip_name = 'i0'
        return next_vip_name

class Edge(HistoryModel):
    edge_id = models.AutoField(primary_key=True)
    name = models.CharField('Name',
                            unique=True,
                            max_length=63,
                            validators=[RegexValidator(edge_name_rex)],
                            help_text=H_EDGE_NAME)
    description = models.CharField(
        'Description',
        max_length=1024,
        blank=True,
        null=True)
    date_created = models.DateTimeField('Date Created',
                                        auto_now_add=True)
    date_modified = models.DateTimeField('Date Modified',
                                         auto_now=True)
    enable_gslb = models.SmallIntegerField(
        null=True,
        blank=True,
        choices=BOOL_TYPES,
        help_text=H_ENABLE_GSLB)

    def __unicode__(self):
        return '%s' % (self.name)

    def is_deletable(self):
        from spectrum_api.dna.models.domain import DomainEdge

        vips = Vip.objects.filter(edge=self)
        domainedges = DomainEdge.objects.filter(edge=self)
        if vips.exists():
            return False
        elif domainedges.exists():
            return False
        else:
            return True

        return True

    class Meta:
        app_label = 'configuration'
        db_table = 'base_edge'
        ordering = ['name']

    class SpectrumMeta:
        allow_delete = True
        keep_latest_change_action_id = True

    def get_related_items(self):
        from spectrum_api.dna.models.domain import Domain, DomainEdge
        from spectrum_api.wpo.models.wpo import WPOCluster

        return ((Vip, Vip.objects.filter(edge=self)[:DSP_DEPS_LIMIT]),
                (Domain, DomainEdge.objects.filter(edge=self)[:DSP_DEPS_LIMIT]),
                (WPOCluster, WPOCluster.objects.filter(edge=self)[:DSP_DEPS_LIMIT]),
        )

    def get_required_probeconfigs(self, domain=None, probe=None):
        ''' basically return domainedgs's probe which overrides domain's probe.
        if domainedge's probe is none, then return domain's probe.
        '''
        from spectrum_api.dna.models.domain import Domain, DomainEdge

        if probe:
            probeconfigs = BaseProbeConfig.objects.filter(pk=probe.pk)
        elif domain:
            try:
                domainedge = DomainEdge.objects.get(edge=self, domain=domain)
                if domainedge.probe:
                    probeconfigs = BaseProbeConfig.objects.filter(pk=domainedge.probe.pk)
                elif domain.probe:
                    probeconfigs = BaseProbeConfig.objects.filter(pk=domain.probe.pk)
                else:
                    probeconfigs = BaseProbeConfig.objects.none()
            except:
                domainedge = None
                if domain.probe:
                    probeconfigs = BaseProbeConfig.objects.filter(pk=domain.probe.pk)
                else:
                    probeconfigs = BaseProbeConfig.objects.none()

        else:
            mydomainedges = DomainEdge.objects.filter(edge=self)
            probelist = []
            for domainedge in mydomainedges:
                if domainedge.probe:
                    if domainedge.probe.pk not in probelist:
                        probelist.append(domainedge.probe.pk)
                elif domainedge.domain.probe:
                    if domainedge.domain.probe.pk not in probelist:
                        probelist.append(domainedge.domain.probe.pk)

            # domainprobes = self.get_edge_domains().values('probe').distinct()
            probeconfigs = BaseProbeConfig.objects.filter(pk__in=probelist)
        return probeconfigs

    def has_mandatory_domain_probeconfigs(self, request, domain, required_probe=None):
        return self.check_domainedge_probe_constraint(request, domain, required_probe)

    def check_domainedge_probe_constraint(self, request, domain, required_probe=None, force_update=False):
        errmsg = ''
        msglist = []
        is_edgeprobe_valid = True

        if self.pk:
            from spectrum_api.dna.models.domain import Domain, DomainEdge

            if required_probe is None:
                # probe has been removed for domain - vip pair.
                try:
                    domainedge = DomainEdge.objects.get(domain=domain, edge=self)
                    if domainedge.probe:
                        required_probe = domainedge.probe
                    elif domain.probe:
                        required_probe = domainedge.probe
                except:
                    # required_probe = self.get_required_domainvip_probeconfig(domain)
                    if domain.probe:
                        required_probe = domain.probe

            probeconfigs = self.get_required_probeconfigs(domain, required_probe)
            vips = self.get_vips()
            for vip in vips:
                is_vipprobe_valid, check_message = vip.check_required_probeconfigs(request, probeconfigs, force_update)

                if not is_vipprobe_valid:
                    is_edgeprobe_valid = False
                    msglist.append(check_message)

            errmsg = '\r\n'.join(msglist)

        if force_update:
            return True, errmsg
        else:
            return is_edgeprobe_valid, errmsg

    def add_required_probeconfigs(self, request):
        if self.pk:
            probeconfigs = self.get_required_probeconfigs()
            vips = self.get_vips()
            for vip in vips:
                vip.add_required_probeconfigs(request, probeconfigs)

    def get_probe_configs(self):
        if self.pk:
            vips = self.get_vips()
            vipprobes = VipProbeConfigs.objects.filter(vip__in=vips.values('vip'))
            probeconfigs = BaseProbeConfig.objects.filter(probeconfig_id__in=vipprobes.values('probe').distinct())
            return probeconfigs
        else:
            return BaseProbeConfig.objects.none()

    def get_vips(self):
        if self.pk:
            return Vip.objects.filter(edge=self)
        else:
            return Vip.objects.none()

    def add_vip(self, request, vip):
        if self.pk:
            vipedges = BaseVipEdge.objects.filter(vip=vip, edge=self)
            if not vipedges.exists():
                vipedge = BaseVipEdge(vip=vip, edge=self)
                vipedge.save(request=request)
                # self.add(vip)
                # self.save(request=request)

    def get_edge_domains(self):
        try:
            from spectrum_api.dna.models.domain import Domain, DomainEdge

            mydomainedges = DomainEdge.objects.filter(edge=self)
            domains = Domain.objects.filter(domain_id__in=mydomainedges.values('domain'))
            return domains
        except Exception, e:
            raise e

    def get_domainedges_with_single_edge(self):
        from spectrum_api.dna.models.domain import Domain, DomainEdge

        domainedges = DomainEdge.objects.values('domain').annotate(edge_count=Count('edge')).filter(edge_count=1)
        mydomainedges = DomainEdge.objects.filter(edge=self).filter(domain__in=domainedges.values('domain'))
        return mydomainedges
        # domains = Domain.objects.filter(domain_id__in=mydomainedges.values('domain'))
        # return domains

class EdgeAll(Model):
    edge_id = models.AutoField(primary_key=True)
    name = models.CharField('Name',
                            unique=True,
                            max_length=63,
                            validators=[RegexValidator(edge_name_rex)],
                            help_text=H_EDGE_NAME)
    description = models.CharField(
        'Description',
        max_length=1024,
        blank=True,
        null=True)
    date_created = models.DateTimeField('Date Created',
                                        auto_now_add=True)
    date_modified = models.DateTimeField('Date Modified',
                                         auto_now=True)
    enable_gslb = models.SmallIntegerField(
        null=True,
        blank=True,
        choices=BOOL_TYPES,
        help_text=H_ENABLE_GSLB)
    pop_count = models.IntegerField()
    vip_count = models.IntegerField()
    domain_count = models.IntegerField()

    def __unicode__(self):
        return '%s' % (self.name)

    class Meta:
        app_label = 'configuration'
        db_table = 'base_edge_all'
        ordering = ['name']

    class SpectrumMeta:
        allow_delete = True


class Vip(HistoryModel):
    vip = models.AutoField(primary_key=True,
                           db_column='vip_id')
    host = models.ForeignKey(Host,
                             related_name='vip_host_set')
    ihms_vip = models.ForeignKey(
        IhmsVip,
        unique=True,
        verbose_name='Vip',
        help_text=H_VIP,
        null=True,
        blank=True)
    vip_name = models.CharField('Vip name',
                                max_length=63,
                                validators=[RegexValidator(customer_vip_rex)],
                                help_text=H_CUSTOMER_VIPNAME)
    vip_addr = models.IPAddressField(
        null=True,
        unique=True,
        help_text=H_CUSTOMER_VIPADDR)
    edge = models.ManyToManyField(
        Edge,
        related_name='edge_set',
        blank=True)
    probeconfigs = models.ManyToManyField(
        'BaseProbeConfig',
        related_name='vip_probeconfig_set',
        through='VipProbeConfigs',
        blank=True,
        null=True)
    mproxy_shield = models.BooleanField(blank=True,
                                        default=False,
                                        help_text=H_MPROXY_SHIELD)
    mproxy_outgoing_ip = models.BooleanField(blank=True,
                                             default=False,
                                             help_text=H_MPROXY_OUTGOING_IP)
    description = models.CharField(
        'Description',
        max_length=1024,
        blank=True)
    date_created = models.DateTimeField('Date Created',
                                        auto_now_add=True)
    date_modified = models.DateTimeField('Date Modified',
                                         auto_now=True)
    enable_gslb = models.SmallIntegerField(
        null=True,
        blank=True,
        choices=BOOL_TYPES,
        help_text=H_ENABLE_GSLB)
    obj_state = models.BooleanField("State", editable=False, default=True)
    vip_alias_name = models.CharField(max_length=255, blank=True)

    def clean(self):
        if MPROXY_ROLE in [str(x) for x in self.host.role.all()]:
            if not self.mproxy_shield:
                mproxy_shields = Vip.all_objects.filter(
                    host=self.host, mproxy_shield=1)
                if mproxy_shields.count() == 0:
                    raise ValidationError({'mproxy_shield':
                                               [_("this vip must have a mproxy_shield value")]})
                elif mproxy_shields.count() == 1:
                    if self == mproxy_shields[0]:
                        raise ValidationError({'mproxy_shield':
                                                   [_("this vip must have a mproxy_shield value")]})
                else:
                    print 'mproxy_shield is more then 1'
        # add
        # if self._adding:
        if self.pk is None:
            import socket, struct
            if self.vip_addr:
                ihmsvip = IhmsVip.objects.filter(ip_id=struct.unpack('>L', socket.inet_aton(self.vip_addr))[0])
                if ihmsvip.exists():
                    if Vip.objects.filter(ihms_vip__in=ihmsvip).exists():
                        raise ValidationError({'vip_addr': [_('this vip addr already exist as ihms vip.')]})
                else:
                    if Vip.objects.filter(vip_addr=self.vip_addr).exists():
                        raise ValidationError({'vip_addr': [_('this vip address already exist in customer vip')]})
                if self.getvipbyfullname():
                    raise ValidationError({'vip_name': [_('this vip name already exist.')]})
            else:
                raise ValidationError({'vip_addr': [_('Should configuration VIP Address.')]})
        # edit
        else:
            if self.host.system.pop.is_clb_pop():
                if not self.host.system.pop.is_modifiable():
                    raise ValidationError(
                        "This vip's CLB pop is pending status. Please wait until the lock is released.")

            host = Host.objects.filter(pk=self.host.pk)
            if host:
                vip_name = Vip.all_objects.filter(vip_name=self.vip_name, host=host[0])
                if vip_name and self.pk and not int(self.pk) in [obj.pk for obj in vip_name]:
                    raise ValidationError({'vip_name': [_('modification duplicated. this vip name already exist.')]})

            if not self.ihms_vip and \
                            Vip.objects.filter(vip_addr=self.vip_addr).exclude(pk=self.pk).count() > 1:
                raise ValidationError({'vip_addr':
                                           [_('this vip address already exist in customer vip')]})

    def delete(self, *args, **kwargs):
        # track = kwargs.pop('track', True)
        # host = self.host
        request = kwargs.pop('request', None)
        if self.host.system.pop.is_clb_pop():
            if self.host.system.pop.is_related_clb_zone_pending():
                raise Exception(_("This pop's CLB DNS Zone '%s' is in pending lock status. Please wait until the lock is released.") %
                self.host.system.pop.get_related_pending_clb_zones())
            self.host.system.pop.status = 0
            self.host.system.pop.save(request=request)
            self.update_related_domain_status_modified(request=request)
        super(Vip, self).delete(*args, **kwargs)

        # if host and host.getvips().count() == 0:
        # system = host.system
        #    host.delete(request=request)
        #    if system and system.gethosts().count() == 0:
        #        system.delete(request=request)

    def save(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        #moved validation logic before save since transaction middleware is not working.
        if (self.vip_name is None or self.vip_name == "") and self.vip_addr == "" and self.ihms_vip is None:
            title = "[Spectrum] Base name validation error"
            if is_ihms_sync_running():
                log_error(request, 'ihms sync running. VIP name is Empty', None, None, title)
            else:
                log_error(request, 'VIP name is Empty', None, None, title)

            raise ValidationError('VIP name is Empty')

        if MPROXY_ROLE in [str(x) for x in self.host.role.all()]:
            if self.mproxy_shield:
                mproxy_shields = Vip.all_objects.filter(
                    host=self.host, mproxy_shield=1)
                if not mproxy_shields.count() > 1:
                    mproxy_shields.update(mproxy_shield=0)

            if self.mproxy_outgoing_ip:
                mproxy_outgoing_ips = Vip.all_objects.filter(
                    host=self.host, mproxy_outgoing_ip=1)
                if mproxy_outgoing_ips.count() > 0:
                    mproxy_outgoing_ips.update(mproxy_outgoing_ip=0)
        try:
            oid = request.GET.get('host', None)
            if oid:
                self.host = Host.objects.get(pk=oid)
            else:
                pass
        except:
            pass
        # check cases of adding/removing vip to/from edge ==> update_domain_config_status
        # requestedEdges = request.POST['edge']
        if self.pk:
            previous_self = Vip.objects.get(pk=self.pk)
            if (str(self) != str(previous_self)):
                # check and change static rule action
                self.change_relate_static_rules(request, str(previous_self), str(self))

            myedges = self.get_edges()
            from spectrum_api.dna.models.domain import DomainEdge, Domain

            mydomainedges = DomainEdge.objects.filter(edge__in=myedges)
            if mydomainedges.exists():
                domains = Domain.objects.filter(domain_id__in=mydomainedges.values('domain'))
                for domain in domains:
                    domain.update_domain_config_status(request=request)

        super(Vip, self).save(request=request)
        if self.pk:
            try:
                if self.host.system.pop.is_clb_pop():
                    self.host.system.pop.status = 0
                    self.host.system.pop.save(request=request)

                    self.update_related_domain_status_modified(request=request)
            except:
                pass



    def get_edges(self):
        # return self.edge.all()
        # from spectrum_api.configuration.models.base import BaseVipEdge
        if self.pk:
            vipedges = BaseVipEdge.objects.filter(vip=self).values('edge')
            edges = Edge.objects.filter(edge_id__in=vipedges)
        else:
            edges = Edge.objects.none()
        return edges

    def get_required_domainedge_probeconfigs(self, domain=None):
        from spectrum_api.dna.models.domain import DomainEdge

        required_probelist = []
        if self.pk:
            if domain is not None:
                edges = self.get_edges()
                domainedges = DomainEdge.objects.filter(domain=domain, edge__in=edges.values('edge_id'))
            else:
                edges = self.get_edges()
                domains = self.get_edge_domains(edges)
                domainedges = DomainEdge.objects.filter(domain__in=domains, edge__in=edges.values('edge_id'))

            for domainedge in domainedges:
                if domainedge.probe and domainedge.probe.pk not in required_probelist:
                    required_probelist.append(domainedge.probe.pk)
                elif domain.probe and domain.probe.pk not in required_probelist:
                    required_probelist.append(domain.probe.pk)

        probeconfigs = BaseProbeConfig.objects.filter(probeconfig_id__in=required_probelist)
        return probeconfigs

    def get_required_domainvip_probeconfigs(self):
        required_probelist = []
        domains = self.get_vip_domains()
        for domain in domains:
            probe = self.get_required_domainvip_probeconfig(domain)
            if probe is not None and probe not in required_probelist:
                required_probelist.append(probe)
        return required_probelist

    def has_mandatory_domain_probeconfig(self, domain, domainvip_probe=None):
        '''
        domainvip_probe is target probe need to be validated, which is not saved with domain-vip yet
        if domainvip_probe parameter present, need to pass domain edge probe validation
        '''
        result = True
        message = ''

        myprobes = self.get_probe_configs()
        required_probe = self.get_required_domainvip_probeconfig(domain, domainvip_probe)
        if required_probe is not None:
            if required_probe in myprobes:
                result = True
            else:
                message = "Vip '%s' does not have probe '%s'" % (str(self), required_probe.name)
                return False, message

        # if not domainvip_prove save, vip may be involved with other domain through edge
        if domainvip_probe is None:
            required_edge_probeconfigs = self.get_required_domainedge_probeconfigs(domain)
            # required_edge_probeconfigs = BaseProbeConfig.objects.filter(probeconfig_id__in=required_probelist)
            required_edge_probeconfigs = required_edge_probeconfigs.exclude(
                probeconfig_id__in=myprobes.values('probeconfig_id'))
            if required_edge_probeconfigs.exists():
                message = "Vip '%s' does not have probe '%s'" % (
                str(self), ','.join(required_edge_probeconfigs.values('name')))
                result = False

        return result, message

    def has_mandatory_domainvip_probeconfig(self, domain, domainvip_probe):
        return self.has_mandatory_domain_probeconfig(domain, domainvip_probe)

    def get_required_domainvip_probeconfig(self, domain, domainvip_probe=None):
        from spectrum_api.dna.models.domain import DomainVip

        required_probe = None

        if self.pk:
            if domainvip_probe:
                required_probe = domainvip_probe
            else:
                if domain is not None:
                    try:
                        domainvip = DomainVip.objects.get(vip=self, domain=domain)
                        if domainvip.probe:
                            required_probe = domainvip.probe
                        elif domain.probe:
                            required_probe = domain.probe
                    except:
                        domainvip = None
                        if domain.probe:
                            required_probe = domain.probe

        return required_probe

    def add_required_domainvip_probeconfig(self, request, domain, required_probe=None):
        if self.pk:
            if required_probe is None:
                required_probe = self.get_required_domainvip_probeconfig(domain)

            if required_probe:
                probevips = VipProbeConfigs.objects.filter(vip=self, probe=required_probe)
                if not probevips.exists():
                    probevip = VipProbeConfigs(vip=self, probe=required_probe)
                    probevip.save(request=request)

    def check_required_probeconfigs(self, request, probeconfigs, force_update=False):
        is_valid = True
        check_message = ''
        msglist = []
        if self.pk:
            for required_probe in probeconfigs:
                # if not required_probe in myprobeconfigs:
                probevips = VipProbeConfigs.objects.filter(vip=self, probe=required_probe)
                if not probevips.exists():
                    if force_update:
                        probevip = VipProbeConfigs(vip=self, probe=required_probe)
                        probevip.save(request=request)
                    is_valid = False
                    msglist.append(str(required_probe))

            check_message = "Vip '%s' requires probeconfigs '%s' for domain." % (str(self), ','.join(msglist))

        return is_valid, check_message

    def add_required_probeconfigs(self, request, probeconfigs):
        if self.pk:
            myprobeconfigs = self.probeconfigs.all()
            # myprobeconfigs = self.probeconfigs.filter(probe__not__in=self.probeconfigs.all().values('probe').distinct())
            for required_probe in probeconfigs:
                if not required_probe in myprobeconfigs:
                    vipprobes = VipProbeConfigs.objects.filter(vip=self, probe=required_probe)
                    if not vipprobes.exists():
                        vipprobeconfig = VipProbeConfigs(vip=self, probe=required_probe)
                        vipprobeconfig.save(request=request)

    def get_probe_configs(self):
        if self.pk:
            vipprobes = VipProbeConfigs.objects.filter(vip=self)
            probeconfigs = BaseProbeConfig.objects.filter(probeconfig_id__in=vipprobes.values('probe').distinct())
            return probeconfigs
        else:
            return BaseProbeConfig.objects.none()

    def get_probeagent_config(self):
        from spectrum_api.configuration.models.probeagent import ProbeAgent

        if self.pk:
            return ProbeAgent.all_objects.filter(vip=self)
        else:
            return ProbeAgent.objects.none()

    def get_hyperion_config(self):
        from spectrum_api.sitecheck.models.hyperion import HyperionAgent

        if self.pk:
            return HyperionAgent.all_objects.filter(ipid=self.pk)
        else:
            return HyperionAgent.objects.none()

    def get_storagenode_config(self):
        from spectrum_api.cloudstorage.models.cloudstorage import StorageNode

        if self.pk:
            return StorageNode.all_objects.filter(ip_id=self.getIpid())
        else:
            return StorageNode.objects.none()

    def __unicode__(self):
        return self.get_ipaddr()

    def get_ipaddr(self):
        '''
        let's return ipaddr explicitly
        :return:
        '''
        if self.ihms_vip:
            return u'%s' % (self.ihms_vip)
        else:
            return u'%s' % (self.vip_addr)

    def get_fullvipname(self):
        if self.ihms_vip:
            return u'%s' % (self.ihms_vip.getfullvipname())
        else:
            return u'%s-%s' % (self.vip_name, self.host.get_fullhostname())

    def getvipbyfullname(self):
        from spectrum_api.shared_components.utils.common import getvipsbyvipname

        try:
            return getvipsbyvipname(self.get_fullvipname())
        except:
            return None

    def getpopname(self):
        return str(self.host.system.pop)

    def name(self):
        if self.ihms_vip:
            return u'%s-%s' % (self.ihms_vip.vip_name, self.host)
        else:
            return u'%s-%s' % (self.vip_name, self.host)

    def getGslbStatus(self):
        '''used by prism api script'''
        if self.enable_gslb == 1:
            return 'UP'
        elif self.enable_gslb == 0:
            return 'DOWN'
        else:
            return 'UP'  # self.host.getGslbStatus()

    def get_status_enabled(self):
        '''used by mproxy general purposes defined by prism 2.0'''
        if self.enable_gslb == 1:
            return 'enabled'
        elif self.enable_gslb == 0:
            return 'disabled'
        else:  # default value
            return 'enabled'  # self.host.get_status_enabled()

    def get_service_status(self):
        '''return 3 status: enabled,disabled,failure which are updated by RMS probe
        '''
        result = self.get_status_enabled()
        try:
            if self.enable_gslb == 1:
                from spectrum_api.configuration.models.node_mon import NodeRms

                noderms = NodeRms.objects.get(vip_ip=str(self))
                if noderms.val is not None and noderms.val < 0:
                    result = 'failure'
        except:
            return result
        return result

    def releaseFromIHMS(self, request, vip_name, vip_addr):
        self.ihms_vip = None
        self.vip_name = vip_name
        self.vip_addr = vip_addr
        self.save(request=request)

    def getIpid(self):
        if self.ihms_vip:
            return self.ihms_vip_id
        else:
            return getIPidbyipaddr(self.vip_addr)

    def is_deletable(self):
        # DSP_DEPS_LIMIT = 1
        from spectrum_api.configuration.models.probeagent import ProbeAgent
        from spectrum_api.configuration.models.gslb import GSLB
        # from spectrum_api.dna.models.domain import Domain, DomainEdge, DomainVip
        from spectrum_api.sitecheck.models.hyperion import HyperionAgent
        from spectrum_api.cloudstorage.models.cloudstorage import StorageNode
        from spectrum_api.wpo.models.wpo import WPONode
        #
        # for edge in self.edge.all():
        # if DomainEdge.objects.filter(edge=edge):
        #        return False
        # vipsearch = VipSearch.objects.get(vip=self.pk)

        if GSLB.objects.filter(vip=self).exists():
            return False
        elif ProbeAgent.objects.filter(vip=self).exists():
            return False
        # elif System.objects.filter(vip=vipsearch):
        #    return False
        # elif PopUplinkProbeConfigs.objects.filter(vip=self).exists():
        #    return False
        # elif VipProbeConfigs.objects.filter(vip=self,probe__probe_type=0).exists():
        #    return False
        elif ProbeConfigAggregateProbe.objects.filter(
                vip=self).exists():  # directlry bound to aggregate probe not through base_probe_config
            return False
        elif HyperionAgent.objects.filter(ipid=self).exists():
            return False
        elif StorageNode.objects.filter(ip_id=self.getIpid()).exists():
            return False
        elif self.has_related_static_rules():
            return False
        elif WPONode.objects.filter(vip=self).exists():
            return False
        else:
            return True

    def check_edgelist_probe_constraint(self, request, edgelist, probelist, force_update=False):
        '''
        edgelist: list from client user input
        probelist: list from client user input
        '''
        errmsg = ''
        msglist = []
        result = True
        if self.pk:
            edges = Edge.objects.filter(edge_id__in=edgelist)
            userinput_probeconfigs = BaseProbeConfig.objects.filter(pk__in=probelist)

            # required_probeconfigs = self.get_required_domain_probeconfigs()
            for edge in edges:
                required_probeconfigs = edge.get_required_probeconfigs()
                probe_list = []
                if required_probeconfigs.exists():
                    for required_probe in required_probeconfigs:
                        if not required_probe in userinput_probeconfigs:
                            if force_update:
                                probevips = VipProbeConfigs.objects.filter(vip=self, probe=required_probe)
                                if not probevips.exists():
                                    probevip = VipProbeConfigs(vip=self, probe=required_probe)
                                    probevip.save(request=request)

                            if not required_probe.name in probe_list:
                                probe_list.append(required_probe.name)
                    if len(probe_list) > 0:
                        msglist.append("Edge '%s' requires probeconfigs '%s'." % (str(edge), ",".join(probe_list)))
                        # return False,errmsg

            required_vip_probeconfigs = self.get_required_domainvip_probeconfigs()
            probe_list = []
            if len(required_vip_probeconfigs) > 0:
                for required_probe in required_vip_probeconfigs:
                    if not required_probe in userinput_probeconfigs:
                        if force_update:
                            probevips = VipProbeConfigs.objects.filter(vip=self, probe=required_probe)
                            if not probevips.exists():
                                probevip = VipProbeConfigs(vip=self, probe=required_probe)
                                probevip.save(request=request)

                        if not required_probe.name in probe_list:
                            probe_list.append(required_probe.name)
                if len(probe_list) > 0:
                    msglist.append("Vip '%s' requires probeconfigs '%s'." % (str(self), ",".join(probe_list)))

            if len(msglist) > 0:
                result = False
                errmsg = "\r\n".join(msglist)

        if force_update:
            return True, errmsg
        else:
            return result, errmsg

    def has_related_static_rules(self):
        from spectrum_api.dna.models.domain import DomainStaticRuleAction
        from spectrum_api.dns.serializers.clb import re_vip_action,re_set_action
        ipaddr = str(self)
        rule_actions = DomainStaticRuleAction.objects.filter(action__contains=ipaddr)

        if rule_actions.exists():
            rule_action_values = rule_actions.values('action')
            for rule_action in rule_action_values:
                actions = rule_action.get('action').strip().split('\n')
                #action = action.replace("=",",").replace("\r\n",",").replace("\n",",").replace("\r",",")
                #temps = [x.strip() for x in action.split(",")]
                #if ipaddr in temps:
                #    return True
                for action in actions:
                    vip_re = re_vip_action.match(action)
                    action_re = re_set_action.match(action)
                    if vip_re:
                        temps = [x.strip() for x in vip_re.group(1).split(",")]
                        if ipaddr in temps:
                            return True
                    if action_re:
                        if action_re.group('data') == ipaddr:
                            return True
        return False

    def get_related_static_rule_action_ids(self):
        from spectrum_api.dna.models.domain import DomainStaticRuleAction
        from spectrum_api.dns.serializers.clb import re_vip_action,re_set_action

        action_ids = []
        ipaddr = str(self)
        rule_actions = DomainStaticRuleAction.objects.filter(action__contains=ipaddr)
        if rule_actions.exists():
            rule_action_values = rule_actions.values('action','pk')
            for rule_action in rule_action_values:
                actions = rule_action.get('action').strip().split('\n')
                action_pk = rule_action.get('pk')
                for action in actions:
                    vip_re = re_vip_action.match(action)
                    action_re = re_set_action.match(action)
                    if vip_re:
                        temps = [x.strip() for x in vip_re.group(1).split(",")]
                        if ipaddr in temps:
                            action_ids.append(action_pk)
                    if action_re:
                        if action_re.group('data') == ipaddr:
                            action_ids.append(action_pk)
        return action_ids

    def is_clb_pop(self):
        return self.host.system.pop.is_clb_pop()

    def update_related_domain_status_modified(self, request):
        if self.is_clb_pop():
            domains = self.get_clb_domains()
            for domain in domains:
                domain.status = 0
                domain.save(request=request)  # domin save will trigger zone save also.

    def change_relate_static_rules(self, request, oldip, newip):
        from spectrum_api.dna.models.domain import DomainStaticRuleAction

        rule_actions = DomainStaticRuleAction.objects.filter(action__contains=str(oldip))
        for rule_action in rule_actions:
            new_actionlines = []
            actionlines = rule_action.action.replace("\r\n","\n").replace("\r","\n").split("\n")
            for actionline in actionlines:
                if len(actionline.strip()) > 6: #ipaddrsss length should be larger than 6byte
                    new_actions = []
                    actions = actionline.split(",")
                    for action in actions:
                        if len(action.strip()) > 6:
                            subactions = action.split("=")
                            matched = False
                            for subaction in subactions:
                                if subaction.strip() == oldip:
                                    matched = True
                                    break
                            if matched:
                                action = action.replace(oldip,newip) #keep original space character intact
                        new_actions.append(action)
                    new_actionlines.append(",".join(new_actions))
                else:
                    new_actionlines.append(actionline)

            new_rule_action =  "\r\n".join(new_actionlines)
            if rule_action.action != new_rule_action:
                rule_action.action = new_rule_action
                rule_action.save(request=request)

    def get_edge_domains(self, edges=None):
        '''return directly attached domain-vip's domains
        '''
        from spectrum_api.dna.models.domain import Domain, DomainEdge

        if edges is None:
            edges = self.get_edges()
        domainlist = DomainEdge.objects.filter(edge__in=edges.values('edge_id')).values('domain').distinct()
        domains = Domain.objects.filter(domain_id__in=domainlist)
        return domains

    def get_vip_domains(self):
        '''return directly attached domain-vip's domains
        '''
        from spectrum_api.dna.models.domain import Domain, DomainVip

        domainvips = DomainVip.objects.filter(vip=self).values('domain').distinct()
        domains = Domain.objects.filter(domain_id__in=domainvips)
        return domains

    def get_clb_domains(self):
        from spectrum_api.dna.models.domain import Domain, DomainVip

        domainvips = DomainVip.objects.filter(vip=self).values('domain')
        domains = Domain.objects.filter(domain_id__in=domainvips)
        domains = domains.exclude(clb_dns_zone__isnull=True)
        return domains

    def get_domains_with_single_vip(self):
        from spectrum_api.dna.models.domain import Domain, DomainVip

        domainvips = DomainVip.objects.values('domain').annotate(vip_count=Count('vip')).filter(vip_count=1)
        mydomainvips = DomainVip.objects.filter(vip=self).filter(domain__in=domainvips.values('domain'))
        domains = Domain.objects.filter(domain_id__in=mydomainvips.values('domain'))
        return domains

    def get_related_domains(self):
        from spectrum_api.dna.models.domain import DomainVip
        related_domains = []
        domain_vip_objs = DomainVip.all_objects.filter(vip=self)
        for domain_vip in domain_vip_objs:
            related_domains.append(domain_vip.domain.name)

        return related_domains

    def get_related_domain_actions(self):
        from spectrum_api.dna.models.domain import DomainStaticRuleNormalizedAction
        related_domain_actions = []

        normalized_actions = DomainStaticRuleNormalizedAction.objects.filter(vip=self)
        if normalized_actions.exists():
            for normalized_action in normalized_actions:
                domain_name = normalized_action.get_staticrule_action_relation_display()
                if not domain_name in related_domain_actions:
                    related_domain_actions.append(domain_name)

        return related_domain_actions

    def get_related_objects(self):
        DSP_DEPS_LIMIT = 10
        from spectrum_api.configuration.models.probeagent import ProbeAgent
        from spectrum_api.configuration.models.gslb import GSLB
        from spectrum_api.dna.models.domain import DomainEdge, DomainVip, DomainStaticRuleAction
        from spectrum_api.sitecheck.models.hyperion import HyperionAgent
        from spectrum_api.cloudstorage.models.cloudstorage import StorageNode
        from spectrum_api.wpo.models.wpo import WPONode
        related_action_ids = self.get_related_static_rule_action_ids()
        return ((DomainVip, DomainVip.objects.filter(vip=self)[:DSP_DEPS_LIMIT]),
                (Edge, self.edge.all()[:DSP_DEPS_LIMIT]),
                (DomainEdge,
                 DomainEdge.objects.filter(edge__in=self.edge.all().values_list('edge_id'))[:DSP_DEPS_LIMIT]),
                (GSLB, GSLB.objects.filter(vip=self)[:DSP_DEPS_LIMIT]),
                (ProbeAgent, ProbeAgent.objects.filter(vip=self)[:DSP_DEPS_LIMIT]),
                (VipProbeConfigs, VipProbeConfigs.objects.filter(vip=self)[:DSP_DEPS_LIMIT]),
                (ProbeConfigAggregateProbe, ProbeConfigAggregateProbe.objects.filter(vip=self)[:DSP_DEPS_LIMIT]),
                (System, System.objects.filter(vip=self)[:DSP_DEPS_LIMIT]),
                # (Host, vip_host_mgmt_ip),
                (HyperionAgent, HyperionAgent.objects.filter(ipid=self)[:DSP_DEPS_LIMIT]),
                (StorageNode, StorageNode.objects.filter(ip_id=self.getIpid())[:DSP_DEPS_LIMIT]),
                (WPONode, WPONode.objects.filter(vip=self)[:DSP_DEPS_LIMIT]),
                (DomainStaticRuleAction,
                 DomainStaticRuleAction.objects.filter(pk__in=related_action_ids)[:DSP_DEPS_LIMIT]),)

    def delete_related(self, request):
        try:
            single_domains = []
            self.delete_probe_config(request)
            domains = self.get_single_vip_domains(request)
            for domain in domains:
                single_domains.append(domain)

            self.delete_domain_vip(request)
            self.delete_edge_domain(request)

            if len(
                    single_domains) > 0:  # find domain bound with self and update domain config state,since its' only one vip has been deleted.
                for single_domain in single_domains:
                    single_domain.update_domain_config_status(request=request)  # means there is no vip/edge availabe

            # self.delete_gslb_config(request)
            # self.delete_probe_agents(request)
            self.delete_system_ipmi(request)
            # self.delete_host_masterip(request)
            # self.delete_hyperion_agents(request)
        except Exception, e:
            raise e
            # pass

    def get_single_vip_domains(self, request):
        try:
            domains = self.get_domains_with_single_vip()
            # orphaned_domains = Domain.objects.filter(domain_id__in=domains.values('domain'))
            return domains
        except Exception, e:
            raise e

    def delete_domain_vip(self, request):
        from spectrum_api.dna.models.domain import DomainVip

        try:
            domain_vip = DomainVip.objects.filter(vip=self)
            if domain_vip.exists():
                for domainvip in domain_vip:
                    domainvip.update_history(request, 3)
                domain_vip.delete()  # this is queryset delete, so it needs to run update_history before delete
        except Exception, e:
            raise e

    def delete_probe_config(self, request):
        try:
            vipprobeconfigs = VipProbeConfigs.objects.filter(vip=self)
            if vipprobeconfigs.exists():
                for vipprobeconfig in vipprobeconfigs:
                    vipprobeconfig.update_history(request, 3)
                vipprobeconfigs.delete()  # this is queryset delete, so it needs to run update_history before delete
        except Exception, e:
            raise e

    def delete_edge_domain(self, request):
        try:
            edges = []
            single_domains = []
            for edge in self.edge.all():
                edges.append(edge)

            self.edge.clear()

            try:
                for edge in edges:
                    single_domain_edges = edge.get_domainedges_with_single_edge()
                    for domainedge in single_domain_edges:
                        if domainedge.domain in single_domains:
                            pass
                        else:
                            single_domains.append(domainedge.domain)
                            # do not delete domainedge
                            # if domainedge.getVipCount() == 0:
                            # #domainedge.update_history(request,3)
                            #    domainedge.delete(request=request)
                            # do not delete edge, it may be reused
                            # if edge.is_deletable():
                            #    #edge.update_history(request,3)
                            #    edge.delete(request=request)
            except Exception, e:
                raise e

            if single_domains:
                for single_domain in single_domains:
                    single_domain.update_domain_config_status(request=request)

        except Exception, e:
            raise e

    def delete_gslb_config(self, request):
        from spectrum_api.configuration.models.gslb import GSLB

        try:
            gslbconfigs = GSLB.objects.filter(vip=self)
            for gslbconfig in gslbconfigs:
                gslbconfig.vip = None
                gslbconfig.save(request=request)
                # gslbconfigs.delete()
        except Exception, e:
            raise e

    def delete_probe_agents(self, request):
        from spectrum_api.configuration.models.probeagent import ProbeAgent

        try:
            probeagents = ProbeAgent.objects.filter(vip=int(self.pk))
            for probeagent in probeagents:
                probeagent.vip = None
                probeagent.save(request=request)
        except Exception, e:
            raise e

    def delete_system_ipmi(self, request):
        try:
            systemipmis = System.objects.filter(vip=self)
            for systemipmi in systemipmis:
                systemipmi.vip = None
                systemipmi.save(request=request)
        except Exception, e:
            raise e

    def snapshot_of_domain_relation(self):
        from spectrum_api.dna.models.domain import DomainVip, BasePopDNSZoneRelation
        domainvips = DomainVip.objects.filter(vip=self, domain__clb_dns_zone__status=4)\
                                    .distinct('domain')
        if domainvips.exists():
            domain_ids = [dv.domain for dv in domainvips]
            pop = self.host.system.pop
            for domain_id in domain_ids:
                try:
                    rel = BasePopDNSZoneRelation(pop=pop, zone=domain_id.clb_dns_zone)
                    rel.save()
                except:
                    pass

    class Meta:
        app_label = 'configuration'
        unique_together = [('host', 'vip_name')]
        db_table = 'base_vip'
        ordering = ['vip']

    class SpectrumMeta:
        allow_delete = True
        keep_latest_change_action_id = True

class VipSearch(Model):
    """ This model is for searching vip.
    the table is view to get full vip name."""
    vip = models.PositiveIntegerField(primary_key=True,
        db_column='vip_id')
    full_vip_name = models.CharField(max_length=255)
    ip = models.IPAddressField()
    pop_name = models.CharField(max_length=63)
    iata_code = models.CharField(max_length=63)
    full_host_name = models.CharField(max_length=255)
    host_id = models.PositiveIntegerField()

    def __unicode__(self):
        return u'%s(%s)' % (self.full_vip_name, self.ip)

    class Meta:
        app_label = 'configuration'
        db_table = 'base_vip_search'
        managed = False


class PopPacketlossProbeAgentConfig(HistoryModel):
    from spectrum_api.configuration.models.probeagent import ProbeAgent
    poppacketloss_probeagentconfig_id = models.AutoField(primary_key=True, db_column='id')
    pop = models.ForeignKey(Pop, db_column='pop_id')  # ,on_delete=models.DO_NOTHING
    probeagent = models.ForeignKey(ProbeAgent, db_column='probeagent_id',  # on_delete=models.DO_NOTHING,
        help_text=H_PROBEAGENT)

    def __unicode__(self):
        return u'%s -> %s' % (self.pop, self.probeagent)

    class Meta:
        app_label = 'configuration'
        db_table = 'base_pop_pktlossserver'
        verbose_name = 'Pop Packetloss Probe Agent'

    class SpectrumMeta:
        allow_delete = True
        parent = 'pop'

class PopProbeAgentConfig(HistoryModel):
    from spectrum_api.configuration.models.probeagent import ProbeAgent
    popprobeagentconfig_id = models.AutoField(primary_key=True,
        db_column='id')
    pop = models.ForeignKey(Pop, related_name='pop_set')  # ,on_delete=models.DO_NOTHING
    probeagent = models.ForeignKey(ProbeAgent,
        related_name='probe_agent_set',  # on_delete=models.DO_NOTHING,
        help_text=H_PROBEAGENT)
    primary = models.BooleanField(default=False,
        help_text=H_PROBEAGENT_PRIMARY)

    def __unicode__(self):
        return u'%s -> %s' % (self.pop, self.probeagent)

    def clean(self):
        try:
            system_list = System.objects.filter(pop=self.pop)
            host_list = []
            for system in system_list:
                host_list += Host.objects.filter(system=system)
            vip_list = []
            for host in host_list:
                vip_list += Vip.objects.filter(host=host)
            aggregate_probe_list = []
            for vip in vip_list:
                for vipprobe in VipProbeConfigs.objects.filter(vip=vip):
                    if vipprobe.probe.probe_type == 0:
                        aggregate_probe_list.append(vipprobe)
            for aggregate_probe in aggregate_probe_list:
                for sub_probe in ProbeConfigAggregateProbe.objects.filter(\
                                        probeconfigaggregate_fk=aggregate_probe.probe.pk):
                    if sub_probe.vip:
                        sub_probe_vip = Vip.objects.get(vip=sub_probe.vip.vip)
                        if not self.probeagent in\
                                        sub_probe_vip.host.system.pop.probeagent.all():
                            raise ValidationError({"probeagent":
                                                [_("%(pop)s pop can't probing %(probe)s.\
                                                At first, you have to\
                                                registe %(probeagent)s probeagent to %(sub_pop)s pop"
                                                        % {"pop": self.pop,
                                                        "probe": sub_probe_vip,
                                                        "probeagent" : self.probeagent,
                                                        "sub_pop" : sub_probe_vip.host.system.pop})]})
        except Pop.DoesNotExist:
            pass
        except Exception, e:
            raise e

    class Meta:
        app_label = 'configuration'
        db_table = 'base_pop_probeagent'
        verbose_name = 'Probe Agent'

    class SpectrumMeta:  #not supported when admin save
        parent = 'pop'
        allow_delete=True
        keep_latest_change_action_id = True


class BaseProbeConfig(HistoryModel):
    probeconfig_id = models.AutoField('Id', primary_key=True)
    name = models.CharField(
        'Probe Name',
        max_length=63,
        validators=[RegexValidator(probe_name_rex)],
        unique=True,
        help_text=H_PROBE_NAME
    )
    description = models.CharField('Description',
        max_length=1024, blank=True, null=True,
        help_text=H_PROBE_DESC)
    interval = models.PositiveIntegerField("Interval",
        null=True,
        blank=True,
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)],
        help_text=H_PROBE_INTERVAL)
    ttl_factor = models.FloatField("TTL Factor",
        null=True,
        blank=True,
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)],
        help_text=H_PROBE_TTL_FACTOR)
    threshold = models.FloatField("Threshold",
        null=True,
        blank=True,
        validators=[MaxValueValidator(4294967295)],
        help_text=H_PROBE_THESHOLD)
    report = models.SmallIntegerField("Report",
        null=True,
        blank=True,
        default=1,
        choices=BOOL_TYPES,
        help_text=H_PROBE_REPORT)
    report_other = models.SmallIntegerField("Report to other",
        null=True,
        blank=True,
        default=1,
        choices=BOOL_TYPES,
        help_text=H_PROBE_REPORTOTHER)
    log = models.SmallIntegerField("Log",
        null=True,
        blank=True,
        default=1,
        choices=BOOL_TYPES,
        help_text=H_PROBE_LOG)
    timeout = models.FloatField("Timeout",
        null=True,
        blank=True,
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)],
        help_text=H_PROBE_TIMEOUT)
    try_count = models.IntegerField(
        "Try Count",
        null=True,
        blank=True,
        default=1,
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        help_text=H_PROBE_TRY_COUNT)
    scaling = models.FloatField("Scaling",
        null=True,
        blank=True,
        validators=[MaxValueValidator(4294967295)],
        help_text=H_PROBE_SCALING)
    timespan = models.IntegerField(
        "Rate Func Timespan",
        null=True,
        blank=True,
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)],
        help_text=H_PROBE_RATEFUNC)
    ratio_base = models.SmallIntegerField(
        "Step Func Ratio Based",
        null=True,
        blank=True,
        choices=BOOL_TYPES,
        help_text=H_PROBE_RATIO_BASE)
    step_func = models.TextField("Step Func",
        blank=True,
        null=True,
        validators=[MaxLengthValidator(1024), RegexValidator(stepfunc_rex)],
        help_text=H_PROBE_STEPFUNC)
    date_created = models.DateTimeField('Date Created',
        auto_now_add=True)
    date_modified = models.DateTimeField('Date Modified',
        auto_now=True)

    probe_type = models.SmallIntegerField(editable=False,
        choices=PROBE_TYPES,
        default=0)

    use_clb = models.BooleanField(
        db_column='use_clb',
        verbose_name='Use CLB',
        default=0,
        help_text="Checking this field will dedicate this probe for CLB services.<br/><a href='#show-all' id='view_clb_allow_probe'>[show probe use customers]</a>")

    alert_message = models.TextField("Alert Message",
        blank=True,
        null=True,
        validators=[MaxLengthValidator(4096)])

    def __unicode__(self):
        return '%s' % (self.name)

    def clean(self):
        if self.report == 0:
            from spectrum_api.dna.models.domain import Domain
            domain_list = Domain.objects.filter(probe=self)
            if domain_list.exists():
                raise ValidationError({"probe":
                    [_("this probe already used at %s Domain. In this case, probe report must be 'True'" % domain_list[0])]})

        probe = BaseProbeConfig.objects.exclude(pk=self.pk).filter(name=self.name)
        if probe.exists():
            raise ValidationError({"name": [_("Probe Configuration with this Probe Name already exists.")]})

    class Meta:
        app_label = 'configuration'
        db_table = 'base_probeconfig'
        verbose_name = 'Probe Configuration'
        ordering = ['name']

    class SpectrumMeta:
        allow_delete = True
        keep_latest_change_action_id = True

    def is_deletable(self):
        try:
            from spectrum_api.dna.models.domain import Domain, DomainVip, DomainEdge
            if Domain.objects.filter(probe=self).exists():
                return False
            if DomainVip.objects.filter(probe=self).exists():
                return False
            if DomainEdge.objects.filter(probe=self).exists():
                return False
            vipprobes = VipProbeConfigs.objects.filter(probe=self)
            if vipprobes.exists():
                if self.use_clb:
                    return False
            if self.probe_type != 0:  # 0 means "AGGREGATE" probe
                # aggregate_probes = []
                aggregated = ProbeConfigAggregateProbe.objects.filter(probe=self)

                if aggregated.exists():
                    return False
                else:
                    return True
        except:
            return True
        return True

    def get_related_objects(self):
        DSP_DEPS_LIMIT = 10

        from spectrum_api.dna.models.domain import Domain, DomainVip, DomainEdge

        return ((VipProbeConfigs, VipProbeConfigs.objects.filter(probe=self)[:DSP_DEPS_LIMIT]),
                (Domain, Domain.objects.filter(probe=self)[:DSP_DEPS_LIMIT]),
                (ProbeConfigAggregateProbe, ProbeConfigAggregateProbe.objects.filter(probe=self)[:DSP_DEPS_LIMIT]),
                (DomainVip, DomainVip.objects.filter(probe=self)[:DSP_DEPS_LIMIT]),
                (DomainEdge, DomainEdge.objects.filter(probe=self)[:DSP_DEPS_LIMIT]),)

    def save(self, *args, **kwargs):
        request = kwargs.get('request', None)
        if self.pk:
            old_probe = BaseProbeConfig.objects.get(pk=self.pk)
            if old_probe.name != self.name:
                try:
                    from spectrum_api.rms.models.gslb_rms import RMSDisplayProbes
                    rms_probe = RMSDisplayProbes.objects.get(probe_name=old_probe.name)
                    rms_probe.probe_name = self.name
                    rms_probe.save(request=request)
                except:
                    pass
        else:
            old_probe = None

        super(BaseProbeConfig, self).save(*args, **kwargs)

class ProbeConfigStandaloneICMP(BaseProbeConfig):
    icmp_type = models.IntegerField(
        db_column='type',
        null=True,
        blank=True,
        help_text=H_ICMP_TYPE)
    ICMP_VALUE_TYPES = (
        ('RESPONSE_TIME', 'RESPONSE_TIME'),
    )
    value_type = models.CharField(max_length=30,
        null=True,
        blank=True,
        choices=ICMP_VALUE_TYPES,
        help_text=H_ICMP_VALUE)

    class Meta:
        app_label = 'configuration'
        db_table = 'base_probeconfig_standalone_icmp'
        verbose_name = 'ICMP Probe'

    def save(self, *args, **kwargs):
        self.probe_type = 8
        super(ProbeConfigStandaloneICMP, self).save(*args, **kwargs)

class ProbeConfigStandaloneSNMP(BaseProbeConfig):
    SNMP_VERSION_TYPE = (
        ('1', '1'),
        ('2', '2'),
        ('2c', '2c'),
        ('3', '3'),
    )
    version = models.CharField(max_length=10,
        choices=SNMP_VERSION_TYPE,
        null=True,
        blank=True,
        help_text=H_SNMP_VERSION)
    port = models.PositiveIntegerField(
        blank=True,
        null=True,
        validators=[MaxValueValidator(65535)],
        help_text=H_SNMP_PORT)
    OID_TYPE = (
        ('NORMAL', 'NORMAL'),
        ('AVERAGE_SUBTREE', 'AVERAGE_SUBTREE'),
        ('ATTACH_IFNUMBER', 'ATTACH_IFNUMBER'),
    )
    oid_type = models.CharField(max_length=15,
        choices=OID_TYPE,
        null=True,
        blank=True,
        help_text=H_SNMP_OID_TYPE)
    oid = models.CharField(max_length=255,
        validators=[RegexValidator(oid_rex)],
        help_text=H_SNMP_OID)
    community = models.CharField(max_length=63,
        null=True,
        blank=True,
        validators=[RegexValidator(default_name_rex)],
        help_text=H_SNMP_COMMUNITY)
    username = models.CharField(max_length=63,
        blank=True,
        null=True,
        validators=[RegexValidator(default_name_rex)],
        help_text=H_SNMP_USERNAME)
    SECURITY_LEVEL_TYPE = (
        ('noAuthNoPriv', 'noAuthNoPriv'),
        ('authNoPriv', 'authNoPriv'),
        ('authPriv', 'authPriv'),
    )
    security_level = models.CharField(
        max_length=20,
        choices=SECURITY_LEVEL_TYPE,
        null=True,
        blank=True,
        help_text=H_SNMP_SECURITY_LEVEL)
    AUTH_PROTOCOL_TYPE = (
        ('MD5', 'MD5'),
        ('SHA1', 'SHA1'),
    )
    auth_protocol = models.CharField(
        max_length=5,
        choices=AUTH_PROTOCOL_TYPE,
        null=True,
        blank=True,
        help_text=H_SNMP_AUTH_PROTOCOL)
    auth_password = models.CharField(max_length=30,
        null=True,
        blank=True,
        validators=[MinLengthValidator(8), RegexValidator(default_name_rex)],
        help_text=H_SNMP_AUTH_PW)
    PRIV_PROTOCOL_TYPE = (
        ('DES', 'DES'),
        ('AES', 'AES'),
        ('AES128', 'AES128'),
    )
    priv_protocol = models.CharField(
        max_length=10,
        choices=PRIV_PROTOCOL_TYPE,
        blank=True,
        null=True,
        help_text=H_SNMP_PRIV_PROTOCOL)
    priv_password = models.CharField(max_length=30,
        null=True,
        blank=True,
        validators=[MinLengthValidator(8), RegexValidator(default_name_rex)],
        help_text=H_SNMP_PRIV_PW)
    context = models.CharField(max_length=255,
        blank=True,
        null=True,
        validators=[RegexValidator(default_name_rex)],
        help_text=H_SNMP_CONTEXT)
    SNMP_VALUE_TYPES = (
        ('EMBEDDED', 'EMBEDDED'),
        ('RESPONSE_TIME', 'RESPONSE_TIME'),
    )
    value_type = models.CharField(max_length=30,
        choices=SNMP_VALUE_TYPES,
        null=True,
        blank=True,
        help_text=H_SNMP_VALUE)

    def save(self, *args, **kwargs):
        self.probe_type = 1
        super(ProbeConfigStandaloneSNMP, self).save(*args, **kwargs)

    class Meta:
        app_label = 'configuration'
        db_table = 'base_probeconfig_standalone_snmp'
        verbose_name = 'SNMP Probe'

class ProbeConfigStandaloneTCP(BaseProbeConfig):
    port = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(65535)],
        help_text=H_TCP_PORT)
    message = models.TextField(validators=[MaxLengthValidator(65535)],
        blank=True,
        null=True,
        help_text=H_MESSAGE)
    content_length = models.IntegerField(
        blank=True,
        null=True,
        validators=[MinValueValidator(-1), MaxValueValidator(65535)],
        help_text=H_TCP_CONTENT_LENGTH)
    TCP_VALUE_TYPES = (
        ('RESPONSE_TIME', 'RESPONSE_TIME'),
        ('CONNECT_TIME', 'CONNECT_TIME'),
        ('CONNECTIVITY', 'CONNECTIVITY'),
        ('REGEX_VALUE', 'REGEX_VALUE'),
        ('REGEX_RESPONSE_TIME', 'REGEX_RESPONSE_TIME'),
    )
    value_type = models.CharField(max_length=30,
        choices=TCP_VALUE_TYPES,
        null=True,
        blank=True,
        help_text=H_TCP_VALUE)
    regex = models.TextField(
        validators=[MaxLengthValidator(255)],
        blank=True,
        help_text=H_TCP_REGEX)

    def save(self, *args, **kwargs):
        self.probe_type = 2
        super(ProbeConfigStandaloneTCP, self).save(*args, **kwargs)

    class Meta:
        app_label = 'configuration'
        db_table = 'base_probeconfig_standalone_tcp'
        verbose_name = 'TCP Probe'

class ProbeConfigStandaloneSSL(BaseProbeConfig):
    verify_server = models.SmallIntegerField(
        null=True,
        blank=True,
        choices=BOOL_TYPES,
        help_text=H_SSL_VERIFY_SERVER)
    port = models.PositiveIntegerField(
        blank=True,
        null=True,
        validators=[MaxValueValidator(65535)],
        help_text=H_SSL_PORT)
    message = models.TextField(
        validators=[MaxLengthValidator(65535)],
        blank=True,
        null=True,
        help_text=H_SSL_MESSAGE)
    content_length = models.IntegerField(blank=True,
        null=True,
        validators=[MinValueValidator(-1), MaxValueValidator(65535)],
        help_text=H_SSL_CONTENT_LENGTH)
    SSL_VALUE_TYPES = (
        ('RESPONSE_TIME', 'RESPONSE_TIME'),
        ('CONNECT_TIME', 'CONNECT_TIME'),
        ('CONNECTIVITY', 'CONNECTIVITY'),
        ('REGEX_VALUE', 'REGEX_VALUE'),
        ('REGEX_RESPONSE_TIME', 'REGEX_RESPONSE_TIME'),
    )
    value_type = models.CharField(max_length=30,
        choices=SSL_VALUE_TYPES,
        null=True,
        blank=True,
        help_text=H_SSL_VALUE)
    regex = models.TextField(
        validators=[MaxLengthValidator(255)],
        null=True,
        blank=True,
        help_text=H_SSL_REGEX)

    def save(self, *args, **kwargs):
        self.probe_type = 4
        super(ProbeConfigStandaloneSSL, self).save(*args, **kwargs)

    class Meta:
        app_label = 'configuration'
        db_table = 'base_probeconfig_standalone_ssl'
        verbose_name = 'SSL Probe'

class ProbeConfigStandaloneUDP(BaseProbeConfig):
    port = models.PositiveIntegerField(
        validators=[MaxValueValidator(65535)],
        help_text=H_UDP_PORT)
    message = models.TextField(
        validators=[MaxLengthValidator(65535)],
        blank=True,
        null=True,
        help_text=H_UDP_MESSAGE)
    content_length = models.IntegerField(blank=True,
        null=True,
        validators=[MinValueValidator(-1), MaxValueValidator(65535)],
        help_text=H_UDP_CONTENT_LENGTH)
    UDP_VALUE_TYPES = (
        ('RESPONSE_TIME', 'RESPONSE_TIME'),
        ('REGEX_VALUE', 'REGEX_VALUE'),
        ('REGEX_RESPONSE_TIME', 'REGEX_RESPONSE_TIME'),
    )
    value_type = models.CharField(max_length=30,
        choices=UDP_VALUE_TYPES,
        blank=True,
        help_text=H_UDP_VALUE)
    regex = models.TextField(
        validators=[MaxLengthValidator(255)],
        blank=True,
        help_text=H_UDP_REGEX)

    def save(self, *args, **kwargs):
        self.probe_type = 3
        super(ProbeConfigStandaloneUDP, self).save(*args, **kwargs)

    class Meta:
        app_label = 'configuration'
        db_table = 'base_probeconfig_standalone_udp'
        verbose_name = 'UDP Probe'

class ProbeConfigStandaloneFTP(BaseProbeConfig):
    port = models.PositiveIntegerField(blank=True,
        null=True,
        validators=[MaxValueValidator(65535)],
        help_text=H_FTP_PORT)
    username = models.CharField(max_length=255,
        blank=True,
        null=True,
        validators=[RegexValidator(default_name_rex)],
        help_text=H_FTP_USERNAME)
    password = models.CharField(max_length=30,
        blank=True,
        null=True,
        validators=[RegexValidator(default_name_rex)],
        help_text=H_FTP_PW)
    filepath = models.CharField(max_length=4096,
        blank=True,
        null=True,
        validators=[RegexValidator(path_rex)],
        help_text=H_FTP_PATH)
    content_length = models.IntegerField(blank=True,
        null=True,
        validators=[MinValueValidator(-1), MaxValueValidator(65535)],
        help_text=H_FTP_CONTENT_LENGTH)
    FTP_VALUE_TYPES = (
        ('RESPONSE_TIME', 'RESPONSE_TIME'),
        ('CONNECT_TIME', 'CONNECT_TIME'),
        ('CONNECTIVITY', 'CONNECTIVITY'),
        ('REGEX_VALUE', 'REGEX_VALUE'),
        ('REGEX_RESPONSE_TIME', 'REGEX_RESPONSE_TIME'),
    )
    value_type = models.CharField(max_length=30,
        choices=FTP_VALUE_TYPES,
        null=True,
        blank=True,
        help_text=H_FTP_VALUE)
    regex = models.TextField(
        validators=[MaxLengthValidator(255)],
        blank=True,
        help_text=H_FTP_REGEX)

    def save(self, *args, **kwargs):
        self.probe_type = 5
        super(ProbeConfigStandaloneFTP, self).save(*args, **kwargs)

    class Meta:
        app_label = 'configuration'
        db_table = 'base_probeconfig_standalone_ftp'
        verbose_name = 'FTP Probe'

class ProbeConfigStandaloneRTMP(BaseProbeConfig):
    port = models.PositiveIntegerField(blank=True,
        null=True,
        validators=[MaxValueValidator(65535)],
        help_text=H_RTMP_PORT)
    encrypted = models.SmallIntegerField(
        null=True,
        blank=True,
        choices=BOOL_TYPES,
        help_text=H_RTMP_ENCRIPTED)
    verify_server = models.SmallIntegerField(
        null=True,
        blank=True,
        choices=BOOL_TYPES,
        help_text=H_RTMP_VERIFY)
    app = models.CharField(max_length=255,
        blank=True,
        null=True,
        validators=[RegexValidator(rtmp_app_rex)],
        help_text=H_RTMP_APP)
    tcurl = models.CharField(max_length=255,
        blank=True,
        null=True,
        help_text=H_RTMP_TCURL)
    flashver = models.CharField(max_length=63,
        blank=True,
        null=True,
        validators=[RegexValidator(rtmp_flashver_rex)],
        help_text=H_RTMP_FLASHVER)
    stream = models.CharField(max_length=255,
        blank=True,
        null=True,
        validators=[RegexValidator(rtmp_stream_name_rex)],
        help_text=H_RTMP_STREAM)
    RTMP_VALUE_TYPES = (
        ('RESPONSE_TIME', 'RESPONSE_TIME'),
        ('STREAM_AVAIL', 'STREAM_AVAIL'),
        ('CONNECT_TIME', 'CONNECT_TIME'),
        ('CONNECTIVITY', 'CONNECTIVITY'),
        ('APP_CONNECT_TIME', 'APP_CONNECT_TIME'),
        ('APP_CONNECTIVITY', 'APP_CONNECTIVITY'),
    )
    value_type = models.CharField(max_length=30,
        choices=RTMP_VALUE_TYPES,
        null=True,
        blank=True,
        help_text=H_RTMP_VALUE)

    def save(self, *args, **kwargs):
        self.probe_type = 6
        super(ProbeConfigStandaloneRTMP, self).save(*args, **kwargs)

    class Meta:
        app_label = 'configuration'
        db_table = 'base_probeconfig_standalone_rtmp'
        verbose_name = 'RTMP Probe'

class ProbeConfigStandaloneDNS(BaseProbeConfig):
    domain = models.CharField(max_length=255,
        blank=True,
        null=True,
        validators=[RegexValidator(gslb_domain_rex)],
        help_text=H_DNS_DOMAIN)
    dns_class = models.PositiveIntegerField(blank=True,
        null=True,
        validators=[MaxValueValidator(65535)],
        db_column='class',
        help_text=H_DNS_CLASS)
    dns_type = models.PositiveIntegerField(blank=True,
        null=True,
        db_column='type',
        validators=[MaxValueValidator(65535)],
        help_text=H_DNS_TYPE)
    port = models.PositiveIntegerField(blank=True,
        null=True,
        validators=[MaxValueValidator(65535)],
        help_text=H_DNS_PORT)
    DNS_VALUE_TYPES = (
        ('RESPONSE_TIME', 'RESPONSE_TIME'),
        ('UP_DOWN', 'UP_DOWN'),
        ('NO_ERROR', 'NO_ERROR'),
        ('RESPONSE_CODE_MATCH', 'RESPONSE_CODE_MATCH'),
        ('ANSWER_COUNT', 'ANSWER_COUNT'),
    )
    value_type = models.CharField(max_length=30,
        choices=DNS_VALUE_TYPES,
        null=True,
        blank=True,
        help_text=H_DNS_VALUE)
    response_code = models.IntegerField(blank=True,
        null=True,
        validators=[MinValueValidator(0), MaxValueValidator(15)],
        help_text=H_DNS_CODEMATCH)

    def save(self, *args, **kwargs):
        self.probe_type = 7
        super(ProbeConfigStandaloneDNS, self).save(*args, **kwargs)

    class Meta:
        app_label = 'configuration'
        db_table = 'base_probeconfig_standalone_dns'
        verbose_name = 'DNS Probe'

class ProbeConfigAggregate(BaseProbeConfig):
    AGGREGATE_TYPE = (
        ('SUM', 'SUM'),
        ('BEST', 'BEST'),
        ('POP_SUM', 'POP_SUM'),
    )

    aggregate_type = models.CharField("Aggregate Type",
        max_length=10,
        choices=AGGREGATE_TYPE,
        null=True,
        blank=True,
        help_text=H_PROBE_AGGRE_TYPE)

    def save(self, *args, **kwargs):
        self.probe_type = 0
        super(ProbeConfigAggregate, self).save(*args, **kwargs)

    class Meta:
        app_label = 'configuration'
        db_table = 'base_probeconfig_aggregate'
        verbose_name = 'Aggregate Probe'

class ProbeConfigAggregateProbe(HistoryModel):
    probeconfigaggregateprobe_id = models.AutoField(primary_key=True)
    probe = models.ForeignKey(BaseProbeConfig,
        related_name='probe_set',
        help_text=H_PROBE_AGGRE_SUBPROBE)
    weight = models.FloatField(blank=True,
        null=True,
        validators=[MinValueValidator(0),
            MaxValueValidator(4294967295)],
        help_text=H_PROBE_AGGRE_WEIGHT)
    vip = models.ForeignKey(Vip,
        blank=True,
        null=True,
        help_text=H_PROBE_AGGRE_VIP)
    probeconfigaggregate_fk = models.ForeignKey(ProbeConfigAggregate)



    # Prevent nested aggregate probe from pointing parent aggregate probe.
    def make_nested_aggregate_probes_list(self, probe, aggregate_probe_list):
        nested_probes = ProbeConfigAggregateProbe.objects.filter(
            probeconfigaggregate_fk=probe.pk)
        for nested_probe in nested_probes:
            if nested_probe.probe.probe_type == 0:
                if not nested_probe.probe.pk in aggregate_probe_list:
                    aggregate_probe_list.append(nested_probe.probe.pk)
                    self.make_nested_aggregate_probes_list(nested_probe.probe,
                        aggregate_probe_list)
                    aggregate_probe_list.remove(nested_probe.probe.pk)
                else:
                    raise ValidationError({"probe":
'''One of nested aggregate probes sets the parent aggregate probe: %s''' % nested_probe.probe})

    def clean(self):
        try:
            if self.probeconfigaggregate_fk.pk == self.probe.pk:
                raise ValidationError({"probe":
                                    [_("Not allow to assign itself.")]})
        except ObjectDoesNotExist:
            return

        if self.probe.probe_type == 0:  # 0: AGGREGATE PROBE
            if self.vip:
                raise ValidationError({"vip":
                    [_("Cannot assign a vip for aggregate probe. Should be empty")]})

            aggregate_probe_list = [self.probeconfigaggregate_fk.pk, ]
            self.make_nested_aggregate_probes_list(
                self.probe,
                aggregate_probe_list)

    def __unicode__(self):
        return u'%s-> %s' % (self.probeconfigaggregate_fk.name,
            self.probe.name)

    class Meta:
        app_label = 'configuration'
        db_table = 'base_probeconfig_aggregate_probe'
        verbose_name = 'Probe'
        unique_together = ('probeconfigaggregate_fk', 'probe')

    class SpectrumMeta:
        allow_delete = True
        parent = 'probe'

class PopUplinkProbeConfigs(HistoryModel):
    pop_uplink_probe_id = models.AutoField(primary_key=True)
    probe = models.ForeignKey(BaseProbeConfig)
    pop = models.ForeignKey(Pop)
    vip = models.ForeignKey(Vip, blank=True, null=True, on_delete=models.SET_NULL)
    threshold = models.FloatField("Threshold",
        blank=True,
        validators=[MaxValueValidator(4294967295)],
        help_text=H_OVERRIDE_THRESHOLD)
    step_func = models.TextField("Step Func",
        blank=True,
        null=True,
        validators=[MaxLengthValidator(1024), RegexValidator(stepfunc_rex)],
        help_text=H_OVERRIDE_STEPFUNC)

    def clean(self):
        if not hasattr(self, "probe"):
            return


    def __unicode__(self):
        try:
            return u'%s' % (self.probe)
        except:
            return u'register required'

    class Meta:
        app_label = 'configuration'
        db_table = 'base_pop_uplink_probe'
        unique_together = ('probe', 'pop')
        verbose_name = 'Uplink Probe'

    class SpectrumMeta:
        allow_delete = True
        parent = 'pop'
        keep_latest_change_action_id = True

class VipProbeConfigs(HistoryModel):
    vip_probe_id = models.AutoField(primary_key=True)
    probe = models.ForeignKey(BaseProbeConfig,
        related_name='probeconfig_set')
    vip = models.ForeignKey(Vip, related_name='vipprobeconfigs_set')
    threshold = models.FloatField("Threshold",
        blank=True,
        validators=[MaxValueValidator(4294967295)],
        help_text=H_OVERRIDE_THRESHOLD)
    step_func = models.TextField("Step Func",
        blank=True,
        null=True,
        validators=[MaxLengthValidator(1024), RegexValidator(stepfunc_rex)],
        help_text=H_OVERRIDE_STEPFUNC)
    timeout = models.FloatField("Timeout",
        blank=True,
        null=True,
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)],
        help_text=H_OVERRIDE_TIMEOUT)

    def get_all_probevips_from_aggregate_probe(self,
                                            probe, probe_list=[]):
        probevips = ProbeConfigAggregateProbe.objects.filter(
            probeconfigaggregate_fk=probe)
        for probevip in probevips:
            if probevip.probe.probe_type != 0:
                probe_list.append(probevip)
            else:
                self.get_all_probevips_from_aggregate_probe(probevip.probe,
                    probe_list)

    def verify_probe_agent(self, probe, targetpop):
        if probe in targetpop.probeagent.all():
            return True
        return False


    def save(self, *args, **kwargs):
        request = kwargs.get('request', None)
        super(VipProbeConfigs, self).save(*args, **kwargs)
        if self.pk:
            try:
                if self.vip.host.system.pop.is_clb_pop():
                    self.vip.host.system.pop.status = 0
                    self.vip.host.system.pop.save(request=request)
            except:
                pass

    # validation for only aggregate probe.
    # should be possible to be used by this pop's all probes:
    # (primary probe and backup probes)
    def clean(self):
        if not hasattr(self, "probe") or self.probe.probe_type != 0:
            return

        # get vip list by given aggregate probe.
        # validation moved to vip serializser

    def __unicode__(self):
        try:
            return u'%s -> %s' % (self.vip, self.probe)
        except:
            return u'register required'

    class Meta:
        app_label = 'configuration'
        db_table = 'base_vip_probe'
        unique_together = ('probe', 'vip')
        verbose_name = 'Probe'

    class SpectrumMeta:
        allow_delete = True
        keep_latest_change_action_id = True
        parent = 'vip'

class Role(HistoryModel):
    role_id = models.AutoField(primary_key=True)
    role_name = models.CharField(
        max_length=50,
        validators=[RegexValidator(default_name_rex)],
        unique=True
    )

    def __unicode__(self):
        return '%s' % (self.role_name)

    class Meta:
        app_label = 'configuration'
        db_table = 'base_role'
        ordering = ['role_name']

    class SpectrumMeta:
        allow_delete = True
        keep_latest_change_action_id = True


class HostRole(HistoryModel):
    hostrole_id = models.AutoField(primary_key=True, db_column='id')
    host = models.ForeignKey(Host)
    role = models.ForeignKey(Role)

    def __unicode__(self):
        return u'%s -> %s' % (self.host, self.role)

    def save(self, *args, **kwargs):
        super(HostRole, self).save(*args, **kwargs)

    def clean(self):
        if str(self.role) == MPROXY_ROLE:
            try:
                vips = Vip.objects.filter(host=self.host, mproxy_shield=True)
                if vips.count() == 0:
                    raise ValidationError({'__all__':\
                        [_('you have to set the mproxy shield, \
                            one of vip that related vip list')]})
                if vips.count() > 1:
                    raise ValidationError({'__all__':\
                        [_('mproxy shield is setted  %s vips' %
                        vips)]})
            except Host.DoesNotExist:
                # for django-rest-framework 2.3.x problem
                # because when create new host-role. self.host can't access it.
                pass
            except Exception as e:
                pass
        super(HostRole, self).clean()

    class Meta:
        app_label = 'configuration'
        db_table = 'base_host_role'
        unique_together = ('role', 'host')

    class SpectrumMeta:
        allow_delete = True
        parent = 'host'
        keep_latest_change_action_id = True

class RoleConfigSetting(InterimModel):
    roleconfig_id = models.AutoField(primary_key=True, db_column='id')
    role = models.ForeignKey(Role)
    config_phase = models.ForeignKey(ConfigPhase,
        related_name='host_configphase_set')

    def __unicode__(self):
        return u'%s -> %s' % (self.role, self.config_phase)

    class Meta:
        app_label = 'configuration'
        db_table = 'base_role_configsetting'
        unique_together = ('role', 'config_phase')

class PopInfo(Model):
    pop = models.OneToOneField(Pop, db_column="pop_id", primary_key=True)
    desc_link = models.CharField(db_column='desc_link',
                                null=True,
                                blank=True,
                                max_length=1024)
    idc = models.ForeignKey(IhmsIdc, db_column='idc_id', null=True)
    country = models.ForeignKey(IhmsCountry, db_column='country_id', null=True)
    priority = models.PositiveIntegerField(null=True, blank=True)

    class Meta:
        app_label = 'configuration'
        db_table = 'base_pop_info'
        managed = False

class BaseVipEdge(HistoryModel):
    id = models.AutoField(primary_key=True)
    vip = models.ForeignKey(Vip)
    edge = models.ForeignKey(Edge)

    class Meta:
        app_label = 'configuration'
        db_table = 'base_vip_edge'
        managed = False
        unique_together = ("vip", "edge", )

    class SpectrumMeta:
        allow_delete = True

    def __unicode__(self):
        # ex host_id.system_id.pop_id
        if self.vip.ihms_vip:
            return u'%s.%s(%s)' % (self.vip.ihms_vip.vip_name, self.vip.host, self.vip)
        else:
            return u'%s.%s(%s)' % (self.vip.vip_name, self.vip.host, self.vip)

class PopNameInfo(Model):
    id = models.PositiveIntegerField(primary_key=True, db_column='pop_id')
    name = models.CharField(db_column='pop_name')
    def __unicode__(self):
        return u'%s' % (self.pop_name)

    class Meta:
        app_label = 'configuration'
        db_table = 'pop_name_info'
        managed = False

class SystemNameInfo(Model):
    id = models.PositiveIntegerField(primary_key=True, db_column='system_id')
    pop = models.PositiveIntegerField(db_column='pop_id')
    name = models.CharField(db_column='system_name')
    def __unicode__(self):
        return u'%s' % (self.system_name)

    class Meta:
        app_label = 'configuration'
        db_table = 'system_name_info'
        managed = False

class HostNameInfo(Model):
    id = models.PositiveIntegerField(primary_key=True, db_column='host_id')
    system = models.PositiveIntegerField(db_column='system_id')
    name = models.CharField(db_column='host_name')
    def __unicode__(self):
        return u'%s' % (self.host_name)

    class Meta:
        app_label = 'configuration'
        db_table = 'host_name_info'
        managed = False
