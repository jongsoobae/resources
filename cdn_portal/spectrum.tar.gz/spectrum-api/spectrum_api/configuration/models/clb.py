# -*- coding: utf-8 -*-
"""
    Copyright (c) 2012 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Cloud Load Balancer
"""
from datetime import datetime
from django.core.validators import MaxLengthValidator
from django.db import models
from django.utils.encoding import smart_unicode

from spectrum_api.configuration.models import InterimModel
from spectrum_api.configuration.models.base import Pop, BaseProbeConfig, Vip, Host, VipProbeConfigs
from spectrum_api.shared_components.models import StatMaster, BaseModel
from spectrum_api.shared_components.models.customer import CustomerDisplay, \
    CustomerContract, CustomerAccount


USETYPE_CHOICES = (
    (1, 'Cloud Load Balancer'),
    (2, 'Partner/Reseller POPs'),
)

DOMAIN_MON_STATUS = (
        (0, 'Normal'),
        (1, 'Disabled'),
        (2, 'Warned'),
        (3, 'Failed'),
    )

ALERT_USER_FLAG = (
        (0, 'Alert Off(Same as now)'),
        (1, 'Alert only for the Failed Domain(Currently, "Alert On")'),
        (2, 'Alert Off(Same as now)'),
    )

__DEF_CLB_ALERT_GROUP_NAME__ = "MyGroup"  # Default Alert group name is in @PRBPRISM-71

class CLBLocationContinent(BaseModel):
    continent = models.AutoField(primary_key=True, db_column='continent_id')
    continent_name = models.CharField(max_length=255,
                                        validators=[MaxLengthValidator(255)],
                                        unique=True,
                                        verbose_name='continent name',
                                        help_text='Value : Maximum length is less than 255 bytes string')
    continent_alias = models.TextField(max_length=255,
                                        validators=[MaxLengthValidator(255)],
                                        verbose_name='Description',
                                        db_column='continent_alias_name',
                                        blank=True,
                                        help_text='Value : Maximum length is less than 255 bytes string')
    date_created = models.DateTimeField(auto_now_add=True, editable=False)
    date_modified = models.DateTimeField(auto_now=True, editable=False)
    obj_state = models.BooleanField("Status", editable=False, default=True)

    class Meta:
        app_label = 'configuration'
        db_table = 'clb_location_continent'
        verbose_name = 'Cloud Load Balancer Location Continent'
        managed = False

    def __unicode__(self):
        return u"%s" % (self.continent_name)

    def save(self, request):
        super(CLBLocationContinent, self).save(request=request)

class CLBLocationRegion(BaseModel):
    region = models.AutoField(primary_key=True, db_column='region_id')
    region_name = models.CharField(max_length=100,
                                    validators=[MaxLengthValidator(100)],
                                    unique=True,
                                    verbose_name='Perceived Location',
                                    help_text='Value : Maximum length is less than 100 bytes string')
    region_alias = models.TextField(max_length=255,
                                    validators=[MaxLengthValidator(255)],
                                    verbose_name='Description',
                                    blank=True,
                                    help_text='Value : Maximum length is less than 255 bytes string')
    continent = models.ForeignKey(CLBLocationContinent, db_column='continent_id')
    date_created = models.DateTimeField(auto_now_add=True, editable=False)
    date_modified = models.DateTimeField(auto_now=True, editable=False)
    obj_state = models.BooleanField("Status", editable=False, default=True)

    class Meta:
        app_label = 'configuration'
        db_table = 'clb_location_region'
        verbose_name = 'Cloud Load Balancer Perceived Location'
        managed = False

    class SpectrumMeta:
        allow_delete = True

    def __unicode__(self):
        return smart_unicode(self.region_name)

    def save(self, request):
        super(CLBLocationRegion, self).save(request=request)


class CLBLocationRegionBasePop(BaseModel):
    id = models.AutoField(primary_key=True)
    region = models.ForeignKey(CLBLocationRegion,
                                        db_column='region_id',
                                        verbose_name='Perceived Location')
    pop = models.ForeignKey(Pop, db_column='pop_id', related_name="clb_basepop_set", on_delete=models.SET_NULL)
    is_primary = models.BooleanField()
    date_created = models.DateTimeField(auto_now_add=True, editable=False)
    date_modified = models.DateTimeField(auto_now=True, editable=False)
    obj_state = models.BooleanField("Status", editable=False, default=True)

    class Meta:
        app_label = 'configuration'
        db_table = 'clb_location_region_base_pop'
        unique_together = ("region", "pop",)
        verbose_name = 'Customer Perceived Location mapping POP'
        managed = False

    class SpectrumMeta:
        allow_delete = True

    def __unicode__(self):
        return u"%s ( %s )" % (self.region, self.pop)

    def save(self, request):
        super(CLBLocationRegionBasePop, self).save(request=request)

    def get_primary_pop_name(self):
        if self.pop.ihms_pop :
            pri_pop_name = self.pop.ihms_pop.pop_code
        else:
            pri_pop_name = self.pop.pop_name
        return pri_pop_name

    def get_pop_list_from_region(self):
        base_pop_set = CLBLocationRegionBasePop.all_objects.filter(region=self.region_id, obj_state=1)
        primary_pop = None
        pop_arr = []
        for obj in base_pop_set:
            pop_arr.append(obj.pop)

        return pop_arr

    def get_customer_pop_name(self, customer):
        primary_pop_name = self.get_primary_pop_name()
        air_port = primary_pop_name.split('-')[len(primary_pop_name.split('-')) - 1]

        pop_prefix = 'C0' + str(customer.account_id).zfill(10)

        is_created = False
        pop_name = pop_prefix + str(1).zfill(4) + '-' + air_port
        for i in range(1, 9999):
            cust_idx = str(i).zfill(4)
            pop_name = pop_prefix + cust_idx + '-' + air_port
            try:
                Pop.all_objects.get(pop_name=pop_name)
            except Pop.DoesNotExist:
                is_created = True
                break

        return pop_name, is_created

    def create_customer_pop(self, request, customer, group_state=1):
        pop_name, is_created = self.get_customer_pop_name(customer)
        primary_pop = self.pop

        customer_pop = Pop(pop_name=pop_name)
        if not primary_pop.rttserver is None:
            customer_pop.rttserver = primary_pop.rttserver
        customer_pop.enable_gslb = group_state
        customer_pop.save(reqeust=request)
        return customer_pop, is_created


class CustomerAllowProbeConfig(InterimModel):
    id = models.AutoField(primary_key=True)
    probeconfig = models.ForeignKey(BaseProbeConfig, db_column='probeconfig_id')
    customer = models.ForeignKey(CustomerDisplay)
    contract_no = models.ForeignKey(CustomerContract, db_column='contract_no')
    use_type = models.SmallIntegerField(choices=USETYPE_CHOICES, default=1)
    date_created = models.DateTimeField(auto_now_add=True, editable=False)
    date_modified = models.DateTimeField(auto_now=True, editable=False)
    obj_state = models.BooleanField("Status", editable=False, default=True)

    class Meta:
        app_label = 'configuration'
        db_table = 'customer_allow_probeconfig'
        unique_together = ("probeconfig", "contract_no",)
        verbose_name = 'Customer Probe'
        managed = False

    class SpectrumMeta:
        allow_delete = True

    def __unicode__(self):
        return u"%s" % (self.customer)

    def is_deletable(self):
        contract_pops = CustomerContractPop.all_objects.filter(customer=self.customer)
        pops = [p.pop for p in contract_pops]
        vips = Vip.all_objects.filter(host__system__pop__in=pops, probeconfigs=self.probeconfig)
        if vips.exists():
            return False
        else:
            return True


class CustomerContractPop(InterimModel):
    id = models.AutoField(primary_key=True)
    customer = models.ForeignKey(CustomerDisplay)
    contract_no = models.ForeignKey(CustomerContract, null=True, db_column='contract_no')
    pop_alias = models.CharField(max_length=100, null=True)
    pop = models.ForeignKey(Pop)
    region = models.ForeignKey(CLBLocationRegion, null=True)
    use_type = models.SmallIntegerField(choices=USETYPE_CHOICES, default=1)
    date_created = models.DateTimeField(auto_now_add=True, editable=False)
    date_modified = models.DateTimeField(auto_now=True, editable=False)
    obj_state = models.BooleanField("Status", default=True)
    probe_agent_selection_type = models.SmallIntegerField(default=0)

    class Meta:
        app_label = 'configuration'
        db_table = 'customer_contract_base_pop'
        verbose_name = 'Customer Pop'
        managed = False

    class SpectrumMeta:
        allow_delete = True
        with_no_request = True

    def __unicode__(self):
        return "%s (%s-%s)" % (self.pop_alias, self.customer.account, self.contract_no)

    def is_deletable(self):
        try:
            if self.pop:
                return self.pop.is_deletable()
        except Pop.DoesNotExist:
            return True
        return True

    @staticmethod
    def get_avaliable_probes(customer):
        if customer:
            my_probe_objs = CustomerAllowProbeConfig.all_objects.\
                filter(customer=customer, obj_state=True).values('probeconfig_id')
            other_allow_config_objs = CustomerAllowProbeConfig.all_objects.filter(obj_state=True).\
                exclude(customer=customer).exclude(probeconfig__in=my_probe_objs).values('probeconfig_id')
            base_probe_config_for_customer = BaseProbeConfig.all_objects.filter(use_clb=1).\
                exclude(pk__in=other_allow_config_objs)
            base_probe_config_for_customer = base_probe_config_for_customer
        else:
            base_probe_config_for_customer = BaseProbeConfig.all_objects.all()

        data = []
        for obj in base_probe_config_for_customer:
            data.append({'probeconfig_id': obj.probeconfig_id,
                         'name': obj.name,
                         'description': smart_unicode(obj.description) if obj.description is not None else '',
                         'alert_message': smart_unicode(obj.alert_message) if obj.alert_message is not None else ''})
        return data

    def get_or_create_host(self, request=None):
        host_objs = Host.all_objects.filter(system__pop=self.pop)
        if host_objs.exists():
            host_obj = host_objs[0]
        else:
            system_obj = self.pop.create_new_customer_system(request)
            host_obj = system_obj.create_new_customer_host(request)
        return host_obj

    def get_host(self):
        return Host.all_objects.filter(system__pop=self.pop)[0]

    def get_vip_set(self):
        ret = []

        try:
            cust_pop = CustomerContractPop.all_objects.get(pop=self.pop)
        except CustomerContractPop.DoesNotExist:
            cust_pop = None
            return ret

        avail_probes = cust_pop.get_avaliable_probes(cust_pop.customer)
        avail_probe_array = []
        for probe in avail_probes:
            avail_probe_array.append(probe['probeconfig_id'])

        vip_set = self.pop.get_vips()
        for vip_obj in vip_set:
            ret_vip_obj = {}

            vipprobe_objs = VipProbeConfigs.all_objects.filter(vip=vip_obj)
            ret_vip_obj['vip'] = vip_obj.pk
            ret_vip_obj['vip_addr'] = vip_obj
            ret_vip_obj['vip_alias_name'] = vip_obj.vip_alias_name
            ret_vip_obj['enable_gslb'] = vip_obj.enable_gslb
            ret_vip_obj['vipprobe_set'] = []
            for vp_obj in vipprobe_objs:
                if vp_obj.probe.pk in avail_probe_array:
                    ret_vip_obj['vipprobe_set'].append(vp_obj.probe)
            ret.append(ret_vip_obj)

        return ret


class CLBAlertManagementBase(BaseModel):
    clbalertmanagementbase_id = models.AutoField(db_column='id', primary_key=True)
    alert_gmt_cd = models.CharField(max_length=50, default='GMT_61')
    account_no = models.ForeignKey(CustomerAccount, db_column='account_no')
    reg_date = models.DateTimeField(auto_now=True, auto_now_add=True)

    class Meta:
        app_label = 'configuration'
        db_table = 'clb_alert_management_base'

    class SpectrumMeta:
        allow_delete = True

class CLBAlertGroup(BaseModel):
    clbalertgroup_id = models.AutoField(db_column='id', primary_key=True)
    alert_base_id = models.ForeignKey(CLBAlertManagementBase, db_column='alert_base_id', related_name='clb_alert_group_set')
    clb_group_name = models.CharField(max_length=50)
    group_type = models.SmallIntegerField(default=1)
    sort_order = models.IntegerField()
    date_off_start_time = models.DateTimeField(null=True)
    date_off_end_time = models.DateTimeField(null=True)
    date_off_use_flag = models.BooleanField(default=False)
    repeat_off_date = models.CharField(max_length=20, null=True)
    repeat_off_start_time = models.CharField(max_length=4, null=True)
    repeat_off_end_time = models.CharField(max_length=4, null=True)
    repeat_off_use_flag = models.BooleanField(default=False)
    alert_use_flag = models.SmallIntegerField(default=1, choices=ALERT_USER_FLAG)
    reg_date = models.DateTimeField(auto_now=True, auto_now_add=True)

    class Meta:
        app_label = 'configuration'
        db_table = 'clb_alert_group'
        unique_together = ("alert_base_id", "clb_group_name")
        ordering = ['sort_order']

    class SpectrumMeta:
        allow_delete = True

    def __unicode__(self):
        return u"%s"%self.clb_group_name

    @property
    def is_snoonzed(self):
        """
        current alert group is in scheduled maintenance
            or turn off the alarm at the request time.

        return boolean True
          - True is current alert group do not alerm off.
          - False is alerm on.
        """
        _weekday = {
            0 : 1, # monday
            1 : 2, # Tuesday
            2 : 3, # Wednesday
            3 : 4, # Thursday
            4 : 5, # Friday
            5 : 6, # Saturday
            6 : 0, # sunday
        }
        _sp = ":"

        # every alert time information's tz is UTC+0
        cur_t = datetime.utcnow()

        if self.alert_use_flag in [1, 2]:
            if self.date_off_use_flag == True:
                if self.date_off_start_time <= cur_t and \
                    self.date_off_end_time >= cur_t:
                    return True

            if self.repeat_off_use_flag == True:
                if self.repeat_off_date is None:
                    return False

                weekday = [int(i) for i in self.repeat_off_date.split(_sp)]
                if _weekday[cur_t.weekday()] in weekday:
                    start_time = int(self.repeat_off_start_time)
                    end_time = int(self.repeat_off_end_time)
                    cur_time = int(cur_t.strftime("%H%M"))

                    if start_time > end_time:
                        # do something
                        if start_time <= cur_time and 2359 >= cur_time:
                            return True

                        if 0000 <= cur_time and end_time >= cur_time:
                            return True
                    else:
                        if start_time <= cur_time and end_time >= cur_time:
                            return True
                else:
                    return False
            return False
        else:
            return True

class CLBAlertGroupHasCLBDomain(InterimModel):
    clbalertgrouphasclbdomain_id = models.AutoField(db_column='id', primary_key=True)
    clb_alert_group = models.ForeignKey(CLBAlertGroup, db_column='clb_alert_group_id')
    statmaster = models.ForeignKey(StatMaster, db_column='statmaster_id')

    class Meta:
        app_label = 'configuration'
        db_table = 'clb_alert_group_has_clb_domain'
        unique_together = ("clb_alert_group", "statmaster")

    class SpectrumMeta:
        allow_delete = True

class CLBAlertRecipients(BaseModel):
    clbalertrecipients_id = models.AutoField(db_column='id', primary_key=True)
    alert_base_id = models.ForeignKey(CLBAlertManagementBase, db_column='alert_base_id')
    username = models.CharField(max_length=100, null=True)
    email = models.CharField(max_length=100, null=True)
    phone_number = models.CharField(max_length=50)
    comment = models.CharField(max_length=100)

    class Meta:
        app_label = 'configuration'
        db_table = 'clb_alert_recipients'

    class SpectrumMeta:
        allow_delete = True

class CLBAlertGroupHasRecipients(InterimModel):
    clbalertgrouphasrecipients_id = models.AutoField(db_column='id', primary_key=True)
    clb_alert_group = models.ForeignKey(CLBAlertGroup, db_column='clb_alert_group_id')
    clb_alert_recipients = models.ForeignKey(CLBAlertRecipients, db_column='clb_alert_recipients_id')

    class Meta:
        app_label = 'configuration'
        db_table = 'clb_alert_group_has_recipients'

    class SpectrumMeta:
        allow_delete = True


def get_clbalert_group(statmaster, account_no):
        groupHasDomain = CLBAlertGroupHasCLBDomain.all_objects.filter(statmaster=statmaster)

        if groupHasDomain.exists():
            return {'group_id':groupHasDomain[0].clb_alert_group.clbalertgroup_id, 'group_name':groupHasDomain[0].clb_alert_group.clb_group_name, 'sort_order':groupHasDomain[0].clb_alert_group.sort_order}
        else:
            group = CLBAlertGroup.all_objects.filter(alert_base_id__account_no=account_no, group_type=0)

            if group.exists():
                return {'group_id':group[0].clbalertgroup_id, 'group_name':group[0].clb_group_name, 'sort_order':group[0].sort_order}
            else :
                return {'group_id':0, 'group_name':'', 'sort_order':0}

class CLBAlertDomainFailHistory(InterimModel):
    id = models.AutoField(primary_key=True)
    statmaster = models.ForeignKey(StatMaster, db_column='statmaster_id')
    fail_message = models.CharField()
    update_time = models.DateTimeField()

    class Meta:
        app_label = 'configuration'
        unique_together = (('statmaster_id', 'update_time'),)
        db_table = 'clb_alert_domain_fail_history'

    def get_domain(self):
        return self.statmaster.display_name

class CLBAlertVipFailHistory(InterimModel):
    id = models.AutoField(primary_key=True)
    account_no = models.ForeignKey(CustomerAccount, db_column='account_no')
    vip_addr = models.CharField()
    vip_probe_name = models.CharField()
    val = models.IntegerField()
    fail_message = models.CharField()
    update_time = models.DateTimeField()

    class Meta:
        app_label = 'configuration'
        unique_together = (('account_no', 'vip_addr', 'vip_probe_name', 'update_time'),)
        db_table = 'clb_alert_vip_fail_history'

class CLBAlertDomainSnapshot(InterimModel):
    statmaster = models.ForeignKey(StatMaster, db_column='statmaster_id', primary_key=True)
    status = models.SmallIntegerField(editable=False,
        choices=DOMAIN_MON_STATUS,
        default=0)
    tot_vip_cnt = models.IntegerField(default=0)
    fail_vip_cnt = models.IntegerField(default=0)
    domain_fail_history = models.ForeignKey(CLBAlertDomainFailHistory, db_column='domain_fail_history_id', null=True)
    update_time = models.DateTimeField()

    class Meta:
        app_label = 'configuration'
        db_table = 'clb_alert_domain_snapshot'

    def get_domain(self):
        return self.statmaster.display_name

    def get_group(self):
        return get_clbalert_group(self.statmaster, self.statmaster.customer.account.account_no)

    def get_account_no(self):
        return self.statmaster.customer.account.account_no


class SettingCount(BaseModel):
    id = models.AutoField(primary_key=True)
    name = models.CharField(unique=True, max_length=50)
    count = models.IntegerField()

    class Meta:
        app_label = 'configuration'
        db_table = 'setting_count'
