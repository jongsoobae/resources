import json
from datetime import datetime
from django.db import models
from django.conf import settings
from django.contrib.auth.models import User
from django.core.validators import MaxValueValidator, MinValueValidator
# import pysvn
from spectrum_api.shared_components.models import BaseModel
from spectrum_api.shared_components.utils.svn_client import get_login, ssl_server_trust_prompt
from spectrum_api.shared_components.utils import shared_constants
from spectrum_api.shared_components.models.mailer import EventActionQueue, EventManager

GOLD_PHASE = 1000

STATUS_CHOICES = shared_constants.PUSH_STATUS_CHOICES

MODEL_FIELD_MAP = {'zone_id':'dns_zone',
                   'domain_id':'gslb_domain',
                   'pop_id':'base_pop'}

def get_revision_number(config_group_name, config_type_name):
    try:
        from django.utils import importlib
        svnurl = settings.CONFIG_SVN_SERVER + "/" + config_group_name + "_" + config_type_name

        pysvn = importlib.import_module('pysvn')
        client = pysvn.Client()
        if svnurl.find("https://") > -1:
            client.callback_get_login = get_login
            client.callback_ssl_server_trust_prompt = ssl_server_trust_prompt
        revision = client.revpropget('revision', url=svnurl)[0].number
        return revision
    except Exception,e:
        return -1

def set_extra_meta(action_id, extra_data_key, context):
    """
        Some of config group need extra meta informations when try to Config push(deploy).
        and they are insert to "ConfigDistAction" and "ConfigDistActionExtra".

        This function use for insert extra_meta information.

        Relevant CONFIG GROUPs
         - BASE
            * condition_field : pop_id
         - GSLB
            * (Non-CLB) condition_field : domain_id
            * (CLB) condition_field : zone_id
         - CDNS
            * condition_field : zone_id
    """
    from spectrum_api.shared_components.utils.common import insert_many
    #TODO: beginning django 1.4, bulk_create function has been introduced. Need to replace insert_many with bulk_create
    extra_data = context.get(extra_data_key, None)
    if type(extra_data) is str:
        extra_data = [extra_data]

    try:
        objects = []
        #TODO: improve performance with get_latest_change_action_history_id
        for target_pk in extra_data:
            change_history_action_id = ConfigDistActionExtra.get_latest_change_action_history_id(
                MODEL_FIELD_MAP.get(extra_data_key), target_pk)
            data = {'action':action_id,
                    'condition_field':extra_data_key,
                    'data':target_pk,
                    'change_history_action_id':change_history_action_id,
                    'date_created':datetime.now()}
            objects.append(ConfigDistActionExtra(**data))
            if len(objects) > 200:
                insert_many(objects)
                objects = []
        insert_many(objects)
    except Exception as e:
        #failed to insert action_extra table as bulk insert, insert row by row
        for target_pk in extra_data:
            change_history_action_id = ConfigDistActionExtra.get_latest_change_action_history_id(
                MODEL_FIELD_MAP.get(extra_data_key), target_pk)
            extra_ = ConfigDistActionExtra.objects.create(action=action_id,
                                condition_field=extra_data_key,
                                data=target_pk,
                                change_history_action_id=change_history_action_id,
                                date_created=datetime.now())

class ConfigGroup(BaseModel):
    config_group_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100, unique=True)
    obj_state = models.SmallIntegerField(default=1, editable=False)

    def get_types(self):
        return ConfigType.objects.filter(config_group=self).order_by('name',)

    def __unicode__(self):
        return u'%s' % self.name

    class Meta:
        app_label = 'configuration'
        db_table = 'config_group'
        ordering = ['name']


class ConfigGroupProduct(BaseModel):
    config_group_product_id = models.AutoField(primary_key=True)
    product = models.CharField(max_length=50)
    config_group = models.ForeignKey(ConfigGroup, db_column='config_group_id')
    obj_state = models.SmallIntegerField(default=1, editable=False)

    class Meta:
        app_label = 'configuration'
        db_table = 'config_group_product'
        unique_together = ('product', 'config_group')
        ordering = ['product', 'config_group']

    def __unicode__(self):
        return (u'%s/%s') % (self.config_group, self.name)


class ConfigType(BaseModel):
    config_type_id = models.AutoField(primary_key=True)
    config_group = models.ForeignKey(ConfigGroup, db_column='config_group_id')
    name = models.CharField(max_length=100)
    obj_state = models.SmallIntegerField(default=1, editable=False)
    promote_time = models.IntegerField(default=0)
    is_sequence = models.BooleanField(default=False)

    def get_phases(self):
        return ConfigPhase.objects.filter(config_type=self).order_by('sequence',)

    class Meta:
        app_label = 'configuration'
        db_table = 'config_type'
        unique_together = ('config_group', 'name')
        ordering = ['config_group', 'name']

    def __unicode__(self):
        return (u'%s/%s') % (self.config_group, self.name)


class ConfigPhase(BaseModel):
    config_phase_id = models.AutoField(primary_key=True)
    config_type = models.ForeignKey(ConfigType, db_column='config_type_id')
    name = models.CharField(max_length=100)
    sequence = models.IntegerField(default=0)
    obj_state = models.SmallIntegerField(default=1, editable=False)

    class Meta:
        app_label = 'configuration'
        db_table = 'config_phase'
        unique_together = (('config_type', 'name'), ('config_type', 'sequence'))
        ordering = ['config_type', 'sequence', 'name']

    def __unicode__(self):
        return (u'%s/%s') % (self.config_type, self.name)

    def is_joint_push(self):
        config_joints = ConfigJointGroup.objects.filter(config_phase=self)
        return config_joints.exists()


class ConfigJoint(BaseModel):
    config_joint_id = models.AutoField(primary_key=True)
    config_joint_name = models.CharField(max_length=100)
    is_visible = models.SmallIntegerField(default=1)

    class Meta:
        app_label = 'configuration'
        db_table = 'config_joint'
        ordering = ['config_joint_id']

    def __unicode__(self):
        return (u'%s') % (self.config_joint_name)

    def getJointConfigGroupName(self):
        group_list = ConfigJointGroup.objects.filter(config_joint=self.pk)
        group_list = [str(item.config_phase.config_type.config_group) for item in group_list]
        return " + ".join(group_list)


class ConfigJointGroup(BaseModel):
    config_joint_group_id = models.AutoField(primary_key=True)
    config_joint = models.ForeignKey(ConfigJoint, db_column='config_joint_id')
    config_phase = models.ForeignKey(ConfigPhase, db_column='config_phase_id')
    obj_state = models.SmallIntegerField(default=1, editable=False)

    class Meta:
        app_label = 'configuration'
        db_table = 'config_joint_group'
        unique_together = ('config_joint', 'config_phase')
        # ordering = ['config_joint', 'config_phase']
        ordering = ['config_joint_group_id']

    def __unicode__(self):
        return (u'%s') % (self.config_phase)

def save_user_push_action(action_id, push_action_type, request=None, is_joint_push=False, description=''):
    """
    In case of joint push, parent_joint_action_id is required as action_id.
    :param action_id: if joint action, parent_joint_action_id is required
    :param push_action_type: push_to_staging or push_to_production
    :param request:
    :return:
    """
    try:
        from spectrum_api.shared_components.models import UserActionHistory, get_userinfo_as_tuple_from_context
        user_id, user_email, user_ip, app_name = get_userinfo_as_tuple_from_context(request)
        user_action = UserActionHistory(user_id=user_id,
                                        user_email=user_email,
                                        app_name=app_name,
                                        action_type=push_action_type,
                                        related_action_id=action_id,
                                        user_ip=user_ip)
        user_action.save()

        if push_action_type in [shared_constants.PUSH_TO_PRODUCTION, shared_constants.PUSH_TO_STAGING]:
            try:
                event_key = "%s_%s_%s" % (str(push_action_type), user_email, str(user_action.pk))
                event_manager = user_action.get_event_manager()
                event_action_queue = EventActionQueue(event_key=event_key,
                                                 event_manager=event_manager,
                                                 action_type=push_action_type,
                                                 related_action_id=user_action.pk,
                                                 description="%s %s %s" % (app_name, push_action_type, description),
                                                 create_user=user_email)
                event_action_queue.save()
            except Exception,e:
                pass
    except Exception,e:
        pass


class ConfigDistAction(BaseModel):
    action_id = models.AutoField(primary_key=True, db_column='action_id')
    to_phase = models.ForeignKey(ConfigPhase, db_column='to_phase_id', null=True)
    from_phase = models.ForeignKey(ConfigPhase, db_column='from_phase_id', null=True, related_name='from_phase_set')
    config_revision = models.IntegerField(default=-1, validators=[MinValueValidator(-1), MaxValueValidator(2147483647)])
    previous_revision = models.IntegerField(default=-1, validators=[MinValueValidator(-1), MaxValueValidator(2147483647)])
    time_created = models.DateTimeField()
    time_deployed = models.DateTimeField(null=True)
    user = models.ForeignKey(User, db_column='user_id', null=True)
    status = models.SmallIntegerField(null=True, default=0, choices=STATUS_CHOICES)
    status_msg = models.CharField(max_length=500, null=True)
    action_keyword = models.CharField(db_column='action_keyword', max_length=100, null=True, blank=True)
    description = models.CharField(db_column='description', max_length=1024, null=True, blank=True)
    config_joint = models.ForeignKey(ConfigJoint, db_column='config_joint_id', null=True)
    parent_joint_action_id = models.IntegerField(null=True)
    exist_extra = models.NullBooleanField(null=True)

    class Meta:
        app_label = 'configuration'
        db_table = 'config_dist_action'

    class SpectrumMeta:
        track = False

    def is_joint_push(self):
        try:
            return self.to_phase.is_joint_push()
        except:
            return False

    def is_CLB_Myinfra_push(self):
        from spectrum_api.configuration.models.config import ConfigDistActionExtra
        dist_action_extras = ConfigDistActionExtra.objects.filter(action=self, condition_field='pop_id')
        return dist_action_extras.exists()

    def is_CDNS_push(self):
        from spectrum_api.configuration.models.config import ConfigDistActionExtra
        dist_action_extras = ConfigDistActionExtra.objects.filter(action=self, condition_field='zone_id')
        return dist_action_extras.exists()

    def is_push_task_done(self):
        """
        In case of joint push, it needs to track all related action status
        othrwise, check self.status in [shared_constants.CONFIG_COMPLETED, shared_constants.CONFIG_FAILED]
        :return:
        """
        if self.is_joint_push():
            related_actions = ConfigDistAction.objects.filter(action_id=self.parent_joint_action_id)
            if related_actions.exists():
                for action in related_actions:
                    if action.status not in [shared_constants.CONFIG_COMPLETED, shared_constants.CONFIG_FAILED]:
                        return False
                return True
            else:
                return self.status in [shared_constants.CONFIG_COMPLETED, shared_constants.CONFIG_FAILED]
        else:
            return self.status in [shared_constants.CONFIG_COMPLETED, shared_constants.CONFIG_FAILED]


    def is_push_done_and_ok(self):
        """
        In case of joint push, it needs to track all related action status
        otherwise, just check self.status is shared_constants.CONFIG_COMPLETED
        :return:
        """
        if self.is_joint_push():
            related_actions = ConfigDistAction.objects.filter(action_id=self.parent_joint_action_id)
            if related_actions.exists():
                for action in related_actions:
                    if action.status != shared_constants.CONFIG_COMPLETED:
                        return False
                return True
            else:
                return self.status == shared_constants.CONFIG_COMPLETED
        else:
            return self.status == shared_constants.CONFIG_COMPLETED

    def is_push_failed(self):
        """
        check self.status is shared_constants.CONFIG_FAILED
        In case of joint push, it needs to track all related action status
        :return:
        """
        if self.is_joint_push():
            related_actions = ConfigDistAction.objects.filter(action_id=self.parent_joint_action_id)
            if related_actions.exists():
                for action in related_actions:
                    if action.status != shared_constants.CONFIG_FAILED:
                        return False
                return True
            else:
                return self.status == shared_constants.CONFIG_FAILED
        else:
            return self.status == shared_constants.CONFIG_FAILED

    def get_related_zone_names_message(self, key_name=None, template_rule=None):
        from spectrum_api.dns.models.dns import DNSZone
        zone_list = self.get_related_zone_list()
        zone_name_list = DNSZone.objects.filter(pk__in=zone_list).values_list('domain_name', flat=True)
        result_message = "\r\n".join(list(zone_name_list))
        result_message = "%s:\r\n %s" % (key_name.replace("_"," "), result_message)
        return result_message

    def get_related_zone_list(self, key_name=None, template_rule=None):
        from spectrum_api.configuration.models.config import ConfigDistActionExtra
        dist_action_extras = ConfigDistActionExtra.objects.filter(action=self)
        result_list = []
        for action_extra in dist_action_extras:
            result_list += action_extra.get_related_zone_list()

        return result_list

    def get_pushed_server_group_names_message(self, key_name=None, template_rule=None):
        from spectrum_api.configuration.models.clb import CustomerContractPop
        from spectrum_api.configuration.models.config import ConfigDistActionExtra
        pop_list = ConfigDistActionExtra.objects.filter(action=self,
                                                        condition_field='pop_id').values_list('data', flat=True)
        result_list = CustomerContractPop.objects.filter(pop__pk__in=pop_list).values_list('pop_alias', flat=True)
        result_message = "\r\n".join(list(result_list))
        result_message = "%s:\r\n %s" % (key_name.replace("_"," "), result_message)
        return result_message


    def get_pushed_zone_names_message(self, key_name=None, template_rule=None):
        from spectrum_api.dns.models.dns import DNSZone
        from spectrum_api.configuration.models.config import ConfigDistActionExtra
        zone_list = ConfigDistActionExtra.objects.filter(action=self,
                                                        condition_field='zone_id').values_list('data', flat=True)
        zone_name_list = DNSZone.objects.filter(pk__in=zone_list).values_list('domain_name', flat=True)
        result_message = "\r\n".join(list(zone_name_list))
        result_message = "%s:\r\n %s" % (key_name.replace("_"," "), result_message)
        return result_message

    def get_pushed_clb_domains_message(self, key_name=None, template_rule=None):
        from spectrum_api.dna.models.domain import Domain
        from spectrum_api.configuration.models.config import ConfigDistActionExtra
        zone_list = ConfigDistActionExtra.objects.filter(action=self,
                                                        condition_field='zone_id').values_list('data', flat=True)
        domain_list = Domain.objects.filter(clb_dns_zone__pk__in=zone_list).values_list('name', flat=True)
        result_message = "\r\n".join(list(domain_list))
        result_message = "%s:\r\n %s" % (key_name.replace("_"," "), result_message)
        return result_message

    def get_footer_message(self, key_name=None, template_rule=None):
        rule = json.loads(template_rule) if template_rule else {}
        if key_name and rule.has_key(key_name):
            result = rule.get(key_name).get('default', '')
        else:
            result = rule.get('default','')
        return result

    def get_push_result_message(self, key_name=None, template_rule=None, ignore_key_output=True):
        rule = json.loads(template_rule) if template_rule else {}
        if key_name and rule.has_key(key_name):
            if self.is_push_done_and_ok():
                result = rule.get(key_name).get('on_success','Configuration was successfully published on Cloud DNS Servers.')
            elif self.is_push_failed():
                result = rule.get(key_name).get('on_failure','Configuration push failed.')
            else:
                result = rule.get(key_name).get('default','Configuration push is not completed yet.')
        else:
            result = rule.get('default','Configuration push is not completed yet.')
        if key_name and not ignore_key_output:
            result = "%s:\r\n %s" % (key_name.replace("_"," "), result)
        return result

    def generate_notification_message(self, event_manager):
        message_list = []
        title, template, template_rule, init_dict = event_manager.generate_message()

        FOOTER = "Footer"
        template_rule_dict = json.loads(template_rule)
        mydict = {FOOTER: self.get_footer_message(FOOTER, template_rule)}
        for mykey in template_rule_dict.keys():
            mydict.update({mykey: self.get_push_result_message(mykey,template_rule)})
        title_dict = {}
        if self.is_CLB_Myinfra_push():
            SERVER_GROUP_KEY = "Server_Groups"
            RELATED_ZONE_KEY = "Related_Zones"
            mydict.update({SERVER_GROUP_KEY: self.get_pushed_server_group_names_message(SERVER_GROUP_KEY, template_rule),
                      RELATED_ZONE_KEY: self.get_related_zone_names_message(RELATED_ZONE_KEY, template_rule)})
        elif self.is_CDNS_push():
            ZONE_NAME_KEY = "Zone_Name"
            CLB_DOMAIN_KEY = "CLB_Domains"
            title_dict = {ZONE_NAME_KEY: ",".join(list(self.get_pushed_zone_names()))}
            mydict.update({ZONE_NAME_KEY: self.get_pushed_zone_names_message(ZONE_NAME_KEY, template_rule),
                      CLB_DOMAIN_KEY: self.get_pushed_clb_domains_message(CLB_DOMAIN_KEY, template_rule)})

        try:
            for mykey in template_rule_dict.keys():
                title_dict.update({mykey: self.get_push_result_message(mykey,template_rule)})
            title = title.format(**title_dict)
        except:
            pass

        for key, value in init_dict.iteritems():
            init_dict.update({key:mydict.get(key, '')})
        try:
            template_message = template.format(**init_dict)
        except:
            template_message = template
        message_list.append(template_message)

        return title, "\r\n".join(message_list)

    def check_if_already_deployed_http_sites_push(self):
        is_already_deployed = False
        related_parent_action_id = self.parent_joint_action_id
        config_group_name = self.to_phase.config_type.config_group.name
        if config_group_name == 'HTTP_SITES' and self.status == 4:
                #and "This revision is already deployed" in self.status_msg: #completed
            identical_push_actions = ConfigDistAction.objects.filter(config_revision=self.config_revision)
            latest_promoted_global_actions = identical_push_actions.\
                exclude(parent_joint_action_id=self.parent_joint_action_id).filter(from_phase=self.to_phase)
            if latest_promoted_global_actions.exists():
                is_already_deployed = True
                related_parent_action_id = latest_promoted_global_actions[0].parent_joint_action_id
        return is_already_deployed, related_parent_action_id

    def save_user_push_action(self, request=None, config_type_name=''):
        try:
            from spectrum_api.shared_components.utils.common import get_userinfo_as_tuple_from_context
            from spectrum_api.shared_components.models import UserActionHistory, \
                PUSH_TO_STAGING, PUSH_TO_PRODUCTION
            push_action_type = PUSH_TO_STAGING if config_type_name == 'CFGT' else PUSH_TO_PRODUCTION
            user_id, user_email, user_ip, app_name = get_userinfo_as_tuple_from_context(request)
            user_action = UserActionHistory(user_id=user_id,
                                            user_email=user_email,
                                            app_name=app_name,
                                            action_type=push_action_type,
                                            related_action_id=self.pk,
                                            user_ip=user_ip)
            user_action.save()
        except Exception,e:
            pass

    def save(self, *args, **kwargs):
        request = kwargs.get('request', None)
        clb_flag = kwargs.pop("clb_flag", None)
        post_process = False

        try:
            from django.utils import importlib
            config_group_name = self.to_phase.config_type.config_group.name
            config_type_name = self.to_phase.config_type.name

            if config_group_name.upper() == 'BASE':
                if clb_flag is not None and clb_flag == 1:
                    pass
                else:
                    from spectrum_api.configuration.models.clb import CustomerContractPop
                    from spectrum_api.configuration.models.base import Pop
                    clbpops = CustomerContractPop.all_objects.filter(use_type=1).values('pop')  # when server group disabled at aurora ui, obj_state set as 0. so all_objects query needs

                    non_clb_pops = Pop.objects.exclude(pk__in=clbpops)
                    if config_type_name.upper() == 'CFGT':
                        pass
                        # at prism it doesn't need to push base pop xml to staging environment, only customer clb pop need to be tested.
                        # if conig_type == cfgt, it doesn't need to update no_clbpops to status 1
                        # non_clb_pops.update(status=1)
                    elif config_type_name.upper() == 'CFG':
                        #[prismui-2413] we decided to let be_config lock pops instead of UI.
                        non_clb_pops.update(status=3)
                        self.exist_extra = True
                        post_process = True

            if config_group_name.upper() == 'GSLB':
                if clb_flag is not None and clb_flag == 1:
                    pass
                else:
                    from spectrum_api.dna.models.domain import Domain
                    non_clb_domains = Domain.objects.filter(clb_dns_zone__isnull=True)
                    if config_type_name.upper() == 'CFGT':
                        pass
                        # at prism it doesn't need to push gslb domain xml to staging environment, only customer clb domain need to be tested.
                        # clb_domains.update(status=1)
                    elif config_type_name.upper() == 'CFG':
                        non_clb_domains.update(status=3)
                        self.exist_extra = True
                        post_process = True

            self.previous_revision = get_revision_number(config_group_name,config_type_name)
        except Exception, e:
            from spectrum_api.shared_components.utils.common import log_error
            log_error(None, str(e), e)

        super(ConfigDistAction, self).save(*args, **kwargs)
        self.save_user_push_action(request, config_type_name)
        try:
            if self.to_phase.config_type.configphase_set.filter(sequence__gt=self.to_phase.sequence, sequence__lt=1000).exists():
                ConfigDistAction.objects.filter(pk=self.pk).update(parent_joint_action_id=self.pk)
        except (Exception, ):
            pass
        if post_process:
            if config_group_name.upper() == 'BASE':
                if clb_flag is not None and clb_flag == 1:
                    pass
                else:
                    if config_type_name.upper() == 'CFGT':
                        pass
                    elif config_type_name.upper() == 'CFG':
                        pops = non_clb_pops.values_list('pop', flat=True)
                        set_extra_meta(self, 'pop_id', {'pop_id':pops})

            if config_group_name.upper() == 'GSLB':
                if clb_flag is not None and clb_flag == 1:
                    pass
                else:
                    if config_type_name.upper() == 'CFGT':
                        pass
                    elif config_type_name.upper() == 'CFG':
                        domains = non_clb_domains.values_list('domain_id', flat=True)
                        set_extra_meta(self, 'domain_id', {'domain_id':domains})


class ConfigDistState(BaseModel):
    phase = models.OneToOneField(ConfigPhase, db_column='config_phase_id', primary_key=True)
    action = models.OneToOneField(ConfigDistAction, db_column='action_id')

    class Meta:
        app_label = 'configuration'
        db_table = 'config_dist_state'

    class SpectrumMeta:
        track = False

class ConfigDistActionExtra(BaseModel):
    action = models.ForeignKey(ConfigDistAction, primary_key=True)
    condition_field = models.CharField(max_length=50)
    data = models.PositiveIntegerField()
    change_history_action_id = models.PositiveIntegerField(null=True, blank=True)
    date_created = models.DateTimeField(auto_now_add=True)
    class Meta:
        app_label = 'configuration'
        db_table = 'config_dist_action_extra'

    class SpectrumMeta:
        track = False

    @classmethod
    def get_latest_change_action_history_id(cls, model_name, model_pk):
        from spectrum_api.shared_components.models import LatestChangeAction
        try:
            latest_action = LatestChangeAction.objects.get(model_name=model_name, model_pk=model_pk)
            change_history_action_id = latest_action.change_action_history_id
        except LatestChangeAction.DoesNotExist:
            change_history_action_id = None
        return change_history_action_id


    def get_related_zone_list(self):
        if self.condition_field == 'zone_id':
            return [int(self.data)]
        elif self.condition_field == 'domain_id':
            from spectrum_api.dna.models.domain import Domain
            try:
                domain = Domain.objects.get(pk=self.data)
                return [domain.clb_dns_zone.pk]
            except:
                pass
        elif self.condition_field == 'pop_id':
            from spectrum_api.configuration.models.base import Pop
            pop = Pop.objects.get(pk=self.data)
            clb_zone_list = [x.pk for x in pop.get_related_clb_zones()]
            return clb_zone_list
        return []