
# Copyright (c) 2011 CDNetworks Co., Ltd.
# All rights reserved.
#
# $Id: gslb.py 11864 2014-01-02 02:15:00Z kookheon.kwon $
#

from django.core.exceptions import ValidationError
from django.core.validators import MaxValueValidator, MinValueValidator, \
     RegexValidator
from django.db import models

from spectrum_api.configuration.models import Model
from spectrum_api.shared_components.models import HistoryModel
from spectrum_api.configuration.models.base import VipSearch
from spectrum_api.configuration.models.help_msg import H_ENABLE_GSLB, \
    H_NUM_THREADS, H_GSLB_DNS_PORT, H_MAX_CLIENT_RECORDS, H_RTT_REQUEST_INTERVAL, \
    H_PKTLOSS_MOVE_RATE, H_BASEDOMAIN, H_TXT_PREFIX, H_TXT_PASSWORD, \
    H_GEOIP_FILENAME, H_STATIC_DOMAIN_ANSWER_TTL, H_FORWARDER, H_FORWARDER_TYPE, H_FORWARDER_PORT, \
    H_DEBUG_PORT, H_DEBUG_TIMEOUT, H_REQUEST_LOG_ROTATE_INTERVAL, \
    H_FAILURE_LOG_ROTATE_INTERVAL, H_LOG_FAILURE, H_LOG_FORWARD, \
    H_GSLB_MAX_RESOLUTION_T, H_GSLB_CNAME_LATENCY_USE, H_LOG_PROBE, \
    H_LOG_PEDOMAIN_REQUEST, H_PROBE_LOG_ROTATE_INTERVAL, H_GSLB_IPADDR, H_GSLB_INTERFACE, H_DNS_PORT
from spectrum_api.dna.models.help_msg import H_ENABLE_VCPDNS, H_ENABLE_STAT, \
    H_LOG_REQUEST, H_STICKY, H_LIST_ALL, H_SLOWSTART_PERIOD, H_ANSWER_COUNT, \
    H_ANSWER_TTL, H_CUT_OFF, H_TOLERANCE, H_PERCENT, H_COUNT, H_LB_TYPE, \
    H_ENABLE_EDNS_SUBNET, H_ENABLE_CNAME_LATENCY, H_COST_FACTOR, H_PKT_IGNORE, \
    H_UPLINK_IGNORE, H_UPLINK_FACTOR, H_UPPERBOUND, H_LOWERBOUND, \
    H_GEOIP_DEFAULT, H_GEOIP_CONTINENT, H_COUNTRY, H_REGION, H_STATE, H_CITY, \
    H_ISP, H_ASN, H_SCALING_FACTOR, H_NODATA_ACTION
from spectrum_api.shared_components.models.fields import InfinityFloatField
from spectrum_api.shared_components.utils.regex import gslb_domain_rex, \
    txt_prefix_rex, ip_range_rex


LB_TYPES = (
    (0, 'GSLB'),
    (1, 'RR'),
    (2, 'RANDOM'),
)
SELECT_TYPES = (
    (0, 'False'),
    (1, 'True'),
)
SELECT_CNAME_LATENCY_USE_TYPES = (
        (0, 'NO_USE'),
        (1, 'TEST_ONLY'),
        (2, 'IF_PING_FAILS'),
    )

class DomainProperties(HistoryModel):
    enable_gslb = models.SmallIntegerField(
        choices=SELECT_TYPES,
        blank=True,
        null=True,
        help_text=H_ENABLE_GSLB
    )
    enable_vcpdns = models.SmallIntegerField(
        choices=SELECT_TYPES,
        blank=True,
        null=True,
        help_text=H_ENABLE_VCPDNS
    )
    enable_stat = models.SmallIntegerField(
        choices=SELECT_TYPES,
        blank=True,
        null=True,
        help_text=H_ENABLE_STAT
    )
    log_request = models.SmallIntegerField(
        choices=SELECT_TYPES,
        blank=True,
        null=True,
        help_text=H_LOG_REQUEST
    )

    sticky = models.SmallIntegerField(
        choices=SELECT_TYPES,
        blank=True,
        null=True,
        help_text=H_STICKY
    )
    list_all = models.SmallIntegerField(
        choices=SELECT_TYPES,
        blank=True,
        null=True,
        help_text=H_LIST_ALL
    )
    slowstart_period = models.PositiveIntegerField(
        blank=True,
        null=True,
        validators=[MaxValueValidator(4294967295)],
        help_text=H_SLOWSTART_PERIOD
    )
    answer_count = models.PositiveSmallIntegerField(
        blank=True,
        null=True,
        validators=[MinValueValidator(1), MaxValueValidator(30)],
        help_text=H_ANSWER_COUNT
    )
    answer_ttl = models.PositiveIntegerField(
        blank=True,
        null=True,
        validators=[MaxValueValidator(4294967295)],
        help_text=H_ANSWER_TTL
    )
    cutoff = InfinityFloatField(
        blank=True,
        null=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_CUT_OFF
    )
    tolerance = models.FloatField(
        blank=True,
        null=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_TOLERANCE
    )
    fallback_percent = models.PositiveSmallIntegerField(
        blank=True,
        null=True,
        validators=[MaxValueValidator(100)],
        help_text=H_PERCENT
    )
    fallback_count = models.PositiveIntegerField(
        blank=True,
        null=True,
        validators=[MaxValueValidator(4294967295)],
        help_text=H_COUNT
    )

    load_balancing_type = models.SmallIntegerField(
        choices=LB_TYPES,
        blank=True,
        null=True,
        help_text=H_LB_TYPE
    )
    enable_edns_client_subnet = models.SmallIntegerField(
        choices=SELECT_TYPES,
        blank=True,
        null=True,
        help_text=H_ENABLE_EDNS_SUBNET
    )
    enable_cname_latency = models.SmallIntegerField(
        choices=SELECT_TYPES,
        blank=True,
        null=True,
        help_text=H_ENABLE_CNAME_LATENCY
    )
    class Meta:
        abstract = True

class PopMetric(HistoryModel):
    cost_scaling_factor = models.FloatField('Cost Scaling factor',
        blank=True,
        null=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_COST_FACTOR)
    pktloss_ignore = models.SmallIntegerField(
        'Packet Loss Ignore',
        null=True,
        choices=SELECT_TYPES,
        blank=True,
        help_text=H_PKT_IGNORE)
    uplink_ignore = models.SmallIntegerField(
        'Uplink Ignore',
        null=True,
        choices=SELECT_TYPES,
        blank=True,
        help_text=H_UPLINK_IGNORE)
    uplink_scaling_factor = models.FloatField('Uplink Scaling factor',
        blank=True,
        null=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_UPLINK_FACTOR)

    class Meta:
        abstract = True

class DistanceMetric(HistoryModel):
    rtt_upperbound = models.FloatField(
        blank=True,
        null=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_UPPERBOUND)
    rtt_lowerbound = models.FloatField(
        blank=True,
        null=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_LOWERBOUND)
    geoip_default = models.FloatField(
        'Default',
        blank=True,
        null=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_GEOIP_DEFAULT)
    geoip_continent = models.FloatField(
        blank=True,
        null=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_GEOIP_CONTINENT)
    geoip_country = models.FloatField(
        blank=True,
        null=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_COUNTRY)
    geoip_region = models.FloatField(
        blank=True,
        null=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_REGION)
    geoip_state = models.FloatField(
        blank=True,
        null=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_STATE)
    geoip_city = models.FloatField(
        blank=True,
        null=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_CITY)
    geoip_isp = models.FloatField(
        blank=True,
        null=True,
        validators=[MinValueValidator(0.0), MaxValueValidator(1.0)],
        help_text=H_ISP)
    geoip_asn = models.FloatField(
        blank=True,
        null=True,
        validators=[MinValueValidator(0.0), MaxValueValidator(1.0)],
        help_text=H_ASN)
    distance_scaling_factor = models.FloatField(
        blank=True,
        null=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_SCALING_FACTOR)

    class Meta:
        abstract = True

class GSLB(DomainProperties, PopMetric, DistanceMetric):
    gslb_id = models.AutoField(primary_key=True)
    vip = models.ForeignKey(VipSearch,
        unique=True,
        related_name='gslbconfig',
        null=True)
    num_threads = models.PositiveSmallIntegerField(
        blank=True,
        validators=[MaxValueValidator(16)],
        help_text=H_NUM_THREADS
    )
    dns_port = models.PositiveIntegerField(
        'DNS Port',
        blank=True,
        validators=[MinValueValidator(1), MaxValueValidator(65535)],
        help_text=H_GSLB_DNS_PORT
    )
    max_client_records = models.PositiveIntegerField(
        blank=True,
        validators=[MinValueValidator(1), MaxValueValidator(2147483647)],
        help_text=H_MAX_CLIENT_RECORDS
    )
    rtt_request_interval = models.PositiveIntegerField(
        blank=True,
        validators=[MaxValueValidator(4294967295)],
        help_text=H_RTT_REQUEST_INTERVAL
    )
    pktloss_move_rate = models.FloatField(
        blank=True,
        validators=[MinValueValidator(0.0), MaxValueValidator(1.0)],
        help_text=H_PKTLOSS_MOVE_RATE
    )
    basedomain = models.CharField(
        blank=True, max_length=256,
        validators=[RegexValidator(gslb_domain_rex)],
        help_text=H_BASEDOMAIN
    )
    txt_prefix = models.CharField(
        blank=True, max_length=256,
        validators=[RegexValidator(txt_prefix_rex)],
        help_text=H_TXT_PREFIX
    )
    txt_password = models.CharField(
        blank=True, max_length=256,
        help_text=H_TXT_PASSWORD
    )
    geoip_filename = models.CharField(
        blank=True, max_length=4096,
        help_text=H_GEOIP_FILENAME
    )
    static_domain_answer_ttl = models.PositiveIntegerField(
        blank=True,
        validators=[MaxValueValidator(4294967295)],
        help_text=H_STATIC_DOMAIN_ANSWER_TTL
    )
    forwarder_addr = models.IPAddressField(blank=True,
        help_text=H_FORWARDER)
    FORWARDER_TYPES = (
        (0, 'STANDARD'),
        (1, 'PEDNS'),
    )
    forwarder_type = models.SmallIntegerField(
        blank=True,
        null=True,
        choices=FORWARDER_TYPES,
        help_text=H_FORWARDER_TYPE)
    debug_port = models.PositiveIntegerField(
        'Port',
        blank=True,
        validators=[MinValueValidator(1), MaxValueValidator(65535)],
        help_text=H_DEBUG_PORT
    )
    debug_timeout = models.FloatField(
        blank=True,
        validators=[MinValueValidator(1),
                    MaxValueValidator(4294967295)],
        help_text=H_DEBUG_TIMEOUT
    )
    request_log_rotate_interval = models.PositiveIntegerField(
        blank=True,
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)],
        help_text=H_REQUEST_LOG_ROTATE_INTERVAL
    )
    failure_log_rotate_interval = models.PositiveIntegerField(
        blank=True,
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)],
        help_text=H_FAILURE_LOG_ROTATE_INTERVAL
    )
    log_failure = models.SmallIntegerField(blank=True,
        null=True,
        choices=SELECT_TYPES,
        help_text=H_LOG_FAILURE
    )
    log_forward = models.SmallIntegerField(blank=True,
        null=True,
        choices=SELECT_TYPES,
        help_text=H_LOG_FORWARD
    )
    date_created = models.DateTimeField(
        'Date Created',
        auto_now_add=True
    )
    date_modified = models.DateTimeField(
        'Date Modified',
        auto_now=True
    )
    nodata_action = models.CharField(
        blank=True,
        null=True,
        max_length=20,
        help_text=H_NODATA_ACTION
    )
    max_resolution_time = models.IntegerField(
        blank=True,
        null=True,
        verbose_name="Max Resolution Time",
        validators=[MinValueValidator(0), MaxValueValidator(5000)],
        help_text=H_GSLB_MAX_RESOLUTION_T
    )
    cname_latency_use = models.SmallIntegerField(
        choices=SELECT_CNAME_LATENCY_USE_TYPES,
        blank=True,
        null=True,
        max_length=10,
        verbose_name="CNAME Latency",
        help_text=H_GSLB_CNAME_LATENCY_USE
    )
    log_probe = models.SmallIntegerField(
        choices=SELECT_TYPES,
        blank=True,
        null=True,
        help_text=H_LOG_PROBE
    )
    log_pedomain_request = models.SmallIntegerField(
        choices=SELECT_TYPES,
        blank=True,
        null=True,
        help_text=H_LOG_PEDOMAIN_REQUEST
    )
    probe_log_rotate_interval = models.IntegerField(
        blank=True,
        null=True,
        verbose_name="Probe Log rotate interval",
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_PROBE_LOG_ROTATE_INTERVAL
    )

    def __unicode__(self):
        if self.pk == 1:
            return "Global Configuration"
        return "GSLB Configuration for %s" % self.vip

    def clean(self):
        if self.nodata_action and len(self.nodata_action) > 0:
            if self.nodata_action.upper() != 'FORWARD' and self.nodata_action.upper() != 'IGNORE' and self.nodata_action.upper() != 'REFUSE':
                raise ValidationError({'__all__':"Invalid nodata_action value %s. It should be one of 'FORWARD','IGNORE','REFUSE'" % (self.nodata_action)})

    class Meta:
        app_label = 'configuration'
        db_table = 'gslb_config'
        ordering = ['vip__ip']

    class SpectrumMeta:
        allow_delete = True

class ForwarderPort(HistoryModel):
    forwarder_port_id = models.AutoField(primary_key=True,
        db_column='id')
    gslb = models.ForeignKey('GSLB',
        related_name='forwarder_port_set')
    forwarder_port = models.PositiveIntegerField(
        blank=True,
        default=5353,
        validators=[MinValueValidator(1), MaxValueValidator(65535)],
        help_text=H_FORWARDER_PORT)

    def __unicode__(self):
        return 'GSLB Forwarder port about %s' % (self.gslb)

    class Meta:
        app_label = 'configuration'
        db_table = 'gslb_forwarder_port'

    class SpectrumMeta:
        allow_delete = True

class GSLBInterface(HistoryModel):
    id = models.AutoField(primary_key=True)
    gslb_id = models.ForeignKey(GSLB, db_column='gslb_id')
    interface = models.CharField(max_length=40,
                        db_column='interface_id',
                        help_text=H_GSLB_INTERFACE)
    port = models.IntegerField(db_column='port',
                        blank=True,
                        null=True,
                        validators=[MinValueValidator(1), MaxValueValidator(65535)],
                        help_text=H_DNS_PORT)
    class Meta:
        app_label = 'configuration'
        db_table = 'gslb_config_interface'
        unique_together = ('gslb_id', 'interface',)
        verbose_name = "DNS Listen Interface"
        ordering = ['interface', ]

    class SpectrumMeta:
        allow_delete = True

class GSLBIPAddr(HistoryModel):
    id = models.AutoField(primary_key=True)
    gslb_id = models.ForeignKey(GSLB, db_column='gslb_id')
    ipaddr = models.CharField(max_length=40,
                        verbose_name='IP Address',
                        validators=[RegexValidator(ip_range_rex)],
                        db_column='ipaddr',
                        help_text=H_GSLB_IPADDR)
    port = models.IntegerField(db_column='port',
                        blank=True,
                        null=True,
                        validators=[MinValueValidator(1), MaxValueValidator(65535)],
                        help_text=H_DNS_PORT)
    class Meta:
        app_label = 'configuration'
        db_table = 'gslb_config_ipaddr'
        unique_together = ('gslb_id', 'ipaddr',)
        verbose_name = "DNS Listen IP Address"
        verbose_name_plural = "DNS Listen IP Addresses"
        ordering = ['ipaddr', ]

    class SpectrumMeta:
        allow_delete = True
