#
# Copyright (c) 2011 CDNetworks Co., Ltd.
# All rights reserved.
#
# $Id$
#

from django.utils.translation import ugettext as _

H_PRIMARY_PROBE = _(
'''Primary probe to monitor this pop.
Backup probes are used only when the primary probe is none or expired.
'''
)

H_PKTLOSS = _(
'''The threshold of the packet loss percentage.
If the packet loss rate of this pop exceeds the threshold,
then this pop is marked as down.

<strong>* Default: 100</strong>
* Acceptable range: 0.0 - 100.0
'''
)

H_RTT_SERVER = _(
'''IP address of RTT server of this pop. When requested by gslb,
RTT server measures latency between this pop and a given IP.
The latency is then reported to all gslbs located in same pop
with the original requester.

The gslb maintains RTT between all clients and pops. If this
data does not exist, or has expired, then gslb requests the
RTT server of the concerned pop to measure the RTT.

A pop can be associated with zero or one RTT server.
One RTT server can be shared by multiple pops.

Attribute 'addr' is mandatory.
Change requires gslb reload.
'''
)

H_PKTLOSS_SERVER = _(
'''IP address of packet loss servers of this pop. Packet loss servers
of each pop periodically send/reply UDP packets each other and report
the packet loss rates measured.

When a pop is associated with multiple packet loss servers, a packet
loss server of lowest packet loss rate will represent the pop. For
example, if this pop is associated with two packet loss servers whose
observed packet loss rates are 100% and 0% each, gslb will consider
this pop is having 0% of packet loss.

A pop can be associated with zero or more packet loss servers.
A packet loss server can be shared by multiple pops.
Attribute 'addr' is mandatory.

Change requires gslb, probe and rms reload.
'''
)

H_FORWARDER = _(
'''Address of the name server to which gslb forwards every request that
it cannot respond. This is a global configuration for all gslbs. We
can override it per pop or per gslb.

Forwarding happens when the requested domain is disabled on gslb side
or the requested record type is not supported by gslb. As of now, we
use named(BIND) as a forwarder running on each and every gslb machine.
It is the actual authoritative name server for Cloud DNS today.

Only one IP address and maximum 10 port numbers can be specified.
If multiple port numbers are given, gslb evenly distributes forward
packets on the multiple ports.

Default address is 127.0.0.1

Any changes require gslb reload.

For the 'addr' attribute,
* value range: valid IPv4 address string''')

H_FORWARDER_PORT = _(
'''Maximum 10 ports are allowed per forwarder.
Default port number is 5353.  ''')

H_FORWARDER_TYPE = _(
'''
There are two different forwarder types:
"STANDARD" for any standard name servers such as BIND,
"PEDNS" for Panther Express DNS.

For PEDNS type forwarder, gslb adds "x1.2.3.4."(where 1.2.3.4 is
the source IP of DNS query) in front of the original question name
if the requested record type was A or TXT or ANY. For example,
when gslb gets an A record request for www.foo.com from 1.2.3.4,
gslb forwards x1.2.3.4.www.foo.com to PEDNS type forwarder. This
is called X-forwarding and it is to provide the source IP to pedns
so that pedns can use the source IP for routing decision. When
gslb gets reply for X-forwarded query, gslb removes back the prefix
part(x1.2.3.4. in this example) from question name and then send
the reply to the original requester.

For STANDARD type forwarder or for other record types than A, TXT
or ANY, gslb doesn't modify the question name in the middle of
forwarding.

Default type is STANDARD.
'''
)

H_IHMSPOP = _(
''' This is from IHMS.
''')

H_ENABLE_GSLB_POP = _(
'''Enable/disable GSLB to return any vips of this pop to client.
So, FALSE forbids GSLB to sending any traffic to this pop.

In detail, when this flag is FALSE, GSLB will exclude any vips
of this pop from selection process even though Probe Agents are saying
the vips are up.
This is similar to the way how GSLB handles the down vips
but there is a difference: When GSLB does random selection
because of no available vips there, GSLB will include down vips
in the selection but not disabled vips.

<strong>* Default: FALSE.</strong>
''')

H_SERVER_MANAGE_IP = _(
''' This ip is for server management.
we can pick up one of vips within this pop.
''')

H_ENABLE_GSLB = _(
'''Enable/disable GSLB to return any vips of this system to client.
So, FALSE forbids GSLB to sending any traffic to this system.

This flag is NOT EFFECTIVE if the pop level $enable_gslb is FALSE.
That means once you disable GSLB for the pop,
GSLB would not be enabled for this system even if you set this flag TRUE.

<em>See the pop level enable_gslb for more detail.</em>

<strong>* Default: True</strong>
''')

H_EDGE_NAME = _(
'''A edge could be used as an aliase of multiple vips.
The edges are not mutually exclusive.

* The edge name should be specified in max 63 characters.
''')

H_CUSTOMER_POPNAME = _(
'''If this pop is for a customer, the name should be started with C.
If this pop is for a vender, the name should be started with V.

ex) C1-SJC, V1-SJC
''')

H_POPNAME = _(
'''If this pop is for a customer, the name should be started with C.
If this pop is for a vender, the name should be started with V.

ex) C1-SJC, V1-SJC, P0-SJC
''')

H_COST = _(
'''Certain POPs might have a fixed constant $cost
that can be included in score calculation of GSLB
as a penalty of the POPs.

<strong>* Default: 0</strong>
* Acceptable range: 0.0 - 4294967295.0
''')

H_POPGROUP = _(
'''A pop can belong to multiple pop groups.
This information is used to define static rules for a domain.

For example, a pop can belong to a group: "US".
We can then define a static rule in the domain configuration file
saying that all requests from the US for this domain should always be
served by the "US" pop group.
''')

H_CUSTOMER_SYSTEMNAME = _(
'''If this system is for a customer, the name should be started with s.
and you can write only number after string 's'.

ex) s1, s123
''')

H_CUSTOMER_HOSTNAME = _(
'''If this host is for a customer, the name should be start with h,
and you can write only number after string 'h'.

ex) h1, h123
'''
)

H_CUSTOMER_VIPNAME = _(
'''If this vip is for a customer, the name should be start with i,
and you can write only number after string 'i'.

ex) i1, i123
'''
)

H_CUSTOMER_VIPADDR = _(
'''
'''
)

H_MPROXY_SHIELD = _(
'''Existence of this tag indicates that there is a mproxy
shield running on this vip. For mproxy, this IP will be
used to listen for incoming MP connection and to make
active MP connection to the other shields.

Within a host, only one vip can be marked as mproxy shield.
Otherwise, mproxy will error out and exit.

The gslb uses this information for marking mproxy shield
IPs in VCP DNS response so that the client(mproxy edge)
can distinguish shield IPs from the others.

Change requires gslb reload and mproxy restart.
'''
)

H_MPROXY_OUTGOING_IP = _(
'''We can specify which IP mproxy should be used to make
outgoing conneciton except MP connection. MP connection
will be made from the mproxy shield vip.

Within a host, only one vip can be marked as mproxy
outgoing IP. Otherwise, mproxy will error out and exit.

If a host does not have any mproxy outgoing IP, mproxy
will use the mproxy shield vip as the outgoing IP.

Change requires mproxy restart.
'''
)

H_SYSTEM = _('''The system located in this pop.''')
H_HOST = _('''The host on this system.''')
H_VIP = _('''The virtual IP on this host''')

'''
[configuration > base > BaseProbeConfig] help messages.
'''

H_PROBE_NAME = _(
''' "GSLB" as probe name is special.
If a vip has "GSLB" probe, the vip address is recognized
as an GSLB address
and all the probe reports would be sent to the address.
''')

H_PROBE_NAME = _(
'''A string consists of any alphabet, digit, _, -, ~, =, *, +, :, / and . characters.
Maximum allowed length is 63 characters.
'''
)

H_PROBE_DESC = _('''
    Purpose of description is to help users to understand the purpose or intended usage of the particular configuration.
    This field accepts free text input of up to 1000 characters.
''')
H_PROBE_INTERVAL = _(
'''Interval in seconds at which to launch the probe.
The interval is computed from the time the last request
was completed, i.e. either result received or timed out.
This is common for every type and every protocol.

Change requires gslb, probe and rms reload.

<strong>* Default: 300 (If null, probe use this value.)</strong>
* value range: 1 ~ 4294967295 seconds.
''')

H_PROBE_TTL_FACTOR = _(
'''This is used only by the GSLB.

Every probe metric is stored by the GSLB for T seconds, where:

T = $interval * $ttl_factor

T is thus the GSLB-side TTL for this probe metric.
If the probe metric is more than TTL seconds old,
the probe is considered to be down by GSLB.
Setting it to 1 or less is not advisable since it can lead to a small TTL.
As such, the probe could be marked as down even
though the cause is really network delays in probe metric propagation.

Change requires gslb and rms reload.

<strong>* Default: 2.5 (If null, probe use this value.)</strong>
* value range: 1.0 ~ 4294967295.0
''')

H_PROBE_THESHOLD = _(
'''Threshold of the probed value.
If the probed value exceeds this value,
the <probe> would be marked as down.
This is common for every type and every protocol.

Change requires probe reload.


<strong>* Default: 500.0 (If null, probe use this value.)</strong>
* value range: 0 ~ 4294967295
* <em> 0(zero) means no threshold. </em>
''')

H_PROBE_REPORT = _(
'''Flag to enable probe report toward to gslb. Only the probes
whose report flag is set to true can be used for probe_metric
in domain configuration.
This is common for every type and every protocol.

Change requires gslb and probe reload.

<strong>* Default: False (If null, probe use this value.)</strong>
''')

H_PROBE_REPORTOTHER = _(
'''Flag to enable probe report toward the report_to addresses
specified in cdnet.xml. Only the probes whose report_other
flag is set to true will be shown through RMS.
This is common for every type and every protocol.

Change requires probe and rms reload.

<strong>* Default: False (If null, probe use this value.)</strong>
''')

H_PROBE_LOG = _(
'''Flag to enable logging of the probed value.
This is common for every type and every protocol.

Change requires probe reload.

<strong>* Default: False (If null, probe use this value.)</strong>
''')

H_PROBE_TIMEOUT = _(
'''Timeout of the outstanding request in seconds.

If no response back in this amount of time,
the probe would be marked as down.

This is only for STANDALONE type, common for every protocol.
Change requires probe reload.

<strong>* Default: 3.0 (If null, probe use this value.)</strong>
* value range: 1.0 ~ 4294967295.0
''')

H_PROBE_TRY_COUNT = _(
'''This value represent total try count for probe health check.

<strong>(Try Count * Timeout) + Try Count < Interval</strong>
* No Validation when Try Count = 1.

This is only for STANDALONE type, common for every protocol.
Change requires probe reload.

<strong>* Default: 1 (If null, probe use this value.)</strong>
* value range: 1 ~ 5
''')

H_PROBE_SCALING = _(
'''
Multiplier, in case the probed value needs to be
converted to a different scale.
For example, this could be 0.000008, in case of
converting 'Bytes' to 'Mega bits'.
This is common for every type and every protocol.

Change requires probe reload.

<strong>* Default: 1.0 (If null, probe use this value.)</strong>
* value range: 0 ~ 4294967295
''')

H_PROBE_RATEFUNC = _(
'''Definition of the rate function.
This is common for every type and every protocol.

If this is defined, the probing would be done twice with some
time span and the rate of value change(per second) would be used
as the probed value, instead of the actual probed value.

This should be used only for the probes whose value never decreases
except the case of wrapping around.

If the two probing is done but the former value is greater than
the later value, the former value is discarded and one more probing
would be done after the timespan. This is a consideration for
probing a counter whose value is wrapping around, such as an output
octet counter supported by SNMP agent.

This is the time span in seconds between the two probing.
Note that time span cannot be greater than the probe interval.
It will be self adjusted if greater value is given.

* value range: (1 ~ 4294967295) seconds.
''')

H_PROBE_RATIO_BASE = _(
''' If the ratio_based flag is set to TRUE, instead of the actual
probed value, the percentage of the probed value against the
threshold is used in boundary comparison.
This is common for every type and every protocol.

Change requires probe reload.
''')

H_PROBE_STEPFUNC = _(
'''Definition of the step function.

If this is defined, the probed value would be converted
by the step function written in following syntax.

Syntax:
&nbsp; &nbsp; {boundary_1} : {new_value_1}
&nbsp; &nbsp; {boundary_2} : {new_value_2}
&nbsp; &nbsp; ...
&nbsp; &nbsp; {boundary_n} : {new_value_n}

Converting flow:
&nbsp; &nbsp; If the probed value is less than or equal to the {boundary_1},
&nbsp; &nbsp; &nbsp; &nbsp; the {new_value_1} is assigned to the value.
&nbsp; &nbsp; Else if the value is less than or equal to the {boundary_2},
&nbsp; &nbsp; &nbsp; &nbsp; the {new_value_2} is assigned to the value.
&nbsp; &nbsp; ...
&nbsp; &nbsp; Else if the value is less than or equal to the {boundary_n},
&nbsp; &nbsp; &nbsp; &nbsp; the {new_value_n} is assigned to the value.
&nbsp; &nbsp; Else
&nbsp; &nbsp; &nbsp; &nbsp; the probe is marked as down.

The maximum length of the step function is 1024 bytes.

This is common for every type and every protocol.
''')

'''
    Aggregate probe help messages.
'''

H_PROBE_AGGREGATE = _(
''' "AGGREGATE" type is used to combine multiple probe values.
''')

H_PROBE_AGGRE_TYPE = _(
'''AGGREGATE type probe gets value by combining
weighted values of its sub probes.

There are three types of aggregation:
"SUM" type sums all sub probe values.
"BEST" type picks one best(=lowest) sub probe value.
"POP_SUM" type adds up the sub probe value of every vip
on this pop. This type is only for the uplink probes.
See sample-pop.xml for more information.

A sub probe can itself be an AGGREGATE probe.
Theoretically, there is an infinite level of recursion.

When an AGGREGATE probe is associated with a vip (in
sample-pop.xml), the sub probes are assumed to be
associated with the same vip. It is permissible to
use the sub probes from a different vip. In this case,
the vip has to be explicitly specified (see below).
However, that vip needs to be probed by same probe agent.

This can be overridden in pop config file. However,
in that case, ALL the sub probes must be redefined,
even when you want to override only a few of them.

This is only for AGGREGATE type.

Any changes require probe reload.

<strong>* Default: "SUM"</strong>
''')

H_PROBE_AGGRE_SUBPROBE = (
'''List of the sub probes to be aggregated.
In this example, value of the AGGREGATE probe will be:

[value of tcp_connections] * 1.0 +
[value of webcache_resptime] * 1.0 +
[value of ping] * 0.5
''')

H_PROBE_AGGRE_WEIGHT = _(
'''This is the weight of this sub probe.
<strong>* Default: 1.0</strong>
* value range: 0 ~ 4294967295
''')

H_PROBE_AGGRE_VIP = _(
'''This specifies the IP address of this sub probe.
If the sub probe has the same vip as that of the aggregate,
this can be omitted (default).
If a different vip is specified, that vip must be
probed by same agent.
''')

'''
    ICMP PROBE help messages.
'''

H_ICMP_TYPE = _(
'''This is the ICMP type to be inserted into the packet.
Only the type number 8, which means ECHO is supported now.

This is only for ICMP protocol.
Change requires probe reload.

<strong> * Default: 8. (if null, probe use this value)</strong>
''')

H_ICMP_VALUE = _(
'''The type of estimating value from the response.

The only type supported now is the "RESPONSE_TIME",
which means the value is the elapsed milliseconds
between request and response.

This is only for ICMPP protocol.
Change requires probe reload.

<strong> * Default: "RESPONSE_TIME" (if null, probe use this value)</strong>
''')

H_SNMP_VERSION = _(
'''The SNMP version to use.
Version 1, 2(or "2c") and 3 are supported now.
Change requires probe reload.

<strong> * Default: 2 (if null, probe use this value)</strong>
''')

H_SNMP_PORT = _(
'''The port to send the SNMP request.
Change requires probe reolad.

* value range: 1 ~ 65535
<strong> * Default: 161 (if null, probe use this value)</strong>
''')

H_SNMP_OID = _(
'''The OID to be queried through SNMP protocol.
This MUST be specified.

Only numeric OID is supported.
Use snmptranslate to change alphabetic OID to numeric OID.
ex] snmptranslate -On SNMPv2-MIB::sysName

OID should qualify followings:
1. Must be consist of 1 or more subids. (Subid is a numeric value
in range 0~4294967295)
2. Subids must be separated by dot(".") character.
3. Can start with "." or any numeric character but must end with
a numeric character.
4. Cannot contain more than 255 characters.
''')

H_SNMP_OID_TYPE = _(
'''"NORMAL" is for single probe with the OID.
"AVERAGE_SUBTREE" is for multiple probe with
all the subtree of the OID and averaging all the
probed values.
"ATTACH_IFNUMBER" is for single probe with attaching
the interface number of the IP address
at the tail of the OID.

This is only for SNMP protocol.
Change requires probe reload.

<strong> * Default: NORMAL (if null, probe use this value)</strong>
''')

H_SNMP_COMMUNITY = _(
'''The community string for SNMP v1 and v2c messages.
Equivalent with -c option of snmpget.

This is only for SNMP protocol.
Change requires probe reload.

<strong>* Default: public. (if null, probe use this value)</strong>
* value range: Limited to 63 characters long.
''')

H_SNMP_USERNAME = _(
'''Set the username(=security name) for SNMP v3 messages.
Equivalent with -u option of snmpget.

<strong>* Default: probe. (if null, probe use this value)</strong>
* value range: Limited to 63 characters long.
''')

H_SNMP_SECURITY_LEVEL = _(
'''Set the security level for SNMP v3 messages.
Equivalent with -l option of snmpget.

This is only for SNMP protocol.

Change requires probe reload.
<strong>* default: noAuthNoPriv. (if null, probe use this value)</strong>
''')

H_SNMP_AUTH_PROTOCOL = _(
'''Set the authentication protocol for SNMP v3 messages.
Equivalent with -a option of snmpget.

T his is only for SNMP protocol.
<strong>* Default: MD5. (if null, probe use this value)</strong>
''')

H_SNMP_AUTH_PW = _(
'''Set the authentication pass phrase for SNMP v3 messages.
Equivalent with -A option of snmpget.

This is only for SNMP protocol.
Change requires probe reload.

<strong>* This MUST be specified.</strong>
* value range: any string not longer than 30 bytes
and not shorter than 8 bytes
''')

H_SNMP_PRIV_PROTOCOL = _(
'''Set the privacy protocol for SNMP v3 messages.
Equivalent with -x option of snmpget.

This is only for SNMP protocol.
Change requires probe reload.
<strong>* Default: DES. (if null, probe use this value)</strong>
''')

H_SNMP_PRIV_PW = _(
'''Set the authentication pass phrase for SNMP v3 messages.
Equivalent with -A option of snmpget.

This is only for SNMP protocol.
Change requires probe reload.

<strong>* This MUST be specified.</strong>
* value range: any string not longer than 30 bytes
and not shorter than 8 bytes
''')

H_SNMP_CONTEXT = _(
'''Set the context name for SNMP v3 messages.
Equivalent with -n option of snmpget.

This is only for SNMP protocol.
Change requires probe reload.

* Default: empty string "".
* DB value range: any string not longer than 255 bytes
''')

H_SNMP_VALUE = _(
'''The type of estimating value from the response.

"EMBEDDED" means the value is embeded in the response.
"RESPONSE_TIME" means the value is the elapsed milliseconds
between request and response.

This is only for SNMP protocol.
Change requires probe reload.

<strong>* Default: EMBEDDED. (if null, probe use this value)</strong>
* value range: "EMBEDDED" or "RESPONSE_TIME"
''')

H_TCP_PORT = _(
'''The port to connect.
This is only for TCP protocol.
This MUST be specified.

Change requires probe reload.

* value range: 1 ~ 65535
''')

H_MESSAGE = _(
'''The message to be sent after the TCP connection.

Do not leave any meaningless space characters in <message>
because they would be treated as a part of the string.
Following escape characters are supported.
\\a, \\b, \\e, \\E, \\f, \\n, \\r, \\t, \\v, \\\, \\', \\"

This is only for TCP protocol.
Change requires probe reload.

<strong>* Default: no message.</strong>
* value range: any string not longer than 65535 bytes
''')

H_TCP_CONTENT_LENGTH = _(
'''The maximum size of the content that can be retrieved.
This is only for TCP protocol.
Change requires probe reload.

<strong>* Default: -1</strong>
* value range: -1 ~ 65535
* Note: -1 has exactly same meaning as 65535
* Note: 0 means the probing is finished right after sending
the message without waiting for a response
''')

H_TCP_VALUE = _(
'''The type of estimating value from the response.

"RESPONSE_TIME" means the value is the elapsed milliseconds
between request and response, including connect time.

"CONNECT_TIME" means the value is the elapsed milliseconds
for establising TCP connection.

"CONNECTIVITY" means the value is:
&nbsp; &nbsp; 0 for the $port is connectable,
&nbsp; &nbsp; -1(marked as down) for otherwise.

"REGEX_VALUE" means the value is obtained by matching
the response text with the regular expression $regex.
The value would be a numeric string matched by the first
parenthesis of the $regex.
For example, if you want to extract 12345 from "load: 12345",
you can use "load: ([0-9]+)" as the $regex.

"REGEX_RESPONSE_TIME" means the value is the elapsed msecs
between request and response, including connect time, only if
the response text is matched with the $regex.

Change requires probe reload.

<strong> * Default type: "RESPONSE_TIME".</strong>
''')

H_TCP_REGEX = _(
'''The regular expression to be matched when the type is
 "REGEX_VALUE" or "REGEX_RESPONSE_TIME".

 Do not leave any meaningless space characters in $regex
 because they would be treated as a part of the string.

 Following escape characters are supported.
 \\a, \\b, \\e, \\E, \\f, \\n, \\r, \\t, \\v, \\\\, \\', \\"

* value range: any string not longer than 255 bytes.
''')

H_SSL_VERIFY_SERVER = _(
'''Should we ask for server certificate verification?

Note, this only works when <ca_path> in probe_agent.xml is given
properly. Make sure to test if it works well before pushing it into
production.

Verification here means only the peer certificate verification
during SSL connection time. Hence, application protocol specific
verification, like host name matching in https, is not supported.

There was no practical usecase or well-written requirements for the
verification so far. If any, please provide detail requirements to
Engineering before using this in production so that we can improve
this to be more useful.

Change requires probe reload.
<strong>* Default: False </strong>
''')

H_SSL_PORT = _(
'''The port to connect.

This is only for  SSL protocol.
Change requires probe reload.

<strong>* Default: 443 </strong>
* value range: 1 ~ 65535
''')

H_SSL_MESSAGE = _(
'''The message to be sent after the SSL connection.

Do not leave any meaningless space characters in $message
because they would be treated as a part of the string.

Following escape characters are supported.
\\a, \\b, \\e, \\E, \\f, \\n, \\r, \\t, \\v, \\\\, \\', \\"

* value range: any string not loger than 65535 bytes.
<strong>* Default: no message.</strong>
''')

H_SSL_CONTENT_LENGTH = _(
'''The maximum size of the content that can be retrieved.
This is only for SSL protocol.
Change requires probe reload.

<strong>* Default: -1</strong>
* value range: -1 ~ 65535
* Note: -1 has exactly same meaning as 65535
* Note: 0 means the probing is finished right after sending
the message without waiting for a response
''')

H_SSL_VALUE = _(
'''The type of estimating value from the response.

"RESPONSE_TIME" means the value is the elapsed milliseconds
between request and response, including connect time.

"CONNECT_TIME" means the value is the elapsed milliseconds
for establising TCP and SSL connection.

"CONNECTIVITY" means the value is:
&nbsp; &nbsp; 0 for the SSL connection through the $port is available,
&nbsp; &nbsp; -1(marked as down) for otherwise.

"REGEX_VALUE" means the value is obtained by matching
the response text with the regular expression $regex.
The value would be a numeric string matched by the first
parenthesis of the $regex.
For example, if you want to extract 12345 from "load: 12345",
you can use "load: ([0-9]+)" as the $regex.

"REGEX_RESPONSE_TIME" means the value is the elapsed msecs
between request and response, including connect time, only if
the response text is matched with the $regex.

Change requires probe reload.

<strong>* Default: "RESPONSE_TIME" </strong>
''')

H_SSL_REGEX = _(
'''The regular expression to be matched
when the type is "REGEX_VALUE" or "REGEX_RESPONSE_TIME".

Do not leave any meaningless space characters in $regex
because they would be treated as a part of the string.

Following escape characters are supported.
\\a, \\b, \\e, \\E, \\f, \\n, \\r, \\t, \\v, \\\\, \\', \\"

* value range: any string not longer than 255 bytes.
''')

H_UDP_PORT = _(
'''The port to connect.
This is only for UDP protocol.
This MUST be specified.

Change requires probe reload.

* value range: 1 ~ 65535
''')

H_UDP_MESSAGE = _(
'''The message to be sent.

Do not leave any meaningless space characters in <message>
because they would be treated as a part of the string.

Following escape characters are supported.
\\a, \\b, \\e, \\E, \\f, \\n, \\r, \\t, \\v, \\\, \\', \\"

This is only for UDP protocol.
Default is no message.
Change requires probe reload.

* value range: any string not longer than 65535 bytes.
''')

H_UDP_CONTENT_LENGTH = _(
'''The maximum size of the content that can be retrieved.

This is only for UDP protocol.
Change requires probe reload.

<strong>* Default: -1 </strong>
* value range: -1 ~ 65535
* Note: -1 means only the first part of the response,
read by first recv() call, will be retrieved
(maximum 65535 bytes)
* Note: 0 means the probing is finished right after sending
the message without waiting for a response
''')

H_UDP_VALUE = _(
'''The type of estimating value from the response.

"RESPONSE_TIME" means the value is the elapsed milliseconds
between request and response, including connect time.

"REGEX_VALUE" means the value is obtained by matching
the response text with the regular expression <regex>.
The value would be a numeric string matched by the first
parenthesis of the <regex>.
For example, if you want to extract 12345 from "load: 12345",
you can use "load: ([0-9]+)" as the <regex>.

"REGEX_RESPONSE_TIME" means the value is the elapsed msecs
between request and response, including connect time, only if
the response text is matched with the <regex>.

This is only for UDP protocol.
Change requires probe reload.

<strong>* Default: RESPONSE_TIME </strong>
''')

H_UDP_REGEX = _(
'''The regular expression to be matched when the type
is "REGEX_VALUE" or "REGEX_RESPONSE_TIME".

Do not leave any meaningless space characters in $regex
because they would be treated as a part of the string.

Following escape characters are supported.
\\a, \\b, \\e, \\E, \\f, \\n, \\r, \\t, \\v, \\\\, \\', \\"

* value range: any string not longer than 255 bytes.
''')

H_FTP_PORT = _(
'''The port to connect.

<strong>* Default: 21.</strong>
* value range: 1 ~ 65535
''')

H_FTP_USERNAME = _(
'''Username to be passed with USER command.
This is only for FTP protocol.

Change requires probe reload.

* value range: any string not longer than 255 bytes.
<strong>* Default: anonymous.</strong>
''')

H_FTP_PW = _(
'''Username to be passed with USER command.

This is only for FTP protocol.
Change requires probe reload.

* value range: any string not longer than 255 bytes
''')

H_FTP_PATH = _(
'''Path to the object file.
If the path is none, the content would be a result of
LIST command right after the login.

This is only for FTP protocol.
Change requires probe reload.

* value range: valid linux file path not longer than 4095 bytes
''')

H_FTP_CONTENT_LENGTH = _(
'''The maximum size of the content that can be retrieved.

Note that, only data incoming through the data channel are
treated as a content. In other words, any replies through
the control channel are not stored in the content buffer.

This is only for FTP protocol.
Change requires probe reload.

<strong>* Default: -1</strong>
* value range: -1 ~ 65535
* Note: -1 has exactly same meaning as 65535
* Note: 0 means the probing is finished when the first byte of
data is received but no bytes would be stored into the
content buffer
''')

H_FTP_VALUE = _(
'''The type of estimating value from the response.

"RESPONSE_TIME" means the value is the elapsed milliseconds
between request and response, including connect time.

"CONNECT_TIME" means the value is the elapsed milliseconds
for establising TCP connection.

"CONNECTIVITY" means the value is:
0 for the <port> is connectable,
-1(marked as down) for otherwise.

"REGEX_VALUE" means the value is obtained by matching
the content text with the regular expression <regex>.
The value would be a numeric string matched by the first
parenthesis of the <regex>.
For example, if you want to extract 12345 from "load: 12345",
you can use "load: ([0-9]+)" as the <regex>.

"REGEX_RESPONSE_TIME" means the value is the elapsed msecs
between request and response, including connect time, only if
the response text is matched with the <regex>.

This is only for FTP protocol.
Change requires probe reload.

<strong>* Default: "RESPONSE_TIME".</strong>
''')

H_FTP_REGEX = _(
''' The regular expression to be matched
when the type is "REGEX_VALUE" or "REGEX_RESPONSE_TIME".

Do not leave any meaningless space characters in $regex
because they would be treated as a part of the string.

Following escape characters are supported.
\\a, \\b, \\e, \\E, \\f, \\n, \\r, \\t, \\v, \\\\, \\', \\"

* value range: any string not longer than 255 bytes
''')

H_RTMP_PORT = _(
'''The port to connect.
This is only for RTMP protocol.

Change requires probe reload.

<strong>* Default: 1935.</strong>
* value range: 1 ~ 65535
''')

H_RTMP_ENCRIPTED = _(
'''Should we use encrypted mode(RTMPE)?

This is only for RTMP protocol.
Change requires probe reload.

<strong>* Default: False </strong>
''')

H_RTMP_VERIFY = _(
'''Should we verify the server in handshaking?

This is only for RTMP protocol.
Change requires probe reload.

<strong>* Default: False </strong>
''')

H_RTMP_APP = _(
'''The app name to be connected.

This is only for RTMP protocol.
Change requires probe reload.

<strong>* Default: None</strong>
* value range: valid uri stem not longer than 255
''')

H_RTMP_TCURL = _(
'''The tcurl parameter to be sent with 'connect' command.
It's typical form is: 'rtmp://domain:port/app'.

This is only for RTMP protocol.
Change requires probe reload.

<strong>* Default: None</strong>
* value range: valid url not longer than 255
''')

H_RTMP_FLASHVER = _(
'''The flashver parameter to be sent with 'connect' command.

This is only for RTMP protocol.
Change requires probe reload.

<strong>* Default: None</strong>
* value range: any string not longer than 63
''')

H_RTMP_STREAM = _(
'''The stream name to play.

This is only for RTMP protocol.
Change requires probe reload.

<strong>* Default: None</strong>
* value range: valid uri stem not longer than 255
''')

H_RTMP_VALUE = _(
'''The type of estimating value from the response.

"RESPONSE_TIME" means the value is the elapsed milliseconds
between request and response, including connect time.

"STREAM_AVAIL" means the value is:
0 for the stream is available(playable),
-1(marked as down) for otherwise.

"CONNECT_TIME" means the value is the elapsed milliseconds
for TCP connection and RTMP handshaking.

"CONNECTIVITY" means the value is:
0 for the RTMP handshaking through the <port> is available,
-1(marked as down) for otherwise.

"APP_CONNECT_TIME" means the value is the elapsed milliseconds
for connecting to the app.

"APP_CONNECTIVITY" means the value is:
0 for the app is connectable,
-1(marked as down) for otherwise.

This is only for RTMP protocol.
Change requires probe reload.

<strong>* Default: "RESPONSE_TIME".</strong>
''')

H_DNS_DOMAIN = _(
'''Domain name to be queried.

This is only for DNS protocol.
Change requires probe reload.

<strong>* Default: "localhost"</strong>
* value range: valid domain name
''')

H_DNS_CLASS = _(
'''Numeric value to be filled in the CLASS field of DNS query.
E.g. 1 for IN class, 3 for CHAOS class.

This is only for DNS protocol.
Change requires probe reload.

<strong>* Default: 1</strong>
* value range: 0 ~ 65535
''')

H_DNS_TYPE = _(
'''Numeric value to be filled in the TYPE field of DNS query.
E.g. 1 for A, 2 for NS, 5 for CNAME, 12 for PTR, 255 for ANY.

This is only for DNS protocol.
Change requires probe reload.

<strong>* Default: 255</strong>
* value range: 0 ~ 65535
''')

H_DNS_PORT = _(
'''The port to send a DNS query.

This is only for DNS protocol.
Change requires probe reload.

<strong>* Default: 53.</strong>
* value range: 1 ~ 65535
''')

H_DNS_VALUE = _(
'''The type of estimating value from the response.

"RESPONSE_TIME" means the value is the elapsed milliseconds
between request and response.

"UP_DOWN" means the value is
0 for the request responsed, regardless of the response code.
-1(marked as down) for otherwise.

"NO_ERROR" means the value is
0 for the request responsed with response code 0(NOERROR).
-1(marked as down) for otherwise.

"RESPONSE_CODE_MATCH" means the value is
0 for the request responsed with the expected response code,
which is specified by <response_code> below.
-1(marked as down) for otherwise.

"ANSWER_COUNT" means the value is the answer count in the response.
Remark that, the value would be 0, which has a positive meaning,
for the response containing no answers, which is probably a
negative response. You may use <stepfunc> to convert the value.
The value will be -1(marked as down) for any failure before
getting a response.

This is only for DNS protocol.
Change requires probe reload.

<strong>* Default: RESPONSE_TIME</strong>
''')

H_DNS_CODEMATCH = _(
'''The expected response code for "RESPONSE_CODE_MATCH" type.

E.g. 0 for NOERROR, 1 for FORMERR, 2 for SERVFAIL,
3 for NXDOMAIN, 4 for NOTIMPL, 5 for REFUSED, etc.

* value range: 0 ~ 15
 ''')

H_LOGXFER_PATTERN = _(
'''The pattern should be something that is understandable by glob(7).

This is glob pattern:
&nbsp; &nbsp; <em>?</em> matches exactly one character
&nbsp; &nbsp; <em>*</em> matches any number of characters (including none).
&nbsp; &nbsp; <em>{!glob}</em> Matches anything that does not match glob
&nbsp; &nbsp; <em>{a,b,c}</em> matches any one of a, b or c
&nbsp; &nbsp; <em>[abc]</em> matches any character in the set a, b or c
&nbsp; &nbsp; <em>[^abc]</em> matches any character not in the set a, b or c
&nbsp; &nbsp; <em>[0-9]</em> matches any digit.
&nbsp; &nbsp; <em>[A-Z]</em> matches any uppercase letter.
&nbsp; &nbsp; <em>[a-z,A-Z]</em> matches any uppercase or lowercase letter.

''')

H_LOGXFER_DOMAIN = _(
'''This is the domain name for the log collector.
it can be used with below keywords.
To use below keywords, the hostname should be NGP hostname.

&nbsp; &nbsp; $POP:       Pop name
&nbsp; &nbsp; $SYSTEM:    System id
&nbsp; &nbsp; $HOST:      Host id
&nbsp; &nbsp; $HOSTNAME:  Hostname Name

DEFAULT: logxfer.cdngp.net.
''')

H_LOGXFER_PORT = _(
'''This is port number of log collector

DEFAULT: 2108
''')

H_LOGXFER_USE_SSL = _(
'''Flag to indicate if the transfer should be done using SSL

DEFAULT: 0 (don't use ssl)
''')

H_LOGXFER_TIMEOUT = _(
'''This is the network timeout in seconds when trying to send the log file.

DEFAULT: 10 seconds
MIN: 1 second
MAX: 600 seconds
''')

H_LOGXFER_SEND_COMPRESSED = _(
'''This is the flag to indicate if the file should be compressed
before it is sent. If we compress the file,
then .gz is appended to the file name.

DEFAULT: 0 (FALSE)
''')

H_LOGXFER_MOVE = _(
'''Full path to the directory where the logfiles should be moved
after they have been successfully transferred. This can be used
to send log files to multiple locations.

DEFAULT: If this tag is not specified, then the file is deleted
''')

H_LOGXFER_WAITTIME = _(
'''This is time in seconds logxfer waits in between the checks
for new log files that need to be transferred.

DEFAULT: 60 seconds
MIN: 1 seconds
MAX: 600 seconds
''')

H_LOGXFER_BASEDIR = _(
'''In log collector, related path to the directory
where the log files should be saved

If this tag is used, the folder needs to be created under done,
uploads and verified folders on the log collector.

DEFAULT: If this is not specified, then a logfile will save in root dir
''')

H_LOGXFER_RENAME = _(
'''rename uses to change from a log file name
that is selected by pattern to renamed format.
this can be used for a service daemon dose not support NGP logging format.

DEFAULT: 0 (FALSE)
''')

H_LOGXFER_RENAMEKEY = _(
'''This is used in $rename_format.
it will be used to indicate whether the file is already renamed or not.

DEFAULT: LXRN
''')

H_LOGXFER_RENAMEFORMAT = _(
'''This is the renamed file format that is used
when a log file is saved on the server.
The various keywords are:

&nbsp; &nbsp; $RENAMEKEY rename keyword (mandetory)
&nbsp; &nbsp; $HOSTNAME  hostname
&nbsp; &nbsp; $POP       Pop name
&nbsp; &nbsp; &nbsp; &nbsp; To use this, hostname should be NGP hostname.
&nbsp; &nbsp; $SYSTEM    System id
&nbsp; &nbsp; &nbsp; &nbsp; To use this, hostname should be NGP hostname.
&nbsp; &nbsp; $HOST      Host id
&nbsp; &nbsp; &nbsp; &nbsp; To use this, hostname should be NGP hostname.

&nbsp; &nbsp; $DATETIME the time for a log file to be created.
&nbsp; &nbsp; &nbsp; &nbsp; plus renamed epoch time with
&nbsp; &nbsp; &nbsp; &nbsp; microseconds by logxfer.
&nbsp; &nbsp; &nbsp; &nbsp; format is yyyyMMddHHmmss-renamedtime
&nbsp; &nbsp; $EXT the extension of log file.

DEFAULT: $RENAMEKEY-$HOSTNAME-$DATETIME.$EXT
''')

H_LOGXFER_COPYPATH = _(
'''If a log file need to be uploaded to multiple servers,
we can use copy tag. A pattern can have multiful $copy.
if one more copy_path is defined, logxfer will copy a file
into the copy path before the file is uploaded to log collector.
after copy is done, the file will be transfered by its pattern.
''')

H_OVERRIDE_THRESHOLD = _(
'''Threshold can be overriden here.
<br/><br/>
* VALUE RANGE: 0.0 ~ 4294967295.0<br/>
* NOTE: 0(zero) means no threshold
'''
)

H_OVERRIDE_STEPFUNC = _(
'''Step function can be overriden here.<br/>
Note that we don't support override of 'ratio_based' attribute.
<br/><br/>
* VALUE RANGE: valid step function statement
               no longer than 1024 bytes
'''
)

H_OVERRIDE_TIMEOUT = _(
'''Timeout can be overriden here.
<br/><br/>
* VALUE RANGE : 1.0 ~ 4294967295.0
'''
)

# GSLB Help

H_NUM_THREADS = _(
'''The number of DNS worker threads.
Default is 0, which means the number of CPU cores.
Change requires gslb reload.

* VALUE RANGE : 0 ~ 16
'''
)

H_GSLB_DNS_PORT = _(
'''Port on which to send/receive DNS queries.
Change requires gslb restart.

* value range: 1 ~ 65535
'''
)

H_MAX_CLIENT_RECORDS = _(
'''The maximum number of clients in the client database.

Be careful to use too big number compared to the physical memory size
the gslb machine have. If this number is too big, gslb might not work
properly. It requires about (40 + 8 * #RTTserver) bytes of memory per
client record.

Change requires gslb restart.

* value range: 1 ~ 2147483647
'''
)

H_RTT_REQUEST_INTERVAL = _(
'''The RTT request sending interval per client and RTT server pair.
The gslb sends RTT request when:

a. The first time the client(LDNS) has been seen.

b. If the latest request sent time is greater than the latest
&nbsp;&nbsp;&nbsp;report received time, e.g. request sent but not reported yet,
&nbsp;&nbsp;&nbsp;the time this interval past from the latest request.

c. Otherwise, the time this interval past from the latest report
&nbsp;&nbsp;&nbsp;received. Based on the local time, not based on the measured
&nbsp;&nbsp;&nbsp;time included in the report.

If it is set to 0, the gslb will send a RTT request only at
the first time the client has been seen.

Change requires gslb reload.

* value range: 0 ~ 4294967295
'''
)

H_PKTLOSS_MOVE_RATE = _(
'''Rate of moving a pktloss value when a new pktloss report has come.

For Example, when a 50% of pktloss rate is reported to a pop which has
20% of the pktloss value before, then the pktloss value for the pop
becomes:
&nbsp;&nbsp;20 * pktloss_move_rate + 50 * (1 - pktloss_move_rate)

Change requires gslb reload.

* value range: 0.0 ~ 1.0
'''
)

H_BASEDOMAIN = _(
'''The gslb would answer for some static domains which has a form of:
[vip id]-[host id]-[system id].[popname].[basedomain].

The basedomain is specified here.
See gslb/domains/sample-domainset.xml for domain naming rules.

Change requires gslb reload.

* value range: valid domain name
'''
)

H_TXT_PREFIX = _(
'''
Prefix for debug TXT record. When queried, debug TXT returns some
debug information for resolution of corresponding domain. This only
applies to gslb enabled domains.

For example, if this prefix is set "prefix-", you can query TXT
of prefix-www.foo.com. to get encrypted debug text for A(or ANY)
record resolution of www.foo.com.

The prefix can be made of any characters even if it is not RFC
compliant. However, it is recommended to use only characters which
have no problem with passing through any LDNS. Note that, the prefix
also can be an empty(zero-length) string.

Change requires gslb reload.

For your information, you can decrypt the encrypted debug text by
using gslbdecode tool which is placed under /usr/local/cdnet/bin
during gslb install.

Example usage 1: Passing dig output through pipe
$ dig prefix-test-1.com txt | /usr/local/cdnet/bin/gslbdecode

Example usage 2: Passing encrypted text through command line argument
$ /usr/local/cdnet/bin/gslbdecode -i U2FsdGVkX18mqhhbnpp8L8oy
Uj2dgKIcUm6CpxK5CZQEDwBPlvCuo12wjMAa4pyiQviIt0Q5zJ+FTuCs
AqHlRKeKvcXbd82o3pZCDCw7/kMlYUOQzJqKdyb4I8HJhphfXajUa
ZzkSXa1v9vFLiPWkg==

See help message for more options.
$ ./gslbdecode -h
Options:
-i [input]    : txt record or entire dig output (default: stdin)
-k [password] : password for decryption         (default: cdngpgslb)
-c            : print compact output

* value range: valid domain name
'''
)

H_TXT_PASSWORD = _(
'''Password for debug TXT record encryption/decryption.

Change requires gslb reload.

* value range: any string not longer than 255 bytes
'''
)

H_GEOIP_FILENAME = _(
'''
Relative path to the GeoIP data file from the
cdnet data directory(/usr/local/cdnet/data).

Default: GeoIP.db
Hence, full path to the GeoIP data file is
/usr/local/cdnet/data/GeoIP.db by default.

Change requires gslb reload.

* value range: valid linux file path no longer than 4095 bytes
'''
)

H_STATIC_DOMAIN_ANSWER_TTL = _(
'''This value is used to populate the TTL field of the DNS response
packet for static domain query.

Change requires gslb reload.

* DB value range: integer 0 ~ 4294967295
'''
)

H_DEBUG_PORT = _(
'''The debug port that gslb listens on.

Change requires gslb restart.

* value range: 1 ~ 65535
'''
)

H_DEBUG_TIMEOUT = _(
'''Timeout of idle connections in seconds.

If gslb does not receive a request on an open connection
for this timeout, it will close the connection.

Change requires gslb reload.

* value range: 1.0 ~ 4294967295.0
'''
)

H_REQUEST_LOG_ROTATE_INTERVAL = _(
'''
The time interval (in seconds) after which the temporary
gslb-request log file is moved to a permanent file.

Change requires gslb restart.

* value range: 1 ~ 4294967295
'''
)

H_FAILURE_LOG_ROTATE_INTERVAL = _(
'''
The time interval (in seconds) after which the temporary
gslb-failure log file is moved to a permanent file.

Change requires gslb restart.

* value range: 1 ~ 4294967295
'''
)

H_LOG_FAILURE = _(
'''
If this flag is true, any failed queries, such as dropped
queries due to invalid forwarder reply, will be written down
to gslb-failure log.

Change requires gslb reload.
'''
)

H_LOG_FORWARD = _(
'''
If this flag is true, every queries that replied by forwarder
will be written down to gslb-request log.

Change requires gslb reload.
'''
)

H_PROBEAGENT = _(
'''IP address of probe agents that are assigned to monitor this pop.
Probe agents runs all probes on this pop and reports the values.

A pop can be monitored by any number of probe agents.
A probe agent can monitor any number of pops.

Probe agent compares its IP address to this to identify if it is
responsible for this pop.

Change requires gslb, probe and rms reload.
'''
)

H_PROBEAGENT_PRIMARY = _(
'''This flag indicates whether the probe agent is primary or backup.
There can be zero or one primary probe agent per pop.

Probe value reported from primary probe agent has higher priority
to be used by gslb. Probe values reported from backup probe agents
are used only if there is no recent report from primary probe agent.
In case there are different probe values reported from multiple
backup probe agents, most recent one is used.
'''
)

H_GSLB_INTERFACE = _('''List of the network interfaces and/or the IP addresses on which to
receive DNS queries. Note that GSLB listens on these in addition to
the host primary IP which is the one shown when you do ping `hostname`.

If nothing specified, GSLB listens on all IPs configured in the system
except 127.0.0.1.

<b>* Default: none (i.e. everything except 127.0.0.1)

Change requires GSLB restart.</b>

A network interface to listen on.
The name attribute is mandatory.
''')

H_GSLB_IPADDR = _('''List of the network interfaces and/or the IP addresses on which to
receive DNS queries. Note that GSLB listens on these in addition to
the host primary IP which is the one shown when you do ping `hostname`.

If nothing specified, GSLB listens on all IPs configured in the system
except 127.0.0.1.

<b>* Default: none (i.e. everything except 127.0.0.1)

Change requires GSLB restart.</b>

An IP address to listen on.
The addr attribute is mandatory.
''')

H_GSLB_MAX_RESOLUTION_T = _('''Maximum allowed name resolution time in msec. GSLB will do
its best to make name resolution time shorter than this.
For example, when performing CNAME latency measurement,
GSLB will not take longer than this time limit.

Note that name resolution time does not include network latency
in between GSLB and LDNS. So in LDNS perspective,
DNS response time = name resolution time + GSLB2LDNS_RTT

Value range: 0 ~ 5000
<b>* Default: 3000</b>
''')

H_GSLB_CNAME_LATENCY_USE = _('''Determine how GSLB should use CNAME latency.

NO_USE: Don't use it. Don't even perform the measurement.

TEST_ONLY: Perform the measurement regularly and log the result
           but don't use it.

IF_PING_FAILS: Perform the measurement only if ping fails. I.e,
               use CNAME latency instead of traceroute latency.

<b>Default: NO_USE </b>
''')

H_POP_ENABLE_CNAME_LATENCY = _('''Allow GSLB to run CNAME latency measurement
when this domain gets queried.

<b>* Default: TRUE</b>
''')

H_DNS_PORT = _('''Port on which to send/receive DNS queries.
This overrides the port number specified by &lt; dns_port &gt; .
''')

H_LOG_PROBE = _('''If the flag is true, all probe reports will be written down to log files.

Probe log files:
- gslb-probe log (probe value report)
- gslb-pop2pop log (pop-to-pop pktloss/rtt report)
- gslb-rtt log (pop-to-ldns rtt report)

<b>* Default: FALSE</b>

Change requires GSLB reload.
''')

H_PROBE_LOG_ROTATE_INTERVAL = _('''The time interval (in seconds) after which
a temporary probe log file is moved to a permanent file.

<b>* Default is 86400 (integer; 1 ~ 4294967295) seconds</b>

Change requires GSLB reload.
''')

H_LOG_PEDOMAIN_REQUEST = _('''If this flag is true, per-request log for all PE domains
will be written to the log files(gslb-request4pe_*).

<b>* Default: false</b>

Change requires GSLB reload.
''')
