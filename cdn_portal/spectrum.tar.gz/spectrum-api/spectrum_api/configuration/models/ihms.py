#
# Copyright (c) 2011 CDNetworks Co., Ltd.
# All rights reserved.
#
# $Id: ihms.py 11864 2014-01-02 02:15:00Z kookheon.kwon $
#

from socket import inet_ntoa
from struct import pack
from django.db import models
from spectrum_api.configuration.models import Model
import socket, struct

class IhmsPop(Model):
    pop_id = models.IntegerField(primary_key=True)
    pop_code = models.CharField(unique=True, max_length=50)
    legacy_pop_code = models.CharField(max_length=50)
    legacy_pop_name = models.CharField(max_length=192)
    panther_pop_code = models.CharField(max_length=50)
    entity_id = models.IntegerField()
    airport_id = models.IntegerField()
    ihms_status = models.IntegerField()
    obj_state = models.BooleanField()
    state = models.IntegerField()
    ihms_latest_updater_id = models.CharField(max_length=768)
    ihms_latest_update_date = models.DateTimeField()
    latest_update_date = models.DateTimeField()

    class Meta:
        app_label = 'configuration'
        db_table = u'ihms_pop'
        ordering = ['pop_code']

    def __unicode__(self):
        return u'%s' % (self.pop_code)

class IhmsSystem(Model):
    system_id = models.IntegerField(primary_key=True)
    system_name = models.CharField(max_length=192)
    pop = models.ForeignKey(IhmsPop)
    category_code = models.CharField(max_length=3)
    fbi = models.CharField(max_length=50)
    platform_type = models.CharField(max_length=50)
    svc_group = models.CharField(max_length=3)
    sm_memo = models.CharField(max_length=12000)
    entity_id = models.IntegerField()
    contact = models.CharField(max_length=192)
    team = models.CharField(max_length=192)
    ihms_status = models.IntegerField()
    obj_state = models.BooleanField()
    state = models.IntegerField()
    ihms_latest_updater_id = models.CharField(max_length=768)
    ihms_latest_update_date = models.DateTimeField()
    latest_update_date = models.DateTimeField()

    class Meta:
        app_label = 'configuration'
        db_table = u'ihms_system'
        ordering = ['pop', 'system_name']

    def __unicode__(self):
        return u'%s.%s' % (self.system_name, self.pop)

class IhmsHost(Model):
    host_id = models.IntegerField(primary_key=True)
    system = models.ForeignKey(IhmsSystem)
    host_name = models.CharField(max_length=192)
    legacy_host_name = models.CharField(max_length=80)
    ihms_status = models.IntegerField()
    obj_state = models.BooleanField()
    state = models.IntegerField()
    ihms_latest_updater_id = models.CharField(max_length=768)
    ihms_latest_update_date = models.DateTimeField()
    latest_update_date = models.DateTimeField()

    class Meta:
        app_label = 'configuration'
        db_table = u'ihms_host'
        ordering = ['system', 'host_name']

    def __unicode__(self):
        return u'%s-%s' % (self.host_name, self.system)

class IhmsVip(Model):
    host = models.ForeignKey(IhmsHost, related_name='hostset')
    vip_name = models.CharField(max_length=192, blank=True)
    ip_id = models.PositiveIntegerField(primary_key=True, db_column="ip_id")
    ihms_status = models.IntegerField()
    obj_state = models.BooleanField()
    state = models.IntegerField()
    primary = models.IntegerField()
    ihms_latest_updater_id = models.CharField('Last Updater', max_length=768)
    ihms_latest_update_date = models.DateTimeField("Last Update")
    latest_update_date = models.DateTimeField()

    class Meta:
        app_label = 'configuration'
        db_table = u'ihms_vip'

    def __unicode__(self):
        return '%s' % (inet_ntoa(pack('!L', self.ip_id)))

    def getfullvipname(self):
        return '%s-%s' % (self.vip_name, self.host)

    def getipaddress(self):
        result = ''
        try:
            if self.ip_id:
                result = socket.inet_ntoa(struct.pack('!L', int(self.ip_id)))  # struct.unpack('>L', socket.inet_aton(value))
        except:
            pass
        return result

class IhmsContinent(Model):
    continent_id = models.IntegerField(db_column='continent_id')  # autoField
    continent_code = models.CharField(primary_key=True, max_length=2)
    continent_name = models.CharField(max_length=128)
    ihms_latest_updater_id = models.CharField(max_length=256)
    ihms_latest_update_date = models.DateTimeField()
    obj_state = models.BooleanField()

    class Meta:
        app_label = 'configuration'
        db_table = 'ihms_continent'

    def __unicode__(self):
        return "%s" % (self.continent_name)

class IhmsCountry(Model):
    country_id = models.IntegerField(primary_key=True, db_column='country_id')  # autoField
    country_code = models.CharField(max_length=2)
    country_name = models.CharField(max_length=128)
    continent_code = models.ForeignKey(IhmsContinent, db_column='continent_code')
    country_code3 = models.CharField(null=True, max_length=3)
    country_code_int = models.IntegerField(null=True)
    country_alias = models.CharField(null=True, max_length=64)
    default_gmt = models.CharField(null=True, max_length=6)
    default_locale = models.CharField(null=True, max_length=2)
    default_language = models.CharField(null=True, max_length=2)
    display_enabled = models.IntegerField(default=0)
    ihms_latest_updater_id = models.CharField(max_length=256)
    ihms_latest_update_date = models.DateTimeField()
    latest_update_date = models.DateTimeField()
    obj_state = models.BooleanField()

    class Meta:
        app_label = 'configuration'
        db_table = 'ihms_country'

    def __unicode__(self):
        return "%s" % (self.country_name)

class IhmsState(Model):
    state_id = models.IntegerField(primary_key=True, db_column='state_id')
    state_code = models.CharField(null=True, max_length=3)
    state_name = models.CharField(max_length=128)
    country_code = models.ForeignKey(IhmsCountry, db_column='country_code')
    default_gmt = models.CharField(null=True, max_length=6)
    default_locale = models.CharField(null=True, max_length=2)
    default_language = models.CharField(null=True, max_length=2)
    display_enabled = models.IntegerField(default=0)
    ihms_latest_updater_id = models.CharField(max_length=256)
    ihms_latest_update_date = models.DateTimeField()
    latest_update_date = models.DateTimeField()
    obj_state = models.BooleanField()

    class Meta:
        app_label = 'configuration'
        db_table = 'ihms_state'

    def __unicode__(self):
        return "%s" % (self.state_name)

class IhmsCity(Model):
    city_id = models.IntegerField(primary_key=True, db_column='city_id')
    city_code = models.CharField(null=True, max_length=3)
    city_name = models.CharField(max_length=128)
    city_alias = models.CharField(max_length=128, null=True)
    state = models.ForeignKey(IhmsState, db_column='state_id')
    latitude = models.CharField(null=True, max_length=12)
    longitude = models.CharField(null=True, max_length=12)
    ihms_latest_updater_id = models.CharField(max_length=256)
    ihms_latest_update_date = models.DateTimeField()
    latest_update_date = models.DateTimeField()
    obj_state = models.BooleanField()

    class Meta:
        app_label = 'configuration'
        db_table = 'ihms_city'

    def __unicode__(self):
        return "%s" % (self.city_name)

class IhmsIdc(Model):
    idc_id = models.IntegerField(primary_key=True, db_column='idc_id')
    idc_code = models.CharField(null=True, max_length=2)
    idc_name = models.CharField(max_length=128)
    city = models.ForeignKey(IhmsCity, db_column='city_id')
    city_code = models.CharField(max_length=3)
    detail_addr = models.CharField(max_length=128, null=True)
    contact_name = models.CharField(max_length=64, null=True)
    contact_tel = models.CharField(max_length=16, null=True)
    contact_email = models.CharField(max_length=128, null=True)
    description = models.CharField(max_length=512, null=True)
    status = models.IntegerField(max_length=128)
    ihms_latest_updater_id = models.CharField(max_length=256)
    ihms_latest_update_date = models.DateTimeField()
    latest_update_date = models.DateTimeField()
    obj_state = models.BooleanField()

    class Meta:
        app_label = 'configuration'
        db_table = 'ihms_idc'

    def __unicode__(self):
        return "%s" % (self.idc_name)

class IhmsPopInfo(Model):
    pop = models.OneToOneField(IhmsPop, db_column="pop_id", primary_key=True, null=True)
    desc_link = models.CharField(db_column='desc_link',
                                null=True,
                                blank=True,
                                max_length=1024)
    idc = models.ForeignKey(IhmsIdc, db_column='idc_id')
    country = models.ForeignKey(IhmsCountry, db_column='country_id')
    priority = models.PositiveIntegerField(null=True, blank=True)

    class Meta:
        app_label = 'configuration'
        db_table = 'ihms_pop_info'
