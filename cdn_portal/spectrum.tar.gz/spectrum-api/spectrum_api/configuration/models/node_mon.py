# -*- coding: utf-8 -*-
"""
    Copyright (c) 2013 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Node Monitoring ( with RMS )
"""
from django.db import models
from spectrum_api.configuration.models.base import Pop, Host, System, Vip, BaseProbeConfig
from spectrum_api.dna.models.domain import Domain
from spectrum_api.shared_components.models import BaseModel

class DomainStatus(models.Model):
    domain_id = models.PositiveIntegerField(primary_key=True)
    domain_name = models.CharField()
    enable_gslb = models.SmallIntegerField()
    policy_count = models.PositiveIntegerField()
    total_vip_count = models.PositiveIntegerField()
    valid_count = models.PositiveIntegerField()
    domain_status = models.IntegerField()
    failure_count = models.PositiveIntegerField()
    active_count = models.PositiveIntegerField()

    class Meta:
        db_table = 'domain_status'
        managed = False

    def get_status_display(self):
        if self.domain_status == -1:
            return 'enabled (failure)'
        elif self.domain_status == -2:
            return 'disabled (failure)'
        elif self.domain_status == 1:
            return 'enabled (active)'
        elif self.domain_status == 0:
            return 'disabled (active)'
        elif self.domain_status == 3:
            return 'enabled (expired)'
        elif self.domain_status == 2:
            return 'disabled (expired)'
        elif self.domain_status == 5:
            return 'enabled (none)'
        elif self.domain_status == 4:
            return 'disabled (none)'
        elif self.domain_status == 7:
            return 'no probe and no rule'
        elif self.domain_status == 6:
            return 'no probe and no rule'
        else:
            return 'unknown'

class DomainVipStatus(BaseModel):
    domain = models.ForeignKey(Domain, db_column='domain_id', on_delete=models.DO_NOTHING)
    domain_name = models.CharField()
    vip = models.ForeignKey(Vip, db_column='vip_id', on_delete=models.DO_NOTHING)
    probe = models.ForeignKey(BaseProbeConfig, db_column='probe_id', on_delete=models.DO_NOTHING)
    ipid = models.PositiveIntegerField(db_column='vip', primary_key=True)
    enable_gslb = models.SmallIntegerField()
    probe_message_val = models.SmallIntegerField(db_column='val')
    update_time = models.DateTimeField(editable=False, db_column='timestamp', null=True)
    probe_status = models.SmallIntegerField()

    class Meta:
        db_table = 'domain_vip_probe_status'
        managed = False

    class SpectrumMeta:
        allow_delete = True

    def get_status(self):
        return self.probe_status

    def get_status_display(self):
        if self.probe_status == -1:
            return 'enabled (failure)'
        elif self.probe_status == -2:
            return 'disabled (failure)'
        elif self.probe_status == 1:
            return 'enabled (active)'
        elif self.probe_status == 0:
            return 'disabled (active)'
        elif self.probe_status == 3:
            return 'enabled (expired)'
        elif self.probe_status == 2:
            return 'disabled (expired)'
        elif self.probe_status == 5:
            return 'enabled (none)'
        elif self.probe_status == 4:
            return 'disabled (none)'
        elif self.probe_status == 7:
            return 'no probe'
        elif self.probe_status == 6:
            return 'no probe'
        else:
            return 'unknown'


    def __unicode__(self):
        return u'%s-%s:%s' % (self.domain_name, str(self.vip), str(self.probe_status))

class NodeRms(BaseModel):
    pop_id = models.ForeignKey(Pop, db_column='pop_id', on_delete=models.DO_NOTHING)
    pop_name = models.CharField()
    system_id = models.ForeignKey(System, db_column='system_id', null=True,
                                on_delete=models.DO_NOTHING)
    system_name = models.CharField()
    host_id = models.ForeignKey(Host, db_column='host_id', null=True,
                                on_delete=models.DO_NOTHING)
    host_name = models.CharField()
    vip_id = models.ForeignKey(Vip, db_column='vip_id', primary_key=True,
                                null=True, on_delete=models.DO_NOTHING)
    vip_name = models.CharField()
    vip_ip = models.CharField()
    vip_ip_int = models.PositiveIntegerField()
    val = models.IntegerField()

    class Meta:
        db_table = 'node_rms'
        managed = False

    class SpectrumMeta:
        allow_delete = True

    def __unicode__(self):
        if self.vip_name:
            return u'%s.%s-%s.%s' % (self.vip_name, self.host_name, self.system_name, self.pop_name)
        elif self.host_name:
            return u'%s-%s.%s' % (self.host_name, self.system_name, self.pop_name)
        elif self.system_name:
            return u'%s.%s' % (self.system_name, self.pop_name)
        else:
            return u'%s' % (self.pop_name)
