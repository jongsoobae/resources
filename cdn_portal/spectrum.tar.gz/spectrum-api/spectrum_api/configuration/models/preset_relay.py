#
# Copyright (c) 2011 CDNetworks Co., Ltd.
# All rights reserved.
#
# $Id: hyejun.yim $
#

from django.core.validators import MaxLengthValidator
from django.db import models

from spectrum_api.configuration.models import Model
from spectrum_api.configuration.models.base import Pop

DSP_DEPS_LIMIT = 10
PRESET_RELAY_LEVEL = (
            (1, 'Relay-1'),
            (2, 'Relay-2'),
            (3, 'Relay-3'),
)

"""
    configuration - Pre-set Relay
"""

class MproxyPreset(Model):
    """
    configuration - mproxy preset
    """
    preset_id = models.AutoField(primary_key=True, db_column='preset_id')
    preset_name = models.CharField(max_length=255, unique=True, validators=[MaxLengthValidator(255)])
    date_created = models.DateTimeField('Date Created', auto_now_add=True)
    date_modified = models.DateTimeField('Date Modified', auto_now=True)
    obj_state = models.PositiveSmallIntegerField(default=1)
 
    class Meta:
        app_label = 'dna'
        db_table = 'mproxy_preset'
        ordering = ['preset_id']
 
    class SpectrumMeta:
        allow_delete = True

    def __unicode__(self):
        return self.preset_name

    def get_related_objects(self):
        from spectrum_api.dna.models import domain
        return ((domain.Domain, domain.Domain.objects.filter(mproxy_preset=self)[:DSP_DEPS_LIMIT]),)

    def is_deletable(self):
        from spectrum_api.dna.models import domain
        gslb_domains = domain.Domain.objects.filter(mproxy_preset=self)
        if gslb_domains.exists():
            return False
        return True

    def delete_related(self, request):
        try:
            mproxy_relays = MproxyRelays.objects.filter(preset=self)
            for mproxy_relay in mproxy_relays:
                mproxy_relay.delete(request=request)
        except Exception, e:
            raise e

    def delete(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        self.delete_related(request=request)
        super(MproxyPreset, self).delete()

class MproxyRelays(Model):
    """
    configuration - mproxy relay
    """
    relay_id = models.AutoField(primary_key=True, db_column='relay_id')
    relay_level = models.PositiveSmallIntegerField(default=1, choices=PRESET_RELAY_LEVEL)
    preset = models.ForeignKey(MproxyPreset, db_column="preset_id")
    pop = models.ForeignKey(Pop, db_column="pop_id")
    obj_state = models.PositiveSmallIntegerField(default=1)

    class Meta:
        app_label = 'dna'
        db_table = 'mproxy_relays'
        ordering = ['relay_id', ]
        unique_together = ('relay_level', 'preset', 'pop')

    class SpectrumMeta:
        allow_delete = True

class MproxyPresetRelay(Model):
    """
    configuration - mproxy preset relay
    """
    preset_id = models.PositiveIntegerField(primary_key=True, db_column='preset_id')
    preset_name = models.CharField(max_length=255)
    relay_1 = models.CharField()
    relay_2 = models.CharField()
    relay_3 = models.CharField()

    class Meta:
        app_label = 'dna'
        db_table = 'mproxy_preset_relay'
        ordering = ['preset_id', ]
        managed = False

    def __unicode__(self):
        return self.preset_name

    class SpectrumMeta:
        read_only = True

