#
# Copyright (c) 2011 CDNetworks Co., Ltd.
# All rights reserved.
#
# $Id: probeagent.py 11864 2014-01-02 02:15:00Z kookheon.kwon $
#

from django.core.validators import RegexValidator, MaxValueValidator, \
     MinValueValidator
from django.db import models
from django.db.models import Q
from django.utils.translation import ugettext as _
from spectrum_api.configuration.models import Model
from spectrum_api.configuration.models.base import VipSearch
from django.core.exceptions import ValidationError

path_rex = '^(/\w+)+$'

class ProbeAgent(Model):
    """ This is for probe_agent.xml
    """

    probeagent_id = models.AutoField(primary_key=True)
    vip = models.ForeignKey(VipSearch, null=True, unique=True, on_delete=models.DO_NOTHING)
    rtt_delay = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''RTT probe delay in milliseconds.

This is a time to wait before starting a new RTT probe
when there are one or more outstanding RTT probes and
no active probe is responding. This is the wait time
for the internal epoll loop.

Value Range: (1 ~ 1000) msec.

Change requires PROBE reload.''')
    )
    rtt_timeout = models.FloatField(
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)],
        blank=True,
        null=True,
        help_text=_(
'''Timeout of outstanding RTT requests in seconds.

If an RTT probing request, i.e. a ping, to a client(LDNS) is not
responsed in this amount of time, the Probe tries alternative
probing methods or gives up to measure the RTT to the client.

Value Range: (decimal; 1 ~ 4294967295) seconds.

Change requires PROBE reload.''')
    )
    rtt_cache_ttl = models.PositiveIntegerField(
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        blank=True,
        null=True,
        help_text=_(
'''TTL of each cached RTT in seconds.

The Probe caches RTT values to reduce RTT probing traffic.
The cached RTT values would be expired after this amount of
time from the time it was measured.

Value Range: (integer; 0 ~ 4294967295) seconds.

Change requires PROBE reload.''')
    )
    rtt_max_cache_records = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)],
        blank=True,
        null=True,
        help_text=_(
'''Maximum number of RTT cache records.

Default is 16777216 (integer; 1 ~ 4294967295).

Change requires PROBE restart''')
    )
    rtt_trace_udp_port = models.PositiveIntegerField(
        validators=[MaxValueValidator(65535)],
        blank=True,
        null=True,
        help_text=_(
'''Destination port number for UDP traceroute.
* value range: 1 ~ 65535''')
    )
    rtt_trace_max_hops = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(128)],
        blank=True,
        null=True,
        help_text=_(
'''* value range: 1 ~ 128''')
    )
    rtt_trace_min_hops = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(128)],
        blank=True,
        null=True,
        help_text=_(
'''Can't exceed the max_hops
*value range: 1 ~ <max_hops>''')
    )
    rtt_trace_max_linear_hops = models.PositiveIntegerField(
        validators=[MinValueValidator(0), MaxValueValidator(255)],
        blank=True,
        null=True,
        help_text=_(
'''* value range: 0 ~ 255''')
    )
    rtt_echo_pktlen = models.PositiveIntegerField(
        validators=[MinValueValidator(8), MaxValueValidator(65515)],
        blank=True,
        null=True,
        help_text=_(
'''ICMP ECHO(ping) packet length.
This includes ICMP header length(8 bytes).

Value Range: (8 ~ 65515) bytes.

Change requires PROBE reload.''')
    )
    rtt_max_ping_rounds = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)],
        blank=True,
        null=True,
        help_text=_(
'''We might want to ping multiple times. Here we specify how many
rounds we want to ping. The best value is used.

Value Range: (1 ~ 4294967295).

Change requires PROBE reload.''')
    )
    rtt_dns_udp_port = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(65535)],
        blank=True,
        null=True,
        help_text=_(
'''When ping to a LDNS fails, we try to do a reverse
DNS lookup for the xxxx.in-addr.arpa domain at the LDNS.
Which port should we send a reverse DNS lookup?

Change requires PROBE reload.

* Value Range: 1 ~ 65535
''')
    )
    rtt_dns_tcp_port = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(65535)],
        blank=True,
        null=True,
        help_text=_(
'''When UDP DNS lookup fails, we try a TCP connect to see if we
can get a response (either success or RST) to measure RTT.
Which port should we send a TCP connect request?

Change requires PROBE reload.

* Value Range: 1 ~ 65535
''')
    )
    rtt_max_tcp_probes = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)],
        blank=True,
        null=True,
        help_text=_(
'''Maximum number of outstanding TCP probes for RTT measurement.

Default is 256 (1 ~ 4294967295) probes.

Change requires PROBE reload.''')
    )
    rtt_max_tcp_pending = models.PositiveIntegerField(
        validators=[MinValueValidator(0), MaxValueValidator(65536)],
        blank=True,
        null=True,
        help_text=_(
'''When the number of outstanding TCP probes reaches max_tcp_probes,
we push further TCP probes into a pending queue for a chance to send
them out.

This, max_tcp_pending, sets the pending queue size, that is the
maximum number of pending TCP probes. If the number of outstanding
TCP probes reaches max_tcp_probes and the pending queue capacity
is full, we just skip the TCP method in further RTT measurements.

Value Range: (0 ~ 65536).

Note that, the total number of concurrent RTT measuring instances,
including outstanding or pending probes of any methods, is limited
up to 65536.

Change requires PROBE reload.''')
    )
    pktloss_port = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(65536)],
        blank=True,
        null=True,
        help_text=_(
'''The port for sending packets to Packet Loss Servers.

Change requires PROBE restart.

* value range: 1 ~ 65535''')
    )
    pktloss_interval = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)],
        blank=True,
        null=True,
        help_text=_(
'''Interval in seconds at which to send packets to one of the
Packet Loss Servers. The target is picked up round-robinly.

Value Range: (1 ~ 4294967295) seconds.

Change requires PROBE reload.''')
    )
    pktloss_timeout = models.FloatField(
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)],
        blank=True,
        null=True,
        help_text=_(
'''Timeout of outstanding packets in seconds.

Value Range: (decimal; 1 ~ 4294967295) seconds.

Change requires PROBE reload.''')
    )
    pktloss_delay = models.PositiveIntegerField(
        validators=[MinValueValidator(0), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''Packet sending delay in milliseconds.
This is a maximum time to wait before sending next packet.
*Note: unlike for others, we can use 0 for pktloss delay.

Value Range: (0 ~ 1000) msec.

Change requires PROBE reload.''')
    )
    pktloss_packet_length = models.PositiveIntegerField(
        validators=[MinValueValidator(8), MaxValueValidator(65507)],
        blank=True,
        null=True,
        help_text=_(
'''Length of the packet to be transmitted.
This excludes UDP header(8 bytes) and IP header(20 bytes) length.

Value Range: (8 ~ 65507) bytes.

Change requires PROBE reload.''')
    )
    pktloss_packet_count = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''Number of packets to be transmitted at a time.

Value Range: (1 ~ 1000).

Change requires PROBE reload.''')
    )
    icmp_delay = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''ICMP probe delay in milliseconds.

This is a time to wait before starting a new ICMP probe
when there are one or more outstanding ICMP probes and
no active probe is responding. This is the wait time
for the internal epoll loop.

Value Range: (1 ~ 1000) msec.

Change requires PROBE reload.''')
    )
    icmp_max_probes = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''Maximum number of outstanding ICMP probes.

Value Range: (1 ~ 1000) probes.

Change requires PROBE reload.''')
    )
    icmp_echo_pktlen = models.PositiveIntegerField(
        validators=[MinValueValidator(8), MaxValueValidator(65515)],
        blank=True,
        null=True,
        help_text=_(
'''ICMP ECHO(ping) packet length.
This includes ICMP header length(8 bytes).

Value Range: (8 ~ 65515) bytes.

Change requires PROBE reload.''')
    )
    snmp_delay = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''SNMP probe delay in milliseconds.

This is a time to wait before starting a new SNMP probe
when there are one or more outstanding SNMP probes and
no active probe is responding. This is the wait time
for the internal select loop.

Value Range: (1 ~ 1000) msec.

Change requires PROBE reload.''')
    )
    snmp_max_probes = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''Maximum number of outstanding SNMP probes.

Value Range: (1 ~ 1000) probes.

Change requires PROBE reload.''')
    )
    tcp_delay = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''TCP probe delay in milliseconds.

This is a time to wait before starting a new TCP probe
when there are one or more outstanding TCP probes and
no active probe is responding. This is the wait time
for the internal epoll loop.

Value Range: (1 ~ 1000) msec.

Change requires PROBE reload.''')
    )
    tcp_max_probes = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''Maximum number of outstanding TCP probes.

Value Range: (1 ~ 1000) probes.

Change requires PROBE reload.''')
    )
    ssl_delay = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''SSL probe delay in milliseconds.

This is a time to wait before starting a new SSL probe
when there are one or more outstanding SSL probes and
no active probe is responding. This is the wait time
for the internal epoll loop.

Value Range: (1 ~ 1000) msec.

Setting it to too small value, less than 5, can lead to
inaccuracy in probing response time of the services.

Change requires PROBE reload.''')
    )
    ssl_max_probes = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''Maximum number of outstanding SSL probes.

Value Range: (1 ~ 1000) probes.

Change requires PROBE reload.''')
    )
    ssl_ca_path = models.CharField(
        max_length=255,
        validators=[RegexValidator(path_rex)],
        blank=True,
        null=True,
        help_text=_(
'''Path to the CA file.

Change requires PROBE restart.''')
    )
    udp_delay = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''UDP probe delay in milliseconds.

This is a time to wait before starting a new UDP probe
when there are one or more outstanding UDP probes and
no active probe is responding. This is the wait time
for the internal epoll loop.

Value Range: (1 ~ 1000) msec.

Change requires PROBE reload.''')
    )
    udp_max_probes = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''Maximum number of outstanding UDP probes.

Value Range:(1 ~ 1000) probes.

Change requires PROBE reload.''')
    )
    ftp_delay = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''FTP probe delay in milliseconds.

This is a time to wait before starting a new FTP probe
when there are one or more outstanding FTP probes and
no active probe is responding. This is the wait time
for the internal epoll loop.

Value Range: (1 ~ 1000) msec.

Change requires PROBE reload.''')
    )
    ftp_max_probes = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''Maximum number of outstanding FTP probes.

Value Range: (1 ~ 1000) probes.

Change requires PROBE reload.''')
    )
    rtmp_delay = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''RTMP probe delay in milliseconds.

This is a time to wait before starting a new RTMP probe
when there are one or more outstanding RTMP probes and
no active probe is responding. This is the wait time
for the internal epoll loop.

Value Range: (1 ~ 1000) msec.

Change requires PROBE reload.''')
    )
    rtmp_max_probes = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''Maximum number of outstanding RTMP probes.

Value Range: (1 ~ 1000) probes.

Change requires PROBE reload.''')
    )
    dns_delay = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''DNS probe delay in milliseconds.

This is a time to wait before starting a new DNS probe
when there are one or more outstanding DNS probes and
no active probe is responding. This is the wait time
for the internal epoll loop.

Value Range: (1 ~ 1000) msec.

Change requires PROBE reload.''')
    )
    dns_max_probes = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(1000)],
        blank=True,
        null=True,
        help_text=_(
'''Maximum number of outstanding DNS probes.

Value Range: (1 ~ 1000) probes.

Change requires PROBE reload.''')
    )
    debug_port = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(65535)],
        blank=True,
        null=True,
        help_text=_(
'''The port on which the debug server will be available.

Value Range: 1 ~ 65535

Change requires PROBE restart.''')
    )
    debug_timeout = models.FloatField(
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)],
        blank=True,
        null=True,
        help_text=_(
'''Timeout of idle connections  in seconds.

Value Range: 1.0 ~ 4294967295.0 seconds.

Change requires PROBE reload.''')
    )
    log_rotate_interval = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)],
        blank=True,
        null=True,
        help_text=_(
'''The time interval (in seconds) after which
the temporary log file is moved to a permanent file.

Value Range: (integer; 1 ~ 4294967295) seconds.

Change requires PROBE restart.''')
    )
    report_log_rotate_interval = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)],
        blank=True,
        null=True,
        help_text=_(
'''The time interval (in seconds) after which
a temporary probe-report log file is moved to a permanent file.

Default is 300 (integer; 1 ~ 4294967295) seconds.

Change requires PROBE restart.''')
    )
    rtt_log_rotate_interval = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)],
        blank=True,
        null=True,
        help_text=_(
'''The time interval (in seconds) after which
a temporary probe-rtt log file is moved to a permanent file.

Default is 86400 (integer; 1 ~ 4294967295) seconds.

Change requires PROBE restart.''')
    )
    pop2pop_log_rotate_interval = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)],
        blank=True,
        null=True,
        help_text=_(
'''The time interval (in seconds) after which
a temporary probe-pop2pop log file is moved to a permanent file.

Default is 300 (integer; 1 ~ 4294967295) seconds.

Change requires PROBE restart. ''')
    )

    reporting_protocol = models.SmallIntegerField(
        validators=[MinValueValidator(0), MaxValueValidator(1)],
        null=True,
        help_text=_(
'''This option is only applicable to probe_report.<br/>(In case of rtt/pkloss_report : is not the case

Default is UDP .

Change requires PROBE restart. '''))

    date_created = models.DateTimeField(
        'Date Created',
        auto_now_add=True
    )
    date_modified = models.DateTimeField(
        'Date Modified',
        auto_now=True
    )

    def __unicode__(self):
        return '%s' % (self.vip)

    def clean(self):
        probeAgent = ProbeAgent.objects.exclude(pk=self.pk).filter(vip=self.vip)
        if probeAgent.exists():
            raise ValidationError({"vip": [_("Probe agent with this Vip already exists.")]})

    class Meta:
        app_label = 'configuration'
        db_table = 'probeagent_config'

    class SpectrumMeta:
        allow_delete = True

    def is_deletable(self):
        try:
            from spectrum_api.configuration.models.base import PopProbeAgentConfig, Pop, PopPacketlossProbeAgentConfig

            pops = PopProbeAgentConfig.objects.filter(probeagent=self)
            if pops.exists():
                for pop in pops:
                    if PopProbeAgentConfig.objects.filter(pop=pop.pop).count() <= 1:
                        return False

            pops = PopPacketlossProbeAgentConfig.objects.filter(probeagent=self)
            if pops.exists():
                for pop in pops:
                    if PopPacketlossProbeAgentConfig.objects.filter(pop=pop.pop).count() <= 1:
                        return False

            if Pop.objects.filter(rttserver=self).exists():
                return False

            vipsearch = VipSearch.objects.get(vip=self.vip.pk).pop_name
            if vipsearch:
                base_pops = Pop.objects.filter(Q(pop_name=vipsearch) | Q(ihms_pop__pop_code=vipsearch)) \
                                       .filter(auto_probe=1)
                if base_pops.exists():
                    vips, is_valid = self.check_auto_probe_condition(base_pops[0])
                    if not is_valid:
                        return False

        except Exception, e:
            raise e

        return True

    def check_auto_probe_condition(self, pop):
        from spectrum_api.configuration.models.base import System, Host, Vip
        systems = System.objects.filter(pop=pop) \
                                .filter(Q(enable_gslb=1) | Q(enable_gslb__isnull=True)).values('system')
        hosts = Host.objects.filter(system__in=systems, role__role_name='PROBE') \
                            .filter(Q(enable_gslb=1) | Q(enable_gslb__isnull=True)).values('host')

        vips = Vip.objects.filter(host__in=hosts, probeconfigs__name='probe_health') \
                          .filter(Q(enable_gslb=1) | Q(enable_gslb__isnull=True))
        probe_vips = VipSearch.objects.filter(vip__in=vips.values('vip'))

        vips.query.group_by = ['host_id']
        vips_id = [obj.vip for obj in vips]
        probeagents = ProbeAgent.objects.filter(vip__in=vips_id)

        if probeagents.count() > 2:
            return probe_vips, True

        return probe_vips, False

    def delete_related(self, request):
        try:
            from spectrum_api.configuration.models.base import PopProbeAgentConfig, PopPacketlossProbeAgentConfig
            #
            pop_probeagents = PopProbeAgentConfig.objects.filter(probeagent=self)
            pop_packetloss_probeagents = PopPacketlossProbeAgentConfig.objects.filter(probeagent=self)
            # pop_probeagents.delete()
            for pop_probeagent in pop_probeagents:
                pop_probeagent.delete(request=request)

            for pop_packetloss_probeagent in pop_packetloss_probeagents:
                pop_packetloss_probeagent.delete(request=request)

        except Exception, e:
            raise e

    def get_related_objects(self):
        DSP_DEPS_LIMIT = 10

        from spectrum_api.configuration.models.base import PopProbeAgentConfig, Pop, PopPacketlossProbeAgentConfig

        return ((PopProbeAgentConfig, PopProbeAgentConfig.objects.filter(probeagent=self)[:DSP_DEPS_LIMIT]),
                (Pop, Pop.objects.filter(rttserver=self)[:DSP_DEPS_LIMIT]),
                (PopPacketlossProbeAgentConfig, PopPacketlossProbeAgentConfig.objects.filter(probeagent=self)[:DSP_DEPS_LIMIT]),)
