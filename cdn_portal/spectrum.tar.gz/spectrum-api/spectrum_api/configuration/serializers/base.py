# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Edge Serializer
"""
from rest_framework import serializers
from django.db.models import Q
from spectrum_api.configuration.models.base import Pop, Host, System, Vip, Edge, HostRole, Role, \
                                            BaseVipEdge, VipProbeConfigs, EdgeAll, \
                                            PopUplinkProbeConfigs, PopProbeAgentConfig, PopInfo, \
                                            PopGroup, RoleConfigSetting, PROBE_TYPES
from spectrum_api.shared_components.models.customer import CustomerDisplay
from spectrum_api.configuration.models.clb import CustomerContractPop
from spectrum_api.configuration.models.ihms import IhmsCountry, IhmsIdc, IhmsPopInfo, IhmsPop
from spectrum_api.dna.models.domain import DomainEdge, Domain
from spectrum_api.configuration.models.config import ConfigDistAction
from django.utils.translation import ugettext as _
from spectrum_api.configuration.models.gslb import GSLB

from django.core.validators import MaxValueValidator, MinValueValidator, \
        RegexValidator, MinLengthValidator, MaxLengthValidator
from spectrum_api.shared_components.utils.role_define import MPROXY_ROLE
from spectrum_api.shared_components.utils.regex import REGEX_POP_GROUP_NAME, \
    REGEX_POP_NAME, customersystem_rex, customerhost_rex, edge_name_rex, \
    customer_vip_rex, probe_name_rex, stepfunc_rex, oid_rex, default_name_rex, \
    path_rex, rtmp_app_rex, rtmp_flashver_rex, rtmp_stream_name_rex, \
    gslb_domain_rex, regex_pop_name, regex_system_name, regex_host_name, regex_vip_name, regex_ipv4

class ProbeAgentField(serializers.RelatedField):
    def to_native(self, value):
        return {"probeagent": "%s" % value.pk,
                "probeagentvip": "%s" % value.vip,
                "hostname": "%s" % value.vip.full_host_name,
                "NIC": "%s" % value.vip.ip,
                 "host_id":"%s" % value.vip.host_id}

class HostRoleField(serializers.RelatedField):
    def to_native(self, value):
        return {"role_id": value.role.role_id,
                "role_name": value.role.role_name }


class DomainEdgeSerializer(serializers.ModelSerializer):
    domain_name = serializers.RelatedField(read_only=True, source="domain")
    class Meta:
        model = DomainEdge
        fields = ('domain_edge_id',
                'domain',
                "domain_name",)

    def get_identity(self, data):
        try:
            return data.get('domain_edge_id', None)
        except AttributeError:
            return None

class EdgeVipSerializer(serializers.ModelSerializer):
    vip_name = serializers.SerializerMethodField("get_vip_fullname")
    ip = serializers.CharField(read_only=True, source="vip")
    class Meta:
        model = BaseVipEdge
        fields = ('id', "vip", "vip_name", "ip",)
    def get_vip_fullname(self, obj):
        try:
            return obj.vip.get_fullvipname()
        except:
            # logging
            return obj.vip.vip_name

class EdgeSimpleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Edge
        fields = ('edge_id', 'name',)
        depth = 1

    def get_identity(self, data):
        try:
            return data.get('edge_id', None)
        except AttributeError:
            return None

class EdgeSerializer(serializers.ModelSerializer):
    basevipedge_set = EdgeVipSerializer(many=True, required=False, allow_add_remove=True)
    domainedge_set = DomainEdgeSerializer(many=True, required=False, read_only=True)  # Because Empty edge can't assign to domain
    pops = serializers.SerializerMethodField("get_pops")
    # is_deletable = serializers.SerializerMethodField("get_is_deletable")
    class Meta:
        model = Edge
        fields = ('edge_id', 'name', 'description', 'date_created', 'date_modified', 'enable_gslb', 'basevipedge_set', 'domainedge_set', "pops",)
        depth = 1

    def get_identity(self, data):
        try:
            return data.get('edge_id', None)
        except AttributeError:
            return None

    def get_pops(self, obj):
        try:
            vips = obj.basevipedge_set.all()
            pop_ids = [pop_id["vip__host__system__pop"]
                                for pop_id in vips.values("vip__host__system__pop")\
                                                .distinct()]
            pops = [{"pop": pop.pk, "pop_name": pop}
                            for pop in Pop.objects.filter(pop__in=pop_ids)]
            return pops
        except:
            # logging
            return []

    def get_is_deletable(self, obj):
        return obj.is_deletable()

class EdgeAllSerializer(serializers.ModelSerializer):
    class Meta:
        model = EdgeAll
        fields = ('edge_id',
            'name',
            'description',
            'date_created',
            'date_modified',
            'enable_gslb',
            'pop_count',
            'vip_count',
            'domain_count',)

class EdgeVipDetailSerializer(serializers.ModelSerializer):
    roles = serializers.SerializerMethodField('get_roles')
    ip = serializers.CharField(read_only=True, source="vip")
    host_name = serializers.SerializerMethodField("get_host_fullname")
    vip_name = serializers.SerializerMethodField("get_vip_fullname")

    class Meta:
        model = BaseVipEdge
        fields = ('id', "ip" , "vip", "host_name", "vip_name", "roles",)

    def get_roles(self, obj):
        try:
            roles = [role for role in Role.objects.filter(hostrole__host=obj.vip.host)]
            return roles
        except :
            # looging
            return []

    def get_host_fullname(self, obj):
        try:
            return obj.vip.host.get_fullhostname()
        except:
            # logging
            return obj.vip.host.host_name

    def get_vip_fullname(self, obj):
        try:
            return obj.vip.get_fullvipname()
        except:
            # logging
            return obj.vip.vip_name

class EdgeDetailSerializer(serializers.ModelSerializer):
    basevipedge_set = EdgeVipDetailSerializer(many=True, required=False, allow_add_remove=True)
    domainedge_set = DomainEdgeSerializer(many=True, required=False, read_only=True)  # Because Empty edge can't assign to domain
    pops = serializers.SerializerMethodField("get_pops")
    is_deletable = serializers.SerializerMethodField("get_is_deletable")
    class Meta:
        model = Edge
        fields = ('edge_id', 'name', 'description', 'date_created', 'date_modified', 'enable_gslb', "pops", 'basevipedge_set', 'domainedge_set', "is_deletable",)
        depth = 1

    def get_identity(self, data):
        try:
            return data.get('edge_id', None)
        except AttributeError:
            return None

    def get_pops(self, obj):
        try:
            pops = [{"pop": pop.pk, "pop_name": pop}
                            for pop in Pop.objects.filter(system__host__vip_host_set__edge=obj).distinct()]
            return pops
        except:
            # logging
            return []
    def get_is_deletable(self, obj):
        return obj.is_deletable()

class LiteSystemSerializer(serializers.ModelSerializer):
    system_name_info = serializers.SerializerMethodField('get_name')
    class Meta:
        model = System
        fields = ('system', 'system_name', 'pop', 'description', 'enable_gslb', 'system_name_info')
        depth = 0

    def get_identity(self, data):
        try:
            return data.get('system', None)
        except AttributeError:
            return None

    def get_name(self, data):
        if data.ihms_system:
            return data.ihms_system.system_name
        return data.system_name

class SystemSerializer(serializers.ModelSerializer):
    fullsystemname = serializers.Field('get_fullsystemname')
    system_name_info = serializers.SerializerMethodField('get_name')
    is_deletable = serializers.Field('is_deletable')
    pop_name = serializers.SerializerMethodField('get_pop_name')
    system_name = serializers.CharField(required=False)

    class Meta:
        model = System
        fields = ('system', 'system_name_info', 'fullsystemname', 'system_name', 'pop', 'pop_name', 'description', 'is_deletable', 'enable_gslb', 'ihms_system')
        depth = 0

    def validate_enable_gslb(self, attrs, source):
        new_enable_gslb = attrs.get(source, '1')

        if self.data.get('pop') \
          and (new_enable_gslb == 0 or new_enable_gslb == '0'):
            pop = Pop.objects.get(pk=self.data.get('pop'))
            system = System.objects.get(pk=self.data.get('system'))
            if pop and system:
                from spectrum_api.configuration.models.probeagent import ProbeAgent
                hosts = Host.objects.filter(system=system).values('host')
                vips = Vip.objects.filter(host__in=hosts).values('vip')
                probeagents = ProbeAgent.objects.filter(vip__in=vips)
                if pop.auto_probe==1 and probeagents.count() > 0 \
                  and not pop.check_auto_probeagents(self.data.get('system'), 'system'):
                    enable_gslb = str(self.data.get('enable_gslb'))

                    if enable_gslb != new_enable_gslb:
                        raise serializers.ValidationError(_("Cannot be changed.Please check the auto probe option."))
        return attrs

    def validate_system_name(self, attrs, source):
        ihms_system = attrs.get('ihms_system')
        value = attrs.get(source)
        if not ihms_system:
            try:
                if regex_system_name.match(value) is None:
                    raise serializers.ValidationError(_("system name is invalied"))
            except TypeError as e:
                raise serializers.ValidationError(_("system name is required"))
            except Exception, e:
                raise e
        return attrs

    def get_identity(self, data):
        try:
            return data.get('system', None)
        except AttributeError:
            return None

    def get_name(self, data):
        if data.ihms_system:
            return data.ihms_system.system_name
        return data.system_name

    def get_pop_name(self, data):
        if data.pop.ihms_pop:
            return data.pop.ihms_pop.pop_code
        return data.pop.pop_name


class PopGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = PopGroup
        fields = ('popgroup_id', 'name', 'description')
        depth = 0

    def get_identity(self, data):
        try:
            return data.get('popgroup_id', None)
        except AttributeError:
            return None

class RoleConfigSerializer(serializers.ModelSerializer):
    config_phase_name = serializers.RelatedField(source='config_phase', read_only=True)
    class Meta:
        model = RoleConfigSetting
        fields = ('roleconfig_id', 'config_phase', 'config_phase_name')
        depth = 0

    def get_identity(self, data):
        try:
            return data.get('roleconfig_id', None)
        except AttributeError:
            return None


class RoleSerializer(serializers.ModelSerializer):
    roleconfig = RoleConfigSerializer(many=True, required=False, source="roleconfigsetting_set", allow_add_remove=True)
    role_name = serializers.CharField(validators=[RegexValidator(default_name_rex)], required=True)

    class Meta:
        model = Role
        fields = ('role_id', 'role_name', 'roleconfig')
        depth = 0

    def get_identity(self, data):
        try:
            return data.get('role_id', None)
        except AttributeError:
            return None


class PopLocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = IhmsCountry
        fields = ('country_id', 'country_code', 'country_name')
        depth = 0

    def get_identity(self, data):
        try:
            return data.get('country_id', None)
        except AttributeError:
            return None

class IhmsIdcSerializer(serializers.ModelSerializer):
    class Meta:
        model = IhmsIdc
        fields = ('idc_id', 'idc_code', 'idc_name')
        depth = 0

    def get_identity(self, data):
        try:
            return data.get('idc_id', None)
        except AttributeError:
            return None

class HostRoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = HostRole
        fields = ('hostrole_id', 'role',)

    def get_identity(self, data):
        try:
            return data.get('hostrole_id', None)
        except AttributeError:
            return None

    def validate(self, attrs):
        role = attrs.get("role")
        if role.role_name == MPROXY_ROLE:
            try:
                if self.object:
                    host = self.object.host
                else:
                    host_id = self.context['request'].DATA.get('host', None)
                    if host_id is not None:
                        host = Host.objects.get(host=host_id)
            except Exception as e:
                raise serializers.ValidationError({"role": [_('you have to set the mproxy shield,\
                                                             one of vip that related vip list(-1)')]})

            try:
                vips = Vip.objects.filter(host=host, mproxy_shield=True)
                if vips.count() == 0:
                    raise serializers.ValidationError({'role':\
                        [_('you have to set the mproxy shield, \
                            one of vip that related vip list')]})
                if vips.count() > 1:
                    raise serializers.ValidationError({'role':\
                        [_('mproxy shield is setted  %s vips' %
                        vips)]})
            except serializers.ValidationError as e:
                raise e
            except Exception as e:
                raise serializers.ValidationError({"role":[_("Occurred exception when validate the assigned MPROXY role.")]})

        return attrs

class PopHostSerializer(serializers.ModelSerializer):
    fullhostname = serializers.Field('get_fullhostname')
    is_deletable = serializers.Field('is_deletable')
    pop = serializers.Field('system.pop.pk')
    pop_name = serializers.SerializerMethodField('get_pop_name')
    role = HostRoleSerializer(many=True, required=False, source="hostrole_set", allow_add_remove=True)
    role_info = HostRoleField(many=True, read_only=True, source="hostrole_set")
    system_name = serializers.SerializerMethodField('get_system_name')
    host_name = serializers.CharField(required=False)

    class Meta:
        model = Host
        fields = ('host', 'pop', 'pop_name', 'system', 'system_name', 'host_name', \
                  'fullhostname', 'is_deletable', \
                  'role', 'role_info', 'description', \
                  'enable_gslb', 'ihms_host')

    def validate_role(self, attrs, source):
        roles = [str(obj.role.role_name) for obj in attrs.get(source, [])]
        if self.data.get('pop') and not 'PROBE' in roles:
            pop = Pop.objects.get(pk=self.data.get('pop'))
            host = Host.objects.get(pk=self.data.get('host'))
            if pop and host:
                from spectrum_api.configuration.models.probeagent import ProbeAgent
                vips = Vip.objects.filter(host=host).values('vip')
                probeagents = ProbeAgent.objects.filter(vip__in=vips)
                if pop.auto_probe==1 and probeagents.count() > 0 \
                  and not pop.check_auto_probeagents(self.data.get('host'), 'host'):
                    raise serializers.ValidationError(_("Cannot be changed.Please check the auto probe option."))

        return attrs

    def validate_enable_gslb(self, attrs, source):
        new_enable_gslb = attrs.get(source, '1')
        if self.data.get('pop') \
          and (new_enable_gslb == 0 or new_enable_gslb == '0'):
            pop = Pop.objects.get(pk=self.data.get('pop'))
            host = Host.objects.get(pk=self.data.get('host'))
            if pop and host:
                from spectrum_api.configuration.models.probeagent import ProbeAgent
                vips = Vip.objects.filter(host=host).values('vip')
                probeagents = ProbeAgent.objects.filter(vip__in=vips)
                if pop.auto_probe==1 and probeagents.count() > 0 \
                  and not pop.check_auto_probeagents(self.data.get('host'), 'host'):
                    enable_gslb = str(self.data.get('enable_gslb'))

                    if enable_gslb != new_enable_gslb:
                        raise serializers.ValidationError(_("Cannot be changed.Please check the auto probe option."))
        return attrs

    def validate_host_name(self, attrs, source):
        ihms_host = attrs.get('ihms_host')
        value = attrs.get(source)

        if not ihms_host:
            try:
                if regex_host_name.match(value) is None:
                    raise serializers.ValidationError(_("host name is invalied"))
            except TypeError as e:
                raise serializers.ValidationError(_("host name is required"))
            except Exception as e:
                raise e
        return attrs

    def get_system_name(self, data):
        if data.system.ihms_system:
            return data.system.ihms_system.system_name
        return data.system.system_name

    def get_pop_name(self, data):
        if data.system.pop.pop_name:
            return data.system.pop.pop_name
        return data.system.pop.ihms_pop.pop_code

class BaseSystemSerializer(serializers.ModelSerializer):
    system_name = serializers.SerializerMethodField('get_name')
    class Meta:
        model = System
        fields = ('system', 'system_name')

    def get_name(self, data):
        return data.get_fullsystemname()


class UpLinkBaseProbeConfigSerializer(serializers.ModelSerializer):
    vip_full_name = serializers.SerializerMethodField('get_vip_full_name')
    class Meta:
        model = PopUplinkProbeConfigs
        fields = ('pop_uplink_probe_id', 'probe', 'vip', 'vip_full_name')
    def get_identity(self, data):
        try:
            return data.get('pop_uplink_probe_id', None)
        except AttributeError:
            return None

    def get_vip_full_name(self, data):
        return data.vip.get_fullvipname() + " (%s)" % data.vip if data.vip else None

class PopProbeAgentConfigSerializer(serializers.ModelSerializer):
    NIC = serializers.RelatedField(source='probeagent.vip.ip', read_only=True)
    probeagentvip = serializers.RelatedField(source='probeagent.vip', read_only=True)
    hostname = serializers.RelatedField(source='probeagent.vip.full_host_name', read_only=True)
    host_id = serializers.RelatedField(source='probeagent.vip.host_id', read_only=True)

    class Meta:
        model = PopProbeAgentConfig
        fields = ('popprobeagentconfig_id', 'probeagent', 'primary', 'NIC', 'probeagentvip', 'hostname', 'host_id')

    def get_identity(self, data):
        try:
            return data.get('popprobeagentconfig_id', None)
        except AttributeError:
            return None

class PopInfoSerializer(serializers.ModelSerializer):
    pop = serializers.RelatedField(many=False)
    class Meta:
        model = PopInfo
        fields = ('desc_link', 'idc', 'country', 'priority')

class IhmsPopInfoSerializer(serializers.ModelSerializer):
    pop = serializers.RelatedField(many=False)
    class Meta:
        model = IhmsPopInfo
        fields = ('desc_link', 'idc', 'country', 'priority')

class IhmsPopSerializer(serializers.ModelSerializer):
    popinfo = IhmsPopInfoSerializer(source="ihmspopinfo", required=False)
    class Meta:
        model = IhmsPop
        fields = ('pop_id', 'popinfo')


class CustomerContractPopSerializer(serializers.ModelSerializer):
    customername = serializers.RelatedField(source='customer.customer_name', read_only=True)
    use_type = serializers.IntegerField(required=True)

    class Meta:
        model = CustomerContractPop
        fields = ('id', 'customer', 'use_type', 'customername', 'probe_agent_selection_type')

    def validate(self, attrs):
        errors = {}
        if not attrs.get('customer'):
            errors["customer"] = [_("This field is required")]
        if not attrs.get('use_type') or attrs.get('use_type') == '':
            errors["use_type"] = [_("use type is required")]
        if attrs.has_key('probe_agent_selection_type') and attrs.get('probe_agent_selection_type') not in (0, 1):
            errors["probe_agent_selection_type"] = [_("probe agent selection type is invalid")]
        if len(errors) > 0:
            raise serializers.ValidationError(errors)
        return attrs

class BasePopSerializer(serializers.ModelSerializer):
    pop_name = serializers.SerializerMethodField('get_name')
    class Meta:
        model = Pop
        fields = ('pop', 'pop_name')
    def get_identity(self, data):
        try:
            return data.get('pop', None)
        except AttributeError:
            return None

    def get_name(self, data):
        if data.ihms_pop:
            return data.ihms_pop.pop_code
        return data.pop_name

class PopSerializer(serializers.ModelSerializer):
    pop_name_info = serializers.SerializerMethodField('get_name')
    popgroup_info = PopGroupSerializer(many=True, read_only=True, source="popgroup")
    rttserver_info = ProbeAgentField(many=False, read_only=True, source="rttserver")
    pktlossserver_info = ProbeAgentField(many=True, read_only=True, source="pktlossserver")
    probeagent = PopProbeAgentConfigSerializer(many=True, required=False, source="pop_set", allow_add_remove=True)
    popinfo_info = serializers.SerializerMethodField('get_popinfo')
    popinfo = PopInfoSerializer(source="popinfo", required=False)
    ihms_pop = IhmsPopSerializer(required=False)
    uplinkprobe = UpLinkBaseProbeConfigSerializer(many=True, required=False, source="popuplinkprobeconfigs_set", allow_add_remove=True)
    customerpop = CustomerContractPopSerializer(many=True, required=False, source="customercontractpop_set", allow_add_remove=True)
    cdnw_pop_id = serializers.SerializerMethodField('get_cdnw_pop_id')
    pktloss_threshold = serializers.FloatField(validators=[MinValueValidator(0), MaxValueValidator(100)], required=False)
    cost = serializers.FloatField(validators=[MinValueValidator(0), MaxValueValidator(4294967295)], required=False)
    pop_name = serializers.CharField(required=False)

    class Meta:
        model = Pop
        fields = ('pop', 'pop_name_info', 'pop_name', 'popinfo_info', 'popinfo', 'ihms_pop', 'description', \
                  'enable_gslb', 'cost', 'enable_cname_latency', 'pktloss_threshold', \
                  'rttserver', 'rttserver_info', 'auto_probe',\
                  'pktlossserver', 'pktlossserver_info', \
                  'probeagent', \
                  'popgroup', 'popgroup_info',
                  'uplinkprobe', \
                  'customerpop', 'cdnw_pop_id')

    def validate(self, attrs):
        auto_probe = attrs.get('auto_probe', None)
        if auto_probe == None or auto_probe == 0:
            if attrs.get('rttserver', None) == None or \
                len(attrs.get('pktlossserver', [])) == 0 or \
                len(attrs.get('pop_set', [])) == 0:
                raise serializers.ValidationError({"__all__":[_("The NGP POP must have rtt_server, probe_server and packetloss_server setting")]})

            if not attrs.get('pop_set', None) == None:
                primary_cnt = 0
                for probeagent in attrs.get('pop_set', None):
                    if probeagent.primary == True:
                        primary_cnt += 1
                if primary_cnt != 1:
                    raise serializers.ValidationError({"__all__":[_("The POP need only one primary probeconfig.")]})
        else:
            customercontractpop = attrs.get('customercontractpop_set', None)
            if customercontractpop != None and len(customercontractpop) > 0:
                if customercontractpop[0].use_type == 1:
                    raise serializers.ValidationError({"__all__":[_("Auto Probe cannot be set for customer POPs.  Please set the Probe configurations manually.")]})

            # probe agent check
            pop = self.data.get('pop')
            if pop:
                basepop = Pop.objects.get(pk=pop)
                is_valid = basepop.check_auto_probe_condition()
                if not is_valid:
                    raise serializers.ValidationError({"auto_probe":[_("<b>Prerequisite:</b>A POP must have at least two Probe agents in order to use Auto Probe.\
                        <br/>To cancel the Auto Probe feature, uncheck the \"Auto Probe\" checkbox and manually set the Probe configuration of the POP.")]})

        return attrs

    def validate_pop_name(self, attrs, source):
        ihms_pop = attrs.get('ihms_pop')
        value = attrs.get(source)
        if not ihms_pop:
            try:
                if regex_pop_name.match(value) is None:
                    raise serializers.ValidationError(_("pop name is invalied"))
            except TypeError as e:
                raise serializers.ValidationError(_("pop name is required"))
            except Exception, e:
                raise e
        return attrs

    def __init__(self, *args, **kwargs):
        fields = kwargs.pop('fields', None)
        super(PopSerializer, self).__init__(*args, **kwargs)
        if fields:
            allowed = set(fields)
            existing = set(self.fields.keys())
            for field_name in existing - allowed:
                    self.fields.pop(field_name)

    def get_identity(self, data):
        try:
            return data.get('pop', None)
        except AttributeError:
            return None

    def get_name(self, data):
        if data.ihms_pop:
            return data.ihms_pop.pop_code
        return data.pop_name

    def get_cdnw_pop_id(self, data):
        if data.ihms_pop:
            return data.ihms_pop.pop_id
        else:
            return None

    def get_popinfo(self, data):
        pop_info_obj = None
        try:
            if data.ihms_pop:
                pop_info_obj = data.ihms_pop.ihmspopinfo
            else:
                pop_info_obj = data.popinfo
        except:
            pass
        if pop_info_obj:
            try:
                country = pop_info_obj.country
            except:
                country = None
            try:
                idc = pop_info_obj.idc
            except:
                idc = None
            try:
                priority = pop_info_obj.priority
            except:
                priority = None
            return {'country_id':country.country_id if country else country, \
                    'country':country, \
                    'idc_id':idc.idc_id if idc else idc, \
                    'idc':idc, \
                    'priority':priority}
        else:
            return None

class DomainSerializer(serializers.ModelSerializer):
    class Meta:
        model = Domain
        fields = ('domain_id', 'name')
        depth = 0

    def get_identity(self, data):
        try:
            return data.get('domain_id', None)
        except AttributeError:
            return None


class ConfigDistActionSerializer(serializers.ModelSerializer):
    username = serializers.RelatedField(source='user.username', read_only=True)
    class Meta:
        model = ConfigDistAction
        fields = ('action_id', 'config_revision', 'user', 'description', 'time_created', 'username')
        depth = 0

    def get_identity(self, data):
        try:
            return data.get('action_id', None)
        except AttributeError:
            return None

class CustomerDisplaySerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerDisplay
        fields = ('customer_id', 'customer_name')
        depth = 0

    def get_identity(self, data):
        try:
            return data.get('customer_id', None)
        except AttributeError:
            return None

class VipProbeConfigField(serializers.RelatedField):
    def to_native(self, value):
        return {"probeconfig": "%s" % value.probe.pk,
                "name": "%s" % value.probe.name}

class VipEdgeField(serializers.RelatedField):
    def to_native(self, value):
        return {"edge": "%s" % value.edge.pk,
                "name": "%s" % value.edge.name}

class VipProbeConfigsSerializer(serializers.ModelSerializer):
    probe_name = serializers.RelatedField(source='probe', read_only=True)
    probe_type = serializers.SerializerMethodField('get_probe_type')
    class Meta:
        model = VipProbeConfigs
        fields = ('vip_probe_id', 'probe', 'probe_name', 'probe_type', 'threshold', 'timeout', 'step_func')
    def get_identity(self, data):
        try:
            return data.get('vip_probe_id', None)
        except AttributeError:
            return None
    def get_probe_type(self, data):
        if data.probe:
            return PROBE_TYPES[data.probe.probe_type][1]
        else:
            return ''

class BaseVipEdgeSerializer(serializers.ModelSerializer):
    edge_name = serializers.RelatedField(source='edge', read_only=True)
    class Meta:
        model = BaseVipEdge
        fields = ('id', 'edge', 'edge_name')

    def get_identity(self, data):
        try:
            return data.get('id', None)
        except AttributeError:
            return None

class VipSerializer(serializers.ModelSerializer):
    vip_name_info = serializers.SerializerMethodField('get_name')
    vip_addr_info = serializers.SerializerMethodField('get_vipaddr')
    pop_name = serializers.SerializerMethodField('get_popname')
    system_name = serializers.SerializerMethodField('get_systemname')
    host_name = serializers.SerializerMethodField('get_hostname')
    probeconfig = VipProbeConfigsSerializer(many=True, required=False, source='vipprobeconfigs_set', allow_add_remove=True)
    edge = BaseVipEdgeSerializer(many=True, required=False, source='basevipedge_set', allow_add_remove=True)
    is_deletable = serializers.Field('is_deletable')
    ihms_vip_information = serializers.SerializerMethodField('get_ihms_vip_information')

    gslb_config = serializers.SerializerMethodField('get_gslbconfig_func')
    probeagent_config = serializers.SerializerMethodField('get_probeagent_config_func')
    hyperion_config = serializers.SerializerMethodField('get_hyperion_config_func')
    storagenode_config = serializers.SerializerMethodField('get_storagenode_config_func')

    vip_name = serializers.CharField(required=False)

    class Meta:
        model = Vip
        fields = ('vip', 'host', 'vip_name', 'vip_addr', 'vip_name_info', \
                  'vip_addr_info', 'mproxy_shield', 'mproxy_outgoing_ip', \
                  'probeconfig', 'edge', 'description', \
                  'is_deletable', 'enable_gslb', 'ihms_vip_information', \
                  'gslb_config', 'pop_name', 'system_name', 'host_name',
                  'probeagent_config', 'hyperion_config', 'storagenode_config', 'ihms_vip')

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop('request', None)
        super(VipSerializer, self).__init__(*args, **kwargs)

    def validate_vip_name(self, attrs, source):
        ihms_vip = attrs.get('ihms_vip')
        value = attrs.get(source)
        if not ihms_vip:
            try:
                if regex_vip_name.match(value) is None:
                    raise serializers.ValidationError(_("vip name is invalied"))
            except TypeError as e:
                raise serializers.ValidationError(_("vip name is required"))
            except Exception as e:
                raise e
        return attrs

    def validate_vip_addr(self, attrs, source):
        ihms_vip = attrs.get('ihms_vip', None)
        value = attrs.get(source)
        if not ihms_vip:
            try:
                if regex_ipv4.match(value) is None:
                    raise serializers.ValidationError(_("vip addr is invalied"))
            except TypeError as e:
                raise serializers.ValidationError(_("vip addr is required"))
            except Exception, e:
                raise e
        return attrs

    def validate(self, attrs):
        try:
            force_update = self.request.DATA.get('force_update')
        except:
            force_update = False

        if self.data.get('vip') and not force_update:
            edge_list = [obj.edge_id for obj in attrs.get('basevipedge_set', [])]
            probe_list = [obj.probe_id for obj in attrs.get('vipprobeconfigs_set', [])]
            basevip = Vip.objects.get(pk=self.data.get('vip'))
            is_valid, errmsg = basevip.check_edgelist_probe_constraint(self.request, edge_list, probe_list, force_update)
            if not is_valid:
                raise serializers.ValidationError({"check_edgelist_probe_constraint":[_("%s" % errmsg)]})

        if self.data.get('vip'):
            # need config probe modify(probe_health) validate

            from spectrum_api.configuration.models.probeagent import ProbeAgent

            pop = Vip.objects.get(pk=self.data.get('vip')).host.system.pop
            try:
                probeagents = ProbeAgent.objects.get(vip=self.data.get('vip'))
            except:
                probeagents = None
            if pop:
                if pop.auto_probe==1 and probeagents \
                  and not pop.check_auto_probeagents(self.data.get('vip'), 'vip'):
                    host = Host.objects.get(pk=self.data.get('host'))
                    enable_gslb = str(self.data.get('enable_gslb'))
                    new_host = attrs.get('host', None)
                    new_enable_gslb = attrs.get('enable_gslb', '1')
                    probeconfigs = attrs.get('vipprobeconfigs_set', [])
                    if not new_host:
                        new_host = host

                    if host != new_host:
                        raise serializers.ValidationError({"host":[_("Cannot be changed.Please check the auto probe option.")]})
                    if (enable_gslb != new_enable_gslb and (new_enable_gslb == 0 or new_enable_gslb == '0')):
                        raise serializers.ValidationError({"enable_gslb":[_("Cannot be changed.Please check the auto probe option.")]})

                    probe_list = [str(obj.probe.name) for obj in probeconfigs]
                    if not "probe_health" in probe_list:
                        raise serializers.ValidationError({"probes":[_("Cannot be changed.Please check the auto probe option.")]})

        for probeconfig in attrs.get('vipprobeconfigs_set', []):
            probevips = []
            probeconfig.get_all_probevips_from_aggregate_probe(probeconfig.probe, probevips)
            host = attrs.get('host', None)
            if not host:
                host = Host.objects.get(pk=self.data.get('host'))

            this_pop = host.system.pop
            if this_pop.is_clb_pop():
                if not this_pop.is_modifiable():
                    raise serializers.ValidationError({"__all__":[_("This probevip's CLB pop is pending status. Please wait until the lock is released.")]})

            for probevip in probevips:
                try:
                    probevip.vip = probevip.vip
                except:
                    probevip.vip = None
                if not probevip.vip:
                    # vip is not assigned, it's OK.
                    # because it will be replaced to self.vip by probe agent.
                    continue
                vip = Vip.objects.get(pk=probevip.vip.pk)
                targetpop = vip.host.system.pop
                if targetpop == this_pop:
                    # if pop is same, it's OK.
                    continue
                for probe in this_pop.probeagent.all():
                    if not probe.verify_probe_agent(probe, targetpop):
                        raise serializers.ValidationError({"__all__":
                             [_("Not allow this. This pop's probe agent(%(probe)s) cannot probe %(targetpop)s." % {"probe": probe, "targetpop": targetpop})]})
        return attrs

    def get_hostname(self, data):
        return data.host.get_fullhostname()

    def get_systemname(self, data):
        return data.host.system.get_fullsystemname()

    def get_popname(self, data):
        return data.host.system.pop.get_popname()

    def get_gslbconfig_func(self, data):
        query_set = GSLB.objects.filter(vip=data)
        ret = []
        for obj in query_set:
            ret.append({'id':obj.pk,
                        'name':obj})
        return ret

    def get_probeagent_config_func(self, data):
        query_set = data.get_probeagent_config()
        ret = []
        for obj in query_set:
            ret.append({'id':obj.pk,
                        'name':obj})
        return ret

    def get_hyperion_config_func(self, data):
        query_set = data.get_hyperion_config()
        ret = []
        for obj in query_set:
            ret.append({'id':obj.pk,
                        'obj_state':obj.obj_state,
                        'name':obj})
        return ret

    def get_storagenode_config_func(self, data):
        query_set = data.get_storagenode_config()
        ret = []
        for obj in query_set:
            ret.append({'id':obj.cluster.pk,
                        'obj_state':obj.obj_state,
                        'name':obj})
        return ret

    def get_name(self, data):
        if data.ihms_vip:
            return data.ihms_vip.vip_name
        return data.vip_name

    def get_vipaddr(self, data):
        if data.ihms_vip:
            return data.ihms_vip.getipaddress()
        return data.vip_addr

    def get_ihms_vip_information(self, data):
        if data.ihms_vip:
            return {'Vip_name':data.ihms_vip.vip_name ,
                'Ip':data.ihms_vip ,
                'Primary':data.ihms_vip.primary ,
                'Ihms_Status':'%d' % data.ihms_vip.ihms_status ,
                'Ihms_Latest_Updater_id':data.ihms_vip.ihms_latest_updater_id ,
                'Ihms_Latest_Update_Date':data.ihms_vip.ihms_latest_update_date ,
                'Latest_Update_Date':data.ihms_vip.latest_update_date
                }
        else:
            return None




class CLBPopProbeAgentConfigSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(source='probeagent.pk', required=False, read_only=False)
    vip_addr = serializers.RelatedField(source='probeagent.vip.ip', read_only=True)
    primary = serializers.SerializerMethodField('get_primary')

    class Meta:
        model = PopProbeAgentConfig
        fields = ('id', 'vip_addr', 'primary')

    def get_primary(self, data):
        if data.primary == True:
            return '1'
        else:
            return '0'

class CLBPopSerializer(serializers.ModelSerializer):
    probe_agent = CLBPopProbeAgentConfigSerializer(many=True, required=False, source="pop_set")
    vip = serializers.SerializerMethodField('get_clb_vip')
    class Meta:
        model = Pop
        fields = ('pop', 'probe_agent', 'vip')
    def get_identity(self, data):
        try:
            return data.get('pop', None)
        except AttributeError:
            return None
    def get_clb_vip(self, data):
        queryset = data.get_vips()
        ret = []
        for obj in queryset:
            ret.append({"vip_addr":obj})
        return ret


class SimpleHostSerializer(serializers.ModelSerializer):
    pop = serializers.Field('system.pop.pk')
    host_name = serializers.SerializerMethodField('get_host_name')
    class Meta:
        model = Host
        fields = ('host', 'host_name' , 'enable_gslb' , 'pop' , 'system' , 'description')

    def get_host_name(self, data):
        if data.ihms_host:
            return data.ihms_host.host_name
        return data.host_name


class SimpleHostBulkSerializer(serializers.ModelSerializer):
    fullhostname = serializers.Field('get_fullhostname')
    pop_name = serializers.SerializerMethodField('get_pop_name')
    role = HostRoleSerializer(many=True, required=False, source="hostrole_set", allow_add_remove=True)
    role_info = HostRoleField(many=True, read_only=True, source="hostrole_set")

    class Meta:
        model = Host
        fields = ('pop_name','host',\
                  'fullhostname', 'role', 'role_info',)

    def get_host_name(self, data):
        if data.ihms_host:
            return data.ihms_host.host_name
        return data.host_name

    def get_pop_name(self, data):
        if data.system.pop.pop_name:
            return data.system.pop.pop_name
        return data.system.pop.ihms_pop.pop_code

class HostRoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = HostRole
        fields = ('host', 'role',)
