from rest_framework import serializers
from spectrum_api.configuration.models.clb import CLBAlertManagementBase, \
                                                CLBAlertGroup, \
                                                CLBAlertGroupHasCLBDomain, \
                                                CLBAlertRecipients, \
                                                CLBAlertGroupHasRecipients, \
                                                CLBAlertDomainFailHistory, \
                                                CLBAlertVipFailHistory, \
                                                CLBAlertDomainSnapshot

from spectrum_api.shared_components.models import StatMaster
from spectrum_api.shared_components.models.common_code import GMTCD
from django.utils.translation import ugettext as _
from datetime import datetime

class CLBAlertGroupHasCLBDomainSerializer(serializers.ModelSerializer):
    domain = serializers.SerializerMethodField('get_domain')
    deleted = serializers.SerializerMethodField('get_deleted')

    class Meta:
        model = CLBAlertGroupHasCLBDomain
        fields = ('clbalertgrouphasclbdomain_id', 'statmaster', 'domain', 'deleted')

    def get_identity(self, data):
        try:
            return data.get('clbalertgrouphasclbdomain_id', None)
        except AttributeError:
            return None

    def get_domain(self, data):
        return data.statmaster.display_name

    def get_deleted(self, data):
        return True if data.statmaster.obj_state != 1 else False

class CLBAlertGroupHasRecipientsSerializer(serializers.ModelSerializer):
    email = serializers.RelatedField(source='clb_alert_recipients.email', read_only=True)
    phone_number = serializers.RelatedField(source='clb_alert_recipients.phone_number', read_only=True)
    class Meta:
        model = CLBAlertGroupHasRecipients
        fields = ('clbalertgrouphasrecipients_id', 'clb_alert_group', 'email', 'phone_number')

    def get_identity(self, data):
        try:
            return data.get('clbalertgrouphasrecipients_id', None)
        except AttributeError:
            return None

class BaseCLBAlertGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = CLBAlertGroup
        fields = ('clbalertgroup_id', 'clb_group_name', 'alert_use_flag')

class CLBAlertGroupSerializer(serializers.ModelSerializer):
    clbalertgrouphasclbdomain = CLBAlertGroupHasCLBDomainSerializer(many=True, required=False, source="clbalertgrouphasclbdomain_set")
    clbalertgrouphasrecipient = CLBAlertGroupHasRecipientsSerializer(many=True, required=False, source="clbalertgrouphasrecipients_set")
    clbalertgroup_id = serializers.IntegerField(read_only=True)
    clb_group_name = serializers.CharField(read_only=True)
    group_type = serializers.IntegerField(read_only=True)
    sort_order = serializers.IntegerField(read_only=True)
    alert_base_id = serializers.IntegerField(source='alert_base_id.pk', read_only=True)

    class Meta:
        model = CLBAlertGroup
        fields = ('clbalertgroup_id', 'clb_group_name', 'group_type', 'sort_order', \
                  'date_off_start_time', 'date_off_end_time', 'alert_use_flag', \
                  'date_off_use_flag', 'repeat_off_use_flag', 'alert_base_id', \
                  'repeat_off_start_time', 'repeat_off_end_time', 'repeat_off_date', \
                  'clbalertgrouphasclbdomain', 'clbalertgrouphasrecipient')

    def get_identity(self, data):
        try:
            return data.get('clbalertgroup_id', None)
        except AttributeError:
            return None

    def validate_date_off_start_time(self, attrs, source):
        value = attrs[source]
        if attrs.get('date_off_use_flag', False) and not value:
            raise serializers.ValidationError(_("Start time of Alert Off Scheduling is required"))
        if value and value.year < 1900:
            raise serializers.ValidationError(_("Start time of Alert Off Scheduling is invalid"))
        return attrs

    def validate_date_off_end_time(self, attrs, source):
        value = attrs[source]
        if attrs.get('date_off_use_flag', False) and not value:
            raise serializers.ValidationError(_("End time of Alert Off Scheduling is required"))
        if value and value.year < 1900:
            raise serializers.ValidationError(_("End time of Alert Off Scheduling is invalid"))
        return attrs

    def validate_repeat_off_start_time(self, attrs, source):
        value = attrs[source]
        if attrs.get('repeat_off_use_flag', False) and not value:
            raise serializers.ValidationError(_("Start time of Weekly repeat is required"))
        if value:
            try:
                int_time = int(value)
            except:
                raise serializers.ValidationError(_("Start time of Weekly repeat is invalid"))
            if int_time > 2359 or len(value) != 4:
                raise serializers.ValidationError(_("Start time of Weekly repeat is invalid"))
        return attrs

    def validate_repeat_off_end_time(self, attrs, source):
        value = attrs[source]
        if attrs.get('repeat_off_use_flag', False) and not value:
            raise serializers.ValidationError(_("End time of Weekly repeat is required"))
        if value:
            try:
                int_time = int(value)
            except:
                raise serializers.ValidationError(_("End time of Weekly repeat is invalid"))
            if int_time > 2359 or len(value) != 4:
                raise serializers.ValidationError(_("End time of Weekly repeat is invalid"))
        return attrs

    def validate_repeat_off_date(self, attrs, source):
        value = attrs[source]
        if attrs.get('repeat_off_use_flag', False) and (not value or value == ''):
            raise serializers.ValidationError(_("Weekdays of Weekly repeat is required"))
        if value:
            try:
                split_int_weekday = value.split(':')
                for each in split_int_weekday:
                    weekday = int(each)
                    if not weekday in [0,1,2,3,4,5,6]:
                        raise serializers.ValidationError(_("Weekdays of Weekly repeat is invalid"))
            except:
                raise serializers.ValidationError(_("Weekdays of Weekly repeat is invalid"))
        return attrs

    def validate(self, attrs):
        errors = {}
        if attrs.get('date_off_use_flag', False):
            if attrs.get('date_off_start_time', None) == None:
                errors["date_off_start_time"] = [_("Start time of Alert Off Scheduling is required")]
            if attrs.get('date_off_end_time', None) == None:
                errors["date_off_end_time"] = [_("End time of Alert Off Scheduling is required")]

            date_off_start_time = attrs.get('date_off_start_time', None)
            date_off_end_time = attrs.get('date_off_end_time', None)

            if date_off_start_time and date_off_end_time \
                and date_off_start_time >= date_off_end_time:
                errors["date_off_start_time"] = [_("Start time of Alert Off Scheduling must be earlier")]

        if attrs.get('repeat_off_use_flag', False):
            if attrs.get('repeat_off_start_time', None) == None or \
                attrs.get('repeat_off_start_time', '') == '':
                errors["repeat_off_start_time"] = [_("Start time of Weekly repeat is required")]
            if attrs.get('repeat_off_end_time', None) == None or \
                attrs.get('repeat_off_end_time', '') == '':
                errors["repeat_off_end_time"] = [_("End time of Weekly repeat is required")]
            if attrs.get('repeat_off_date', None) == None or \
                attrs.get('repeat_off_date', '') == '':
                errors["repeat_off_date"] = [_("Weekdays of Weekly repeat is required")]

        if len(errors) > 0:
            raise serializers.ValidationError(errors)
        return attrs


class CLBAlertManagementBaseSerializer(serializers.ModelSerializer):
    clb_alert_group = CLBAlertGroupSerializer(source='clb_alert_group_set', read_only=True)
    gmt_hh = serializers.SerializerMethodField('get_gmt_hh')
    class Meta:
        model = CLBAlertManagementBase
        fields = ('clbalertmanagementbase_id', 'alert_gmt_cd', 'gmt_hh', 'account_no', 'reg_date', 'clb_alert_group')

    def get_identity(self, data):
        try:
            return data.get('clbalertmanagementbase_id', None)
        except AttributeError:
            return None

    def get_gmt_hh(self, obj):
        obj = GMTCD.objects.get(gmt_cd=obj.alert_gmt_cd)
        return obj.gmt_hh

class CLBAlertRecipientsSerializer(serializers.ModelSerializer):
    clbalertgrouphasrecipient = CLBAlertGroupHasRecipientsSerializer(many=True, required=False, source="clbalertgrouphasrecipients_set", allow_add_remove=True)
    username = serializers.CharField(source='username', required=True)
    email = serializers.CharField(source='email', required=True)
    phone_number = serializers.CharField(source='phone_number', required=True)
    comment = serializers.CharField(source='comment', required=False)
    class Meta:
        model = CLBAlertRecipients
        fields = ('clbalertrecipients_id', 'alert_base_id', 'username', 'email', 'phone_number', 'comment', 'clbalertgrouphasrecipient')

    def validate_username(self, attrs, source):
        value = attrs[source]
        if len(value) == 0:
            raise serializers.ValidationError("username is required")
        return attrs

    def validate_email(self, attrs, source):
        value = attrs[source]
        if len(value) == 0:
            raise serializers.ValidationError("email is required")
        return attrs

    def validate_phone_number(self, attrs, source):
        value = attrs[source]
        if len(value) == 0:
            raise serializers.ValidationError("phone_number is required")
        return attrs


class CLBStatMasterSerializer(serializers.ModelSerializer):
    class Meta:
        model = StatMaster
        fields = ('stat_id', 'display_name')

    def __init__(self, *args, **kwargs):
        super(CLBStatMasterSerializer, self).__init__(*args, **kwargs)


class CLBAlertDomainFailHistorySerializer(serializers.ModelSerializer):
    domain = serializers.Field(source='statmaster.display_name')

    class Meta:
        model = CLBAlertDomainFailHistory
        fields = ('id', 'statmaster', 'domain', 'fail_message', 'update_time')

    def get_identity(self, data):
        try:
            return data.get('id', None)
        except AttributeError:
            return None

class CLBAlertVipFailHistorySerializer(serializers.ModelSerializer):

    class Meta:
        model = CLBAlertVipFailHistory
        fields = ('id', 'account_no', 'vip_addr', 'vip_probe_name', 'val', 'fail_message', 'update_time')

    def get_identity(self, data):
        try:
            return data.get('id', None)
        except AttributeError:
            return None

class CLBAlertDomainSnapshotSerializer(serializers.ModelSerializer):
    group = serializers.Field('get_group')
    domain = serializers.Field(source='statmaster.display_name')


    class Meta:
        model = CLBAlertDomainSnapshot
        fields = ('group', 'statmaster', 'domain', 'status', 'tot_vip_cnt', 'fail_vip_cnt', 'domain_fail_history', 'update_time')
        depth = 1


    def get_identity(self, data):
        try:
            return data.get('statmaster_id', None)
        except AttributeError:
            return None


class GMTCDSerializer(serializers.ModelSerializer):
    local_name = serializers.SerializerMethodField('get_local_name')
    class Meta:
        model = GMTCD
        fields = ('gmt_cd', 'local_name')

    def __init__(self, *args, **kwargs):
        super(GMTCDSerializer, self).__init__(*args, **kwargs)

    def get_local_name(self, data):
        return data.gmt_name_en
