# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Rest API
"""
from rest_framework import serializers
from spectrum_api.configuration.models.config import ConfigGroup, ConfigGroupProduct, ConfigType, ConfigPhase, ConfigJointGroup, \
     ConfigDistAction, ConfigDistState

class ConfigGroupSerializer(serializers.ModelSerializer):

    class Meta:
        model = ConfigGroup
        fields = ('config_group_id', 'name')
        depth = 0

    def get_identity(self, data):
        try:
            return data.get('config_group_id', None)
        except AttributeError:
            return None

class ConfigGroupProductSerializer(serializers.ModelSerializer):

    class Meta:
        model = ConfigGroupProduct

        fields = ('product', 'config_group')
        depth = 1

    def get_identity(self, data):
        try:
            return data.get('config_group_product_id', None)
        except AttributeError:
            return None

class ConfigTypeSerializer(serializers.ModelSerializer):

    class Meta:
        model = ConfigType
        fields = ('config_type_id', 'config_group', 'name', 'promote_time', 'is_sequence')
        depth = 1

    def get_identity(self, data):
        try:
            return data.get('config_type_id', None)
        except AttributeError:
            return None

class ConfigPhaseSerializer(serializers.ModelSerializer):
    config_group_name = serializers.RelatedField(source="config_type.config_group")

    class Meta:
        model = ConfigPhase
        fields = ('config_phase_id', 'config_type', 'name', 'sequence', 'config_group_name')
        depth = 1

    def get_identity(self, data):
        try:
            return data.get('config_phase_id', None)
        except AttributeError:
            return None

class ConfigJointSerializer(serializers.ModelSerializer):

    class Meta:
        model = ConfigJointGroup
        fields = ('config_joint_group_id', 'config_joint', 'config_phase')
        depth = 3

    def get_identity(self, data):
        try:
            return data.get('config_joint_group_id', None)
        except AttributeError:
            return None

class ConfigPushSerializer(serializers.ModelSerializer):
    user_id = serializers.RelatedField(source='user.pk')
    username = serializers.RelatedField(source='user')

    class Meta:
        model = ConfigDistAction
        fields = ('action_id', 'to_phase', 'from_phase', 'config_revision', 'previous_revision', 'time_created', 'time_deployed', \
                  'user_id', 'username', 'status', 'status_msg', 'action_keyword', 'description', 'config_joint', 'parent_joint_action_id')
        depth = 3

    def get_identity(self, data):
        try:
            return data.get('action_id', None)
        except AttributeError:
            return None

class ConfigPushStateSerializer(serializers.ModelSerializer):
    to_phase_name = serializers.RelatedField(source="action.to_phase")

    class Meta:
        model = ConfigDistState
        fields = ('phase', 'action', 'to_phase_name')
        depth = 1

    def get_identity(self, data):
        try:
            return data.get('phase', None)
        except AttributeError:
            return None

