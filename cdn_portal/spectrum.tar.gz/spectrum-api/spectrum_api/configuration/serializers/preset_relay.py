from rest_framework import serializers
from django.utils.translation import ugettext as _
from spectrum_api.configuration.models.preset_relay import MproxyPreset, MproxyRelays, \
    MproxyPresetRelay

"""
    configuration - Pre-set Relay
"""

class MproxyPresetSerializer(serializers.ModelSerializer):
    class Meta:
        model = MproxyPreset
        fields = ("preset_id",
                  "preset_name",
                  "date_created",
                  "date_modified",
                  "obj_state")

class MproxyRelaysSerializer(serializers.ModelSerializer):
    preset_name = serializers.RelatedField(source="preset.preset_name", read_only=True)
    pop_name = serializers.SerializerMethodField('get_pop_name')

    class Meta:
        model = MproxyRelays
        fields = ("relay_id",
                  "relay_level",
                  "preset",
                  "preset_name",
                  "pop",
                  "pop_name",
                  "obj_state")

class SubMproxyRelaysSerializer(serializers.ModelSerializer):
    pop_name = serializers.SerializerMethodField('get_pop_name')

    class Meta:
        model = MproxyRelays
        fields = ("relay_id",
                  "relay_level",
                  "pop",
                  "pop_name",
                  "obj_state")

    def get_pop_name(self, data):
        if data.pop.ihms_pop:
            return data.pop.ihms_pop.pop_code
        return data.pop.pop_name

    def get_identity(self, data):
        try:
            return data.get('relay_id', None)
        except AttributeError:
            return None

class MproxyPresetRelaySerializer(serializers.ModelSerializer):
    relays = SubMproxyRelaysSerializer(many=True, source="mproxyrelays_set", required=False, 
                                       allow_add_remove=True)
    class Meta:
        model = MproxyPreset
        fields = ("preset_id",
                  "preset_name",
                  "relays")

    def get_identity(self, data):
        try:
            return data.get('preset_id', None)
        except AttributeError:
            return None

    def validate_preset_name(self, attrs, source):
        preset_name = attrs.get(source, '')
        preset_id = self.data.get('preset_id', None)
        if preset_name != '':
            if preset_id != None:
                presets = MproxyPreset.objects.filter(preset_name=preset_name).exclude(pk=preset_id)
            else:
                presets = MproxyPreset.objects.filter(preset_name=preset_name) 
            if presets.exists():
                raise serializers.ValidationError(_("Pre-set name is duplicated"))
        else:
            raise serializers.ValidationError(_("Pre-set name is required"))

        return attrs

    def validate_relays(self, attrs, source):
        relays = attrs.get(source)

        if len(relays) < 1:
            raise serializers.ValidationError(_("Relay 1's POP is required."))

        return attrs

class MproxyPresetRelayListSerializer(serializers.ModelSerializer):
    class Meta:
        model = MproxyPresetRelay
        fields = ("preset_id",
                  "preset_name",
                  "relay_1",
                  "relay_2",
                  "relay_3")

