# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Rest API
"""

from rest_framework import serializers
from spectrum_api.configuration.models.base import BaseProbeConfig, ProbeConfigStandaloneICMP, ProbeConfigStandaloneSNMP, \
    ProbeConfigStandaloneTCP, ProbeConfigStandaloneSSL, ProbeConfigStandaloneUDP, ProbeConfigStandaloneFTP, ProbeConfigStandaloneRTMP, \
    ProbeConfigStandaloneDNS, ProbeConfigAggregate, ProbeConfigAggregateProbe, VipProbeConfigs
from spectrum_api.configuration.models.clb import CustomerAllowProbeConfig
from spectrum_api.dna.models.domain import Domain, DomainVip, DomainEdge
from django.utils.translation import ugettext as _
from django.core.validators import MaxValueValidator, MinValueValidator, RegexValidator, MinLengthValidator, MaxLengthValidator
from spectrum_api.shared_components.utils.regex import probe_name_rex, stepfunc_rex, regex_stepfunc, oid_rex, regex_oid, \
    default_name_rex, regex_default_name, path_rex, regex_path, rtmp_app_rex, regex_rtmp_app, rtmp_flashver_rex, regex_rtmp_flashver, \
    rtmp_stream_name_rex, regex_rtmp_stream_name, gslb_domain_rex, regex_gslb_domain, default_password_rex, regex_default_password

class ProbeCustomersSerializer(serializers.ModelSerializer):
    customer_name = serializers.RelatedField(source='customer', read_only=True)

    class Meta:
        model = CustomerAllowProbeConfig
        fields = ('id',
                 # 'probeconfig',
                 'customer',
                'contract_no',
                'customer_name')

    def get_identity(self, data):
        try:
            return data.get('id', None)
        except AttributeError:
            return None

class ProbeSerializer(serializers.ModelSerializer):
    customer_set = ProbeCustomersSerializer(many=True, required=False, read_only=False, source="customerallowprobeconfig_set", allow_add_remove=True)
    probe_type_name = serializers.ChoiceField(source="get_probe_type_display", read_only=True)

    name = serializers.CharField(validators=[RegexValidator(probe_name_rex)], required=True)
    interval = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(4294967295)], required=False)
    ttl_factor = serializers.FloatField(validators=[MinValueValidator(1), MaxValueValidator(4294967295)], required=False)
    threshold = serializers.FloatField(validators=[MaxValueValidator(4294967295)], required=False)
    timeout = serializers.FloatField(validators=[MinValueValidator(1), MaxValueValidator(4294967295)], required=False)
    scaling = serializers.FloatField(validators=[MaxValueValidator(4294967295)], required=False)
    timespan = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(4294967295)], required=False)
    step_func = serializers.CharField(validators=[MaxLengthValidator(1024), RegexValidator(stepfunc_rex)], required=False)
    alert_message = serializers.CharField(validators=[MaxLengthValidator(4096)], required=False)
    try_count = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)], required=False)

    class Meta:
        model = BaseProbeConfig
        fields = ('probeconfig_id', 'name', 'description', 'interval', 'ttl_factor', 'threshold', 'report', 'report_other', 'log', 'timeout', 'try_count', 'scaling', 'timespan', 'ratio_base', 'step_func', 'date_created', 'date_modified', 'probe_type', 'probe_type_name', 'use_clb', 'customer_set', 'alert_message')

    def get_identity(self, data):
        try:
            return data.get('probeconfig_id', None)
        except AttributeError:
            return None

    def validate_step_func(self, attrs, source):
        value = attrs.get(source)
        if value :
            if regex_stepfunc.match(value) is None:
                raise serializers.ValidationError(_("This field is invalied."))
        return attrs

    def validate_try_count(self, attrs, source):
        ##############################################################
        # default : try_count(1), timeout(3.0), interval(300)
        # validate : (try_count * timeout) + try_count < interval
        #            except aggregate probe
        ##############################################################
        try:
            try_count = float(attrs.get(source))
        except:
            attrs[source] = 1
            try_count = 1.0
        try:
            timeout = float(attrs.get('timeout'))
        except:
            timeout = 3.0
        try:
            interval = float(attrs.get('interval'))
        except:
            interval = 300.0

        valid_value = (try_count * timeout) + try_count
        if try_count > 1 and (valid_value >= interval):
            err_msg = "This field is invalied. ((Try Count * Timeout) + Try Count)" + str(valid_value) + " < " + str(int(interval)) + "(Interval)"
            raise serializers.ValidationError(_(err_msg))
        return attrs

class ProbeNameSerializer(serializers.ModelSerializer):
    class Meta:
        model = BaseProbeConfig
        fields = ('probeconfig_id', 'name')

    def get_identity(self, data):
        try:
            return data.get('probeconfig_id', None)
        except AttributeError:
            return None

class ProbeIcmpSerializer(ProbeSerializer):
    class Meta:
        model = ProbeConfigStandaloneICMP
        fields = ('probeconfig_id', 'name', 'description', 'interval', 'ttl_factor', 'threshold', 'report', 'report_other', 'log', 'timeout', 'try_count', 'scaling', 'timespan', 'ratio_base', 'step_func', 'date_created', 'date_modified', 'probe_type', 'probe_type_name', 'use_clb', 'customer_set', 'alert_message', 'icmp_type', 'value_type')

    def validate(self, attrs):
        icmp_type = attrs.get('icmp_type', None)

        if (icmp_type or icmp_type == 0) and icmp_type is not 8 :
            raise serializers.ValidationError({"icmp_type":[_("ICMP type supports only number 8.")]})

        return attrs

class ProbeSnmpSerializer(ProbeSerializer):
    port = serializers.IntegerField(validators=[MaxValueValidator(65535)], required=False)
    oid = serializers.CharField(validators=[RegexValidator(oid_rex)], required=False)
    community = serializers.CharField(validators=[RegexValidator(default_name_rex)], required=False)
    username = serializers.CharField(validators=[RegexValidator(default_name_rex)], required=False)
    auth_password = serializers.CharField(validators=[MinLengthValidator(8), RegexValidator(default_name_rex)], required=False)
    priv_password = serializers.CharField(validators=[MinLengthValidator(8), RegexValidator(default_name_rex)], required=False)
    context = serializers.CharField(validators=[RegexValidator(default_name_rex)], required=False)

    class Meta:
        model = ProbeConfigStandaloneSNMP
        fields = ('probeconfig_id', 'name', 'description', 'interval', 'ttl_factor', 'threshold', 'report', 'report_other', 'log', 'timeout', 'try_count', 'scaling', 'timespan', 'ratio_base', 'step_func', 'date_created', 'date_modified', 'probe_type', 'probe_type_name', 'use_clb', 'customer_set', 'alert_message', \
                  'version', 'port', 'oid_type', 'oid', 'value_type', 'community', 'username', 'security_level', 'auth_protocol', 'auth_password', 'priv_protocol', 'priv_password', 'context')

    def validate(self, attrs):
        if attrs.get('version', None) and attrs['version'] == '3' :
            if attrs.get('auth_password', None) == None :
                raise serializers.ValidationError({"auth_password":[_("This field is required.")]})
            if attrs.get('priv_password', None) == None :
                raise serializers.ValidationError({"priv_password":[_("This field is required.")]})

        if not attrs.get('oid', None) :
            raise serializers.ValidationError({"oid":[_("This field is required.")]})

        if attrs.get('oid', None) and regex_oid.match(attrs.get('oid', None)) is None:
            raise serializers.ValidationError({"oid":[_("This field is invalied.")]})

        if attrs.get('community', None) :
            if regex_default_name.match(attrs.get('community', None)) is None:
                raise serializers.ValidationError({"community":[_("This field is invalied.")]})

        if attrs.get('username', None) :
            if regex_default_name.match(attrs.get('username', None)) is None:
                raise serializers.ValidationError({"username":[_("This field is invalied.")]})

        if attrs.get('auth_password', None) :
            if regex_default_name.match(attrs.get('auth_password', None)) is None:
                raise serializers.ValidationError({"auth_password":[_("This field is invalied.")]})

        if attrs.get('priv_password', None) :
            if regex_default_name.match(attrs.get('priv_password', None)) is None:
                raise serializers.ValidationError({"priv_password":[_("This field is invalied.")]})

        if attrs.get('context', None) :
            if regex_default_name.match(attrs.get('context', None)) is None:
                raise serializers.ValidationError({"context":[_("This field is invalied.")]})

        return attrs

class ProbeTcpSerializer(ProbeSerializer):
    port = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(65535)], required=True)
    message = serializers.CharField(validators=[MaxLengthValidator(65535)], required=False)
    content_length = serializers.IntegerField(validators=[MinValueValidator(-1), MaxValueValidator(65535)], required=False)
    regex = serializers.CharField(validators=[MaxLengthValidator(255)], required=False)

    class Meta:
        model = ProbeConfigStandaloneTCP
        fields = ('probeconfig_id', 'name', 'description', 'interval', 'ttl_factor', 'threshold', 'report', 'report_other', 'log', 'timeout', 'try_count', 'scaling', 'timespan', 'ratio_base', 'step_func', 'date_created', 'date_modified', 'probe_type', 'probe_type_name', 'use_clb', 'customer_set', 'alert_message', \
                  'port', 'message', 'content_length', 'value_type', 'regex')

class ProbeSslSerializer(ProbeSerializer):
    port = serializers.IntegerField(validators=[MaxValueValidator(65535)], required=False)
    message = serializers.CharField(validators=[MaxLengthValidator(65535)], required=False)
    content_length = serializers.IntegerField(validators=[MinValueValidator(-1), MaxValueValidator(65535)], required=False)
    regex = serializers.CharField(validators=[MaxLengthValidator(255)], required=False)

    class Meta:
        model = ProbeConfigStandaloneSSL
        fields = ('probeconfig_id', 'name', 'description', 'interval', 'ttl_factor', 'threshold', 'report', 'report_other', 'log', 'timeout', 'try_count', 'scaling', 'timespan', 'ratio_base', 'step_func', 'date_created', 'date_modified', 'probe_type', 'probe_type_name', 'use_clb', 'customer_set', 'alert_message', \
                  'verify_server', 'port', 'message', 'content_length', 'value_type', 'regex')

class ProbeUdpSerializer(ProbeSerializer):
    port = serializers.IntegerField(validators=[MaxValueValidator(65535)], required=True)
    message = serializers.CharField(validators=[MaxLengthValidator(65535)], required=False)
    content_length = serializers.IntegerField(validators=[MinValueValidator(-1), MaxValueValidator(65535)], required=False)
    regex = serializers.CharField(validators=[MaxLengthValidator(255)], required=False)

    class Meta:
        model = ProbeConfigStandaloneUDP
        fields = ('probeconfig_id', 'name', 'description', 'interval', 'ttl_factor', 'threshold', 'report', 'report_other', 'log', 'timeout', 'try_count', 'scaling', 'timespan', 'ratio_base', 'step_func', 'date_created', 'date_modified', 'probe_type', 'probe_type_name', 'use_clb', 'customer_set', 'alert_message', \
                  'port', 'message', 'content_length', 'value_type', 'regex')

class ProbeFtpSerializer(ProbeSerializer):
    port = serializers.IntegerField(validators=[MaxValueValidator(65535)], required=False)
    username = serializers.CharField(validators=[RegexValidator(default_name_rex)], required=False)
    password = serializers.CharField(validators=[RegexValidator(default_password_rex)], required=False)
    filepath = serializers.CharField(validators=[RegexValidator(path_rex)], required=False)
    content_length = serializers.IntegerField(validators=[MinValueValidator(-1), MaxValueValidator(65535)], required=False)
    regex = serializers.CharField(validators=[MaxLengthValidator(255)], required=False)

    class Meta:
        model = ProbeConfigStandaloneFTP
        fields = ('probeconfig_id', 'name', 'description', 'interval', 'ttl_factor', 'threshold', 'report', 'report_other', 'log', 'timeout', 'try_count', 'scaling', 'timespan', 'ratio_base', 'step_func', 'date_created', 'date_modified', 'probe_type', 'probe_type_name', 'use_clb', 'customer_set', 'alert_message', \
                  'port', 'username', 'password', 'filepath', 'content_length', 'value_type', 'regex')

    def validate(self, attrs):
        if attrs.get('username', None) :
            if regex_default_name.match(attrs.get('username', None)) is None:
                raise serializers.ValidationError({"username":[_("This field is invalied.")]})

        if attrs.get('password', None) :
            if regex_default_password.match(attrs.get('password', None)) is None:
                raise serializers.ValidationError({"password":[_("This field is invalied.")]})

        if attrs.get('filepath', None) :
            if regex_path.match(attrs.get('filepath', None)) is None:
                raise serializers.ValidationError({"filepath":[_("This field is invalied.")]})

        return attrs

class ProbeRtmpSerializer(ProbeSerializer):
    port = serializers.IntegerField(validators=[MaxValueValidator(65535)], required=False)
    app = serializers.CharField(validators=[RegexValidator(rtmp_app_rex)], required=False)
    flashver = serializers.CharField(validators=[RegexValidator(rtmp_flashver_rex)], required=False)
    stream = serializers.CharField(validators=[RegexValidator(rtmp_stream_name_rex)], required=False)

    class Meta:
        model = ProbeConfigStandaloneRTMP
        fields = ('probeconfig_id', 'name', 'description', 'interval', 'ttl_factor', 'threshold', 'report', 'report_other', 'log', 'timeout', 'try_count', 'scaling', 'timespan', 'ratio_base', 'step_func', 'date_created', 'date_modified', 'probe_type', 'probe_type_name', 'use_clb', 'customer_set', 'alert_message', \
                  'port', 'encrypted', 'verify_server', 'app', 'tcurl', 'flashver', 'stream', 'value_type')

    def validate(self, attrs):
        if attrs.get('app', None) :
            if regex_rtmp_app.match(attrs.get('app', None)) is None:
                raise serializers.ValidationError({"app":[_("This field is invalied.")]})

        if attrs.get('flashver', None) :
            if regex_rtmp_flashver.match(attrs.get('flashver', None)) is None:
                raise serializers.ValidationError({"flashver":[_("This field is invalied.")]})

        if attrs.get('stream', None) :
            if regex_rtmp_stream_name.match(attrs.get('stream', None)) is None:
                raise serializers.ValidationError({"stream":[_("This field is invalied.")]})

        return attrs

class ProbeDnsSerializer(ProbeSerializer):
    domain = serializers.CharField(validators=[RegexValidator(gslb_domain_rex)], required=False)
    dns_class = serializers.IntegerField(validators=[MaxValueValidator(65535)], required=False)
    dns_type = serializers.IntegerField(validators=[MaxValueValidator(65535)], required=False)
    port = serializers.IntegerField(validators=[MaxValueValidator(65535)], required=False)
    response_code = serializers.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(15)], required=False)

    class Meta:
        model = ProbeConfigStandaloneDNS
        fields = ('probeconfig_id', 'name', 'description', 'interval', 'ttl_factor', 'threshold', 'report', 'report_other', 'log', 'timeout', 'try_count', 'scaling', 'timespan', 'ratio_base', 'step_func', 'date_created', 'date_modified', 'probe_type', 'probe_type_name', 'use_clb', 'customer_set', 'alert_message', \
                  'domain', 'dns_class', 'dns_type', 'port', 'value_type', 'response_code')

    def validate(self, attrs):
        if attrs.get('domain', None) :
            if regex_gslb_domain.match(attrs.get('domain', None)) is None:
                raise serializers.ValidationError({"domain":[_("This field is invalied.")]})

        return attrs

class ProbeAggregateProbesSerializer(serializers.ModelSerializer):
    probe_name = serializers.RelatedField(source='probe.name', read_only=True)
    vip_full_name = serializers.Field(source='vip.get_fullvipname')
    vip_ip = serializers.RelatedField(source='vip', read_only=True)

    weight = serializers.FloatField(validators=[MinValueValidator(0), MaxValueValidator(4294967295)], required=False)

    class Meta:
        model = ProbeConfigAggregateProbe
        fields = ('probeconfigaggregateprobe_id',
                  'probe',
                 'probe_name',
                'weight',
                'vip',
                'vip_full_name',
                'vip_ip'
                )

    def get_identity(self, data):
        try:
            return data.get('probeconfigaggregateprobe_id', None)
        except AttributeError:
            return None

class ProbeAggregateSerializer(ProbeSerializer):
    probes = ProbeAggregateProbesSerializer(many=True, required=False, read_only=False, source="probeconfigaggregateprobe_set", allow_add_remove=True)

    class Meta:
        model = ProbeConfigAggregate
        fields = ('probeconfig_id', 'name', 'description', 'interval', 'ttl_factor', 'threshold', 'report', 'report_other', 'log', 'timeout', 'scaling', 'timespan', 'ratio_base', 'step_func', 'date_created', 'date_modified', 'probe_type', 'probe_type_name', 'use_clb', 'customer_set', 'alert_message', \
                  'aggregate_type', 'probes')

class ProbeVipSerializer(serializers.ModelSerializer):
    vip_full_name = serializers.Field('vip.get_fullvipname')
    vip_ip = serializers.RelatedField(source='vip', read_only=True)

    class Meta:
        model = VipProbeConfigs
        fields = ('vip', 'vip_full_name', 'vip_ip')

    def get_identity(self, data):
        try:
            return data.get('probeconfig_id', None)
        except AttributeError:
            return None

class ProbeDomainSerializer(serializers.ModelSerializer):
    class Meta:
        model = Domain
        fields = ('domain_id', 'name')

    def get_identity(self, data):
        try:
            return data.get('probeconfig_id', None)
        except AttributeError:
            return None

class ProbeRelatedAggregateSerializer(ProbeSerializer):
    probeconfig_id = serializers.RelatedField(source='probeconfigaggregate_fk.pk', read_only=True)
    name = serializers.RelatedField(source='probeconfigaggregate_fk', read_only=True)

    class Meta:
        model = ProbeConfigAggregateProbe
        fields = ('probeconfig_id', 'name')

    def get_identity(self, data):
        try:
            return data.get('probeconfig_id', None)
        except AttributeError:
            return None

class ProbeDeletableSerializer(serializers.ModelSerializer):
    is_deletable = serializers.Field('is_deletable')

    class Meta:
        model = BaseProbeConfig
        fields = ('probeconfig_id', 'is_deletable')

    def get_identity(self, data):
        try:
            return data.get('probeconfig_id', None)
        except AttributeError:
            return None

class ProbeDomainVipSerializer(serializers.ModelSerializer):
    domain_vip_name = serializers.SerializerMethodField("get_domain_vip_name")

    class Meta:
        model = DomainVip
        fields = ('domain_vip_id', 'domain_vip_name', 'domain')

    def get_identity(self, data):
        try:
            return data.get('probeconfig_id', None)
        except AttributeError:
            return None

    def get_domain_vip_name(self, data):
        try:
            return "%s" % data
        except AttributeError:
            return None

class ProbeDomainEdgeSerializer(serializers.ModelSerializer):
    domain_edge_name = serializers.SerializerMethodField("get_domain_edge_name")

    class Meta:
        model = DomainEdge
        fields = ('domain_edge_id', 'domain_edge_name', 'domain')

    def get_identity(self, data):
        try:
            return data.get('probeconfig_id', None)
        except AttributeError:
            return None

    def get_domain_edge_name(self, data):
        try:
            return "%s" % data
        except AttributeError:
            return None
