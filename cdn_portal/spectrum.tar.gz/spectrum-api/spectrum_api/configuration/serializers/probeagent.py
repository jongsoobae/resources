# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Rest API
"""
from rest_framework import serializers
from spectrum_api.configuration.models.base import Pop, PopProbeAgentConfig, PopPacketlossProbeAgentConfig
from spectrum_api.configuration.models.probeagent import ProbeAgent
from django.utils.translation import ugettext as _

from django.core.validators import MaxValueValidator, MinValueValidator, RegexValidator
from spectrum_api.shared_components.utils.regex import path_rex, regex_path

class VipListingField(serializers.RelatedField):
    def to_native(self, value):
        return { "full_vip_name" : value.full_vip_name, "vip" : value.vip, "ip" : value.ip}

class ProbeagentSerializer(serializers.ModelSerializer):
    vips = VipListingField(source="vip")

    rtt_delay = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000)], required=False)
    rtt_timeout = serializers.FloatField(validators=[MinValueValidator(1), MaxValueValidator(4294967295)], required=False)
    rtt_cache_ttl = serializers.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(4294967295)], required=False)
    rtt_max_cache_records = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(4294967295)], required=False)
    rtt_trace_udp_port = serializers.IntegerField(validators=[MaxValueValidator(65535)], required=False)
    rtt_trace_max_hops = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(128)], required=False)
    rtt_trace_min_hops = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(128)], required=False)
    rtt_trace_max_linear_hops = serializers.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(255)], required=False)
    rtt_echo_pktlen = serializers.IntegerField(validators=[MinValueValidator(8), MaxValueValidator(65515)], required=False)
    rtt_max_ping_rounds = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(4294967295)], required=False)
    rtt_dns_udp_port = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(65535)], required=False)
    rtt_dns_tcp_port = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(65535)], required=False)
    rtt_max_tcp_probes = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(4294967295)], required=False)
    rtt_max_tcp_pending = serializers.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(65536)], required=False)
    pktloss_port = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(65536)], required=False)
    pktloss_interval = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(4294967295)], required=False)
    pktloss_timeout = serializers.FloatField(validators=[MinValueValidator(1), MaxValueValidator(4294967295)], required=False)
    pktloss_delay = serializers.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(1000)], required=False)
    pktloss_packet_length = serializers.IntegerField(validators=[MinValueValidator(8), MaxValueValidator(65507)], required=False)
    pktloss_packet_count = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000)], required=False)
    icmp_delay = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000)], required=False)
    icmp_max_probes = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000)], required=False)
    icmp_echo_pktlen = serializers.IntegerField(validators=[MinValueValidator(8), MaxValueValidator(65515)], required=False)
    snmp_delay = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000)], required=False)
    snmp_max_probes = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000)], required=False)
    tcp_delay = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000)], required=False)
    tcp_max_probes = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000)], required=False)
    ssl_delay = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000)], required=False)
    ssl_max_probes = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000)], required=False)
    ssl_ca_path = serializers.CharField(validators=[RegexValidator(path_rex)], required=False)
    udp_delay = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000)], required=False)
    udp_max_probes = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000)], required=False)
    ftp_delay = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000)], required=False)
    ftp_max_probes = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000)], required=False)
    rtmp_delay = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000)], required=False)
    rtmp_max_probes = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000)], required=False)
    dns_delay = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000)], required=False)
    dns_max_probes = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000)], required=False)
    debug_port = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(65535)], required=False)
    debug_timeout = serializers.FloatField(validators=[MinValueValidator(1), MaxValueValidator(4294967295)], required=False)
    log_rotate_interval = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(4294967295)], required=False)
    report_log_rotate_interval = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(4294967295)], required=False)
    rtt_log_rotate_interval = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(4294967295)], required=False)
    pop2pop_log_rotate_interval = serializers.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(4294967295)], required=False)
    reporting_protocol = serializers.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(1)], required=False)

    class Meta:
        model = ProbeAgent
        fields = ('probeagent_id', 'rtt_delay', 'rtt_timeout', 'rtt_cache_ttl', 'rtt_max_cache_records', 'rtt_echo_pktlen', 'rtt_max_ping_rounds', \
                  'rtt_dns_udp_port', 'rtt_dns_tcp_port', 'rtt_max_tcp_probes', 'rtt_max_tcp_pending', 'rtt_trace_udp_port', 'rtt_trace_max_hops', \
                  'rtt_trace_min_hops', 'rtt_trace_max_linear_hops', 'pktloss_port', 'pktloss_interval', 'pktloss_timeout', 'pktloss_delay', \
                  'pktloss_packet_length', 'pktloss_packet_count', 'icmp_delay', 'icmp_max_probes', 'icmp_echo_pktlen', 'snmp_delay', 'snmp_max_probes', \
                  'tcp_delay', 'tcp_max_probes', 'ssl_delay', 'ssl_max_probes', 'ssl_ca_path', 'udp_delay', 'udp_max_probes', 'ftp_delay', \
                  'ftp_max_probes', 'rtmp_delay', 'rtmp_max_probes', 'dns_delay', 'dns_max_probes', 'debug_port', 'debug_timeout', 'log_rotate_interval', \
                  'report_log_rotate_interval', 'rtt_log_rotate_interval', 'pop2pop_log_rotate_interval', 'reporting_protocol', 'date_created', 'date_modified', 'vip', 'vips')
        depth = 0

    def get_identity(self, data):
        try:
            return data.get('probeagent_id', None)
        except AttributeError:
            return None

    def validate(self, attrs):
        if attrs.get('vip', None) == None:
            raise serializers.ValidationError({'vip':[_('Vip field is required.')]})

        if attrs.get('rtt_trace_min_hops', None):
            if not attrs.get('rtt_trace_max_hops', None):
                raise serializers.ValidationError({'rtt_trace_max_hops':[_('Input the "rtt trace max hops" value.')]})

        if attrs.get('rtt_trace_max_hops', None):
            if not attrs.get('rtt_trace_min_hops', None):
                raise serializers.ValidationError({'rtt_trace_min_hops':[_('Input the "rtt trace min hops" value.')]})

        if attrs.get('rtt_trace_min_hops', None) > attrs.get('rtt_trace_max_hops', None):
            raise serializers.ValidationError({'rtt_trace_min_hops':[_('Cannot exceed the "rtt trace max hops" value.')]})

        if attrs.get('ssl_ca_path', None):
            if regex_path.match(attrs.get('ssl_ca_path', None)) is None:
                raise serializers.ValidationError({'ssl_ca_path':[_("This field is invalied.")]})

        return attrs

class ProbeagentNameSerializer(serializers.ModelSerializer):
    vips = VipListingField(source="vip")

    class Meta:
        model = ProbeAgent
        fields = ('probeagent_id', 'vip', 'vips')
        depth = 0

    def get_identity(self, data):
        try:
            return data.get('probeagent_id', None)
        except AttributeError:
            return None

class GlobalProbeagentSerializer(serializers.ModelSerializer):

    class Meta:
        model = ProbeAgent
        fields = ('probeagent_id', 'reporting_protocol', 'rtt_delay', 'rtt_timeout', 'rtt_cache_ttl', 'rtt_max_cache_records', 'rtt_echo_pktlen', 'rtt_max_ping_rounds', 'rtt_dns_udp_port', 'rtt_dns_tcp_port', 'rtt_max_tcp_probes', 'rtt_max_tcp_pending', 'rtt_trace_udp_port', 'rtt_trace_max_hops', 'rtt_trace_min_hops', 'rtt_trace_max_linear_hops', 'pktloss_port', 'pktloss_interval', 'pktloss_timeout', 'pktloss_delay', 'pktloss_packet_length', 'pktloss_packet_count', 'icmp_delay', 'icmp_max_probes', 'icmp_echo_pktlen', 'snmp_delay', 'snmp_max_probes', 'tcp_delay', 'tcp_max_probes', 'ssl_delay', 'ssl_max_probes', 'ssl_ca_path', 'udp_delay', 'udp_max_probes', 'ftp_delay', 'ftp_max_probes', 'rtmp_delay', 'rtmp_max_probes', 'dns_delay', 'dns_max_probes', 'debug_port', 'debug_timeout', 'log_rotate_interval', 'report_log_rotate_interval', 'rtt_log_rotate_interval', 'pop2pop_log_rotate_interval', 'date_created', 'date_modified')

    def get_identity(self, data):
        try:
            return data.get('probeagent_id', None)
        except AttributeError:
            return None

    def transform_reporting_protocol(self, obj, data):
        try:
            if obj.reporting_protocol == 0:
                return 'UDP'
            elif obj.reporting_protocol == 1:
                return 'TCP'
            else:
                return ''
        except:
            return None

class PopListingField(serializers.RelatedField):
    def to_native(self, value):
        return { "pop" : value.pop, "pop_name" : value.get_popname()}

class ProbeagentPopsSerializer(serializers.ModelSerializer):
    pop = PopListingField()

    class Meta:
        model = PopProbeAgentConfig
        fields = ('popprobeagentconfig_id', 'primary', 'pop')

    def get_identity(self, data):
        try:
            return data.get('probeagent_id', None)
        except AttributeError:
            return None

class RttserverPopsSerializer(serializers.ModelSerializer):
    pop_name = serializers.Field('get_popname')
    class Meta:
        model = Pop
        fields = ('pop', 'pop_name')

    def get_identity(self, data):
        try:
            return data.get('pop', None)
        except AttributeError:
            return None

class PacketlossPopsSerializer(serializers.ModelSerializer):
    pop = PopListingField()

    class Meta:
        model = PopPacketlossProbeAgentConfig
        fields = ('poppacketloss_probeagentconfig_id', 'pop')

    def get_identity(self, data):
        try:
            return data.get('poppacketloss_probeagentconfig_id', None)
        except AttributeError:
            return None

class ProbeagentDeletableSerializer(serializers.ModelSerializer):
    is_deletable = serializers.Field('is_deletable')

    class Meta:
        model = ProbeAgent
        fields = ('probeagent_id', 'is_deletable')

    def get_identity(self, data):
        try:
            return data.get('probeagent_id', None)
        except AttributeError:
            return None
