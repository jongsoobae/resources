import os
import json
from random import randint, choice
from socket import inet_ntoa
from struct import pack
from string import ascii_uppercase, digits
if 'DJANGO_SETTINGS_MODULE' not in os.environ or os.environ['DJANGO_SETTINGS_MODULE'] is None:
    os.environ['DJANGO_SETTINGS_MODULE'] = 'spectrum_api.settings'
from django.contrib.auth.models import User
from rest_framework.test import APIClient


import unittest2 as unittest

class TestBaseInfo(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = APIClient()
        user = User.objects.get(username='jungho.park')
        cls.client.force_authenticate(user=user)

    def setUp(self):
        self.random_length = randint(10, 20)

    def test_create_pop(self):
        """
            Pop Create *************************************************************************************************************
        """
        pop_create_name = 'P' + str(randint(0, 1000)) + '-' + ''.join(choice(ascii_uppercase + digits) for _ in range(self.random_length)) + 'UNITTEST'
        pop_create_params = {
            "pop_name": pop_create_name,
            "description": "created by acceptance unittest",
            "enable_gslb": 1,
            "cost": 49200,
            "enable_cname_latency": 0,
            "pktloss_threshold": 90,
            "rttserver": 34,
            "rttserver_info": {
                "NIC": "174.35.32.102",
                "probeagentvip": "i0-h0-s0.P0-ATL(174.35.32.102)",
                "hostname": "h0-s0.P0-ATL",
                "host_id": "7454",
                "probeagent": "34"
            },
            "pktlossserver": [
                37,
                55
            ],
            "pktlossserver_info": [
                {
                    "NIC": "119.31.255.76",
                    "probeagentvip": "i0-h0-s0.P0-BOM(119.31.255.76)",
                    "hostname": "h0-s0.P0-BOM",
                    "host_id": "7471",
                    "probeagent": "37"
                },
                {
                    "NIC": "87.118.248.11",
                    "probeagentvip": "i0-h0-s0.P0-MOW(87.118.248.11)",
                    "hostname": "h0-s0.P0-MOW",
                    "host_id": "7588",
                    "probeagent": "55"
                }
            ],
            "probeagent": [
                {
                    "probeagent": 4,
                    "primary": True,
                    "NIC": "37.29.0.164",
                    "probeagentvip": "i0-h0-s1001.v0-rov(37.29.0.164)",
                    "hostname": "h0-s1001.v0-rov",
                    "host_id": 8288
                },
                {
                    "probeagent": 5,
                    "primary": False,
                    "NIC": "37.29.0.167",
                    "probeagentvip": "i0-h0-s0.v0-rov(37.29.0.167)",
                    "hostname": "h0-s0.v0-rov",
                    "host_id": 8286
                },
                {
                    "probeagent": 6,
                    "primary": False,
                    "NIC": "46.232.206.162",
                    "probeagentvip": "i0-h0-s0.V0-CEK(46.232.206.162)",
                    "hostname": "h0-s0.V0-CEK",
                    "host_id": 8291
                }
            ],
            "popgroup": [
                4,
                9,
                10
            ],
            "popgroup_info": [
                {
                    "popgroup_id": 4,
                    "name": "pop-India"
                },
                {
                    "popgroup_id": 9,
                    "name": "pop-kr-customer"
                },
                {
                    "popgroup_id": 10,
                    "name": "pop-cn-customer"
                }
            ],
            "uplinkprobe": [
                {
                    "pop_uplink_probe_id": 3,
                    "probe": 41,
                    "vip": 63318,
                    "vip_full_name": "i1-h0-s0.C000000010410001-ICN (125.209.222.72)"
                },
                {
                    "pop_uplink_probe_id": 4,
                    "probe": 36,
                    "vip": 63319,
                    "vip_full_name": "i2-h0-s0.C000000010410001-ICN (125.209.238.170)"
                }
            ],
            "customerpop": [
                {
                    "id": 83,
                    "customer": 750,
                    "use_type": 1,
                    "probe_agent_selection_type": 0
                }
            ]
        }

        response = self.client.post('/api/pops/', pop_create_params, format='json')
        test_data = json.loads(response.content)
        self.assertTrue(int(response.status_code) == 201)
        self.assertNotEqual(None, test_data['pop'])

        pop_id = test_data['pop']

        response = self.client.get('/api/pops/%d/' % pop_id, {}, format='json')
        test_data = json.loads(response.content)
        self.assertTrue(int(response.status_code) == 200)
        self.assertNotEqual(None, test_data['pop'])

        response = self.client.patch('/api/pops/%d/' % pop_id, test_data, format='json')
        test_data = json.loads(response.content)
        self.assertTrue(int(response.status_code) == 200)
        self.assertNotEqual(None, test_data['pop'])

        """
            System Create *************************************************************************************************************
        """
        system_create_name = 's' + str(randint(10000, 60000))
        system_create_params = {
            "system_name": system_create_name,
            "pop": pop_id,
            "description": "created by acceptance unittest",
            "enable_gslb": 0,
            "is_deletable": 1
        }

        response = self.client.post('/api/pops/%d/systems/' % pop_id, system_create_params, format='json')
        test_data = json.loads(response.content)
        self.assertTrue(int(response.status_code) == 201)
        self.assertNotEqual(None, test_data['system'])
        system_id = test_data['system']

        response = self.client.get('/api/pops/%d/systems/%d/' % (pop_id, system_id), test_data, format='json')
        test_data = json.loads(response.content)
        self.assertTrue(int(response.status_code) == 200)
        self.assertNotEqual(None, test_data['system'])

        response = self.client.patch('/api/pops/%d/systems/%d/' % (pop_id, system_id), test_data, format='json')
        test_data = json.loads(response.content)
        self.assertTrue(int(response.status_code) == 200)
        self.assertNotEqual(None, test_data['system'])

        """
            Host Create *************************************************************************************************************
        """
        host_create_name = 'h' + str(randint(10000, 60000))
        host_create_params = {
            "system": system_id,
            "host_name": host_create_name,
            "role": [
                {
                    "hostrole_id": 0,
                    "role": 14
                },
                {
                    "hostrole_id": 0,
                    "role": 26
                },
                {
                    "hostrole_id": 0,
                    "role": 40
                }
            ],
            "description": "created by acceptance unittest",
            "enable_gslb": 1
        }

        response = self.client.post('/api/pops/%d/systems/%d/hosts/' % (pop_id, system_id), host_create_params, format='json')
        test_data = json.loads(response.content)
        self.assertTrue(int(response.status_code) == 201)
        self.assertNotEqual(None, test_data['host'])
        host_id = test_data['host']

        response = self.client.get('/api/pops/%d/systems/%d/hosts/%d/' % (pop_id, system_id, host_id), test_data, format='json')
        test_data = json.loads(response.content)
        self.assertTrue(int(response.status_code) == 200)
        self.assertNotEqual(None, test_data['host'])

        response = self.client.patch('/api/pops/%d/systems/%d/hosts/%d/' % (pop_id, system_id, host_id), test_data, format='json')
        test_data = json.loads(response.content)
        self.assertTrue(int(response.status_code) == 200)
        self.assertNotEqual(None, test_data['host'])

        """
            Vip Create *************************************************************************************************************
        """
        vip_create_name = 'i' + str(randint(10000, 60000))
        vip_create_ip_address = inet_ntoa(pack('>I', randint(1, 0xffffffff)))
        vip_create_params = {
            "host": host_id,
            "vip_name": vip_create_name,
            "vip_addr": vip_create_ip_address,
            "mproxy_shield": True,
            "mproxy_outgoing_ip": True,
            "probeconfig": [
                {
                    "vip_probe_id": 0,
                    "probe": 1000119,
                    "probe_name": "active_directory_health",
                    "probe_type": "AGGREGATE",
                    "threshold": 30,
                    "timeout": 60,
                    "step_func": "test"
                },
                {
                    "vip_probe_id": 0,
                    "probe": 1000195,
                    "probe_name": "arena_tcp_51",
                    "probe_type": "TCP",
                    "threshold": None,
                    "timeout": None,
                    "step_func": None
                }
            ],
            "edge": [],
            "description": "created by accceptance test",
            "enable_gslb": 0,
        }

        response = self.client.post('/api/pops/%d/systems/%d/hosts/%d/vips/' % (pop_id, system_id, host_id), vip_create_params, format='json')
        test_data = json.loads(response.content)
        self.assertNotEqual(None, test_data['vip'])
        self.assertTrue(int(response.status_code) == 201)
        vip_id = test_data['vip']

        response = self.client.get('/api/pops/%d/systems/%d/hosts/%d/vips/%d/' % (pop_id, system_id, host_id, vip_id), test_data, format='json')
        test_data = json.loads(response.content)
        self.assertTrue(int(response.status_code) == 200)
        self.assertNotEqual(None, test_data['vip'])

        response = self.client.patch('/api/pops/%d/systems/%d/hosts/%d/vips/%d/' % (pop_id, system_id, host_id, vip_id), test_data, format='json')
        test_data = json.loads(response.content)
        self.assertTrue(int(response.status_code) == 200)
        self.assertNotEqual(None, test_data['vip'])

        """
            Base Object Delete *************************************************************************************************************
        """

        response = self.client.delete('/api/pops/%d/systems/%d/hosts/%d/vips/%d/' % (pop_id, system_id, host_id, vip_id), {}, format='json')
        self.assertTrue(int(response.status_code) == 204)
        self.assertTrue(response.content == '')

        response = self.client.delete('/api/pops/%d/systems/%d/hosts/%d/' % (pop_id, system_id, host_id), {}, format='json')
        self.assertTrue(int(response.status_code) == 204)
        self.assertTrue(response.content == '')

        response = self.client.delete('/api/pops/%d/systems/%d/' % (pop_id, system_id), {}, format='json')
        self.assertTrue(int(response.status_code) == 204)
        self.assertTrue(response.content == '')

        response = self.client.delete('/api/pops/%d/' % (pop_id), {}, format='json')
        self.assertTrue(int(response.status_code) == 204)
        self.assertTrue(response.content == '')

if __name__ == "__main__":
    unittest.main()

