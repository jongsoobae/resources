# -*- coding: utf-8 -*-

from django.conf.urls.defaults import patterns, url
from rest_framework.urlpatterns import format_suffix_patterns

from spectrum_api.configuration.views.base import SystemDetailAPI, SystemAPI, StatusUpdate, PopGroupsAPI, RoleAPI, PopLocationAPI, \
                                                PopDetailAPI, RelatedEdgesAPI, RelatedDomainsAPI, ConfigDistActionHistoryAPI, \
                                                RelatedHostAPI, PopAPI, BasePopAPI, IhmsIdcAPI, CustomerDisplayAPI, \
                                                HostAPI, HostDetailAPI, VipDetailAPI, VipAPI, RelatedVipAPI, RelatedSystemAPI, \
                                                RoleDetailAPI, BaseInfoAPI, PopRelatedItemAPI, SystemRelatedItemAPI, \
                                                CLBPopListAPI, HostRelatedItemAPI, VipRelatedItemAPI, CLBSetPrimary, PopRestore, \
                                                BaseObjectStatus, HostBulkAPI, HostRoleAPI
from spectrum_api.configuration.views.clb import CLBAlertManagementBaseAPI, \
                                                CLBAlertGroupAPI, \
                                                CLBAlertRecipientsAPI, \
                                                CLBAlertGroupDetailAPI, \
                                                CLBAlertRecipientsDetailAPI, \
                                                CLBStatMasterAPI, \
                                                GMTCDAPI, \
                                                CLBAlertDomainStatusAPI, \
                                                CLBAlertDomainFailHistoryAPI, \
                                                CLBAlertVipFailHistoryAPI, \
                                                CLBAlertDomainSnapshotAPI, \
                                                CLBAlertGroupHasDomainAPI, \
                                                BaseCLBAlertGroupAPI
from spectrum_api.configuration.views.config import ConfigGroupAPI, ConfigGroupDetailAPI, ConfigGroupProductAPI, ConfigTypeAPI, ConfigPhaseAPI, ConfigJointAPI, \
                                                ConfigPushAPI, ConfigPushStateAPI,ConfigActionPromotedAPI
from spectrum_api.configuration.views.edge import EdgeAPI, EdgeDetailAPI, EdgeRelatedAPI
from spectrum_api.configuration.views.probe import ProbeAPI, ProbeIcmpAPI, ProbeIcmpDetailAPI, ProbeSnmpAPI, ProbeSnmpDetailAPI, ProbeTcpAPI, ProbeTcpDetailAPI, \
    ProbeSslAPI, ProbeSslDetailAPI, ProbeUdpAPI, ProbeUdpDetailAPI, ProbeFtpAPI, ProbeFtpDetailAPI, ProbeRtmpAPI, ProbeRtmpDetailAPI, ProbeDnsAPI, ProbeDnsDetailAPI, \
    ProbeAggregateAPI, ProbeAggregateDetailAPI, ProbeTypeAPI, ProbeVipsAPI, ProbeDomainsAPI, ProbeDeletableAPI, ProbeNameAPI, ProbeRelatedAggregateAPI, \
    ProbeDomainVipAPI, ProbeDomainEdgeAPI, ProbeRelatedItemAPI
from spectrum_api.configuration.views.probeagent import ProbeagentAPI, ProbeagentDetailAPI, GlobalProbeagentDetailAPI, ProbeagentPopsAPI, RttserverPopsAPI, PacketlossPopsAPI, \
    ProbeagentDeletableAPI, ProbeagentNameAPI, ProbeagentRelatedItemAPI, AutoProbePopsAPI
from spectrum_api.configuration.views.preset_relay import PresetListAPI, \
    PresetRelayAddAPI, PresetRelayInfoAPI, PresetRelatedItemAPI, PresetRelayListAPI, PresetRelayDetailAPI


restfw_api_urlpatterns = patterns('spectrum_api.configuration.views',
    url(r'^edges/$', EdgeAPI.as_view(), name="edges"),
    url(r'^edges/(?P<edge_id>[0-9]+)/$', EdgeDetailAPI.as_view(), name="edge-detail"),
    url(r'^edges/(?P<edge_id>[0-9]+)/related/$', EdgeRelatedAPI.as_view(), name="edge-related"),
    url(r'^probeagents/$', ProbeagentAPI.as_view(), name="probeagents"),
    url(r'^probeagents/(?P<probeagent_id>[0-9]+)/$', ProbeagentDetailAPI.as_view(), name="probeagent-detail"),
    url(r'^probeagents/global/$', GlobalProbeagentDetailAPI.as_view(), name="globalProbeagent-detail"),
    url(r'^probeagents/(?P<probeagent_id>[0-9]+)/pops/$', ProbeagentPopsAPI.as_view(), name="probeagentPops"),
    url(r'^rttservers/(?P<probeagent_id>[0-9]+)/pops/$', RttserverPopsAPI.as_view(), name="rttserverPops"),
    url(r'^packetloss/(?P<probeagent_id>[0-9]+)/pops/$', PacketlossPopsAPI.as_view(), name="packetlossPops"),
    url(r'^probeagents/(?P<probeagent_id>[0-9]+)/deletable/$', ProbeagentDeletableAPI.as_view(), name="probeagent-deletable"),
    url(r'^probeagentname/$', ProbeagentNameAPI.as_view(), name="probeagent-name"),
    url(r'^probeagents/(?P<probeagent_id>[0-9]+)/related_objects/$', ProbeagentRelatedItemAPI.as_view(), name="probeagent-related-object"),
    url(r'^probeagents/(?P<probeagent_id>[0-9]+)/autoprobe_pops/$', AutoProbePopsAPI.as_view(), name="probeagentAutoProbePops"),

    url(r'^probes/$', ProbeAPI.as_view(), name="probes"),
    url(r'^probename/$', ProbeNameAPI.as_view(), name="probe-name"),
    url(r'^probes/icmp/$', ProbeIcmpAPI.as_view(), name="probesICMP"),
    url(r'^probes/icmp/(?P<probeconfig_id>[0-9]+)/$', ProbeIcmpDetailAPI.as_view(), name="probesICMP-detail"),
    url(r'^probes/snmp/$', ProbeSnmpAPI.as_view(), name="probesSNMP"),
    url(r'^probes/snmp/(?P<probeconfig_id>[0-9]+)/$', ProbeSnmpDetailAPI.as_view(), name="probesSNMP-detail"),
    url(r'^probes/tcp/$', ProbeTcpAPI.as_view(), name="probesTCP"),
    url(r'^probes/tcp/(?P<probeconfig_id>[0-9]+)/$', ProbeTcpDetailAPI.as_view(), name="probesTCP-detail"),
    url(r'^probes/ssl/$', ProbeSslAPI.as_view(), name="probesSNMP"),
    url(r'^probes/ssl/(?P<probeconfig_id>[0-9]+)/$', ProbeSslDetailAPI.as_view(), name="probesSSL-detail"),
    url(r'^probes/udp/$', ProbeUdpAPI.as_view(), name="probesUDP"),
    url(r'^probes/udp/(?P<probeconfig_id>[0-9]+)/$', ProbeUdpDetailAPI.as_view(), name="probesUDP-detail"),
    url(r'^probes/ftp/$', ProbeFtpAPI.as_view(), name="probesFTP"),
    url(r'^probes/ftp/(?P<probeconfig_id>[0-9]+)/$', ProbeFtpDetailAPI.as_view(), name="probesFTP-detail"),
    url(r'^probes/rtmp/$', ProbeRtmpAPI.as_view(), name="probesRTMP"),
    url(r'^probes/rtmp/(?P<probeconfig_id>[0-9]+)/$', ProbeRtmpDetailAPI.as_view(), name="probesRTMP-detail"),
    url(r'^probes/dns/$', ProbeDnsAPI.as_view(), name="probesDNS"),
    url(r'^probes/dns/(?P<probeconfig_id>[0-9]+)/$', ProbeDnsDetailAPI.as_view(), name="probesDNS-detail"),
    url(r'^probes/aggregate/$', ProbeAggregateAPI.as_view(), name="probesAggregate"),
    url(r'^probes/aggregate/(?P<probeconfig_id>[0-9]+)/$', ProbeAggregateDetailAPI.as_view(), name="probesAggregate-detail"),
    url(r'^probes/types/$', ProbeTypeAPI.as_view(), name="probeType"),
    url(r'^probes/(?P<probeconfig_id>[0-9]+)/vips/$', ProbeVipsAPI.as_view(), name="probeVips"),
    url(r'^probes/(?P<probeconfig_id>[0-9]+)/domains/$', ProbeDomainsAPI.as_view(), name="probeDomains"),
    url(r'^probes/(?P<probeconfig_id>[0-9]+)/relatedaggregates/$', ProbeRelatedAggregateAPI.as_view(), name="related-aggregates"),
    url(r'^probes/(?P<probeconfig_id>[0-9]+)/deletable/$', ProbeDeletableAPI.as_view(), name="probe-deletable"),
    url(r'^probes/(?P<probeconfig_id>[0-9]+)/domainvip/$', ProbeDomainVipAPI.as_view(), name="probeDomainVip"),
    url(r'^probes/(?P<probeconfig_id>[0-9]+)/domainedge/$', ProbeDomainEdgeAPI.as_view(), name="probeDomainEdge"),
    url(r'^probes/(?P<probeconfig_id>[0-9]+)/related_objects/$', ProbeRelatedItemAPI.as_view(), name="probe-related-object"),

    url(r'^pops/$', PopAPI.as_view(), name="pops"),
    url(r'^pops/(?P<pop>[0-9]+)/$', PopDetailAPI.as_view(), name="pop-detail"),
    url(r'^pops/(?P<pop>[0-9]+)/systems/$', SystemAPI.as_view(), name="systems"),
    url(r'^pops/(?P<pop>[0-9]+)/systems/(?P<system>[0-9]+)/$', SystemDetailAPI.as_view(), name="system-detail"),

    url(r'^pops/(?P<pop>[0-9]+)/systems/(?P<system>[0-9]+)/hosts/$', HostAPI.as_view(), name="hosts"),
    url(r'^pops/(?P<pop>[0-9]+)/systems/(?P<system>[0-9]+)/hosts/(?P<host>[0-9]+)/$', HostDetailAPI.as_view(), name="host-detail"),

    url(r'^pops/(?P<pop>[0-9]+)/systems/(?P<system>[0-9]+)/hosts/(?P<host>[0-9]+)/vips/$', VipAPI.as_view(), name="hosts"),
    url(r'^pops/(?P<pop>[0-9]+)/systems/(?P<system>[0-9]+)/hosts/(?P<host>[0-9]+)/vips/(?P<vip>[0-9]+)/$', VipDetailAPI.as_view(), name="host-detail"),

    url(r'^pop/clblist/$', CLBPopListAPI.as_view(), name="clbpoplist"),
    url(r'^probe/setprimary/$', CLBSetPrimary.as_view(), name="clbsetprimary"),

    # Regenerated URLs (Added by kookheon.kwon)
    url(r'^baseconfig/pops/$', PopAPI.as_view(), name="re-pops"),
    url(r'^baseconfig/pops/(?P<pop>[0-9]+)/$', PopDetailAPI.as_view(), name="re-pop-detail"),
    url(r'^baseconfig/pops/(?P<pop>[0-9]+)/systems/$', SystemAPI.as_view(), name="re-systems"),
    url(r'^baseconfig/systems/(?P<system>[0-9]+)/$', SystemDetailAPI.as_view(), name="re-system-detail"),
    url(r'^baseconfig/systems/(?P<system>[0-9]+)/hosts/$', HostAPI.as_view(), name="re-hosts"),
    url(r'^baseconfig/hosts/(?P<host>[0-9]+)/$', HostDetailAPI.as_view(), name="re-host-detail"),
    url(r'^baseconfig/hosts/(?P<host>[0-9]+)/vips/$', VipAPI.as_view(), name="re-vips"),
    url(r'^baseconfig/vips/(?P<vip>[0-9]+)/$', VipDetailAPI.as_view(), name="re-vip-detail"),

    url(r'^popgroups/$', PopGroupsAPI.as_view(), name="pop-groups"),
    url(r'^roles/$', RoleAPI.as_view(), name="roles"),
    url(r'^roles/(?P<role_id>[0-9]+)/$', RoleDetailAPI.as_view(), name="detail-role"),
    url(r'^poplocations/$', PopLocationAPI.as_view(), name="pop-locations"),
    url(r'^ihmsidcs/$', IhmsIdcAPI.as_view(), name="ihms-idcs"),
    url(r'^lite/customers/$', CustomerDisplayAPI.as_view(), name="customerdisplays"),
    url(r'^lite/pops/$', BasePopAPI.as_view(), name="lite-pops"),
    url(r'^lite/clbalertgroups/$', BaseCLBAlertGroupAPI.as_view(), name="lite-alertgroups"),

    url(r'^relatededges/(?P<base_type>[a-zA-Z]+)/(?P<base_id>[0-9]+)/$', RelatedEdgesAPI.as_view(), name="related-edges"),
    url(r'^relateddomains/(?P<base_type>[a-zA-Z]+)/(?P<base_id>[0-9]+)/$', RelatedDomainsAPI.as_view(), name="related-domains"),
    url(r'^relatedhosts/(?P<base_type>[a-zA-Z]+)/(?P<base_id>[0-9]+)/role/(?P<role_id>[0-9]+)/$', RelatedHostAPI.as_view(), name="role-related-hosts"),
    url(r'^relatedhosts/(?P<base_type>[a-zA-Z]+)/(?P<base_id>[0-9]+)/$', RelatedHostAPI.as_view(), name="related-edges"),
    url(r'^relatedvips/(?P<base_type>[a-zA-Z]+)/(?P<base_id>[0-9]+)/$', RelatedVipAPI.as_view(), name="related-vips"),
    url(r'^relatedsystems/(?P<base_type>[a-zA-Z]+)/(?P<base_id>[0-9]+)/$', RelatedSystemAPI.as_view(), name="related-systems"),
    url(r'^relatedsystems/(?P<base_type>[a-zA-Z]+)/$', RelatedSystemAPI.as_view(), name="related-systems"),
    url(r'^configdistactionhistory/(?P<keyword>.+)/$', ConfigDistActionHistoryAPI.as_view(), name="configdistactionhistory"),

    url(r'^status/update/(?P<base_type>[a-zA-Z]+)/$', StatusUpdate.as_view(), name="statusupdate"),
    url(r'^baseobject/status/(?P<base_type>[a-zA-Z]+)/(?P<base_id>[0-9]+)/$', BaseObjectStatus.as_view(), name="baseobjectstatus"),
    url(r'^restore/pop/(?P<base_id>[0-9]+)/$', PopRestore.as_view(), name="poprestore"),

    url(r'^config/groups/$', ConfigGroupAPI.as_view(), name="configGroup"),
    url(r'^config/groups/(?P<config_group_id>[0-9]+)/$', ConfigGroupDetailAPI.as_view(), name="configGroup-detail"),
    url(r'^config/groups/products/$', ConfigGroupProductAPI.as_view(), name="configGroupProduct"),
    url(r'^config/types/$', ConfigTypeAPI.as_view(), name="configType"),
    url(r'^config/phases/$', ConfigPhaseAPI.as_view(), name="configPhase"),
    url(r'^config/jointgroups/$', ConfigJointAPI.as_view(), name="configJoint"),
    url(r'^config/push/$', ConfigPushAPI.as_view(), name="configPush"),
    url(r'^config/promotedactions/$', ConfigActionPromotedAPI.as_view(), name="promoted_actions"),
    url(r'^config/states/$', ConfigPushStateAPI.as_view(), name="configState"),

    url(r'^clb/alertmanagementbase/$', CLBAlertManagementBaseAPI.as_view(), name="clb_management_base"),
    url(r'^clb/alertgroup/$', CLBAlertGroupAPI.as_view(), name="clb_alert_group"),
    url(r'^clb/alertgroup/(?P<alertgroup_id>[0-9]+)/$', CLBAlertGroupDetailAPI.as_view(), name="clb_alert_group_detail"),
    url(r'^clb/alertrecipients/$', CLBAlertRecipientsAPI.as_view(), name="clb_alert_recipients"),
    url(r'^clb/alertrecipients/(?P<recipient_id>[0-9]+)/$', CLBAlertRecipientsDetailAPI.as_view(), name="clb_alert_recipients"),
    url(r'^clb/statmaster/$', CLBStatMasterAPI.as_view(), name="clb_stat_master"),
    url(r'^gmtcd/$', GMTCDAPI.as_view(), name="gmt_cd"),
    url(r'^clb/alertdomainstatus/$', CLBAlertDomainStatusAPI.as_view(), name="clb_alert_domain_status"),
    url(r'^clb/alertdomainfailhistory/$', CLBAlertDomainFailHistoryAPI.as_view(), name="clb_alert_domain_fail_history"),
    url(r'^clb/alertvipfailhistory/$', CLBAlertVipFailHistoryAPI.as_view(), name="clb_alert_vip_fail_history"),
    url(r'^clb/alertdomainsnapshot/$', CLBAlertDomainSnapshotAPI.as_view(), name="clb_alert_domain_snapshot"),
    url(r'^clb/alertgrouphasdomain/(?P<account_no>[0-9]+)/$$', CLBAlertGroupHasDomainAPI.as_view(), name="clbalertgrouphasdomain"),

    url(r'^baseinfo/(?P<base_type>[a-zA-Z]+)/$', BaseInfoAPI.as_view(), name="base-info"),

    url(r'^pops/(?P<pop_id>[0-9]+)/related_objects/$', PopRelatedItemAPI.as_view(), name="pop-related-object"),
    url(r'^systems/(?P<system_id>[0-9]+)/related_objects/$', SystemRelatedItemAPI.as_view(), name="system-related-object"),
    url(r'^hosts/(?P<host_id>[0-9]+)/related_objects/$', HostRelatedItemAPI.as_view(), name="host-related-object"),
    url(r'^hosts/$', HostBulkAPI.as_view(), name="host_list"),
    url(r'^vips/(?P<vip_id>[0-9]+)/related_objects/$', VipRelatedItemAPI.as_view(), name="vip-related-object"),
    url(r'^hostrole/$', HostRoleAPI.as_view(), name="host_role_bulk"),

    # Configuration > Pre-set Relay
    url(r'^preset_relays/presets/$', PresetListAPI.as_view(), name="preset-list"),
    url(r'^preset_relays/presets/add/$', PresetRelayAddAPI.as_view(), name="preset-relay-add"),
    url(r'^preset_relays/presets/(?P<preset_id>[0-9]+)/relays/$', PresetRelayInfoAPI.as_view(), name="preset-relay-info"),
    url(r'^preset_relays/presets/(?P<preset_id>[0-9]+)/related_objects/$', PresetRelatedItemAPI.as_view(), name="preset-related-object"),
    url(r'^preset_relays/$', PresetRelayListAPI.as_view(), name="preset-relay-list"),
    url(r'^preset_relays/(?P<preset_id>[0-9]+)/$', PresetRelayDetailAPI.as_view(), name="preset-relay-detail"),
)
urlpatterns = format_suffix_patterns(restfw_api_urlpatterns)
