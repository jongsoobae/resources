# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Rest API
"""
from django.db import transaction
from django.http import Http404
from django.shortcuts import get_list_or_404
from django.utils.translation import ugettext as _
from rest_framework import mixins, exceptions, generics
from rest_framework.response import Response
from rest_framework.status import HTTP_400_BAD_REQUEST, HTTP_403_FORBIDDEN, HTTP_404_NOT_FOUND
from rest_framework.views import APIView
from rest_framework.exceptions import APIException

from spectrum_api.configuration.models.base import Pop, Host, System, Vip, Edge, HostRole, Role, \
                                            BaseVipEdge, PopGroup, \
                                            PopNameInfo, SystemNameInfo, HostNameInfo, \
                                            PopProbeAgentConfig, PopInfo, VipSearch
from spectrum_api.configuration.models.clb import CustomerContractPop
from spectrum_api.configuration.models.config import ConfigDistAction
from spectrum_api.configuration.models.ihms import IhmsCountry, IhmsIdc
from spectrum_api.configuration.models.probeagent import ProbeAgent
from spectrum_api.configuration.serializers.base import EdgeSerializer, EdgeSimpleSerializer, SystemSerializer, PopGroupSerializer, \
                                            RoleSerializer, PopLocationSerializer, PopSerializer, DomainSerializer, \
                                            ConfigDistActionSerializer, PopHostSerializer, BasePopSerializer, \
                                            IhmsIdcSerializer, CustomerDisplaySerializer, VipSerializer, BaseSystemSerializer, \
                                            CLBPopSerializer, SimpleHostSerializer, LiteSystemSerializer, SimpleHostBulkSerializer,\
                                            HostRoleSerializer
from spectrum_api.configuration.views.config import config_push, ConfigAPIException
from spectrum_api.dna.models.domain import DomainEdge, Domain, DomainVip
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.mixins import CreateModelMixin, UpdateModelMixin, DestroyModelMixin
from spectrum_api.shared_components.models.customer import CustomerDisplay
from rest_framework import status
from django.db.models import Q


class AccessInvalidPopID(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = 'Pop ID Missing'

class PopDoesNotExist(APIException):
    status_code = HTTP_404_NOT_FOUND
    default_detail = _(u'You requested a pop which does not exists')

class AccessInvalidSystemID(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = 'System ID Missing'

class SystemDoesNotExist(APIException):
    status_code = HTTP_404_NOT_FOUND
    default_detail = _(u'You requested a system which does not exists.')

class AccessInvalidHostID(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = 'Host ID Missing'

class HostDoesNotExist(APIException):
    status_code = HTTP_404_NOT_FOUND
    default_detail = _(u'You requested a host which does not exists.')

class AccessInvalidVipID(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = 'Vip ID Missing'

class VipDoesNotExist(APIException):
    status_code = HTTP_404_NOT_FOUND
    default_detail = _(u'You requested a vip which does not exists.')


model_class = {'system':System, 'pop':Pop, 'host':Host, 'vip':Vip, 'edge':Edge}

CONFIG_PUSH_GROUP = 1
CONFIG_PUSH_STATUS = 0
CONFIG_TYPE_ID = 1

class ObjDeleteNotAllowed(exceptions.APIException):
    status_code = HTTP_403_FORBIDDEN
    default_detail = _("You can not delete this pop")

    def __init__(self, *args, **kwargs):
        obj_name = kwargs.pop('obj_name', '')
        except_msg = kwargs.pop('except_msg', None)
        default_detail = "You can not delete this %s" % obj_name
        if except_msg:
            default_detail = "%s, %s" % (default_detail, except_msg)
        self.default_detail = _("%s" % default_detail)
        super(ObjDeleteNotAllowed, self).__init__(*args, **kwargs)



def get_name_info(obj_type, obj_list):
    host_info = {}
    system_info = {}
    pop_info = {}

    from django.db import connections
    if len(obj_list) == 0:
        return (host_info, system_info, pop_info)

    if obj_type == 'host':
        where_str = " where hni.host_id in (%s)" % ','.join(obj_list)
        sql = """
            select
            pni.pop_id, pni.pop_name
            , sni.system_id, sni.system_name
            , hni.host_id, hni.host_name
            from pop_name_info pni
            inner join system_name_info sni on sni.pop_id = pni.pop_id
            inner join host_name_info hni on hni.system_id = sni.system_id
            %s
            """ % where_str
    elif obj_type == 'system':
        where_str = " where sni.system_id in (%s)" % ','.join(obj_list)
        sql = """
            select
            pni.pop_id, pni.pop_name
            , sni.system_id, sni.system_name
            from pop_name_info pni
            inner join system_name_info sni on sni.pop_id = pni.pop_id
            %s
            """ % where_str
    else:
        where_str = " where pni.pop_id in (%s)" % ','.join(obj_list)
        sql = """
            select
            pni.pop_id, pni.pop_name
            from pop_name_info pni
            %s
            """ % where_str

    cursor = connections[ 'default' ].cursor()
    cursor.execute(sql)
    rs = cursor.fetchall()

    for obj in rs:
        if not pop_info.has_key(obj[0]):
            pop_info[obj[0]] = {}
        pop_info[obj[0]] = { 'pop_id' :obj[0], 'pop_name':obj[1]}
        if len(obj) >= 3:
            if not system_info.has_key(obj[2]):
                system_info[obj[2]] = {}
            system_info[obj[2]] = { 'system_id' :obj[2], 'system_name':obj[3]}
        if len(obj) >= 5:
            if not host_info.has_key(obj[4]):
                host_info[obj[4]] = {}
            host_info[obj[4]] = { 'host_id' :obj[4], 'host_name':obj[5]}

    return (host_info, system_info, pop_info)

def get_host_role_info(host_list):
    host_info = {}
    from django.db import connections
    if len(host_list) > 0:
        where_str = " where bhr.host_id in (%s)" % ','.join(host_list)
    else:
        return host_info
    sql = """
            select bhr.host_id, bhr.role_id, br.role_name from base_host_role bhr inner join base_role br on bhr.role_id = br.role_id
            %s
            """ % where_str
    cursor = connections[ 'default' ].cursor()
    cursor.execute(sql)
    rs = cursor.fetchall()

    for obj in rs:
        if not host_info.has_key(obj[0 ]):
            host_info[obj[ 0]] = {}
        host_info[obj[ 0]][obj[ 1]] = { 'role_id' :obj[1 ], 'role_name' :obj[2 ]}

    return host_info



def pop_host_monitoring_count(pop_list):
    pop_info = {}
    from django.db import connections

    if len(pop_list) > 0:
        where_str = " where a.pop_id in (%s)" % ','.join(pop_list)
    else:
        return pop_info
    sql = """
            select a.pop_id,
                    sum(a.enabled),
                    sum(a.disabled),
                    sum(a.failure)
            from (
            select distinct base_system.pop_id, host_status.host_id, host_status.host_status,
                if(host_status.host_status = 1 or host_status.host_status = 3 or host_status.host_status = 7, 1, 0) enabled,
                if(host_status.host_status = -2 or host_status.host_status = 0 or host_status.host_status = 2 or host_status.host_status = 6, 1, 0) disabled,
                if(host_status.host_status = -1, 1, 0) failure
            from prism.host_status host_status
            inner join prism.base_system base_system on host_status.system_id = base_system.system_id
            ) a
            %s
            group by a.pop_id
    """ % where_str
    cursor = connections['default'].cursor()
    cursor.execute(sql)
    rs = cursor.fetchall()

    for obj in rs:
        pop_info[obj[0]] = {'pop_id':obj[0],
                            'enabled':obj[1],
                            'disabled':obj[2],
                            'failure':obj[3],
                            }

    return pop_info



def pop_monitoring_info(pop_list):
    pop_info = {}
    from django.db import connections
    if len(pop_list) > 0:
        where_str = " where pop_id in (%s)" % ','.join(pop_list)
    else:
        return pop_info
    sql = """
            select pop_id, pop_name, enable_gslb, pop_status, is_active,
            is_failure, is_warned, active_count,
            failure_count, warned_count, total_system_count From pop_status
            %s;
    """ % where_str
    cursor = connections['default'].cursor()
    cursor.execute(sql)
    rs = cursor.fetchall()

    for obj in rs:
        pop_info[obj[0]] = {'pop_id':obj[0],
                            'pop_name':obj[1],
                            'enable_gslb':obj[2],
                            'pop_status':obj[3],
                            'is_active':obj[4],
                            'is_failure':obj[5],
                            'is_warned':obj[6],
                            'active_count':obj[7],
                            'failure_count':obj[8],
                            'warned_count':obj[9],
                            'total_system_count':obj[10],
                            }

    return pop_info


def pop_role_info(pop_list, role_list=[]):
    pop_info = {}
    from django.db import connections
    if len(pop_list) > 0 or len(role_list) > 0:
        where_str = ""
        if len(pop_list) > 0:
            where_str = " where bp.pop_id in (%s)" % ','.join(pop_list)
        if len(role_list) > 0:
            if where_str == "":
                where_str = " where bsr.role_id in (%s)" % ','.join(role_list)
            else:
                where_str = +" and bsr.role_id in (%s)" % ','.join(role_list)
    else:
        return pop_info
    sql = """
            select distinct bp.pop_id, bsr.role_id, br.role_name from base_host_role bsr inner join base_host bh on bsr.host_id = bh.host_id
                        inner join base_system bs on bh.system_id = bs.system_id
                        inner join base_pop bp on bs.pop_id = bp.pop_id
                        inner join base_role br on bsr.role_id = br.role_id
                %s
            """ % where_str
    cursor = connections['default'].cursor()
    cursor.execute(sql)
    rs = cursor.fetchall()

    for obj in rs:
        if not pop_info.has_key(obj[0]):
            pop_info[obj[0]] = {}
        pop_info[obj[0]][obj[1]] = {'role_id':obj[1], 'role_name':obj[2]}

    return pop_info

def host_monitoring_info(host_list):
    host_info = {}
    from django.db import connections
    if len(host_list) > 0:
        where_str = " where hs.host_id in (%s)" % ','.join(host_list)
    else:
        return host_info
    sql = """
            select hs.host_id, hs.host_status, hs.active_count, hs.failure_count, hs.total_count from host_status hs
                %s
            """ % where_str
    cursor = connections['default'].cursor()
    cursor.execute(sql)
    rs = cursor.fetchall()

    for obj in rs:
        if not host_info.has_key(obj[0]):
            host_info[obj[0]] = {'host_id':obj[0],
                                 'host_status':obj[1],
                                 'active_count':obj[2],
                                 'failure_count':obj[3],
                                 'total_count':obj[4],
                                 'NIC':'',
                                 'primary':0,
                                 'vip':{}
                                 }
    if len(host_list) > 0:
        where_str = " where bh.host_id in (%s)" % ','.join(host_list)
    else:
        where_str = ""
    sql = """
            select
            bh.host_id,
            bv.vip_id,
            if(isnull(ihms_vip_id), bv.vip_name, iv.vip_name) vip_name,
            if(isnull(ihms_vip_id), bv.vip_addr, inet_ntoa(iv.ip_id)) vip_ip,
            iv.`primary`
            From base_vip `bv` left outer join ihms_vip `iv` on bv.ihms_vip_id = iv.ip_id
            inner join base_host `bh` on bv.host_id = bh.host_id
            left outer join ihms_host `ih` on bh.ihms_host_id = ih.host_id
            inner join base_system `bs` on bh.system_id = bs.system_id
            left outer join ihms_system `is` on bs.ihms_system_id = `is`.system_id
            inner join base_pop `bp` on bs.pop_id = bp.pop_id
            left outer join ihms_pop `ip` on bp.ihms_pop_id = ip.pop_id
            %s
            """ % where_str
    cursor = connections['default'].cursor()
    cursor.execute(sql)
    rs = cursor.fetchall()

    host_primary = {}
    for obj in rs:
        if host_info[obj[0]]['primary'] == 1:
            pass
        else:
            host_info[obj[0]]['primary'] = obj[4]
            if host_info[obj[0]]['primary'] == 1:
                host_primary[obj[0]] = obj[2]
                host_info[obj[0]]['NIC'] = obj[3]
            else:
                if not host_primary.has_key(obj[0]):
                    host_primary[obj[0]] = obj[2]
                    host_info[obj[0]]['NIC'] = obj[3]
                else:
                    if int(host_primary[obj[0]].split('i')[1]) > int(obj[2].split('i')[1]):
                        host_primary[obj[0]] = obj[2]
                        host_info[obj[0]]['NIC'] = obj[3]

        host_info[obj[0]]['vip'][obj[1]] = {'vip_id':obj[1],
                                 'vip_name':obj[2],
                                 'vip_ip':obj[3],
                                 'primary':obj[4]
                                 }
    return host_info

def system_monitoring_info(system_list):
    system_info = {}
    from django.db import connections
    if len(system_list) > 0:
        where_str = " where system_id in (%s)" % ','.join(system_list)
    else:
        return system_info
    sql = """
            select system_id, pop_id, system_status, active_count, total_host_count from system_status
                %s
            """ % where_str
    cursor = connections['default'].cursor()
    cursor.execute(sql)
    rs = cursor.fetchall()

    for obj in rs:
        if not system_info.has_key(obj[0]):
            system_info[obj[0]] = {'system_id':obj[0],
                                 'pop_id':obj[1],
                                 'system_status':obj[2],
                                 'active_count':obj[3],
                                 'total_count':obj[4]
                                 }
    return system_info


def vip_monitoring_info(vip_list):
    vip_info = {}
    from django.db import connections
    if len(vip_list) > 0:
        where_str = " where vip_id in (%s)" % ','.join(vip_list)
    else:
        return vip_info
    sql = """
            select vip_id, host_id, vip_status, active_count, total_count from vip_status
                %s
            """ % where_str
    cursor = connections['default'].cursor()
    cursor.execute(sql)
    rs = cursor.fetchall()

    for obj in rs:
        if not vip_info.has_key(obj[0]):
            vip_info[obj[0]] = {'vip_id':obj[0],
                                 'host_id':obj[1],
                                 'vip_status':obj[2],
                                 'active_count':obj[3],
                                 'total_count':obj[4]
                                 }
    return vip_info


class SystemAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):
    queryset = System.objects.select_related('ihms_system').all()
    serializer_class = LiteSystemSerializer
    search_fields = ('system_name',)
    lookup_url_kwarg = 'system'

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()
        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)

    def get_queryset(self):
        pop_id = self.kwargs['pop']
        system_pop_set = self.queryset.filter(pop__pop=pop_id)
        return system_pop_set

    def get_object(self, queryset=None):
        if queryset is None:
            queryset = self.filter_queryset(self.get_queryset())
        else:
            pass

        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field

        try:
            data = self.request.DATA

            lookup = map(lambda x : x.get(lookup_url_kwarg) , data)
            filter_kwargs = {"%s__in" % self.lookup_field: lookup}

            obj = get_list_or_404(queryset, **filter_kwargs)
        except Exception, e:
            raise e

        return obj

    def get(self, request, *args, **kwargs):
        ret = super(SystemAPI, self).list(request, *args, **kwargs)

        if isinstance(ret.data, list):
            org_results = ret.data
        else:
            org_results = ret.data['results']
        system_list = []
        for result in org_results:
            system_list.append(str(result['system']))
        system_mon_info = system_monitoring_info(system_list)
        host_info, system_info, pop_info = get_name_info('system', system_list)

        for result in org_results:
            result[ 'is_deletable' ] = False
            if pop_info.has_key(result[ 'pop' ]):
                result[ 'pop_name' ] = pop_info[result['pop' ]][ 'pop_name']
            if system_info.has_key(result[ 'system' ]):
                result[ 'fullsystemname' ] = system_info[result['system' ]][ 'system_name']

            if system_mon_info.has_key(result['system']):
                system_mon_item = system_mon_info[result['system']]
                result['status'] = system_mon_item['system_status']
                result['host_count'] = {'total_count':system_mon_item['total_count'],
                                       'active_count':system_mon_item['active_count']}
            else:
                result['status'] = -1
                result['host_count'] = {'total_count':0,
                                       'active_count':0}

        if isinstance(ret.data, list):
            ret.data = org_results
        else:
            ret.data['results'] = org_results
        return ret

    def post(self, request, *args, **kwargs):
        return super(SystemAPI, self).create(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(SystemAPI, self).partial_update(request, *args, **kwargs)

class SystemRelatedItemAPI(SpectrumGenericAPIView):
    lookup_url_kwarg = "system_id"

    def get(self, request, *args, **kwargs):
        related_items = {}
        try:
            system_id = self.kwargs.pop(self.lookup_url_kwarg)

            system = System.objects.get(pk=int(system_id))
            system_items = system.get_related_objects()

            for items in system_items:
                key = unicode(items[0].__name__)
                sub_items = []
                for sub_item in items[1]:
                    sub_items.append("%s" % sub_item)

                if len(sub_items) > 0:
                    related_items.update({key: sub_items})
            related_items["is_deletable"] = system.is_deletable()
            return Response(related_items)
        except KeyError:
            raise AccessInvalidSystemID
        except System.DoesNotExist:
            raise SystemDoesNotExist
        except:
            raise APIException(detail=_(u"Occured system failure"))

class SystemDetailAPI(mixins.RetrieveModelMixin,
                      UpdateModelMixin,
                      DestroyModelMixin,
                      SpectrumGenericAPIView):
    queryset = System.objects.all()
    serializer_class = SystemSerializer
    search_fields = ('system_name',)
    lookup_url_kwarg = 'system'

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        if instance and instance.ihms_system and data:
            if data.has_key('system_name'):
                data.pop('system_name')
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()
        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)

    def get(self, request, *args, **kwargs):
        return super(SystemDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        # valid modifiable
        return super(SystemDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(SystemDetailAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ObjDeleteNotAllowed(obj_name='system')

        if obj.pop.is_clb_pop():
            if obj.pop.is_related_clb_zone_pending():
                raise ObjDeleteNotAllowed(obj_name='vip',
                                          except_msg="This pop's CLB DNS Zone '%s' is in pending lock status. Please wait until the lock is released.") \
                                          % (obj.pop.get_related_pending_clb_zones())

    def delete(self, request, *args, **kwargs):
        return super(SystemDetailAPI, self).destroy(request, *args, **kwargs)

class StatusUpdate(SpectrumGenericAPIView):
    lookup_url_kwarg = 'base_type'
    @transaction.commit_manually
    def patch(self, request, *args, **kwargs):
        base_type = self.kwargs.get(self.lookup_url_kwarg)
        if isinstance(self.request.DATA, list):
            data_list = self.request.DATA
        else:
            data_list = [self.request.DATA]
        try:
            for data in data_list:
                # auto_probe : probe agent check
                if not system_host_vip_autoprobe_chk(base_type, data):
                    raise Exception('Cannot be changed.Please check the auto probe option.')

                query_set = model_class[base_type].objects.filter(pk__in=data['id'])
                query_set.update(enable_gslb=data['enable_gslb'])
                if data['save_and_push'] == True:
                    CONFIG_DESC = data['description']
                    if len(CONFIG_DESC.strip()) == 0:
                        raise Exception('Description is empty. Require fill in description.')
                    ACTION_KEYWORD = data['src_key']
                    if len(ACTION_KEYWORD.strip()) == 0:
                        raise Exception('src_key is requried')
                    result = config_push(self.request, CONFIG_PUSH_GROUP, CONFIG_TYPE_ID, -1, ACTION_KEYWORD, CONFIG_DESC)
                    if result['status_code'] != status.HTTP_200_OK:
                        transaction.rollback()
                        raise ConfigAPIException(result['status_code'], result['detail'])
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response(_(u"{'detail':'updated'}"))


def system_host_vip_autoprobe_chk(base_type, data):
    try:
        query_sets = model_class[base_type].objects.filter(pk__in=data['id'])
        enable_gslb = data['enable_gslb']

        for query_set in query_sets:
            if base_type == 'system':
                # Change SYSTEM Status
                pop = query_set.pop
                if pop and not pop.check_auto_probeagents(query_set.pk, base_type):
                    hosts = Host.objects.filter(system=query_set).values('host')
                    vips = Vip.objects.filter(host__in=hosts).values('vip')
                    probeagents = ProbeAgent.objects.filter(vip__in=vips)
                    if pop.auto_probe==1 and probeagents.count() > 0:
                        if enable_gslb == 0 or enable_gslb == '0':
                            return False
            elif base_type == 'host':
                # Change HOST Status
                pop = query_set.system.pop
                if pop and not pop.check_auto_probeagents(query_set.pk, base_type):
                    vips = Vip.objects.filter(host=query_set).values('vip')
                    probeagents = ProbeAgent.objects.filter(vip__in=vips)
                    if pop.auto_probe==1 and probeagents.count() > 0:
                        if enable_gslb == 0 or enable_gslb == '0':
                            return False
            elif base_type == 'vip':
                # Change Vip Status
                pop = query_set.host.system.pop
                try:
                    probeagents = ProbeAgent.objects.get(vip=query_set)
                except:
                    probeagents = None
                if pop and probeagents and not pop.check_auto_probeagents(query_set.pk, base_type):
                    if pop.auto_probe==1 and (enable_gslb == 0 or enable_gslb == '0'):
                        return False
    except Exception, e:
        return False

    return True 


class PopGroupsAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):
    queryset = PopGroup.objects.all()
    serializer_class = PopGroupSerializer
    lookup_url_kwarg = "popgroup_id"
    search_fields = ('name',)

    def get(self, request, *args, **kwargs):
        return super(PopGroupsAPI, self).list(request, *args, **kwargs)

class RoleAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):
    queryset = Role.objects.all()
    serializer_class = RoleSerializer
    search_fields = ('role_name',)
    lookup_url_kwarg = "role_id"

    def get(self, request, *args, **kwargs):
        return super(RoleAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(RoleAPI, self).create(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(RoleAPI, self).partial_update(request, *args, **kwargs)

class RoleDetailAPI(mixins.RetrieveModelMixin,
                      UpdateModelMixin,
                      DestroyModelMixin,
                      SpectrumGenericAPIView):
    queryset = Role.objects.all()
    serializer_class = RoleSerializer
    search_fields = ('role_name',)
    lookup_url_kwarg = "role_id"

    def get(self, request, *args, **kwargs):
        return super(RoleDetailAPI, self).retrieve(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(RoleDetailAPI, self).partial_update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        return super(RoleDetailAPI, self).destroy(request, *args, **kwargs)


class PopLocationAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):
    queryset = IhmsCountry.objects.all()
    serializer_class = PopLocationSerializer
    search_fields = ('country_name',)

    def get(self, request, *args, **kwargs):
        return super(PopLocationAPI, self).list(request, *args, **kwargs)

class IhmsIdcAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):
    queryset = IhmsIdc.objects.all()
    serializer_class = IhmsIdcSerializer
    search_fields = ('idc_name',)

    def get(self, request, *args, **kwargs):
        return super(IhmsIdcAPI, self).list(request, *args, **kwargs)

class PopDetailAPI(mixins.RetrieveModelMixin,
                      UpdateModelMixin,
                      DestroyModelMixin,
                      SpectrumGenericAPIView):
    queryset = Pop.objects.select_related('ihms_pop').all()
    serializer_class = PopSerializer
    # search_fields = ('pop_name',)
    lookup_url_kwarg = 'pop'

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        pop_info = PopInfo(pop=instance)
        pop_info.save()
        if instance and instance.ihms_pop_id and data:
            if data.has_key('pop_name'):
                data.pop('pop_name')
            if data.has_key('popinfo'):
                data.pop('popinfo')
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()
        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)


    def get(self, request, *args, **kwargs):
        ret = super(PopDetailAPI, self).retrieve(request, *args, **kwargs)
        pop_list = [str(ret.data['pop']), ]
        pop_status = pop_monitoring_info(pop_list)
        pop_hosts = pop_host_monitoring_count(pop_list)
        if pop_status.has_key(int(ret.data['pop'])):
            pop_mon = pop_status[int(ret.data['pop'])]
            ret.data['status'] = pop_mon['pop_status']
        else:
            ret.data['status'] = -1
        if pop_hosts.has_key(int(ret.data['pop'])):
            pop_host = pop_hosts[int(ret.data['pop'])]
            ret.data['host_count'] = {'enabled': pop_host['enabled'], 'disabled':pop_host['disabled'], 'failure':pop_host['failure']}
        else:
            ret.data['host_count'] = {'enabled': 0, 'disabled':0, 'failure':0}

        return ret

    def patch(self, request, *args, **kwargs):
        return super(PopDetailAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ObjDeleteNotAllowed(obj_name='pop')

    def delete(self, request, *args, **kwargs):
        return super(PopDetailAPI, self).destroy(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        # valid modifiable
        return super(PopDetailAPI, self).update(request, *args, **kwargs)

class PopAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):
    queryset = Pop.objects.all()
    serializer_class = PopSerializer
    search_fields = ('pop_name', 'ihms_pop__pop_code',)
    lookup_url_kwarg = "pop"

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        lite_flag = self.request.GET.get('lite', None)
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()
        if lite_flag:
            return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context,
                                fields=('pop', 'pop_name_info', 'pop_name',
                                        'popinfo_info', 'popinfo',
                                        'description', 'cdnw_pop_id'))
        else:
            return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)


    def get_queryset(self):
        role = self.request.GET.get('role', None)
        popgroup = self.request.GET.get('popgroup', None)

        if role:
            role_list = role.split(',')
            pop_roles = pop_role_info([], role_list)
            if len(pop_roles.keys()) > 0:
                self.queryset = self.queryset.filter(pk__in=pop_roles.keys())

        if popgroup:
            popgroup_list = popgroup.split(',')
            self.queryset = self.queryset.filter(popgroup__in=popgroup_list)
        return self.queryset

    def get_object(self, queryset=None):
        if queryset is None:
            queryset = self.filter_queryset(self.get_queryset())
        else:
            pass

        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field

        try:
            data = self.request.DATA

            lookup = map(lambda x : x.get(lookup_url_kwarg) , data)
            filter_kwargs = {"%s__in" % self.lookup_field: lookup}

            obj = get_list_or_404(queryset, **filter_kwargs)
        except Exception, e:
            raise e

        return obj

    def get(self, request, *args, **kwargs):
        role = self.request.GET.get('role', None)
        popgroup = self.request.GET.get('popgroup', None)
        queryset = Pop.objects.all()
        if role:
            role_list = role.split(',')
            pop_roles = pop_role_info([], role_list)
            queryset = queryset.filter(pk__in=pop_roles.keys())

        if popgroup:
            popgroup_list = popgroup.split(',')
            queryset = queryset.filter(popgroup__in=popgroup_list)
        if self.request.GET.get('pop_name', None):
            pop_name = self.request.GET.get('pop_name')
            queryset = queryset.filter(Q(pop_name__icontains=pop_name) | Q(ihms_pop__pop_code__icontains=pop_name))

        if self.request.GET.get('ihms_pop__pop_code', None):
            ihms_pop__pop_code = self.request.GET.get('ihms_pop__pop_code')
            queryset = queryset.filter(Q(pop_name__icontains=ihms_pop__pop_code) | Q(ihms_pop__pop_code__icontains=ihms_pop__pop_code))

        if self.request.GET.get('search', None):
            pop_name = self.request.GET.get('search')
            queryset = queryset.filter(Q(pop_name__icontains=pop_name) | Q(ihms_pop__pop_code__icontains=pop_name))

        base_pop = queryset.select_related('ihms_pop',
                                           'ihms_pop__ihmspopinfo',
                                           'popinfo',
                                           'popinfo__country',
                                           'ihms_pop__ihmspopinfo__country',
                                           'ihms_pop__ihmspopinfo__idc')
        ret = []
        for pop in base_pop:
            pop_dic_temp = {'pop':0, 'pop_name':'', 'pop_name_info':'', 'description':None, 'cdnw_pop_id':None, 'popinfo_info':None, 'popinfo':None}
            popinfo_dic_temp = {'country_id':None, \
                                'country':None, \
                                'idc_id':None, \
                                'idc':None, \
                                'priority':None}
            pop_dic_temp['pop'] = pop.pop
            pop_dic_temp['pop_name'] = pop.pop_name
            pop_dic_temp['cdnw_pop_id'] = pop.ihms_pop_id
            pop_dic_temp['description'] = pop.description
            country = None
            pop_info_obj = None
            try:
                if pop.ihms_pop:
                    pop_info_obj = pop.ihms_pop.ihmspopinfo
                    pop_dic_temp['pop_name_info'] = pop.ihms_pop.pop_code
                else:
                    pop_info_obj = pop.popinfo
                    pop_dic_temp['pop_name_info'] = pop.pop_name
            except:
                pass

            if pop_info_obj:
                try:
                    country = pop_info_obj.country
                except:
                    country = None
                try:
                    idc = pop_info_obj.idc
                except:
                    idc = None
                try:
                    priority = pop_info_obj.priority
                except:
                    priority = None
                popinfo_dic_temp['country_id'] = country.country_id if country else country
                popinfo_dic_temp['country'] = country.country_name if country else country
                popinfo_dic_temp['idc_id'] = idc.idc_id if idc else idc
                popinfo_dic_temp['idc'] = idc.idc_name if idc else idc
                popinfo_dic_temp['priority'] = priority

            pop_dic_temp['popinfo_info'] = popinfo_dic_temp
            pop_dic_temp['popinfo'] = popinfo_dic_temp
            ret.append(pop_dic_temp)

        org_results = ret

        pop_list = []
        for result in org_results:
            pop_list.append(str(result['pop']))
        pop_status = pop_monitoring_info(pop_list)
        pop_roles = pop_role_info(pop_list)
        pop_hosts = pop_host_monitoring_count(pop_list)
        for result in org_results:
            if pop_status.has_key(int(result['pop'])):
                pop_mon = pop_status[int(result['pop'])]
                result['status'] = pop_mon['pop_status']
            else:
                result['status'] = -1

            if pop_hosts.has_key(int(result['pop'])):
                pop_host = pop_hosts[int(result['pop'])]
                result['host_count'] = {'enabled': pop_host['enabled'], 'disabled':pop_host['disabled'], 'failure':pop_host['failure']}
            else:
                result['host_count'] = {'enabled': 0, 'disabled':0, 'failure':0}

            if pop_roles.has_key(int(result['pop'])):
                pop_role = pop_roles[int(result['pop'])]
                result['role'] = pop_role.values()
            else:
                result['role'] = []


        pop_location = {}
        for result in org_results:
            try:
                if result['cdnw_pop_id']:
                    if result['popinfo_info'] and result['popinfo_info']['country']:
                        if not pop_location.has_key(result['popinfo_info']['country']):
                            pop_location[result['popinfo_info']['country']] = {'country_name':result['popinfo_info']['country'], \
                                                                   'pop_count':0, \
                                                                   'host_count':0, \
                                                                   'online_count':0, \
                                                                   'pop':[]}
                        pop_location[result['popinfo_info']['country']]['pop'].append(result)
                        host_count = result['host_count']['disabled'] + result['host_count']['failure'] + result['host_count']['enabled']
                        online_count = result['host_count']['enabled']
                        pop_location[result['popinfo_info']['country']]['host_count'] += host_count
                        pop_location[result['popinfo_info']['country']]['online_count'] += online_count
                        pop_location[result['popinfo_info']['country']]['pop_count'] += 1
                    else:
                        ind_key = 'Unlocated'
                        if not pop_location.has_key(ind_key):
                            pop_location[ind_key] = {'country_name':'Unlocated', \
                                                                   'pop_count':0, \
                                                                   'host_count':0, \
                                                                   'online_count':0, \
                                                                   'pop':[]}
                        pop_location[ind_key]['pop'].append(result)
                        host_count = result['host_count']['disabled'] + result['host_count']['failure'] + result['host_count']['enabled']
                        online_count = result['host_count']['enabled']
                        pop_location[ind_key]['host_count'] += host_count
                        pop_location[ind_key]['online_count'] += online_count
                        pop_location[ind_key]['pop_count'] += 1

                else:
                    ind_key = 'Customer POPs'
                    if not pop_location.has_key(ind_key):
                        pop_location[ind_key] = {'country_name':'Customer POPs', \
                                                                   'pop_count':0, \
                                                                   'host_count':0, \
                                                                   'online_count':0, \
                                                                   'pop':[]}
                    pop_location[ind_key]['pop'].append(result)
                    host_count = result['host_count']['disabled'] + result['host_count']['failure'] + result['host_count']['enabled']
                    online_count = result['host_count']['enabled']
                    pop_location[ind_key]['host_count'] += host_count
                    pop_location[ind_key]['online_count'] += online_count
                    pop_location[ind_key]['pop_count'] += 1
            except:
                pass

        if pop_location.has_key('Customer POPs'):
            cus_pop = pop_location.pop('Customer POPs')
        else:
            cus_pop = None
        if pop_location.has_key('Unlocated'):
            unlocate_pop = pop_location.pop('Unlocated')
        else:
            unlocate_pop = None

        list_items = pop_location.items()
        list_items.sort(lambda a, b:cmp(a[1]['country_name'], b[1]['country_name']))

        ret_list = [a[1] for a in list_items]

        if cus_pop:
            ret_list.append(cus_pop)
        if unlocate_pop:
            ret_list.append(unlocate_pop)

        for item in ret_list:
            try:
                pop_list = item['pop']
                pop_list.sort(lambda a, b:cmp(a['pop_name'], b['pop_name']))
            except:
                pass

        return Response(ret_list)

    def post(self, request, *args, **kwargs):
        return super(PopAPI, self).create(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(PopAPI, self).partial_update(request, *args, **kwargs)


class PopRelatedItemAPI(SpectrumGenericAPIView):
    lookup_url_kwarg = "pop_id"

    def get(self, request, *args, **kwargs):
        related_items = {}
        try:
            pop_id = self.kwargs.pop(self.lookup_url_kwarg)

            pop = Pop.objects.get(pk=int(pop_id))
            pop_items = pop.get_related_objects()

            for items in pop_items:
                key = unicode(items[0].__name__)
                sub_items = []
                for sub_item in items[1]:
                    sub_items.append("%s" % sub_item)

                if len(sub_items) > 0:
                    related_items.update({key: sub_items})
            related_items["is_deletable"] = pop.is_deletable()
            return Response(related_items)
        except KeyError:
            raise AccessInvalidPopID
        except Pop.DoesNotExist:
            raise PopDoesNotExist
        except Exception, e:
            raise APIException(detail=_(u"Occured system failure"))

class RelatedEdgesAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):
    queryset = Edge.objects.all()
    serializer_class = EdgeSerializer
    search_fields = ('name',)

    def get_queryset(self):
        base_type = self.kwargs['base_type']
        base_id = self.kwargs['base_id']
        if base_type == 'pop':
            base_set = BaseVipEdge.objects.filter(vip__host__system__pop=base_id)
        elif base_type == 'system':
            base_set = BaseVipEdge.objects.filter(vip__host__system=base_id)
        elif base_type == 'host':
            base_set = BaseVipEdge.objects.filter(vip__host=base_id)
        elif base_type == 'vip':
            base_set = BaseVipEdge.objects.filter(vip=base_id)
        edge_ids = [x.edge_id for x in base_set]
        relatedEdges = self.queryset.filter(edge_id__in=edge_ids)
        return relatedEdges

    def get(self, request, *args, **kwargs):
        lite = request.QUERY_PARAMS.get("lite", None)
        if lite:
            self.serializer_class = EdgeSimpleSerializer
        else:
            pass

        if not kwargs['base_type'] in model_class.keys():
            raise Http404
        return super(RelatedEdgesAPI, self).list(request, *args, **kwargs)


class RelatedDomainsAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):
    queryset = Domain.objects.all()
    serializer_class = DomainSerializer
    search_fields = ('name',)
    lookup_url_kwarg = 'base_type'

    def get_queryset(self):
        base_type = self.kwargs['base_type']
        base_id = self.kwargs['base_id']
        if base_type == 'pop':
            base_set = DomainVip.objects.filter(vip__host__system__pop=base_id)
            edge_set = BaseVipEdge.objects.filter(vip__host__system__pop=base_id)
        elif base_type == 'system':
            base_set = DomainVip.objects.filter(vip__host__system=base_id)
            edge_set = BaseVipEdge.objects.filter(vip__host__system=base_id)
        elif base_type == 'host':
            base_set = DomainVip.objects.filter(vip__host=base_id)
            edge_set = BaseVipEdge.objects.filter(vip__host=base_id)
        elif base_type == 'vip':
            base_set = DomainVip.objects.filter(vip=base_id)
            edge_set = BaseVipEdge.objects.filter(vip=base_id)
        elif base_type == 'edge':
            base_set = DomainEdge.objects.filter(edge=base_id)
            edge_set = BaseVipEdge.objects.filter(edge=base_id)

        domain_ids1 = [x.domain_id for x in base_set]

        edge_ids = [x.edge_id for x in edge_set]
        domainedge_set = DomainEdge.objects.filter(edge__in=edge_ids)
        domain_ids2 = [x.domain_id for x in domainedge_set]
        domain_ids = domain_ids1 + domain_ids2
        relatedDomains = self.queryset.filter(domain_id__in=domain_ids)

        return relatedDomains

    def get(self, request, *args, **kwargs):
        if not kwargs['base_type'] in model_class.keys():
            raise Http404
        return super(RelatedDomainsAPI, self).list(request, *args, **kwargs)


class ConfigDistActionHistoryAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):
    queryset = ConfigDistAction.objects.all()
    serializer_class = ConfigDistActionSerializer
    lookup_url_kwarg = 'action_keyword'
    def get_queryset(self):
        keyword = self.kwargs['keyword']
        configdistactionhistory = self.queryset.filter(action_keyword=keyword)
        return configdistactionhistory

    def get(self, request, *args, **kwargs):
        return super(ConfigDistActionHistoryAPI, self).list(request, *args, **kwargs)




class RelatedHostAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):
    queryset = Host.objects.select_related('ihms_host' , 'system' , 'system__pop').all()
    serializer_class = SimpleHostSerializer
    search_fields = ('host_name' ,)
    lookup_url_kwarg = 'base_type'

    def get_queryset(self):
        base_type = self.kwargs[ 'base_type']
        base_id = self.kwargs[ 'base_id']
        role_id = self.kwargs[ 'role_id'] if self.kwargs.has_key('role_id') else None
        if base_type == 'pop' :
            relatedHosts = self.queryset.filter(system__pop=base_id)
        elif base_type == 'system':
            relatedHosts = self.queryset.filter(system=base_id)
        elif base_type == 'host':
            relatedHosts = self.queryset.filter(host=base_id)
        elif base_type == 'vip':
            vip_obj = Vip.objects.filter(vip=base_id)
            host_list = [v.host.pk for v in vip_obj]
            relatedHosts = self.queryset.filter(host__in=host_list)
        elif base_type == 'edge':
            base_set = BaseVipEdge.objects.filter(edge=base_id)
            vip_ids = [x.vip.pk for x in base_set]
            vip_set = Vip.objects.filter(vip__in=vip_ids)
            host_ids = [x.host.pk for x in vip_set]
            relatedHosts = self.queryset.filter(host__in=host_ids)
        if role_id != None :
            role_hosts = HostRole.objects.filter(host__in=relatedHosts, role=role_id).values('host__pk')
            relatedHosts = relatedHosts.filter(host__in=role_hosts)
        return relatedHosts


    def get(self, request, *args, **kwargs):
        if not kwargs[ 'base_type'] in model_class.keys():
            raise Http404
        ret = super(RelatedHostAPI, self).list(request, *args, **kwargs)
        if isinstance(ret.data, list):
            org_results = ret.data
        else :
            org_results = ret.data[ 'results' ]

        host_list = []
        for result in org_results:
            host_list.append(str(result[ 'host' ]))
        host_mon_info = host_monitoring_info(host_list)

        host_info, system_info, pop_info = get_name_info('host', host_list)
        host_role_info = get_host_role_info(host_list)

        for result in org_results:
            result[ 'is_deletable' ] = False
            if host_info.has_key(result[ 'host' ]):
                result[ 'fullhostname' ] = host_info[result['host' ]][ 'host_name']
            if pop_info.has_key(result[ 'pop' ]):
                result[ 'pop_name' ] = pop_info[result['pop' ]][ 'pop_name']
            if system_info.has_key(result[ 'system' ]):
                result[ 'system_name' ] = system_info[result['system' ]][ 'system_name']
            if host_role_info.has_key(result[ 'host' ]):
                result['role_info' ] = host_role_info[result[ 'host']].values()
                result['role' ] = host_role_info[result[ 'host']].keys()
            else:
                result['role_info' ] = []
                result['role' ] = []
            if host_mon_info.has_key(result[ 'host' ]):
                host_mon_item = host_mon_info[result[ 'host' ]]
                result[ 'status' ] = host_mon_item[ 'host_status']
                result[ 'NIC' ] = host_mon_item[ 'NIC']
                result[ 'vip_count' ] = {'total_count' :host_mon_item[ 'total_count'],
                                   'active_count' :host_mon_item[ 'active_count']}
            else :
                result[ 'status' ] = -1
                result[ 'NIC' ] = ''
                result[ 'vip_count' ] = {'total_count' :0 ,
                                   'active_count' :0 }

        if isinstance(ret.data, list):
            ret.data = org_results
        else :
            ret.data[ 'results' ] = org_results
        return ret

class BasePopAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):
    queryset = Pop.objects.all()
    serializer_class = BasePopSerializer
    search_fields = ('pop_name',)
    filter_fields = ('pop', "pop_name", {"pop_code":"ihms_pop__pop_code"})
    lookup_url_kwarg = "pop"

    def get(self, request, *args, **kwargs):
        return super(BasePopAPI, self).list(request, *args, **kwargs)

class CustomerDisplayAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):
    queryset = CustomerDisplay.objects.all()
    serializer_class = CustomerDisplaySerializer
    search_fields = ('customer_name',)
    lookup_url_kwarg = "customer"

    def get(self, request, *args, **kwargs):
        return super(CustomerDisplayAPI, self).list(request, *args, **kwargs)


class HostDetailAPI(mixins.RetrieveModelMixin,
                      UpdateModelMixin,
                      DestroyModelMixin,
                      SpectrumGenericAPIView):
    queryset = Host.objects.all()
    serializer_class = PopHostSerializer
    search_fields = ('host_name',)
    lookup_url_kwarg = 'host'

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        if instance and instance.ihms_host and data:
            if data.has_key('host_name'):
                data.pop('host_name')
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()
        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)

    def get(self, request, *args, **kwargs):
        ret = super(HostDetailAPI, self).retrieve(request, *args, **kwargs)
        host_list = [str(ret.data['host'])]
        host_mon_info = host_monitoring_info(host_list)
        if len(host_mon_info) > 0:
            host_mon_item = host_mon_info[ret.data['host']]
            ret.data['status'] = host_mon_item['host_status']
        else:
            ret.data['status'] = -1
        return ret

    def put(self, request, *args, **kwargs):
        # valid modifiable
        return super(HostDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(HostDetailAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ObjDeleteNotAllowed(obj_name='host')

        if obj.system.pop.is_clb_pop():
            if obj.system.pop.is_related_clb_zone_pending():
                raise ObjDeleteNotAllowed(obj_name='vip',
                                          except_msg="This pop's CLB DNS Zone '%s' is in pending lock status. Please wait until the lock is released.") \
                                          % (obj.system.pop.get_related_pending_clb_zones())

    def delete(self, request, *args, **kwargs):
        return super(HostDetailAPI, self).destroy(request, *args, **kwargs)

class HostAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):
    queryset = Host.objects.all()
    serializer_class = PopHostSerializer
    search_fields = ('host_name',)
    lookup_url_kwarg = "host"

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()
        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)

    def get_queryset(self):
        system = self.kwargs['system']
        relatedHosts = self.queryset.filter(system=system)
        return relatedHosts

    def get_object(self, queryset=None):
        if queryset is None:
            queryset = self.filter_queryset(self.get_queryset())
        else:
            pass

        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field

        try:
            data = self.request.DATA

            lookup = map(lambda x : x.get(lookup_url_kwarg) , data)
            filter_kwargs = {"%s__in" % self.lookup_field: lookup}

            obj = get_list_or_404(queryset, **filter_kwargs)
        except Exception, e:
            raise e

        return obj

    def get(self, request, *args, **kwargs):
        return super(HostAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(HostAPI, self).create(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(HostAPI, self).partial_update(request, *args, **kwargs)

class HostRelatedItemAPI(SpectrumGenericAPIView):
    lookup_url_kwarg = "host_id"

    def get(self, request, *args, **kwargs):
        related_items = {}
        try:
            host_id = self.kwargs.pop(self.lookup_url_kwarg)

            host = Host.objects.get(pk=int(host_id))
            host_items = host.get_related_objects()

            for items in host_items:
                key = unicode(items[0].__name__)
                sub_items = []
                for sub_item in items[1]:
                    sub_items.append("%s" % sub_item)

                if len(sub_items) > 0:
                    related_items.update({key: sub_items})
            related_items["is_deletable"] = host.is_deletable()
            return Response(related_items)
        except KeyError:
            raise AccessInvalidHostID
        except Host.DoesNotExist:
            raise HostDoesNotExist
        except:
            raise APIException(detail=_(u"Occured system failure"))


class VipDetailAPI(mixins.RetrieveModelMixin,
                      UpdateModelMixin,
                      DestroyModelMixin,
                      SpectrumGenericAPIView):
    queryset = Vip.objects.all()
    serializer_class = VipSerializer
    search_fields = ('vip_name',)
    lookup_url_kwarg = 'vip'

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        if instance and instance.ihms_vip and data:
            if data.has_key('vip_name'):
                data.pop('vip_name')
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()
        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context, request=self.request)

    def get(self, request, *args, **kwargs):
        return super(VipDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(VipDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(VipDetailAPI, self).partial_update(request, *args, **kwargs)

    def post_save(self, obj, created=False):
        myedges = obj.get_edges()
        probes = obj.vipprobeconfigs_set.all()
        edge_list = [edge.edge_id for edge in myedges]
        probe_list = [probe.probe_id for probe in probes]

        is_valid, errmsg = obj.check_edgelist_probe_constraint(self.request, edge_list,
                                                                probe_list, True)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ObjDeleteNotAllowed(obj_name='vip')

        if obj.host.system.pop.is_clb_pop():
            if obj.host.system.pop.is_related_clb_zone_pending():
                raise ObjDeleteNotAllowed(obj_name='vip',
                                          except_msg="This pop's CLB DNS Zone '%s' is in pending lock status. Please wait until the lock is released.") \
                                          % (obj.host.system.pop.get_related_pending_clb_zones())

    def delete(self, request, *args, **kwargs):
        return super(VipDetailAPI, self).destroy(request, *args, **kwargs)

class VipRelatedItemAPI(SpectrumGenericAPIView):
    lookup_url_kwarg = "vip_id"

    def get(self, request, *args, **kwargs):
        related_items = {}
        try:
            vip_id = self.kwargs.pop(self.lookup_url_kwarg)

            vip = Vip.objects.get(pk=int(vip_id))
            vip_items = vip.get_related_objects()

            for items in vip_items:
                key = unicode(items[0].__name__)
                sub_items = []
                for sub_item in items[1]:
                    if hasattr(sub_item,'get_full_name'):
                        sub_items.append("%s" % sub_item.get_full_name())
                    else:
                        sub_items.append("%s" % sub_item)

                if len(sub_items) > 0:
                    related_items.update({key: sub_items})
            related_items["is_deletable"] = vip.is_deletable()
            return Response(related_items)
        except KeyError:
            raise AccessInvalidVipID
        except Vip.DoesNotExist:
            raise VipDoesNotExist
        except:
            raise APIException(detail=_(u"Occured system failure"))

class VipAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):
    queryset = Vip.objects.all()
    serializer_class = VipSerializer
    search_fields = ('host_name',)
    lookup_url_kwarg = "vip"

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()
        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)

    def get_queryset(self):
        host = self.kwargs['host']
        relatedVips = self.queryset.filter(host=host)
        return relatedVips

    def get_object(self, queryset=None):
        if queryset is None:
            queryset = self.filter_queryset(self.get_queryset())
        else:
            pass

        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field

        try:
            data = self.request.DATA

            lookup = map(lambda x : x.get(lookup_url_kwarg) , data)
            filter_kwargs = {"%s__in" % self.lookup_field: lookup}

            obj = get_list_or_404(queryset, **filter_kwargs)
        except Exception, e:
            raise e

        return obj

    def get(self, request, *args, **kwargs):
        ret = super(VipAPI, self).list(request, *args, **kwargs)

        if isinstance(ret.data, list):
            org_results = ret.data
        else:
            org_results = ret.data['results']

        vip_list = []
        for result in org_results:
            vip_list.append(str(result['vip']))
        vip_mon_info = vip_monitoring_info(vip_list)

        for result in org_results:
            vip_mon_item = vip_mon_info[result['vip']]
            result['status'] = vip_mon_item['vip_status']

        if isinstance(ret.data, list):
            ret.data = org_results
        else:
            ret.data['results'] = org_results
        return ret

    def post(self, request, *args, **kwargs):
        return super(VipAPI, self).create(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(HostAPI, self).partial_update(request, *args, **kwargs)



class RelatedVipAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):
    queryset = Vip.objects.all()
    serializer_class = VipSerializer
    search_fields = ('vip_name',)
    lookup_url_kwarg = 'base_type'

    def get_queryset(self):
        base_type = self.kwargs['base_type']
        base_id = int(self.kwargs['base_id'])
        if base_type == 'pop':
            systems = System.objects.filter(pop=base_id).values('system')
            hosts = Host.objects.filter(system__in=systems).values('host')
            vips = Vip.objects.filter(host__in=hosts)
            return vips
        elif base_type == 'system':
            hosts = Host.objects.filter(system=base_id).values('host')
            vips = Vip.objects.filter(host__in=hosts)
            return vips
        elif base_type == 'host':
            vips = Vip.objects.filter(host=base_id)
            return vips
        elif base_type == 'vip':
            vips = Vip.objects.filter(vip=base_id)
            return vips
        elif base_type == 'edge':
            base_set = BaseVipEdge.objects.filter(edge=base_id)
            vip_ids = [x.vip_id for x in base_set]
            vips = Vip.objects.filter(vip__in=vip_ids)
            return vips

    def get(self, request, *args, **kwargs):
        if not kwargs['base_type'] in model_class.keys():
            raise Http404
        ret = super(RelatedVipAPI, self).list(request, *args, **kwargs)

        if isinstance(ret.data, list):
            org_results = ret.data
        else:
            org_results = ret.data['results']

        vip_list = []
        for result in org_results:
            vip_list.append(str(result['vip']))
        vip_mon_info = vip_monitoring_info(vip_list)

        for result in org_results:
            vip_mon_item = vip_mon_info[result['vip']]
            result['status'] = vip_mon_item['vip_status']

        if isinstance(ret.data, list):
            ret.data = org_results
        else:
            ret.data['results'] = org_results
        return ret


class RelatedSystemAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):
    queryset = System.objects.all()
    serializer_class = BaseSystemSerializer
    search_fields = ('system_name', 'ihms_system__system_name')
    lookup_url_kwarg = 'base_type'

    def get_queryset(self):
        base_type = self.kwargs['base_type']
        if base_type == 'all':
            return self.queryset
        else:
            base_id = self.kwargs['base_id']
            if base_type == 'pop':
                systems = System.objects.filter(pop=base_id)
                return systems
            elif base_type == 'system':
                systems = System.objects.filter(system=base_id)
                return systems
            elif base_type == 'host':
                base_set = Host.objects.filter(host=base_id).values('system')
                systems = System.objects.filter(system__in=base_set)
                return systems
            elif base_type == 'vip':
                hosts = Vip.objects.filter(vip=base_id).values('host')
                base_set = Host.objects.filter(host__in=hosts).values('system')
                systems = System.objects.filter(system__in=base_set)
                return systems
            elif base_type == 'edge':
                base_set = BaseVipEdge.objects.filter(edge=base_id)
                vip_ids = [x.vip_id for x in base_set]
                hosts = Vip.objects.filter(vip__in=vip_ids).values('host')
                base_set = Host.objects.filter(host__in=hosts).values('system')
                systems = System.objects.filter(system__in=base_set)
                return systems

    def get(self, request, *args, **kwargs):
        if not kwargs['base_type'] in model_class.keys() and kwargs['base_type'] != 'all':
            raise Http404
        return super(RelatedSystemAPI, self).list(request, *args, **kwargs)


class BaseInfoAPI(SpectrumGenericAPIView):
    queryset = PopNameInfo.objects.all()
    lookup_url_kwarg = 'base_type'
    filter_fields = ('pk',)
    ordering = "pk"

    def get_queryset(self):
        system = self.request.GET.get('system', None)
        pop = self.request.GET.get('pop', None)

        lookup_base = self.kwargs.get("base_type", None)
        if lookup_base == "system":
            if pop:
                queryset = SystemNameInfo.objects.filter(pop=pop).all()
            else:
                queryset = SystemNameInfo.objects.all()
        elif lookup_base == "host":
            if system:
                queryset = HostNameInfo.objects.filter(system=system).all()
            else:
                queryset = HostNameInfo.objects.all()
        else:
            queryset = self.queryset

        return queryset

    def get(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        field_names = queryset.model._meta.get_all_field_names()
        ret = [{"id": item[0], "name": item[1]} for item in queryset.values_list('id', 'name')]
        return Response(ret)


# only used by node_dashboard in OUI
class HostBulkAPI(mixins.ListModelMixin,
                  SpectrumGenericAPIView):
    #serializer_class = BaseSystemSerializer
    queryset = Host.objects.select_related('ihms_host' , 'system' , 'system__pop').all()
    serializer_class = SimpleHostBulkSerializer
    filter_fields = ({'ihms_pop_name':'system__pop__ihms_pop__pop_code'},)
    search_fields = ('host_name',)

    def get(self, request, *args, **kwargs):
        """
        if not kwargs['base_type'] in model_class.keys() and kwargs['base_type'] != 'all':
            raise Http404
        """
        object_list = self.get_queryset()
        page = self.paginate_queryset(object_list)
        if page is not None:
            serializer = self.get_pagination_serializer(page)
        else:
            serializer = self.get_serializer(object_list, many=True)
        try:
            return Response(serializer.data)
        except:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def get_queryset(self):
        try:
            pop_names = self.request.QUERY_PARAMS['ihms_pop_name__in']
            host_ids = VipSearch.objects.filter(pop_name__in=pop_names.split(',')).values('host_id')
            return Host.objects.filter(pk__in=host_ids)
        except:
            return Host.objects.none()


class HostRoleAPI(mixins.ListModelMixin,
                CreateModelMixin,
                SpectrumGenericAPIView):
    queryset = HostRole.objects.all()
    serializer_class = HostRoleSerializer
    filter_fields = ('host','role',)

    def get(self, request, *args, **kwargs):
        return super(HostRoleAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(HostRoleAPI, self).create(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):

        for field in self.filter_fields:
            is_found = False
            for rkey in request.QUERY_PARAMS.keys():
                if field in rkey:
                    is_found = True
                    break
            if not is_found:
                return Response('If you want to delete, need more params [%s].' % ','.join(self.filter_fields)
                                , status=status.HTTP_400_BAD_REQUEST)

        queryset = self.filter_queryset(self.get_queryset())
        queryset.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class CLBPopListAPI(generics.ListCreateAPIView, \
                     generics.UpdateAPIView, \
                     generics.DestroyAPIView, \
                     SpectrumGenericAPIView):

    queryset = Pop.objects.all()
    serializer_class = CLBPopSerializer

    def get_queryset(self):
        probe_agent_selection_type = self.request.GET.get('probe_agent_selection_type', 0)
        pop_objs = CustomerContractPop.objects.filter(use_type=1, probe_agent_selection_type=probe_agent_selection_type).values('pop')
        queryset = Pop.objects.filter(pop__in=pop_objs)
        return queryset

    def get(self, request, *args, **kwargs):
        ret = super(CLBPopListAPI, self).list(request, *args, **kwargs)
        return ret


class CLBSetPrimary(SpectrumGenericAPIView):
    @transaction.commit_manually
    def patch(self, request, *args, **kwargs):
        popid = self.request.GET.get('popid', None)
        probeagent_id = self.request.GET.get('probeagent_id', None)
        if not popid or not probeagent_id:
            raise Http404
        req_data = {"detail":_(u"OK")}
        try:
            pop = Pop.objects.get(pk=popid)
            probeconfig_objs = PopProbeAgentConfig.objects.filter(primary=True, pop=pop)
            for probeconfig in probeconfig_objs:
                probeconfig.primary = False
                probeconfig.save(request=self.request)

            probeagent = ProbeAgent.objects.get(pk=probeagent_id)
            probeconfig = PopProbeAgentConfig.objects.get(probeagent=probeagent, pop=pop)
            probeconfig.primary = True
            probeconfig.save(request=self.request)
            pop.rttserver = probeagent
            pop.save(request=self.request)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response(req_data)

class PopRestore(SpectrumGenericAPIView):
    lookup_url_kwarg = 'base_id'
    @transaction.commit_manually
    def patch(self, request, *args, **kwargs):
        base_id = self.kwargs.get(self.lookup_url_kwarg)
        try:
            pop_obj = Pop.all_objects.get(pk=base_id)
            pop_obj.obj_state = True
            pop_obj.save(request=self.request)
        except Pop.DoesNotExist:
            transaction.rollback()
            raise Http404
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response(_(u"{'detail':'updated'}"))


class BaseObjectStatus(SpectrumGenericAPIView):
    def get(self, request, *args, **kwargs):
        base_type = self.kwargs['base_type']
        base_id = self.kwargs['base_id']
        ret = {}
        if base_type == 'pop':
            obj_list = [base_id]
            pop_status = pop_monitoring_info( obj_list)
            pop_hosts = pop_host_monitoring_count( obj_list)

            if pop_status.has_key(int(base_id)):
                if pop_hosts.has_key(int(base_id)):
                    pop_host_item = pop_hosts[int(base_id)]
                    pop_status[int(base_id)]['host_count'] = { 'enabled': int(pop_host_item['enabled' ]), \
                                                              'disabled':int(pop_host_item[ 'disabled']), \
                                                              'failure':int(pop_host_item['failure'])}
                else:
                    pop_status[int(base_id)]['host_count'] = { 'enabled': 0 , 'disabled':0, 'failure':0 }
                ret = pop_status[int(base_id)]

        elif base_type == 'system':
            obj_list = [base_id]
            system_mon_info = system_monitoring_info( obj_list)
            host_info, system_info, pop_info = get_name_info('system', obj_list)

            if system_mon_info.has_key(int(base_id)):
                if system_mon_info.has_key(int(base_id)):
                    system_mon_info[int(base_id)][ 'fullsystemname' ] = system_info[int(base_id)][ 'system_name']
                    system_mon_item = system_mon_info[int(base_id)]
                    system_mon_info[int(base_id)][ 'status'] = system_mon_item['system_status']
                    system_mon_info[int(base_id)][ 'host_count'] = {'total_count':system_mon_item['total_count'],
                                           'active_count':system_mon_item['active_count']}
                else:
                    system_mon_info[int(base_id)][ 'fullsystemname' ] = "Unknown"
                    system_mon_info[int(base_id)][ 'status'] = -1
                    system_mon_info[int(base_id)][ 'host_count'] = {'total_count' :0 ,
                                           'active_count':0 }
                ret = system_mon_info[int(base_id)]
        return Response(ret)
