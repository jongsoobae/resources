from django.conf import settings
from django.db import IntegrityError
from django.db import transaction
from django.utils.translation import ugettext as _
from rest_framework import generics, exceptions, status
from rest_framework import mixins
from rest_framework.response import Response
from rest_framework.status import HTTP_400_BAD_REQUEST
from rest_framework.views import APIView

from spectrum_api.configuration.models.clb import CLBAlertManagementBase, \
                                                CLBAlertGroup, \
                                                CLBAlertGroupHasCLBDomain, \
                                                CLBAlertRecipients, \
                                                CLBAlertGroupHasRecipients, \
                                                CLBAlertDomainFailHistory, \
                                                CLBAlertVipFailHistory, \
                                                CLBAlertDomainSnapshot, \
                                                DOMAIN_MON_STATUS, \
                                                SettingCount
from spectrum_api.configuration.serializers.clb import CLBAlertManagementBaseSerializer, \
                                                    CLBAlertGroupSerializer, \
                                                    CLBAlertRecipientsSerializer, \
                                                    CLBAlertDomainFailHistorySerializer, \
                                                    CLBAlertVipFailHistorySerializer, \
                                                    CLBAlertDomainSnapshotSerializer, \
                                                    CLBStatMasterSerializer, \
                                                    GMTCDSerializer, \
                                                    BaseCLBAlertGroupSerializer
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.mixins import ListModelMixin, CreateModelMixin, UpdateModelMixin, DestroyModelMixin
from spectrum_api.shared_components.models import StatMaster
from spectrum_api.shared_components.models.common_code import GMTCD


class CLBAPIException(exceptions.APIException):
    def __init__(self, status_code, detail):
        self.status_code = status_code
        super(CLBAPIException, self).__init__(detail)

class CLBAlertManagementBaseAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):

    queryset = CLBAlertManagementBase.objects.all()
    serializer_class = CLBAlertManagementBaseSerializer
    lookup_url_kwarg = "clbalertmanagementbase_id"
    filter_fields = ('account_no',)

    def get(self, request, *args, **kwargs):
        ret = super(CLBAlertManagementBaseAPI, self).list(request, *args, **kwargs)
        if isinstance(ret.data, list):
            org_results = ret.data
        else:
            org_results = ret.data['results']

        for result in org_results:
            for group in result['clb_alert_group']:
                group['clbalertgrouphasclbdomain'].sort(lambda a, b:cmp(a['domain'], b['domain']))

        if isinstance(ret.data, list):
            ret.data = org_results
        else:
            ret.data['results'] = org_results
        return ret

    def patch(self, request, *args, **kwargs):
        return super(CLBAlertManagementBaseAPI, self).partial_update(request, *args, **kwargs)


class CLBAlertGroupDetailAPI(mixins.RetrieveModelMixin,
                      UpdateModelMixin,
                      DestroyModelMixin,
                      SpectrumGenericAPIView):
    queryset = CLBAlertGroup.objects.all()
    serializer_class = CLBAlertGroupSerializer
    lookup_url_kwarg = "alertgroup_id"
    filter_fields = ({'account_no':'alert_base_id__account_no'},)

    def get(self, request, *args, **kwargs):
        return super(CLBAlertGroupDetailAPI, self).retrieve(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(CLBAlertGroupDetailAPI, self).partial_update(request, *args, **kwargs)

class CLBAlertGroupAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):

    queryset = CLBAlertGroup.objects.all()
    serializer_class = CLBAlertGroupSerializer
    lookup_url_kwarg = "clbalertgroup_id"
    filter_fields = ({'account_no':'alert_base_id__account_no'},)


    def get(self, request, *args, **kwargs):
        ret = super(CLBAlertGroupAPI, self).list(request, *args, **kwargs)
        return ret

    def patch(self, request, *args, **kwargs):
        return super(CLBAlertGroupAPI, self).partial_update(request, *args, **kwargs)

class CLBAlertRecipientsAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):

    queryset = CLBAlertRecipients.objects.all()
    serializer_class = CLBAlertRecipientsSerializer
    filter_fields = ({'account_no':'alert_base_id__account_no'},)

    def get(self, request, *args, **kwargs):
        ret = super(CLBAlertRecipientsAPI, self).list(request, *args, **kwargs)
        return ret

    def post(self, request, *args, **kwargs):
        return super(CLBAlertRecipientsAPI, self).create(request, *args, **kwargs)

class CLBAlertRecipientsDetailAPI(mixins.RetrieveModelMixin,
                      UpdateModelMixin,
                      DestroyModelMixin,
                      SpectrumGenericAPIView):
    queryset = CLBAlertRecipients.objects.all()
    serializer_class = CLBAlertRecipientsSerializer
    lookup_url_kwarg = "recipient_id"
    filter_fields = ({'account_no':'alert_base_id__account_no'},)

    def get(self, request, *args, **kwargs):
        return super(CLBAlertRecipientsDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(CLBAlertRecipientsDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(CLBAlertRecipientsDetailAPI, self).partial_update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        return super(CLBAlertRecipientsDetailAPI, self).destroy(request, *args, **kwargs)

class CLBStatMasterAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):

    queryset = StatMaster.objects.filter(material_no=settings.CLB_MATERIAL).all()
    serializer_class = CLBStatMasterSerializer
    filter_fields = ({'account_no':'customer__account__account_no'},)

    def get(self, request, *args, **kwargs):
        ret = super(CLBStatMasterAPI, self).list(request, *args, **kwargs)
        return ret


class GMTCDAPI(mixins.ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):
    queryset = GMTCD.objects.all()
    serializer_class = GMTCDSerializer

    def get(self, request, *args, **kwargs):
        ret = super(GMTCDAPI, self).list(request, *args, **kwargs)
        return ret

    def post(self, request, *args, **kwargs):
        return super(CLBStatMasterAPI, self).create(request, *args, **kwargs)

class CLBAlertDomainStatusAPI(SpectrumGenericAPIView):
    def get(self, request, *args, **kwargs):
        Domain_status = [{'status':t[0], 'status_name':t[1]} for t in DOMAIN_MON_STATUS]
        return Response(Domain_status)

class CLBAlertDomainFailHistoryAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = CLBAlertDomainFailHistory.objects.select_related().all()
    search_fields = ('statmaster__customer__account__account_no',)
    filter_fields = ({"account_no":'statmaster__customer__account__account_no'}, 'update_time',)

    serializer_class = CLBAlertDomainFailHistorySerializer

    def get(self, request, *args, **kwargs):
        accNo = self.request.QUERY_PARAMS.get('account_no', None)

        if not accNo:
            raise CLBAPIException(status.HTTP_400_BAD_REQUEST, _('account_no is required.'))

        ret = super(CLBAlertDomainFailHistoryAPI, self).list(request, *args, **kwargs)
        return ret

    def get_queryset(self):
        queryset = self.queryset
        queryset = self.filter_queryset(queryset)

        if self.kwargs is not None:
            accNo = self.request.QUERY_PARAMS.get('account_no', None)
            group_id = self.request.QUERY_PARAMS.get('group_id', None)
            if accNo and group_id:
                stat_item = []
                default_group_stat_item = []
                group_list = group_id.split(',')

                stat_item = CLBAlertGroupHasCLBDomain.objects.filter(clb_alert_group__alert_base_id__account_no=accNo,
                                                                clb_alert_group__in=group_list).values('statmaster')

                stat_item = [i.get('statmaster') for i in stat_item]

                hasDefaultGroup = CLBAlertGroup.objects.filter(alert_base_id__account_no=accNo,
                                             clbalertgroup_id__in=group_list,
                                             group_type=0)

                if len(hasDefaultGroup):
                    default_group_stat_item = StatMaster.objects.filter(material_no=settings.CLB_MATERIAL, \
                                                     customer__account__account_no=accNo) \
                                                     .exclude(stat_id__in=stat_item)\
                                                     .values('stat_id')
                    default_group_stat_item = [i.get('stat_id') for i in default_group_stat_item]

                stat_item.extend(default_group_stat_item)

                queryset = queryset.filter(statmaster__in=stat_item)
        return queryset

class CLBAlertVipFailHistoryAPI(ListModelMixin, SpectrumGenericAPIView):

    queryset = CLBAlertVipFailHistory.objects.all()
    search_fields = ('account_no__account_no',)
    filter_fields = ({'account_no':'account_no__account_no'}, 'update_time',)

    serializer_class = CLBAlertVipFailHistorySerializer

    def get(self, request, *args, **kwargs):
        accNo = self.request.QUERY_PARAMS.get('account_no', None)

        if not accNo:
            raise CLBAPIException(status.HTTP_400_BAD_REQUEST, _('account_no is required.'))

        ret = super(CLBAlertVipFailHistoryAPI, self).list(request, *args, **kwargs)
        return ret


class CLBAlertDomainSnapshotAPI(ListModelMixin, SpectrumGenericAPIView):

    queryset = CLBAlertDomainSnapshot.objects.select_related('statmaster', 'domain_fail_history').all()
    search_fields = ('statmaster__customer__account__account_no', 'status',)
    filter_fields = ({"account_no":'statmaster__customer__account__account_no'}, 'status',)

    serializer_class = CLBAlertDomainSnapshotSerializer

    def get(self, request, *args, **kwargs):
        accNo = self.request.QUERY_PARAMS.get('account_no', None)

        if not accNo:
            raise CLBAPIException(status.HTTP_400_BAD_REQUEST, _('account_no is required.'))

        snoonzed_groups = []
        groups = CLBAlertGroup.objects.filter(alert_base_id__account_no=accNo)
        for group in groups:
            if group.is_snoonzed == True:
                snoonzed_groups.append(group.pk)

        ret = super(CLBAlertDomainSnapshotAPI, self).list(request, *args, **kwargs)

        if isinstance(ret.data, dict):
            buf = [item for item in self._snooze_alerm(snoonzed_groups, ret.data['results'])]
            ret.data['results'] = buf
        else:
            buf = [item for item in self._snooze_alerm(snoonzed_groups, ret.data)]
            ret.data = buf

        return ret

    def _snooze_alerm(self, snooze_groups, items):
        _STATUS_ALRAM_OFF_ = 4
        for item in items:
            if item['group']['group_id'] in snooze_groups:
                if item['status'] >= 3:
                    item['status'] = _STATUS_ALRAM_OFF_
            yield item

class CLBAlertGroupHasDomainAPI(SpectrumGenericAPIView):
    lookup_url_kwarg = 'account_no'
    @transaction.commit_manually
    def patch(self, request, *args, **kwargs):
        account_no = self.kwargs.get(self.lookup_url_kwarg)
        cnt_num = 20
        try:
            sc_qs = SettingCount.objects.get(name='ALERT_GROUP_COUNT')
            cnt_num = sc_qs.count
        except:
            pass

        req_data = self.request.DATA
        if len(req_data) > cnt_num:
            transaction.rollback()
            return Response({"detail":_(u"Count of alert groups can't be over max count [%d]." % cnt_num)}, status=HTTP_400_BAD_REQUEST)

        hasdomain_ids = []
        alertgroup_ids = []

        try:
            groupdomain_set = CLBAlertGroupHasCLBDomain.objects.\
                        filter(clb_alert_group__alert_base_id__account_no=account_no)
            list_statid = [obj.statmaster_id for obj in groupdomain_set]
            list_statid_param = []
            is_default_group = False
            for req_obj in req_data:
                if req_obj['group_type'] == 0:
                    is_default_group = True
                for req_item in req_obj['clbalertgrouphasclbdomain']:
                    if req_item.has_key('clbalertgrouphasclbdomain_id'):
                        if req_item['statmaster'] not in list_statid:
                            raise Exception(_(u'statmaster is invalid [%s].' % req_obj['clb_group_name']))
                        else:
                            list_statid_param.append(req_item['statmaster'])
                    else:
                        raise Exception(_(u'clbalertgrouphasclbdomain_id is required [%s].' % req_obj['clb_group_name']))

            if len(set(list_statid)) != len(set(list_statid_param)):
                raise Exception(_(u'all clbalertgrouphasclbdomain_id are required [%s].' % req_obj['clb_group_name']))
            if not is_default_group:
                raise Exception(_(u'default group is required.'))

            objs = CLBAlertManagementBase.objects.filter(account_no=account_no)
            obj_clbalertmanagebase = objs[0]
            for req_obj in req_data:
                if not req_obj.has_key('clbalertgroup_id'):
                    obj_clbalertgroup = CLBAlertGroup()
                    obj_clbalertgroup.repeat_off_use_flag = 0
                else:
                    obj_clbalertgroup = CLBAlertGroup.objects.get(clbalertgroup_id=req_obj['clbalertgroup_id'])

                obj_clbalertgroup.alert_base_id = obj_clbalertmanagebase
                obj_clbalertgroup.sort_order = req_obj['sort_order']
                obj_clbalertgroup.clb_group_name = req_obj['clb_group_name']
                try:
                    obj_clbalertgroup.save()
                except IntegrityError, e:
                    if e.args[0] == 1062:
                        raise Exception(_(u'Duplicate group name [%s].' % req_obj['clb_group_name']))
                    else:
                        raise Exception('[%s]' % e)
                req_obj['clbalertgroup_id'] = obj_clbalertgroup.pk
                alertgroup_ids.append(obj_clbalertgroup.pk)
                for req_item in req_obj['clbalertgrouphasclbdomain']:
                    obj_grouphasdomain = CLBAlertGroupHasCLBDomain.objects.get(clbalertgrouphasclbdomain_id=req_item['clbalertgrouphasclbdomain_id'])
                    obj_grouphasdomain.clb_alert_group = obj_clbalertgroup
                    obj_grouphasdomain.statmaster_id = req_item['statmaster']
                    obj_grouphasdomain.save()
                    hasdomain_ids.append(obj_grouphasdomain.pk)
                    req_item['clbalertgrouphasclbdomain_id'] = obj_grouphasdomain.pk

            for req_obj in req_data:
                req_obj['clbalertgrouphasclbdomain'].sort(lambda a, b:cmp(a['domain'], b['domain']))

            alertgroup_set = CLBAlertGroup.objects.filter(alert_base_id__account_no=account_no)
            del_related_alertgroup = alertgroup_set.exclude(clbalertgroup_id__in=alertgroup_ids).exclude(group_type=0)
            del_related_recipient = CLBAlertGroupHasRecipients.objects.filter(clb_alert_group__in=del_related_alertgroup)
            del_related_recipient.delete()
            for obj_group in del_related_alertgroup:
                obj_group.delete(request=request)
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
        else:
            transaction.commit()
            return Response(req_data)


    def get(self, request, *args, **kwargs):
        account_no = self.kwargs.get(self.lookup_url_kwarg)
        ret_dic = {}
        default_group_id = 0
        current_domain_dict = {}
        alertgroup_dict = {}
        group_set = CLBAlertGroup.objects.filter(alert_base_id__account_no=account_no)
        for obj in group_set:
            if not ret_dic.has_key(obj.clbalertgroup_id):
                if obj.group_type == 0:
                    default_group_id = obj.clbalertgroup_id
                ret_dic[obj.clbalertgroup_id] = {'clbalertgroup_id':obj.clbalertgroup_id,
                    'clb_group_name':obj.clb_group_name,
                    'group_type':obj.group_type,
                    'sort_order':obj.sort_order,
                    'alert_base_id':obj.alert_base_id.clbalertmanagementbase_id,
                    'clbalertgrouphasclbdomain':[]
                    }
                alertgroup_dict[obj.clbalertgroup_id] = {}
        groupdomain_set = CLBAlertGroupHasCLBDomain.objects.filter(clb_alert_group__alert_base_id__account_no=account_no)
        for obj in groupdomain_set:
            if not alertgroup_dict[obj.clb_alert_group.clbalertgroup_id].has_key(obj.statmaster.stat_id):
                alertgroup_dict[obj.clb_alert_group.clbalertgroup_id][obj.statmaster.stat_id] = \
                                                    {"clbalertgrouphasclbdomain_id":obj.clbalertgrouphasclbdomain_id,
                                                     "statmaster":obj.statmaster.stat_id,
                                                     "domain":obj.statmaster.display_name,
                                                     "deleted":True if obj.statmaster.obj_state != 1 else False}
            current_domain_dict[obj.statmaster.stat_id] = {"stat_id":obj.statmaster.stat_id}

        for obj in alertgroup_dict:
            list_items = alertgroup_dict[obj].values()
            list_items.sort(lambda a, b:cmp(a['domain'], b['domain']))
            ret_dic[obj]['clbalertgrouphasclbdomain'] = list_items

        list_items = ret_dic.items()
        list_items.sort(lambda a, b:cmp(a[1]['sort_order'], b[1]['sort_order']))

        ret_list = [a[1] for a in list_items]

        return Response(ret_list)


class BaseCLBAlertGroupAPI(generics.ListCreateAPIView, \
                     generics.UpdateAPIView, \
                     generics.DestroyAPIView, \
                     SpectrumGenericAPIView):

    queryset = CLBAlertGroup.objects.all()
    serializer_class = BaseCLBAlertGroupSerializer
    lookup_url_kwarg = "clbalertgroup_id"
    filter_fields = ({'account_no':'alert_base_id__account_no'},)


    def get(self, request, *args, **kwargs):
        ret = super(BaseCLBAlertGroupAPI, self).list(request, *args, **kwargs)
        return ret
