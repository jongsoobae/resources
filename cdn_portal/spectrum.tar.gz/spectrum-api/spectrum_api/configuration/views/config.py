# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Rest API
"""
from datetime import datetime
from rest_framework.response import Response

from spectrum_api.configuration.models.config import ConfigGroup,\
    ConfigGroupProduct, ConfigType, ConfigPhase,\
    ConfigJointGroup, ConfigDistAction, ConfigDistState, ConfigDistActionExtra
from spectrum_api.configuration.serializers.config import ConfigGroupSerializer,\
    ConfigGroupProductSerializer, ConfigTypeSerializer, ConfigPhaseSerializer, \
    ConfigJointSerializer, ConfigPushSerializer, ConfigPushStateSerializer
from rest_framework import exceptions
from rest_framework import generics, filters
from django.db.models import Max
from django.db import transaction
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from rest_framework import status
from spectrum_api.shared_components.utils.user_util import getPrismUserObj
from spectrum_api.shared_components.mixins import CreateModelMixin, ListModelMixin, RetrieveModelMixin
from spectrum_api.shared_components.utils.common import log_error
from django.utils.translation import ugettext as _

class ConfigAPIException(exceptions.APIException):
    def __init__(self, status_code, detail):
        self.status_code = status_code
        super(ConfigAPIException, self).__init__(detail=detail)

class ConfigGroupAPI(ListModelMixin,
                     SpectrumGenericAPIView):
    queryset = ConfigGroup.objects.filter(obj_state=1).all()

    serializer_class = ConfigGroupSerializer
    lookup_url_kwarg = "config_group_id"
    paginate_by = None

    def get(self, request, *args, **kwargs):
        return super(ConfigGroupAPI, self).list(request, *args, **kwargs)

class ConfigGroupDetailAPI(RetrieveModelMixin,
                           SpectrumGenericAPIView):
    queryset = ConfigGroup.objects.filter(obj_state=1).all()

    filter_backends = (filters.SearchFilter,)
    search_fields = ('config_group_id',)
    serializer_class = ConfigGroupSerializer
    lookup_url_kwarg = 'config_group_id'

    def get(self, request, *args, **kwargs):
        return super(ConfigGroupDetailAPI, self).retrieve(request, *args, **kwargs)


class ConfigGroupProductAPI(ListModelMixin,
                            SpectrumGenericAPIView):
    queryset = ConfigGroupProduct.objects.filter(obj_state=1).all()
    search_fields = ('product',)
    filter_fields = ('product',)

    serializer_class = ConfigGroupProductSerializer
    lookup_url_kwarg = "config_group_product_id"
    paginate_by = None

    def get(self, request, *args, **kwargs):
        return super(ConfigGroupProductAPI, self).list(request, *args, **kwargs)


class ConfigTypeAPI(ListModelMixin,
                    SpectrumGenericAPIView):
    queryset = ConfigType.objects.filter(obj_state=1).all()
    search_fields = ('config_group__config_group_id',)
    filter_fields = ({'config_group_id':'config_group__config_group_id'},)

    serializer_class = ConfigTypeSerializer
    lookup_url_kwarg = "config_type_id"
    paginate_by = None

    def get(self, request, *args, **kwargs):
        return super(ConfigTypeAPI, self).list(request, *args, **kwargs)


class ConfigPhaseAPI(ListModelMixin,
                     SpectrumGenericAPIView):
    queryset = ConfigPhase.objects.filter(obj_state=1).all()
    search_fields = ('config_type__config_type_id', 'config_type__name',)
    filter_fields = ({'config_type_id':'config_type__config_type_id'}, {'config_type_name':'config_type__name'}, {'config_group_id':'config_type__config_group__config_group_id'}, {'config_group_name':'config_type__config_group__name'},'name')

    serializer_class = ConfigPhaseSerializer
    lookup_url_kwarg = "config_phase_id"
    paginate_by = None

    def get(self, request, *args, **kwargs):
        return super(ConfigPhaseAPI, self).list(request, *args, **kwargs)


class ConfigJointAPI(ListModelMixin,
                     SpectrumGenericAPIView):
    queryset = ConfigJointGroup.objects.filter(obj_state=1).all()

    serializer_class = ConfigJointSerializer
    lookup_url_kwarg = "config_joint_group_id"
    paginate_by = None

    def get(self, request, *args, **kwargs):
        return super(ConfigJointAPI, self).list(request, *args, **kwargs)

class ConfigPushAPI(ListModelMixin,
                    CreateModelMixin,
                    SpectrumGenericAPIView):
    queryset = ConfigDistAction.objects.all()
    search_fields = ('to_phase__config_type__config_group__config_group_id', 'to_phase__config_type__config_group__name',
                     'to_phase__config_type__config_type_id', 'to_phase__config_type__name', 'config_joint__config_joint_id',)
    filter_fields = ({"config_group_id":'to_phase__config_type__config_group__config_group_id'},
                    {"config_group_name":'to_phase__config_type__config_group__name'},
                    {"config_type_id":'to_phase__config_type__config_type_id'},
                    {"config_type_name":'to_phase__config_type__name'},
                    {"config_joint_id":'config_joint__config_joint_id'},
                    {"action": "action_id"}, {"parent_id": "parent_joint_action_id"},)
#{"status_msg":"status_msg"},
    serializer_class = ConfigPushSerializer
    lookup_url_kwarg = "action_id"

    def get(self, request, *args, **kwargs):
        return super(ConfigPushAPI, self).list(request, *args, **kwargs)

    @transaction.commit_manually
    def post(self, request, *args, **kwargs):
        result = False
        config_group_id = -1
        config_type_id = -1
        action_keyword = None
        config_desc = None
        config_joint_id = None
        revision = -1
        rollback = 'false'
        parent_joint_action_id = None
        to_phase_id = 0
        status_msg = None
        clb_flag = 0
        config_phase_id = None
        inserted_action_id = []

        data = self.request.DATA
        if data.has_key('config_group_id') and data['config_group_id']:
            config_group_id = data['config_group_id']
        if data.has_key('config_type_id') and data['config_type_id']:
            config_type_id = int(data['config_type_id'])
        if data.has_key('config_phase_id') and data['config_phase_id']:
            config_phase_id = int(data['config_phase_id'])
        if data.has_key('action_keyword') and data['action_keyword']:
            action_keyword = data['action_keyword']
        if data.has_key('description') and data['description']:
            config_desc = data['description']
        if data.has_key('config_joint_id') and data['config_joint_id']:
            config_joint_id = int(data['config_joint_id'])
        if data.has_key('revision') and data['revision']:
            revision = int(data['revision'])
        if data.has_key('rollback') and data['rollback']:
            rollback = data['rollback']

        # validate
        if revision < -1 or revision > 2147483647:
            transaction.rollback()
            raise ConfigAPIException(status.HTTP_400_BAD_REQUEST, _('revision is invalid.'))

        # promote
        if data.has_key('action_id') and data['action_id']:
            action_id = data['action_id']

        # promete (NON-SEQUENCIAL VERSION)
        if data.has_key('to_phase_id') and data['to_phase_id']:
            to_phase_id = data['to_phase_id']

        if data.has_key('status_msg') and data['status_msg']:
            status_msg = data['status_msg']

        if data.has_key('clb_flag') and data['clb_flag']:
            clb_flag = int(data['clb_flag'])

        try:
            context = data.get("context", None)
            if type(context) is dict:
                pass
            else:
                context = None

        except Exception as e:
            log_error(request, "failed : get config dist action context", e)
            context = None

        if config_joint_id and config_joint_id > 0:
            joint_action_id = joint_push(
                self.request, config_joint_id, revision=revision, action_keyword=action_keyword,
                config_desc=config_desc, rollback=rollback, status_msg=status_msg,
                clb_flag=clb_flag, context=context)
            return Response({'joint_action_id': joint_action_id})
        else :
            try:
                if data.has_key('indiv') and data['indiv'] :
                    result = config_push_promote(request, action_id, config_type_id, rollback)
                elif to_phase_id > 0:
                    result = config_push_promote_nonseq(request, action_id, to_phase_id)
                else :
                    result = config_push(self.request, config_group_id, config_type_id, revision, action_keyword, config_desc, config_joint_id, parent_joint_action_id, rollback, status_msg, clb_flag, context=context, config_phase_id=config_phase_id)

                if result['status_code'] != status.HTTP_200_OK:
                    transaction.rollback()
                    raise ConfigAPIException(result['status_code'], result['detail'])

            except:
                transaction.rollback()
                raise ConfigAPIException(result['status_code'], result['detail'])
            else :
                transaction.commit()
                output = {'action_id' : result['detail']}
                return Response(output)

class ConfigActionPromotedAPI(ListModelMixin, SpectrumGenericAPIView):
    def get(self, request, *args, **kwargs):
        promoted_action_id_list = []

        config_group_name = self.request.GET.get('config_group_name', None)
        action_ids = self.request.GET.get('action_id_list')
        try:
            action_id_list = [int(action_id) for action_id in action_ids.split(",")]
            dist_actions= ConfigDistAction.objects.filter(action_id__in=action_id_list) #.values_list('parent_joint_action_id',flat=True)
            parent_action_id_list = []
            for dist_action in dist_actions:
                is_already_deployed, related_action_id = dist_action.check_if_already_deployed_http_sites_push()
                if related_action_id:
                    parent_action_id_list.append(related_action_id)
                else:
                    promoted_action_id_list.append({'action_id':dist_action.pk,
                                                    'group':dist_action.to_phase.config_type.config_group.name,
                                                    'parent_joint_action_id':None})
            promoted_actions = ConfigDistAction.objects.filter(parent_joint_action_id__in=parent_action_id_list)
            if config_group_name:
                promoted_actions = promoted_actions.filter(to_phase__config_type__config_group__name=config_group_name)

            for promoted in promoted_actions:
                promoted_action_id_list.append({'action_id':promoted.action_id,
                                        'group': promoted.to_phase.config_type.config_group.name,
                                        'parent_joint_action_id':promoted.parent_joint_action_id})
        except Exception,e:
            pass

        return Response(promoted_action_id_list)

class ConfigPushStateAPI(ListModelMixin,
                         SpectrumGenericAPIView):
    queryset = ConfigDistState.objects.filter().all()
    search_fields = ('action__to_phase__config_type__config_group__config_group_id', 'action__to_phase__config_type__config_group__name', 'action__to_phase__config_type__config_type_id', 'action__to_phase__config_type__name',)
    filter_fields = ({"config_group_id":'action__to_phase__config_type__config_group__config_group_id'}, {"config_group_name":'action__to_phase__config_type__config_group__name'}, {"config_type_id":'action__to_phase__config_type__config_type_id'}, {"config_type_name":'action__to_phase__config_type__name'},)

    serializer_class = ConfigPushStateSerializer
    lookup_url_kwarg = "phase"
    paginate_by = None

    def get(self, request, *args, **kwargs):
        return super(ConfigPushStateAPI, self).list(request, *args, **kwargs)


def get_config_extra_keys():
    __CONFIG_EXTRA_KEY__ = {
        'GSLB' : "zone_id",
    }

    return __CONFIG_EXTRA_KEY__

def get_extra_key_from_config_group_name(config_group_name):
    __CONFIG_EXTRA_KEY__ = get_config_extra_keys()
    try:
        _group_name = config_group_name.strip().upper()
        if is_config_group_require_extra_data(_group_name):
            if _group_name in __CONFIG_EXTRA_KEY__.keys():
                return __CONFIG_EXTRA_KEY__.get(_group_name)
            else:
                raise Exception("'%s' is missing in __CONFIG_EXTRA_KEY__"%(_group_name))
    except Exception as e:
        log_error({}, "failed : got error when return config group's extra key name'%s'"%(config_group_name), e)
        return None

def is_config_group_require_extra_data(config_group_name):
    __REQUIRED_EXTRA_DATA_CONFIG_GROUP__ = get_config_extra_keys().keys()
    try:
        _group_name = config_group_name.strip().upper()
        if _group_name in __REQUIRED_EXTRA_DATA_CONFIG_GROUP__:
            return True
        else:
            return False
    except Exception as e:
        log_error({}, "failed : got error when check config group required extra data'%s'"%(config_group_name), e)
        return False

def _check_required_extra_data(config_group_name, context=None):
    """
    Check config group need to additional data for config dist action.

    :param config_group: config group name
    :type config_group: string

    :param context: config dist action extra data
    :type context: dict

    :returns: return required or not and config EXTRA KEY name,
    :rtype: bool, string
    """
    try:
        _group_name = config_group_name.strip().upper()
        if is_config_group_require_extra_data(_group_name):

            if context is None:
                return False, None

            if context.get(get_extra_key_from_config_group_name(_group_name), None) is not None:
                return True, get_extra_key_from_config_group_name(_group_name)
            else:
                return False, None

        else:
            return False, None

    except Exception as e:
        log_error({}, "failed : got error when check config group name '%s'"%(config_group_name), e)
        return False, None

def config_push(request, config_group_id= -1, config_type_id= -1, revision= -1, action_keyword="", desc="", config_joint_id=None, parent_joint_action_id=None, rollback='false', status_msg="", clb_flag=0, context=None, config_phase_id=None):
    try:
        user = getPrismUserObj(request)

        try:
            if config_type_id > 0:
                initial_phase = ConfigPhase.objects.filter(config_type=config_type_id)[0]
            elif config_phase_id:
                initial_phase = ConfigPhase.objects.get(pk=config_phase_id)
        except Exception as e:
            raise e

        max_version_num = ConfigDistState.objects.filter(phase__config_type=initial_phase.config_type).aggregate(Max('action__config_revision')).get('action__config_revision__max', None)

        if rollback == 'true':
            # allow rollback for only superuser
            if initial_phase and user.is_superuser:
                # check user specified version number is less than the max
                if max_version_num and revision >= max_version_num:
                    return {"status_code":status.HTTP_400_BAD_REQUEST, "detail":_('Revision number too big.')}
                else:
                    cda_new = ConfigDistAction(to_phase=initial_phase,
                                            config_revision=revision,
                                            user=user,
                                            action_keyword=action_keyword,
                                            description=desc[:1023] if len(desc) > 1023 else desc,
                                            status=6,
                                            status_msg=status_msg)

                    cda_new.save(request=request, clb_flag=clb_flag)
                    return {"status_code":status.HTTP_200_OK, "detail":cda_new.pk}
            else:
                return {"status_code":status.HTTP_400_BAD_REQUEST, "detail":_('Not initial phase or user is not superuser.')}

        else:
            if initial_phase:
                if max_version_num and revision > 0 and revision > max_version_num:
                    cda_new = ConfigDistAction(to_phase=initial_phase,
                                               action_keyword=action_keyword,
                                               description=desc,
                                               user=user,
                                               config_joint=config_joint_id,
                                               parent_joint_action_id=parent_joint_action_id,
                                               config_revision=revision,
                                               status_msg=status_msg)
                    cda_new.save(request=request, clb_flag=clb_flag)
                    return {"status_code":status.HTTP_200_OK, "detail":cda_new.pk}
                elif revision == -1:
                    is_extra_, extra_data_key = _check_required_extra_data(
                                                                initial_phase.config_type.config_group.name,
                                                                context
                                                            )

                    cda_new = ConfigDistAction(to_phase=initial_phase,
                                               action_keyword=action_keyword,
                                               description=desc,
                                               user=user,
                                               config_joint_id=config_joint_id,
                                               parent_joint_action_id=parent_joint_action_id,
                                               status_msg=status_msg)
                    cda_new.save(request=request, clb_flag=clb_flag)

                    if is_extra_:
                        extra_data = context.get(extra_data_key, None)
                        if type(extra_data) is list:
                            pass
                        else:
                            extra_data = [extra_data]

                        try:
                            for target_pk in extra_data:
                                extra_ = ConfigDistActionExtra(action=cda_new,
                                                    condition_field=extra_data_key,
                                                    data=target_pk)
                                extra_.save()
                        except Exception as e:
                            log_error(request, "Got Error when insert extra data.")
                            return {"detail": _("Occured system error (-3)")}

                    return {"status_code":status.HTTP_200_OK, "detail":cda_new.pk}
                else:
                    return {"status_code":status.HTTP_400_BAD_REQUEST, "detail":_('Revision number too small')}
            else:
                return {"status_code":status.HTTP_400_BAD_REQUEST, "detail":_('Not initial phase')}
        #if config_type_id > 0:
        #else:
        #    error_msg = ''
        #
        #    if config_type_id == -1:
        #        error_msg = _('config_type required.')
        #   return {"status_code":status.HTTP_400_BAD_REQUEST, "detail":error_msg}
    except Exception, e:
        return {"status_code":status.HTTP_500_INTERNAL_SERVER_ERROR, "detail":str(e)}


def joint_group_type_info(config_joint_id):
    from django.db import connections

    sql = """
            SELECT c.config_group_id, c.config_type_id
            FROM config_joint_group a
            INNER JOIN config_phase b
            ON a.config_phase_id = b.config_phase_id
            INNER JOIN config_type c
            ON b.config_type_id = c.config_type_id
            WHERE a.config_joint_id=%d
            AND a.obj_state=1
            AND b.obj_state=1
            AND c.obj_state=1
            ORDER BY config_group_id
            """ % config_joint_id
    cursor = connections['default'].cursor()
    cursor.execute(sql)
    rs = cursor.fetchall()

    config_info = []

    for obj in rs:
        config_info.append({'config_group_id':obj[0], 'config_type_id':obj[1]})

    return config_info


def config_push_promote(request, action_id, config_type_id, rollback):
    GOLD_PHASE = 1000

    user = getPrismUserObj(request)

    if rollback == "true":
        # allow rollback for only superuser
        if user.is_superuser:
            # get revision number from Gold
            cds = ConfigDistState.objects.get(action=action_id, phase__config_type=config_type_id, phase__sequence=GOLD_PHASE)
            config_revision = cds.action.config_revision

            # get all phases and rollback with the revision number
            if cds.phase.config_type.is_sequence:
                all_states = ConfigDistState.objects.filter(phase__config_type=config_type_id).exclude(phase__sequence=GOLD_PHASE)
                first_state = all_states[0].phase

                for index, state in enumerate(all_states):

                    if index == 0:
                        cda_new = ConfigDistAction(to_phase=state.phase, config_revision=config_revision, user=user, status=6)
                    else:
                        cda_new = ConfigDistAction(to_phase=state.phase, from_phase=first_state, config_revision= -1, user=user, status=6)
                    cda_new.save(request=request)
            else:
                pass

            return {"status_code":status.HTTP_200_OK, "detail":cda_new.pk}
        else:
            return {"status_code":status.HTTP_400_BAD_REQUEST, "detail":_('User is not superuser.')}
    else:
        try:
            this_state = ConfigDistState.objects.get(action=action_id, phase__config_type=config_type_id)
        except:
            this_state = None

        try:
            next_phase = ConfigPhase.objects.filter(config_type=config_type_id, sequence__gt=this_state.phase.sequence)[0]
        except:
            next_phase = None

        # if there is a next phase promote to next phase
        if next_phase and this_state:
            if next_phase.sequence == GOLD_PHASE:
                try:
                    # if gold phase is already in State Table
                    seek_for_gold = ConfigDistState.objects.get(phase__config_type=config_type_id, phase__sequence=GOLD_PHASE)

                    # insert new action
                    cda_new = ConfigDistAction(to_phase=seek_for_gold.phase, from_phase=this_state.phase, config_revision=this_state.action.config_revision, user=user, status=4, time_deployed=datetime.now())
                    cda_new.save(request=request)

                    # replace existing with new action
                    seek_for_gold.action = cda_new
                    seek_for_gold.save(request=request)
                except:
                    # if gold phase is not in State Table
                    # just create action
                    gold_phase = ConfigPhase.objects.get(config_type=config_type_id, sequence=GOLD_PHASE)

                    # insert new action
                    cda_new = ConfigDistAction(to_phase=gold_phase, from_phase=this_state.phase, config_revision=this_state.action.config_revision, user=user, status=4, time_deployed=datetime.now())
                    cda_new.save(request=request)

                    this_state.phase = gold_phase
                    this_state.save(request=request)
            else:
                # insert new action
                cda_new = ConfigDistAction(to_phase=next_phase, from_phase=this_state.phase, config_revision=this_state.action.config_revision, user=user)
                cda_new.save(request=request)

            return {"status_code":status.HTTP_200_OK, "detail":cda_new.pk}
        else:
            return {"status_code":status.HTTP_400_BAD_REQUEST, "detail":_('next_phase and this_state required.')}

def config_push_promote_nonseq(request, action_id, to_phase_id):
    try:
        user = getPrismUserObj(request)
        current_state = ConfigDistState.objects.get(action=action_id)
        to_phase = ConfigPhase.objects.get(pk=to_phase_id)
        from_phase = ConfigPhase.objects.get(pk=current_state.phase.config_phase_id)

        cda_new = ConfigDistAction(to_phase=to_phase, from_phase=from_phase, config_revision=current_state.action.config_revision, user=user)
        cda_new.save(request=request)

        return {"status_code":status.HTTP_200_OK, "detail":cda_new.pk}
    except Exception, e:
        return {"status_code":status.HTTP_500_INTERNAL_SERVER_ERROR, "detail":str(e)}


def joint_push(request, config_joint_id,
               revision=-1, action_keyword=None, config_desc=None, rollback='false', status_msg=None,
               clb_flag=0, context=None):
    """
        Raises:
          ConfigAPIException: If failed to push.
    """

    inserted_action_id = []
    parent_joint_action_id = None

    try:
        joint_info = joint_group_type_info(config_joint_id)

        is_first = True

        for arr in joint_info:
            config_group_id = arr['config_group_id']
            config_type_id = arr['config_type_id']

            result = config_push(
                request, config_group_id, config_type_id, revision, action_keyword, config_desc,
                config_joint_id, parent_joint_action_id, rollback, status_msg, clb_flag, context=context)

            if result['status_code'] != status.HTTP_200_OK:
                transaction.rollback()
                raise ConfigAPIException(status_code=result['status_code'], detail=result['detail'])
            else:
                first_action_id = int(result['detail'])
                if is_first:
                    parent_joint_action_id = first_action_id
                    is_first = False

            inserted_action_id.append(int(result['detail']))

    except:
        transaction.rollback()
        raise ConfigAPIException(result['status_code'], result['detail'])

    else:
        query_set = ConfigDistAction.objects.filter(action_id__in=inserted_action_id)
        query_set.update(parent_joint_action_id=parent_joint_action_id)
        transaction.commit()
        return parent_joint_action_id