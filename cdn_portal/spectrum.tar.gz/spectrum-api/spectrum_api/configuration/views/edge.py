# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Rest API
"""
from django.utils.translation import ugettext as _
from rest_framework import exceptions
from rest_framework.status import HTTP_404_NOT_FOUND, HTTP_403_FORBIDDEN, \
                                HTTP_500_INTERNAL_SERVER_ERROR
from rest_framework.response import Response
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.mixins import CreateModelMixin, UpdateModelMixin, DestroyModelMixin, \
                                                ListModelMixin, RetrieveModelMixin
from spectrum_api.configuration.models.base import Edge, EdgeAll, BaseVipEdge
from spectrum_api.configuration.serializers.base import EdgeSerializer, EdgeAllSerializer, EdgeDetailSerializer, EdgeSimpleSerializer

from spectrum_api.dna.models.domain import DomainEdge

class EdgeDoseNotExist(exceptions.APIException):
    status_code = HTTP_404_NOT_FOUND
    default_detail = _('You access does not exists Edge')

class EdgeDeleteNotAllowed(exceptions.APIException):
    status_code = HTTP_403_FORBIDDEN
    default_detail = _("You can not delete this edge")

class EdgeModifyNotAllowed(exceptions.APIException):
    status_code = HTTP_403_FORBIDDEN
    default_detail = _("You can not modify this edge")

class ServiceUnavailable(exceptions.APIException):
    status_code = HTTP_500_INTERNAL_SERVER_ERROR
    default_detail = _("Occured internal failure. Please request later")

class EdgeAPI(ListModelMixin,
            CreateModelMixin,
            UpdateModelMixin,
            DestroyModelMixin,
            SpectrumGenericAPIView):
    queryset = Edge.objects.all()
    serializer_class = EdgeSerializer
    lookup_url_kwarg = "edge_id"
    search_fields = ("name", "description",)
    filter_fields = ("name", "description",)
    request = None

    def get(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        lite = request.QUERY_PARAMS.get("lite", None)
        if lite:
            self.serializer_class = EdgeSimpleSerializer
        else:
            self.queryset = EdgeAll.objects.all()
            self.serializer_class = EdgeAllSerializer

        return super(EdgeAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        self.request = request
        return super(EdgeAPI, self).create(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        self.request = request
        return super(EdgeAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        self.request = request
        return super(EdgeAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise EdgeDeleteNotAllowed

    def post_save(self, obj, created=False):
        if hasattr(obj, "__iter__"):
            for item in obj:
                item.add_required_probeconfigs(request=self.request)
        else:
            obj.add_required_probeconfigs(request=self.request)

    def delete(self, request, *args, **kwargs):
        return super(EdgeAPI, self).destroy(request, *args, **kwargs)


class EdgeDetailAPI(RetrieveModelMixin,
                    UpdateModelMixin,
                    DestroyModelMixin,
                    SpectrumGenericAPIView):
    queryset = Edge.objects.all()
    serializer_class = EdgeDetailSerializer
    lookup_url_kwarg = 'edge_id'
    request = None

    def get(self, request, *args, **kwargs):
        return super(EdgeDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        self.request = request
        return super(EdgeDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        self.request = request
        return super(EdgeDetailAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise EdgeDeleteNotAllowed

    def post_save(self, obj, created=False):
        obj.add_required_probeconfigs(request=self.request)

    def delete(self, request, *args, **kwargs):
        return super(EdgeDetailAPI, self).destroy(request, *args, **kwargs)

class EdgeRelatedAPI(RetrieveModelMixin,
                    SpectrumGenericAPIView):
    queryset = Edge.objects.all()
    serializer_class = EdgeDetailSerializer
    lookup_url_kwarg = 'edge_id'

    def get(self, request, *args, **kwargs):
        related_items = {}
        try:
            edge_id = self.kwargs.pop(self.lookup_url_kwarg)

            edge = Edge.objects.get(edge_id=edge_id)
            edge_items = edge.get_related_items()

            is_deletable = edge.is_deletable()

            for items in edge_items:
                key = unicode(items[0].__name__.lower())
                sub_items = []
                for sub_item in items[1]:
                    sub_items.append({"id": sub_item.pk, "name":"%s" % sub_item})

                related_items.update({key: sub_items})

            related_items.update({"is_deletable": is_deletable})
            return Response(related_items)
        except Edge.DoesNotExist:
            raise EdgeDoseNotExist
        except Exception, e:
            raise ServiceUnavailable
