# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Rest API
"""
from django.utils.translation import ugettext as _

from rest_framework.exceptions import APIException
from rest_framework.response import Response

from rest_framework.status import HTTP_400_BAD_REQUEST
from rest_framework.status import HTTP_403_FORBIDDEN
from rest_framework.status import HTTP_404_NOT_FOUND

from spectrum_api.shared_components.generics import SpectrumGenericAPIView

from spectrum_api.shared_components.mixins import ListModelMixin
from spectrum_api.shared_components.mixins import RetrieveModelMixin
from spectrum_api.shared_components.mixins import CreateModelMixin
from spectrum_api.shared_components.mixins import UpdateModelMixin
from spectrum_api.shared_components.mixins import DestroyModelMixin

from spectrum_api.configuration.models.preset_relay import MproxyPreset, MproxyRelays, \
    MproxyPresetRelay
from spectrum_api.configuration.serializers.preset_relay import MproxyPresetSerializer
from spectrum_api.configuration.serializers.preset_relay import MproxyRelaysSerializer
from spectrum_api.configuration.serializers.preset_relay import MproxyPresetRelaySerializer
from spectrum_api.configuration.serializers.preset_relay import MproxyPresetRelayListSerializer

__PRESET_URL_LOOKUP_KEY__ = "preset_id"
__RELAY_URL_LOOKUP_KEY__ = "relay_id"


class AccessInvalidPresetID(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = 'Preset ID Missing'

class AccessInvalidRelayID(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = 'Relay ID Missing'

class MproxyPresetDoesNotExist(APIException):
    status_code = HTTP_404_NOT_FOUND
    default_detail = _(u'You requested a Pre-set which does not exists.')
# 
class ObjDeleteNotAllowed(APIException):
    status_code = HTTP_403_FORBIDDEN
    default_detail = _("You can not delete this Pre-set")
 
    def __init__(self, *args, **kwargs):
        obj_name = kwargs.pop('obj_name', '')
        except_msg = kwargs.pop('except_msg', None)
        default_detail = "You can not delete this %s" % obj_name
        if except_msg:
            default_detail = "%s, %s" % (default_detail, except_msg)
        self.default_detail = _("%s" % default_detail)
        super(ObjDeleteNotAllowed, self).__init__(*args, **kwargs)

class PresetListAPI(ListModelMixin,
                    SpectrumGenericAPIView):
    queryset = MproxyPreset.objects.all()
    serializer_class = MproxyPresetSerializer
    lookup_url_kwarg = __PRESET_URL_LOOKUP_KEY__
    search_fields = ('preset_name',)
    ordering = 'preset_id'
  
    def get(self, request, *args, **kwargs):
        return super(PresetListAPI, self).list(request, *args, **kwargs)

class PresetRelayAddAPI(RetrieveModelMixin, 
                        CreateModelMixin,
                        SpectrumGenericAPIView):
    queryset = MproxyPreset.objects.all()
    serializer_class = MproxyPresetRelaySerializer
    lookup_url_kwarg = __PRESET_URL_LOOKUP_KEY__

    def post(self, request, *args, **kwargs):
        return super(PresetRelayAddAPI, self).create(request, *args, **kwargs)

class PresetRelayInfoAPI(RetrieveModelMixin,
                         UpdateModelMixin,
                         DestroyModelMixin,
                         SpectrumGenericAPIView):
    queryset = MproxyPreset.objects.all()
    serializer_class = MproxyPresetRelaySerializer
    lookup_url_kwarg = __PRESET_URL_LOOKUP_KEY__

    def get(self, request, *args, **kwargs):
        return super(PresetRelayInfoAPI, self).retrieve(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(PresetRelayInfoAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ObjDeleteNotAllowed(obj_name='Pre-set')

    def delete(self, request, *args, **kwargs):
        return super(PresetRelayInfoAPI, self).destroy(request, *args, **kwargs)

class PresetRelatedItemAPI(SpectrumGenericAPIView):
    lookup_url_kwarg = "preset_id"

    def get(self, request, *args, **kwargs):
        related_items = {}
        try:
            preset_id = self.kwargs.pop(self.lookup_url_kwarg)

            preset = MproxyPreset.objects.get(pk=int(preset_id))
            preset_items = preset.get_related_objects()

            for items in preset_items:
                key = unicode(items[0].__name__)
                sub_items = []
                for sub_item in items[1]:
                    sub_items.append("%s" % sub_item)

                if len(sub_items) > 0:
                    related_items.update({key: sub_items})
            related_items["is_deletable"] = preset.is_deletable()
            return Response(related_items)
        except KeyError:
            raise AccessInvalidPresetID
        except MproxyPreset.DoesNotExist:
            raise MproxyPresetDoesNotExist
        except:
            raise APIException(detail=_(u"Occured system failure"))

class PresetRelayListAPI(ListModelMixin,
                         SpectrumGenericAPIView):
    queryset = MproxyPresetRelay.objects.all()
    serializer_class = MproxyPresetRelayListSerializer
    lookup_url_kwarg = __PRESET_URL_LOOKUP_KEY__
    search_fields = ('preset_name','preset_id',)
    ordering = 'preset_id'

    def get(self, request, *args, **kwargs):
        return super(PresetRelayListAPI, self).list(request, *args, **kwargs)

class PresetRelayDetailAPI(RetrieveModelMixin,
                           SpectrumGenericAPIView):
    queryset = MproxyPresetRelay.objects.all()
    serializer_class = MproxyPresetRelayListSerializer
    lookup_url_kwarg = __PRESET_URL_LOOKUP_KEY__

    def get(self, request, *args, **kwargs):
        return super(PresetRelayDetailAPI, self).retrieve(request, *args, **kwargs)

