# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Rest API
"""

from rest_framework.response import Response
from rest_framework.exceptions import APIException
from rest_framework.status import HTTP_404_NOT_FOUND, HTTP_403_FORBIDDEN, HTTP_400_BAD_REQUEST

from spectrum_api.configuration.models.base import BaseProbeConfig, ProbeConfigStandaloneICMP, ProbeConfigStandaloneSNMP, \
    ProbeConfigStandaloneTCP, ProbeConfigStandaloneSSL, ProbeConfigStandaloneUDP, ProbeConfigStandaloneFTP, ProbeConfigStandaloneRTMP, \
    ProbeConfigStandaloneDNS, ProbeConfigAggregate, VipProbeConfigs, ProbeConfigAggregateProbe
from spectrum_api.configuration.models.base import PROBE_TYPES
from spectrum_api.dna.models.domain import Domain, DomainVip, DomainEdge

from spectrum_api.configuration.serializers.probe import ProbeSerializer, ProbeIcmpSerializer, ProbeSnmpSerializer, ProbeTcpSerializer, \
    ProbeSslSerializer, ProbeUdpSerializer, ProbeFtpSerializer, ProbeRtmpSerializer, ProbeDnsSerializer, ProbeAggregateSerializer, \
    ProbeVipSerializer, ProbeDomainSerializer, ProbeDeletableSerializer, ProbeNameSerializer, ProbeRelatedAggregateSerializer, \
    ProbeDomainVipSerializer, ProbeDomainEdgeSerializer

from rest_framework import filters
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.mixins import CreateModelMixin, UpdateModelMixin, DestroyModelMixin, \
                                                ListModelMixin, RetrieveModelMixin
from django.utils.translation import ugettext as _


def get_probe_id(BaseProbeConfig):
    return BaseProbeConfig.get("probeconfig_id")

class ProbeDoseNotExist(APIException):
    status_code = HTTP_404_NOT_FOUND
    default_detail = _('You access does not exists Probe config')

class ProbeDeleteNotAllowed(APIException):
    status_code = HTTP_403_FORBIDDEN
    default_detail = _("You can not delete this Probe config")

class AccessInvalidProbeID(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = 'Probe ID Missing'

class ProbeDoesNotExist(APIException):
    status_code = HTTP_404_NOT_FOUND
    default_detail = _(u'You requested a probe which does not exists.')


class ProbeTypeAPI(SpectrumGenericAPIView):
    def get(self, request, *args, **kwargs):
        probe_type = [{'probe_type':t[0], 'probe_type_name':t[1]} for t in PROBE_TYPES]
        return Response(probe_type)


class ProbeAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = BaseProbeConfig.objects.all()
    search_fields = ('name', 'probe_type',)
    filter_fields = ('name', 'probe_type',)

    serializer_class = ProbeSerializer
    lookup_url_kwarg = "probeconfig_id"

    def get(self, request, *args, **kwargs):
        return super(ProbeAPI, self).list(request, *args, **kwargs)

class ProbeNameAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = BaseProbeConfig.objects.all()
    search_fields = ('name',)
    filter_fields = ('name',)

    serializer_class = ProbeNameSerializer
    lookup_url_kwarg = "probeconfig_id"

    def get(self, request, *args, **kwargs):
        return super(ProbeNameAPI, self).list(request, *args, **kwargs)

class ProbeIcmpAPI(ListModelMixin,
                   CreateModelMixin,
                   UpdateModelMixin,
                   DestroyModelMixin,
                   SpectrumGenericAPIView):
    queryset = ProbeConfigStandaloneICMP.objects.all()
    search_fields = ('name', 'probe_type',)
    filter_fields = ('name', 'probe_type',)

    serializer_class = ProbeIcmpSerializer
    lookup_url_kwarg = "probeconfig_id"

    def get(self, request, *args, **kwargs):
        return super(ProbeIcmpAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(ProbeIcmpAPI, self).create(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeIcmpAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeIcmpAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeIcmpAPI, self).destroy(request, *args, **kwargs)

class ProbeIcmpDetailAPI(RetrieveModelMixin,
                         UpdateModelMixin,
                         DestroyModelMixin,
                         SpectrumGenericAPIView):
    queryset = ProbeConfigStandaloneICMP.objects.all()

    filter_backends = (filters.SearchFilter,)
    search_fields = ('name', 'probe_type',)
    serializer_class = ProbeIcmpSerializer
    lookup_url_kwarg = 'probeconfig_id'

    def get(self, request, *args, **kwargs):
        return super(ProbeIcmpDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeIcmpDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeIcmpDetailAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeIcmpDetailAPI, self).destroy(request, *args, **kwargs)


class ProbeSnmpAPI(ListModelMixin,
                   CreateModelMixin,
                   UpdateModelMixin,
                   DestroyModelMixin,
                   SpectrumGenericAPIView):
    queryset = ProbeConfigStandaloneSNMP.objects.all()
    search_fields = ('name', 'probe_type',)
    filter_fields = ('name', 'probe_type',)

    serializer_class = ProbeSnmpSerializer
    lookup_url_kwarg = "probeconfig_id"

    def get(self, request, *args, **kwargs):
        return super(ProbeSnmpAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(ProbeSnmpAPI, self).create(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeSnmpAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeSnmpAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeSnmpAPI, self).destroy(request, *args, **kwargs)


class ProbeSnmpDetailAPI(RetrieveModelMixin,
                         UpdateModelMixin,
                         DestroyModelMixin,
                         SpectrumGenericAPIView):
    queryset = ProbeConfigStandaloneSNMP.objects.all()

    filter_backends = (filters.SearchFilter,)
    search_fields = ('name', 'probe_type',)
    serializer_class = ProbeSnmpSerializer
    lookup_url_kwarg = 'probeconfig_id'

    def get(self, request, *args, **kwargs):
        return super(ProbeSnmpDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeSnmpDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeSnmpDetailAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeSnmpDetailAPI, self).destroy(request, *args, **kwargs)

class ProbeTcpAPI(ListModelMixin,
                   CreateModelMixin,
                   UpdateModelMixin,
                   DestroyModelMixin,
                   SpectrumGenericAPIView):
    queryset = ProbeConfigStandaloneTCP.objects.all()
    search_fields = ('name', 'probe_type',)
    filter_fields = ('name', 'probe_type',)

    serializer_class = ProbeTcpSerializer
    lookup_url_kwarg = "probeconfig_id"

    def get(self, request, *args, **kwargs):
        return super(ProbeTcpAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(ProbeTcpAPI, self).create(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeTcpAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeTcpAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeTcpAPI, self).destroy(request, *args, **kwargs)


class ProbeTcpDetailAPI(RetrieveModelMixin,
                        UpdateModelMixin,
                        DestroyModelMixin,
                        SpectrumGenericAPIView):
    queryset = ProbeConfigStandaloneTCP.objects.all()

    filter_backends = (filters.SearchFilter,)
    search_fields = ('name', 'probe_type',)
    serializer_class = ProbeTcpSerializer
    lookup_url_kwarg = 'probeconfig_id'

    def get(self, request, *args, **kwargs):
        return super(ProbeTcpDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeTcpDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeTcpDetailAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeTcpDetailAPI, self).destroy(request, *args, **kwargs)

class ProbeSslAPI(ListModelMixin,
                   CreateModelMixin,
                   UpdateModelMixin,
                   DestroyModelMixin,
                   SpectrumGenericAPIView):
    queryset = ProbeConfigStandaloneSSL.objects.all()
    search_fields = ('name', 'probe_type',)
    filter_fields = ('name', 'probe_type',)

    serializer_class = ProbeSslSerializer
    lookup_url_kwarg = "probeconfig_id"

    def get(self, request, *args, **kwargs):
        return super(ProbeSslAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(ProbeSslAPI, self).create(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeSslAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeSslAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeSslAPI, self).destroy(request, *args, **kwargs)


class ProbeSslDetailAPI(RetrieveModelMixin,
                        UpdateModelMixin,
                        DestroyModelMixin,
                        SpectrumGenericAPIView):
    queryset = ProbeConfigStandaloneSSL.objects.all()

    filter_backends = (filters.SearchFilter,)
    search_fields = ('name', 'probe_type',)
    serializer_class = ProbeSslSerializer
    lookup_url_kwarg = 'probeconfig_id'

    def get(self, request, *args, **kwargs):
        return super(ProbeSslDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeSslDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeSslDetailAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeSslDetailAPI, self).destroy(request, *args, **kwargs)

class ProbeUdpAPI(ListModelMixin,
                   CreateModelMixin,
                   UpdateModelMixin,
                   DestroyModelMixin,
                   SpectrumGenericAPIView):
    queryset = ProbeConfigStandaloneUDP.objects.all()
    search_fields = ('name', 'probe_type',)
    filter_fields = ('name', 'probe_type',)

    serializer_class = ProbeUdpSerializer
    lookup_url_kwarg = "probeconfig_id"

    def get(self, request, *args, **kwargs):
        return super(ProbeUdpAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(ProbeUdpAPI, self).create(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeUdpAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeUdpAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeUdpAPI, self).destroy(request, *args, **kwargs)


class ProbeUdpDetailAPI(RetrieveModelMixin,
                        UpdateModelMixin,
                        DestroyModelMixin,
                        SpectrumGenericAPIView):
    queryset = ProbeConfigStandaloneUDP.objects.all()

    filter_backends = (filters.SearchFilter,)
    search_fields = ('name', 'probe_type',)
    serializer_class = ProbeUdpSerializer
    lookup_url_kwarg = 'probeconfig_id'

    def get(self, request, *args, **kwargs):
        return super(ProbeUdpDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeUdpDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeUdpDetailAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeUdpDetailAPI, self).destroy(request, *args, **kwargs)

class ProbeFtpAPI(ListModelMixin,
                   CreateModelMixin,
                   UpdateModelMixin,
                   DestroyModelMixin,
                   SpectrumGenericAPIView):
    queryset = ProbeConfigStandaloneFTP.objects.all()
    search_fields = ('name', 'probe_type',)
    filter_fields = ('name', 'probe_type',)

    serializer_class = ProbeFtpSerializer
    lookup_url_kwarg = "probeconfig_id"

    def get(self, request, *args, **kwargs):
        return super(ProbeFtpAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(ProbeFtpAPI, self).create(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeFtpAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeFtpAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeFtpAPI, self).destroy(request, *args, **kwargs)

class ProbeFtpDetailAPI(RetrieveModelMixin,
                        UpdateModelMixin,
                        DestroyModelMixin,
                        SpectrumGenericAPIView):
    queryset = ProbeConfigStandaloneFTP.objects.all()

    filter_backends = (filters.SearchFilter,)
    search_fields = ('name', 'probe_type',)
    serializer_class = ProbeFtpSerializer
    lookup_url_kwarg = 'probeconfig_id'

    def get(self, request, *args, **kwargs):
        return super(ProbeFtpDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeFtpDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeFtpDetailAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeFtpDetailAPI, self).destroy(request, *args, **kwargs)

class ProbeRtmpAPI(ListModelMixin,
                   CreateModelMixin,
                   UpdateModelMixin,
                   DestroyModelMixin,
                   SpectrumGenericAPIView):
    queryset = ProbeConfigStandaloneRTMP.objects.all()
    search_fields = ('name', 'probe_type',)
    filter_fields = ('name', 'probe_type',)

    serializer_class = ProbeRtmpSerializer
    lookup_url_kwarg = "probeconfig_id"

    def get(self, request, *args, **kwargs):
        return super(ProbeRtmpAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(ProbeRtmpAPI, self).create(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeRtmpAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeRtmpAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeRtmpAPI, self).destroy(request, *args, **kwargs)

class ProbeRtmpDetailAPI(RetrieveModelMixin,
                        UpdateModelMixin,
                        DestroyModelMixin,
                        SpectrumGenericAPIView):
    queryset = ProbeConfigStandaloneRTMP.objects.all()

    filter_backends = (filters.SearchFilter,)
    search_fields = ('name', 'probe_type',)
    serializer_class = ProbeRtmpSerializer
    lookup_url_kwarg = 'probeconfig_id'

    def get(self, request, *args, **kwargs):
        return super(ProbeRtmpDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeRtmpDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeRtmpDetailAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeRtmpDetailAPI, self).destroy(request, *args, **kwargs)


class ProbeDnsAPI(ListModelMixin,
                   CreateModelMixin,
                   UpdateModelMixin,
                   DestroyModelMixin,
                   SpectrumGenericAPIView):
    queryset = ProbeConfigStandaloneDNS.objects.all()
    search_fields = ('name', 'probe_type',)
    filter_fields = ('name', 'probe_type',)

    serializer_class = ProbeDnsSerializer
    lookup_url_kwarg = "probeconfig_id"

    def get(self, request, *args, **kwargs):
        return super(ProbeDnsAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(ProbeDnsAPI, self).create(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeDnsAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeDnsAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeDnsAPI, self).destroy(request, *args, **kwargs)

class ProbeDnsDetailAPI(RetrieveModelMixin,
                        UpdateModelMixin,
                        DestroyModelMixin,
                        SpectrumGenericAPIView):
    queryset = ProbeConfigStandaloneDNS.objects.all()

    filter_backends = (filters.SearchFilter,)
    search_fields = ('name', 'probe_type',)
    serializer_class = ProbeDnsSerializer
    lookup_url_kwarg = 'probeconfig_id'

    def get(self, request, *args, **kwargs):
        return super(ProbeDnsDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeDnsDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeDnsDetailAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeDnsDetailAPI, self).destroy(request, *args, **kwargs)

class ProbeAggregateAPI(ListModelMixin,
                   CreateModelMixin,
                   UpdateModelMixin,
                   DestroyModelMixin,
                   SpectrumGenericAPIView):
    queryset = ProbeConfigAggregate.objects.all()
    search_fields = ('name', 'probe_type',)
    filter_fields = ('name', 'probe_type',)

    serializer_class = ProbeAggregateSerializer
    lookup_url_kwarg = "probeconfig_id"

    def get(self, request, *args, **kwargs):
        return super(ProbeAggregateAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(ProbeAggregateAPI, self).create(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeAggregateAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeAggregateAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeAggregateAPI, self).destroy(request, *args, **kwargs)


class ProbeAggregateDetailAPI(RetrieveModelMixin,
                              UpdateModelMixin,
                              DestroyModelMixin,
                              SpectrumGenericAPIView):
    queryset = ProbeConfigAggregate.objects.all()

    filter_backends = (filters.SearchFilter,)
    search_fields = ('name', 'probe_type',)
    serializer_class = ProbeAggregateSerializer
    lookup_url_kwarg = 'probeconfig_id'

    def get(self, request, *args, **kwargs):
        return super(ProbeAggregateDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeAggregateDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeAggregateDetailAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeAggregateDetailAPI, self).destroy(request, *args, **kwargs)


class ProbeVipsAPI(ListModelMixin,
                SpectrumGenericAPIView):
    queryset = VipProbeConfigs.objects.all()
    filter_backends = (filters.SearchFilter,)
    serializer_class = ProbeVipSerializer
    lookup_url_kwarg = 'probeconfig_id'

    def get_queryset(self):
        try:
            probeconfig_id = self.kwargs.get(self.lookup_url_kwarg)
            if probeconfig_id:
                probeVips = self.queryset.filter(probe=probeconfig_id)
                return probeVips
            else:
                return self.queryset
        except:
            return self.queryset

    def get(self, request, *args, **kwargs):
        return super(ProbeVipsAPI, self).list(request, *args, **kwargs)

class ProbeDomainsAPI(ListModelMixin,
                SpectrumGenericAPIView):
    queryset = Domain.objects.all()
    filter_backends = (filters.SearchFilter,)
    serializer_class = ProbeDomainSerializer
    lookup_url_kwarg = 'probeconfig_id'

    def get_queryset(self):
        try:
            probeconfig_id = self.kwargs.get(self.lookup_url_kwarg)
            if probeconfig_id:
                probeDomains = self.queryset.filter(probe=probeconfig_id)
                return probeDomains
            else:
                return self.queryset
        except:
            return self.queryset

    def get(self, request, *args, **kwargs):
        return super(ProbeDomainsAPI, self).list(request, *args, **kwargs)

class ProbeRelatedAggregateAPI(ListModelMixin,
                SpectrumGenericAPIView):
    queryset = ProbeConfigAggregateProbe.objects.all()
    filter_backends = (filters.SearchFilter,)
    serializer_class = ProbeRelatedAggregateSerializer
    lookup_url_kwarg = 'probeconfig_id'

    def get_queryset(self):
        try:
            probeconfig_id = self.kwargs.get(self.lookup_url_kwarg)
            if probeconfig_id:
                ProbeAggregates = self.queryset.filter(probe=probeconfig_id)
                return ProbeAggregates
            else:
                return self.queryset
        except:
            return self.queryset

    def get(self, request, *args, **kwargs):
        return super(ProbeRelatedAggregateAPI, self).list(request, *args, **kwargs)

class ProbeDeletableAPI(RetrieveModelMixin,
                SpectrumGenericAPIView):
    queryset = BaseProbeConfig.objects.all()

    filter_backends = (filters.SearchFilter,)
    search_fields = ('name', 'probe_type',)
    serializer_class = ProbeDeletableSerializer
    lookup_url_kwarg = 'probeconfig_id'

    def get(self, request, *args, **kwargs):
        return super(ProbeDeletableAPI, self).retrieve(request, *args, **kwargs)

class ProbeDomainVipAPI(ListModelMixin,
                SpectrumGenericAPIView):
    queryset = DomainVip.objects.all()
    filter_backends = (filters.SearchFilter,)
    serializer_class = ProbeDomainVipSerializer
    lookup_url_kwarg = 'probeconfig_id'

    def get_queryset(self):
        try:
            probeconfig_id = self.kwargs.get(self.lookup_url_kwarg)
            if probeconfig_id:
                probeDomainVip = self.queryset.filter(probe=probeconfig_id)
                return probeDomainVip
            else:
                return self.queryset
        except:
            return self.queryset

    def get(self, request, *args, **kwargs):
        return super(ProbeDomainVipAPI, self).list(request, *args, **kwargs)

class ProbeDomainEdgeAPI(ListModelMixin,
                SpectrumGenericAPIView):
    queryset = DomainEdge.objects.all()
    filter_backends = (filters.SearchFilter,)
    serializer_class = ProbeDomainEdgeSerializer
    lookup_url_kwarg = 'probeconfig_id'

    def get_queryset(self):
        try:
            probeconfig_id = self.kwargs.get(self.lookup_url_kwarg)
            if probeconfig_id:
                probeDomainEdge = self.queryset.filter(probe=probeconfig_id)
                return probeDomainEdge
            else:
                return self.queryset
        except:
            return self.queryset

    def get(self, request, *args, **kwargs):
        return super(ProbeDomainEdgeAPI, self).list(request, *args, **kwargs)

class ProbeRelatedItemAPI(SpectrumGenericAPIView):
    lookup_url_kwarg = "probeconfig_id"

    def get(self, request, *args, **kwargs):
        related_items = {}
        try:
            probeconfig_id = self.kwargs.pop(self.lookup_url_kwarg)

            probe = BaseProbeConfig.objects.get(pk=int(probeconfig_id))
            probe_items = probe.get_related_objects()

            for items in probe_items:
                key = unicode(items[0].__name__)
                sub_items = []
                for sub_item in items[1]:
                    sub_items.append("%s" % sub_item)

                if len(sub_items) > 0:
                    related_items.update({key: sub_items})
            related_items["is_deletable"] = probe.is_deletable()
            return Response(related_items)
        except KeyError:
            raise AccessInvalidProbeID
        except BaseProbeConfig.DoesNotExist:
            raise ProbeDoesNotExist
        except:
            raise APIException(detail=_(u"Occured system failure"))
