# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Rest API
"""
from rest_framework.exceptions import APIException
from rest_framework.status import HTTP_404_NOT_FOUND, HTTP_403_FORBIDDEN, HTTP_400_BAD_REQUEST

from spectrum_api.configuration.models.base import Pop, PopProbeAgentConfig, PopPacketlossProbeAgentConfig, \
        VipSearch
from spectrum_api.configuration.models.probeagent import ProbeAgent
from spectrum_api.configuration.serializers.probeagent import ProbeagentSerializer, ProbeagentPopsSerializer, \
        RttserverPopsSerializer, PacketlossPopsSerializer, GlobalProbeagentSerializer, ProbeagentDeletableSerializer, \
        ProbeagentNameSerializer
from rest_framework import filters
from django.db.models import Q
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.mixins import CreateModelMixin, UpdateModelMixin, DestroyModelMixin, \
                                                ListModelMixin, RetrieveModelMixin
from django.utils.translation import ugettext as _
from rest_framework.response import Response

def get_probeagent_id(probeagent):
    return probeagent.get("probeagent_id")

class ProbeagentDoseNotExist(APIException):
    status_code = HTTP_404_NOT_FOUND
    default_detail = _('You access does not exists Probeagent')

class ProbeagentDeleteNotAllowed(APIException):
    status_code = HTTP_403_FORBIDDEN
    default_detail = _("You can not delete this Probeagent")

class AccessInvalidProbeagentID(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = 'Probeagent ID Missing'

class ProbeagentDoesNotExist(APIException):
    status_code = HTTP_404_NOT_FOUND
    default_detail = _(u'You requested a probeagent which does not exists.')


class ProbeagentAPI(ListModelMixin,
            CreateModelMixin,
            UpdateModelMixin,
            DestroyModelMixin,
            SpectrumGenericAPIView):
    queryset = ProbeAgent.objects.filter(~Q(probeagent_id=1)).all()
    search_fields = ('vip__vip', 'vip__full_vip_name', 'vip__ip',)
    filter_fields = ({"vip":'vip__vip'}, {"full_vip_name":'vip__full_vip_name'}, {"ip":'vip__ip'},)

    serializer_class = ProbeagentSerializer
    lookup_url_kwarg = "probeagent_id"

    def get(self, request, *args, **kwargs):
        return super(ProbeagentAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(ProbeagentAPI, self).create(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeagentAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeagentAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeagentDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeagentAPI, self).destroy(request, *args, **kwargs)

class ProbeagentNameAPI(ListModelMixin,
                        SpectrumGenericAPIView):
    queryset = ProbeAgent.objects.filter(~Q(probeagent_id=1)).all().select_related('vip')
    search_fields = ('vip__vip', 'vip__full_vip_name', 'vip__ip',)
    filter_fields = ({"vip":'vip__vip'}, {"full_vip_name":'vip__full_vip_name'}, {"ip":'vip__ip'},)

    serializer_class = ProbeagentNameSerializer
    lookup_url_kwarg = "probeagent_id"

    def get(self, request, *args, **kwargs):
        return super(ProbeagentNameAPI, self).list(request, *args, **kwargs)

class ProbeagentDetailAPI(RetrieveModelMixin,
                    UpdateModelMixin,
                    DestroyModelMixin,
                    SpectrumGenericAPIView):
    queryset = ProbeAgent.objects.filter(~Q(probeagent_id=1)).all()

    filter_backends = (filters.SearchFilter,)
    search_fields = ('vip__vip', 'vip__full_vip_name', 'vip__ip',)
    serializer_class = ProbeagentSerializer
    lookup_url_kwarg = 'probeagent_id'

    def get(self, request, *args, **kwargs):
        return super(ProbeagentDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProbeagentDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProbeagentDetailAPI, self).partial_update(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise ProbeagentDeleteNotAllowed

    def delete(self, request, *args, **kwargs):
        return super(ProbeagentDetailAPI, self).destroy(request, *args, **kwargs)

class GlobalProbeagentDetailAPI(ListModelMixin,
                                 SpectrumGenericAPIView):
    queryset = ProbeAgent.objects.filter(probeagent_id=1).all()

    serializer_class = GlobalProbeagentSerializer
    lookup_url_kwarg = "probeagent_id"

    def get(self, request, *args, **kwargs):
        return super(GlobalProbeagentDetailAPI, self).list(request, *args, **kwargs)


class ProbeagentPopsAPI(ListModelMixin,
                        SpectrumGenericAPIView):
    queryset = PopProbeAgentConfig.objects.all()
    queryset = PopProbeAgentConfig.all_objects.select_related('pop')
    filter_backends = (filters.SearchFilter,)
    search_fields = ('ProbeAgent__vip__vip', 'ProbeAgent__vip__full_vip_name', 'ProbeAgent__vip__ip',)
    serializer_class = ProbeagentPopsSerializer
    lookup_url_kwarg = 'probeagent_id'

    def get_queryset(self):
        try:
            probeagent_id = self.kwargs.get(self.lookup_url_kwarg)
            if probeagent_id:
                probeagentPops = self.queryset.filter(probeagent__probeagent_id=probeagent_id)
                return probeagentPops
            else:
                return self.queryset
        except:
            return self.queryset

    def get(self, request, *args, **kwargs):
        return super(ProbeagentPopsAPI, self).list(request, *args, **kwargs)

class RttserverPopsAPI(ListModelMixin,
                       SpectrumGenericAPIView):
    queryset = Pop.objects.all()
    filter_backends = (filters.SearchFilter,)
    search_fields = ('ProbeAgent__vip__vip', 'ProbeAgent__vip__full_vip_name', 'ProbeAgent__vip__ip',)
    serializer_class = RttserverPopsSerializer
    lookup_url_kwarg = 'probeagent_id'

    def get_queryset(self):
        try:
            probeagent_id = self.kwargs.get(self.lookup_url_kwarg)
            if probeagent_id:
                rttserverPops = self.queryset.filter(rttserver=probeagent_id)
                return rttserverPops
            else:
                return self.queryset
        except:
            return self.queryset

    def get(self, request, *args, **kwargs):
        return super(RttserverPopsAPI, self).list(request, *args, **kwargs)

class PacketlossPopsAPI(ListModelMixin,
                        SpectrumGenericAPIView):
    queryset = PopPacketlossProbeAgentConfig.all_objects.select_related('pop')
    filter_backends = (filters.SearchFilter,)
    search_fields = ('ProbeAgent__vip__vip', 'ProbeAgent__vip__full_vip_name', 'ProbeAgent__vip__ip',)
    serializer_class = PacketlossPopsSerializer
    lookup_url_kwarg = 'probeagent_id'

    def get_queryset(self):
        try:
            probeagent_id = self.kwargs.get(self.lookup_url_kwarg)
            if probeagent_id:
                packetlossPops = self.queryset.filter(probeagent__probeagent_id=probeagent_id)
                return packetlossPops
            else:
                return self.queryset
        except:
            return self.queryset

    def get(self, request, *args, **kwargs):
        return super(PacketlossPopsAPI, self).list(request, *args, **kwargs)

class ProbeagentDeletableAPI(RetrieveModelMixin,
                              SpectrumGenericAPIView):
    queryset = ProbeAgent.objects.filter(~Q(probeagent_id=1)).all()

    filter_backends = (filters.SearchFilter,)
    search_fields = ('vip__vip', 'vip__full_vip_name', 'vip__ip',)
    serializer_class = ProbeagentDeletableSerializer
    lookup_url_kwarg = 'probeagent_id'

    def get(self, request, *args, **kwargs):
        return super(ProbeagentDeletableAPI, self).retrieve(request, *args, **kwargs)

class ProbeagentRelatedItemAPI(SpectrumGenericAPIView):
    lookup_url_kwarg = "probeagent_id"

    def get(self, request, *args, **kwargs):
        related_items = {}
        try:
            probeagent_id = self.kwargs.pop(self.lookup_url_kwarg)

            probeagent = ProbeAgent.objects.get(pk=int(probeagent_id))
            probeAgent_items = probeagent.get_related_objects()

            for items in probeAgent_items:
                key = unicode(items[0].__name__)
                sub_items = []
                for sub_item in items[1]:
                    sub_items.append("%s" % sub_item)

                if len(sub_items) > 0:
                    related_items.update({key: sub_items})
            related_items["is_deletable"] = probeagent.is_deletable()
            return Response(related_items)
        except KeyError:
            raise AccessInvalidProbeagentID
        except ProbeAgent.DoesNotExist:
            raise ProbeagentDoesNotExist
        except:
            raise APIException(detail=_(u"Occured system failure"))

class AutoProbePopsAPI(ListModelMixin,
                       SpectrumGenericAPIView):
    lookup_url_kwarg = 'probeagent_id'

    def get(self, request, *args, **kwargs):
        pops_list = []
        try:
            probeagent_id = self.kwargs.pop(self.lookup_url_kwarg)
            probeagent = ProbeAgent.objects.get(pk=int(probeagent_id))

            vipsearch = VipSearch.objects.filter(vip=probeagent.vip.pk).values('pop_name')
            if vipsearch.exists():
                base_pops = Pop.objects.filter(Q(pop_name__in=vipsearch) | Q(ihms_pop__pop_code__in=vipsearch)) \
                                       .filter(auto_probe=1)
                if base_pops.count() > 0:
                    vips, is_valid = probeagent.check_auto_probe_condition(base_pops[0])
                    if vips.count() > 0:
                        probeagent_vips = [{'vip':items.vip, 'full_vip_name':items.full_vip_name, 'ip':items.ip} for items in vips]
                    else:
                        probeagent_vips = []
                    pops_list = [{'pop':items.pop, 'pop_name':items.get_popname(), 'auto_probe':items.auto_probe, 
                                  'probe_vips':probeagent_vips} for items in base_pops]

            return Response(pops_list)
        except KeyError:
            raise AccessInvalidProbeagentID
        except ProbeAgent.DoesNotExist:
            raise ProbeagentDoesNotExist
        except:
            raise APIException(detail=_(u"Occured system failure"))
