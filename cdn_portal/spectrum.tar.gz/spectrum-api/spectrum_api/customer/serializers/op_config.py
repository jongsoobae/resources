# -*- coding: utf-8 -*-
from datetime import datetime
from django.core.validators import MaxLengthValidator
from rest_framework import serializers

from spectrum_api.customer.views.common import get_cached_all_adusers
from spectrum_api.customer.views.common import WORK_TYPE_STR
from spectrum_api.customer.views.common import WORK_TYPE_CODE_STR

from spectrum_api.shared_components.models import csStatMaster
from spectrum_api.shared_components.models.customer import CustomerItem
from spectrum_api.shared_components.models.customer import CustomerSfaOrder
from spectrum_api.shared_components.models.customer import CustomerItemOperator
from spectrum_api.shared_components.models.customer import CustomerItemPlatform
from spectrum_api.shared_components.models.customer import LegacyAddService

MATERIAL_CODE_STORAGE = 1014
MATERIAL_CODE_AQUA_DIRECTOR = 1019
MATERIAL_CODE_HTTP_STREAMING = 1180

PLATFORM_CODE_CS = 8008
PLATFORM_CODE_CS_AA = 8023
PLATFORM_CODE_WMS = 8003
PLATFORM_CODE_FMS = 8004

PLATFORM_TYPE_CS = (PLATFORM_CODE_CS, PLATFORM_CODE_CS_AA)
PLATFORM_TYPE_MS = (PLATFORM_CODE_WMS, PLATFORM_CODE_FMS)


class OPConfigSerializer(serializers.ModelSerializer):
    contract_no = serializers.IntegerField(source='contract.contract_no')
    contract_name = serializers.SerializerMethodField('strip_contract_name')
    contract_region_name = serializers.CharField(source='contract.sales_org_name')
    account_no = serializers.IntegerField(source='contract.account.account_no')
    account_name_local = serializers.CharField(source='contract.account.account_name_local')
    account_name_eng = serializers.CharField(source='contract.account.account_name_eng')
    product_name = serializers.CharField(source='material_desc')
    platforms = serializers.SerializerMethodField('get_platforms')
    sections = serializers.SerializerMethodField('get_show_sections')
    am_name = serializers.CharField(source='contract.sales_rep_name')
    sm_name = serializers.SerializerMethodField('get_sm_name')
    contract_start_date = serializers.DateField(source='contract.contract_start')
    contract_end_date = serializers.DateField(source='contract.contract_end')
    added_services = serializers.SerializerMethodField('get_child_contract')

    class Meta:
        model = CustomerItem
        fields = ('item_id', 'item_no', 'contract_no', 'contract_name', 'contract_region_name', 'material_no',
                  'account_no', 'account_name_local', 'account_name_eng', 'product_name', 'platforms', 'sections',
                  'am_name', 'sm_name', 'contract_start_date', 'contract_end_date',
                  'added_services')

    @staticmethod
    def strip_contract_name(obj):
        return obj.contract.contract_name.strip()

    @staticmethod
    def get_platforms(obj):
        qs = CustomerItemPlatform.objects.select_related('platform').filter(item__item_id=obj.item_id)
        return qs.values_list('platform__platform_no', 'platform__platform_name')

    @staticmethod
    def get_show_sections(obj):
        rs = {}
        qs = CustomerItemPlatform.objects.select_related('platform').filter(item__item_id=obj.item_id)
        platforms = qs.values_list('platform__platform_no', flat=True)
        for platform in platforms:
            if platform in PLATFORM_TYPE_CS:
                rs['cs'] = True
            if platform in PLATFORM_TYPE_MS:
                rs['ms'] = True
                if platform == PLATFORM_CODE_WMS:
                    rs['lm'] = True

        # Check Material codes.
        children = CustomerItem.objects.filter(parent_item__item_id=obj.item_id).all()
        for child in children:
            if child.material_no == MATERIAL_CODE_STORAGE:
                rs['storage'] = True
            if child.material_no == MATERIAL_CODE_AQUA_DIRECTOR:
                rs['ad'] = True

        return rs

    @staticmethod
    def get_sm_name(obj):
        cached_ldap_users = get_cached_all_adusers()[1]
        result = {'sm_prime': None, 'sm_sub': None}
        operators = CustomerItemOperator.objects.filter(item__item_id=obj.item_id).all()
        for op in operators:
            sm_info = {
                'email': op.email,
                'display_name': cached_ldap_users.get(op.email, op.email)
            }
            if op.prime is 1:
                result['sm_prime'] = sm_info
            elif op.prime is 2:
                result['sm_sub'] = sm_info
        return result

    @staticmethod
    def get_child_contract(obj):
        result = []
        children = CustomerItem.objects.filter(parent_item__item_id=obj.item_id).all()
        for child in children:
            result.append({
                # 'item_id': child.item_id,
                'added_service_code': '%s - %s' % (child.item_no, child.material_no),
                'material_desc': child.material_desc.strip(),
                'update_date': child.update_time.strftime('%Y-%m-%d')
            })
        return result


class OPConfigAssigneeConfirmationSerializer(serializers.ModelSerializer):
    csorderno = serializers.IntegerField(source='csorderno')
    item_id = serializers.IntegerField(source='item_id')
    task_type = serializers.SerializerMethodField('get_task_type')
    request_type = serializers.SerializerMethodField('get_request_type')
    contract = serializers.SerializerMethodField('get_contract')
    status = serializers.IntegerField(source='status')
    requested_date = serializers.SerializerMethodField('get_requested_date')

    class Meta:
        model = CustomerSfaOrder
        fields = ('csorderno', 'item_id', 'task_type', 'request_type', 'contract', 'status', 'requested_date')

    @staticmethod
    def get_task_type(obj):
        return WORK_TYPE_STR.get(obj.work_type, 'Unknown')

    @staticmethod
    def get_request_type(obj):
        return WORK_TYPE_CODE_STR.get(obj.work_type_code, 'Unknown')

    @staticmethod
    def get_contract(obj):
        return '%d [%d] / %s / %s / %s' % (obj.item.contract.contract_no, obj.item.item_no,
                                           obj.item.contract.contract_name.strip(),
                                           obj.item.material_desc.strip(), obj.item.material_desc.strip())

    @staticmethod
    def get_requested_date(obj):
        return obj.create_time.strftime('%Y-%m-%d')


class OPConfigCSPadListSerializer(serializers.ModelSerializer):
    stat_id = serializers.IntegerField(source='statmaster_id.stat_id')
    parent_stat_id = serializers.IntegerField(source='statmaster_id.parent_stat_id')
    pad_status = serializers.IntegerField(source='statmaster_id.obj_state')
    date_created = serializers.DateTimeField(source='statmaster_id.date_created')
    pad_name = serializers.CharField(source='domain')
    auth_config = serializers.SerializerMethodField('get_auth_config')

    class Meta:
        model = csStatMaster
        fields = ('stat_id', 'parent_stat_id', 'pad_status', 'date_created', 'pad_name', 'auth_config')

    @staticmethod
    def get_auth_config(obj):
        # If parent_stat_id is not None, this object is the Sub pad.
        if obj.statmaster_id.material_no != MATERIAL_CODE_HTTP_STREAMING or obj.statmaster_id.parent_stat_id:
            return None

        try:
            las = LegacyAddService.objects.filter(add_svc_type='P', add_svc_name=obj.domain,
                                                  account__account_no=obj.statmaster_id.item.contract.account.account_no)
            return las[0].add_svc_id
        except:
            return 0


class OPConfigAuthConfigAddSerializer(serializers.ModelSerializer):
    class Meta:
        model = LegacyAddService
        fields = ('add_svc_type',  'account', 'add_svc_name', 'obj_state', 'date_created', 'date_modified')
