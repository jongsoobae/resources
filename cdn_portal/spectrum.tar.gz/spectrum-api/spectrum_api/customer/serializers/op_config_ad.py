from rest_framework import serializers

from spectrum_api.shared_components.models.customer import LegacyAddService


class AquaDirectorSerializer(serializers.ModelSerializer):
    account = serializers.PrimaryKeyRelatedField(write_only=True)
    add_svc_type = serializers.CharField(default='D', write_only=True)
    date_create = serializers.DateTimeField(read_only=True)

    class Meta:
        model = LegacyAddService
        fields = ('add_svc_id', 'add_svc_type', 'account', 'add_svc_name', 'date_created')
