from rest_framework import serializers

from spectrum_api.shared_components.models.customer import LegacyAddService


class PublishPointSerializer(serializers.ModelSerializer):
    account = serializers.PrimaryKeyRelatedField(write_only=True)
    add_svc_type = serializers.CharField(default='M', write_only=True)
    # 1: WMS, 2: WMS (Win 2000), 8: FMS
    # But We support only WMS, so we set default value is 1.
    service_type_cd = serializers.PrimaryKeyRelatedField(default=1, write_only=True)
    date_create = serializers.DateTimeField(read_only=True)

    class Meta:
        model = LegacyAddService
        fields = ('add_svc_id', 'add_svc_type', 'account', 'add_svc_name', 'service_type_cd', 'date_created')
