from rest_framework import serializers

from spectrum_api.shared_components.models.customer import LegacyServiceDomain
from spectrum_api.shared_components.models import LegacyStatMaster
from spectrum_api.shared_components.models import LegacyServiceDomainStatMap
from spectrum_api.shared_components.models import StatMaster


class StatMapSerializer(serializers.ModelSerializer):
    stat_svc_name = serializers.CharField(source='legacy_stat.stat_svc_name')
    keywords = serializers.SerializerMethodField('get_keywords')

    class Meta:
        model = LegacyServiceDomainStatMap
        field = ('stat_svc_name', 'keywords')

    @staticmethod
    def get_keywords(obj):
        qs = StatMaster.objects.filter(parent_stat_id=obj.legacy_stat.statmaster_id.stat_id)
        return qs.values_list('keyword', flat=True)


class StatKeywordListSerializer(serializers.ModelSerializer):
    stat_services = StatMapSerializer(source='legacyservicedomainstatmap_set', many=True)

    class Meta:
        model = LegacyServiceDomain
        fields = ('svc_domain_id', 'svc_domain_name', 'stat_services')


class LegacyServiceDomainSerializer(serializers.ModelSerializer):
    item_id = serializers.IntegerField(source='item_id')

    class Meta:
        model = LegacyServiceDomain
        fields = ('svc_domain_id', 'svc_domain_name', 'item_id', 'date_created')


class StatServiceSerializer(serializers.ModelSerializer):
    stat_svc_type = serializers.IntegerField(source='statmaster_id.platform_cd')

    class Meta:
        model = LegacyStatMaster
        fields = ('statmaster_id', 'stat_svc_name', 'stat_svc_type', 'date_created')


class StatKeywordSerializer(serializers.ModelSerializer):
    class Meta:
        model = StatMaster
        fields = ('stat_id', 'obj_state', 'keyword', 'daemon_type_cd', 'date_created')
