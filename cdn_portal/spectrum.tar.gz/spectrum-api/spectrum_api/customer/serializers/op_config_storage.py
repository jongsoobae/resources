
from rest_framework import serializers

from spectrum_api.shared_components.models import csStatMaster
from spectrum_api.shared_components.models import LegacyStatMaster
from spectrum_api.shared_components.models import HermesMapStatMaster


class CSStatServiceListSerializer(serializers.ModelSerializer):
    stat_service = serializers.CharField(source='domain')
    stat_id = serializers.IntegerField(source='statmaster_id.stat_id')

    class Meta:
        model = csStatMaster
        fields = ('stat_service', 'stat_id')


class LegacyStatServiceListSerializer(serializers.ModelSerializer):
    stat_service = serializers.CharField(source='stat_svc_name')
    stat_id = serializers.IntegerField(source='statmaster_id.stat_id')

    class Meta:
        model = LegacyStatMaster
        fields = ('stat_service', 'stat_id')


class HermesMapStatMasterSerializer(serializers.ModelSerializer):

    class Meta:
        model = HermesMapStatMaster
        fields = ('stat_id', 'corporation_cd', 'service_set', 'isBilling')
