# -*- coding: utf-8 -*-
from rest_framework import serializers
from spectrum_api.customer.views.common import WORK_TYPE_STR
from spectrum_api.customer.views.common import WORK_TYPE_CODE_STR
from spectrum_api.customer.views.common import BUNDLE_PRODUCTS

from spectrum_api.shared_components.models.customer import CustomerSfaOrder


class OPListSerializer(serializers.ModelSerializer):
    item_id = serializers.IntegerField(source='item.item_id')
    parent_item_id = serializers.SerializerMethodField('get_parent_item_id')
    contract_region_name = serializers.CharField(source='item.contract.sales_org_name')
    service_region = serializers.SerializerMethodField('get_service_region')
    work_type_label = serializers.SerializerMethodField('get_work_type_label')
    work_type_code_label = serializers.SerializerMethodField('get_work_type_code_label')
    account_name = serializers.SerializerMethodField('get_account_name')
    contract_product_name = serializers.SerializerMethodField('get_contract_product_name')
    sales_rep_name = serializers.CharField(source='item.contract.sales_rep_name')
    contract_request_time = serializers.SerializerMethodField('get_contract_time')
    contract_start_time = serializers.DateField(source='item.contract.contract_start')
    contract_end_time = serializers.DateField(source='item.contract.contract_end')

    class Meta:
        model = CustomerSfaOrder
        fields = ("item_id",
                  "parent_item_id",
                  "csorderno",
                  "contract_region_name",
                  "service_region",
                  "work_type_label",
                  "work_type_code_label",
                  "account_name",
                  "contract_product_name",
                  "sales_rep_name",
                  "status",
                  "contract_request_time",
                  "contract_start_time",
                  "contract_end_time")

    @staticmethod
    def get_parent_item_id(obj):
        # If parent_item is None, This item is already parent item (= Major item).
        # If this parent_item's material_no is BUNDLE PRODUCT, This item is parent_item (= Major item).
        if not obj.item.parent_item or obj.item.parent_item.material_no in BUNDLE_PRODUCTS:
            return obj.item.item_id
        return obj.item.parent_item.item_id

    @staticmethod
    def get_service_region(obj):
        return "Global" if obj.item.contract.ocsp_region == 4000 else "Local"

    @staticmethod
    def get_account_name(obj):
        return '%s (%s)' % (obj.item.contract.account.account_name_local, obj.item.contract.account.account_name_eng)

    @staticmethod
    def get_contract_product_name(obj):
        return '%d [%d] / %s / %s / %s' % (obj.item.contract.contract_no, obj.item.item_no,
                                           obj.item.contract.contract_name.strip(), obj.item.material_desc.strip(),
                                           obj.get_platform_name())

    @staticmethod
    def get_work_type_label(obj):
        return WORK_TYPE_STR.get(obj.work_type, 'Unknown')

    @staticmethod
    def get_work_type_code_label(obj):
        return WORK_TYPE_CODE_STR.get(obj.work_type_code, 'Unknown')

    @staticmethod
    def get_contract_time(obj):
        return obj.create_time.strftime('%Y-%m-%d')

