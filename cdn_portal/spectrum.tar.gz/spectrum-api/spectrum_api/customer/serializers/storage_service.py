from rest_framework import serializers

from spectrum_api.shared_components.models import HermesMapStatMaster
from spectrum_api.shared_components.models import csStatMaster
from spectrum_api.shared_components.models import LegacyStatMaster

from spectrum_api.customer.views.pal_soap_requests import get_management_host_list
from spectrum_api.customer.views.pal_soap_requests import get_service_set_list


class StorageServiceListSerializer(serializers.ModelSerializer):
    hermesmap_id = serializers.IntegerField(source='id')
    is_billing = serializers.BooleanField(source='isBilling')
    stat_service = serializers.SerializerMethodField('get_stat_service')
    service_set_info = serializers.SerializerMethodField('get_service_set_info')
    item_id = serializers.IntegerField(source='stat_id.item.item_id')

    class Meta:
        model = HermesMapStatMaster
        fields = ('hermesmap_id', 'stat_id', 'item_id', 'corporation_cd', 'service_set',
                  'is_billing', 'stat_service', 'date_created', 'date_modified', 'service_set_info')

    @staticmethod
    def get_stat_service(obj):
        try:
            csm = csStatMaster.objects.get(statmaster_id=obj.stat_id)
            return csm.domain
        except:
            try:
                lsm = LegacyStatMaster.objects.get(statmaster_id=obj.stat_id)
                return lsm.stat_svc_name
            except:
                pass
        return '-'

    @staticmethod
    def get_service_set_info(obj):
        mgmts = get_management_host_list(obj.corporation_cd)
        for mgmt in mgmts:
            service_set_dict = get_service_set_list(mgmt['hostName'], obj.corporation_cd)[0]
            if obj.service_set in service_set_dict:
                return service_set_dict[obj.service_set]
        return {}
