import os
if os.environ.get('DJANGO_SETTINGS_MODULE') is None:
    os.environ['DJANGO_SETTINGS_MODULE'] = 'spectrum_api.settings'

import json
import unittest

from django.contrib.auth.models import User

from rest_framework.test import force_authenticate
from rest_framework.test import APIRequestFactory
from rest_framework.response import Response
from rest_framework.authtoken.models import Token

from spectrum_api.customer.views.common import WORK_TYPE_STR
from spectrum_api.customer.views.op_list import OPList

from api_test import url_constants as base_url_constants
from api_test.contrib.jsonschema import validate
from api_test.constants import AUTH_SPECTRUMAPI_APPLICATION_USER


results_json_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "title": "default format",
    "description": "spectrum api default json schema",
    "type": 'array',
    "items": {
        "type": "object",
        "properties": {
            "work_type_label": {
                "type": "string"
            }
        }
    }
}


def assert_response_code(response_code, check_status_code) :
    if check_status_code :
        check_status_code = 200
    assert response_code == check_status_code


def assert_json_schema(data_json, json_schema):
    """
    json_schema = {
        'type':'array',
        {
            'type':'object',
            'properties':{'sstorage_name': {'type':'string'}}
        }
    }
    result = validate({'storage_name':'1'}, json_schema)
    """
    if not json_schema:
        json_schema = base_url_constants.default_json_schema

    validate(data_json, json_schema)


def get_json_value(keyname, response):
    if type(response) is Response and not response.is_rendered :
        response.render()

    response_json = json.loads(response.content)
    return response_json[keyname]


class OpListSearchTest(unittest.TestCase):
    def setUp(self):
        self.factory = APIRequestFactory()
        self.token = Token.objects.get(user__username='aurorauser')
        self.user = User.objects.get(username=AUTH_SPECTRUMAPI_APPLICATION_USER)

    def test_work_type_field(self):
        for key, value in WORK_TYPE_STR.iteritems():
            # Modify json schema
            results_json_schema['items']['properties']['work_type_label']['pattern'] = value

            # Get request
            request = self.factory.get('/api/op_list/list', {'task_type': key, 'page_size':30}, format='json')
            force_authenticate(request, user=self.user, token=self.token)

            response = OPList.as_view()(request)
            results_arr = get_json_value('results', response)

            # Check response
            assert_response_code(response.status_code, 200)
            assert_json_schema(results_arr, results_json_schema)
