# -*- coding: utf-8 -*-

from django.conf.urls.defaults import patterns, url
from rest_framework.urlpatterns import format_suffix_patterns

from spectrum_api.customer.views import op_list
from spectrum_api.customer.views import op_config
from spectrum_api.customer.views import op_config_ad
from spectrum_api.customer.views import op_config_ms
from spectrum_api.customer.views import op_config_lm
from spectrum_api.customer.views import op_config_storage
from spectrum_api.customer.views import storage_service

restfw_api_urlpatterns = patterns(
    'spectrum_api.customer.views',
    url(r'^op_list/list/$', op_list.OPList.as_view(), name="opening_process_list"),
    url(r'^op_list/update_sm_user/$', op_list.OPUpdateSMUser.as_view(), name="opening_process_update_sm_user"),
    url(r'^op_list/get_active_users/$', op_list.OPGetActiveUsers.as_view(), name="opening_process_get_active_users"),
    url(r'^op_config/contract/$', op_config.OPConfigContract.as_view(), name="opening_process_config_contract"),
    url(r'^op_config/assignee_confirmation/$', op_config.OPConfigAssigneeConfirmation.as_view(), name="opening_process_config_assignee_confirmation"),
    # Config - cs
    url(r'^op_config/cs_pad_list/$', op_config.OPConfigCSPadList.as_view(), name="opening_process_config_cs_pad_list"),
    url(r'^op_config/auth_config/$', op_config.OPConfigAuthConfigAdd.as_view(), name="opening_process_config_auth_config_add"),
    url(r'^op_config/auth_config/(?P<add_svc_id>[0-9]+)/$', op_config.OPConfigAuthConfigDelete.as_view(), name="opening_process_config_auth_config_delete"),
    # Config - storage
    url(r'^op_config/storage_list/(?P<item_id>[0-9]+)/$', op_config_storage.OPConfigStorageList.as_view(), name="opening_process_config_storage_list"),
    url(r'^op_config/stat_service_list/$', op_config_storage.OPConfigStatServiceList.as_view(), name="opening_process_config_stat_service_list"),
    url(r'^op_config/get_upload_server/$', op_config_storage.OPConfigGetUploadServer.as_view(), name="opening_process_config_get_upload_server"),
    url(r'^op_config/add_storage_service/$', op_config_storage.OPConfigStorageService.as_view(), name="opening_process_config_add_storage_service"),
    url(r'^op_config/update_storage_service/(?P<hermesmap_id>[0-9]+)/$', op_config_storage.OPConfigStorageService.as_view(), name="opening_process_config_update_storage_service"),
    # Config - WMS,FMS
    url(r'^op_config/get_stat_keyword_list/(?P<item_id>[0-9]+)/$', op_config_ms.OPConfigStatKeywordList.as_view(), name="opening_process_config_get_stat_keyword_list"),
    url(r'^op_config/add_service_domain/$', op_config_ms.OPConfigServiceDomain.as_view(), name="opening_process_config_add_service_domain"),
    url(r'^op_config/update_service_domain/(?P<svc_domain_id>[0-9]+)/$', op_config_ms.OPConfigServiceDomain.as_view(), name="opening_process_config_update_service_domain"),
    url(r'^op_config/add_ms_stat_service/$', op_config_ms.OPConfigMSStatService.as_view(), name="opening_process_config_add_ms_stat_service"),
    url(r'^op_config/ms_stat_service/(?P<svc_domain_id>[0-9]+)/$', op_config_ms.OPConfigMSStatService.as_view(), name="opening_process_config_ms_stat_service"),
    url(r'^op_config/update_ms_stat_service/(?P<stat_id>[0-9]+)/$', op_config_ms.OPConfigUpdateMSStatService.as_view(), name="opening_process_config_update_ms_stat_service"),
    url(r'^op_config/check_valid_ms_stat_service/$', op_config_ms.OPConfigCheckValidMSStatService.as_view(), name="opening_process_config_check_valid_ms_stat_service"),
    url(r'^op_config/add_ms_keyword/$', op_config_ms.OPConfigMSKeyword.as_view(), name="opening_process_config_add_ms_keyword"),
    url(r'^op_config/ms_keyword/(?P<stat_id>[0-9]+)/$', op_config_ms.OPConfigMSKeyword.as_view(), name="opening_process_config_ms_keyword"),
    url(r'^op_config/check_valid_ms_keyword/$', op_config_ms.OPConfigCheckValidMSKeyword.as_view(), name="opening_process_config_check_valid_ms_keyword"),
    # Config - Live Monitoring
    url(r'^op_config/publish_point/$', op_config_lm.OPConfigPublishPoint.as_view(), name="opening_process_config_publish_point"),
    url(r'^op_config/publish_point/(?P<add_svc_id>[0-9]+)/$', op_config_lm.OPConfigPublishPoint.as_view(), name="opening_process_config_delete_publish_point"),
    # Config - Aqua Director
    url(r'^op_config/aqua_director/$', op_config_ad.OPConfigAquaDirector.as_view(), name="opening_process_config_aqua_director"),
    url(r'^op_config/aqua_director/(?P<add_svc_id>[0-9]+)/$', op_config_ad.OPConfigAquaDirector.as_view(), name="opening_process_config_delete_aqua_director"),
    # Storage service
    url(r'^storage_service/mgmt_server_list/$', storage_service.MgmtServerList.as_view(), name="management_server_list"),
    url(r'^storage_service/storage_service_list/$', storage_service.StorageServiceList.as_view(), name="storage_service_list"),
)
urlpatterns = format_suffix_patterns(restfw_api_urlpatterns)
