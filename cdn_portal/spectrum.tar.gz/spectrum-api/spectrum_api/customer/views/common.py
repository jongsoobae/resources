from django.core.cache import cache
from spectrum_api.shared_components.utils.ldap_mgmt import LDAPManager
from spectrum_api import config_constants

WORK_TYPE_STR = {
    '11': 'Setup',
    '12': 'Termination',
    '13': 'Change',
    '21': 'Stop',
    '22': 'Re-Setup',
    '41': 'Service Add',
    '42': 'Service Delete'
}

WORK_TYPE_CODE_STR = {
    '1101': 'Trial Service',                    # In case to request opening about new Trial Service product
    '1102': 'Contract',                         # In case to request opening about new Contract product
    '1201': 'Termination',                      # In case to terminate the contract about Trial / Contract
    '1202': 'Value Add Service Termination',    # Not used
    '1203': 'Termination by Default',           # In case to terminate the contract about Trial / Contract - Manual handling
    '1301': 'Change Commit',                    # In case to change contract size of Trial / Contract
    '1302': 'Add Value Added Service',          # In case to register optional service of Trial / Contract
    '1303': 'Delete Value Added Service',       # In case to delete optional service Trial / Contract
    '1304': 'Add Product',                      # In case to register main service product of Trial / Contract
    '1305': 'Delete Product',                   # In case to delete main service product of Trial / Contract
    '2101': 'Suspend by Default',               # Not used
    '2102': 'Suspend by Customer',              # Not used
    '2201': 'Credit Control Release',           # Not used
    '2202': 'Resume Suspended Service',         # Not used
    '4101': 'Add Domain',                       # In case to add the domain that is served on product
    '4102': 'Add Publishing Point',             # In case to add the publishing point that is served on product
    '4103': 'Add Service Region',               # In case to add the service region that is served on product
    '4104': 'Add Platform',                     # In case to add the platform that is served on product
    '4201': 'Delete Domain',                    # In case to delete the domain that is served on product
    '4202': 'Delete Publishing Point',          # In case to delete the publishing point that is served on product
    '4203': 'Delete Service Region',            # In case to delete the service region that is served on product
    '4204': 'Delete Platform'                   # In case to delete the platform that is served on product
}

MATERIAL_CODE_CDN_SERVICE = 1056                # CDN Service
MATERIAL_CODE_WPS = 1171                        # Web Performance Suite (WPS)

BUNDLE_PRODUCTS = (MATERIAL_CODE_CDN_SERVICE, MATERIAL_CODE_WPS)

ADUSER_CACHE_KEY = 'ADUSERS_CACHE_KEY'


def get_all_adusers():
    ld = LDAPManager(protocol=config_constants.INTERNAL_AD_PROTOCOL,
                     ldap_host=config_constants.INTERNAL_AD_SERVER,
                     ldap_port=config_constants.INTERNAL_AD_PORT,
                     ldap_base_dn=config_constants.INTERNAL_AD_BASE,
                     ldap_base_user=config_constants.INTERNAL_AD_LOGIN_ID,
                     ldap_base_pass=config_constants.INTERNAL_AD_LOGIN_PWD)
    user_filter = '(&(objectCategory=person)(objectClass=user)' \
                  '(userAccountControl=512)(samaccountname=*)(givenname=*)(wWWHomePage=*))'
    # user_filter = '(&(objectClass=user)(objectCategory=person)(mail=*)(wWWHomePage=*))'
    users = ld.get_all_users(None, user_filter, attrib=None)
    ld.unbind()

    user_list = []
    user_dict = {}
    for user in users:
        if 'mail' in user and user['mail'][0] and 'cdnetworks' in user['mail'][0]:
            user_list.append({"id": user['mail'][0], "name": user['displayName'][0]})
            user_dict[user['mail'][0]] = unicode(user['displayName'][0], 'utf-8')
    return [sorted(user_list, key=lambda usr: usr['name']), user_dict]


def get_cached_all_adusers():
    # Cache ldap user list
    try:
        cached_data = cache.get(ADUSER_CACHE_KEY)
    except:
        cached_data = None

    if not cached_data:
        try:
            cached_data = get_all_adusers()
            cache.set(ADUSER_CACHE_KEY, cached_data, 14400)
        except:
            cached_data = [[], {}]
    return cached_data
