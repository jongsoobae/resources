# -*- coding: utf-8 -*-
from __future__ import absolute_import

from django.shortcuts import get_object_or_404

from rest_framework import mixins
from rest_framework.status import HTTP_400_BAD_REQUEST
from rest_framework.response import Response

from spectrum_api.config_constants import AQUA_API_URL_PREFIX
from spectrum_api.config_constants import AQUA_API_USER
from spectrum_api.config_constants import AQUA_API_PASSWORD

from spectrum_api.customer.serializers.op_config import OPConfigCSPadListSerializer
from spectrum_api.customer.serializers.op_config import OPConfigAssigneeConfirmationSerializer
from spectrum_api.customer.serializers.op_config import OPConfigSerializer
from spectrum_api.customer.serializers.op_config import OPConfigAuthConfigAddSerializer
from spectrum_api.customer.views.common import BUNDLE_PRODUCTS

from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.models import csStatMaster
from spectrum_api.shared_components.models.customer import CustomerItem
from spectrum_api.shared_components.models.customer import CustomerSfaOrder
from spectrum_api.shared_components.models.customer import LegacyAddService
from spectrum_api.shared_components.utils.common import log_error

import urllib2


class OPConfigContract(SpectrumGenericAPIView):
    queryset = CustomerItem.objects.select_related('contract__account')
    serializer_class = OPConfigSerializer

    def get(self, request, *args, **kwargs):
        qs = self.queryset
        item_id = self.request.GET.get('item_id', None)
        if not item_id:
            return Response({'detail': 'item_id must not None'}, status=HTTP_400_BAD_REQUEST)

        # If the item has parent_item_id, we have to find its parent item.
        citem = CustomerItem.objects.get(item_id=item_id)
        if citem.parent_item:
            # If Parent_item's material_no belong to BUNDLE_PRODUCTS(CDN service, WPS), We ignore parent_item.
            if citem.parent_item.material_no not in BUNDLE_PRODUCTS:
                item_id = citem.parent_item.item_id
        filter_kwargs = {'item_id': item_id}
        obj = get_object_or_404(qs, **filter_kwargs)
        serializer = self.get_serializer(obj)
        return Response(serializer.data)


class OPConfigAssigneeConfirmation(mixins.ListModelMixin, SpectrumGenericAPIView):
    queryset = CustomerSfaOrder.objects.select_related('item__contract__account')
    serializer_class = OPConfigAssigneeConfirmationSerializer

    def get_queryset(self):
        qs = self.queryset

        item_id = self.request.GET.get('item_id', None)
        if not item_id:
            return Response({'detail': 'item_id must not None'}, status=HTTP_400_BAD_REQUEST)

        item_ids = [item_id]

        children = CustomerItem.objects.filter(parent_item__item_id=item_id).all()
        for child in children:
            item_ids.append(child.item_id)

        return qs.filter(item__item_id__in=item_ids).order_by('-create_time')

    def get(self, request, *args, **kwargs):
        return super(OPConfigAssigneeConfirmation, self).list(request, *args, **kwargs)


class OPConfigCSPadList(mixins.ListModelMixin, SpectrumGenericAPIView):
    queryset = csStatMaster.all_objects.select_related('statmaster_id__item__contract__account').order_by('domain')
    serializer_class = OPConfigCSPadListSerializer
    paginate_by = None

    def get_queryset(self):
        qs = self.queryset

        item_id = self.request.GET.get('item_id', None)
        if not item_id:
            return Response({'detail': 'item_id must not None'}, status=HTTP_400_BAD_REQUEST)

        qs = qs.filter(statmaster_id__item__item_id=item_id)

        return qs

    def get(self, request, *args, **kwargs):
        return super(OPConfigCSPadList, self).list(request, *args, **kwargs)


class OPConfigAuthConfigAdd(mixins.CreateModelMixin, SpectrumGenericAPIView):
    serializer_class = OPConfigAuthConfigAddSerializer

    def post(self, request, *args, **kwargs):
        try:
            add_svc_name = request.DATA.get('add_svc_name', None)
            url = '%s/insertServiceNameAurora?user=%s&pass=%s&service_name=%s' % \
                  (AQUA_API_URL_PREFIX, AQUA_API_USER, AQUA_API_PASSWORD, add_svc_name)
            resp = urllib2.urlopen(url, timeout=10)
            if resp.getcode() != 200:
                raise Exception('Failed to insert service on AuthConfig: %d, %s' % (resp.status_code, resp.reason))

            return super(OPConfigAuthConfigAdd, self).create(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle ADD request on LegacyAddService."
            log_error(request, msg, e=e)
            raise e


class OPConfigAuthConfigDelete(mixins.DestroyModelMixin, SpectrumGenericAPIView):
    lookup_url_kwarg = "add_svc_id"
    model = LegacyAddService

    def delete(self, request, *args, **kwargs):
        try:
            add_svc_id = kwargs.get(self.lookup_url_kwarg, None)
            las = LegacyAddService.objects.get(add_svc_id=add_svc_id)
            url = '%s/deleteServiceNameAurora?user=%s&pass=%s&service_name=%s' % \
                  (AQUA_API_URL_PREFIX, AQUA_API_USER, AQUA_API_PASSWORD, las.add_svc_name)
            resp = urllib2.urlopen(url, timeout=10)
            if resp.getcode() != 200:
                raise Exception('Failed to insert service on AuthConfig: %d, %s' % (resp.status_code, resp.reason))

            return super(OPConfigAuthConfigDelete, self).destroy(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle DELETE request on LegacyAddService."
            log_error(request, msg, e=e)
            raise e
