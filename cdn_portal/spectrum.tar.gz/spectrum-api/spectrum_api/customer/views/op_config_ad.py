from __future__ import absolute_import

from spectrum_api.config_constants import AQUA_API_URL_PREFIX
from spectrum_api.config_constants import AQUA_API_USER
from spectrum_api.config_constants import AQUA_API_PASSWORD

from django.db import transaction

from rest_framework import mixins
from rest_framework.exceptions import NotAcceptable
from rest_framework.exceptions import ParseError

from spectrum_api.customer.serializers.op_config_ad import AquaDirectorSerializer
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.models.customer import CustomerAccount
from spectrum_api.shared_components.models.customer import LegacyAddService

from xml.dom import minidom

import urllib2


class OPConfigAquaDirector(mixins.ListModelMixin,
                           mixins.CreateModelMixin,
                           mixins.DestroyModelMixin, SpectrumGenericAPIView):
    queryset = LegacyAddService.objects.filter(add_svc_type='D').order_by('date_created')
    lookup_url_kwarg = 'add_svc_id'
    filter_fields = ({'account_no': 'account__account_no'},)
    serializer_class = AquaDirectorSerializer
    paginate_by = None

    def get(self, request, *args, **kwargs):
        return super(OPConfigAquaDirector, self).list(request, args, kwargs)

    @transaction.commit_on_success
    def post(self, request, *args, **kwargs):
        account = request.DATA.get('account')
        add_svc_name = request.DATA.get('add_svc_name')
        if account is None or add_svc_name is None:
            raise ParseError

        # Check duplication
        qs = self.queryset
        qs = qs.filter(add_svc_name=add_svc_name)
        if qs.count() > 0:
            raise NotAcceptable('Duplicated !! \'%s\' already in use.' % add_svc_name)

        # Register to Aqua auth config server
        customer = CustomerAccount.objects.get(account_no=account)
        url = '%s/registerDNS?user=%s&pass=%s&dns=%s&crc=%s&customer_name=%s&obj_state=1' % \
              (AQUA_API_URL_PREFIX, AQUA_API_USER, AQUA_API_PASSWORD,
               add_svc_name, self._check_crc16_ccitt_xmodem(add_svc_name),
               urllib2.quote(customer.account_name_local.encode('utf-8')))
        resp = urllib2.urlopen(url, timeout=10)
        if resp.getcode() != 200:
            raise Exception('Failed to add service on AuthConfig: %d, %s' % (resp.status_code, resp.reason))
        # Parsing XML
        dom = minidom.parseString(resp.read())
        ax_data = dom.getElementsByTagName('ax21:data')
        success = ax_data[0].getElementsByTagName('ax21:success')[0].firstChild.data
        msg = ax_data[0].getElementsByTagName('ax21:message')[0].firstChild.data
        if str(success) == '0':
            raise NotAcceptable('Failed register to AquaAuth config server: %s' % msg)
        return super(OPConfigAquaDirector, self).create(request, args, kwargs)

    # def delete(self, request, *args, **kwargs):
    #     return super(OPConfigAquaDirector, self).destroy(request, args, kwargs)

    @staticmethod
    def _check_crc16_ccitt_xmodem(message):
        # CRC-16-CITT poly, the CRC sheme used by ymodem protocol
        poly = 0x1021
        # 16bit operation register, initialized to zeros
        reg = 0x00
        # pad the end of the message with the size of the poly
        message += '\x00\x00'
        # for each bit in the message
        for byte in message:
            mask = 0x80
            while mask > 0:
                # left shift by one
                reg <<= 1
                # input the next bit from the message into the right hand side of the op reg
                if ord(byte) & mask:
                    reg += 1
                mask >>= 1
                # if a one popped out the left of the reg, xor reg w/poly
                if reg > 0xffff:
                    # eliminate any one that popped out the left
                    reg &= 0xffff
                    # xor with the poly, this is the remainder
                    reg ^= poly
        return reg
