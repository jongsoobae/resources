from __future__ import absolute_import

from rest_framework import mixins
from rest_framework.exceptions import NotAcceptable
from rest_framework.exceptions import ParseError

from spectrum_api.customer.serializers.op_config_lm import PublishPointSerializer

from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.models.customer import LegacyAddService


class OPConfigPublishPoint(mixins.ListModelMixin,
                           mixins.CreateModelMixin,
                           mixins.DestroyModelMixin, SpectrumGenericAPIView):
    queryset = LegacyAddService.objects.filter(add_svc_type='M').order_by('date_created')
    lookup_url_kwarg = 'add_svc_id'
    filter_fields = ({'account_no': 'account__account_no'},)
    serializer_class = PublishPointSerializer
    paginate_by = None

    def get(self, request, *args, **kwargs):
        return super(OPConfigPublishPoint, self).list(request, args, kwargs)

    def post(self, request, *args, **kwargs):

        account = request.DATA.get('account')
        add_svc_name = request.DATA.get('add_svc_name')
        if account is None or add_svc_name is None:
            raise ParseError

        qs = self.queryset
        qs = qs.filter(account__account_no=account, add_svc_name=add_svc_name)
        if qs.count() > 0:
            raise NotAcceptable('Duplicated !! This customer already has \'%s\'' % add_svc_name)

        return super(OPConfigPublishPoint, self).create(request, args, kwargs)

    def delete(self, request, *args, **kwargs):
        return super(OPConfigPublishPoint, self).destroy(request, args, kwargs)
