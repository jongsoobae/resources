from __future__ import absolute_import

from datetime import datetime
from datetime import timedelta
from django.db import transaction
from rest_framework import mixins
from rest_framework import status
from rest_framework.exceptions import APIException
from rest_framework.exceptions import ParseError
from rest_framework.exceptions import NotAcceptable
from rest_framework.response import Response

from spectrum_api.customer.serializers.op_config import PLATFORM_CODE_FMS
from spectrum_api.customer.serializers.op_config import PLATFORM_CODE_WMS
from spectrum_api.customer.serializers.op_config_ms import LegacyServiceDomainSerializer
from spectrum_api.customer.serializers.op_config_ms import StatServiceSerializer
from spectrum_api.customer.serializers.op_config_ms import StatKeywordSerializer
from spectrum_api.customer.serializers.op_config_ms import StatKeywordListSerializer

from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.models.customer import LegacyServiceDomain
from spectrum_api.shared_components.models.customer import CustomerItem
from spectrum_api.shared_components.models.customer import CustomerDisplay
from spectrum_api.shared_components.models import StatMaster
from spectrum_api.shared_components.models import LegacyStatMaster
from spectrum_api.shared_components.models import LegacyServiceDomainStatMap

import logging

log = logging.getLogger(__name__)


SVC_TYPE_STREAMING_W = 1
SVC_TYPE_STREAMING_W_WIN_2000 = 2
SVC_TYPE_STREAMING_F = 8


class OPConfigStatKeywordList(mixins.ListModelMixin, SpectrumGenericAPIView):
    queryset = LegacyServiceDomain.objects.all()
    lookup_url_kwarg = 'item_id'
    serializer_class = StatKeywordListSerializer
    paginate_by = None

    def get_queryset(self):
        return self.queryset.filter(item__item_id=self.kwargs.get(self.lookup_url_kwarg))

    def get(self, request, *args, **kwargs):
        return super(OPConfigStatKeywordList, self).list(request, args, kwargs)


class OPConfigServiceDomain(mixins.CreateModelMixin,
                            mixins.UpdateModelMixin,
                            mixins.DestroyModelMixin, SpectrumGenericAPIView):
    queryset = LegacyServiceDomain.objects.all()
    serializer_class = LegacyServiceDomainSerializer
    lookup_url_kwarg = 'svc_domain_id'

    def pre_save(self, obj):
        qr = LegacyServiceDomain.objects.filter(svc_domain_name=obj.svc_domain_name)
        if qr.exists():
            raise APIException('Duplicate service domain name.')

    def post(self, request, *args, **kwargs):
        return super(OPConfigServiceDomain, self).create(request, args, kwargs)

    def patch(self, request, *args, **kwargs):
        return super(OPConfigServiceDomain, self).partial_update(request, args, kwargs)

    def delete(self, request, *args, **kwargs):
        lsdsm = LegacyServiceDomainStatMap.objects.filter(svc_domain__svc_domain_id=self.kwargs.get(self.lookup_url_kwarg))
        if lsdsm.count() > 0:
            return Response({'detail': 'This service domain has stat_services. You can not delete it.'},
                            status=status.HTTP_406_NOT_ACCEPTABLE)
        return super(OPConfigServiceDomain, self).destroy(request, args, kwargs)


class OPConfigMSStatService(mixins.ListModelMixin, SpectrumGenericAPIView):
    queryset = LegacyStatMaster.objects.all()
    serializer_class = StatServiceSerializer
    lookup_url_kwarg = 'svc_domain_id'
    paginate_by = None

    def get_queryset(self):
        stat_map = LegacyServiceDomainStatMap.objects\
            .filter(svc_domain__svc_domain_id=self.kwargs.get(self.lookup_url_kwarg))
        stat_ids = stat_map.values_list('legacy_stat_id', flat=True)
        qs = LegacyStatMaster.objects.filter(statmaster_id__in=stat_ids)
        return qs

    def get(self, request, *args, **kwargs):
        return super(OPConfigMSStatService, self).list(request, args, kwargs)

    @transaction.commit_manually
    def post(self, request, *args, **kwargs):
        try:
            svc_domain_id = request.DATA.get('svc_domain_id')
            item_id = request.DATA.get('item_id')
            stat_svc_name = request.DATA.get('stat_svc_name')
            stat_svc_type = request.DATA.get('stat_svc_type')
            if None in [stat_svc_name, stat_svc_type, item_id]:
                raise ParseError("Bad Request")
            if stat_svc_type not in [str(SVC_TYPE_STREAMING_W),
                                     str(SVC_TYPE_STREAMING_W_WIN_2000),
                                     str(SVC_TYPE_STREAMING_F)]:
                raise ParseError("Bad Request, Unknown stat service type ")
            # check valid stat_svc_name
            OPConfigCheckValidMSStatService.check_valid_stat_svc_name(stat_svc_name)

            item = CustomerItem.objects.get(item_id=item_id)
            customer = CustomerDisplay.objects.get(account__account_no=item.contract.account.account_no,
                                                   ocsp_region=item.contract.ocsp_region)
            stat = StatMaster()
            stat.item = item
            stat.customer = customer
            stat.material_no = item.material_no
            stat.keyword = stat_svc_name
            stat.display_name = stat_svc_name
            stat.platform_no = PLATFORM_CODE_FMS if int(stat_svc_type) == SVC_TYPE_STREAMING_F else PLATFORM_CODE_WMS
            stat.platform_cd = int(stat_svc_type)
            stat.top_dir_depth = 1
            stat.save()

            lstat = LegacyStatMaster()
            lstat.statmaster_id = stat
            lstat.stat_svc_name = stat_svc_name
            lstat.save()

            svc_domain = LegacyServiceDomain.objects.get(svc_domain_id=svc_domain_id)
            stat_map = LegacyServiceDomainStatMap()
            stat_map.svc_domain = svc_domain
            stat_map.legacy_stat = lstat
            stat_map.save()

            transaction.commit()
            return Response({}, status=status.HTTP_200_OK)
        except APIException, e:
            transaction.rollback()
            return Response({'detail': e.detail}, status=e.status_code)
        except Exception, e:
            transaction.rollback()
            return Response({'detail': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class OPConfigUpdateMSStatService(SpectrumGenericAPIView):
    lookup_url_kwarg = 'stat_id'

    @transaction.commit_manually
    def patch(self, request, *args, **kwargs):
        try:
            stat_id = self.kwargs.get(self.lookup_url_kwarg)
            stat_svc_name = request.DATA.get('stat_svc_name')
            if not stat_id or not stat_svc_name:
                raise ParseError()

            qs = StatMaster.all_objects.filter(keyword=stat_svc_name)
            if qs.count() > 0:
                raise NotAcceptable('Duplication! \'%s\' is already in use.' % stat_svc_name)

            sm = StatMaster.all_objects.get(stat_id=stat_id)
            lsm = LegacyStatMaster.all_objects.get(statmaster_id=sm)
            sm.keyword = stat_svc_name
            sm.display_name = stat_svc_name
            lsm.stat_svc_name = stat_svc_name
            lsm.save()
            sm.save()

            transaction.commit()
            return Response({}, status=status.HTTP_200_OK)
        except APIException, e:
            transaction.rollback()
            return Response({'detail': e.detail}, status=e.status_code)
        except Exception, e:
            transaction.rollback()
            return Response({'detail': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class OPConfigMSKeyword(mixins.ListModelMixin,
                        mixins.UpdateModelMixin, SpectrumGenericAPIView):
    queryset = StatMaster.all_objects.all()
    serializer_class = StatKeywordSerializer
    lookup_url_kwarg = 'stat_id'
    paginate_by = None

    def get_queryset(self):
        qs = self.queryset
        if self.request.method.lower() == 'get':
            qs = qs.filter(parent_stat_id=self.kwargs.get(self.lookup_url_kwarg))
        return qs

    def get(self, request, *args, **kwargs):
        return super(OPConfigMSKeyword, self).list(request, args, kwargs)

    def patch(self, request, *args, **kwargs):
        try:
            if self.request.DATA.get('obj_state') == 1:
                # Inactive -> Active
                # We MUST check the keyword already use other contract.
                request_sm = StatMaster.all_objects.get(stat_id=self.kwargs.get(self.lookup_url_kwarg))

                qs = StatMaster.all_objects.filter(keyword=request_sm.keyword, parent_stat_id__isnull=False)
                sms = qs.values('item_id', 'obj_state', 'date_modified')
                for sm in sms:
                    if sm['obj_state'] > 0:
                        raise APIException('Duplicated! this value already used by item_id: %d' % sm['item_id'])
                    if sm['item_id'] != request_sm.item_id and sm['date_modified'] > datetime.now() - timedelta(days=1):
                        raise APIException(
                            'Not acceptable! You MUST NOT update this value while 24 hours from \'%s (GMT)\' '
                            '(item_id: %d)' % (sm['date_modified'], sm['item_id']))
            else:
                # Active -> Inactive
                pass
            return super(OPConfigMSKeyword, self).partial_update(request, args, kwargs)
        except APIException, e:
            return Response({'detail': e.detail}, status=e.status_code)
        except Exception, e:
            return Response({'detail': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @transaction.commit_manually
    def post(self, request, *args, **kwargs):
        try:
            stat_id = request.DATA.get('stat_id')
            keyword_name = request.DATA.get('keyword_name')
            daemon_type = request.DATA.get('daemon_type')
            if None in [stat_id, keyword_name, daemon_type]:
                raise ParseError()
            if daemon_type not in ['S', 'L']:
                raise ParseError()
            parent_stat = StatMaster.objects.get(stat_id=stat_id)
            # check valid keyword
            OPConfigCheckValidMSKeyword.check_valid_keyword(keyword_name, daemon_type, parent_stat.item_id)

            stat = StatMaster()
            stat.parent_stat_id = stat_id
            stat.item = parent_stat.item
            stat.customer = parent_stat.customer
            stat.material_no = parent_stat.material_no
            stat.keyword = keyword_name
            stat.display_name = keyword_name
            stat.platform_no = parent_stat.platform_no
            stat.platform_cd = parent_stat.platform_cd
            if stat.platform_cd in [SVC_TYPE_STREAMING_W, SVC_TYPE_STREAMING_F]:
                stat.daemon_type_cd = daemon_type
            stat.save()

            transaction.commit()
            return Response({}, status=status.HTTP_200_OK)
        except APIException, e:
            transaction.rollback()
            return Response({'detail': e.detail}, status=e.status_code)
        except Exception, e:
            transaction.rollback()
            return Response({'detail': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class OPConfigCheckValidMSStatService(SpectrumGenericAPIView):
    queryset = StatMaster.objects.all()

    @staticmethod
    def check_valid_stat_svc_name(stat_svc_name):
        if not stat_svc_name:
            raise ParseError()
        qs = StatMaster.all_objects.filter(keyword=stat_svc_name, obj_state__gt=0)
        item_ids = qs.values_list('item_id', flat=True)
        if item_ids:
            raise NotAcceptable('Duplicated! this value already used by item_id: %s' % str(item_ids))

    def get(self, request, *args, **kwargs):
        try:
            self.check_valid_stat_svc_name(request.QUERY_PARAMS.get('stat_svc_name'))
            return Response({}, status=status.HTTP_200_OK)
        except APIException, e:
            return Response({'detail': e.detail}, status=e.status_code)
        except Exception, e:
            return Response({'detail': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class OPConfigCheckValidMSKeyword(SpectrumGenericAPIView):
    queryset = StatMaster.objects.all()

    @staticmethod
    def check_valid_keyword(keyword, daemon_type, item_id):
        if not keyword or not item_id or item_id == 0 or (daemon_type != 'S' and daemon_type != 'L'):
            raise ParseError()
        if len(keyword) < 2:
            raise NotAcceptable('Keyword is too short.')
        if keyword[0] != '/':
            raise NotAcceptable('Keyword MUST begin with \'/\'.')
        if daemon_type == 'S' and keyword[-1] != '/':
            raise NotAcceptable('Keyword MUST begin with \'/\' and end with\'/\'.')

        # parent_stat_id__isnull=False means this StatMaster is keyword (not stat_service).
        qs = StatMaster.all_objects.filter(keyword=keyword, parent_stat_id__isnull=False)
        sms = qs.values('item_id', 'obj_state', 'date_modified')
        for sm in sms:
            if sm['obj_state'] > 0:
                raise APIException('Duplicated! this value already used by item_id: %d' % sm['item_id'])
            if sm['item_id'] == item_id:
                raise APIException('Duplicated! this contract already has \'%s\'' % keyword)
            elif sm['date_modified'] > datetime.now() - timedelta(days=1):
                raise APIException('Not acceptable! You MUST NOT update this value while 24 hours from \'%s (GMT)\' '
                                   '(item_id: %d)' % (sm['date_modified'], sm['item_id']))

    def get(self, request, *args, **kwargs):
        try:
            self.check_valid_keyword(request.QUERY_PARAMS.get('keyword'),
                                     request.QUERY_PARAMS.get('daemon_type'),
                                     int(request.QUERY_PARAMS.get('item_id')))
            return Response({}, status=status.HTTP_200_OK)
        except APIException, e:
            return Response({'detail': e.detail}, status=e.status_code)
        except Exception, e:
            return Response({'detail': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
