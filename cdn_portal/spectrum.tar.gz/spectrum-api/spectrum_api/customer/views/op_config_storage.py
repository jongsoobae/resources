from __future__ import absolute_import

from rest_framework import mixins
from rest_framework import status
from rest_framework.exceptions import APIException
from rest_framework.exceptions import ParseError
from rest_framework.response import Response

from spectrum_api.customer.serializers.storage_service import StorageServiceListSerializer
from spectrum_api.customer.serializers.op_config_storage import CSStatServiceListSerializer
from spectrum_api.customer.serializers.op_config_storage import LegacyStatServiceListSerializer
from spectrum_api.customer.serializers.op_config_storage import HermesMapStatMasterSerializer
from spectrum_api.customer.views.pal_soap_requests import get_service_set_list

from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.models import HermesMapStatMaster
from spectrum_api.shared_components.models import csStatMaster
from spectrum_api.shared_components.models import LegacyStatMaster

import logging

log = logging.getLogger(__name__)


class OPConfigStorageList(mixins.ListModelMixin, SpectrumGenericAPIView):
    queryset = HermesMapStatMaster.all_objects.select_related('stat_id__item').order_by('-date_modified')
    serializer_class = StorageServiceListSerializer
    paginate_by = None

    def get_queryset(self):
        item_id = self.kwargs.get('item_id')
        if not item_id:
            return Response({'detail': 'item_id must not None'}, status=status.HTTP_400_BAD_REQUEST)
        return self.queryset.filter(stat_id__item__item_id=item_id)

    def get(self, request, *args, **kwargs):
        return super(OPConfigStorageList, self).list(request, *args, **kwargs)


class OPConfigStatServiceList(mixins.ListModelMixin, SpectrumGenericAPIView):
    queryset = csStatMaster.objects.select_related('statmaster_id').order_by('domain')
    serializer_class = CSStatServiceListSerializer
    paginate_by = None

    def get_queryset(self):
        qs = self.queryset

        item_id = self.request.QUERY_PARAMS.get('item_id')
        stat_master_type = self.request.QUERY_PARAMS.get('stat_master_type')
        if not item_id or not stat_master_type:
            raise ParseError('item_id and stat_master_type must not None')

        if stat_master_type == 'ms':
            # Change target table from csStatMaster to LegacyStatMaster
            self.serializer_class = LegacyStatServiceListSerializer
            qs = LegacyStatMaster.objects.select_related('statmaster_id').order_by('stat_svc_name')
        elif stat_master_type != 'cs':
            raise APIException('Unsupported stat master type')

        return qs.filter(statmaster_id__item__item_id=item_id)

    def get(self, request, *args, **kwargs):
        return super(OPConfigStatServiceList, self).list(request, *args, **kwargs)


class OPConfigGetUploadServer(SpectrumGenericAPIView):
    def get(self, request, *args, **kwargs):
        try:
            region = request.QUERY_PARAMS.get('region')
            mgmt_server = request.QUERY_PARAMS.get('mgmt_server')
            service_set = request.QUERY_PARAMS.get('service_set')

            if not region or not mgmt_server or not service_set:
                return Response({'detail': 'Bad Request'}, status=status.HTTP_400_BAD_REQUEST)

            ss_dict = get_service_set_list(mgmt_server, region)[0]
            if service_set not in ss_dict:
                return Response({'detail': 'Not Found service set'}, status=status.HTTP_404_NOT_FOUND)

            return Response(ss_dict[service_set])
        except Exception, e:
            return Response({'detail': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class OPConfigStorageService(mixins.CreateModelMixin,
                             mixins.UpdateModelMixin,
                             mixins.DestroyModelMixin, SpectrumGenericAPIView):
    queryset = HermesMapStatMaster.objects.all()
    serializer_class = HermesMapStatMasterSerializer
    lookup_url_kwarg = 'hermesmap_id'

    def pre_save(self, obj):
        if self.request.method.lower() == 'post':
            qr = HermesMapStatMaster.objects.filter(stat_id__stat_id=obj.stat_id.stat_id,
                                                    corporation_cd=obj.corporation_cd, service_set=obj.service_set)
            if qr.exists():
                raise APIException('This stat service is already in use on the STAT')

    def post(self, request, *args, **kwargs):
        return super(OPConfigStorageService, self).create(request, args, kwargs)

    def patch(self, request, *args, **kwargs):
        return super(OPConfigStorageService, self).partial_update(request, args, kwargs)

    def delete(self, request, *args, **kwargs):
        return super(OPConfigStorageService, self).destroy(request, args, kwargs)
