# -*- coding: utf-8 -*-
from __future__ import absolute_import

from django.db.models import Q
from django.db.models import Count
from rest_framework import mixins
from rest_framework import status
from rest_framework.response import Response

from spectrum_api.customer.serializers.op_list import OPListSerializer
from spectrum_api.customer.views.common import get_cached_all_adusers
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.models.customer import CustomerSfaOrder
from spectrum_api.shared_components.models.customer import CustomerItemOperator

import logging

log = logging.getLogger(__name__)


class OPList(mixins.ListModelMixin, SpectrumGenericAPIView):
    queryset = CustomerSfaOrder.objects.select_related('item__contract__account', 'platform') \
        .filter(~Q(status=-1)).order_by('-create_time')
    filter_fields = ('status')

    serializer_class = OPListSerializer
    cached_ldap_users = None

    def get_queryset(self):
        qs = self.queryset

        contract_region = self.request.GET.get('contract_region', None)
        service_region = self.request.GET.get('service_region', None)
        name = self.request.GET.get('name', None)
        amsm = self.request.GET.get('amsm', None)
        start_date = self.request.GET.get('start_date', None)
        end_date = self.request.GET.get('end_date', None)
        termination_start = self.request.GET.get('termination_start', None)
        termination_end = self.request.GET.get('termination_end', None)
        task_type = self.request.GET.get('task_type', None)

        if name:
            qs = qs.filter(Q(item__contract__contract_no__icontains=name) |
                           Q(item__contract__contract_name__icontains=name) |
                           Q(item__material_desc__icontains=name) | Q(platform__platform_name__icontains=name) |
                           Q(item__contract__account__account_name_local__icontains=name) |
                           Q(csorderno__icontains=name))

        if service_region:
            if service_region.lower() == "global":
                qs = qs.filter(item__contract__ocsp_region=4000)
            else:
                qs = qs.exclude(item__contract__ocsp_region=4000)

        if contract_region:
            contract_region_code_list = contract_region.split(',')
            qs = qs.filter(item__contract__sales_org__in = contract_region_code_list)

        if amsm:
            if amsm.lower() in ('null', 'none') :
                sm_list = CustomerItemOperator.objects.values_list('item_id').distinct()
                qs = qs.exclude(Q(item__parent_item__item_id__in=sm_list) | Q(item__item_id__in = sm_list))
            else:
                find_list = []
                for email, display_name in self.cached_ldap_users.items():
                    if amsm in email or amsm in display_name:
                        find_list.append(email)
                item_ids = CustomerItemOperator.objects.filter(email__in=find_list).values_list('item__item_id', flat=True)
                qs = qs.filter(Q(item__contract__sales_rep_name__icontains=amsm) | Q(item__item_id__in=item_ids))

        if start_date:
            qs = qs.filter(create_time__gte=start_date)
        if end_date:
            qs = qs.filter(create_time__lte=end_date)

        if termination_start:
            qs = qs.filter(item__contract__contract_end__gte=termination_start)
        if termination_end:
            qs = qs.filter(item__contract__contract_end__lte=termination_end)

        if task_type:
            qs = qs.filter(work_type=task_type)

        return qs

    def get(self, request, *args, **kwargs):
        self.cached_ldap_users = get_cached_all_adusers()[1]

        qs = self.filter_queryset(self.get_queryset())

        response = super(OPList, self).list(request, *args, **kwargs)

        is_page_size_max = type(response.data) is list
        results = response.data if is_page_size_max else response.data['results']

        # Get customer_item_operator
        # We'll make
        # response.data['results']['data']['sm_prime'] = { prime info }
        # response.data['results']['data']['sm_sub'] = { sub info }
        # We use parent_item_id because
        item_ids = []
        for result in results:
            item_ids.append(result['parent_item_id'])
        operations = CustomerItemOperator.objects.filter(item__item_id__in=item_ids).values()
        op_prime_dict = {}
        op_sub_dict = {}
        for op in operations:
            sm_info = {
                'email': op['email'],
                'display_name': self.cached_ldap_users.get(op['email'], op['email'])
            }
            if op['prime'] is 1:
                op_prime_dict[op['item_id']] = sm_info
            elif op['prime'] is 2:
                op_sub_dict[op['item_id']] = sm_info

        for result in results:
            if result['parent_item_id'] in op_prime_dict:
                sm = op_prime_dict[result['parent_item_id']]
                result['sm_prime'] = {'email': sm['email'], 'display_name': sm['display_name']}
            if result['parent_item_id'] in op_sub_dict:
                sm = op_sub_dict[result['parent_item_id']]
                result['sm_sub'] = {'email': sm['email'], 'display_name': sm['display_name']}

        # We need status' count
        if not is_page_size_max :
            response.data['confirmed_count'] = 0
            response.data['requested_count'] = 0
            scounts = qs.values('status').annotate(status_count=Count('status'))
            for scount in scounts:
                if scount['status'] == 9:
                    response.data['confirmed_count'] = scount['status_count']  # Confirmed
                else:
                    response.data['requested_count'] = scount['status_count']  # Requested

        return response


class OPUpdateSMUser(SpectrumGenericAPIView):
    def patch(self, request, *args, **kwargs):
        try:
            if 'prime' in request.DATA:
                try:
                    cio = CustomerItemOperator.objects.get(item__item_id=request.DATA['item_id'], prime=1)
                    cio.email = request.DATA['prime']
                    cio.save()
                except:
                    CustomerItemOperator.objects.create(
                        email=request.DATA['prime'],
                        item_id=request.DATA['item_id'],
                        prime=1
                    )

            if 'sub' in request.DATA:
                try:
                    cio = CustomerItemOperator.objects.get(item__item_id=request.DATA['item_id'], prime=2)
                    cio.email = request.DATA['sub']
                    cio.save()
                except:
                    CustomerItemOperator.objects.create(
                        email=request.DATA['sub'],
                        item_id=request.DATA['item_id'],
                        prime=2
                    )
            return Response({'detail': 'updated'}, status=status.HTTP_200_OK)
        except Exception, e:
            log.warn('Failed \'%d\' update SM User: %s', (request.DATA['item_id'], str(e)))
            return Response({'detail': str(e), 'status': status.HTTP_500_INTERNAL_SERVER_ERROR})


class OPGetActiveUsers(SpectrumGenericAPIView):
    def get(self, request, *args, **kwargs):
        try:
            return Response({'factor': 'success', 'users': get_cached_all_adusers()[0]})
        except Exception, e:
            log.warn('Failed get active users: %s', str(e))
            return Response({'detail': str(e), 'status': status.HTTP_500_INTERNAL_SERVER_ERROR})
