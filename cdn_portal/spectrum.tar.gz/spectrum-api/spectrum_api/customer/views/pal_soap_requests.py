from django.core.cache import cache
from httplib import HTTPConnection
from spectrum_api import config_constants
from xml.dom import minidom

SERVICE_SET_CACHE_KEY = 'SERVICE_SET_%s_CACHE_KEY'
MGMT_SERVER_CACHE_KEY = 'MGMT_SERVER_%s_CACHE_KEY'

SERVICE_SET_CACHE_TIME = 300        # 5 minutes
MGMT_SERVER_CACHE_TIME = 14400      # 4 hours

url = "/PALSyncManager15.asmx"

host_pal = {
    'kr': config_constants.HOST_PAL_KR,
    'us': config_constants.HOST_PAL_US,
    'jp': config_constants.HOST_PAL_JP,
    'cn': config_constants.HOST_PAL_CN,
    'sg': config_constants.HOST_PAL_SG,
    'uk': config_constants.HOST_PAL_UK
}


def send_request(func, body, region):
    host_region = host_pal[region.lower()]
    conn = HTTPConnection(host_region)
    conn.request("POST", url, body=body, headers={"SOAPAction": "http://pal.cdnetworks.com/{func}".format(func=func), "Host": host_region, "Content-Type": "text/xml; charset=utf-8"})
    data = conn.getresponse().read()
    dom_obj = minidom.parseString(data)
    return dom_obj


def get_management_host_list(region):
    try:
        cached_data = cache.get(MGMT_SERVER_CACHE_KEY % region.upper())
        if cached_data:
            return cached_data
    except:
        pass

    body = """<?xml version="1.0" encoding="utf-8"?>
    <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
      <soap:Body>
        <GetManagementHostList xmlns="http://pal.cdnetworks.com/" />
      </soap:Body>
    </soap:Envelope>
     """
    dom_obj = send_request("GetManagementHostList", body, region)
    result = []
    mgmt_list = dom_obj.getElementsByTagName("ManagementHostList")
    for mgmt in mgmt_list:
        tmp_dict = {}
        for child in mgmt.childNodes:
            tmp_dict[child.tagName] = child.lastChild.nodeValue
        result.append(tmp_dict)

    if len(result) > 0:
        cache.set(MGMT_SERVER_CACHE_KEY % region.upper(), result, MGMT_SERVER_CACHE_TIME)
    return result


def get_service_set_list(mgmt_hostname, region):
    try:
        cached_data = cache.get(SERVICE_SET_CACHE_KEY % mgmt_hostname.upper())
        if cached_data:
            return cached_data
    except:
        pass

    body = """<?xml version="1.0" encoding="utf-8"?>
    <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
      <soap:Body>
        <GetServiceSetList xmlns="http://pal.cdnetworks.com/">
          <management>{management}</management>
          <cp_name></cp_name>
          <serviceset></serviceset>
        </GetServiceSetList>
      </soap:Body>
    </soap:Envelope>""".format(management=mgmt_hostname)
    dom_obj = send_request("GetServiceSetList", body, region)

    service_set_dict = {}
    service_set_list = []
    service_sets = dom_obj.getElementsByTagName("ServicesetList")
    for service_set in service_sets:
        tmp_dict = {}
        for child in service_set.childNodes:
            tmp_dict[child.tagName] = child.lastChild.nodeValue
        service_set_dict[tmp_dict['servicesetID']] = tmp_dict
        service_set_list.append(tmp_dict['servicesetID'])

    service_set_list.sort()
    result = [service_set_dict, service_set_list]
    cache.set(SERVICE_SET_CACHE_KEY % mgmt_hostname.upper(), result, SERVICE_SET_CACHE_TIME)
    return result
