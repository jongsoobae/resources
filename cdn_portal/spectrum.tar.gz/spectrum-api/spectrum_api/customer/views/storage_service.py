from __future__ import absolute_import

from django.db.models import Q
from rest_framework import mixins
from rest_framework import status
from rest_framework.exceptions import ParseError
from rest_framework.response import Response

from spectrum_api.customer.serializers.storage_service import StorageServiceListSerializer
from spectrum_api.customer.views.pal_soap_requests import get_management_host_list
from spectrum_api.customer.views.pal_soap_requests import get_service_set_list

from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.models import HermesMapStatMaster
from spectrum_api.shared_components.models import csStatMaster
from spectrum_api.shared_components.models import LegacyStatMaster

import logging

log = logging.getLogger(__name__)


class MgmtServerList(SpectrumGenericAPIView):
    def get(self, request, *args, **kwargs):
        try:
            param_region = request.QUERY_PARAMS.get('region', None)
            param_mgmt_server = request.QUERY_PARAMS.get('mgmt_server', None)
            if param_region is None:
                return Response({'detail': 'Bad Request', 'status': status.HTTP_400_BAD_REQUEST})

            if param_mgmt_server:
                service_sets = get_service_set_list(param_mgmt_server, param_region)
                return Response({'factor': 'success', 'service_set_list': service_sets[1]})

            mgmt_servers = get_management_host_list(param_region)
            return Response({'factor': 'success', 'mgmt_server_list': mgmt_servers})
        except Exception, e:
            err_msg = 'Failed to get management server list: %s' % str(e)
            log.warn(err_msg)
            return Response({'detail': err_msg, 'status': status.HTTP_500_INTERNAL_SERVER_ERROR})


class StorageServiceList(mixins.ListModelMixin, SpectrumGenericAPIView):
    queryset = HermesMapStatMaster.all_objects.select_related('stat_id__item').order_by('-date_modified')
    filter_fields = ('id',)
    serializer_class = StorageServiceListSerializer

    def get_queryset(self):
        qs = self.queryset

        region = self.request.GET.get('region', None)
        stat_service = self.request.GET.get('stat_service', None)
        mgmt_server = self.request.GET.get('mgmt_server', None)
        service_set = self.request.GET.get('service_set', None)

        if region is None:
            raise ParseError()

        qs = qs.filter(corporation_cd=region)

        if service_set:
            qs = qs.filter(service_set=service_set)

        if stat_service:
            stat_ids = qs.values_list('stat_id', flat=True)
            cs_stat_qs = csStatMaster.objects.filter(statmaster_id__stat_id__in=stat_ids,
                                                     domain__icontains=stat_service)
            cs_stat_ids = cs_stat_qs.values_list('statmaster_id__stat_id', flat=True)
            legacy_stat_qs = LegacyStatMaster.objects.filter(statmaster_id__stat_id__in=stat_ids,
                                                             stat_svc_name__icontains=stat_service)
            legacy_stat_ids = legacy_stat_qs.values_list('statmaster_id__stat_id', flat=True)
            qs = qs.filter(Q(stat_id__in=cs_stat_ids) | Q(stat_id__in=legacy_stat_ids))

        if mgmt_server:
            tmp_service_set = []
            sset_list = get_service_set_list(mgmt_server, region)
            for sset in sset_list[1]:
                tmp_service_set.append(sset)
            qs = qs.filter(service_set__in=tmp_service_set)

        return qs

    def get(self, request, *args, **kwargs):
        return super(StorageServiceList, self).list(request, *args, **kwargs)

