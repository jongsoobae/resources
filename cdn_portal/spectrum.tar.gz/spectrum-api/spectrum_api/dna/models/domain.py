#
# Copyright (c) 2011 CDNetworks Co., Ltd.
# All rights reserved.
#
# $Id: domain.py 12145 2014-02-13 04:26:08Z injune.hwang $
#
from datetime import datetime
from datetime import timedelta
import re
import traceback

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import RegexValidator
from django.core.validators import MinValueValidator
from django.core.validators import MaxValueValidator
from django.core.validators import MaxLengthValidator
from django.db import models
from django.db.models import Q
from django.utils.translation import ugettext as _

from spectrum_api.configuration.models.preset_relay import MproxyPreset

from spectrum_api.configuration.models import Model
from spectrum_api.shared_components.models import HistoryModel, save_snapshot_obj, ActionRelatedSnapshot
from spectrum_api.configuration.models import InterimModel
from spectrum_api.configuration.models.base import BaseProbeConfig
from spectrum_api.configuration.models.base import Edge
from spectrum_api.configuration.models.base import Vip
from spectrum_api.configuration.models.base import VipProbeConfigs
from spectrum_api.configuration.models.base import Pop
from spectrum_api.configuration.models.base import VipSearch

from spectrum_api.configuration.models.clb import CLBAlertGroup
from spectrum_api.configuration.models.clb import CLBAlertManagementBase
from spectrum_api.configuration.models.clb import __DEF_CLB_ALERT_GROUP_NAME__
from spectrum_api.configuration.models.clb import CLBAlertGroupHasCLBDomain

from spectrum_api.configuration.models.gslb import DomainProperties
from spectrum_api.configuration.models.gslb import PopMetric
from spectrum_api.configuration.models.gslb import DistanceMetric
from spectrum_api.configuration.models.gslb import LB_TYPES
from spectrum_api.configuration.models.gslb import SELECT_TYPES

from spectrum_api.dna.models import DNA_EDGE_DOMAIN
from spectrum_api.dna.models import DNA_SHIELD_DOMAIN
from spectrum_api.dna.models import DNA_RELAY_DOMAIN
from spectrum_api.dna.models import DNA_ORIGIN_DOMAIN
from spectrum_api.dna.models import GSLB_DOMAIN
from spectrum_api.dna.models import DOMAIN_ALIAS
from spectrum_api.dna.models import WPO_DOMAIN

from spectrum_api.dna.models.help_msg import H_PROBE_METRIC
from spectrum_api.dna.models.help_msg import H_PROBE_METRIC_INC
from spectrum_api.dna.models.help_msg import H_PROBE_METRIC_SC
from spectrum_api.dna.models.help_msg import H_DOMAIN_NAME
from spectrum_api.dna.models.help_msg import H_BACKUP_ANSWER
from spectrum_api.dna.models.help_msg import H_DOMAIN_DESC
from spectrum_api.dna.models.help_msg import H_EDGE_DOMAIN
from spectrum_api.dna.models.help_msg import H_MPROXY_APP
from spectrum_api.dna.models.help_msg import H_DOMAIN_ALIAS_NAME
from spectrum_api.dna.models.help_msg import H_ENABLE_GSLB
from spectrum_api.dna.models.help_msg import H_LB_TYPE
from spectrum_api.dna.models.help_msg import H_ANSWER_COUNT
from spectrum_api.dna.models.help_msg import H_ANSWER_TTL
from spectrum_api.dna.models.help_msg import H_CONDITION_SEQUENCE
from spectrum_api.dna.models.help_msg import H_STATIC_RULE
from spectrum_api.dna.models.help_msg import H_GSLB_STATICRULE_CONDITION_INVERT
from spectrum_api.dna.models.help_msg import H_ACTION_SEQUENCE
from spectrum_api.dna.models.help_msg import H_PROBE_INC
from spectrum_api.dna.models.help_msg import H_PROBE_SCALING
from spectrum_api.dna.models.help_msg import H_WEIGHT
from spectrum_api.dna.models.help_msg import H_PRIORITY
from spectrum_api.dna.models.help_msg import H_DELAY_START_TIME

from spectrum_api.dns.models.dns import DNSZone
from spectrum_api.sap.sap_calls import update_sap_cs_stats
from spectrum_api.sap.sap_calls import get_connection

from spectrum_api.shared_components.models import StatMaster
from spectrum_api.shared_components.models.customer import CustomerDisplay
from spectrum_api.shared_components.models.customer import CustomerItem
from spectrum_api.shared_components.models.customer import CustomerSfaOrder
from spectrum_api.shared_components.models.customer import CustomerContract

from spectrum_api.shared_components.utils.common import get_vips_by_ipaddr
from spectrum_api.shared_components.utils.common import log_error
from spectrum_api.shared_components.utils.regex import gslb_domain_rex
from spectrum_api.shared_components.utils.regex import REGEX_APP_NAME
from spectrum_api.shared_components.utils.validate_static_rule import validate_static_rule


# from spectrum_api.dna.models.mproxy import MproxyApp
TIMEOUT = 30  # deploy time out minutes
DSP_DEPS_LIMIT = 10
DEV_LOCK_TIMEOUT = 30
DOMAIN_STATUS = (
            (0, 'Modified'),
            (1, 'Pending Testing'),
            (2, 'Sent to Stage'),
            (3, 'Promote to Production'),
            (4, 'In Production'),
            (-2, 'Pending Failed'),
            (-4, 'Production Failed'),
            )
STATIC_RULE_CONDITION_TYPE = (
    (0, 'always'),
    (1, 'iprange'),
    (2, 'geodata'),
    (3, 'percent'),
)
MONITORING_TYPE = ((0,'Default'),(1,'KR Sejong Monitoring'))
STATIC_RULE_ACTION_TYPE = (
    (0, 'deny'),
    (1, 'vip'),
    (2, 'cname'),
    (3, 'ip_a'),
)

regex_client = "^\s*client\.ip\s*\=\s*(?P<client_ip>.*)\s*$"
regex_geo = "^\s*client\.(?P<geo_scale>continent|country|region|isp|asn)\s*\=\s*(?P<geo_data>.*)\s*$"
regex_percent = "^\s*request\.portion\s*\=\s*(?P<percent>\d+)\s*$"
regex_always = "^\s*always\s*$"

re_parse_clientip = re.compile(regex_client, re.IGNORECASE| re.MULTILINE)
re_parse_geo = re.compile(regex_geo, re.IGNORECASE| re.MULTILINE)
re_parse_percent = re.compile(regex_percent, re.IGNORECASE| re.MULTILINE)
re_parse_always = re.compile(regex_always, re.IGNORECASE| re.MULTILINE)

DOMAIN_TYPE = (
        (DNA_EDGE_DOMAIN, 'DNA_EDGE'),
        (DNA_SHIELD_DOMAIN, 'DNA_SHIELD'),
        (DNA_RELAY_DOMAIN, 'DNA_RELAY'),
        (DNA_ORIGIN_DOMAIN, 'DNA_ORIGIN'),
        (GSLB_DOMAIN, 'GSLB'),
        (WPO_DOMAIN, 'WPO'),
        (DOMAIN_ALIAS, 'DOMAIN_ALIAS'),
    )
class ProbeMetric(HistoryModel):
    probe = models.ForeignKey(
        BaseProbeConfig,
        null=True,
        blank=True,
        help_text=H_PROBE_METRIC
    )
    probe_increment = models.FloatField(
        null=True,
        blank=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_PROBE_METRIC_INC
    )
    probe_scaling_factor = models.FloatField(
        null=True,
        blank=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_PROBE_METRIC_SC
    )

    class Meta:
        abstract = True


class Domain(DomainProperties, PopMetric, DistanceMetric, ProbeMetric):
    domain_id = models.AutoField(primary_key=True)
    name = models.CharField(
        max_length=255,
        help_text=H_DOMAIN_NAME,
        unique=True,
        verbose_name="Domain",
        validators=[RegexValidator(gslb_domain_rex)]
    )
    vips = models.ManyToManyField(Vip, through='DomainVip')
    customer = models.ForeignKey(CustomerDisplay,
        null=True,
        blank=True)
    domain_type = models.SmallIntegerField(
        choices=DOMAIN_TYPE,
        editable=True)
    config_state = models.SmallIntegerField(editable=False)
    date_created = models.DateTimeField(
        'Date Created',
        auto_now_add=True
    )
    date_modified = models.DateTimeField(
        'Date Modified',
        auto_now=True
    )
    backupanswer = models.TextField(
        "Backup Answer",
        blank=True,
        help_text=H_BACKUP_ANSWER)
    system_ignore = models.BooleanField(default=True, editable=False)
    parent_domain = models.ForeignKey('self',
        blank=True, null=True, editable=False)
    # mproxyapp = models.ManyToManyField('MproxyApp', through='GslbDomainMproxyApp')
    is_admin = models.BooleanField()
    status = models.PositiveSmallIntegerField(default=0, editable=False, choices=DOMAIN_STATUS)
    time_deployed = models.DateTimeField(editable=False, null=True)
    clb_dns_zone = models.ForeignKey(DNSZone, null=True,
                                     db_column='clb_dns_zone',
                                     related_name='dnszone_set')
    monitoring_type = models.SmallIntegerField(default=0, choices=MONITORING_TYPE)
    description = models.TextField(
        'Description',
        max_length=1024,
        validators=[MaxLengthValidator(1024)],
        help_text=H_DOMAIN_DESC,
        blank=True)
    latest_updater = models.CharField(max_length=100)

    mproxy_preset = models.ForeignKey(MproxyPreset, null=True,
                                      db_column='mproxy_preset_id')

    delay_start_time = models.PositiveIntegerField(
        blank=True,
        null=True,
        validators=[MinValueValidator(1), MaxValueValidator(172800)],
        help_text=H_DELAY_START_TIME
    )

    def __unicode__(self):
        return '%s' % (self.name)

    class Meta:
        app_label = 'dna'
        db_table = 'gslb_domain'

    class SpectrumMeta:
        allow_delete = True
        parent = 'clb_dns_zone'
        keep_latest_change_action_id = True
        log_diff_skip_fields = ['status']

    def save_related_object_as_snapshot(self, action_id):
        """
        this function overrides HistoryModel's method and save snapshot data of custom defined related objects
        'related_to_serialize' keyword at 'SpectrumMeta' only support Foreign key related objects and
        does not support other related objects like manytomany relation.
        CLB domain needs snapshot data for restore feature.
        """
        try:
            #if self.clb_dns_zone:
            domainvips = DomainVip.objects.filter(domain=self)
            if domainvips.exists():
                save_snapshot_obj(domainvips, self._meta.db_table, self.pk, action_id)

            static_conditions = DomainStaticRuleCondition.objects.filter(domain=self)
            if static_conditions.exists():
                save_snapshot_obj(static_conditions, self._meta.db_table, self.pk, action_id)

            for static_condition in static_conditions:
                static_actions = DomainStaticRuleAction.objects.filter(condition=static_condition)
                if static_actions.exists():
                    save_snapshot_obj(static_actions, static_condition._meta.db_table, static_condition.pk, action_id)

        except Exception,e:
            pass

    def getGslbStatus(self):
        if self.enable_gslb == 1:
            return 'UP'
        elif self.enable_gslb == 0:
            return 'DOWN'
        else:
            return 'UP'

    def get_answer_ttl(self):
        if self.answer_ttl:
            return self.answer_ttl
        else:
            return 60

    def get_answer_count(self):
        if self.answer_count:
            return self.answer_count
        else:
            return 1

    def get_load_balancing_type_value(self):
        if self.load_balancing_type:
            return self.load_balancing_type
        else:
            return 0

    def get_load_balancing_type(self):
        if self.load_balancing_type:
            return LB_TYPES[self.load_balancing_type][1]
        else:
            return LB_TYPES[0][1]  # if null, it should be admin mode : gslb type

    def has_mproxyedge_or_mproxyvip(self):
        # from spectrum_api.dna.models.domain import MproxyApp
        if self.pk:
            mproxyapp = MproxyApp.objects.filter(edge_domain=self)
            if mproxyapp.count() > 0:
                return mproxyapp[0].has_mproxyedge_or_mproxyvip()
            else:
                return False
        else:
            return False

    def is_related_with_wpo(self):
        from spectrum_api.wpo.models.wpo import WPOCluster, WPOWid
        if self.pk:
            if WPOCluster.objects.filter(primary_cluster_domain=self).exists():
                return True
            elif WPOCluster.objects.filter(staging_cluster_domain=self).exists():
                return True
            elif WPOWid.objects.filter(host_domain=self).exists():
                return True
            elif WPOWid.objects.filter(backup_host_domain=self).exists():
                return True
            elif WPOWid.objects.filter(staging_host_domain=self).exists():
                return True

        return False

    def is_valid_config(self):
        vips = self.get_related_vips()
        if self.pk:
            domainconditions = DomainStaticRuleCondition.objects.filter(domain=self)
        else:
            domainconditions = DomainStaticRuleCondition.objects.none()
        if len(vips) > 0:
            return True
        elif domainconditions.exists():
            return True
        else:
            return False

    def is_mproxy_safe(self):
        if self.get_system_edges().exists():
            return True
        elif self.get_system_vips().exists():
            return True
        else:
            return False

    def get_config_status(self):
        # if self.is_valid_config():
        if self.config_state:
            return 'ok'
        else:
            return ''

    def create_or_replace_cname_static_rule(self, cname_domain, request=None):
        try:
            static_rule_conditions = DomainStaticRuleCondition.objects.filter(domain=self)
            static_rule_actions = DomainStaticRuleAction.objects.filter(condition__in=static_rule_conditions)

            static_rule_actions.delete()
            static_rule_conditions.delete()

            static_rule_condition = DomainStaticRuleCondition()
            static_rule_condition.domain = self
            static_rule_condition.policy_name = str(cname_domain)
            static_rule_condition.sequence = 1
            static_rule_condition.condition = "always"
            static_rule_condition.save(request=request)

            static_rule_action = DomainStaticRuleAction()
            static_rule_action.condition = static_rule_condition
            static_rule_action.action = "response.answer = CNAME, 3600, %s " \
                                        "\nfollow_cname = true" % (cname_domain)
            static_rule_action.sequence = 1
            static_rule_action.save(request=request)
        except Exception, e:
            raise e

    def get_conditions(self):
        if self.pk:
            return DomainStaticRuleCondition.objects.filter(domain=self.pk)
        else:
            return DomainStaticRuleCondition.objects.none()

    def get_actions(self, condition=None):
        if condition and condition.pk:
            return DomainStaticRuleAction.objects.filter(condition=condition.pk)
        else:
            return DomainStaticRuleAction.objects.filter(condition__in=self.get_conditions().values('domain_staticrule_condition_id'))

    def get_system_edges(self, edge=None):
        if self.pk:
            if edge is not None:
                return DomainEdge.objects.filter(domain=self.pk, edge=edge)
            else:
                return DomainEdge.objects.filter(domain=self.pk)
        else:
            return DomainEdge.objects.none()

    def get_edge_names(self):
        resultlist = []
        domainedges = self.get_system_edges()
        for domainedge in domainedges:
            resultlist.append("%s," % (domainedge.edge.name))

        result = ''.join(resultlist)
        if result.endswith(","):
            return result[0:len(result) - 1]
        else:
            return result

    def get_system_vips(self, vip=None):
        if self.pk:
            if vip is not None:
                return DomainVip.objects.filter(domain=self.pk, vip=vip)
            else:
                return DomainVip.objects.filter(domain=self.pk)
        else:
            return DomainVip.objects.none()

    def add_vip(self, request, vip):
        domainvips = self.get_system_vips(vip)
        if not domainvips.exists():
            domainvip = DomainVip(domain=self, vip=vip)
            domainvip.save(request=request)
            domainvip.update_history(request)
            self.update_domain_config_status(request)

    def add_edge(self, request, edge):
        domainedges = self.get_system_edges(edge)
        if not domainedges.exists():
            domainedge = DomainEdge(domain=self, edge=edge)
            domainedge.save(request=request)
            domainedge.update_history(request)
            self.update_domain_config_status(request)

    def set_probeconfig(self, request, probeconfig):
        self.probe_id = probeconfig.pk
        self.save(request=request)
        # check_probe_constraint

    def get_clb_service_broken_vips(self):
        broken_vips = []
        if self.clb_dns_zone:
            # domainvips = self.get_system_vips()
            vips = self.get_related_vips()  # get all vips including edge_through vips
            # for domainvip in domainvips:
            for vip in vips:
                status = vip.get_service_status()
                # if status != 'failure': #for test purposes
                if status == 'failure':
                    if vip not in broken_vips:
                        broken_vips.append(str(vip))
            return broken_vips

        else:
            return broken_vips

    def get_related_starfs(self):
        """"this function generates starfs monitor status html"""
        from spectrum_api.cloudstorage.models.cloudstorage import Storage, StorageCluster, \
            StorageSidVhosts, StorageClusterVhosts
        result = {}
        _domain_title_ = "title"
        _domain_value_ = "value"

        _STORAGE_NAME_ = "storage_name"
        _STORAGE_ID_ = "storage_id"
        _STORAGE_DOMAINS = "domains"

        try:
            if self.probe.name == 'starfs':
                storage = Storage.objects.filter(Q(data_domain=self) |
                                                 Q(upload_domain=self) |
                                                 Q(https_origin_domain=self) |
                                                 Q(https_upload_domain=self))
                if storage.exists():
                    pass
                else:
                    storage_cluster = StorageCluster.objects.filter(Q(backup_domain=self) |
                                                                    Q(backup_https_domain=self) |
                                                                    Q(backup_upload_domain=self) |
                                                                    Q(backup_https_upload_domain=self))
                    if storage_cluster.exists():
                        storage = Storage.objects.filter(pk=storage_cluster[0].storage.pk)
                    else:
                        storage_vhosts = StorageSidVhosts.objects.filter(Q(gslb_service_domain=self) |
                                                                         Q(https_service_domain=self))
                        if storage_vhosts.exists():
                            storage = Storage.objects.filter(pk=storage_vhosts[0].storage.pk)
                        else:
                            storage_vhosts_cluster = StorageClusterVhosts.objects.filter(Q(backup_domain=self) |
                                                                                         Q(backup_https_domain=self))
                            if storage_vhosts_cluster.exists():
                                storage = Storage.objects.filter(pk=storage_vhosts_cluster[0].vhosts.storage.pk)
                            else:
                                return result

                storage_vhosts = StorageSidVhosts.objects.filter(storage=storage)

                related_origin_domains = []
                related_upload_domains = []
                related_vhosts_domains = []
                origin_domains = []
                upload_domains = []
                vhosts_domains = []

                if storage.exists():
                    if storage[0].data_domain:
                        origin_domains.append(storage[0].data_domain.name)
                    if storage[0].https_origin_domain:
                        origin_domains.append(storage[0].https_origin_domain.name)
                    if storage[0].upload_domain:
                        upload_domains.append(storage[0].upload_domain.name)
                    if storage[0].https_upload_domain:
                        upload_domains.append(storage[0].https_upload_domain.name)

                if storage_vhosts.exists():
                    for vhosts in storage_vhosts:
                        if vhosts.gslb_service_domain:
                            vhosts_domains.append(vhosts.gslb_service_domain.name)
                        if vhosts.https_service_domain:
                            vhosts_domains.append(vhosts.https_service_domain.name)

                sid_list = {_STORAGE_NAME_:"%s" % (storage[0].storage_name),
                            _STORAGE_ID_:storage[0].pk}

                if len(origin_domains) > 0:
                    related_origin_domains = [{_domain_title_:"origin domain", _domain_value_: origin_domains}]
                if len(upload_domains) > 0:
                    related_upload_domains = [{_domain_title_:"upload domain", _domain_value_: upload_domains}]
                if len(vhosts_domains) > 0:
                    related_vhosts_domains = [{_domain_title_:"vhosts domain", _domain_value_: vhosts_domains}]

                storage_domains = related_origin_domains + related_upload_domains + related_vhosts_domains

                result.update(sid_list)
                result.update({_STORAGE_DOMAINS:storage_domains})
            else:
                return result

        except Exception as e:
            pass

        return result

    def get_related_mproxy(self):
        """"this function generates mproxy edge monitor status html"""
        from spectrum_api.dna.models.mproxy import MproxyDomainVip, MproxyDomainEdge
        result = {}
        _domain_title_ = "title"
        _domain_value_ = "value"

        _MPROXY_APP_NAME_ = "mproxy_app_name"
        _MPROXY_APP_ID_ = "mproxy_app_id"
        _MPROXY_DOMAINS = "domains"

        _EDGE_DOMAIN_ = "edge domain"

        try:
            if self.is_mproxy_related():
                def _domain_item(data, domain_type='shield'):
                    key = "%s_domain__name"%(domain_type)
                    buf = []
                    for domain_val in data:
                        if domain_val[key] is not None:
                            buf.append(domain_val[key])
                        else:
                            continue

                    buf = set(buf)

                    for i in buf:
                        yield {
                                _domain_title_: "%s domain"%(domain_type),
                                _domain_value_: i
                            }

                mproxy_app_condition_field = {
                    DNA_EDGE_DOMAIN : ["edge_domain",],
                    DNA_SHIELD_DOMAIN : ["mproxydomainedge__shield_domain",
                                        "mproxydomainvip__shield_domain"],
                    DNA_ORIGIN_DOMAIN : ["mproxydomainedge__origin_domain",
                                        "mproxydomainvip__origin_domain"],
                    DNA_RELAY_DOMAIN : ["mproxydomainedge__relay_domain",
                                        "mproxydomainvip__relay_domain"],
                }

                mproxy_node_condition_field = {
                    DNA_SHIELD_DOMAIN : "shield_domain",
                    DNA_ORIGIN_DOMAIN : "origin_domain",
                    DNA_RELAY_DOMAIN : "relay_domain",
                }

                qs = Q()
                for field in mproxy_app_condition_field[self.domain_type]:
                    qs |= Q(**{field: self})

                mproxyapp = MproxyApp.objects.filter(qs)

                mproxy_node_filter = {
                    "mproxy_app__in" : mproxyapp
                }

                if mproxy_node_condition_field.has_key(self.domain_type):
                    mproxy_node_filter.update({
                        mproxy_node_condition_field[self.domain_type] : self
                    })

                mproxy_edge = MproxyDomainEdge.objects.filter(**mproxy_node_filter)
                mproxy_vip = MproxyDomainVip.objects.filter(**mproxy_node_filter)

                edge_domains = []
                shield_domains = []
                origin_domains = []
                relay_domains = []

                related_domains = []
                mproxy_domains = []

                if mproxy_edge.exists():
                    rdomains = mproxy_edge.values('shield_domain__name',
                                                'origin_domain__name',
                                                'relay_domain__name',)
                    related_domains = [i for i in rdomains]

                if mproxy_vip.exists():
                    rdomains = mproxy_vip.values('shield_domain__name',
                                                'origin_domain__name',
                                                'relay_domain__name',)
                    related_domains = related_domains + [i for i in rdomains]

                mproxy_app_list = {_MPROXY_APP_NAME_:"%s" % (mproxyapp[0].mproxy_app_name),
                                    _MPROXY_APP_ID_:mproxyapp[0].pk}

                if self.domain_type != DNA_EDGE_DOMAIN:
                    edge_domain_names = mproxyapp.distinct('edge_domain__name')
                    edge_domains = [{_domain_title_:_EDGE_DOMAIN_, _domain_value_: i}
                                    for i in edge_domain_names]

                if self.domain_type != DNA_SHIELD_DOMAIN:
                    shield_domains = [i for i in _domain_item(related_domains, 'shield')]

                if self.domain_type != DNA_ORIGIN_DOMAIN:
                    origin_domains = [i for i in _domain_item(related_domains, 'origin')]

                if self.domain_type != DNA_RELAY_DOMAIN:
                    relay_domains = [i for i in _domain_item(related_domains, 'relay')]

                mproxy_domains = edge_domains + shield_domains + origin_domains + relay_domains

                result.update(mproxy_app_list)
                result.update({_MPROXY_DOMAINS:mproxy_domains})
            else:
                return result

        except Exception as e:
            pass

        return result

    def is_mproxy_related(self):
        return self.domain_type == DNA_EDGE_DOMAIN or self.domain_type == DNA_SHIELD_DOMAIN or self.domain_type == DNA_RELAY_DOMAIN or self.domain_type == DNA_ORIGIN_DOMAIN

    def get_all_related_popnames(self):
        popnames = []
        domainedges = self.get_system_edges()
        for domainedge in domainedges:
            for vip in domainedge.getvips():
                popname = vip.getpopname()
                if popname not in popnames:
                    popnames.append(popname)

        for domainvip in self.get_system_vips():
            popname = domainvip.vip.getpopname()
            if popname not in popnames:
                popnames.append(popname)
        return popnames

    def get_related_edge_popnames(self):
        popnames = []
        domainedges = self.get_system_edges()
        for domainedge in domainedges:
            for vip in domainedge.getvips():
                popname = vip.getpopname()
                if popname not in popnames:
                    popnames.append(popname)

        return popnames

    def get_related_vip_popnames(self):
        popnames = []
        for domainvip in self.get_system_vips():
            popname = domainvip.vip.getpopname()
            if popname not in popnames:
                popnames.append(popname)

        return popnames

    def get_related_vips(self):
        """
        deprecated: don't use this anymore. use get_all_related_vips which is more fast and has lighter query
        beware get_all_related_vips return queryset result instead of list
        :return:
        """
        vips = []

        domainedges = self.get_system_edges()
        for domainedge in domainedges:
            for vip in domainedge.getvips():
                if vip not in vips:
                    vips.append(vip)

        for domainvip in self.get_system_vips():
            if domainvip.vip not in vips:
                vips.append(domainvip.vip)

        return vips

    def get_all_related_vips(self):
        domainedges = DomainEdge.objects.filter(domain=self.pk).values('edge')
        domainvips = DomainVip.objects.filter(domain=self.pk).values('vip')
        vips = Vip.objects.filter(Q(edge__in=domainedges)|Q(pk__in=domainvips)).distinct() #.order_by('host__system__pop')
        return vips

    def get_related_domainvips_with_rms(self):
        from spectrum_api.configuration.models.node_mon import DomainVipStatus
        domainvip_status_set = DomainVipStatus.objects.filter(domain=self)
        return domainvip_status_set

    def get_related_vips_with_default_probe(self):
        '''vips whose domain does not have domainedge's probe or domainvip's probe
        if default domain probe is none, return all related vips
        '''
        vips = []
        domainedges = self.get_system_edges()
        for domainedge in domainedges:
            if not domainedge.probe:
                for vip in domainedge.getvips():
                    if vip not in vips:
                        vips.append(vip)

        for domainvip in self.get_system_vips():
            if not domainvip.probe:
                if domainvip.vip not in vips:
                    vips.append(domainvip.vip)

        return vips

    def get_domain_aliases(self):
        if self.pk:
            return DomainAlias.objects.filter(domain=self.pk)
        else:
            return DomainAlias.objects.none()

    def get_clb_zone(self):
        if self.clb_dns_zone:
            return DNSZone.objects.filter(zone_id=self.clb_dns_zone.pk)
        else:
            return DNSZone.objects.none()

    def get_deploy_status_text(self):
        msg = ''
        if self.is_clb_domain():
            if self.status < 0:
                msg = "(domain deploy failed)"
            if self.status == 1 or self.status == 3:
                msg = "(domain deploy pending)"
        return msg

    def get_full_domain_name(self):
        if self.clb_dns_zone:
            return self.name  # + "." +self.clb_dns_zone.domain_name
        else:
            return self.name

    def get_related_items(self):

        from spectrum_api.dna.models.mproxy import MproxyDomainEdge, MproxyDomainVip

        # default related item list
        related_item_list = [
            (DomainAlias, DomainAlias.objects.filter(domain=self)[:DSP_DEPS_LIMIT]),
            (Vip, self.get_system_vips()[:DSP_DEPS_LIMIT]),
            (Edge, self.get_system_edges()[:DSP_DEPS_LIMIT]),
            (DomainStaticRuleCondition, self.get_conditions()[:DSP_DEPS_LIMIT]),
            (DomainStaticRuleAction, self.get_actions()[:DSP_DEPS_LIMIT])
        ]

        if self.domain_type == DNA_EDGE_DOMAIN:
            try:
                mproxyapp = MproxyApp.objects.filter(edge_domain=self.pk)[0]

                related_item_list += [
                    (Domain, Domain.objects.filter(parent_domain=self)[:DSP_DEPS_LIMIT]),
                    (MproxyDomainEdge, MproxyDomainEdge.objects.filter(mproxy_app=mproxyapp)[:DSP_DEPS_LIMIT]),
                    (MproxyDomainVip, MproxyDomainVip.objects.filter(mproxy_app=mproxyapp)[:DSP_DEPS_LIMIT])
                ]

            except Exception:
                related_item_list.append((Domain, Domain.objects.filter(parent_domain=self)[:DSP_DEPS_LIMIT]))

        elif self.domain_type in [DNA_SHIELD_DOMAIN, DNA_RELAY_DOMAIN, DNA_ORIGIN_DOMAIN]:

            try:
                mproxyapp = MproxyApp.objects.filter(edge_domain=self.parent_domain)[0]

                related_item_list += [
                    (MproxyDomainEdge, MproxyDomainEdge.objects.filter(mproxy_app=mproxyapp)[:DSP_DEPS_LIMIT]),
                    (MproxyDomainVip, MproxyDomainVip.objects.filter(mproxy_app=mproxyapp)[:DSP_DEPS_LIMIT])
                ]

            except Exception:
                pass

        else:
            if self.clb_dns_zone:
                # from spectrum_fe.dns.models.dns import DNSZone
                pass

            else:
                if self.domain_type == WPO_DOMAIN:
                    from spectrum_api.wpo.models.wpo import WPOCluster, WPOWid

                    related_item_list += [
                        (WPOCluster, WPOCluster.objects.filter(
                            Q(primary_cluster_domain=self) | Q(staging_cluster_domain=self))[:DSP_DEPS_LIMIT]),
                        (WPOWid, WPOWid.objects.filter(
                            Q(host_domain=self) | Q(staging_host_domain=self) | Q(backup_host_domain=self))[:DSP_DEPS_LIMIT]),
                    ]

                # Check Domain is used in StarFS Components
                elif self.domain_type == GSLB_DOMAIN and self.probe and self.probe.name == 'starfs':

                    from spectrum_api.cloudstorage.models.cloudstorage import Storage
                    from spectrum_api.cloudstorage.models.cloudstorage import StorageCluster
                    from spectrum_api.cloudstorage.models.cloudstorage import StorageSidVhosts
                    from spectrum_api.cloudstorage.models.cloudstorage import StorageClusterVhosts

                    related_item_list += [
                        (Storage, Storage.objects.filter(
                            Q(data_domain=self) | Q(upload_domain=self) | Q(master_domain=self) | Q(https_origin_domain=self) | Q(https_upload_domain=self)
                        )[:DSP_DEPS_LIMIT]),

                        (StorageCluster, StorageCluster.objects.filter(
                            Q(backup_domain=self) | Q(backup_https_domain=self) | Q(backup_upload_domain=self) | Q(backup_https_upload_domain=self)
                        )[:DSP_DEPS_LIMIT]),

                        (StorageSidVhosts, StorageSidVhosts.objects.filter(
                            Q(gslb_service_domain=self) | Q(https_service_domain=self)
                        )[:DSP_DEPS_LIMIT]),

                        (StorageClusterVhosts, StorageClusterVhosts.objects.filter(
                            Q(backup_domain=self) | Q(backup_https_domain=self)
                        )[:DSP_DEPS_LIMIT])
                    ]

        # return related item list
        return tuple(related_item_list)

    # def add_required_domain_probeconfigs_to_related_vips(self, request):
    #    if self.probe:
    #        related_vips = self.get_related_vips_with_default_probe()
    #        for vip in related_vips:
    #            vip.add_required_domain_probeconfig(request, self)

    def check_probe_constraint(self, request, required_probe=None, force_update=False):
        is_valid = True
        check_message = ''
        msglist = []

        if self.pk:
            if required_probe is None:
                required_probe = self.probe
            # if self.probe != required_probe:  # probeconfig changed
            if required_probe is not None:
                vips = self.get_related_vips()  # self.get_related_vips_with_default_probe()
                for basevip in vips:
                    probevips = VipProbeConfigs.objects.filter(vip=basevip, probe=required_probe)
                    if not probevips.exists():
                        if force_update:
                            probevip = VipProbeConfigs(vip=basevip, probe=required_probe)
                            probevip.save(request=request)
                        is_valid = False
                        msglist.append(str(basevip))

                check_message = "Domain probe '%s' is required to be included in vips '%s'." % (str(required_probe), '\r\n'.join(msglist))

        if force_update:
            return True, check_message
        else:
            return is_valid, check_message

    def is_clb_domain(self):
        if self.clb_dns_zone:
            return True
        else:
            return False

    def is_clb_customer_mode(self):
        ''' in case domain is clb and in customer mode, it is not allowed to modify at prism side.
        '''
        if self.pk and self.clb_dns_zone:
            if self.is_admin:
                return False
            else:
                return True
        else:
            return False

    # def is_clb_customer_mode(self):
    #    try:
    #        if self.is_clb_domain() and not self.is_admin:
    #            return True
    #        else:
    #            return False
    #    except: # has no pk, no way to find out clb mode
    #        return False

    def delete_all_related(self, request):
        try:
            conditions_set = DomainStaticRuleCondition.all_objects.filter(domain=self)
            for condition_obj in conditions_set:
                actions_set = DomainStaticRuleAction.all_objects.filter(condition=condition_obj)
                for action_obj in actions_set:
                    action_obj.delete(request=request)
                condition_obj.delete(request=request)

            domainvips = DomainVip.objects.filter(domain=self)
            if domainvips.exists():
                for domainvip in domainvips:
                    domainvip.delete(request=request)
                    # self.update_system_ignore(request)
            self.delete(request=request)
        except Exception, e:
            log_error(request, str(e), e)

    def is_deletable(self):
        # staticrules = self.get_conditions()
        # clbzone = self.get_clb_zone()
        # domainaliases = self.get_domain_aliases()
        # vips = self.get_system_vips()
        # edges = self.get_system_edges()

        # if staticrules.exists():
        #    return False
        # elif clbzone.exists():
        #    return False
        # elif domainaliases.exists():
        #    return False
        # elif vips.exists():
        #    return False
        # elif edges.exists():
        #    return False
        if self.is_mproxy_related() and self.has_mproxyedge_or_mproxyvip():
            return False
        elif self.is_related_with_wpo():
            return False
        elif self.probe and self.probe.name == 'starfs':
            # Cloud Storage 2.7 - if probe name is starfs, cannot delete
            return False
        else:
            return True

    def update_domain_config_status(self, request):
        """
        In order to lock unfinished config before publishing, we need to keep domain config_state info up to date.
        """
        # valid_state = self.is_valid_config()
        # if valid_state != self.config_state:
        #    self.config_state = valid_state
        self.save(request=request)

    def update_mproxy_config_status(self, request):
        """
        if this domain has to do with mproxy app, update mproxy config state also.
        """
        if self.domain_type == DNA_EDGE_DOMAIN:
            try:
                mproxyapp = MproxyApp.objects.get(edge_domain=self)
                mproxyapp.update_mproxy_config_status(request=request)
            except:
                pass
        elif self.domain_type in [DNA_SHIELD_DOMAIN, DNA_RELAY_DOMAIN, DNA_ORIGIN_DOMAIN]:
            try:
                mproxyapp = MproxyApp.objects.get(edge_domain=self.parent_domain)
                mproxyapp.update_mproxy_config_status(request=request)
            except:
                pass

    # means this domain has no vip/edge available ==> deprecated
    def update_system_ignore(self, request):
        """
        If there are no vips and no edges for this domain,
        system_ignore should be True.
        """
        edges = self.get_system_edges()
        vips = self.get_system_vips()

        self.system_ignore = False
        if edges.count() == 0 and vips.count() == 0:
            self.system_ignore = True
        self.save(request=request)

    def normalize_rules(self, request=None):
        if self.pk and self.clb_dns_zone:
            # if self.is_admin:
            #    pass
            # else:
            try:
                domain_conditions = DomainStaticRuleCondition.objects.filter(domain=self)
                for domain_condition in domain_conditions:
                    try:
                        domain_condition.normalize_condition(request=request)
                        domain_actions = DomainStaticRuleAction.objects.filter(condition=domain_condition)
                        for domain_action in domain_actions:
                            domain_action.normalize_action(request=request)

                    except Exception, e:
                        log_error(request, str(e), e)
                        raise e
                self.is_admin = 0
                self.save(request=request)
            except Exception, e:
                self.is_admin = 1
                self.save(request=request)
        else:
            pass

    def change_clb_admin_mode(self, request):
        if self.pk and self.clb_dns_zone:
            if self.is_admin:
                self.is_admin = 0  # customer mode ==> normalize condition action
                domain_conditions = DomainStaticRuleCondition.objects.filter(domain=self)

                if self.etc_policy is not None:
                    next_etc_policy_rules = domain_conditions.filter(sequence__gt=self.etc_policy.sequence)

                    if next_etc_policy_rules.exists():
                        raise Exception(_("There is some rules after \"always\" condition rule."
                                        " \"always\" condition rule have to set last before change to \"Customer Mode\""))

                for domain_condition in domain_conditions:
                    domain_condition.normalize_condition(request=request)
                    domain_actions = DomainStaticRuleAction.objects.filter(condition=domain_condition)
                    for domain_action in domain_actions:
                        domain_action.normalize_action(request=request)
            else:
                self.is_admin = 1
                domain_conditions = DomainStaticRuleCondition.objects.filter(domain=self)
                for domain_condition in domain_conditions:
                    domain_condition.denormalize_conditions()
        else:
            raise Exception('clb zone for domain %s does not exist.' % (self.name))

        self.save(request=request)

    def get_clb_serverips(self):
        serverlist = []
        try:
            if self.pk and self.clb_dns_zone:
                vips = self.get_related_vips()  # get all vips including edge_through vips
                # for vip in self.vips.all():
                for vip in vips:
                    serverlist.append(str(vip))

            return " ".join(serverlist)
        except:
            return ''

    def get_clb_attrib(self):
        try:
            from spectrum_api.configuration.models.clb import CustomerContractPop
            item = None
            if self.pk and self.clb_dns_zone:
                serverlist = []
                server_group_list = []
                vips = self.get_related_vips()  # get all vips including edge_through vips
                # for vip in self.vips.all():
                for vip in vips:
                    cust_pop_obj = CustomerContractPop.all_objects.get(pop=vip.host.system.pop)
                    serverlist.append("%s %s %s" % (cust_pop_obj.pop_alias, vip.vip_alias_name, vip))
                    if not cust_pop_obj in server_group_list:
                        server_group_list.append(cust_pop_obj.pop_alias)
                servers = ','.join(serverlist)

                domain_conditions = DomainStaticRuleCondition.objects.filter(domain=self)
                condition_list = []
                for domain_condition in domain_conditions:
                    condition_list.append(str(domain_condition.get_attrib()))
                # domain_action = DomainStaticRuleAction.objects.filter(condition = domain_condition)
                conditions = ','.join(condition_list)

                probe_name = ''
                if self.probe:
                    probe_name = self.probe.name

                item = {'Zone Name': self.clb_dns_zone.domain_name,
                       # 'Server Groups':'',
                       'Servers':servers,
                       'Domain Name':self.name,
                       'Number of Answer':str(self.get_answer_count()),
                       'Default TTL':str(self.get_answer_ttl()),
                       'Dynamic Selection Type':self.get_load_balancing_type(),
                       'Health Check':probe_name,
                       'Policies':conditions}
        except:
            item = None
        return item

    def get_clb_detail_for_customer(self):
        result_list = []
        errmsg = ''
        try:
            from spectrum_api.configuration.models.clb import CustomerContractPop
            if self.pk and self.clb_dns_zone:
                result_list.append("Zone Name: %s" % (self.clb_dns_zone.domain_name))
                result_list.append("Domain Name: %s" % (self.name))
                result_list.append("Number of Answer: %s" % (str(self.get_answer_count())))
                result_list.append("Default TTL: %s" % (str(self.get_answer_ttl())))
                result_list.append("Dynamic Selection Type: %s" % (self.get_load_balancing_type()))

                if self.probe:
                    result_list.append("Health Check: %s" % (self.probe.name))
                else:
                    result_list.append("Health Check: %s" % (''))
                serverlist = []
                server_group_list = []
                result_list.append("")
                result_list.append("Servers:")
                vips = self.get_related_vips()  # get all vips including edge_through vips
                # for vip in self.vips.all():
                for vip in vips:
                    try:
                        cust_pop_obj = CustomerContractPop.all_objects.get(pop=vip.host.system.pop)
                        serverlist.append("%s %s %s" % (cust_pop_obj.pop_alias, vip.vip_alias_name, vip))
                        if not cust_pop_obj in server_group_list:
                            server_group_list.append(cust_pop_obj.pop_alias)
                    except:
                        pass
                servers = '\r\n'.join(serverlist)
                result_list.append(servers)

                if self.is_admin:
                    result_list.append("")
                    result_list.append("**Policies are locked and only can be managed by admin user. If you want to change policy, please contact our domain administrator at support@cdnetworks.com.")
                    result_list.append("")
                    domain_conditions = DomainStaticRuleCondition.objects.filter(domain=self)
                    # condition_list = []
                    result_list.append("Policies:")
                    for domain_condition in domain_conditions:
                        # condition_list.append(str(domain_condition.get_attrib()))
                        result_list.append(str(domain_condition.get_admin_conditions_for_customer()))
                else:
                    domain_conditions = DomainStaticRuleCondition.objects.filter(domain=self)
                    # condition_list = []
                    result_list.append("")
                    result_list.append("Policies:")
                    for domain_condition in domain_conditions:
                        # condition_list.append(str(domain_condition.get_attrib()))
                        result_list.append(str(domain_condition.get_denormalized_condition_for_customer()))
                    # domain_action = DomainStaticRuleAction.objects.filter(condition = domain_condition)
                    # conditions = ','.join(condition_list)
            else:
                errmsg = 'clb zone for domain %s does not exist.' % (self.name)
        except Exception, e:
            errmsg = str(e)
            # log_error(None,errmsg,e)
        return "\r\n".join(result_list), errmsg

    def get_clb_policies_for_customer(self):
        result_list = []
        errmsg = ''
        try:
            if self.pk and self.clb_dns_zone:
                domain_conditions = DomainStaticRuleCondition.objects.filter(domain=self)
                # condition_list = []
                # result_list.append("Policies:")
                for domain_condition in domain_conditions:
                    # condition_list.append(str(domain_condition.get_attrib()))
                    if self.is_admin:
                        result_list.append(str(domain_condition.get_admin_conditions_for_customer()))
                    else:
                        result_list.append(str(domain_condition.get_denormalized_condition_for_customer()))
                # domain_action = DomainStaticRuleAction.objects.filter(condition = domain_condition)
                # conditions = ','.join(condition_list)
            else:
                errmsg = 'clb zone for domain %s does not exist.' % (self.name)
        except Exception, e:
            errmsg = str(e)
        return "\r\n".join(result_list), errmsg

    def is_related_clb_zone_pending(self):
        if self.clb_dns_zone:
            zone_status = int(self.clb_dns_zone.status)
            if zone_status == 1 or zone_status == 3:
                return True
            else:
                return False
        else:
            return False

    def get_timeout(self):
        right_now = datetime.now()
        date_modified = self.date_modified
        if settings.DEBUG:
            time2compare = timedelta(minutes=DEV_LOCK_TIMEOUT)
        else:
            time2compare = timedelta(minutes=TIMEOUT)
        timeout = False
        if (right_now - date_modified) > time2compare:
            timeout = True
        return timeout

    def is_modifiable(self):
        '''if domain deploy status is 'pending' or 'locked', it won't be modifiable
        '''

        self.status = int(self.status)
        if self.status == 1 or self.status == 3:  # pending to stage, pending to production
            # if settings.DEBUG and self.get_timeout():
                # this generally not happen at production servers where be_config running all the time.
                # But in dev environment where be_config not running, this needs to be accounted.
            #    return True
            # else:
            return False
        else:
            return True

    def is_pushable(self):
        return self.is_production_pushable()

    def is_stage_pushable(self):
        '''if domain deploy status is 'new','modified' or 'staging', it won't be pushable
        '''
        self.status = int(self.status)
        if self.status < 2:
            return True
        return False

    def is_production_pushable(self):
        '''if domain deploy status is 'new','modified' or 'staging', it won't be pushable
        '''
        self.status = int(self.status)
        if self.status < 4:
            return True
        return False

    def get_deploy_status(self):
        for TEMPSTATUS in DOMAIN_STATUS:
            if TEMPSTATUS[0] == self.status:
                if not self.time_deployed and self.status == 0:
                    return _(u'New')
                else:
                    return TEMPSTATUS[1]

        return self.status

    def clean(self):
        PE_DNS_DYNAMIC_ZONES = ['cdngc.net', 'cdngm.net', 'gccdn.net', 'gccdn.cn']

        for pe_dnszone_suffix in  PE_DNS_DYNAMIC_ZONES:
            if self.name.strip().lower().endswith(pe_dnszone_suffix):
                raise ValidationError({'detail':"Invalid domain name %s. Domain name ends with PE DNS Dynamic Zone name." % (self.name)})

        if self.name.count('*') > 1:
            raise ValidationError({'detail':"Invalid domain name %s. '*' cannot be more than once." % (self.name)})

        if self.is_clb_domain():
            if not self.is_modifiable():
                raise ValidationError({'detail':"This CLB domain is in pending lock status. Please wait until the lock is released. status: %s." % (self.get_deploy_status())})
            if self.is_related_clb_zone_pending():
                raise ValidationError({'detail':"This CLB domain's DNS Zone '%s' is in pending lock status. Please wait until the lock is released." % (self.clb_dns_zone.domain_name)})

    def delete(self, *args, **kwargs):
        if self.clb_dns_zone:
            request = kwargs.get("request", None)
            try:
                keyword = "%s." % (self.name.strip("."))
                stat = StatMaster.objects.get(keyword=keyword,
                                    customer=self.clb_dns_zone.customer,
                                    material_no=getattr(settings, "CLB_MATERIAL"))
                stat.obj_state = 2  # set inactive
                stat.save(request=request)
                self.clb_dns_zone.status = 0
                self.clb_dns_zone.save(request=request)
            except Exception as e:
                pass
        super(Domain, self).delete(*args, **kwargs)

    def save(self, *args, **kwargs):
        request = kwargs.get("request")
        self.name = self.name.strip(".")  # avoid domain name start with . (comma)
        stat_keyword = "%s." % (self.name.strip("."))
        is_dirty = False
        if self.pk:
            if self.clb_dns_zone:
                is_dirty = False
                if not self.is_modifiable():
                    raise Exception('This CLB domain is locked. status: %s' % (self.get_deploy_status()))
                else:
                    self.status = 0
                    try:
                        self.clb_dns_zone.status = 0
                        self.clb_dns_zone.save(request=request)
                    except:
                        pass

                    # valid host_name is changed.
                    previous_config = self.__class__._default_manager.get(pk=self.pk)
                    if self.name != previous_config.name:
                        is_dirty = True

            valid_state = self.is_valid_config()
            if valid_state != self.config_state:
                self.config_state = valid_state

        if self.clb_dns_zone:
            # CLB Domain have to set log_request True -- @AURORAUI-422
            self.log_request=True

        self.latest_updater = request.enduser.username
        super(Domain, self).save(*args, **kwargs)
        try:
            self.update_mproxy_config_status(request=request)
        except Exception, e:
            log_error(request, str(e), e)

        # if clb domain add stat_domain
        if self.clb_dns_zone:
            # check stat_domain
            try:
                if is_dirty:
                    # if name is changed. change stat_master.obj_state set to 2
                    old_keyword = "%s." % (previous_config.name.strip("."))
                    old_stat = StatMaster.objects.get(keyword=old_keyword,
                                        customer=self.clb_dns_zone.customer,
                                        material_no=getattr(settings, "CLB_MATERIAL"))
                    old_stat.obj_state = 2  # set inactive
                    old_stat.save(request=request)
            except Exception as e:
                log_error(request, str(e), e)

            try:
                stat_domain = StatMaster.all_objects.get(keyword=stat_keyword,
                                                    customer=self.clb_dns_zone.customer,
                                                    material_no=getattr(settings, "CLB_MATERIAL"))

                if stat_domain.obj_state != 1:
                    """
                    if obj_state is not 1 ( active ) set active
                    """
                    stat_domain.obj_state = 1
                    stat_domain.save(request=request)
            except StatMaster.DoesNotExist:
                parent_stat = self.clb_dns_zone.dnsstatmaster_set.all()[0].statmaster
                clb_stat_params = {
                                    "keyword": stat_keyword,
                                    "display_name" : stat_keyword.strip("."),
                                    "obj_state" : 1,
                                    "material_no" : getattr(settings, "CLB_MATERIAL"),
                                    "customer" : self.clb_dns_zone.customer,
                                    "parent_stat_id" : parent_stat.stat_id,
                                    "item_id" : parent_stat.item_id
                                }
                stat_domain = StatMaster(**clb_stat_params)
                stat_domain.save(request=request)
            except Exception as e:
                log_error(request, str(e), e)

            # Check alert group
            try:
                root_alert_group = CLBAlertGroup.objects.get(group_type__exact=0,
                                                        alert_base_id__account_no=self.clb_dns_zone.customer.account)
            except (CLBAlertGroup.DoesNotExist, CLBAlertManagementBase.DoesNotExist):
                if self.clb_dns_zone.customer.account.sales_org == 1000:
                    tz_ = "GMT_15"
                elif self.clb_dns_zone.customer.account.sales_org == 2000:
                    tz_ = "GMT_16"
                elif self.clb_dns_zone.customer.account.sales_org == 3000:
                    tz_ = "GMT_20"
                else:
                    tz_ = "GMT_61"

                base_mgr, mgr_created = CLBAlertManagementBase.objects.get_or_create(alert_gmt_cd=tz_,
                                                        account_no=self.clb_dns_zone.customer.account)

                root_alert_group, group_created = CLBAlertGroup.objects.get_or_create(group_type=0,
                                                            sort_order=0, alert_base_id=base_mgr,
                                                            clb_group_name=__DEF_CLB_ALERT_GROUP_NAME__)

            except Exception as e:
                log_error(request, str(e), e)

            try:
                domain_alert_group = CLBAlertGroupHasCLBDomain.objects.get(statmaster=stat_domain)
            except CLBAlertGroupHasCLBDomain.DoesNotExist:
                domain_alert_group = CLBAlertGroupHasCLBDomain(clb_alert_group=root_alert_group,
                                                            statmaster=stat_domain)
                domain_alert_group.save()
            except Exception as e:
                log_error(request, str(e), e)

    @property
    def policies(self):
        try:
            staticruleconditions = self.domainstaticrulecondition_set.exclude(condition="always")
            return staticruleconditions
        except:
            return []

    @policies.setter
    def policies(self, value):
        pass

    @property
    def etc_policy(self):
        try:
            staticruleconditions = self.domainstaticrulecondition_set.filter(condition="always")
            if staticruleconditions.exists():
                return staticruleconditions.order_by('sequence')[0]
            else:
                raise Exception("No rules.")
        except:
            return None

    @etc_policy.setter
    def etc_policy(self, value):
        pass

    @property
    def host_name(self):
        try:
            if self.clb_dns_zone:
                replaced_zone_name = r"%s$" % (self.clb_dns_zone.domain_name)
                host_name = re.sub(replaced_zone_name, "", self.name).strip(".")
            else:
                host_name = self.name

            return host_name
        except:
            return self.name

    @host_name.setter
    def host_name(self, value):
        try:
            root_name = self.clb_dns_zone.domain_name
            if value.endswith(root_name):
                host_name = value.replace(root_name, "")
                host_name = host_name.strip(".")
                if len(host_name) == "":
                    host_name = value
                else:
                    host_name = "%s.%s" % (host_name, root_name)
            else:
                host_name = "%s.%s" % (value, root_name)

            self.name = host_name.strip(".")
        except:
            self.name = value.strip(".")

    def snapshot_base_relation(self):
        """
        Make snapshot of between zone (clb domains) and related POP
        """
        from spectrum_api.dna.models.domain import DomainVip, BasePopDNSZoneRelation
        domainvips = DomainVip.objects\
                                .filter(domain__clb_dns_zone=self.clb_dns_zone)\
                                .distinct('vip')
        related_vips = [d.vip for d in domainvips]
        pops = Pop.objects.filter(pop__system__host__vip_host_set__vip__in=related_vips)\
                        .distinct('pop')

        for pop in pops:
            try:
                rel = BasePopDNSZoneRelation(pop=pop, zone=self.clb_dns_zone)
                rel.save()
            except:
                pass

class MproxyApp(Model):
    mproxy_app_id = models.AutoField(primary_key=True)
    edge_domain = models.ForeignKey(Domain, db_column='edge_domain_id',
        help_text=H_EDGE_DOMAIN)
    obj_state = models.PositiveSmallIntegerField(default=1)
    config_state = models.SmallIntegerField(editable=False)
    mproxy_app_name = models.CharField(max_length=251, unique=True, help_text=H_MPROXY_APP, validators=[RegexValidator(REGEX_APP_NAME)])
    customer = models.ForeignKey(CustomerDisplay,
        db_column='customer_id',
        blank=True,
        null=True)
    # stat = models.ManyToManyField(StatMaster, db_table='mproxy_app_stat_master', related_name='mproxyapp_set')
    date_created = models.DateTimeField('Date Created', auto_now_add=True)
    date_modified = models.DateTimeField('Date Modified', auto_now=True)
    contract = models.ForeignKey(CustomerContract, db_column='contract_no', null=True)
    latest_updater = models.CharField(max_length=100)
    description = models.CharField(max_length=1024, blank=True)

    def __unicode__(self):
        return '%s' % (self.mproxy_app_name)

    def clean(self):
        pass

    def has_mproxyedge_or_mproxyvip(self):
        from spectrum_api.dna.models.mproxy import MproxyDomainEdge, MproxyDomainVip
        mproxyvips = MproxyDomainVip.objects.filter(mproxy_app=self)
        mproxyedges = MproxyDomainEdge.objects.filter(mproxy_app=self)

        if mproxyvips.count() > 0:
            return True
        else:
            if mproxyedges.count() > 0:
                for mproxyedge in mproxyedges:
                    if mproxyedge.get_vips().count() > 0:
                        return True
            return False

    def get_domainedges(self):
        mproxyedges = self.get_mproxyedges()
        # domainedges = DomainEdge.objects.filter(domain=self.edge_domain)
        domainedges = DomainEdge.objects.filter(pk__in=mproxyedges.values('domain_edge'))
        return domainedges

    def is_valid_config(self):
        result = True
        if self.has_mproxyedge_or_mproxyvip():
            result = True
            # if self.edge_domain.is_valid_config():
            if self.edge_domain.is_mproxy_safe():
                result = True
                # domains = Domain.objects.filter(parent_domain=self.edge_domain)
                # for domain in domains:
                #    if domain.is_valid_config():
                #        result = True
                #    else:
                #        result = False
                #        break
            else:
                result = False
        else:
            result = False

        return result

    def get_config_status(self):
        if self.is_valid_config():
            return 'ok'
        else:
            return ''

    def get_domainvips(self):
        mproxyvips = self.get_mproxyvips()
        domainvips = DomainVip.objects.filter(pk__in=mproxyvips.values('domain_vip'))
        return domainvips

    def get_mproxyedges(self):
        from spectrum_api.dna.models.mproxy import MproxyDomainEdge
        mproxyedges = MproxyDomainEdge.objects.filter(mproxy_app=self)
        return mproxyedges

    def get_mproxyedgecount(self):
        return self.get_mproxyedges().count()

    def get_mproxyvipcount(self):
        return self.get_mproxyvips().count()

    def get_mproxyvips(self):
        from spectrum_api.dna.models.mproxy import MproxyDomainVip
        mproxyvips = MproxyDomainVip.objects.filter(mproxy_app=self)
        return mproxyvips

    def is_deletable(self):
        mproxyedges = self.get_mproxyedges()
        mproxyvips = self.get_mproxyvips()
        if mproxyedges.exists():
            return False
        elif mproxyvips.exists():
            return False
        else:
            return True

    def update_mproxy_config_status(self, request):
        """
        In order to lock unfinished config before publishing, we need to keep mproxy config_state info up to date.
        """
        # valid_state = self.is_valid_config()
        # if valid_state != self.config_state:
        #    self.config_state = valid_state
        self.save(request=request)

    def save(self, *args, **kwargs):
        request = kwargs.get('request', None)
        if not self.pk:  # insert
            mproxyapps = MproxyApp.objects.filter(mproxy_app_name=self.mproxy_app_name)
            if mproxyapps.exists():
                raise Exception("mproxy app name '%s' is duplicated." % (self.mproxy_app_name))

        contract_no = self.contract.contract_no  # kwargs.pop('contract', None)
        self.latest_updater = request.user.username
        if self.pk:
            valid_state = self.is_valid_config()
            if valid_state != self.config_state:
                self.config_state = valid_state
        super(MproxyApp, self).save(*args, **kwargs)


        if contract_no == None:
            contract_no = request.POST.get('contract', None)

        if contract_no:
            statmasters = StatMaster.objects.filter(material_no=settings.DNA_MATERIAL,
                keyword=self.mproxy_app_name, display_name=self.mproxy_app_name)
            if statmasters.exists():
                stat_master = statmasters[0]
                pass
            else:
                stat_master = StatMaster(material_no=settings.DNA_MATERIAL,
                    keyword=self.mproxy_app_name, display_name=self.mproxy_app_name)
            stat_master.customer = self.customer  # PRISMUI-1169

            today = datetime.today()
            yesterday = today - timedelta(days=1)
            customer_items = CustomerItem.objects.filter(Q(material_no=settings.DNA_MATERIAL),
                Q(status_code__isnull=True) | Q(status_code=''),
                Q(contract__contract_terminate__gte=yesterday,
                contract__contract_end__gte=yesterday) | Q(contract__contract_terminate__isnull=True,
                contract__contract_end__gte=yesterday))

            if contract_no:
                customer_items = customer_items.filter(contract__contract_no=contract_no)
            else:
                customer_items = customer_items.filter(contract__account=self.customer.account,
                    contract__tz_offset=self.customer.tz_offset)
            if customer_items.count() == 1:
                stat_master.item = customer_items[0]
                # now mark complete if not complete...
                orders = CustomerSfaOrder.objects.filter(item=stat_master.item, status=2)
                for order in orders:
                    conn = get_connection()
                    # make call to SAP to mark complete...
                    try:
                        check_updated = update_sap_cs_stats(request, order.pk, 9, connection=conn)
                        if check_updated:
                            order.status = 9
                            order.save(request=request)
                    except:
                        order.status = -1
                        order.save(request=request)
            elif customer_items.count() > 1:
                if statmasters.exists():  # if update, maintain previous item_id
                    pass
                else:
                    stat_master.item = None
                """ IF ITEM COUNT > 1, SET ITEM_ID AS NULL """

                error_title = 'Mproxyapp is created but item_id is set to NULL for stat_master'
                error_msg = 'HTTP HOST: {host}\nSERVER NAME: {server}\n\nMproxyapp is created but item_id is set to NULL for stat_master\n\nMproxy: {appid}\nApp Name: {appname}'.format(host=request.get_host(), server=request.META['SERVER_NAME'], appid=self.pk, appname=self.mproxy_app_name)
                log_error(request, error_msg, None, None, error_title)
            else:  # customer item does not exist
                """ IF ITEM COUNT == 0 DO NOT ALLOW USER TO CREATE ZONE """
                pass

            try:
                stat_master.save(request=kwargs.get('request', None))
                # if self.stat.all().count() ==0:
                #    self.stat.add(stat_master)
                # from spectrum_api.dna.models.domain import MproxyStatMaster
                mproxystatmasters = MproxyStatMaster.objects.filter(mproxyapp=self)
                if mproxystatmasters.exists():
                    pass
                else:
                    mproxystatmaster = MproxyStatMaster(mproxyapp=self, statmaster=stat_master)
                    mproxystatmaster.save(request=kwargs.get('request', None))
            except Exception, e:
                error_title = 'Mproxyapp is created but stat_master is not generated correctly'
                error_msg = 'HTTP HOST: {host}\nSERVER NAME: {server}\n\nMproxyapp is created but stat_master is not generated correctly\n\nAppname: {appid}\nApp Name: {appname}\n\nTrace Back:{trace}'.format(host=request.get_host(), server=request.META['SERVER_NAME'], appid=self.pk, appname=self.mproxy_app_name, trace=traceback.format_exc(e))
                log_error(request, error_msg, e, None, error_title)

    class Meta:
        app_label = 'dnaapp'
        db_table = 'mproxy_app'
        verbose_name = 'Mproxy App'
        ordering = ['-date_modified']

    class SpectrumMeta:
        allow_delete = True

class MproxyStatMaster(Model):
    mproxystatmaster_id = models.AutoField(primary_key=True, db_column='id')
    mproxyapp = models.ForeignKey(MproxyApp)
    mproxyport_id = models.PositiveIntegerField()
    statmaster = models.ForeignKey(StatMaster)

    def __unicode__(self):
        return '%s %s' % (self.mproxyapp, self.mproxyport_id)

    class Meta:
        app_label = 'dna'
        db_table = 'mproxy_app_stat_master'

    def clean(self):
        pass

class DomainAlias(HistoryModel):
    domain_alias_id = models.AutoField(primary_key=True)
    name = models.CharField(
        max_length=255,
        help_text=H_DOMAIN_ALIAS_NAME,
        unique=True,
        verbose_name="Alias Name",
        validators=[RegexValidator(gslb_domain_rex)]
    )
    domain = models.ForeignKey(Domain,
        db_column='domain_id',
        verbose_name="Original Domain Name")
    customer = models.ForeignKey(CustomerDisplay,
                                blank=True,
                                null=True)
    description = models.TextField(
        'Description',
        max_length=1024,
        validators=[MaxLengthValidator(1024)],
        help_text=H_DOMAIN_DESC,
        blank=True)
    date_created = models.DateTimeField(
        'Date Created',
        auto_now_add=True
    )
    date_modified = models.DateTimeField(
        'Date Modified',
        auto_now=True
    )
    latest_updater = models.CharField(max_length=100)

    def clean(self):
        if self.name.count('*') > 1:
            raise ValidationError({'__all__':"Invalid domain name %s. * cannot be more than once." % (self.name)})

    def __unicode__(self):
        return '%s' % (self.name)

    def is_valid_config(self):
        return self.domain.is_valid_config()

    class Meta:
        app_label = 'dna'
        db_table = 'gslb_domain_alias'

    class SpectrumMeta:
        parent = 'domain'
        allow_delete = True

    def save(self, *args, **kwargs):
        request = kwargs.get("request")
        self.latest_updater = request.enduser.username
        super(DomainAlias, self).save(*args, **kwargs)

class DomainAll(HistoryModel):
    domain = models.PositiveIntegerField(Domain, db_column='domain_id')
    name = models.CharField(primary_key=True,
        max_length=255)

    domain_type = models.SmallIntegerField(choices=DOMAIN_TYPE)
    description = models.TextField(
        'Description',
        max_length=1024,
        validators=[MaxLengthValidator(1024)],
        help_text=H_DOMAIN_DESC,
        blank=True)
    vip_count = models.IntegerField(db_column='vip_count')
    edge_count = models.IntegerField(db_column='edge_count')
    customer = models.ForeignKey(CustomerDisplay,
        db_column='customer_id',
        blank=True,
        null=True)
    enable_gslb = models.SmallIntegerField(
        choices=SELECT_TYPES,
        blank=True,
        null=True,
        help_text=H_ENABLE_GSLB
    )
    load_balancing_type = models.SmallIntegerField(
        choices=LB_TYPES,
        blank=True,
        null=True,
        help_text=H_LB_TYPE
    )
    answer_count = models.PositiveSmallIntegerField(
        blank=True,
        null=True,
        validators=[MinValueValidator(1), MaxValueValidator(30)],
        help_text=H_ANSWER_COUNT
    )
    answer_ttl = models.PositiveIntegerField(
        blank=True,
        null=True,
        validators=[MaxValueValidator(4294967295)],
        help_text=H_ANSWER_TTL
    )
    probe = models.ForeignKey(
        BaseProbeConfig,
        null=True,
        blank=True,
        help_text=H_PROBE_METRIC,
        on_delete=models. DO_NOTHING
    )
    date_created = models.DateTimeField(
        'Date Created',
        auto_now_add=True
    )
    date_modified = models.DateTimeField(
        'Date Modified',
        auto_now=True)
    latest_updater = models.CharField(max_length=100)

    def __unicode__(self):
        return '%s' % (self.name)

    class Meta:
        app_label = 'dna'
        db_table = 'gslb_domain_all'
        verbose_name = 'GSLB domain All'
        managed = False

    class SpectrumMeta:
        allow_delete = True

class DomainStaticRuleCondition(HistoryModel):
    domain_staticrule_condition_id = models.AutoField(primary_key=True)
    domain = models.ForeignKey(Domain, editable=True)
    sequence = models.PositiveIntegerField(help_text=H_CONDITION_SEQUENCE)
    condition = models.TextField(help_text=H_STATIC_RULE)
    policy_name = models.CharField(max_length=100)
    is_enabled = models.BooleanField(default=True)
    invert = models.NullBooleanField(help_text=H_GSLB_STATICRULE_CONDITION_INVERT)

    def __unicode__(self):
        return u'%s' % (self.condition)

    def get_full_name(self):
        return u'%s >> %s' % (str(self.domain), str(self.condition))

    class Meta:
        app_label = 'dna'
        unique_together = [('domain', 'sequence'), ]
        db_table = 'gslb_domain_staticrule_condition'
        verbose_name = 'Static Rule Condition'
        ordering = ['sequence', ]

    class SpectrumMeta:
        parent = 'domain'
        allow_delete = True

    def get_previous_obj(self):
        if self.pk:
            previous_self = DomainStaticRuleCondition.objects.get(domain_staticrule_condition_id=self.pk)
            if previous_self:
                try:
                    previous_self.sequence = self.previous_sequence
                except:
                    pass
                return previous_self
            else:
                return None
        else:
            return None

    def save(self, *args, **kwargs):
        request = kwargs.pop("request")

        policy_name = self.policy_name
        if policy_name is not None and policy_name != '':
            self.policy_name = policy_name.replace(' ', '^:^')

        previous_self = self.get_previous_obj()

        super(DomainStaticRuleCondition, self).save(request=request, previous_self=previous_self)
        if self.domain.is_clb_customer_mode():
            self.normalize_condition(request)

    #def delete(self):
    #    normalized_conditions = DomainStaticRuleNomalizedCondition.objects.filter(domain_staticrule_condition=self.pk)
    #    if normalized_conditions.exists():
    #        normalized_conditions.delete()
    #    super(DomainStaticRuleCondition, self).delete()

    def clean(self):
        if not is_invertible_condition(self.condition):
            """
            if staticrule has 'always' or 'request.portion' rule flags,
            invert field will be set null.
            """
            self.invert = None

        if self.domain.is_clb_customer_mode() and settings.PROJECT_NAME == 'prism_fe':
            raise ValidationError('not allowed modify at prism when domain %s is CLB and in customer mode.' % (self.domain))
        if self.condition:
            is_valid_static_condition, err_msg = validate_static_rule(self.condition, True)
            if is_valid_static_condition is False:
                raise ValidationError({'condition':"%s" % (err_msg)})

    def get_enabled_status(self):
        if self.is_enabled == 0:
            return 'enabled'
        else:
            return 'disabled'

    def get_actions(self):
        domain_actions = DomainStaticRuleAction.objects.filter(condition=self)
        action_list = []
        for domain_action in domain_actions:
            action_list.append(domain_action.get_denormalized_action_for_customer())
            # action_list.append(domain_action.get_attrib())
        return '\r\n'.join(action_list)

    def get_attrib(self):
        try:
            policy_name = self.policy_name
            if policy_name is not None or policy_name != '':
                policy_name = policy_name.replace('^:^', ' ')

            item = {'policy_name':policy_name,
                    'sequence': str(self.sequence),
                    'enabled': self.get_enabled_status(),
                    'condition':self.get_denormalized_condition_for_customer(),
                    'invert' : self.invert,
                    'action': self.get_actions()}
        except Exception, e:
            item = None
        return item

    def normalize_condition(self, request=None):
        geo_datas = ['client.continent', 'client.country', 'client.region', 'client.isp', 'client.asn']

        normalized_conditions = DomainStaticRuleNomalizedCondition.objects.filter(domain_staticrule_condition=self)
        if normalized_conditions.exists():
            normalized_conditions.delete()

        normalized_condition = DomainStaticRuleNomalizedCondition(domain_staticrule_condition=self)

        normalized_condition.invert = self.invert

        clientip = re_parse_clientip.match(self.condition)
        geo_sets = re_parse_geo.match(self.condition)
        percent = re_parse_percent.match(self.condition)
        is_always = re_parse_always.match(self.condition)

        if is_always is not None:
            normalized_condition.condition_type = 0
        elif clientip is not None:
            matched_set = clientip.groupdict()
            condition_list = matched_set["client_ip"].split(",")
            if len(condition_list) > 1:
                for ipblock in condition_list:
                    normalized_condition = DomainStaticRuleNomalizedCondition(domain_staticrule_condition=self)
                    normalized_condition.condition_type = 1
                    normalized_condition.iprange = ipblock
                    normalized_condition.save(request=request)
            else:
                normalized_condition.condition_type = 1
                normalized_condition.iprange = matched_set["client_ip"]
        elif geo_sets is not None:
            normalized_condition.condition_type = 2
        elif percent is not None:
            normalized_condition.condition_type = 3
            matched_set = percent.groupdict()
            normalized_condition.percent = matched_set["percent"]
        else:
            raise Exception('%s condition rule can not be normailized.' % (self.condition))

        normalized_condition.save(request=request)

    def denormalize_conditions(self, request=None):
        normalized_conditions = DomainStaticRuleNomalizedCondition.objects.filter(domain_staticrule_condition=self)
        if normalized_conditions.exists():
            normalized_conditions.delete()

    def get_admin_conditions_for_customer(self):
        result_list = []
        result_list.append("Policy%s: Managed by admin user"%(self.display_policy_type()))
        result_list.append(self.condition)
        result_list.append("Action: Managed by admin user")
        actions = DomainStaticRuleAction.objects.filter(condition=self)
        for action in actions:
            result_list.append(action.action)
        return "\r\n".join(result_list)


    def get_denormalized_condition(self):
        result = []
        normalized_conditions = DomainStaticRuleNomalizedCondition.objects.filter(domain_staticrule_condition=self)
        for normalized_condition in normalized_conditions:
            if normalized_condition.condition_type == 0:
                result.append('always')
            elif normalized_condition.condition_type == 1:
                result.append('client.ip=%s' % (normalized_condition.iprange))
            elif normalized_condition.condition_type == 2:
                pass
            elif normalized_condition.condition_type == 3:
                result.append('request.portion=%s' % (str(normalized_condition.percent)))

        return "\n".join(result)

    def display_policy_type(self):
        is_invert_msg = _('Rule will be applied inversely')
        is_disabled_msg = _("Disabled")

        return_msg = ""
        if self.invert == True:
            return_msg = " (%s)"%(is_invert_msg)

        if self.is_enabled == False:
            return_msg = " [%s]%s"%(is_disabled_msg, return_msg)

        return return_msg

    def get_denormalized_condition_for_customer(self):
        result = []
        normalized_conditions = DomainStaticRuleNomalizedCondition.objects.filter(domain_staticrule_condition=self)
        for normalized_condition in normalized_conditions:
            actions = DomainStaticRuleAction.objects.filter(condition=self)
            if normalized_condition.condition_type == 0:
                # condition = always
                if actions.exists():
                    if actions[0].action.lower().strip() == 'ignore':
                        result.append('ETC policy: Deny')
                    else:
                        result.append('ETC Policy: Fixed Record')
            elif normalized_condition.condition_type == 1:
                iprange = 'IP Range = %s' % (normalized_condition.iprange)
                result.append('Condition%s: %s' % (self.display_policy_type(), iprange))
            elif normalized_condition.condition_type == 2:
                buf_geo = []
                get_geo_datas = re_parse_geo.findall(self.condition)
                for geo_set in get_geo_datas:
                    geo_key = geo_set[0].lower()
                    if geo_key == 'continent':
                        buf_geo.append('    Geo continent = %s' % (geo_set[1]))
                    elif geo_key == 'country':
                        buf_geo.append('    Geo country = %s' % (geo_set[1]))
                    elif geo_key == 'region':
                        buf_geo.append('    Geo region = %s' % (geo_set[1]))
                    elif geo_key == 'isp':
                        buf_geo.append('    Geo isp = %s' % (geo_set[1]))
                    elif geo_key == 'asn':
                        buf_geo.append('    Geo asn = %s' % (geo_set[1]))
                result.append('Condition%s: \r\n%s'%(self.display_policy_type(), "\r\n".join(buf_geo)))
            elif normalized_condition.condition_type == 3:
                result.append('Condition%s: Percent = %s' % (self.display_policy_type(), str(normalized_condition.percent)))

            for action in actions:
                result.append('Action: %s' % (action.get_denormalized_action_for_customer()))
            result.append('')

        return "\r\n".join(result)

class DomainStaticRuleNomalizedCondition(Model):
    domain_staticrule_condition = models.ForeignKey(DomainStaticRuleCondition, db_column='condition_id')
    condition_type = models.PositiveSmallIntegerField(choices=STATIC_RULE_CONDITION_TYPE)
    command = models.CharField(max_length=100, null=True)
    iprange = models.CharField(max_length=50, null=True)
    country = models.CharField(max_length=2048, null=True)
    continent = models.CharField(max_length=256, null=True)
    region = models.CharField(max_length=256, null=True)
    isp = models.CharField(max_length=256, null=True)
    asn = models.CharField(max_length=256, null=True)
    percent = models.PositiveSmallIntegerField(null=True,)
    invert = models.NullBooleanField(help_text=H_GSLB_STATICRULE_CONDITION_INVERT)
    latest_updater = models.CharField(max_length=100)
    date_created = models.DateTimeField(
        'Date Created',
        auto_now_add=True
    )
    date_updated = models.DateTimeField(
        'Date Updated',
        auto_now=True
    )

    def __unicode__(self):
        return u'%s_%s' % (self.domain_staticrule_condition, str(self.pk))

    class Meta:
        app_label = 'dna'
        db_table = 'gslb_domain_staticrule_normalized_condition'
        verbose_name = 'Static Rule Normalized Condition'
        # ordering = ['sequence', ]

    class SpectrumMeta:
        allow_delete = True

    @property
    def domainstaticrulenomalizedaction(self):
        try:
            normailized_rules = []
            staticruleactions = self.domain_staticrule_condition.domainstaticruleaction_set.all()
            for action in staticruleactions:
                normailized_rules.append(action.domainstaticrulenormalizedaction_set.all()[0])
            return normailized_rules
        except:
            return []

class DomainStaticRuleAction(HistoryModel):
    domain_staticrule_action_id = models.AutoField(primary_key=True)
    condition = models.ForeignKey(DomainStaticRuleCondition)
    action = models.TextField()
    sequence = models.PositiveIntegerField(help_text=H_ACTION_SEQUENCE)

    def __unicode__(self):
        return u'%s' % (self.action)

    def get_full_name(self):
        return u'%s >> %s >> %s' % (str(self.condition.domain),
                                    str(self.condition), str(self.action))

    class Meta:
        app_label = 'dna'
        db_table = 'gslb_domain_staticrule_action'
        verbose_name = 'Static Rule Action'
        ordering = ['sequence', ]

    class SpectrumMeta:
        parent = 'condition'
        allow_delete = True

    def clean(self):
        if self.pk:
            if self.condition.domain.is_clb_customer_mode() and settings.PROJECT_NAME == 'prism_fe':
                raise ValidationError('not allowed modify at prism when domain %s is CLB and in customer mode.' % (self.condition.domain))
        if self.action:
            is_valid_static_action, err_msg = validate_static_rule(self.action, False)
            if is_valid_static_action is False:
                raise ValidationError({'action':"%s" % (err_msg)})

    def get_previous_obj(self):
        if self.pk:
            previous_self = DomainStaticRuleAction.objects.get(domain_staticrule_action_id=self.pk)
            if previous_self:
                try:
                    if hasattr(self, 'previous_sequence'):
                        previous_self.sequence = self.previous_sequence
                except:
                    pass
                return previous_self
            else:
                return None
        else:
            return None

    def save(self, *args, **kwargs):
        request = kwargs.get("request")
        try:
            previous_self = self.get_previous_obj()

            super(DomainStaticRuleAction, self).save(request=request, previous_self=previous_self)
            if self.condition.domain.is_clb_customer_mode():
                self.normalize_action(request)
        except Exception, e:
            log_error(request, str(e), e)

    def get_attrib(self):
        try:
            item = {'sequence': str(self.sequence),
                    'action':self.get_denormalized_action_for_customer()}
        except:
            item = None
        return item

    def normalize_action(self, request=None):
        normalized_actions = DomainStaticRuleNormalizedAction.objects.filter(domain_staticrule_action=self)
        if normalized_actions.exists():
            normalized_actions.delete()

        action_list = self.action.split('\n')
        try:
            for action in action_list:
                actions = action.split('=')
                action_key = actions[0].strip().lower()

                if action_key == 'system.vip':  # action_type 1
                    action_value = actions[1].strip().lower()
                    ip_list = action_value.split(',')
                    for ip in ip_list:
                        vips = get_vips_by_ipaddr(ip)
                        if len(vips) == 0:
                            raise Exception("'%s' rule action can not be normailized. ip '%s' is not valid." % (self.action, ip))
                        else:
                            customervip = vips[0]
                            if self.condition.domain.clb_dns_zone:
                                if customervip.host.system.pop.get_related_clb_customer() != self.condition.domain.clb_dns_zone.customer:
                                    raise Exception("'%s' rule action can not be normailized. ip '%s' is registered to other customer." % (self.action, ip))

                        normalized_actions = DomainStaticRuleNormalizedAction.objects.filter(domain_staticrule_action=self, action_type=1, vip=vips[0])
                        if normalized_actions.exists():
                            pass
                        else:
                            normalized_action = DomainStaticRuleNormalizedAction(domain_staticrule_action=self)
                            normalized_action.action_type = 1
                            normalized_action.vip = vips[0]
                            normalized_action.save(request=request)
                else:
                    # normalized_actions = DomainStaticRuleNormalizedAction.objects.filter(domain_staticrule_action=self,action_type=0,vip=vips[0])
                    normalized_action = DomainStaticRuleNormalizedAction(domain_staticrule_action=self)
                    if action_key == 'ignore':
                        normalized_action.action_type = 0  # 0:deny, 1:vip, 2:cname, 3:ip_a
                    elif action_key == 'response.answer':
                        action_value = actions[1].strip().lower()
                        value_list = action_value.split(',')
                        if len(value_list) > 3:
                            raise Exception('Normalizing not supported for static rule %s.' % (self.action))
                        if action_value.startswith('cname'):
                            normalized_action.action_type = 2
                            normalized_action.cname = value_list[2].strip()
                            normalized_action.cname_ttl = value_list[1].strip()
                        elif action_value.startswith('a'):
                            normalized_action.action_type = 3
                            # vips = get_vips_by_ipaddr(value_list[2].strip())
                            normalized_action.ip_a = value_list[2].strip()
                            # if len(vips) ==0:
                            #    raise Exception('%s rule action can not be normailized. ip %s is not valid.' % (self.action, value_list[2]))
                            # normalized_action.vip = vips[0]
                            normalized_action.ip_a_ttl = value_list[1].strip()
                    else:
                        raise Exception('%s rule action can not be normailized.' % (self.action))
                    normalized_action.save(request=request)
        except Exception, e:
            normalized_actions = DomainStaticRuleNormalizedAction.objects.filter(domain_staticrule_action=self)
            if normalized_actions.exists():
                normalized_actions.delete()
            raise e

    def get_denormalized_action(self):
        result = []
        result_ips = []
        normalized_actions = DomainStaticRuleNormalizedAction.objects.filter(domain_staticrule_action=self)
        for normalized_action in normalized_actions:
            if normalized_action.action_type == 0:
                result.append('ignore')
            elif normalized_action.action_type == 1:
                result_ips.append(str(normalized_action.vip))
            elif normalized_action.action_type == 2:
                # if len(normalized_action.cname) > 0:
                result.append('response.answer=CNAME,%s,%s' % (str(normalized_action.cname_ttl), normalized_action.cname))
                # else:
                #    result.append('response.answer=A,%s,%s' % (str(normalized_action.ip_a_ttl),str(normalized_action.vip)))
            elif normalized_action.action_type == 3:
                result.append('response.answer=A,%s,%s' % (str(normalized_action.ip_a_ttl), str(normalized_action.ip_a)))

        if len(result_ips) > 0:
            result.append('system.vip=%s' % (','.join(result_ips)))

        return '\n'.join(result)

    def get_denormalized_action_for_customer(self):
        result = []
        result_ips = []
        normalized_actions = DomainStaticRuleNormalizedAction.objects.filter(domain_staticrule_action=self)

        for normalized_action in normalized_actions:
            if normalized_action.action_type == 0:
                result.append('Set Deny')
            elif normalized_action.action_type == 1:
                result_ips.append(str(normalized_action.vip))
            elif normalized_action.action_type == 2:
                # if len(normalized_action.cname) > 0:
                result.append('Set CNAME: %s,%s' % (str(normalized_action.cname_ttl), normalized_action.cname))
                # else:
                #    result.append('response.answer=A,%s,%s' % (str(normalized_action.ip_a_ttl),str(normalized_action.vip)))
            elif normalized_action.action_type == 3:
                result.append('Set A: %s,%s' % (str(normalized_action.ip_a_ttl), str(normalized_action.ip_a)))

        if len(result_ips) > 0:
            result.append('Set IP: %s' % (' '.join(result_ips)))

        return '\r\n'.join(result)

class DomainStaticRuleNormalizedAction(Model):
    domain_staticrule_action = models.ForeignKey(DomainStaticRuleAction, db_column='action_id')
    action_type = models.PositiveSmallIntegerField(choices=STATIC_RULE_ACTION_TYPE)
    command = models.CharField(max_length=100)
    vip = models.ForeignKey(Vip, db_column="vip_id")
    ip_a = models.CharField(max_length=15)
    ip_a_ttl = models.PositiveIntegerField()
    cname = models.CharField(max_length=256)
    cname_ttl = models.PositiveIntegerField()
    latest_updater = models.CharField(max_length=100)
    date_created = models.DateTimeField(
        'Date Created',
        auto_now_add=True
    )
    date_updated = models.DateTimeField(
        'Date Updated',
        auto_now=True
    )

    def __unicode__(self):
        return u'%s_%s' % (self.domain_staticrule_action, str(self.pk))

    class Meta:
        app_label = 'dna'
        db_table = 'gslb_domain_staticrule_normalized_action'
        verbose_name = 'Static Rule Normalized Action'

    class SpectrumMeta:
        allow_delete = True

    def get_domain(self):
        try:
            rule_action = DomainStaticRuleAction.objects.get(pk=int(self.domain_staticrule_action.pk))
            condition = DomainStaticRuleCondition.objects.get(pk=int(rule_action.condition.pk))
            return condition.domain
        except:
            return None

    def get_staticrule_action_relation_display(self):
        try:
            policy_name = self.domain_staticrule_action.condition.policy_name
            if policy_name is not None or policy_name != '':
                policy_name = policy_name.replace('^:^', ' ')

            rel = {
                "domain_name" : self.domain_staticrule_action.condition.domain.name,
                "policy_name" : policy_name
            }
            return "%(domain_name)s -> Policy name : %(policy_name)s"%(rel)
        except:
            return None


class DomainEdge(HistoryModel):
    domain_edge_id = models.AutoField(primary_key=True)
    domain = models.ForeignKey(Domain)
    edge = models.ForeignKey(Edge)
    probe = models.ForeignKey(
        BaseProbeConfig,
        null=True,
        blank=True
    )
    probe_increment = models.FloatField(
        null=True,
        blank=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_PROBE_INC)
    probe_scaling_factor = models.FloatField(
        null=True,
        blank=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_PROBE_SCALING)
    weight = models.FloatField(default=1.0, null=True, blank=True,
        help_text=H_WEIGHT)
    priority = models.IntegerField(
        null=True,
        blank=True,
        validators=[MinValueValidator(1), MaxValueValidator(10)],
        help_text=H_PRIORITY
    )

    class Meta:
        app_label = 'dna'
        db_table = 'gslb_domain_edge'
        unique_together = [('domain', 'edge'), ]

    class SpectrumMeta:
        parent = 'domain'
        allow_delete = True

    def __unicode__(self):
        return u'%s -> %s' % (self.domain, self.edge)

    def is_mproxy_related(self):
        return self.get_mproxy_services().exists() and self.domain.domain_type == DNA_EDGE_DOMAIN

    def get_mproxy_services(self):
        from spectrum_api.dna.models.mproxy import MproxyDomainEdge
        return MproxyDomainEdge.objects.filter(domain_edge=self.pk)

    def getVipCount(self):
        vips = Vip.objects.filter(edge=self.edge)
        if vips:
            return vips.count()
        else:
            return 0

    def getvips(self):
        vips = Vip.objects.filter(edge=self.edge).distinct()
        return vips

    def getpopnames(self):
        pops = []
        vips = Vip.objects.filter(edge=self.edge)
        for vip in vips:
            popname = vip.getpopname()
            if popname not in pops:
                pops.append(popname)
        return pops

    def clean(self):
        # validate this edge is empty or not
        try:
            vips = Vip.objects.filter(edge=self.edge)
        except:
            vips = None

        if not vips:
            raise ValidationError({'edge': "This edge is empty."})
        # validate vips on this edge has domain's probes.

        """
        if self.domain.is_clb_customer_mode() and settings.PROJECT_NAME == 'prism_fe':
            raise ValidationError('not allowed modify at prism when domain %s is CLB and in customer mode.' % (self.domain))

        # since before saved,we need to pass probe input to validate.
        is_valid, errmsg = self.edge.has_mandatory_domain_probeconfigs(None, self.domain, self.probe)
        if not is_valid:
            raise ValidationError({'__all__': errmsg})
        """
        # if self.domain.probe:
        #    if not self.probe:
        #        for vip in vips:
        #            if not self.domain.probe.pk in [x['probe_id'] for x in vip.vipprobeconfigs_set.values()]:
        #                raise ValidationError({'__all__':
        #                    "%s vip doesn't have %s probe."
        #                    % (vip, self.domain.probe)})

        # if self.probe:
        #    for vip in vips:
        #        if not self.probe.pk in [x['probe_id'] for x in vip.vipprobeconfigs_set.values()]:
        #            raise ValidationError({'__all__':
        #                "%s vip doesn't have %s probe." %
        #                (vip, self.probe)})
        # related pop have rttserver exist or not
        for vip in vips:
            if not vip.host.system.pop.rttserver:
                raise ValidationError({'__all__':
                    "%s pop doesn't have rttserver" % vip.host.system.pop})

        if self.probe_scaling_factor is not None or self.probe_increment is not None:
            if self.probe is None and self.domain.probe is None:
                raise ValidationError({'probe': _("\"Probe increment\" or \"Probe scaling factor\" are required Probe configuration")})

    def save(self, *args, **kwargs):
        super(DomainEdge, self).save(*args, **kwargs)

class DomainBaseVip(HistoryModel):
    domain = models.ForeignKey(Domain)
    probe = models.ForeignKey(
        BaseProbeConfig,
        null=True,
        blank=True
    )
    probe_increment = models.FloatField(
        null=True,
        blank=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_PROBE_INC
    )
    probe_scaling_factor = models.FloatField(
        null=True,
        blank=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_PROBE_SCALING
    )
    weight = models.FloatField(
        default=1.0,
        null=True,
        blank=True,
        help_text=H_WEIGHT
    )
    priority = models.IntegerField(
        blank=True,
        null=True,
        validators=[MinValueValidator(1), MaxValueValidator(10)],
        help_text=H_PRIORITY
    )

    class Meta:
        abstract = True


class DomainVip(DomainBaseVip):
    domain_vip_id = models.AutoField(primary_key=True)
    vip = models.ForeignKey(Vip)

    def is_mproxy_related(self):
        return self.get_mproxy_services().exists() and self.domain.domain_type == DNA_EDGE_DOMAIN

    def get_mproxy_services(self):
        from spectrum_api.dna.models.mproxy import MproxyDomainVip
        return MproxyDomainVip.objects.filter(domain_vip=self.pk)

    def get_ip_status(self, vip):
        result = vip.get_status_enabled()
        try:
            from spectrum_api.configuration.models.node_mon import DomainVipStatus
            domainvips = DomainVipStatus.objects.filter(domain=self.domain, vip=vip)

            gslb_enabled = vip.enable_gslb
            if vip.host.system.pop.enable_gslb == 0:
                gslb_enabled = 0
            if gslb_enabled == 0:
                if domainvips.exists():
                    if domainvips[0].probe_message_val is not None and domainvips[0].probe_message_val < 0:
                        result = 'failure-off'
                else:
                    result = 'disabled'
            else:
                # if vip.enable_gslb in [1, None]:
                if domainvips.exists():
                    if domainvips[0].probe_message_val is not None and domainvips[0].probe_message_val < 0:
                        result = 'failure'
                    else:
                        # if probe_message_val is none
                        try:
                            if domainvips[0].probe:
                                result = 'failure'
                        except:
                            result = 'enabled'
                else:
                    result = 'failure'

        except:
            return result
        return result

    # def save(self,request):
    #    super(DomainVip, self).save(request=request)

    def clean(self):
        try:
            self.vip
        except:
            raise ValidationError({'__all__': 'vip field is required'})

        """
        if self.domain.is_clb_customer_mode() and settings.PROJECT_NAME == 'prism_fe':
            raise ValidationError('not allowed modify at prism when domain %s is CLB and in customer mode.' % (self.domain))

        # validate vip have domain's probes.

        is_valid, errmsg = self.vip.has_mandatory_domainvip_probeconfig(self.domain, self.probe)
        if not is_valid:
            raise ValidationError({'__all__': errmsg})
        """

        # <<<<
        # if self.domain.probe:
        #    if not self.probe:
        #        if not self.domain.probe.pk in [x['probe_id'] for x in self.vip.vipprobeconfigs_set.values()]:
        #            raise ValidationError({'__all__':
        #                "%s vip must have %s probe."
        #                % (self.vip, self.domain.probe)})
        # if self.probe:
        #    if not self.probe.pk in [x['probe_id'] for x in self.vip.vipprobeconfigs_set.values()]:
        #        raise ValidationError({'__all__':
        #            "%s vip must have %s probe." %
        #            (self.vip, self.probe)})
        # related pop must have rttserver
        if not self.vip.host.system.pop.rttserver:
            raise ValidationError({'__all__':
                "%s pop must have rttserver" % self.vip.host.system.pop})

        if self.probe_scaling_factor is not None or self.probe_increment is not None:
            if self.probe is None and self.domain.probe is None:
                raise ValidationError({'probe': _("\"Probe increment\" or \"Probe scaling factor\" are required Probe configuration")})

    def __unicode__(self):
        return u'%s -> %s(%s)' % (self.domain, self.vip.name(), self.vip)

    class Meta:
        app_label = 'dna'
        db_table = 'gslb_domain_vip'
        verbose_name = 'System Vip'
        unique_together = [('domain', 'vip'), ]

    class SpectrumMeta:
        parent = 'domain'
        allow_delete = True

def is_invertible_condition(condition):
    """
    The function is check gslb_domain_staticrule_condition has invertible condition rule or not.

    allow invertible condition is start by follow static rule flags.
        - client.*

    follow condoition is not allowed.
        - always
        - request.portion
    """
    re_invertible_condition_rule = "^\s*client\.\w+\s*\="
    re_not_allow_invertible_condition_rule = "^\s*(always|request\.portion)\s*"

    re_invertible = re.compile(re_invertible_condition_rule, re.IGNORECASE | re.MULTILINE)
    re_not_invertible = re.compile(re_not_allow_invertible_condition_rule, re.IGNORECASE | re.MULTILINE)

    try:
        condition = condition.strip()
        if re_not_invertible.match(condition) is not None:
            return False
        elif re_invertible.match(condition):
            return True
        else:
            return False
    except (TypeError, AttributeError):
        return False

class BasePopDNSZoneRelation(InterimModel):
    pop = models.ForeignKey(Pop)
    zone = models.ForeignKey(DNSZone)

    class Meta:
        app_label = 'dna'
        db_table = 'base_pop_dns_zone_relation'
        verbose_name = "POP Related zone snapshot"
        unique_together = (('pop', 'zone',),)

    def __unicode__(self):
        return u'%s -> %s' % (self.pop, self.zone)


class DomainDynamicRelay(HistoryModel):
    dynamic_relay_id = models.AutoField(primary_key=True)
    domain = models.ForeignKey(Domain)
    pop = models.ForeignKey(Pop)
    obj_state = models.PositiveSmallIntegerField(default=1)

    class Meta:
        app_label = 'dna'
        db_table = 'gslb_domain_dynamic_relay'

    class SpectrumMeta:
        parent = 'domain'
        allow_delete = True

    def __unicode__(self):
        return u'%s -> %s' % (self.domain, self.pop)
