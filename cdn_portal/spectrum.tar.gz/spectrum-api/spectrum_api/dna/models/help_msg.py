#
# Copyright (c) 2011 CDNetworks Co., Ltd.
# All rights reserved.
#
# $Id: help_msg.py 11864 2014-01-02 02:15:00Z kookheon.kwon $
#

from django.utils.translation import ugettext as _

H_SHIELD_DOMAIN = _(''' What is the shield domain name that MProxy should
resolve with GSLB to get the shield IP(s)?''')

H_RELAY_DOMAIN = _(''' What is the relay domain name that MProxy should
resolve with GSLB to get the relay IP(s)?''')

H_ORIGIN_DOMAIN = _('''What is the origin domain name that MProxy should
resolve with GSLB to get the origin IP(s)?''')

H_EDGE_DOMAIN = _('''What is the edge domain name that MProxy should
resolve with GSLB to get the origin IP(s)?''')

H_MPROXY_APP = _('''The App Name must follow these rules:
  1) When creating a new DNA app, the App Name must be unique.
  2) The entire name can be no larger than 251 characters.
  3) Alpha numeric characters and limited special characters are allowed :
    3-1) Allowed Special Characteres are ("-", "_", ".")
    3-2) Letters are both upper case and lower case alphabets from the English language.
    3-3) Digits are 0 - 9
  ''')

H_PROTOCOL = _('''what protocol should be used?
'tcp' is the only valid value now.''')

H_TYPE = _('''What type of service is it?
For now, only 'tunnel' and 'http' are available.
'http' is for debug-port only.''')

H_PORT = _('''Which port should we provide service on?
* value range: 1 ~ 65535
''')

H_EPOL_ACCEPT_NUM = _('''How many connections can be accepted during each
epol loop
* Default: 1024''')

H_DS_RESET = _('''Should MProxy sends a TCP RST to the end-user
whenever MProxy detects an error?
<strong>* Default: false</strong>''')

H_ACCESS_LOG = _('''Summary Access Log Format (SAccess log).
Please refer to ops-manual for the default format
for tunnel service.

* value range: any string not longer than 1023 bytes
''')

H_CACCESS_LOG = _('''Continuous Access Log Format (CAccess log)
Please refer to ops-manual for details.''')

H_ORIGIN_FB = _(
'''Do we expect the first byte from origin?

Default: off (i.e. the first byte is from the end-user)
'''
)

H_LOG_LEVEL = _(
'''Override the process-wise debug log level for
any request on this domain.

Default: follow the process-wise log level

* value range: 0 ~ 255
'''
)

H_READ_S = _('''
read_s timeout is not useful for tunnel service.
In tunnel service, It will be ignored in most cases. Please use <ds_idle_s>
and <us_idle_s> instead.
* Default: 10s
''')

H_WRITE_S = _('''How long should MProxy wait for the write socket
buffer to be available.
* Default: 15s''')

H_CONNECT_S = _(''' How long should MProxy wait when establishing
the upstream connection.
* Default: 5s''')

H_DS_IDLE_S = _('''After downstream has idled for X seconds,
MProxy will close the transaction.
* Defaults: 300s (5 mins)''')

H_US_IDLE_S = _('''After upstream has idled for X seconds,
MProxy will close the transaction.
* Defaults: 300s (5 mins)''')

H_TIMEOUT_FB = _(
'''How long should mproxy wait for the first byte.
By default, mproxy expects the first byte from
the end-user unless the origin_fb is set.

The fb_s must be greater than both ds_idle_s
and us_idle_s.

Only works for mproxy 1.1.9 or later.

* DB value range: 0 ~ 4294967295
* Default: 15 seconds
'''
)
H_ORIGIN_PORT = _(
'''Support different edge/vip service port from origin server port if this tag exists.

* Default: blank (no existence of the tag)
'''
)
H_DYNAMIC_RELAY = _(
'''Use dynamic relay if this tag exists.

* Default: FALSE (no existence of the tag)
'''
)
H_CIP_PASSTHROUGH = _(
'''Client ip will be included in tcp header, if this tag exists.

* Default: FALSE (no existence of the tag)
'''
)
H_ACL_TYPE = _(
'''white:white list, black: black list.

* Default: null
'''
)

H_ACL_IPADDR = _(
'''ipaddr='127.0.0.1'
   ipaddr='192.168.0.0/16'
   ipaddr='10.0.0.1-10.0.1.1'
'''
)

H_GZIP_REQ = _(
'''Compress request message if this tag exists.

* Default: FALSE (no existence of the tag)
'''
)

H_GZIP_REP = _(
'''Compress response message if this tag exists.

* Default: FALSE (no existence of the tag)
'''
)

H_GZIP_WBITS = _(
'''The base two logarithm of the window size.
(the size of the history buffer)

* Default: 15
* DB value range: 8 ~ 15
'''
)

H_GZIP_MEMLEVEL = _(
'''Specify how much memory should be allocated
for the internal compression state.

memLevel=1 : uses minimum memory but is slow
and reduces compression ratio

memLevel=9 : uses maximum memory
for optimal speed

* Default: 8
* DB value range: 1 ~ 9
'''
)

H_GZIP_COMPLEVEL = _(
'''Specify compression levels.

compression-level=0 : no compression
compression-level=1 : best speed
compression-level=9 : best compression

* Default: 6
* DB value range: 0 ~ 9
'''
)

H_GZIP_MAXBUF = _(
'''Maximum buffer size.

* Default: 4096
* DB value range: 0 ~ 4294967295

'''
)

H_PROBE_INC = _('''Whenever a VIP is selected, it's load is incremented to
prevent overloading. The value by which the load is
incremented is specified here.
* Acceptable range: 0 - 4294967295.0.''')

H_PROBE_SCALING = _('''A factor to scale the probe score.
Default: 1.0 Acceptable values: 0 - 4294967295.0''')

H_WEIGHT = _('''A weight to divide the entire vip score.
Default: 1.0 Acceptable range: Any numbers.
Negative value makes this vip excluded from the score based vip selection.
However, even if a vip has a negative weight,
it will be included in the random selection process
which can be triggered by $fallback. The lower the weight,
the less likely this VIP is going to get picked,
all other things being equal.''')

H_ENABLE_GSLB = _(
'''This flag determines if DNS queries for the domain will be resolved or forwarded.
''')

H_ENABLE_VCPDNS = _(
''' VCP DNS query for this domain will be accepted only if this flag is true.

    VCP DNS is a custom DNS protocol based on UDP.
    Some applications, such as MProxy, can only work with VCP DNS.
    Hence, any domains of these applications must have this flag on.
''')

H_ENABLE_STAT = _(
''' If this flag is true, 5-min interval stat will be supported for this domain through the debug port.

    This flag is designed only for temporary and selective use. Since this affects DNS down time in
    configuration reload to be a little longer, this should be used carefully. Using this for a few domains
    are fine but do not use it for hundreds or thousands of domains.
''')

H_LOG_REQUEST = _(
''' If this flag is true, per-request log for this domain will be written to the log files(gslb-request_*).

    This flag is designed only for temporary and selective use. Since this affects DNS performance,
    this should be used carefully.
''')

H_STICKY = _(
''' If this flag is true, GSLB will select IP addresses only from the best pop.

    Then, what is the best pop?

    First, let's define the best vips as:
    &nbsp; &nbsp; available vips of lowest total score
    &nbsp; &nbsp; or any vips if there are no available vips.

    Now, here is our rule priority to be the best pop:
    &nbsp; &nbsp; Among all pops having one or more best vips,
    &nbsp; &nbsp; 1)  a pop which has the only best vip.
    &nbsp; &nbsp; 2)  the only pop which is up.
    &nbsp; &nbsp; 3a) a pop which has the lowest distance + pop score.
    &nbsp; &nbsp; 3b) if there are multiple pops satisfying the rule 2a),
    &nbsp; &nbsp; &nbsp; one of the lowest distance score has the priority.
    &nbsp; &nbsp; 4)  a pop which is down but has the lowest distance score.
''')

H_COUNT = _(
''' This specifies lower threasholds for falling back to random selection on resolving the domain.

    Default is 0.
    Acceptable range is 0 - 4294967295.

    If the percentage of available VIPs is less than $count threshold, then the gslb makes a random selection from ALL VIPs.
    Note that, no matter the threshold values are, the gslb will do fallback if there are no available VIPs.
''')

H_PERCENT = _(
''' This specifies lower threasholds for falling back to random selection on resolving the domain.

    percent: Default is 0.
    Acceptable range is 0 - 100.

    If the percentage of available VIPs is less than $percent then the gslb makes a random selection from ALL VIPs.
    Note that, no matter the threshold values are, the gslb will do fallback if there are no available VIPs.
''')

H_TOLERANCE = _(
''' While answering a DNS query, GSLB picks up the VIPs whose scores are
    lower than others. However, it is possible we decide that any one
    whose score is within a certain range of the lowest score can be
    answered. This option is used for that.

    The upper limit of the range is computed as:
    the minimum score plus the tolerance amount

    For example, if the answer count was 2 and the tolerance was 5 and
    we got the following score table calculated,

    &nbsp; &nbsp; score(1.1.1.1) = 10
    &nbsp; &nbsp; score(2.2.2.2) = 13
    &nbsp; &nbsp; score(3.3.3.3) = 15
    &nbsp; &nbsp; score(4.4.4.4) = 20

    then the gslb randomly picks up two from three:
    1.1.1.1, 2.2.2.2 and 3.3.3.3

    If the tolerance was less than 5 in the above example,
    then the gslb picks up the best two: 1.1.1.1 and 2.2.2.2

    Acceptable range : 0.0 - 4294967295.0
''')

H_ANSWER_COUNT = _(''' This value determines the number of answers that will be included in the DNS response packet.
    Acceptable range : 1 ~ 30
''')

H_DELAY_START_TIME = _(
''' When VIP has recovered to be up from down, this value determines the time to apply in the service.
    You could enter the value in seconds. The server will be service on after a period of time which you entered.

    value range : 1-172800 (Max 2days)

    *When used in conjunction with 'Slow start period'
    The VIP will be service on after the period set in 'VIP start delay time' and
    The VIP will service gradually for the period set in 'Slow start period'.
''')

H_SLOWSTART_PERIOD = _(
''' Any new vips added into a domain get started in slow-start mode.
    That is, a new vip initially has 100% chance to be excluded from
    answer selection and the chance linealy decreases to 0% during the
    $slowstart_period seconds.

    Note that, slow-start mode is also applied to the vips which
    were down once but has recovered to be up.

    And also note that, since we are discarding all probe values when we
    stop GSLB, restarting GSLB may cause many of the vip resources fall
    into slow-start mode. To avoid this, we must have some warming-up
    time before getting a restarted GSLB back into service.

    Acceptable range : 0 - 4294967295
''')

H_LIST_ALL = _(
''' If this flag is true, GSLB will respond whole IP addresses
    including unavailable ones.

    If both $sticy and $list_all are true, GSLB will respond whole
    IP addresss from the best pop, including unavailable ones.

    Note that, when VCP DNS is being used, GSLB will mark which IPs
    are available. But if the standard DNS protocol is being used,
    client has no way to distinguish available ones and the others.
''')

H_ANSWER_TTL = _(
'''
This value is used to populate the TTL field of the DNS response packet.

Acceptable range: 0 - 4294967295.
''')

H_CUT_OFF = _(
''' While answering a DNS query, there might be multiple VIPs that might be available. However, it is possible we decide that only
    VIPs whose score is within a certain range of the lowest score be included. This option is used for that.

    The upper limit of the range is computed as:
    &nbsp; &nbsp; the minimum score plus the cutoff amount

    For example, if the answer count was 3 and the cutoff was 20 and we got the following score table calculated,

    &nbsp; &nbsp; score(1.1.1.1) = 10
    &nbsp; &nbsp; score(2.2.2.2) = 20
    &nbsp; &nbsp; score(3.3.3.3) = 40
    &nbsp; &nbsp; score(4.4.4.4) = 50

    then 3.3.3.3 and 4.4.4.4 are eliminated from the answer candidate
    because their scores are higher then the cutoff score: 10+20 = 30.
    In this case, GSLB will answer 1.1.1.1 and 2.2.2.2 even though the answer count was 3.

    Acceptable range: 0 - Infinity
''')

H_LB_TYPE = _(
''' This specifies the load-balancing type which is applied for dynamic answer selection in normal situations, i.e. other than fallback situations.

    GSLB: Optimal answers are selected through regular GSLB algorithm.
    &nbsp; &nbsp; Cutoff and tolerance are applied.
    &nbsp; &nbsp; Down vips are excluded from the selection.

    RR: Answers are selected in round-robin manner.
    &nbsp; &nbsp; Down vips are excluded from the selection.

    RANDOM: Answers are randomly selected.
    &nbsp; &nbsp; Down vips are excluded from the selection.
'''
)

H_NODATA_ACTION = _(
''' The action which should be taken when gslb has no data for the question
  domain. Having no data means that there is no such a domain in the gslb
  domains(given by domains.xml) and no such a zone in the loaded zones
  (given by gslbzones.conf).

  It should be one of the followings.

  FORWARD: Forward the query to the forwarder.
  IGNORE: Drop the query. Do not respond.
  REFUSE: Respond with the response code REFUSED.

  Default is FORWARD.

  Change requires GSLB reload.
'''
)

H_COST_FACTOR = _(
''' A factor by which the cost value of each pop is scaled.
    Cost values, specified in each pop configuration, will be
    multiplied by this scaling_factor and then be added to
    scores of each pop.

    Acceptable range : 0.0 ~ 4294967295.0
''')

H_PKT_IGNORE = _(
''' Whether to ignore the packet loss or not.

    If this is set to false, then all the pops which have
    threshold-exceeded packet loss will be excluded from the
    answer selection.

    It has a concept of UP or DOWN. No matter how much is
    the packet loss rate.
''')

H_UPLINK_IGNORE = _(
    ''' Whether to ignore the uplink probe.

    If this is set to false, then each pop gets the initial
    score from the reported uplink probe value. All the pops
    whose uplink is marked down will be excluded from the
    answer selection.
''')

H_UPLINK_FACTOR = _(
''' A factor by which the uplink probe value is scaled.

    Note that scaling_factor=0 and ignore=true are different when the uplink probe is down.
    In that case, scaling_factor=0 makes this pop to be considered as unavailable,
    but ignore=true just ignores the uplink probe, thus makes this pop to be considered always available irrespetive of uplink status.

    *value range: 0.0 ~ 4294967295.0
''')

H_UPPERBOUND = _(
''' RTT distance evaluating options.

    Let rtt be the measured RTT between the client and the POP.
    Then,
    &nbsp; &nbsp; value = $lowerbound, if rtt < $lowerbound
    &nbsp; &nbsp; value = $upperbound, if rtt > $upperbound
    &nbsp; &nbsp; value = rtt,          otherwise

    RTT distance can not be available
    if the measurement by the RTT server fails.

    Acceptable range : 0.0 - 4294967295.0
''')

H_LOWERBOUND = _(
''' Can not exceed the upperbound value.

    Acceptable range : 0.0 - 4294967295.0
''')

H_GEOIP_DEFAULT = _(
''' GeoIP distance evaluating options.

First, we take a value based on geological location.
If the client and POP located in same city,
value = [city]
else if the client and POP located in same region,
value = [region]
else if the client and POP located in same state,
value = [state]
else if the client and POP located in same country,
value = [country]
else if the client and POP located in same continent,
value = [continent]
otherwise,
value = [default]

Then, we scale the value based on network similarity.
If the client and POP are on same AS,
value = value * [asn]
else if the client and POP are on same ISP,
value = value * [isp]

GeoIP distance can not be available
if the GeoIP DB loading fails.

* Acceptable range : 0.0 - 4294967295.0
''')

H_GEOIP_CONTINENT = _(
'''Assigning a value greater than default will have same
    effect with assigning a value equal to default.

    Acceptable range : 0.0 - 4294967295.0
'''
)

H_COUNTRY = _(
'''Assigning a value greater than continent will have same
    effect with assigning a value equal to continent.

    Acceptable range : 0.0 - 4294967295.0
''')

H_REGION = _(
'''Assigning a value greater than country will have same
    effect with assigning a value equal to country.

    Acceptable range : 0.0 - 4294967295.0
''')

H_STATE = _(
'''Assigning a value greater than region will have same
    effect with assigning a value equal to region.

    Acceptable range : 0.0 - 4294967295.0
''')

H_CITY = _(
'''Assigning a value greater than state will have same
    effect with assigning a value equal to state.

    Acceptable range : 0.0 - 4294967295.0
''')

H_ISP = _(
''' If the client and POP are on a network provided by same ISP,
    then value = value * $isp

    Acceptable range : 0.0 - 1.0
''')

H_ASN = _(
''' Assigning a value greater than <isp> will have same
    effect with assigning a value equal to <isp>.

    Acceptable range : 0.0 - 1.0
''')


H_SCALING_FACTOR = _(
''' A factor by which the distance score is scaled.

    Acceptable range : 0.0 - 4294967295.0
''')

H_PROBE_METRIC = _(
''' The probe to be used for probe score calculation.
'''
)

H_PROBE_METRIC_INC = _(
''' Whenever a VIP is selected, it's load is incremented to prevent overloading.
    The value by which the load is incremented is specified here.

* Default: 0.0
* value range: 0.0 ~ 4294967295.0
''')

H_PROBE_METRIC_SC = _(
''' A factor to scale the probe score.

* Default: 1.0
* value range: 0.0 ~ 4294967295.0
''')

H_STATIC_RULE = _(
'''A rule, generally, is consist of [condition] and [action].
It means that for a given `condition`, take this `action`.
There should be one and only one [condition] per static rule.
However, there can be one or more(up to 10) [action]s per
static rule.

But even though there can be multiple [action]s, only one [action]
can be taken for the rule at a time. Among the multiple <action>s,
first one gets the higher priority and second one gets next higher
priority and so on. Once higher priority <action> fails to be taken,
then lower priority one gets a chance to be taken. For example, if
first [action] restricts answer candidates to a certain subset (see
action type ii~v) but there were no alive ones in the subset, then
second [action] will be tried.
''')

H_CONDITION_SEQUENCE = _(
'''This field used by condition's order. record of lower sequence comes earlier

    * Acceptable range: 1 ~ 2147483647
'''
)

H_ACTION_SEQUENCE = _(
'''This field used by action's order. record of lower sequence comes earlier.
    maximum 10 actions are allowed per condition

    * Acceptable range: 1 ~ 2147483647
'''
)

H_STATIC_ACTION = _(
''' (i) Consider only POPs that belong to a certain <pop_group>
    &nbsp; &nbsp; [type]  = system.pop_group
    &nbsp; &nbsp; [value] = Name of a pop group that has been specified in
    &nbsp; &nbsp; &nbsp; &nbsp; one of the pop files.
    &nbsp; &nbsp; &nbsp; &nbsp; Multiple can be specified separated by comma.

    (ii) Consider only VIPs that belong to a certain <edge>
    &nbsp; &nbsp; [type]  = system.edge
    &nbsp; &nbsp; [value] = Name of a edge that has been specified in
    &nbsp; &nbsp; &nbsp; &nbsp; one of the pop files.
    &nbsp; &nbsp; &nbsp; &nbsp; Multiple can be specified separated by comma.

    (iii) Respond with a custom answer record.
    &nbsp; &nbsp; [type]  = response.answer
    &nbsp; &nbsp; [value] = There are 3 parts separated by comma.
    &nbsp; &nbsp; &nbsp; &nbsp; Part 1: The record type.
    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Acceptable values: CNAME, A
    &nbsp; &nbsp; &nbsp; &nbsp; Part 2: The TTL.
    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Acceptable range: 0 - 4294967295.
    &nbsp; &nbsp; &nbsp; &nbsp; Part 3: The CNAME/A record.

    A flag 'follow_cname' can be used with a CNAME answer.
    If follow_cname = true, GSLB answers corresponding A records
    along with the CNAME record if it can resolve it. This is the
    default behavior. If follow_cname = false, GSLB responds only
    the CNAME record without trying to resolve it.
    The CNAME following can be done only once. For example, let
    the domain www.A.com CNAMEs to www.B.com. We will then try to
    resolve the latter. But if www.B.com CNAMEs to www.C.com, we
    do not try to resolve www.C.com. So there can not be any CNAME
    following chains.

''')

H_BACKUP_ANSWER = _(
''' Backup answers: The custom answers that will be used when
    there are no available vips to be answered.

    CNAME or A record can be specified and its syntax is similar to
    the custom answer type of <action> in <static>.

    In a statement line, there are 3 parts separated by comma.
    Part 1: The record type.
    &nbsp; &nbsp; Acceptable values: CNAME, A
    Part 2: The TTL.
    &nbsp; &nbsp; Acceptable range: 0 - 4294967295.
    Part 3: The CNAME/A record.

    Example:
    &nbsp; &nbsp; CNAME, 300, origin.foo.com.
    &nbsp; &nbsp; follow_cname = true

    Multiple A record answers are allowed but multiple CNAME record
    answers are not. In addition, A and CNAME can not be used together.

    A flag 'follow_cname' can be used with a CNAME answer.
    If follow_cname = true, GSLB answers corresponding A records
    along with the CNAME record if it can resolve it. This is the
    default behavior. If follow_cname = false, GSLB responds only
    the CNAME record without trying to resolve it.
    The CNAME following can be done only once. For example, let
    the domain www.A.com CNAMEs to www.B.com. We will then try to
    resolve the latter. But if www.B.com CNAMEs to www.C.com, we
    do not try to resolve www.C.com. So there can not be any CNAME
    following chains.
''')

H_DOMAIN_NAME = _(
''' The domain name must to follow these rules:
    &nbsp; &nbsp; 1) The entire domain name cannot be larger than 255 characters.
    &nbsp; &nbsp; 2) A domain name may be made up of multiple labels. Two adjacent labels are
    &nbsp; &nbsp; &nbsp; &nbsp; separated by exactly one period (".")
    &nbsp; &nbsp; 3) Each label must have at least one period(".") and cannot be larger than 63 characters.
    &nbsp; &nbsp; 4) Only alphabets(A~Z and a~z), digits(0~9),hyphen("-") and asterisk("*") are allowed in each label.
    &nbsp; &nbsp; 5) Hyphen("-") cannot be the first or the last character of each label.
    &nbsp; &nbsp; 6) Asterisk("*") cannot be more than once in the entire domain name.

    Here are the domain name matching rules:
    &nbsp; &nbsp;1) It does case-insensitive string comparison.
    &nbsp; &nbsp;   e.g. Question WWW.FOO.COM matches to the domain www.foo.com.
    &nbsp; &nbsp;2) Exact match has higher priority than wildcard match. We use
    &nbsp; &nbsp;   asterisk("*") as the wildcard character which matches to any
    &nbsp; &nbsp;   possible non-empty string.
    &nbsp; &nbsp;   e.g. Question WWW.FOO.COM matches to the regular domain www.foo.com
    &nbsp; &nbsp;   and the wildcard domain www.*.com. If both www.foo.com and www.*.com
    &nbsp; &nbsp;   exist at the same time, the question matches to www.foo.com.
    &nbsp; &nbsp;3) If multiple wildcard matches exist, the one having longer
    &nbsp; &nbsp;   post-wildcard string has higher priority.
    &nbsp; &nbsp;   e.g. Question WWW.FOO.COM matches to the wildcard domain *.foo.com
    &nbsp; &nbsp;   and the wildcard domain www.*.com. If both *.foo.com and www.*.com
    &nbsp; &nbsp;   exist at the same time, the question matches to *.foo.com.
    &nbsp; &nbsp;4) Among the wildcard domains having same post-wildcard string,
    &nbsp; &nbsp;   the one having longer pre-wildcard string has higher priority.
    &nbsp; &nbsp;   e.g. Question WWW.FOO.COM matches to the wildcard domain www.*.com
    &nbsp; &nbsp;   and the wildcard domain *.com. If both www.*.com and *.com exist at
    &nbsp; &nbsp;   the same time, the question matches to www.*.com.
''')

H_DOMAIN_ALIAS_NAME = _(
''' The domain alias name must to follow these rules:
    &nbsp; &nbsp; 1) The entire domain name cannot be larger than 255 characters.
    &nbsp; &nbsp; 2) A domain name may be made up of multiple labels. Two adjacent labels are
    &nbsp; &nbsp; &nbsp; &nbsp; separated by exactly one period (".")
    &nbsp; &nbsp; 3) Each label must have at least one period(".") and cannot be larger than 63 characters.
    &nbsp; &nbsp; 4) Only alphabets(A~Z and a~z), digits(0~9),hyphen("-") and asterisk("*") are allowed in each label.
    &nbsp; &nbsp; 5) Hyphen("-") cannot be the first or the last character of each label.
    &nbsp; &nbsp; 6) Asterisk("*") cannot be more than once in the entire domain name.

    Here are the domain name matching rules:
    &nbsp; &nbsp;1) It does case-insensitive string comparison.
    &nbsp; &nbsp;   e.g. Question WWW.FOO.COM matches to the domain www.foo.com.
    &nbsp; &nbsp;2) Exact match has higher priority than wildcard match. We use
    &nbsp; &nbsp;   asterisk("*") as the wildcard character which matches to any
    &nbsp; &nbsp;   possible non-empty string.
    &nbsp; &nbsp;   e.g. Question WWW.FOO.COM matches to the regular domain www.foo.com
    &nbsp; &nbsp;   and the wildcard domain www.*.com. If both www.foo.com and www.*.com
    &nbsp; &nbsp;   exist at the same time, the question matches to www.foo.com.
    &nbsp; &nbsp;3) If multiple wildcard matches exist, the one having longer
    &nbsp; &nbsp;   post-wildcard string has higher priority.
    &nbsp; &nbsp;   e.g. Question WWW.FOO.COM matches to the wildcard domain *.foo.com
    &nbsp; &nbsp;   and the wildcard domain www.*.com. If both *.foo.com and www.*.com
    &nbsp; &nbsp;   exist at the same time, the question matches to *.foo.com.
    &nbsp; &nbsp;4) Among the wildcard domains having same post-wildcard string,
    &nbsp; &nbsp;   the one having longer pre-wildcard string has higher priority.
    &nbsp; &nbsp;   e.g. Question WWW.FOO.COM matches to the wildcard domain www.*.com
    &nbsp; &nbsp;   and the wildcard domain *.com. If both www.*.com and *.com exist at
    &nbsp; &nbsp;   the same time, the question matches to www.*.com.
'''
)

H_DOMAIN_DESC = _('''
Describe of domains.
Allowed message max length is 1024 Bytes.
''')

H_ENABLE_EDNS_SUBNET = _('''
    Let GSLB use edns-client-subnet instead of LDNS IP
    if the information is given through DNS query.
''')

H_ENABLE_CNAME_LATENCY = _('''
    Allow GSLB to run CNAME latency measurement
    when this domain gets queried.
''')

H_PRIORITY = _('''Priority to be chosen as answer.

Denoting that priority 1 as primary and priority 2 as secondary,
if any of primary vips are available, GSLB chooses answers only
from the primary vips even if there are better secondary vips.
In other words, secondary vips can only be chosen when all
primary vips are unavailable. If all vips are unavailable,
then answers are randomly chosen only from the primary vips.
Same logic is extended to the later priorities. For example,
tertiary(priority 3) vips can only be chosen when all primary
and secondary vips are unavailable.

Note that setting the priorities on mproxy shield vips is
important for the failover path of DNA product (since 2.0).
Mproxy may ask GSLB to choose answers only from the backup
(non-primary) vips so that it can try with the backup shield
when there was any issue in between the primary shield and the
origin. So we should put 1 as the priority of primary shields
and put 2 or more as the priority of backup shields.

Value range: 1~10 (integer)
<b>Default: 1</b>
''')

H_GSLB_STATICRULE_CONDITION_INVERT = _("""If this is True, Invert of the Condtion gets applied for static rule matching.
For example, if the Condition was 'client.conuntry = KR' and the Invert option was True,
this static rule matches to the DNS queries from all other conuntries than KR.

Note that, the Invert option only works for the 'client' statements.
The other statements like 'always' or 'request.portion' are not affected by the Invert option.
""")
