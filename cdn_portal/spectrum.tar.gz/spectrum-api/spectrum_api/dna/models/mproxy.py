#
# Copyright (c) 2011 CDNetworks Co., Ltd.
# All rights reserved.
#
# $Id: mproxy.py 11864 2014-01-02 02:15:00Z kookheon.kwon $
#

import os
import re
from django.core.validators import MaxValueValidator, MinValueValidator, \
    MaxLengthValidator
from django.db import models
from django.conf import settings
from django.utils.translation import ugettext as _
from django.core.cache import cache

from spectrum_api.shared_components.utils.common import run_command_from_local, get_vips_by_ipaddr,\
    get_cityname_by_popcode,get_mproxy_pop_status_by_popcode
from spectrum_api.configuration.models import InterimModel
from spectrum_api.configuration.models.base import VipSearch
from spectrum_api.shared_components.models import StatMaster, BaseModel
from spectrum_api.shared_components.models.customer import CustomerAccount
from spectrum_api.dna.models.domain import Domain, DomainEdge, DomainVip, \
    MproxyApp, MproxyStatMaster
from spectrum_api.dna.models.help_msg import H_PORT, H_ORIGIN_PORT, H_ACL_TYPE, \
    H_PROTOCOL, H_TYPE, H_DS_RESET, H_ACCESS_LOG, H_CACCESS_LOG, H_ORIGIN_FB, \
    H_LOG_LEVEL, H_READ_S, H_WRITE_S, H_CONNECT_S, H_DS_IDLE_S, H_US_IDLE_S, \
    H_TIMEOUT_FB, H_DYNAMIC_RELAY, H_CIP_PASSTHROUGH, H_GZIP_REQ, H_GZIP_REP, \
    H_GZIP_WBITS, H_GZIP_MEMLEVEL, H_GZIP_COMPLEVEL, H_GZIP_MAXBUF, \
    H_ORIGIN_DOMAIN, H_SHIELD_DOMAIN, H_RELAY_DOMAIN

REGEX_IPV4_VCPDIG= "^\{IP\s\#\d+\}\s*flags:\s*(.*)\s*\|\s*len:\s*(\d+)\s*\|\s*addr:\s*(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\s*$"
#{IP #01} flags: Avail Shield | len: 4 | addr: 119.31.249.134
REGEX_DNS_VCPDIG= "^\{DNS_RESPONSE}\s*id:\s*(\d+)\s*\|\s*name_len:\s*(\d+)\s*\|\s*name:\s*(.*)\s*\|\s*rcode:\s*(.*)\s*\|\s*flags:\s*(.*)\s*\|\s*pktno:\s*(\d+)\s*\|\s*ip_count:\s*(\d+)\s*\|\s*ai_count:\s*(\d+)\s*$"
#{DNS_RESPONSE} id: 58952 | name_len: 45 | name: x174.35.71.209.fotatest2-dn.mshield.cdngd.net | rcode: NOERROR | flags: Last Dynamic | pktno: 0 | ip_count: 2 | ai_count: 0

ALERT_STATUS = (
            (0, 'Inbound Traffic Spike'),
            (1, 'Outbound Traffic Spike'),
            (2, 'Inbound Traffic Down'),
            (3, 'Outbound Traffic Down'),
            (4, 'Connection Spike'),
            (5, 'Connection Down'),
            (6, 'Error Spike'),
)

THRESHOLD_TYPE = (
            (0, 'Static'),
            (1, 'Dynamic'),
)

class MproxyBaseConfig(InterimModel):
    """
    Mproxy Common Configuration
    """
#     port = models.PositiveIntegerField(
#         validators=[MinValueValidator(1), MaxValueValidator(65535)],
#         help_text=H_PORT
#     )

    origin_port = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(65535)],
        blank=True,
        help_text=H_ORIGIN_PORT
    )

    ACL_TYPES = (
                 ('white', 'white'),
                 ('black', 'black'),
    )

    acl_type = models.CharField(
        max_length=20,
        choices=ACL_TYPES,
        blank=True,
        help_text=H_ACL_TYPE)

    PROTOCOL_TYPES = (
        ('tcp', 'tcp'),
        ('udp', 'udp'),
    )
    protocol = models.CharField(
        max_length=10,
        choices=PROTOCOL_TYPES,
        default="tcp",
        help_text=H_PROTOCOL
    )
    SERVICE_TYPES = (
        ('tunnel', 'tunnel'),
        ('http', 'http'),
    )
    type = models.CharField(
        max_length=10,
        choices=SERVICE_TYPES,
        default="tunnel",
        help_text=H_TYPE
    )
    ds_reset_on_error = models.BooleanField(
        default=False,
        blank=True,
        help_text=H_DS_RESET)
    access_log = models.CharField(
        max_length=1024,
        blank=True,
        help_text=H_ACCESS_LOG)
    continuous_access_log = models.CharField(
        max_length=1024,
        blank=True,
        help_text=H_CACCESS_LOG)
    origin_fb = models.BooleanField(
        default=False,
        blank=True,
        help_text=H_ORIGIN_FB)
    log_level = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        validators=[MaxValueValidator(255)],
        help_text=H_LOG_LEVEL)

    # for timeout
    timeout_read_s = models.PositiveSmallIntegerField(
        _('Read Timeout'),
        null=True,
        blank=True,
        help_text=H_READ_S)
    timeout_write_s = models.PositiveSmallIntegerField(
        _('Write Timeout'),
        null=True,
        blank=True,
        help_text=H_WRITE_S)
    timeout_connect_s = models.PositiveSmallIntegerField(
        _('Connection Timeout'),
        null=True,
        blank=True,
        help_text=H_CONNECT_S)
    timeout_ds_idle_s = models.PositiveSmallIntegerField(
        _('Downstream Idle Timeout'),
        null=True,
        blank=True,
        help_text=H_DS_IDLE_S)
    timeout_us_idle_s = models.PositiveSmallIntegerField(
        _('Upstream Idle Timeout'),
        null=True,
        blank=True,
        help_text=H_US_IDLE_S)
    timeout_fb_s = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        validators=[MaxValueValidator(4294967295)],
        help_text=H_TIMEOUT_FB)

    dynamic_relay = models.BooleanField(
        default=False,
        blank=True,
        help_text=H_DYNAMIC_RELAY)
    cip_passthrough = models.BooleanField(
        default=False,
        blank=True,
        help_text=H_CIP_PASSTHROUGH)
    # for gzip
    gzip_req = models.BooleanField(
        default=False,
        blank=True,
        help_text=H_GZIP_REQ)
    gzip_rep = models.BooleanField(
        default=False,
        blank=True,
        help_text=H_GZIP_REP)
    gzip_wbits = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        validators=[MinValueValidator(8), MaxValueValidator(15)],
        help_text=H_GZIP_WBITS)
    gzip_memlevel = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        validators=[MinValueValidator(1), MaxValueValidator(9)],
        help_text=H_GZIP_MEMLEVEL)
    gzip_complevel = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        validators=[MaxValueValidator(9)],
        help_text=H_GZIP_COMPLEVEL)
    gzip_maxbuf = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        validators=[MaxValueValidator(4294967295)],
        help_text=H_GZIP_MAXBUF)

    class Meta:
        abstract = True

    def get_ip_status(self, vip):
        result = vip.get_status_enabled()
        try:
            if vip.enable_gslb == 1:
                from spectrum_api.configuration.models.node_mon import NodeRms
                noderms = NodeRms.objects.get(vip_ip=str(vip))
                if noderms.val is not None and noderms.val < 0:
                    result = 'failure'
        except:
            return result
        return result


class MproxyDomainEdge(MproxyBaseConfig):
    """
    mproxy configuration for a edge of domain
    """

    mproxy_edge_id = models.AutoField(primary_key=True)
    origin_domain = models.ForeignKey(
        Domain,
        related_name='edge_origin_set',
        help_text=H_ORIGIN_DOMAIN)
    shield_domain = models.ForeignKey(
        Domain,
        related_name='edge_shield_set',
        help_text=H_SHIELD_DOMAIN)
    relay_domain = models.ForeignKey(
        Domain,
        related_name='edge_relay_set',
        help_text=H_RELAY_DOMAIN, null=True, blank=True)
    domain_edge = models.ForeignKey(DomainEdge)
    mproxy_app = models.ForeignKey(MproxyApp)

    SELECT_PORT_TYPES = (
        (1, 'Single'),
        (2, 'List'),
        (3, 'Range'),
    )
    BOOL_TYPES = (
        (0, 'False'),
        (1, 'True'),
    )

    port = models.CharField(
        max_length=20,
        null=True,
        help_text=H_PORT
    )
    port_type = models.SmallIntegerField(
        choices=SELECT_PORT_TYPES,
        null=False
    )
    external_domain = models.CharField(
        max_length=255,
        blank=True
    )
    external_domain_enabled = models.SmallIntegerField(
        choices=BOOL_TYPES,
        null=True,
        blank=True
    )


    class Meta:
        app_label = 'dna'
        db_table = 'mproxy_edge'
        verbose_name = _('MProxy Configuration')
        unique_together = [('domain_edge', 'port', 'protocol') ]

    def __unicode__(self):
        try:
            return u'%s(%s)' % (self.mproxy_app, self.domain_edge)
        except:
            return u'%s' % self.domain_edge

    def get_displayname(self):
        return u'%s/%s' % (self.protocol, str(self.port))

    def get_vips(self):
        vips = self.domain_edge.getvips()
        return vips

    def get_relay_type(self):
        if self.dynamic_relay:
            return 'dynamic relay'
        else:
            return 'static relay'

    def get_popnames(self):
        return self.domain_edge.getpopnames()

    def get_tcp_dynamic_vcpdig_result_from_command(self, edge_ip, target_domain, dynamic_relay=False):
        '''
        :param edge_ip:
        :param target_domain:
        :param dynamic_relay: do not use self.dynamic relay. use parameter
        :return:
        '''
        vcpdig_file = "%s/bin/vcpdig" % settings.PROJECT_LOCATION
        if os.path.exists(vcpdig_file):
            cmd = "%s -i %s x%s.%s" % (vcpdig_file, settings.GSLB_SERVER, edge_ip, target_domain)
            if dynamic_relay:
                route_protocol_option = 'T'
                if str(self.protocol) == 'udp':
                    route_protocol_option = 'U'
                cmd = "%s -%s" % (cmd, route_protocol_option)

            return run_command_from_local(cmd)
        else:
            raise Exception("%s file does not exist." % vcpdig_file)

    def parse_vips_from_vcp_dig_result(self, vcpdig_result):
        vcpdig_result = vcpdig_result.replace("\r\n", "\n")
        lines = vcpdig_result.split("\n")
        try:
            iplist = []
            dynamic_check = None
            for line in lines:
                match = re.match(REGEX_IPV4_VCPDIG, line, re.IGNORECASE)
                if match:
                    ipaddr = match.group(3)
                    if ipaddr not in iplist:
                        iplist.append(ipaddr)

                dns_match = re.match(REGEX_DNS_VCPDIG, line, re.IGNORECASE)
                if dns_match:
                    flags_check = dns_match.group(5)
                    flags_check_list = str(flags_check).strip().split(' ')
                    if 'Dynamic' in flags_check_list:
                        dynamic_check = flags_check
            return iplist, dynamic_check
        except Exception,e:
            raise e

    def get_pop_code_by_iplist(self, iplist, ip_pop_dict=None):
        for ipaddr in iplist:
            try:
                if ip_pop_dict is None:
                    #this is expensive
                    vips = get_vips_by_ipaddr(ipaddr)
                    return vips[0].getpopname()
                else:
                    return ip_pop_dict.get(ipaddr)
            except:
                pass

        return ''


    def get_relay_pop_code(self, edge_ip, target_domain, ipdict = None, dynamic_relay=False, number=1):
        cache_key = "relay_edge_%s_%s_%s" % (edge_ip,target_domain,number)
        if edge_ip.strip() == '':
            return '',[], None
        else:
            try:
                iplist = cache.get(cache_key)
                try:
                    popcode = self.get_pop_code_by_iplist(iplist, ipdict)
                except:
                    popcode = ''
            except:
                iplist = None

            dynamic_check = None
            if iplist is None:
                digresult, err = self.get_tcp_dynamic_vcpdig_result_from_command(edge_ip, target_domain, dynamic_relay)
                try:
                    iplist, dynamic_check = self.parse_vips_from_vcp_dig_result(digresult)
                    cache.set(cache_key, iplist, 5)
                    popcode = self.get_pop_code_by_iplist(iplist, ipdict)
                except Exception,e:
                    raise e

            return popcode, iplist, dynamic_check

    def get_relay_route(self, edge_pop_code = None, ipdict=None):
        '''
        return mproxy relay routing path. internally run vcpdig to communicate with GSLB server.
        :param edge_pop_code:
        :return:
        '''
        edge_domain_vips = self.mproxy_app.edge_domain.get_all_related_vips()
        if self.external_domain_enabled:
            origin_domain_name = self.external_domain
        else:
            origin_domain_name = self.origin_domain.name

        edge_pop_route_list = []
        pop_list = []
        vipsearches = VipSearch.objects.filter(pk__in=edge_domain_vips.values('vip'))
        for vip in vipsearches:
            if vip.pop_name not in pop_list:
                edge_ipaddr = vip.ip
                pop_list.append(vip.pop_name)
                try:
                    shield_domain_preset = self.shield_domain.mproxy_preset.pk
                except:
                    shield_domain_preset = None

                if edge_pop_code is not None and vip.pop_name.upper() != edge_pop_code.upper():
                    continue

                edge_pop_route = {'mproxy_app_id':str(self.mproxy_app.pk),
                                  'mproxy_edge_id':str(self.pk),
                                  'dynamic_relay': str(self.dynamic_relay),
                                  'relay_domain': str(self.relay_domain if self.relay_domain else ''),
                                  'port': str(self.port),
                                  'protocol': str(self.protocol)}

                relay_iplist_all = []
                relay_pop_code_all = []
                if self.dynamic_relay:
                    # relay 1 check
                    relay_pop_code, relay_iplist, dynamic_check = self.get_relay_pop_code(edge_ipaddr,
                                                                                          self.shield_domain.name,
                                                                                          ipdict,
                                                                                          self.dynamic_relay)
                    relay_iplist_all.append(relay_iplist)
                    relay_pop_code_all.append(relay_pop_code)
                    if len(relay_iplist) > 0:
                        edge_ipaddr = relay_iplist[0]

                    if dynamic_check and shield_domain_preset is not None and shield_domain_preset != 0:
                        # mproxy_preset_id not null(0)
                        # relay 2 check
                        relay_pop_code, relay_iplist, dynamic_check = self.get_relay_pop_code(edge_ipaddr,
                                                                                          self.shield_domain.name,
                                                                                          ipdict,
                                                                                          self.dynamic_relay,
                                                                                          2)
                        relay_iplist_all.append(relay_iplist)
                        relay_pop_code_all.append(relay_pop_code)
                        if len(relay_iplist) > 0:
                            edge_ipaddr = relay_iplist[0]

                        if dynamic_check:
                            # relay 3 check
                            relay_pop_code, relay_iplist, dynamic_check = self.get_relay_pop_code(edge_ipaddr,
                                                                                          self.shield_domain.name,
                                                                                          ipdict,
                                                                                          self.dynamic_relay,
                                                                                          3)
                            relay_iplist_all.append(relay_iplist)
                            relay_pop_code_all.append(relay_pop_code)
                            if len(relay_iplist) > 0:
                                edge_ipaddr = relay_iplist[0]
                else:
                    if self.relay_domain:
                        relay_pop_code, relay_iplist, dynamic_check = self.get_relay_pop_code(edge_ipaddr, self.relay_domain.name, ipdict)
                        if len(relay_iplist) > 0:
                            edge_ipaddr = relay_iplist[0]
                        else:
                            edge_ipaddr = ''
                        relay_iplist_all.append(relay_iplist)
                        relay_pop_code_all.append(relay_pop_code)

                shield_pop_code, shield_iplist, dynamic_check = self.get_relay_pop_code(edge_ipaddr, self.shield_domain.name, ipdict)
                if self.dynamic_relay:
                    relay_pop_city_all = []
                    relay_pop_status_all = []
                    for relay_pop in relay_pop_code_all:
                        relay_pop_city_all.append(get_cityname_by_popcode(relay_pop))
                        relay_pop_status_all.append(get_mproxy_pop_status_by_popcode(relay_pop))
                    edge_pop_route.update({'relay_pop_status':relay_pop_status_all})
                    edge_pop_route.update({'relay_pop_city':relay_pop_city_all})
                if len(shield_iplist) > 0:
                    shield_ipaddr = shield_iplist[0]
                else:
                    shield_ipaddr = ''

                origin_pop_code, origin_iplist, dynamic_check = self.get_relay_pop_code(shield_ipaddr, origin_domain_name, ipdict)

                edge_pop_route.update({'edge_pop_code': vip.pop_name,
                                  'relay_pop_code':relay_pop_code_all,
                                  'relay_ip_list': relay_iplist_all,
                                  'shield_domain_name':self.shield_domain.name,
                                  'shield_pop_code': shield_pop_code,
                                  'shield_ip_list': shield_iplist,
                                  'origin_domain_name': origin_domain_name,
                                  'origin_pop_code':origin_pop_code,
                                  'origin_ip_list': origin_iplist,
                                  'mproxy_preset_id':shield_domain_preset})

                edge_pop_route_list.append(edge_pop_route)
        return edge_pop_route_list

    def save(self, *args, **kwargs):
        super(MproxyDomainEdge, self).save(*args, **kwargs)

class MproxyDomainVip(MproxyBaseConfig):
    """
    mproxy configuration for a vip of domain
    """
    mproxy_vip_id = models.AutoField(primary_key=True)
    origin_domain = models.ForeignKey(Domain, related_name='vip_origin_set')
    shield_domain = models.ForeignKey(Domain, related_name='vip_shield_set')
    relay_domain = models.ForeignKey(Domain, related_name='vip_relay_set', null=True, blank=True)
    domain_vip = models.ForeignKey(DomainVip)
    # base_vip = models.ForeignKey(Vip)
    mproxy_app = models.ForeignKey(MproxyApp)

    port = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(65535)],
        help_text=H_PORT
    )

    class Meta:
        app_label = 'dna'
        db_table = 'mproxy_vip'
        verbose_name = _('MProxy Configuration')
        unique_together = [('domain_vip', 'port', 'protocol')]

    def __unicode__(self):
        try:
            return u'%s(%s)' % (self.mproxy_app, self.domain_vip)
        except:
            return u'%s' % self.domain_vip

    def get_displayname(self):
        return u'%s/%s' % (self.protocol, str(self.port))

    def get_relay_type(self):
        if self.dynamic_relay:
            return 'dynamic relay'
        else:
            return 'static relay'

    def save(self, *args, **kwargs):
        super(MproxyDomainVip, self).save(*args, **kwargs)


class MproxyAlertManagement(BaseModel):
    """
    dna - monitoring alert menu / alert management
    """
    alert_id = models.AutoField(primary_key=True, db_column='alert_management_id')
    alert_type = models.PositiveSmallIntegerField(choices=ALERT_STATUS)
    service_domain = models.IntegerField(db_column='service_domain_id', null=True)  # service_domain_id field
    stat_master = models.ForeignKey(StatMaster, db_column="mproxy_stat_id")
    threshold_type = models.PositiveSmallIntegerField(default=0, choices=THRESHOLD_TYPE)
    threshold_value = models.IntegerField(validators=[MaxValueValidator(4294967295)])
    alert_receiver = models.CharField(max_length=512, validators=[MaxLengthValidator(512)])
    account = models.ForeignKey(CustomerAccount, db_column='account_no')
    obj_state = models.PositiveSmallIntegerField(default=1)

    class Meta:
        app_label = 'dna'
        db_table = 'mproxy_alert_management'
        ordering = ['alert_id', ]

    class SpectrumMeta:
        allow_delete = True
        track = True

    def get_mproxy_app_delete_check(self):
        is_deleted = False

        try:
            if self.stat_master:
                mproxy_app = MproxyApp.objects.get(mproxy_app_name=self.stat_master.keyword)
        except:
            is_deleted = True

        return is_deleted

class MproxyAlertHistory(BaseModel):
    """
    dna - monitoring alert menu / alert history
    """
    alert = models.ForeignKey(MproxyAlertManagement, db_column="alert_id")
    statmaster = models.ForeignKey(StatMaster, db_column="stat_id")
    service_domain = models.CharField(max_length=255)
    alert_type = models.PositiveSmallIntegerField(choices=ALERT_STATUS)
    fail_message = models.CharField(max_length=512)
    update_time = models.DateTimeField(auto_now=True, auto_now_add=True, primary_key=True)

    class Meta:
        unique_together = ('update_time', 'alert_id', 'stat_id')
        app_label = 'dna'
        db_table = 'dna_alert_history'

    class SpectrumMeta:
        read_only = True

