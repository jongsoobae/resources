# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Domain Regular expression
"""
import re

# PRISMUI-1578 better domain name validation
'''
    REGEX_DOMAIN_NAME = r'(?=^.{1,254}$)(^(?:(?!-)[a-zA-Z0-9\-]{1,63}(?<!-)\.?)+(?:[a-zA-Z]{2,})$)'
    REGEX_DOMAIN_NAME_FLEXIBLE = r'(?=^.{1,254}$)(^(?:(?!-)[a-zA-Z0-9\-_]{1,63}(?<!-)\.?)+(?:[a-zA-Z]{2,})$)'

    REGEX_HOST_NAME = r'^(|(\*|(?!-)[a-zA-Z0-9-]{1,63}(?<!-))((\.)(?!-)[a-zA-Z0-9-]{1,63}(?<!-))*)$'
    REGEX_HOST_NAME_FLEXIBLE = r'^(|(\*|(?!-)[a-zA-Z0-9-_]{1,63}(?<!-))((\.)(?!-)[a-zA-Z0-9-_]{1,63}(?<!-))*)$'

    REGEX_HOST_NAME_NS = r'^(|(|(?!-)[a-zA-Z0-9-_]{1,63}(?<!-))((\.)(?!-)[a-zA-Z0-9-_]{1,63}(?<!-))*)$'
    REGEX_DOMAIN_NAME_FLEXIBLE2 = r'^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.[a-zA-Z]{2,4}$'
    REGEX_DOMAIN_NAME_FQDN = '(?=^.{1,254}$)(^(?:(?!-)[a-zA-Z0-9\-]{1,63}(?<!-)\.?)+(?:[a-zA-Z]{2,})\.?$)'
'''
ALLOW_ASTERISK_DOMAIN_REGEX = re.compile(r'(?=^.{1,254}$)(^([a-zA-Z0-9\-\_\,\*]{1,63}(\.|$))+$)')
NOT_ALLOW_ASTERISK_DOMAIN_REGEX = re.compile(r'(?=^.{1,254}$)(^([a-zA-Z0-9\-\_\,]{1,63}(\.|$))+$)')

DNS_CNAME_POLICY_REGEX = re.compile(r'(?=^.{1,254}$)(?=^(?!\-|\_))(([a-zA-Z0-9\-\_]{0,61}[a-zA-Z0-9](\.|$)(?!\-|\_))+$)')

regex_domain_flexible2 = NOT_ALLOW_ASTERISK_DOMAIN_REGEX
regex_domain = NOT_ALLOW_ASTERISK_DOMAIN_REGEX
regex_domain_flexible = NOT_ALLOW_ASTERISK_DOMAIN_REGEX
regex_domain_fqdn = NOT_ALLOW_ASTERISK_DOMAIN_REGEX
regex_host_ns = NOT_ALLOW_ASTERISK_DOMAIN_REGEX

regex_host = ALLOW_ASTERISK_DOMAIN_REGEX
regex_host_flexible = ALLOW_ASTERISK_DOMAIN_REGEX


regex_cname_policy = DNS_CNAME_POLICY_REGEX
IP_RE = re.compile(
    r"^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$")
IP_CIDR_RE = re.compile(r'^(\d{1,3}\.){0,3}\d{1,3}/\d{1,2}$')

regex_ip = re.compile(IP_RE)
regex_ip_cidr = re.compile(IP_CIDR_RE)