from django.db import models
from spectrum_api.shared_components.models import BaseModel

class DnaStatParent(BaseModel):
    start_time = models.DateTimeField(auto_now_add=True)
    end_time = models.DateTimeField(default='2038-01-01 00:00:00')

    class Meta:
        abstract = True

    class SpectrumMeta:
        read_only = True
        router = 'stats'

class DnaLocationContinentMap(DnaStatParent):
    continent_id = models.AutoField(primary_key=True)
    ihms_continent = models.CharField(unique=True, max_length=100)
    continent_name = models.CharField(max_length=100)
    is_visible = models.BooleanField(db_column='isVisible')

    class Meta:
        db_table = 'location_continent_map'

class DnaLocationCountryMap(DnaStatParent):
    country_id = models.AutoField(primary_key=True)
    continent = models.ForeignKey(DnaLocationContinentMap)
    country_name = models.CharField(max_length=100)
    ihms_country = models.CharField(max_length=50, primary_key=True, db_column='ihms_country')
    is_visible = models.BooleanField(db_column='isVisible')

    class Meta:
        db_table = 'location_country_map'

class DnaLocationRegionMap(DnaStatParent):
    region_id = models.AutoField(primary_key=True)
    country = models.ForeignKey(DnaLocationCountryMap)
    region_name = models.CharField(max_length=100)
    is_visible = models.BooleanField(db_column='isVisible')

    class Meta:
        db_table = 'location_region_map'
        unique_together = ('country', 'region_name')

class DnaLocationIspMap(DnaStatParent):
    isp_id = models.AutoField(primary_key=True)
    isp_name = models.CharField(max_length=100)
    ihms_isp_code = models.CharField(max_length=50)
    is_visible = models.BooleanField(db_column='isVisible')

    class Meta:
        db_table = 'location_isp_map'

