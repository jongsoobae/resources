# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Domain Serializer
"""
from django.core.validators import MaxValueValidator, MinValueValidator, \
    RegexValidator
from django.db.models import Q
from django.utils.translation import ugettext as _
from rest_framework import serializers
from spectrum_api.configuration.models.gslb import LB_TYPES, SELECT_TYPES
from spectrum_api.dna.models import DOMAIN_ALIAS
from spectrum_api.dna.models.domain import Domain, DomainAll, DomainStaticRuleCondition, \
    DomainStaticRuleAction, DomainEdge, DomainVip, DomainAlias, DomainDynamicRelay
from spectrum_api.dna.utils.validate_static_rule import validate_static_rule
from spectrum_api.configuration.models.help_msg import H_ENABLE_GSLB, \
    H_NUM_THREADS, H_GSLB_DNS_PORT, H_MAX_CLIENT_RECORDS, H_RTT_REQUEST_INTERVAL, \
    H_PKTLOSS_MOVE_RATE, H_BASEDOMAIN, H_TXT_PREFIX, H_TXT_PASSWORD, \
    H_GEOIP_FILENAME, H_STATIC_DOMAIN_ANSWER_TTL, H_FORWARDER, H_FORWARDER_TYPE, \
    H_DEBUG_PORT, H_DEBUG_TIMEOUT, H_REQUEST_LOG_ROTATE_INTERVAL, \
    H_FAILURE_LOG_ROTATE_INTERVAL, H_LOG_FAILURE, H_LOG_FORWARD, \
    H_GSLB_MAX_RESOLUTION_T, H_GSLB_CNAME_LATENCY_USE, H_LOG_PROBE, \
    H_LOG_PEDOMAIN_REQUEST, H_PROBE_LOG_ROTATE_INTERVAL
from spectrum_api.dna.models.help_msg import H_ENABLE_VCPDNS, H_ENABLE_STAT, \
    H_LOG_REQUEST, H_STICKY, H_LIST_ALL, H_SLOWSTART_PERIOD, H_ANSWER_COUNT, \
    H_ANSWER_TTL, H_CUT_OFF, H_TOLERANCE, H_PERCENT, H_COUNT, H_LB_TYPE, \
    H_ENABLE_EDNS_SUBNET, H_ENABLE_CNAME_LATENCY, H_COST_FACTOR, H_PKT_IGNORE, \
    H_UPLINK_IGNORE, H_UPLINK_FACTOR, H_UPPERBOUND, H_LOWERBOUND, \
    H_GEOIP_DEFAULT, H_GEOIP_CONTINENT, H_COUNTRY, H_REGION, H_STATE, H_CITY, \
    H_ISP, H_ASN, H_SCALING_FACTOR, H_NODATA_ACTION, H_DELAY_START_TIME
from spectrum_api.dna.models.help_msg import H_PROBE_METRIC_INC, \
    H_PROBE_METRIC_SC, H_DOMAIN_NAME, H_BACKUP_ANSWER, H_DOMAIN_DESC, \
    H_EDGE_DOMAIN, H_MPROXY_APP, H_DOMAIN_ALIAS_NAME, H_ENABLE_GSLB, H_LB_TYPE, \
    H_ANSWER_COUNT, H_ANSWER_TTL, H_CONDITION_SEQUENCE, H_STATIC_RULE, \
    H_GSLB_STATICRULE_CONDITION_INVERT, H_ACTION_SEQUENCE, H_PROBE_INC, \
    H_PROBE_SCALING, H_WEIGHT, H_PRIORITY

from spectrum_api.configuration.models.preset_relay import MproxyPresetRelay

class SubDomainEdgeSerializer(serializers.ModelSerializer):
    edge_name = serializers.RelatedField(source="edge", read_only=True)
    probe_name = serializers.RelatedField(source="probe", read_only=True)

    class Meta:
        model = DomainEdge
        fields = ("domain_edge_id",
                  "probe",
                  "probe_name",
                  "probe_increment",
                  "probe_scaling_factor",
                  "weight",
                  "priority",
                  "edge",
                  "edge_name")

    def validate(self, attrs):
        probe_increment = attrs.get("probe_increment", None)
        probe_scaling_factor = attrs.get("probe_scaling_factor", None)

        if probe_increment is not None or probe_scaling_factor is not None:
            domain_edge_probe = attrs.get("probe", None)
            domain_probe = attrs["domain"].probe
            if domain_edge_probe is None and domain_probe is None:
                raise serializers.ValidationError({"probe": [_("\"Probe increment\" or \"Probe scaling factor\" are required Probe configuration")]})

        return attrs


class SubDomainVipSerializer(serializers.ModelSerializer):
    vip_name = serializers.RelatedField(source="vip", read_only=True)
    probe_name = serializers.RelatedField(source="probe", read_only=True)

    class Meta:
        model = DomainVip
        fields = ("domain_vip_id",
                  "vip",
                  "vip_name",
                  "probe",
                  "probe_name",
                  "probe_increment",
                  "probe_scaling_factor",
                  "weight",
                  "priority",)

    def validate(self, attrs):
        probe_increment = attrs.get("probe_increment", None)
        probe_scaling_factor = attrs.get("probe_scaling_factor", None)

        if probe_increment is not None or probe_scaling_factor is not None:
            domain_probe = attrs.get("probe", None)
            if domain_probe is None:
                raise serializers.ValidationError({"probe": [_("\"Probe increment\" or \"Probe scaling factor\" are required Probe configuration")]})

        return attrs

class DomainEdgeSerializer(serializers.ModelSerializer):
    edge_name = serializers.RelatedField(source="edge", read_only=True)
    domain_name = serializers.RelatedField(source="domain", read_only=True)
    probe_name = serializers.RelatedField(source="probe", read_only=True)

    class Meta:
        model = DomainEdge
        fields = ("domain_edge_id",
                  "domain",
                  "domain_name",
                  "probe",
                  "probe_name",
                  "probe_increment",
                  "probe_scaling_factor",
                  "weight",
                  "priority",
                  "edge",
                  "edge_name")

    def validate(self, attrs):
        probe_increment = attrs.get("probe_increment", None)
        probe_scaling_factor = attrs.get("probe_scaling_factor", None)

        if probe_increment is not None or probe_scaling_factor is not None:
            domain_edge_probe = attrs.get("probe", None)
            domain_probe = attrs["domain"].probe
            if domain_edge_probe is None and domain_probe is None:
                raise serializers.ValidationError({"probe": [_("\"Probe increment\" or \"Probe scaling factor\" are required Probe configuration")]})

        return attrs


class DomainVipSerializer(serializers.ModelSerializer):
    vip_name = serializers.RelatedField(source="vip", read_only=True)
    domain_name = serializers.RelatedField(source="domain", read_only=True)
    probe_name = serializers.RelatedField(source="probe", read_only=True)

    class Meta:
        model = DomainVip
        fields = ("domain_vip_id",
                  "vip",
                  "domain",
                  "domain_name",
                  "vip_name",
                  "probe",
                  "probe_name",
                  "probe_increment",
                  "probe_scaling_factor",
                  "weight",
                  "priority",)

    def validate(self, attrs):
        probe_increment = attrs.get("probe_increment", None)
        probe_scaling_factor = attrs.get("probe_scaling_factor", None)

        if probe_increment is not None or probe_scaling_factor is not None:
            domain_vip_probe = attrs.get("probe", None)
            domain_probe = attrs["domain"].probe
            if domain_vip_probe is None and domain_probe is None:
                raise serializers.ValidationError({"probe": [_("\"Probe increment\" or \"Probe scaling factor\" are required Probe configuration")]})

        return attrs

    def validate_priority(self, attrs, source):
        value = attrs[source]
        if type(value) is int and value < 1 :
            raise serializers.ValidationError({"probe": [_("Priority value is invalid ( allow : 1 ~ )" )]})

        return attrs


class SubDomainStaticRuleActionSerializer(serializers.ModelSerializer):
    sequence = serializers.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(4294967295)],)

    class Meta:
        model = DomainStaticRuleAction
        fields = ("domain_staticrule_action_id",
                  "action",
                  "sequence",)

    def get_identity(self, data):
        try:
            return data.get('domain_staticrule_action_id', None)
        except AttributeError:
            return None

    def validate_action(self, attrs, source):
        try:
            is_valid, exception_msg = validate_static_rule(attrs[source], False)
            if not is_valid:
                raise serializers.ValidationError(exception_msg)
        except:
            pass

        return attrs


class SubDomainStaticRuleConditionSerializer(serializers.ModelSerializer):
    domainstaticruleactions = SubDomainStaticRuleActionSerializer(
        many=True, source="domainstaticruleaction_set", required=True, allow_add_remove=True)
    policy_name = serializers.CharField(required=False)
    sequence = serializers.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(4294967295)],)

    class Meta:
        model = DomainStaticRuleCondition
        fields = ("domain_staticrule_condition_id",
                  "sequence",
                  "condition",
                  "policy_name",
                  "is_enabled",
                  "invert",
                  "domainstaticruleactions")

    def get_identity(self, data):
        try:
            return data.get("domain_staticrule_condition_id", None)
        except AttributeError:
            return None

    def validate_condition(self, attrs, source):
        try:
            is_valid, exception_msg = validate_static_rule(attrs[source], True)
            if not is_valid:
                raise serializers.ValidationError(exception_msg)
        except:
            pass

        return attrs


class DomainStaticRuleActionSerializer(serializers.ModelSerializer):
    sequence = serializers.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(4294967295)],)

    class Meta:
        model = DomainStaticRuleAction
        fields = ("domain_staticrule_action_id",
                  "action",
                  "sequence",)

    def get_identity(self, data):
        try:
            return data.get('domain_staticrule_action_id', None)
        except AttributeError:
            return None

    def validate_action(self, attrs, source):
        try:
            is_valid, exception_msg = validate_static_rule(attrs[source], False)
            if not is_valid:
                raise serializers.ValidationError(exception_msg)
        except:
            pass

        return attrs


class DomainStaticRuleConditionSerializer(serializers.ModelSerializer):
    domainstaticruleactions = SubDomainStaticRuleActionSerializer(
        many=True, source="domainstaticruleaction_set", required=True, allow_add_remove=True)
    policy_name = serializers.CharField(required=False)
    sequence = serializers.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(4294967295)],)

    class Meta:
        model = DomainStaticRuleCondition
        fields = ("domain_staticrule_condition_id",
                  "domain",
                  "sequence",
                  "condition",
                  "policy_name",
                  "is_enabled",
                  "invert",
                  "domainstaticruleactions",)

    def get_identity(self, data):
        try:
            return data.get("domain_staticrule_condition_id", None)
        except AttributeError:
            return None

class DomainSerializer(serializers.ModelSerializer):
    probe_increment = serializers.FloatField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_PROBE_METRIC_INC
    )
    probe_scaling_factor = serializers.FloatField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_PROBE_METRIC_SC
    )
    delay_start_time = serializers.IntegerField(
        required=False,
        validators=[MinValueValidator(1), MaxValueValidator(172800)],
        help_text=H_DELAY_START_TIME
    )
    slowstart_period = serializers.IntegerField(
        required=False,
        validators=[MaxValueValidator(4294967295)],
        help_text=H_SLOWSTART_PERIOD
    )
    answer_count = serializers.IntegerField(
        required=False,
        validators=[MinValueValidator(1), MaxValueValidator(30)],
        help_text=H_ANSWER_COUNT
    )
    answer_ttl = serializers.IntegerField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_ANSWER_TTL
    )
    cutoff = serializers.FloatField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_CUT_OFF
    )
    tolerance = serializers.FloatField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_TOLERANCE
    )
    fallback_percent = serializers.IntegerField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        help_text=H_PERCENT
    )
    fallback_count = serializers.IntegerField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_COUNT
    )
    cost_scaling_factor = serializers.FloatField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_COST_FACTOR)

    uplink_scaling_factor = serializers.FloatField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_UPLINK_FACTOR)
    rtt_upperbound = serializers.FloatField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_UPPERBOUND)
    rtt_lowerbound = serializers.FloatField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_LOWERBOUND)
    geoip_default = serializers.FloatField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_GEOIP_DEFAULT)
    geoip_continent = serializers.FloatField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_GEOIP_CONTINENT)
    geoip_country = serializers.FloatField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_COUNTRY)
    geoip_region = serializers.FloatField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_REGION)
    geoip_state = serializers.FloatField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_STATE)
    geoip_city = serializers.FloatField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_CITY)
    geoip_isp = serializers.FloatField(
        required=False,
        validators=[MinValueValidator(0.0), MaxValueValidator(1.0)],
        help_text=H_ISP)
    geoip_asn = serializers.FloatField(
        required=False,
        validators=[MinValueValidator(0.0), MaxValueValidator(1.0)],
        help_text=H_ASN)
    distance_scaling_factor = serializers.FloatField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)],
        help_text=H_SCALING_FACTOR)

    customer_name = serializers.RelatedField(source="customer", read_only=True)
    domainvips = SubDomainVipSerializer(many=True, source="domainvip_set", required=False)
    domainedges = SubDomainEdgeSerializer(many=True, source="domainedge_set", required=False)
    domainstaticruleconditions = SubDomainStaticRuleConditionSerializer(source="domainstaticrulecondition_set",
                                                required=False, many=True,
                                                allow_add_remove=True)
    domain_type_display = serializers.ChoiceField(source="get_domain_type_display", read_only=True)
    is_clb_domain = serializers.SerializerMethodField('get_is_clb_domain')
    is_valid = serializers.SerializerMethodField('get_is_valid')
    latest_updater = serializers.ChoiceField(source="latest_updater", read_only=True)
    load_balancing_type_display = serializers.RelatedField(source="get_load_balancing_type_display", read_only=True)
    probe_name = serializers.ChoiceField(source="probe", read_only=True)
    status_display = serializers.ChoiceField(source="get_status_display", read_only=True)

    class Meta:
        model = Domain
        fields = ("domain_id",
                  "name",
                  "vips",
                  "customer",
                  "customer_name",
                  "is_clb_domain",
                  "domain_type",
                  "domain_type_display",
                  "config_state",
                  "date_created",
                  "date_modified",
                  "backupanswer",
                  "system_ignore",
                  "parent_domain",
                  "is_admin",
                  "is_valid",
                  "status",
                  "status_display",
                  "time_deployed",
                  "clb_dns_zone",
                  "description",
                  "latest_updater",
                  "answer_count",
                  "answer_ttl",
                  "cost_scaling_factor",
                  "cutoff",
                  "distance_scaling_factor",
                  "enable_cname_latency",
                  "enable_edns_client_subnet",
                  "enable_gslb",
                  "enable_stat",
                  "enable_vcpdns",
                  "fallback_count",
                  "fallback_percent",
                  "geoip_asn",
                  "geoip_city",
                  "geoip_continent",
                  "geoip_country",
                  "geoip_default",
                  "geoip_isp",
                  "geoip_region",
                  "geoip_state",
                  "list_all",
                  "load_balancing_type",
                  "load_balancing_type_display",
                  "log_request",
                  "pktloss_ignore",
                  "probe",
                  "probe_name",
                  "probe_increment",
                  "probe_scaling_factor",
                  "rtt_lowerbound",
                  "rtt_upperbound",
                  "delay_start_time",
                  "slowstart_period",
                  "sticky",
                  "tolerance",
                  "uplink_ignore",
                  "uplink_scaling_factor",
                  "domainedges",
                  "domainvips",
                  "domainstaticruleconditions",)
        depth = 0

    def get_identity(self, data):
        try:
            return data.get('domain_id', None)
        except AttributeError:
            return None

    def get_is_valid(self, obj):
        try:
            if obj.is_valid_config():
                return 'ok'
            else:
                return ''
        except:
            return ''

    def get_is_clb_domain(self, obj):
        if obj.clb_dns_zone is None:
            return False
        else:
            return True

    def validate_domain_type(self, attrs, source):
        if attrs.get(source) == DOMAIN_ALIAS:
            raise serializers.ValidationError(
                _("You can not configured domain alias type. Please check GSLB Domain documents."))

        return attrs

    def validate(self, attrs):
        rtt_lowerbound = attrs.get("rtt_lowerbound", None)
        rtt_upperbound = attrs.get("rtt_upperbound", None)

        domain_probe = attrs.get("probe", None)
        probe_increment = attrs.get("probe_increment", None)
        probe_scaling_factor = attrs.get("probe_scaling_factor", None)

        if rtt_lowerbound > rtt_upperbound:
            raise serializers.ValidationError(
                {"rtt_lowerbound": [_("rtt_lowerbound can not greater than rtt_upperbound")]})

        if probe_increment is not None or probe_scaling_factor is not None:
            if domain_probe is None:
                raise serializers.ValidationError({"probe": [_("Missing \"Probe Metric > Probe\" configuration."\
                                                " \"Probe increment\" or \"Probe scaling factor\" are required Probe configuration")]})

        if domain_probe is None:
            # check related edge & vip has probe_matric
            domainvips = DomainVip.objects.filter(domain=self.object, probe__isnull=True)\
                                        .filter(Q(probe_increment__isnull=False)
                                                |Q(probe_scaling_factor__isnull=False))
            domainedges = DomainEdge.objects.filter(domain=self.object, probe__isnull=True)\
                                        .filter(Q(probe_increment__isnull=False)
                                                |Q(probe_scaling_factor__isnull=False))

            if domainedges.exists() or domainvips.exists():
                raise serializers.ValidationError({"probe": [_("Related Domain Vip or Domain Edge has \"Probe increment\" or \"Probe scaling factor\"."\
                                                                " You have to check Domain Edge/Domain Vip configuration.")]})

        return attrs

    def validate_delay_start_time(self, attrs, source):
        domain_probe = attrs.get("probe", None)
        delay_start_time = attrs.get(source, None)

        if domain_probe is None and delay_start_time is not None:
            raise serializers.ValidationError(
                _("If do not set the Probe, can not set the Delay start time."))

        return attrs

    def validate_slowstart_period(self, attrs, source):
        domain_probe = attrs.get("probe", None)
        slowstart_period = attrs.get(source, None)

        if domain_probe is None and slowstart_period is not None:
            raise serializers.ValidationError(
                _("If do not set the Probe, can not set the Slowstart period."))

        if domain_probe is not None and slowstart_period is not None and slowstart_period < 0:
            raise serializers.ValidationError(
                _("Ensure this value is greater than or equal to 0."))

        return attrs

class DomainDetailSerializer(DomainSerializer):
    related_mproxy_app = serializers.SerializerMethodField('get_mproxy_app')
    related_starfs = serializers.SerializerMethodField('get_starfs')
    clb_dns_zone_name = serializers.RelatedField(source="clb_dns_zone", read_only=True)
    monitoring_type = serializers.IntegerField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        help_text="Monitoring Type"
    )

    class Meta:
        model = Domain
        fields = ("domain_id",
                  "name",
                  "vips",
                  "customer",
                  "customer_name",
                  "is_clb_domain",
                  "domain_type",
                  "monitoring_type",
                  "domain_type_display",
                  "config_state",
                  "date_created",
                  "date_modified",
                  "backupanswer",
                  "system_ignore",
                  "parent_domain",
                  "is_admin",
                  "is_valid",
                  "status",
                  "status_display",
                  "time_deployed",
                  "clb_dns_zone",
                  "clb_dns_zone_name",
                  "description",
                  "latest_updater",
                  "answer_count",
                  "answer_ttl",
                  "cost_scaling_factor",
                  "cutoff",
                  "distance_scaling_factor",
                  "enable_cname_latency",
                  "enable_edns_client_subnet",
                  "enable_gslb",
                  "enable_stat",
                  "enable_vcpdns",
                  "fallback_count",
                  "fallback_percent",
                  "geoip_asn",
                  "geoip_city",
                  "geoip_continent",
                  "geoip_country",
                  "geoip_default",
                  "geoip_isp",
                  "geoip_region",
                  "geoip_state",
                  "list_all",
                  "load_balancing_type",
                  "load_balancing_type_display",
                  "log_request",
                  "pktloss_ignore",
                  "probe",
                  "probe_name",
                  "probe_increment",
                  "probe_scaling_factor",
                  "rtt_lowerbound",
                  "rtt_upperbound",
                  "delay_start_time",
                  "slowstart_period",
                  "sticky",
                  "tolerance",
                  "uplink_ignore",
                  "uplink_scaling_factor",
                  "domainedges",
                  "domainvips",
                  "domainstaticruleconditions",
                  "related_mproxy_app",
                  "mproxy_preset",
                  "related_starfs",)

    def get_mproxy_app(self, obj):
        return obj.get_related_mproxy()
    def get_starfs(self, obj):
        return obj.get_related_starfs()

class DomainAliasSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source="customer", read_only=True)
    origin_domain_name = serializers.RelatedField(source="domain", read_only=True)
    date_created = serializers.DateTimeField(read_only=True)
    date_modified = serializers.DateTimeField(read_only=True)
    latest_updater = serializers.CharField(read_only=True)

    class Meta:
        model = DomainAlias
        fields = ("domain_alias_id",
                  "name",
                  "domain",
                  "description",
                  "origin_domain_name",
                  "customer",
                  "customer_name",
                  "date_created",
                  "date_modified",
                  "latest_updater",)
        depth = 0

    def get_identity(self, data):
        try:
            return data.get('domain_alias_id', None)
        except AttributeError:
            return None


class DomainAllSerializer(serializers.ModelSerializer):
    customer_name = serializers.RelatedField(source="customer", read_only=True)
    domain_type_display = serializers.ChoiceField(source="get_domain_type_display", read_only=True)
    load_balancing_type_display = serializers.RelatedField(source="get_load_balancing_type_display", read_only=True)
    probe_name = serializers.ChoiceField(source="probe", read_only=True)

    class Meta:
        model = DomainAll
        depth = 0

    def transform_vip_count(self, obj, value):
        try:
            if value is not None:
                return int(value)
            else:
                return 0
        except:
            return 0

    def transform_edge_count(self, obj, value):
        try:
            if value is not None:
                return int(value)
            else:
                return 0
        except:
            return 0

class DomainDynamicRelaySerializer(serializers.ModelSerializer):
    class Meta:
        model = DomainDynamicRelay
        fields = ("dynamic_relay_id",
                  "domain",
                  "pop",
                  "obj_state")

