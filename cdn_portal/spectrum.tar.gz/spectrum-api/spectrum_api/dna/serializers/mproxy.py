from rest_framework import serializers
from django.core.validators import MaxValueValidator, MinValueValidator, \
    MaxLengthValidator, email_re
from django.utils.translation import ugettext as _

from spectrum_api.dna.models.mproxy import MproxyAlertManagement, MproxyAlertHistory, \
    ALERT_STATUS, THRESHOLD_TYPE
from spectrum_api.dna.models.domain import MproxyApp

class MproxyAlertManangemnetSerializer(serializers.ModelSerializer):
    alert_type_display = serializers.ChoiceField(source="get_alert_type_display", read_only=True)
    service_domain_name = serializers.RelatedField(source="stat_master", read_only=True)
    threshold_value = serializers.IntegerField(
        required=False,
        validators=[MinValueValidator(1), MaxValueValidator(4294967295)]
    )
    threshold_type_display = serializers.ChoiceField(source="get_threshold_type_display", read_only=True)
    alert_receiver = serializers.CharField(validators=[MaxLengthValidator(512)], required=False)
    is_deleted = serializers.SerializerMethodField("get_mproxy_app_delete_check")
    stat_id = serializers.RelatedField(source="stat_master.pk", read_only=True)

    class Meta:
        model = MproxyAlertManagement
        fields = ("alert_id",
                  "alert_type",
                  "alert_type_display",
                  "service_domain",
                  "service_domain_name",
                  "threshold_type",
                  "threshold_type_display",
                  "threshold_value",
                  "alert_receiver",
                  "account",
                  "stat_master",
                  "stat_id",
                  "obj_state",
                  "is_deleted")

    def get_mproxy_app_delete_check(self, obj):
        return obj.get_mproxy_app_delete_check()

    def validate_alert_receiver(self, attrs, source):
        value = attrs[source]
        if value:
            try:
                err = []
                range_val = value.split(",")
                for val in range_val:
                    val = val.strip()
                    if not email_re.match(val):
                        err.append(val)
                if len(err)>0:
                    raise serializers.ValidationError(_('%s is invalid email address.') % ','.join(err))
            except TypeError as e:
                raise serializers.ValidationError(_('%s is invalid email address.') % value)
            except Exception as e:
                raise e
        else:
            raise serializers.ValidationError(_('This field is required.'))
        return attrs

    def validate_threshold_value(self, attrs, source):
        value = attrs[source]
        if value:
            int_value = int(value)
            if int_value < 1:
                raise serializers.ValidationError(_('threshold_value is invalid.'))
            else:
                alert_type = int(attrs.get("alert_type"))
                threshold_type = int(attrs.get("threshold_type"))
                # threshold_type == 1(Dynamic)
                if alert_type and threshold_type and threshold_type==1:
                    if alert_type==2 or alert_type==3 or alert_type==5:
                        if int_value < 30 or int_value > 100:
                            raise serializers.ValidationError(_('Invalid Threshold Value(allow : 30~100).'))
                    else:
                        if int_value < 200:
                            raise serializers.ValidationError(_('Invalid Threshold Value(allow : 200~).'))
        else:
            raise serializers.ValidationError(_('This field is required.'))
        return attrs

class AlertMproxyAppSimpleSerializer(serializers.ModelSerializer):
    account = serializers.RelatedField(source="customer.account.account_no", read_only=True)

    class Meta:
        model = MproxyApp
        fields = ("mproxy_app_id",
                  "mproxy_app_name",
                  "customer",
                  "account")

class MproxyAlertHistorySerializer(serializers.ModelSerializer):
    alert_type_display = serializers.ChoiceField(source="get_alert_type_display")
    account = serializers.RelatedField(source="alert.account.account_no", read_only=True)

    class Meta:
        model = MproxyAlertHistory
        fields = ("alert",
                  "statmaster",
                  "service_domain",
                  "alert_type",
                  "alert_type_display",
                  "fail_message",
                  "update_time",
                  "account")
