import json
import unittest
from django.contrib.auth.models import User
from rest_framework.test import APIClient

from spectrum_api.dna.models.mproxy import MproxyAlertManagement


class MproxyAlertManagementTest(unittest.TestCase):

    def setUp(self):
        user = User.objects.get(username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=user)

    def test(self):
        response = self.client.get('/api/mproxy_monitoring/alert_management/')

        # response status code should be 200
        self.assertEqual(response.status_code, 200)

        response_dict = json.loads(response.content)

        api_alert_managements = response_dict.get('count')
        db_alert_managements = MproxyAlertManagement.objects.all()

        # response alert management list count = db alert management list count
        self.assertEqual(api_alert_managements, db_alert_managements.count())
