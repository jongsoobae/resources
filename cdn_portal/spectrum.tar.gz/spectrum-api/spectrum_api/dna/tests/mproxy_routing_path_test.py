from django.contrib.auth.models import User
from rest_framework import status
from rest_framework.test import APIClient

from django.utils import unittest
from spectrum_api.dna.models.domain import MproxyApp
from spectrum_api.dna.models.mproxy import MproxyDomainEdge

import random

__author__ = 'root'


class MproxyAppsMonitorTests(unittest.TestCase):
    def setUp(self):
        user = User.objects.get(username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=user)

    def tearDown(self):
        pass

    def test(self):
        mproxy_app_id = 164
        select_url = '/api/mproxy_apps/' + str(mproxy_app_id) + '/monitor/'
        data = {}

        response = self.client.get(select_url, data, format='json')
        self.mproxy_app_id = response.data['mproxy_app_id']

        db_mproxy_app = MproxyApp.objects.get(pk=self.mproxy_app_id)

        self.assertEqual(status.HTTP_200_OK, response.status_code)
        self.assertEqual(self.mproxy_app_id, db_mproxy_app.pk)

        mproxy_app_data = response.data['services'][0]

        self.assertTrue(len(mproxy_app_data) > 0)
        self.assertTrue("mproxy_preset_id" in mproxy_app_data)

    def assertEqual(self, first, second, msg=None):
        super(MproxyAppsMonitorTests, self).assertEqual(str(first), str(second), msg)

class MproxyRoutingPathCallTests(unittest.TestCase):
    def setUp(self):
        user = User.objects.get(username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=user)

    def tearDown(self):
        pass

    def test(self):
        # dynamic_relay
        insert_url = '/api/mproxy_edge/406/relay_route/'
        data = {
            "edge_pop_code": 'P11-FRA'
        }

        response = self.client.get(insert_url, data, format='json')
        self.mproxy_edge_id = response.data['mproxy_edge_id']

        db_mproxy_edge = MproxyDomainEdge.objects.get(pk=self.mproxy_edge_id)

        self.assertEqual(status.HTTP_200_OK, response.status_code)
        self.assertEqual(self.mproxy_edge_id, db_mproxy_edge.pk)

        self.assertEqual(18, len(response.data))
        self.assertTrue("relay_pop_code" in response.data)
        self.assertTrue(len(response.data['relay_pop_code']) > 0)
        self.assertTrue("relay_pop_city" in response.data)
        self.assertTrue(len(response.data['relay_pop_city']) > 0)
        self.assertTrue("relay_pop_status" in response.data)
        self.assertTrue(len(response.data['relay_pop_status']) > 0)
        self.assertTrue("mproxy_preset_id" in response.data)

        # not dynamic_relay
        insert_url = '/api/mproxy_edge/214/relay_route/'
        data = {
            "edge_pop_code": 'P12-SJC'
        }

        response = self.client.get(insert_url, data, format='json')
        self.mproxy_edge_id = response.data['mproxy_edge_id']

        db_mproxy_edge = MproxyDomainEdge.objects.get(pk=self.mproxy_edge_id)

        self.assertEqual(status.HTTP_200_OK, response.status_code)
        self.assertEqual(self.mproxy_edge_id, db_mproxy_edge.pk)

        self.assertEqual(16, len(response.data))
        self.assertEqual([], response.data['relay_pop_code'])
        self.assertTrue("mproxy_preset_id" in response.data)
        self.assertEqual(None, response.data['mproxy_preset_id'])

    def assertEqual(self, first, second, msg=None):
        super(MproxyRoutingPathCallTests, self).assertEqual(str(first), str(second), msg)

