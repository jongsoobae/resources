# -*- coding: utf-8 -*-

from django.conf.urls.defaults import patterns, url
from rest_framework.urlpatterns import format_suffix_patterns

from spectrum_api.dna.views.domain import DomainAPI, DomainDetailAPI, DomainStaticRuleConditionAPI, \
                                        DomainStaticRuleConditionDetailAPI, \
                                        DomainCustomerAPI, DomainTypeAPI, DomainAllAPI, \
                                        DomainEdgeAPI, DomainEdgeDetailAPI, DomainVipAPI, DomainVipDetailAPI, \
                                        DomainSubVipAPI, DomainRelatedItemAPI, DomainAliasAPI, DomainAliasDetailAPI, DomainStaticRuleConditionSwapAPI, \
                                        DomainStaticRuleConditionSeqUpAPI, DomainStaticRuleConditionSeqDownAPI, DomainAdminModeHandleAPI,\
                                        DomainStaticRuleValidateAPI,DomainStaticRuleImportAPI, \
                                        DomainRelayPopsAPI, DomainPresetRelayAPI

from spectrum_api.dna.views.mproxy import DynamicRelayPopsAPI, MproxyAlertManagementAPI, \
                                        MproxyAlertManangementDetailAPI, AlertMproxyAppSimpleAPI, MproxyAlertHistoryAPI, \
                                        MproxyEdgeRelayRouteAPI,MproxyAppRelayRouteAPI, MproxyAppsMonitorAPI, \
                                        AlertMproxyAppStatSimpleAPI



restfw_api_urlpatterns = patterns('spectrum_api.dna.views',

	url(r'^domainsall/$', DomainAllAPI.as_view(), name="domains"),
    url(r'^domains/$', DomainAPI.as_view(), name="domains"),
    url(r'^domains/(?P<domain_id>[0-9]+)/$', DomainDetailAPI.as_view(), name="domain-detail"),
    url(r'^domains/(?P<domain_id>[0-9]+)/adminmode/$', DomainAdminModeHandleAPI.as_view(), name="domain-adminmode"),
    url(r'^domains/(?P<domain_id>[0-9]+)/related_vips/$', DomainSubVipAPI.as_view(), name="domain-related-vips"),
    url(r'^domains/(?P<domain_id>[0-9]+)/related_objects/$', DomainRelatedItemAPI.as_view(), name="domain-related-object"),

    url(r'^domains/(?P<domain_id>[0-9]+)/conditions/$', DomainStaticRuleConditionAPI.as_view(), name="domainstaticrules"),
    url(r'^domains/(?P<domain_id>[0-9]+)/conditions/(?P<domain_staticrule_condition_id>[0-9]+)/$', DomainStaticRuleConditionDetailAPI.as_view(), name="domainstaticrule-detail"),
    url(r'^domains/(?P<domain_id>[0-9]+)/conditions/(?P<domain_staticrule_condition_id>[0-9]+)/moveup/$', DomainStaticRuleConditionSeqUpAPI.as_view(), name="domainstaticrule-swap"),
    url(r'^domains/(?P<domain_id>[0-9]+)/conditions/(?P<domain_staticrule_condition_id>[0-9]+)/movedown/$', DomainStaticRuleConditionSeqDownAPI.as_view(), name="domainstaticrule-swap"),
    url(r'^domains/(?P<domain_id>[0-9]+)/conditions/swap/$', DomainStaticRuleConditionSwapAPI.as_view(), name="domainstaticrule-swap"),
    url(r'^domains/(?P<domain_id>[0-9]+)/conditions/import/$', DomainStaticRuleImportAPI.as_view(), name="domainstaticrule-import"),


    # url(r'^domains/(?P<domain_id>[0-9]+)/conditions/(?P<domain_staticrule_condition_id>[0-9]+)/actions/$', DomainStaticRuleActionAPI.as_view(), name="domainstaticruleactions"),
    # url(r'^domains/(?P<domain_id>[0-9]+)/conditions/(?P<domain_staticrule_condition_id>[0-9]+)/actions/(?P<domain_staticrule_action_id>[0-9]+)/$', DomainStaticRuleActionDetailAPI.as_view(), name="domainstaticruleaction-detail"),

   	url(r'^domainaliase/$', DomainAliasAPI.as_view(), name="domainaliases"),
    url(r'^domainaliase/(?P<domain_alias_id>[0-9]+)/$', DomainAliasDetailAPI.as_view(), name="domainalias-detail"),

    url(r'^validate_staticrule/$', DomainStaticRuleValidateAPI.as_view(), name="domainstaticrule-validate"),

    # Domain Edge
    url(r'^domains/(?P<domain_id>[0-9]+)/edges/$', DomainEdgeAPI.as_view(), name="domain_subedges"),
    url(r'^domains/(?P<domain_id>[0-9]+)/edges/(?P<domain_edge_id>[0-9]+)/$', DomainEdgeDetailAPI.as_view(), name="domain_subedges-detail"),
    # Domain Vips
    url(r'^domains/(?P<domain_id>[0-9]+)/vips/$', DomainVipAPI.as_view(), name="domain-subvips"),
    url(r'^domains/(?P<domain_id>[0-9]+)/vips/(?P<domain_vip_id>[0-9]+)/$', DomainVipDetailAPI.as_view(), name="domain-subvips-detail"),
    # Non-related
    # Domain Edge
    url(r'^domains_edges/$', DomainEdgeAPI.as_view(), name="domainedges"),
    url(r'^domains_edges/(?P<domain_edge_id>[0-9]+)/$', DomainEdgeDetailAPI.as_view(), name="domainedge-detail"),
    # Domain Vips
    url(r'^domains_vips/$', DomainVipAPI.as_view(), name="domainvips"),
    url(r'^domains_vips/(?P<domain_vip_id>[0-9]+)/$', DomainVipDetailAPI.as_view(), name="domainvip-detail"),

    # domain misc function
    url(r'^domains_customers/$', DomainCustomerAPI.as_view(), name="domain_customers"),
    url(r'^domains_types/$', DomainTypeAPI.as_view(), name="domains_types"),

    # Mproxy Edge
    url(r'^mproxy_edges/dynamic_relay/$', DynamicRelayPopsAPI.as_view(), name="dynamic_relay_pops"),
    url(r'^mproxy_edge/(?P<mproxy_edge_id>[0-9]+)/relay_route/$', MproxyEdgeRelayRouteAPI.as_view(), name="mproxy_edge_relay_route_pops"),
    url(r'^mproxy_app/(?P<mproxy_app_id>[0-9]+)/relay_route/$', MproxyAppRelayRouteAPI.as_view(), name="mproxy_app_relay_route_pops"),
    url(r'^domains/(?P<domain_id>[0-9]+)/dynamic_relay/$', DomainRelayPopsAPI.as_view(), name="domain_relay_pops"),

    # Mproxy Monitoring
    url(r'^mproxy_monitoring/alert_management/$', MproxyAlertManagementAPI.as_view(), name="mproxy_alert_manangement"),
    url(r'^mproxy_monitoring/alert_management/(?P<alert_id>[0-9]+)$', MproxyAlertManangementDetailAPI.as_view(), name="mproxy_alert_manangement_detail"),
    url(r'^mproxy_monitoring/mproxy_app/$', AlertMproxyAppSimpleAPI.as_view(), name="alert_mproxy_app_list"),
    url(r'^mproxy_monitoring/mproxy_app/stat/$', AlertMproxyAppStatSimpleAPI.as_view(), name="alert_mproxy_app_stat_list"),
    url(r'^mproxy_monitoring/alert_history/$', MproxyAlertHistoryAPI.as_view(), name="alert_mproxy_history"),
    url(r'^mproxy_apps/(?P<mproxy_app_id>[0-9]+)/monitor/$', MproxyAppsMonitorAPI.as_view(), name="mproxy_apps_monitor"),

    # Mproxy Pre-set Relay
    url(r'^domains/(?P<domain_id>[0-9]+)/preset_relay/$', DomainPresetRelayAPI.as_view(), name="domain_preset_relays"),
)
urlpatterns = format_suffix_patterns(restfw_api_urlpatterns)
