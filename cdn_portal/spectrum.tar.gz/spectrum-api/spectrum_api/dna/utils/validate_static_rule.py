#!/usr/bin/python

import re
from string import *

class struct(object):
    def __init__(self, *args, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)

CONDITION_VALIDATOR_LIST = [
	struct(
		errmsg = 'Condition statement must either be "always" or start with "client." or "request."',
		regex = '^((\s*always\s*$)|(\s*client\.)|(\s*request\.))',
	),
	struct(
		errmsg = 'If condition statement starts with "client.", all lines must be like "client.(ip|continent|country|region|state|city|isp|asn) = (comma separated values)"',
		regex = '^((?!\s*client\.)|((\s*client\.(ip|continent|country|region|state|city|isp|asn)[ \\t]*=[ \\t]*([^, \\t\\n]+[ \\t]*)+(,[ \\t]*[^, \\t\\n]+([ \\t]+[^, \\t\\n]+)*[ \\t]*)*(\\r?\\n|$))+\s*$))',
	),
	struct(
		errmsg = 'A "client.ip" line in condition statement must be like "client.ip = (comma separated IP ranges)"',
		regex = '^(((?!\s*client\.ip)[^\\n]*|(\s*client\.ip[ \\t]*=[ \\t]*\d{1,3}(\.\d{1,3}){0,3}[ \\t]*([-/\d\.]+[ \\t]*)+(,[ \\t]*\d{1,3}(\.\d{1,3}){0,3}[ \\t]*([-/\d\.]+[ \\t]*)+)*))(\\r?\\n|$))+\s*$',
	),
	struct(
		errmsg = 'If condition statement starts with "request.", it must be a single line of "request.portion = (number)" format',
		regex = '^((?!\s*request\.)|((\s*request\.portion[ \\t]*=[ \\t]*\d+\.?\d*\s*)$))',
	),
]

ACTION_VALIDATOR_LIST = [
	struct(
		errmsg = 'Action statement must either be "ignore" or start with "system." or "response."',
		regex = '^((\s*ignore\s*$)|(\s*system\.)|(\s*response\.))',
	),
	struct(
		errmsg = 'If action statement starts with "system.", all lines must be "system.(something)" or "restriction" or "load_balancing_type" with some values',
		regex = '^((?!\s*system\.)|((\s*(system\.[a-zA-Z_]+|restriction|load_balancing_type)[ \\t]*=[ \\t]*([^ \\t\\n]+[ \\t]*)+(\\r?\\n|$))+\s*$))',
	),
	struct(
		errmsg = 'A "system." line in action statement must be like "system.(pop_group|edge|pop|vip) = (comma separated values)"',
		regex = '^(((?!\s*system\.)[^\\n]*|(\s*system\.(pop_group|edge|pop|vip)[ \\t]*=[ \\t]*([^, \\t\\n]+[ \\t]*)+(,[ \\t]*[^, \\t\\n]+([ \\t]+[^, \\t\\n]+)*[ \\t]*)*))(\\r?\\n|$))+\s*$',
	),
	struct(
		errmsg = 'A "system.vip" line in action statement must be like "system.vip = (comma separated IP ranges)"',
		regex = '^(((?!\s*system\.vip)[^\\n]*|(\s*system\.vip[ \\t]*=[ \\t]*\d{1,3}(\.\d{1,3}){0,3}[ \\t]*([-/\d\.]+[ \\t]*)+(,[ \\t]*\d{1,3}(\.\d{1,3}){0,3}[ \\t]*([-/\d\.]+[ \\t]*)+)*))(\\r?\\n|$))+\s*$',
	),
	struct(
		errmsg = 'A "restriction" line in action statement must take a value of STRICT or GLOBAL (case insensitive)',
		regex = '^(((?!\s*restriction)[^\\n]*|(\s*restriction[ \\t]*=[ \\t]*([Ss][Tt][Rr][Ii][Cc][Tt]|[Gg][Ll][Oo][Bb][Aa][Ll])[ \\t]*))(\\r?\\n|$))+\s*$',
	),
	struct(
		errmsg = 'A "load_balancing_type" line in action statement must take a value of GSLB or RANDOM or RR (case insensitive)',
		regex = '^(((?!\s*load_balancing_type)[^\\n]*|(\s*load_balancing_type[ \\t]*=[ \\t]*([Gg][Ss][Ll][Bb]|[Rr][Aa][Nn][Dd][Oo][Mm]|[Rr][Rr])[ \\t]*))(\\r?\\n|$))+\s*$',
	),
	struct(
		errmsg = 'If action statement starts with "response.", all lines must be like "response.answer = (something)" or "follow_cname = (something)"',
		regex = '^((?!\s*response\.)|((\s*(response\.answer|follow_cname)[ \\t]*=[ \\t]*([^ \\t\\n]+[ \\t]*)+(\\r?\\n|$))+\s*$))',
	),
	struct(
		errmsg = 'A "response.answer" in answer statement must take three comma separated values',
		regex = '^(((?!\s*response\.answer)[^\\n]*|(\s*response\.answer[ \\t]*=[ \\t]*[a-zA-Z_]+[ \\t]*,[ \\t]*\d+[ \\t]*,[ \\t]*[^, \\t\\n]+([ \\t]+[^, \\t\\n]+)*[ \\t]*))(\\r?\\n|$))+\s*$',
	),
	struct(
		errmsg = 'If action statement starts with "response.answer = A,", all lines must start with "response.answer = A," and the last value must be an IP address',
		regex = '^((?!\s*response\.answer[ \\t]*=[ \\t]*[Aa][ \\t]*,)|((\s*response\.answer[ \\t]*=[ \\t]*[Aa][ \\t]*,[ \\t]*\d+[ \\t]*,[ \\t]*\d{1,3}(\.\d{1,3}){3,3}[ \\t]*(\\r?\\n|$))+\s*$))',
	),
	struct(
		errmsg = 'If action statement starts with "response.answer = CNAME,", only an optional line starting with "follow_cname" can follow',
		regex = '^((?!\s*response\.answer[ \\t]*=[ \\t]*[Cc][Nn][Aa][Mm][Ee][ \\t]*,)|(\s*[^\\n]+(\\n\s*follow_cname[^\\n]+)?\s*$))',
	),
	struct(
		errmsg = 'A "response.answer = CNAME" in answer statement must take third value as a consecutive string',
		regex = '^(((?!\s*response\.answer[ \\t]*=[ \\t]*[Cc][Nn][Aa][Mm][Ee][ \\t]*,)[^\\n]*|(\s*response\.answer[ \\t]*=([ \\t]*[^, \\t\\n]+[ \\t]*,){2,2}[ \\t]*[^, \\t\\n]+[ \\t]*))(\\r?\\n|$))+\s*$',
	),
	struct(
		errmsg = 'A "follow_cname" line in answer statement must take a value of TRUE or FALSE (case insensitive)',
		regex = '^(((?!\s*follow_cname)[^\\n]*|(\s*follow_cname[ \\t]*=[ \\t]*([Tt][Rr][Uu][Ee]|[Ff][Aa][Ll][Ss][Ee])[ \\t]*))(\\r?\\n|$))+\s*$',
	),
]

def validate_static_rule(text, is_condition):
	if is_condition:
		validator_list = CONDITION_VALIDATOR_LIST
	else:
		validator_list = ACTION_VALIDATOR_LIST

	for validator in validator_list:
		re_res = re.match(validator.regex, text)
		if re_res == None:
			return False, validator.errmsg

	return True, None
