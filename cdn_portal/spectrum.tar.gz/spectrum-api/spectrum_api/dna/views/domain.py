# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Domain Rest API
"""
from __future__ import absolute_import
import logging
from django.shortcuts import get_list_or_404
from django.db import transaction, connections
from django.utils.translation import ugettext as _
from django.utils.xmlutils import SimplerXMLGenerator
from rest_framework.compat import StringIO
from rest_framework.generics import get_object_or_404
from rest_framework.settings import api_settings
from rest_framework.exceptions import APIException, ParseError
from rest_framework import renderers
from rest_framework.response import Response
from rest_framework.status import HTTP_404_NOT_FOUND, HTTP_400_BAD_REQUEST, \
    HTTP_406_NOT_ACCEPTABLE, HTTP_202_ACCEPTED, HTTP_304_NOT_MODIFIED, HTTP_403_FORBIDDEN
from rest_framework.views import APIView

from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.mixins import CreateModelMixin, UpdateModelMixin, DestroyModelMixin, \
    ListModelMixin, RetrieveModelMixin
from spectrum_api.shared_components.models.customer import CustomerDisplay

from spectrum_api.dna.models import DOMAIN_ALIAS
from spectrum_api.dna.models.domain import DomainAll, Domain, DomainStaticRuleCondition, \
    DomainStaticRuleAction, DomainEdge, DomainVip, DomainAlias, DOMAIN_TYPE, \
    DomainDynamicRelay
from spectrum_api.configuration.models.base import Pop
from spectrum_api.dna.serializers.domain import DomainSerializer, DomainStaticRuleConditionSerializer, DomainStaticRuleActionSerializer, \
    DomainEdgeSerializer, DomainVipSerializer, DomainAliasSerializer, DomainAllSerializer, DomainDetailSerializer, \
    DomainDynamicRelaySerializer
from spectrum_api.dna.utils.validate_static_rule import validate_static_rule

from spectrum_api.configuration.models.preset_relay import MproxyPreset

log = logging.getLogger(__name__)

class AccessInvalidDomainID(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = _(u'Domain ID Missing')


class DomainDoseNotExist(APIException):
    status_code = HTTP_404_NOT_FOUND
    default_detail = _(u'You access does not exists Domain')


class DomainStaticRuleDoseNotExist(APIException):
    status_code = HTTP_404_NOT_FOUND
    default_detail = _(u'You access does not exists Domain Static rule condition')


class DomainStaticRuleNotModified(APIException):
    status_code = HTTP_304_NOT_MODIFIED
    default_detail = _(u'This static rule is not modified')


class NotAcceptableException(APIException):
    status_code = HTTP_406_NOT_ACCEPTABLE
    default_detail = _(u'Request not acceptable')

class NotDeletableDomain(APIException):
    status_code = HTTP_403_FORBIDDEN
    default_detail = _(u'This domain is not deletable')

class isMproxyEdge(APIException):
    status_code = HTTP_403_FORBIDDEN
    default_detail = _(u"You can not delete this domain edge. because this domain edge is configured in MproxyApp")

class MissingStaticRuleAction(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = _(u'You missed input domain static rule action')

def domain_probe_auto_mapping(request, obj):
    try:
        is_valid, check_message = obj.check_probe_constraint(request,
                                        required_probe=obj.probe,
                                        force_update=True)
    except Exception as e:
        log.error(e)
        is_valid = False
        check_message = "%s"%(e)

    return is_valid, check_message

def domain_node_probe_auto_mapping(request, obj):
    try:
        if obj.probe:
            probe = obj.probe
        elif obj.domain.probe:
            probe = obj.domain.probe
        else:
            probe = None

        if probe is not None:
            is_valid, check_message = obj.domain.check_probe_constraint(request,
                                            required_probe=probe,
                                            force_update=True)
    except Exception as e:
        log.error(e)
        is_valid = False
        check_message = "%s"%(e)
    else:
        is_valid = False
        check_message = None

    return is_valid, check_message

def get_domain_dynamic_relay(pop_list):
    relay_info = {}

    if len(pop_list) <= 0:
        return pop_list

    sql = """
            select distinct
                bp.pop_id AS pop_id,
                if(isnull(bp.ihms_pop_id), bp.pop_name, ihp.pop_code) AS pop_name,
                ihc.country_id AS country_id,
                ihc.country_name AS country_name,
                if(isnull(bp.enable_gslb), 0, 1) AS pop_enable_gslb,
                count(mvs.vip_id) as avaliable_count,
                count(h.host_id) as total_count
            from
                prism.base_vip v
                left join prism.mproxy_vip_status mvs on (v.vip_id = mvs.vip_id and mvs.vip_status in (0, 1))
                left join prism.base_vip_probe bvp ON v.vip_id = bvp.vip_id
                join prism.base_host h on v.host_id = h.host_id
                join prism.base_host_role rh ON h.host_id = rh.host_id
                join prism.base_role r ON rh.role_id = r.role_id
                join prism.base_system s ON h.system_id = s.system_id
                join prism.base_pop bp ON s.pop_id = bp.pop_id
                left join prism.ihms_pop ihp ON bp.ihms_pop_id = ihp.pop_id
                left join prism.ihms_pop_info ihi ON ihi.pop_id = ihp.pop_id
                left join prism.ihms_country ihc ON ihc.country_id = ihi.country_id
            where r.role_name = 'MPROXY'
                and bvp.probe_id = 29
                and bp.pop_id in (%s)
            group by bp.pop_id
            order by ihc.country_name, ihp.pop_code, bp.pop_name
            """
    format_strings = ','.join(map(lambda x: '%s', pop_list))
    sql = sql % (format_strings)
    params = []
    params.extend(pop_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, tuple(params))
    rs = cursor.fetchall()

    for obj in rs:
        relay_info[obj[0]] = {"pop":obj[0],
                            "pop_name":obj[1],
                            "country_id":obj[2],
                            "country_name":obj[3],
                            "pop_enable_gslb":obj[4],
                            "avaliable_count":obj[5],
                            "total_count":obj[6]
                            }

    return relay_info

@transaction.commit_on_success
def move_phases_sequence(request, condition, up=True):
    if up:
        conditions = DomainStaticRuleCondition.objects.filter(
            domain=condition.domain,
            sequence__lt=condition.sequence).order_by('-sequence',)
    else:
        conditions = DomainStaticRuleCondition.objects.filter(
            domain=condition.domain,
            sequence__gt=condition.sequence).order_by('sequence',)
    if condition and conditions[0]:
        old_sequence = condition.sequence
        swap_phase = conditions[0]
        new_sequence = swap_phase.sequence
        swap_phase.sequence = -1
        swap_phase.save(request=request)
        condition.sequence = new_sequence
        condition.save(request=request)
        swap_phase.sequence = old_sequence
        swap_phase.save(request=request)


class DomainTextRenderer(renderers.BaseRenderer):
    media_type = 'text/plain'
    format = 'plain'
    charset = 'utf-8'

    def render(self, data, media_type=None, renderer_context=None):
        domainedges = [str(edge.get("edge_name")) for edge in data["domainedges"]]
        domainvips = [str(vip.get("vip_name")) for vip in data["domainvips"]]
        domainstaticruleconditions = [{"condition": str(r.get("condition")),
                                       "invert": r.get("invert"),
                                       "action": [str(ar.get("action")) for ar in r.get("domainstaticruleactions")]}
                                      for r in data["domainstaticruleconditions"]]
        data["domainvips"] = domainvips
        data["domainedges"] = domainedges
        data["domainstaticruleconditions"] = domainstaticruleconditions
        template_string = """Domain Name: %(name)s
Customer : %(customer_name)s
Answer TTL : %(answer_ttl)s
Answer Count : %(answer_count)s
Probe : %(probe_name)s
domain_type_display : %(domain_type_display)s
description : %(description)s

backupanswer : %(backupanswer)s
config_state : %(config_state)s
cost_scaling_factor: %(cost_scaling_factor)s
cutoff : %(cutoff)s
distance_scaling_factor : %(distance_scaling_factor)s
enable_cname_latency : %(enable_cname_latency)s
enable_edns_client_subnet: %(enable_edns_client_subnet)s
enable_gslb : %(enable_gslb)s
enable_stat : %(enable_stat)s
enable_vcpdns : %(enable_vcpdns)s
fallback_count : %(fallback_count)s
fallback_percent: %(fallback_percent)s
geoip_continent : %(geoip_continent)s
geoip_country : %(geoip_country)s
geoip_region : %(geoip_region)s
geoip_state : %(geoip_state)s
geoip_city : %(geoip_city)s
geoip_default : %(geoip_default)s
geoip_isp : %(geoip_isp)s
geoip_asn : %(geoip_asn)s
list_all : %(list_all)s
load_balancing_type : %(load_balancing_type_display)s
log_request : %(log_request)s
parent_domain : %(parent_domain)s
pktloss_ignore : %(pktloss_ignore)s
probe_increment : %(probe_increment)s
probe_scaling_factor : %(probe_scaling_factor)s
rtt_lowerbound : %(rtt_lowerbound)s
rtt_upperbound : %(rtt_upperbound)s
delay_start_time : %(delay_start_time)s
slowstart_period : %(slowstart_period)s
system_ignore : %(system_ignore)s
tolerance : %(tolerance)s
uplink_ignore : %(uplink_ignore)s
uplink_scaling_factor : %(uplink_scaling_factor)s

Edges : %(domainedges)s
Vips : %(domainvips)s
Static Rules : %(domainstaticruleconditions)s"""
        config_str = template_string % data
        return config_str


class DomainConfigXMLRenderer(renderers.XMLRenderer):
    media_type = 'text/config-xml'
    format = 'xml'
    charset = 'utf-8'

    def render(self, data, media_type=None, renderer_context=None):
        if data is None:
            return ''

        domainedges = [str(edge.get("edge_name")) for edge in data["domainedges"]]
        domainvips = [str(vip.get("vip_name")) for vip in data["domainvips"]]
        domainstaticruleconditions = [{"condition": str(r.get("condition")),
                                       "invert": r.get("invert"),
                                       "action": [str(ar.get("action")) for ar in r.get("domainstaticruleactions")]}
                                      for r in data["domainstaticruleconditions"]]
        data["domainvips"] = domainvips
        data["domainedges"] = domainedges
        data["domainstaticruleconditions"] = domainstaticruleconditions

        stream = StringIO()

        xml = SimplerXMLGenerator(stream, self.charset)
        xml.startDocument()
        xml.startElement("root", {})

        self._to_xml(xml, data)

        xml.endElement("root")
        xml.endDocument()
        return stream.getvalue()


__DOMAIN_URL_LOOKUP_KEY__ = "domain_id"
__DOMAIN_CONDITION_URL_LOOKUP_KEY__ = "domain_staticrule_condition_id"
__DOMAINALIAS_URL_LOOKUP_KEY__ = "domain_alias_id"


class DomainAPI(ListModelMixin,
                CreateModelMixin,
                UpdateModelMixin,
                DestroyModelMixin,
                SpectrumGenericAPIView):
    queryset = Domain.objects.all()
    serializer_class = DomainSerializer
    lookup_url_kwarg = __DOMAIN_URL_LOOKUP_KEY__
    search_fields = ("name", "customer__customer_name")
    filter_fields = (
        'domain_id', 'name', {"customer_name": "customer__customer_name"},
        "domain_type", "description", "customer")
    ordering = "-date_modified"

    def get(self, request, *args, **kwargs):
        return super(DomainAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(DomainAPI, self).create(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainAPI, self).partial_update(request, *args, **kwargs)

    def post_save(self, obj, created=False):
        if isinstance(obj, list):
            try:
                [domain_probe_auto_mapping(self.request, obj) for item in obj]
            except Exception as e:
                # system fail
                log.error(e)
        else:
            is_valid, check_message = domain_probe_auto_mapping(self.request, obj)

    def delete(self, request, *args, **kwargs):
        # valid deleteble
        return super(DomainAPI, self).destroy(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise NotDeletableDomain


class DomainDetailAPI(RetrieveModelMixin,
                      UpdateModelMixin,
                      DestroyModelMixin,
                      SpectrumGenericAPIView):
    queryset = Domain.objects.all()
    serializer_class = DomainDetailSerializer
    lookup_url_kwarg = __DOMAIN_URL_LOOKUP_KEY__
    renderer_classes = list(api_settings.DEFAULT_RENDERER_CLASSES) + [DomainTextRenderer, DomainConfigXMLRenderer]

    def get(self, request, *args, **kwargs):
        return super(DomainDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainDetailAPI, self).partial_update(request, *args, **kwargs)

    def post_save(self, obj, created=False):
        if isinstance(obj, list):
            try:
                [domain_probe_auto_mapping(self.request, obj) for item in obj]
            except Exception as e:
                # system fail
                log.error(e)
        else:
            is_valid, check_message = domain_probe_auto_mapping(self.request, obj)

    def delete(self, request, *args, **kwargs):
        # valid deleteble
        return super(DomainDetailAPI, self).destroy(request, *args, **kwargs)

    def pre_delete(self, obj):
        if not obj.is_deletable():
            raise NotDeletableDomain

class DomainStaticRuleConditionAPI(ListModelMixin,
                                   CreateModelMixin,
                                   UpdateModelMixin,
                                   DestroyModelMixin,
                                   SpectrumGenericAPIView):
    queryset = DomainStaticRuleCondition.objects.all()
    filter_fields = ("domain", "sequence", "condition",
                    {"action": "domainstaticruleaction__action"})
    serializer_class = DomainStaticRuleConditionSerializer
    lookup_url_kwarg = __DOMAIN_CONDITION_URL_LOOKUP_KEY__

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()
        if many is False:
            if data is not None:
                many = isinstance(data, list)

        domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
        if domain_id:
            append_item = {"domain": domain_id}
            if data:
                if many:
                    _data = []
                    for i in data:
                        i.update(append_item)
                        _data.append(i)
                    data = _data
                else:
                    data.update(append_item)

        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)

    def get_object(self, queryset=None):
        if queryset is None:
            queryset = self.filter_queryset(self.get_queryset())
        else:
            pass

        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field

        # filter with parent_id
        if self.kwargs is not None:
            parent_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)

            if parent_id is not None:
                queryset = queryset.filter(domain=parent_id)

        try:
            data = self.request.DATA

            if isinstance(data, list):
                lookup = map(lambda x: x.get(lookup_url_kwarg), data)
                filter_kwargs = {"%s__in" % self.lookup_field: lookup}
                obj = get_list_or_404(queryset, **filter_kwargs)
            else:
                lookup = data.get(lookup_url_kwarg)
                filter_kwargs = {"%s" % self.lookup_field: lookup}
                obj = get_object_or_404(queryset, **filter_kwargs)

        except Exception as e:
            raise e

        return obj

    def get_queryset(self):
        filter_kwargs = {}
        queryset = self.queryset

        if self.kwargs is not None:
            domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
            filter_kwargs = {"domain": domain_id}

        if len(filter_kwargs) > 0:
            queryset = queryset.filter(**filter_kwargs)

        return queryset

    def get(self, request, *args, **kwargs):
        return super(DomainStaticRuleConditionAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(DomainStaticRuleConditionAPI, self).create(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainStaticRuleConditionAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainStaticRuleConditionAPI, self).partial_update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        # valid deleteble
        return super(DomainStaticRuleConditionAPI, self).destroy(request, *args, **kwargs)


class DomainStaticRuleConditionDetailAPI(RetrieveModelMixin,
                                         UpdateModelMixin,
                                         DestroyModelMixin,
                                         SpectrumGenericAPIView):
    queryset = DomainStaticRuleCondition.objects.all()
    filter_fields = ("domain", "sequence")
    serializer_class = DomainStaticRuleConditionSerializer
    lookup_url_kwarg = __DOMAIN_CONDITION_URL_LOOKUP_KEY__
    ordering = "sequence"

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()

        domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
        if domain_id:
            append_item = {"domain": domain_id}
            if data:
                if many:
                    _data = []
                    for i in data:
                        i.update(append_item)
                        _data.append(i)
                    data = _data
                else:
                    data.update(append_item)

        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)

    def get_queryset(self):
        filter_kwargs = {}
        queryset = self.queryset

        if self.kwargs is not None:
            domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
            filter_kwargs = {"domain": domain_id}

        if len(filter_kwargs) > 0:
            queryset = queryset.filter(**filter_kwargs)

        return queryset

    def get(self, request, *args, **kwargs):
        return super(DomainStaticRuleConditionDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainStaticRuleConditionDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainStaticRuleConditionDetailAPI, self).partial_update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        # valid deleteble
        return super(DomainStaticRuleConditionDetailAPI, self).destroy(request, *args, **kwargs)


class DomainStaticRuleActionAPI(ListModelMixin,
                                CreateModelMixin,
                                UpdateModelMixin,
                                DestroyModelMixin,
                                SpectrumGenericAPIView):
    queryset = DomainStaticRuleAction.objects.all()
    filter_fields = ("sequence")
    serializer_class = DomainStaticRuleActionSerializer
    lookup_url_kwarg = "domain_staticrule_action_id"

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()

        if many is False:
            if data is not None:
                many = isinstance(data, list)

        domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
        if domain_id:
            append_item = {"domain": domain_id}
            if data:
                if many:
                    _data = []
                    for i in data:
                        i.update(append_item)
                        _data.append(i)
                    data = _data
                else:
                    data.update(append_item)

        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)

    def get_object(self, queryset=None):
        if queryset is None:
            queryset = self.filter_queryset(self.get_queryset())
        else:
            pass

        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field

        try:
            data = self.request.DATA

            lookup = map(lambda x: x.get(lookup_url_kwarg), data)
            filter_kwargs = {"%s__in" % self.lookup_field: lookup}

            obj = get_list_or_404(queryset, **filter_kwargs)
        except Exception as e:
            raise e

        return obj

    def get_queryset(self):
        filter_kwargs = {}
        queryset = self.queryset

        if self.kwargs is not None:
            domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
            domain_condition_id = self.kwargs.get(
                __DOMAIN_CONDITION_URL_LOOKUP_KEY__, None)

            if domain_id:
                filter_kwargs.update({"condition__domain": domain_id})

            if domain_condition_id:
                filter_kwargs.update({"condition": domain_condition_id})

        if len(filter_kwargs) > 0:
            queryset = queryset.filter(**filter_kwargs)

        return queryset

    def get(self, request, *args, **kwargs):
        return super(DomainStaticRuleActionAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(DomainStaticRuleActionAPI, self).create(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainStaticRuleActionAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainStaticRuleActionAPI, self).partial_update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        # valid deleteble
        return super(DomainStaticRuleActionAPI, self).destroy(request, *args, **kwargs)


class DomainStaticRuleActionDetailAPI(RetrieveModelMixin,
                                      UpdateModelMixin,
                                      DestroyModelMixin,
                                      SpectrumGenericAPIView):
    queryset = DomainStaticRuleAction.objects.all()
    filter_fields = ("sequence")
    serializer_class = DomainStaticRuleActionSerializer
    lookup_url_kwarg = 'domain_staticrule_action_id'

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()
        many = isinstance(data, list)

        domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
        if domain_id:
            append_item = {"domain": domain_id}
            if data:
                if many:
                    _data = []
                    for i in data:
                        i.update(append_item)
                        _data.append(i)
                    data = _data
                else:
                    data.update(append_item)

        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)

    def get_queryset(self):
        filter_kwargs = {}
        queryset = self.queryset

        if self.kwargs is not None:
            domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
            domain_condition_id = self.kwargs.get(
                __DOMAIN_CONDITION_URL_LOOKUP_KEY__, None)

            if domain_id:
                filter_kwargs.update({"condition__domain": domain_id})

            if domain_condition_id:
                filter_kwargs.update({"condition": domain_condition_id})

        if len(filter_kwargs) > 0:
            queryset = queryset.filter(**filter_kwargs)

        return queryset

    def get(self, request, *args, **kwargs):
        return super(DomainStaticRuleActionDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainStaticRuleActionDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainStaticRuleActionDetailAPI, self).partial_update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        # valid deleteble
        return super(DomainStaticRuleActionDetailAPI, self).destroy(request, *args, **kwargs)


class DomainEdgeAPI(ListModelMixin,
                    CreateModelMixin,
                    UpdateModelMixin,
                    DestroyModelMixin,
                    SpectrumGenericAPIView):
    queryset = DomainEdge.objects.all()
    serializer_class = DomainEdgeSerializer
    lookup_url_kwarg = "domain_edge_id"

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()
        if many is False:
            if data is not None:
                many = isinstance(data, list)

        domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
        if domain_id:
            append_item = {"domain": domain_id}
            if data:
                if many:
                    _data = []
                    for i in data:
                        i.update(append_item)
                        _data.append(i)
                    data = _data
                else:
                    data.update(append_item)

        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)

    def get_object(self, queryset=None):
        if queryset is None:
            queryset = self.filter_queryset(self.get_queryset())
        else:
            pass

        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field

        try:
            data = self.request.DATA

            lookup = map(lambda x: x.get(lookup_url_kwarg), data)
            filter_kwargs = {"%s__in" % self.lookup_field: lookup}

            obj = get_list_or_404(queryset, **filter_kwargs)
        except Exception as e:
            raise e

        return obj

    def get_queryset(self):
        filter_kwargs = {}
        queryset = self.queryset

        domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
        if domain_id:
            filter_kwargs = {"domain": domain_id}

        if len(filter_kwargs) > 0:
            queryset = queryset.filter(**filter_kwargs)

        return queryset

    def get(self, request, *args, **kwargs):
        return super(DomainEdgeAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(DomainEdgeAPI, self).create(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainEdgeAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainEdgeAPI, self).partial_update(request, *args, **kwargs)

    def post_save(self, obj, created=False):
        if isinstance(obj, list):
            try:
                [domain_node_probe_auto_mapping(self.request, obj) for item in obj]
            except Exception as e:
                # system fail
                log.error(e)
        else:
            is_valid, check_message = domain_node_probe_auto_mapping(self.request, obj)

    def delete(self, request, *args, **kwargs):
        # valid deleteble
        return super(DomainEdgeAPI, self).destroy(request, *args, **kwargs)

    def pre_delete(self, obj):
        if obj.is_mproxy_related():
            raise isMproxyEdge

        try:
            if obj.pk and obj.domain.clb_dns_zone:
                obj.domain.clb_dns_zone.snapshot_of_base_relation()
        except:
            pass

    def pre_save(self, obj):
        # if obj.domain.clb_dns_zone
        try:
            if obj.pk and obj.domain.clb_dns_zone:
                obj.domain.clb_dns_zone.snapshot_of_base_relation()
        except:
            pass

class DomainEdgeDetailAPI(RetrieveModelMixin,
                          UpdateModelMixin,
                          DestroyModelMixin,
                          SpectrumGenericAPIView):
    queryset = DomainEdge.objects.all()
    serializer_class = DomainEdgeSerializer
    lookup_url_kwarg = 'domain_edge_id'

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()
        if many is False:
            if data is not None:
                many = isinstance(data, list)

        domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
        if domain_id:
            append_item = {"domain": domain_id}
            if many:
                _data = []
                for i in data:
                    i.update(append_item)
                    _data.append(i)
                data = _data
            else:
                data.update(append_item)

        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)

    def get_queryset(self):
        filter_kwargs = {}
        queryset = self.queryset

        domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
        if domain_id:
            filter_kwargs = {"domain": domain_id}

        if len(filter_kwargs) > 0:
            queryset = queryset.filter(**filter_kwargs)

        return queryset

    def get(self, request, *args, **kwargs):
        return super(DomainEdgeDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainEdgeDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainEdgeDetailAPI, self).partial_update(request, *args, **kwargs)

    def post_save(self, obj, created=False):
        if isinstance(obj, list):
            try:
                [domain_node_probe_auto_mapping(self.request, obj) for item in obj]
            except Exception as e:
                # system fail
                log.error(e)
        else:
            is_valid, check_message = domain_node_probe_auto_mapping(self.request, obj)

    def delete(self, request, *args, **kwargs):
        # valid deleteble
        return super(DomainEdgeDetailAPI, self).destroy(request, *args, **kwargs)

    def pre_delete(self, obj):
        if obj.is_mproxy_related():
            raise isMproxyEdge

        try:
            if obj.pk and obj.domain.clb_dns_zone:
                obj.domain.clb_dns_zone.snapshot_of_base_relation()
        except:
            pass

    def pre_save(self, obj):
        # if obj.domain.clb_dns_zone
        try:
            if obj.pk and obj.domain.clb_dns_zone:
                obj.domain.clb_dns_zone.snapshot_of_base_relation()
        except:
            pass

class DomainVipAPI(ListModelMixin,
                   CreateModelMixin,
                   UpdateModelMixin,
                   DestroyModelMixin,
                   SpectrumGenericAPIView):
    queryset = DomainVip.objects.all()
    serializer_class = DomainVipSerializer
    lookup_url_kwarg = "domain_vip_id"

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()
        if many is False:
            if data is not None:
                many = isinstance(data, list)

        domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
        if domain_id:
            append_item = {"domain": domain_id}
            if data:
                if many:
                    _data = []
                    for i in data:
                        i.update(append_item)
                        _data.append(i)
                    data = _data
                else:
                    data.update(append_item)

        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)

    def get_object(self, queryset=None):
        if queryset is None:
            queryset = self.filter_queryset(self.get_queryset())
        else:
            pass

        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field

        try:
            data = self.request.DATA

            lookup = map(lambda x: x.get(lookup_url_kwarg), data)
            filter_kwargs = {"%s__in" % self.lookup_field: lookup}

            obj = get_list_or_404(queryset, **filter_kwargs)
        except:
            # raise e
            pass

        return obj

    def get_queryset(self):
        filter_kwargs = {}
        queryset = self.queryset

        domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
        if domain_id:
            filter_kwargs = {"domain": domain_id}

        if len(filter_kwargs) > 0:
            queryset = queryset.filter(**filter_kwargs)

        return queryset

    def get(self, request, *args, **kwargs):
        return super(DomainVipAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(DomainVipAPI, self).create(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainVipAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainVipAPI, self).partial_update(request, *args, **kwargs)

    def pre_save(self, obj):
        # if obj.domain.clb_dns_zone
        try:
            if obj.pk and obj.domain.clb_dns_zone:
                obj.domain.clb_dns_zone.snapshot_of_base_relation()
        except:
            pass

    def pre_delete(self, obj):
        try:
            if obj.pk and obj.domain.clb_dns_zone:
                obj.domain.clb_dns_zone.snapshot_of_base_relation()
        except:
            pass

    def post_save(self, obj, created=False):
        if isinstance(obj, list):
            try:
                [domain_node_probe_auto_mapping(self.request, obj) for item in obj]
            except Exception as e:
                # system fail
                log.error(e)
        else:
            is_valid, check_message = domain_node_probe_auto_mapping(self.request, obj)

    def delete(self, request, *args, **kwargs):
        # valid deleteble
        return super(DomainVipAPI, self).destroy(request, *args, **kwargs)


class DomainVipDetailAPI(RetrieveModelMixin,
                         UpdateModelMixin,
                         DestroyModelMixin,
                         SpectrumGenericAPIView):
    queryset = DomainVip.objects.all()
    serializer_class = DomainVipSerializer
    lookup_url_kwarg = 'domain_vip_id'

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()
        if many is False:
            if data is not None:
                many = isinstance(data, list)

        domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
        if domain_id:
            append_item = {"domain": domain_id}
            if data:
                if many:
                    _data = []
                    for i in data:
                        i.update(append_item)
                        _data.append(i)
                    data = _data
                else:
                    data.update(append_item)

        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)

    def get_queryset(self):
        filter_kwargs = {}
        queryset = self.queryset

        domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
        if domain_id:
            filter_kwargs = {"domain": domain_id}

        if len(filter_kwargs) > 0:
            queryset = queryset.filter(**filter_kwargs)

        return queryset

    def get(self, request, *args, **kwargs):
        return super(DomainVipDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainVipDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainVipDetailAPI, self).partial_update(request, *args, **kwargs)

    def pre_save(self, obj):
        # if obj.domain.clb_dns_zone
        try:
            if obj.pk and obj.domain.clb_dns_zone:
                obj.domain.clb_dns_zone.snapshot_of_base_relation()
        except:
            pass

    def pre_delete(self, obj):
        try:
            if obj.pk and obj.domain.clb_dns_zone:
                obj.domain.clb_dns_zone.snapshot_of_base_relation()
        except:
            pass

    def post_save(self, obj, created=False):
        if isinstance(obj, list):
            try:
                [domain_node_probe_auto_mapping(self.request, obj) for item in obj]
            except Exception as e:
                # system fail
                log.error(e)
        else:
            is_valid, check_message = domain_node_probe_auto_mapping(self.request, obj)

    def delete(self, request, *args, **kwargs):
        # valid deleteble
        return super(DomainVipDetailAPI, self).destroy(request, *args, **kwargs)


class DomainAliasAPI(ListModelMixin,
                     CreateModelMixin,
                     UpdateModelMixin,
                     DestroyModelMixin,
                     SpectrumGenericAPIView):
    queryset = DomainAlias.objects.all()
    serializer_class = DomainAliasSerializer
    lookup_url_kwarg = __DOMAINALIAS_URL_LOOKUP_KEY__
    search_fields = ("name", "customer__customer_name", "domain__name")
    filter_fields = ("domain_id", "name", {"customer_name": "customer__customer_name"},
                     {"origin_domain_name": "domain__name"},
                     "description", "customer")

    def get(self, request, *args, **kwargs):
        return super(DomainAliasAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(DomainAliasAPI, self).create(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainAliasAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainAliasAPI, self).partial_update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        # valid deleteble
        return super(DomainAliasAPI, self).destroy(request, *args, **kwargs)


class DomainAliasDetailAPI(RetrieveModelMixin,
                           UpdateModelMixin,
                           DestroyModelMixin,
                           SpectrumGenericAPIView):
    queryset = DomainAlias.objects.all()
    serializer_class = DomainAliasSerializer
    lookup_url_kwarg = __DOMAINALIAS_URL_LOOKUP_KEY__

    def get(self, request, *args, **kwargs):
        return super(DomainAliasDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainAliasDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        # valid modifiable
        return super(DomainAliasDetailAPI, self).partial_update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        # valid deleteble
        return super(DomainAliasDetailAPI, self).destroy(request, *args, **kwargs)


class DomainAllAPI(ListModelMixin,
                   SpectrumGenericAPIView):
    queryset = DomainAll.objects.all()
    serializer_class = DomainAllSerializer
    lookup_url_kwarg = __DOMAIN_URL_LOOKUP_KEY__
    search_fields = ("name", "customer__customer_name")
    filter_fields = (
        'domain_id', 'name', {"customer_name": "customer__customer_name"},
        "domain_type", "description", "customer")

    def get(self, request, *args, **kwargs):
        return super(DomainAllAPI, self).list(request, *args, **kwargs)

"""
    Utilize APIs
"""
class DomainCustomerAPI(APIView):

    def get(self, request, *args, **kwargs):
        try:
            domain_type = int(request.QUERY_PARAMS.get('domain_type', None))
        except (TypeError, ValueError):
            domain_type = None

        domains_qs = DomainAll.objects.filter(customer__isnull=False)
        if domain_type is not None:
            if DOMAIN_ALIAS == domain_type:
                domains_qs = DomainAlias.objects.filter(customer__isnull=False)
            else:
                domains_qs = Domain.objects.filter(customer__isnull=False, domain_type=domain_type)

        domain_customer_list_qs = domains_qs.values_list("customer")\
                .distinct("customer")
        domain_customer_list = [dc[0] for dc in domain_customer_list_qs]

        customer_list = CustomerDisplay.objects.filter(pk__in=domain_customer_list)\
                        .order_by("customer_name")

        customers = [{"customer_id": c.pk,
                      "customer_name": "%s [%s]"%(c.customer_name.strip(), c.getRegionName())}
                        for c in customer_list]

        return Response(customers)


class DomainTypeAPI(APIView):

    def get(self, request, *args, **kwargs):
        domain_types = [{"domain_type": dt[0], "domain_type_name": dt[1]}
                        for dt in DOMAIN_TYPE]
        domain_types = sorted(domain_types, key=lambda k: k["domain_type"])
        return Response(domain_types)


class DomainReVips(object):

    """
    Vip list of Domain Vip and Domain Edge's VIPs
    """

    def __init__(self, *args, **kwargs):
        domainvip = kwargs.pop("domainvip", None)
        if domainvip:
            self.vip_id = domainvip.vip.pk
            self.ip = "%s" % domainvip.vip
            self.vip_name = domainvip.vip.get_fullvipname()
            self.edges = [{"edge_id": edge.pk, "edge_name": "%s" % edge}
                          for edge in domainvip.vip.edge.all()]
            self.enable_gslb = domainvip.vip.enable_gslb
            self.status = domainvip.get_status()
            self.status_display = domainvip.get_status_display()


class DomainSubVipAPI(SpectrumGenericAPIView):
    lookup_url_kwarg = __DOMAIN_URL_LOOKUP_KEY__

    def get(self, request, *args, **kwargs):
        try:
            domain_id = self.kwargs.pop(self.lookup_url_kwarg)

            domain = Domain.objects.get(domain_id=domain_id)
            # domain_vips = domain.get_related_vips()
            domainvips = domain.get_related_domainvips_with_rms()

            vips = [DomainReVips(domainvip=domain_re_vip)
                    for domain_re_vip in domainvips]
            return Response([vip.__dict__ for vip in vips])
        except KeyError:
            raise AccessInvalidDomainID
        except Domain.DoesNotExist:
            raise DomainDoseNotExist
        except:
            raise APIException(detail=_(u"Occured system failure"))


class DomainRelatedItemAPI(SpectrumGenericAPIView):
    lookup_url_kwarg = __DOMAIN_URL_LOOKUP_KEY__

    def get(self, request, *args, **kwargs):
        related_items = {}
        try:
            domain_id = self.kwargs.pop(self.lookup_url_kwarg)

            domain = Domain.objects.get(domain_id=domain_id)
            domain_items = domain.get_related_items()

            for items in domain_items:
                key = unicode(items[0].__name__)
                sub_items = []
                for sub_item in items[1]:
                    if hasattr(sub_item,'get_full_name'):
                        sub_items.append("%s" % sub_item.get_full_name())
                    else:
                        sub_items.append("%s" % sub_item)

                if len(sub_items) > 0:
                    related_items.update({key: sub_items})
            related_items["is_deletable"] = domain.is_deletable()
            return Response(related_items)
        except KeyError:
            raise AccessInvalidDomainID
        except Domain.DoesNotExist:
            raise DomainDoseNotExist
        except:
            raise APIException(detail=_(u"Occured system failure"))


class DomainStaticRuleConditionSeqUpAPI(SpectrumGenericAPIView):
    queryset = DomainStaticRuleCondition.objects.all()
    lookup_url_kwarg = __DOMAIN_CONDITION_URL_LOOKUP_KEY__
    serializer_class = DomainStaticRuleConditionSerializer
    ordering = "sequence"

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()

        domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
        if domain_id:
            append_item = {"domain": domain_id}
            if data:
                if many:
                    _data = []
                    for i in data:
                        i.update(append_item)
                        _data.append(i)
                    data = _data
                else:
                    data.update(append_item)

        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)

    def get_queryset(self):
        filter_kwargs = {}
        queryset = self.queryset
        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field

        if self.kwargs is not None:
            domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
            filter_kwargs = {"domain": domain_id}

            condtion_id = self.kwargs.get(lookup_url_kwarg, None)
            if condtion_id is not None:
                filter_kwargs.update({"domain_staticrule_condition_id": condtion_id})

        try:
            if len(filter_kwargs) > 0:
                queryset = queryset.get(**filter_kwargs)
        except DomainStaticRuleCondition.DoesNotExist:
            raise DomainStaticRuleDoseNotExist

        return queryset

    def put(self, request, *args, **kwargs):
        condition = self.get_queryset()

        try:
            if condition.sequence > 0:
                move_phases_sequence(request, condition)

                conditions = DomainStaticRuleCondition.objects.filter(domain=condition.domain)
                serializer = self.get_serializer(instance=conditions, many=True)
                return Response(serializer.data, status=HTTP_202_ACCEPTED)
            else:
                raise NotAcceptableException
        except IndexError:
            raise NotAcceptableException(
                detail=_(u"You can't do more shift up. This static rule condition is first item."))
        except NotAcceptableException:
            raise NotAcceptableException(
                detail=_(u"You can't do more shift up. This static rule condition is first item."))
        except Exception as e:
            # logging
            raise APIException(detail="%s" % e)


class DomainStaticRuleConditionSeqDownAPI(SpectrumGenericAPIView):
    queryset = DomainStaticRuleCondition.objects.all()
    lookup_url_kwarg = __DOMAIN_CONDITION_URL_LOOKUP_KEY__
    serializer_class = DomainStaticRuleConditionSerializer
    ordering = "sequence"

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()

        domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
        if domain_id:
            append_item = {"domain": domain_id}
            if data:
                if many:
                    _data = []
                    for i in data:
                        i.update(append_item)
                        _data.append(i)
                    data = _data
                else:
                    data.update(append_item)

        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)

    def get_queryset(self):
        filter_kwargs = {}
        queryset = self.queryset
        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field

        if self.kwargs is not None:
            domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
            filter_kwargs = {"domain": domain_id}

            condtion_id = self.kwargs.get(lookup_url_kwarg, None)

            if condtion_id is not None:
                filter_kwargs.update({"domain_staticrule_condition_id": condtion_id})

        try:
            if len(filter_kwargs) > 0:
                queryset = queryset.get(**filter_kwargs)
        except DomainStaticRuleCondition.DoesNotExist:
            raise DomainStaticRuleDoseNotExist
        return queryset

    def put(self, request, *args, **kwargs):
        condition = self.get_queryset()

        try:
            num_conditons = DomainStaticRuleCondition.objects.filter(domain=condition.domain,
                                                                     sequence__gt=condition.sequence).count()
            if num_conditons > 0:
                move_phases_sequence(request, condition, False)

                conditions = DomainStaticRuleCondition.objects.filter(domain=condition.domain)
                serializer = self.get_serializer(instance=conditions, many=True)
                return Response(serializer.data, status=HTTP_202_ACCEPTED)
            else:
                raise NotAcceptableException
        except NotAcceptableException:
            raise NotAcceptableException(
                detail=_(u"You can't do more shift down. This static rule condition is last item."))
        except Exception as e:
            # logging
            raise APIException(detail="%s" % e)


class DomainStaticRuleConditionSwapAPI(SpectrumGenericAPIView):
    queryset = DomainStaticRuleCondition.objects.all()
    lookup_url_kwarg = __DOMAIN_CONDITION_URL_LOOKUP_KEY__
    serializer_class = DomainStaticRuleConditionSerializer
    ordering = "sequence"

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()

        domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
        if domain_id:
            append_item = {"domain": domain_id}
            if data:
                if many:
                    _data = []
                    for i in data:
                        i.update(append_item)
                        _data.append(i)
                    data = _data
                else:
                    data.update(append_item)

        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)

    def get_queryset(self):
        filter_kwargs = {}
        queryset = self.queryset

        if self.kwargs is not None:
            domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
            filter_kwargs = {"domain": domain_id}

        if len(filter_kwargs) > 0:
            queryset = queryset.filter(**filter_kwargs)

        return queryset

    def put(self, request, *args, **kwargs):
        conditions = self.get_queryset()

        try:
            condition_id = self.kwargs.get(self.lookup_url_kwarg, None)
            seq = request.DATA.get("sequence", None)
            seq = int(seq)
            if seq is None:
                raise ParseError(detail=_(u"Please input number of condition's sequence"))
            elif seq < 0:
                raise ParseError(detail=_(u"Sequence have to greater than zero"))
            else:
                _cur = conditions.get(pk=condition_id)
                if _cur.sequence == seq:
                    raise DomainStaticRuleNotModified
                else:
                    _cur.sequence = seq
                    _cur.save(request=request)

                    conditions = DomainStaticRuleCondition.objects.filter(domain=_cur.domain)

                    serializer = self.get_serializer(instance=conditions)
                    return Response(serializer.data, status=HTTP_202_ACCEPTED)
        except Exception as e:
            # logging
            raise APIException(detail="%s" % e)


class DomainAdminModeHandleAPI(RetrieveModelMixin,
                               SpectrumGenericAPIView):
    queryset = Domain.objects.all()
    lookup_url_kwarg = __DOMAIN_URL_LOOKUP_KEY__
    serializer_class = DomainSerializer

    def get_queryset(self):
        filter_kwargs = {}
        queryset = self.queryset
        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field

        if self.kwargs is not None:
            domain_id = self.kwargs.get(lookup_url_kwarg, None)
            filter_kwargs = {"domain_id": domain_id}

        try:
            if len(filter_kwargs) > 0:
                queryset = queryset.get(**filter_kwargs)
        except Domain.DoesNotExist:
            raise DomainDoseNotExist

        return queryset

    def get(self, request, *args, **kwargs):
        return super(DomainAdminModeHandleAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        domain = self.get_queryset()

        try:
            domain.change_clb_admin_mode(request=request)
            serializer = self.get_serializer(instance=domain)
            return Response(serializer.data, status=HTTP_202_ACCEPTED)
        except Exception as e:
            # logging
            return Response({"detail": _(u"%s" % e)}, status=HTTP_406_NOT_ACCEPTABLE)


class DomainStaticRuleImportAPI(SpectrumGenericAPIView):
    lookup_url_kwarg = __DOMAIN_URL_LOOKUP_KEY__
    queryset = DomainStaticRuleCondition.objects.select_related("domain")
    serializer_class = DomainStaticRuleConditionSerializer

    def get_queryset(self):
        filter_kwargs = {}
        queryset = self.queryset
        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field

        domain_id = self.kwargs.get(lookup_url_kwarg, None)
        filter_kwargs = {"domain": domain_id}

        try:
            queryset = queryset.filter(**filter_kwargs)
        except DomainStaticRuleCondition.DoesNotExist:
            raise DomainDoseNotExist

        return queryset

    def post(self, request, *args, **kwargs):
        many = isinstance(request.DATA, list)
        queryset = self.get_queryset()

        buf = []
        is_valid = True
        INITAL_SEQ = 1

        for validate_result in _validate_gslb_static_rule_condition(conditions=request.DATA):
            if validate_result["is_valid"] == False:
                is_valid = False

            buf.append(validate_result)

        if not hasattr(request.DATA, "__iter__"):
            return Response({"detail": _("Empty static rule is not allow to import. You have to insert more then one static rule.")},
                        status=HTTP_400_BAD_REQUEST)

        if is_valid == True and len(buf) > 0:
            with transaction.commit_on_success():
                # if there is more than 1 rules and every condition are valid
                # it will be proceed delete exists every rules
                queryset.delete()

                domain_id = self.kwargs.get(self.lookup_url_kwarg, None)
                static_rules = []
                if many:
                    for seq, condition in enumerate(request.DATA):
                        seq = INITAL_SEQ + seq
                        invert = condition.get("invert", None)
                        actions = []
                        if invert is not None:
                            invert = str(invert).strip()
                            if invert == 'True' or invert == True or invert == 1:
                                invert = 1
                            else:
                                invert = 0

                        for action_seq, action in enumerate(condition.get("action")):
                            action_seq = INITAL_SEQ + action_seq
                            actions.append({
                                "action": str(action).strip(),
                                "sequence": action_seq
                            })
                        static_rule = {
                            "domain": domain_id,
                            "condition": str(condition.get("condition")).strip(),
                            "sequence": seq,
                            "invert": invert,
                            "domainstaticruleactions": actions
                        }
                        static_rules.append(static_rule)
                    serializer = self.get_serializer(data=static_rules, many=many)
                else:
                    condition = request.DATA
                    actions = []
                    invert = condition.get("invert", None)
                    if invert is not None:
                        invert = str(invert).strip()
                        if invert == 'True' or invert == True or invert == 1:
                            invert = 1
                        else:
                            invert = 0

                    for action_seq, action in condition.get("action"):
                        action_seq = INITAL_SEQ + action_seq
                        actions.append({
                            "action": str(action).strip(),
                            "sequence": action_seq
                        })
                    static_rule = {
                        "domain": domain_id,
                        "sequence": INITAL_SEQ,
                        "condition": str(condition.get("condition")).strip(),
                        "invert": invert,
                        "domainstaticruleactions": actions
                    }

                    serializer = self.get_serializer(data=static_rule, many=many)

                if serializer.is_valid():
                    serializer.save(request=request)

                    return Response(serializer.data)
                else:
                    return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)
        elif is_valid == False:
            return Response(buf, status=HTTP_400_BAD_REQUEST)


class DomainStaticRuleValidateAPI(SpectrumGenericAPIView):

    def post(self, request, *args, **kwargs):
        many = isinstance(request.DATA, list)
        buf = []
        is_valid = True

        for validate_result in _validate_gslb_static_rule_condition(conditions=request.DATA):
            if validate_result["is_valid"] == False:
                is_valid = False

            buf.append(validate_result)
        if is_valid == False:
            return Response(buf, status=HTTP_400_BAD_REQUEST)
        else:
            return Response(buf)


def _validate_gslb_static_rule_condition(conditions=None):
    """
    @ params mixed ( list , dict) : GSLB static rule conditions
    """
    _many = isinstance(conditions, list)
    actions = []
    if _many:
        buf = []
        for rule_set in conditions:
            is_cleaned = True
            try:
                condition = rule_set.get("condition", None)
                if condition is not None:
                    condition = condition.strip()
                    is_valid, exception_msg = validate_static_rule(condition, True)

                    is_cleaned = is_valid

                    import_actions = rule_set.get("action", None)

                    if import_actions is None or not hasattr(import_actions, "__iter__"):
                        raise MissingStaticRuleAction

                    actions = []
                    for validate_action in _validate_gslb_static_rule_action(import_actions):
                        if validate_action[0] == False:
                            if is_cleaned == True:
                                is_cleaned = False
                            actions.append((validate_action[1], validate_action[2]))
                else:
                    is_cleaned = False
                    exception_msg = _(u"condition rule is missing.")

                    actions = []
            except MissingStaticRuleAction as e:
                is_cleaned = False
                exception_msg = _(u'You missed input domain static rule action')
            except Exception as e:
                is_cleaned = False
                exception_msg = _(u"System failure Unable to validate rule")

                actions = []

            if exception_msg is not None:
                detail_msg = (condition, exception_msg)
            else:
                detail_msg = []
            yield {"is_valid": is_cleaned, "detail": detail_msg, "action": actions}

    else:
        condition = conditions
        is_cleaned = True
        if condition is not None:
            condition = condition.strip()
            is_valid, exception_msg = validate_static_rule(condition, True)
            is_cleaned = is_valid
            import_actions = condition.get("action", None)

            if import_actions is None:
                raise MissingStaticRuleAction

            actions = []
            for validate_action in _validate_gslb_static_rule_action(import_actions):
                if validate_action[0] == False:
                    if is_cleaned == True:
                        is_cleaned = False
                    actions.append((validate_action[1], validate_action[2]))
        else:
            is_valid = False
            exception_msg = _(u"condition rule is missing.")

            actions = []

        if exception_msg is not None:
            detail_msg = (condition, exception_msg)
        else:
            detail_msg = []
        yield {"is_valid": is_cleaned, "detail": detail_msg, "action": actions}


def _validate_gslb_static_rule_action(actions=None):
    """
    @ params mixed ( list , dict) : GSLB static rule actions
    """
    many = isinstance(actions, list)
    if many:
        buf = []
        for action in actions:
            try:
                if action is not None:
                    action = action.strip()
                    is_valid, exception_msg = validate_static_rule(action, False)
                else:
                    is_valid = False
                    exception_msg = _(u"action rule is missing.")
            except:
                is_valid = False
                exception_msg = _(u"System failure Unable to validate rule")

            yield (is_valid, action, exception_msg,)
    else:
        if actions is not None:
            actions = actions.strip()
            is_valid, exception_msg = validate_static_rule(actions, False)
        else:
            is_valid = False
            exception_msg = _(u"action rule is missing.")

        yield (is_valid, actions, exception_msg,)


class DomainRelayPopsAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = DomainDynamicRelay.objects.all()
    serializer_class = DomainDynamicRelaySerializer
    lookup_url_kwarg = 'dynamic_relay_id'

    def get_queryset(self):
        queryset = self.queryset
        try:
            domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__)
            # valid check
            int(domain_id)

            queryset = queryset.filter(domain=domain_id)
        except KeyError:
            raise AccessInvalidDomainID
        except ValueError:
            raise Exception(_(u'invalid domain_id input format'))

        return queryset

    def get(self, request, *args, **kwargs):
        ret = super(DomainRelayPopsAPI, self).list(request, *args, **kwargs)

        if isinstance(ret.data, list):
            org_results = ret.data
        else:
            org_results = ret.data['results']

        pop_list = []
        for result in org_results:
            pop_list.append(str(result['pop']))

        domain_relay_pops = get_domain_dynamic_relay(pop_list)

        for result in org_results:
            if domain_relay_pops.has_key(int(result['pop'])):
                pop_mon = domain_relay_pops[int(result['pop'])]
                result['pop_name'] = pop_mon['pop_name']
                result['country_id'] = pop_mon['country_id']
                result['country_name'] = pop_mon['country_name']
                result['relay_status'] = pop_mon['pop_enable_gslb']
                result['avaliable_count'] = pop_mon['avaliable_count']
                result['total_count'] = pop_mon['total_count']
            else:
                result['pop_name'] = ''
                result['country_id'] = 0
                result['country_name'] = ''
                result['relay_status'] = 0
                result['avaliable_count'] = 0
                result['total_count'] = 0

        org_results = sorted(org_results, key=lambda k: k["country_name"])

        if isinstance(ret.data, list):
            ret.data = org_results
        else:
            ret.data['results'] = org_results

        return ret

    @transaction.commit_manually
    def post(self, request, *args, **kwargs):
        domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
        domain = Domain.objects.get(domain_id=domain_id)
        if not domain_id:
            raise AccessInvalidDomainID
        req_data = {"detail":_(u"OK"), "domain_id":domain_id}
        try:
            relayPopLists = request.DATA.get("relaypopslists", [])
            for pop_info in relayPopLists:
                pop = Pop.objects.get(pk=int(pop_info['pop']))

                dynamic_relay = DomainDynamicRelay()
                dynamic_relay.pop = pop
                dynamic_relay.domain = domain
                dynamic_relay.save()

            transaction.commit()
            return Response(req_data)
        except Exception, e:
            # logging
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)

    @transaction.commit_manually
    def delete(self, request, *args, **kwargs):
        # valid deleteble
        req_data = {"detail":_(u"OK")}
        try:
            relayPopLists = request.DATA.get("relaypopslists", [])
            for pop_info in relayPopLists:
                relaypop = self.queryset.filter(pk=int(pop_info['dynamic_relay_id']))
                relaypop.delete()

            transaction.commit()
            return Response(req_data)
        except Exception, e:
            # logging
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)


class DomainPresetRelayAPI(SpectrumGenericAPIView):
    lookup_url_kwarg = __DOMAIN_URL_LOOKUP_KEY__

    @transaction.commit_manually
    def patch(self, request, *args, **kwargs):
         # valid deleteble
        domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
        if not domain_id:
            raise AccessInvalidDomainID

        try:
            domain = Domain.objects.get(domain_id=domain_id)
            preset_id = request.DATA.get("preset_id", None)

            if preset_id is not None:
                mproxy_preset = MproxyPreset.objects.get(pk=int(preset_id))
                domain.mproxy_preset = mproxy_preset
            else:
                domain.mproxy_preset = None
            domain.save(request=request)

            transaction.commit()
            return Response({"detail":_(u"OK"), "domain_id":domain_id, "preset_id":preset_id})
        except Exception, e:
            transaction.rollback()
            return Response({"detail": _(u"%s" % e)}, status=HTTP_400_BAD_REQUEST)
