# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Geo Location Rest API
"""
from __future__ import absolute_import
from django.core.cache import cache
from rest_framework.response import Response

from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.dna.models.stats import DnaLocationContinentMap, DnaLocationCountryMap, \
    DnaLocationRegionMap, DnaLocationIspMap

#Geo Location names shown split by comma in static rule condition string.
__SEPERATOR__ = ","

class GeoLocation(object):
    __CACHE_CONTINENT_KEY__ = "_GEO_CACHE_CONTENTINET_"
    __CACHE_COUNTRY_KEY__ = "_GEO_CACHE_COUNTRY_"
    __CACHE_REGION_KEY__ = "_GEO_CACHE_REGION_"
    __CACHE_ISP_KEY__ = "_GEO_CACHE_ISP_"
    # TTL 1 day
    __CACHE_EXPIRE_T__ = 86400

    def sort(self, data):
        try:
            return sorted([d[0] for d in data], key=lambda k: k[0])
        except:
            # logging E
            return None

    def get_geo_continent(self):
        try:
            data = cache.get(self.__CACHE_CONTINENT_KEY__)
            if not data:
                geo_continents = DnaLocationContinentMap.all_objects\
                    .filter(is_visible=True)\
                    .order_by('continent_name')\
                    .exclude(continent_name__icontains=__SEPERATOR__)\
                    .values_list('continent_name')
                data = self.sort(geo_continents)
                cache.set(self.__CACHE_CONTINENT_KEY__, data, self.__CACHE_EXPIRE_T__)
        except:
            # logging
            geo_continents = DnaLocationContinentMap.all_objects\
                .filter(is_visible=True)\
                .order_by('continent_name')\
                .exclude(continent_name__icontains=__SEPERATOR__)\
                .values_list('continent_name')
            data = self.sort(geo_continents)

        return data

    def get_geo_country(self):
        try:
            data = cache.get(self.__CACHE_COUNTRY_KEY__)
            if not data:
                geo_country = DnaLocationCountryMap.all_objects\
                    .filter(is_visible=True).order_by('country_name')\
                    .exclude(ihms_country__icontains=__SEPERATOR__)\
                    .values_list('ihms_country')
                data = self.sort(geo_country)
                cache.set(self.__CACHE_COUNTRY_KEY__, data, self.__CACHE_EXPIRE_T__)

        except:
            # logging
            geo_country = DnaLocationCountryMap.all_objects\
                .filter(is_visible=True).order_by('country_name')\
                .exclude(ihms_country__icontains=__SEPERATOR__)\
                .values_list('ihms_country')
            data = self.sort(geo_country)
        return data

    def get_geo_region(self):
        try:
            data = cache.get(self.__CACHE_REGION_KEY__)
            if not data:
                geo_regions = DnaLocationRegionMap.all_objects.filter(is_visible=True)\
                                                    .order_by('region_name')\
                                                    .exclude(region_name__icontains=__SEPERATOR__)\
                                                    .values_list('region_name')
                data = self.sort(geo_regions)
                cache.set(self.__CACHE_REGION_KEY__, data, self.__CACHE_EXPIRE_T__)
        except:
            # logging
            geo_regions = DnaLocationRegionMap.all_objects.filter(is_visible=True)\
                                                    .order_by('region_name')\
                                                    .exclude(region_name__icontains=__SEPERATOR__)\
                                                    .values_list('region_name')
            data = self.sort(geo_regions)
        return data

    def get_geo_isp(self):
        try:
            data = cache.get(self.__CACHE_ISP_KEY__)
            if not data:
                geo_isps = DnaLocationIspMap.all_objects\
                    .filter(is_visible=True)\
                    .exclude(isp_name__icontains=__SEPERATOR__)\
                    .order_by('isp_name').values_list('isp_name')
                data = self.sort(geo_isps)
                cache.set(self.__CACHE_ISP_KEY__, data, self.__CACHE_EXPIRE_T__)
        except:
            # logging
            geo_isps = DnaLocationIspMap.all_objects\
                .filter(is_visible=True)\
                .exclude(isp_name__icontains=__SEPERATOR__)\
                .order_by('isp_name').values_list('isp_name')
            data = self.sort(geo_isps)
        return data

    def get_geo_data(self):
        continents = self.get_geo_continent()
        countries = self.get_geo_country()
        regions = self.get_geo_region()
        isps = self.get_geo_isp()

        geo_data = {"continents": continents,
                    "countries": countries,
                    "regions": regions,
                    "isps": isps}
        return geo_data


class GeoLocationAPI(SpectrumGenericAPIView):

    def get(self, request, *args, **kwargs):
        try:
            geo = GeoLocation()
            return Response(geo.get_geo_data())
        except Exception, e:
            raise e


class GeoLocationContinentAPI(SpectrumGenericAPIView):

    def get(self, request, *args, **kwargs):
        try:
            geo = GeoLocation()
            return Response(geo.get_geo_continent())
        except Exception, e:
            raise e


class GeoLocationCountryAPI(SpectrumGenericAPIView):

    def get(self, request, *args, **kwargs):
        try:
            geo = GeoLocation()
            return Response(geo.get_geo_country())
        except Exception, e:
            raise e


class GeoLocationRegionAPI(SpectrumGenericAPIView):

    def get(self, request, *args, **kwargs):
        try:
            geo = GeoLocation()
            return Response(geo.get_geo_region())
        except Exception, e:
            raise e


class GeoLocationISPAPI(SpectrumGenericAPIView):

    def get(self, request, *args, **kwargs):
        try:
            geo = GeoLocation()
            return Response(geo.get_geo_isp())
        except Exception, e:
            raise e
