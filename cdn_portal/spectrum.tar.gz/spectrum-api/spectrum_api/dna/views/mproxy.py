# -*- coding: utf-8 -*-
"""
    Copyright (c) 2015 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        MProxy Rest API
"""
from django.utils.translation import ugettext as _
from django.db import connections
from rest_framework.exceptions import APIException
from rest_framework.response import Response
from rest_framework.status import HTTP_404_NOT_FOUND, HTTP_400_BAD_REQUEST, \
    HTTP_406_NOT_ACCEPTABLE, HTTP_202_ACCEPTED, HTTP_304_NOT_MODIFIED, HTTP_403_FORBIDDEN
from django.core.cache import cache
from django.conf import settings

from spectrum_api.shared_components.utils.common import get_ip_pop_dicts
from spectrum_api.dna.models.mproxy import MproxyDomainEdge
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.mixins import ListModelMixin, RetrieveModelMixin, \
    CreateModelMixin, UpdateModelMixin, DestroyModelMixin
from spectrum_api.dna.models.mproxy import MproxyAlertManagement, MproxyAlertHistory
from spectrum_api.dna.models.domain import MproxyApp
from spectrum_api.dna.serializers.mproxy import MproxyAlertManangemnetSerializer, \
    AlertMproxyAppSimpleSerializer, MproxyAlertHistorySerializer

__POP_NAME_URL_LOOKUP_KEY__ = "pop_name"
__ALERT_MANANGEMENT_URL_LOOKUP_KEY__ = "alert_id"
__MPROXYAPP_URL_LOOKUP_KEY__ = "mproxy_app_id"

# DNA 2.3 - Monitoring Routing Path Page
class MproxyEdgeDoesNotExist(APIException):
    status_code = HTTP_404_NOT_FOUND
    default_detail = _(u'No Mproxy Edge list.')

def get_mproxy_service_list(mproxy_app_id):
    mproxy_service_info = []
    where_str = ""

    if mproxy_app_id is None:
        return mproxy_service_info

    sql = """
            SELECT
                ma.mproxy_app_id, ma.mproxy_app_name,
                me.mproxy_edge_id,
                me.domain_edge_id, be.edge_id, be.name as edge_name,
                ma.edge_domain_id, gd.name as edge_domain_name,
                me.origin_domain_id, me.shield_domain_id, me.relay_domain_id,
                me.dynamic_relay,
                me.external_domain_enabled,
                me.external_domain,
                me.port, me.protocol,
                CONCAT(me.protocol,'/',me.port) as displayname,
                if(isnull(me.shield_domain_id), 
                    null, 
                    (SELECT mproxy_preset_id FROM gslb_domain WHERE domain_id = me.shield_domain_id)) as mproxy_preset_id
            FROM mproxy_app ma
                left join gslb_domain gd on ma.edge_domain_id = gd.domain_id
                left join mproxy_edge me on ma.mproxy_app_id = me.mproxy_app_id
                left join gslb_domain_edge gde on me.domain_edge_id = gde.domain_edge_id
                left join base_edge be on gde.edge_id = be.edge_id
            where ma.obj_state = 1 and ma.mproxy_app_id = %s
            order by me.mproxy_edge_id
            """
    cursor = connections['default'].cursor()
    cursor.execute(sql, [mproxy_app_id])
    fieldnames = [name[0] for name in cursor.description]
    rs = cursor.fetchall()

    for obj in rs:
        rowset = []
        for field in zip(fieldnames, obj):
            rowset.append((field[0], field[1]))
        mproxy_service_info.append(dict(rowset))

    return mproxy_service_info

def get_mproxy_pop_list(edge_list, kind):
    mproxy_pop_info = {}

    if len(edge_list) <= 0:
        return mproxy_pop_info

    sql = """
            SELECT
                me.mproxy_edge_id,
                me.%s_domain_id, gd.name as %s_domain_name,
                bp.pop_id, vs.pop_name, vs.ip,
                if(isnull(ic.city_name), 
                    (select airport_city from spectrum.airport where upper(substring_index(vs.pop_name,'-',-1)) = airport_iata limit 1), 
                    ic.city_name) as city_name,
                mps.pop_status
            FROM mproxy_edge me
                left join gslb_domain gd on me.%s_domain_id = gd.domain_id
                left join gslb_domain_edge gde on gd.domain_id = gde.domain_id
                left join gslb_domain_vip gdv on gd.domain_id = gdv.domain_id
                left join base_vip_edge bve on gde.edge_id = bve.edge_id
                left join base_vip bv on bve.vip_id = bv.vip_id or gdv.vip_id = bv.vip_id
                left join base_vip_search vs on bv.vip_id = vs.vip_id
                left join ihms_pop ip on vs.pop_name = ip.pop_code
                left join base_pop bp on vs.pop_name = bp.pop_name or ip.pop_id = bp.ihms_pop_id
                left join ihms_pop_info ipi on ipi.pop_id = ip.pop_id
                left join ihms_idc ii on ipi.idc_id = ii.idc_id
                left join ihms_city ic on ii.city_id = ic.city_id
                left join mproxy_pop_status mps on bp.pop_id = mps.pop_id
            where me.mproxy_edge_id in (%s)
            order by me.mproxy_edge_id, me.domain_edge_id, vs.pop_name
            """

    format_strings = ','.join(map(lambda x: '%s', edge_list))
    sql = sql % (kind, kind, kind, format_strings)
    params = []
    params.extend(edge_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, tuple(params))
    rs = cursor.fetchall()

    for obj in rs:
        if not mproxy_pop_info.has_key(obj[0]):
            mproxy_pop_info[obj[0]] = []

        list_len = len(mproxy_pop_info[obj[0]])
        if list_len > 0:
            # duplicate pop check
            if mproxy_pop_info[obj[0]][list_len-1]['pop_name'] == obj[4]:
                mproxy_pop_info[obj[0]][list_len-1]['vips'].append({"ip":obj[5]})
            else:
                mproxy_pop_info[obj[0]].append({"mproxy_edge_id":obj[0],
                                        "%s_domain_id"%(kind):obj[1],
                                        "%s_domain_name"%(kind):obj[2],
                                        "pop_id":obj[3],
                                        "pop_name":obj[4],
                                        "city_name":obj[6],
                                        "pop_status":obj[7],
                                        "vips":[{"ip":obj[5]}]
                                        })
        else:
            mproxy_pop_info[obj[0]].append({"mproxy_edge_id":obj[0],
                                        "%s_domain_id"%(kind):obj[1],
                                        "%s_domain_name"%(kind):obj[2],
                                        "pop_id":obj[3],
                                        "pop_name":obj[4],
                                        "city_name":obj[6],
                                        "pop_status":obj[7],
                                        "vips":[{"ip":obj[5]}]
                                        })

    return mproxy_pop_info

def get_mproxy_edge_list(edge_list):
    mproxy_edge_info = {}
    where_str = ""

    if len(edge_list) <= 0:
        return mproxy_edge_info

    sql = """
            SELECT
                me.mproxy_edge_id,
                me.domain_edge_id,
                bp.pop_id, vs.pop_name, vs.ip,
                if(isnull(ic.city_name), 
                    (select airport_city from spectrum.airport where upper(substring_index(vs.pop_name,'-',-1)) = airport_iata limit 1), 
                    ic.city_name) as city_name,
                mps.pop_status
            FROM mproxy_edge me
                left join gslb_domain_edge gde on me.domain_edge_id = gde.domain_edge_id
                left join base_vip_edge bve on gde.edge_id = bve.edge_id
                left join base_vip bv on bve.vip_id = bv.vip_id
                left join base_vip_search vs on bv.vip_id = vs.vip_id
                left join ihms_pop ip on vs.pop_name = ip.pop_code
                left join base_pop bp on vs.pop_name = bp.pop_name or ip.pop_id = bp.ihms_pop_id
                left join ihms_pop_info ipi on ipi.pop_id = ip.pop_id
                left join ihms_idc ii on ipi.idc_id = ii.idc_id
                left join ihms_city ic on ii.city_id = ic.city_id
                left join mproxy_pop_status mps on bp.pop_id = mps.pop_id
            where me.mproxy_edge_id in (%s)
            order by me.mproxy_edge_id, me.domain_edge_id, vs.pop_name
            """

    format_strings = ','.join(map(lambda x: '%s', edge_list))
    sql = sql % (format_strings)
    params = []
    params.extend(edge_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, tuple(params))
    rs = cursor.fetchall()

    for obj in rs:
        if not mproxy_edge_info.has_key(obj[0]):
            mproxy_edge_info[obj[0]] = []

        list_len = len(mproxy_edge_info[obj[0]])
        if list_len > 0:
            # duplicate pop check
            if mproxy_edge_info[obj[0]][list_len-1]['pop_id'] == obj[2]:
                mproxy_edge_info[obj[0]][list_len-1]['vips'].append({"ip":obj[4]})
            else:
                mproxy_edge_info[obj[0]].append({"mproxy_edge_id":obj[0],
                                        "domain_edge_id":obj[1],
                                        "pop_id":obj[2],
                                        "pop_name":obj[3],
                                        "city_name":obj[5],
                                        "pop_status":obj[6],
                                        "vips":[{"ip":obj[4]}]
                                        })
        else:
            mproxy_edge_info[obj[0]].append({"mproxy_edge_id":obj[0],
                                        "domain_edge_id":obj[1],
                                        "pop_id":obj[2],
                                        "pop_name":obj[3],
                                        "city_name":obj[5],
                                        "pop_status":obj[6],
                                        "vips":[{"ip":obj[4]}]
                                        })

    return mproxy_edge_info
# END DNA 2.3 - Monitoring Routing Path Page
# DNA 2.3 - Monitoring Alert Page
def get_mproxy_simple_list(keywords_list, account_no, material_no):
    mproxy_info = []
    where_str = ""

    if len(keywords_list) <= 0:
        return mproxy_info

    if account_no:
        where_str = " and cd.account_no = %s " %(account_no)

    sql = """
            SELECT
                sm.stat_id, 
                sm.display_name, 
                sm.material_no, 
                sm.customer_id as customer,
                cd.account_no as account,
                ma.mproxy_app_id, 
                ma.mproxy_app_name,
                if(isnull(ma.mproxy_app_id), True, False) as is_deleted
            FROM stat_master sm
                left join mproxy_app ma on sm.display_name = ma.mproxy_app_name
                left join customer_display cd on sm.customer_id = cd.customer_id
            WHERE sm.material_no = %s and ma.mproxy_app_id is not null
                and sm.display_name in (%s)
                %s
            order by sm.stat_id
            """

    format_strings = ','.join(map(lambda x: '%s', keywords_list))
    sql = sql % ('%s', format_strings, where_str)
    params = []
    params.append(material_no)
    params.extend(keywords_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, tuple(params))
    fieldnames = [name[0] for name in cursor.description]
    rs = cursor.fetchall()

    for obj in rs:
        rowset = []
        for field in zip(fieldnames, obj):
            rowset.append((field[0], field[1]))
        mproxy_info.append(dict(rowset))

    return mproxy_info
# END DNA 2.3 - Monitoring Alert Page

def get_dynamic_relay_pop_list(pop_name):
    relay_pop_info = []
    where_str = ""

    if pop_name is not '':
        where_str = " and (bp.pop_name like %s or ihp.pop_code like %s) "

    sql = """
            select distinct
                bp.pop_id AS pop_id,
                if(isnull(bp.ihms_pop_id), bp.pop_name, ihp.pop_code) AS pop_name,
                ihc.country_id AS country_id,
                ihc.country_name AS country_name,
                if(isnull(bp.enable_gslb), 0, 1) AS pop_enable_gslb,
                count(mvs.vip_id) as avaliable_count,
                count(h.host_id) as total_count
            from
                prism.base_vip v
                left join prism.mproxy_vip_status mvs on (v.vip_id = mvs.vip_id and mvs.vip_status in (0, 1))
                left join prism.base_vip_probe bvp ON v.vip_id = bvp.vip_id
                join prism.base_host h on v.host_id = h.host_id
                join prism.base_host_role rh ON h.host_id = rh.host_id
                join prism.base_role r ON rh.role_id = r.role_id
                join prism.base_system s ON h.system_id = s.system_id
                join prism.base_pop bp ON s.pop_id = bp.pop_id
                left join prism.ihms_pop ihp ON bp.ihms_pop_id = ihp.pop_id
                left join prism.ihms_pop_info ihi ON ihi.pop_id = ihp.pop_id
                left join prism.ihms_country ihc ON ihc.country_id = ihi.country_id
            where r.role_name = 'MPROXY'
                and bvp.probe_id = 29
                %s
            group by bp.pop_id
            order by ihc.country_name, ihp.pop_code, bp.pop_name
            """ % where_str
    cursor = connections['default'].cursor()

    param = '%' + pop_name + '%'
    if pop_name is not '':
        cursor.execute(sql, [param, param])
    else:
        cursor.execute(sql)

    rs = cursor.fetchall()

    for obj in rs:
        relay_pop_info.append({
                                "pop_id":obj[0],
                                "pop_name":obj[1],
                                "country_id":obj[2],
                                "country_name":obj[3],
                                "pop_enable_gslb":obj[4],
                                "avaliable_count":obj[5],
                                "total_count":obj[6]
                                })

    return relay_pop_info

class DynamicRelayPopsAPI(ListModelMixin, SpectrumGenericAPIView):
    def get(self, request, *args, **kwargs):
        try:
            pop_name = str(request.QUERY_PARAMS.get('pop_name', ''))
        except:
            pop_name = ''

        relay_pop_items = get_dynamic_relay_pop_list(pop_name)

        pops_list = [{'pop':items['pop_id'],
                      'pop_name':items['pop_name'],
                      'country_id':items['country_id'],
                      'country_name':items['country_name'],
                      'relay_status':items['pop_enable_gslb'],
                      'avaliable_count':items['avaliable_count'],
                      'total_count':items['total_count']} for items in relay_pop_items]

        return Response(pops_list)


class MproxyEdgeRelayRouteAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset=MproxyDomainEdge.objects.all()
    lookup_url_kwarg = 'mproxy_edge_id'
    filter_fields = (lookup_url_kwarg)
    """
    /mproxy_edge/1/relay_route/
    """
    def get(self, request, *args, **kwargs):
        mproxy_edge = super(MproxyEdgeRelayRouteAPI, self).get_object()
        try:
            edge_pop_code = str(request.QUERY_PARAMS.get('edge_pop_code', ''))
        except:
            edge_pop_code = ''
        cache_key = "mproxy_edge_relay_route_%s_%s" % (str(mproxy_edge.pk), edge_pop_code)
        try:
            route_list = cache.get(cache_key)
        except:
            route_list = None

        if len(edge_pop_code.strip()) > 0:
            if route_list is None:
                ipdict = get_ip_pop_dicts()
                route_list = mproxy_edge.get_relay_route(edge_pop_code.strip(),ipdict)
                cache.set(cache_key,route_list,5)
            return Response(route_list[0])
        else:
            if route_list is None:
                ipdict = get_ip_pop_dicts()
                route_list = mproxy_edge.get_relay_route(None, ipdict)
                cache.set(cache_key,route_list,5)
            return Response(route_list)

class MproxyAppRelayRouteAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset=MproxyApp.objects.all()
    lookup_url_kwarg = __MPROXYAPP_URL_LOOKUP_KEY__
    filter_fields = (lookup_url_kwarg)
    def get(self, request, *args, **kwargs):
        mproxy_app = super(MproxyAppRelayRouteAPI, self).get_object()
        cache_key = "mproxy_app_relay_route_%s" % (str(mproxy_app.pk))
        try:
            route_list = cache.get(cache_key)
        except:
            route_list = None

        if route_list is None:
            route_list = []
            mproxy_edges = mproxy_app.get_mproxyedges()
            ipdict = get_ip_pop_dicts()
            for mproxy_edge in mproxy_edges:
                route_list.extend(mproxy_edge.get_relay_route(None,ipdict))
            cache.set(cache_key, route_list, 5)
        return Response(route_list)

# DNA 2.3 - Monitoring Alert Page
class MproxyAlertManagementAPI(ListModelMixin, 
                               CreateModelMixin,
                               SpectrumGenericAPIView):
    queryset = MproxyAlertManagement.objects.all()
    serializer_class = MproxyAlertManangemnetSerializer
    lookup_url_kwarg = __ALERT_MANANGEMENT_URL_LOOKUP_KEY__
    ordering = '-alert_id'

    def get_queryset(self):
        filter_kwargs = {}
        queryset = self.queryset

        account_no = self.request.GET.get('account_no', None)
        keywords_list = self.request.GET.getlist('stat_item_keywords')
        if account_no:
            filter_kwargs = {"account": account_no}

        if len(filter_kwargs) > 0:
            queryset = queryset.filter(**filter_kwargs)

        if len(keywords_list) > 0:
            queryset = queryset.filter(stat_master__keyword__in=keywords_list)

        return queryset

    def get(self, request, *args, **kwargs):
        return super(MproxyAlertManagementAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(MproxyAlertManagementAPI, self).create(request, *args, **kwargs)

class MproxyAlertManangementDetailAPI(RetrieveModelMixin,
                                    UpdateModelMixin,
                                    DestroyModelMixin,
                                    SpectrumGenericAPIView):
    queryset = MproxyAlertManagement.objects.all()
    serializer_class = MproxyAlertManangemnetSerializer
    lookup_url_kwarg = __ALERT_MANANGEMENT_URL_LOOKUP_KEY__

    def get(self, request, *args, **kwargs):
        return super(MproxyAlertManangementDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(MproxyAlertManangementDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(MproxyAlertManangementDetailAPI, self).partial_update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        return super(MproxyAlertManangementDetailAPI, self).destroy(request, *args, **kwargs)

class AlertMproxyAppSimpleAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = MproxyApp.objects.all()
    serializer_class = AlertMproxyAppSimpleSerializer
    lookup_url_kwarg = __MPROXYAPP_URL_LOOKUP_KEY__
    ordering = 'mproxy_app_id'

    def get_queryset(self):
        queryset = self.queryset

        account_no = self.request.GET.get('account_no', None)
        keywords_list = self.request.GET.getlist('stat_item_keywords')
        if account_no:
            queryset = queryset.filter(customer__account__account_no=account_no)

        queryset = queryset.filter(mproxy_app_name__in=keywords_list)

        return queryset

    def get(self, request, *args, **kwargs):
        return super(AlertMproxyAppSimpleAPI, self).list(request, *args, **kwargs)
    
class AlertMproxyAppStatSimpleAPI(ListModelMixin, SpectrumGenericAPIView):
    def get(self, request, *args, **kwargs):
        mproxy_app_info = []

        account_no = self.request.GET.get('account_no', None)
        keywords_list = self.request.GET.getlist('stat_item_keywords')
        material_no = settings.DNA_MATERIAL

        mpoxyapp_simple_list = get_mproxy_simple_list(keywords_list, account_no, material_no)

        mproxy_app_info = [{'stat_id':mproxyapp['stat_id'],
                            'display_name':mproxyapp['display_name'],
                            'customer':mproxyapp['customer'],
                            'account':mproxyapp['account'],
                            'mproxy_app_id':mproxyapp['mproxy_app_id'],
                            'mproxy_app_name': mproxyapp['mproxy_app_name'],
                            'is_deleted': mproxyapp['is_deleted']} for mproxyapp in mpoxyapp_simple_list]

        return Response(mproxy_app_info)


class MproxyAlertHistoryAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = MproxyAlertHistory.objects.all()
    serializer_class = MproxyAlertHistorySerializer
    lookup_url_kwarg = __ALERT_MANANGEMENT_URL_LOOKUP_KEY__
    filter_fields = ('update_time',)
    ordering = '-update_time'

    def get_queryset(self):
        filter_kwargs = {}
        queryset = self.queryset

        account_no = self.request.GET.get('account_no', None)
        stat_ids = self.request.GET.getlist('stat_item_ids')
        if account_no:
            queryset = queryset.filter(alert__account__account_no=account_no)

        queryset = queryset.filter(statmaster__in=stat_ids)

        return queryset

    def get(self, request, *args, **kwargs):
        return super(MproxyAlertHistoryAPI, self).list(request, *args, **kwargs)


# DNA 2.3 - Monitoring Routing Path Page
class MproxyAppsMonitorAPI(RetrieveModelMixin, SpectrumGenericAPIView):
    def get(self, request, *args, **kwargs):
        mproxy_app_id = self.kwargs.get('mproxy_app_id', None)
        mproxy_info = {}

        service_list = get_mproxy_service_list(mproxy_app_id)

        if len(service_list) > 0:
            try:
                edges = [int(service['mproxy_edge_id']) for service in service_list]
            except:
                raise MproxyEdgeDoesNotExist

            mproxy_info = {"mproxy_app_id":mproxy_app_id, 
                           "mproxy_app_name":service_list[0]['mproxy_app_name'], 
                           "services":[{'mproxy_edge_id':service['mproxy_edge_id'],
                                      'domain_edge_id':service['domain_edge_id'],
                                      'edge_id':service['edge_id'],
                                      'edge_name':service['edge_name'],
                                      'edge_domain_id':service['edge_domain_id'],
                                      'edge_domain_name': service['edge_domain_name'],
                                      'origin_domain_id':service['origin_domain_id'],
                                      'shield_domain_id':service['shield_domain_id'],
                                      'relay_domain_id':service['relay_domain_id'],
                                      'dynamic_relay':service['dynamic_relay'],
                                      'external_domain_enabled':service['external_domain_enabled'],
                                      'external_domain':service['external_domain'],
                                      'port':service['port'],
                                      'protocol':service['protocol'],
                                      'displayname':service['displayname'],
                                      'mproxy_preset_id':service['mproxy_preset_id'],
                                      'edges':[],
                                      'relays':[],
                                      'shields':[],
                                      'origins':[],
                                      'dynamics':[]} for service in service_list]}

            edge_list = get_mproxy_edge_list(edges)
            relay_list = get_mproxy_pop_list(edges, 'relay')
            shield_list = get_mproxy_pop_list(edges, 'shield')
            origin_list = get_mproxy_pop_list(edges, 'origin')

            for data in mproxy_info['services']:
                # city name duplicate => Seoul(2), Seoul(3)
                edge_city_chk = {}
                relay_city_chk = {}
                shield_city_chk = {}
                origin_city_chk = {}
                if edge_list.has_key(data['mproxy_edge_id']):
                    for edge in edge_list[data['mproxy_edge_id']]:
                        if edge['city_name'] in edge_city_chk.keys():
                            edge_city_chk[edge['city_name']] = edge_city_chk[edge['city_name']] + 1
                            edge['city_name'] = str(edge['city_name']) + '(' + str(edge_city_chk[edge['city_name']]) + ')'
                        else:
                            edge_city_chk.update({edge['city_name']:1})

                    data['edges'] = [{'domain_edge_id': edge['domain_edge_id'],
                                      'pop_id': edge['pop_id'],
                                      'pop_name': edge['pop_name'],
                                      'city_name': edge['city_name'],
                                      'pop_status': edge['pop_status'],
                                      'vips': edge['vips']
                                      } for edge in edge_list[data['mproxy_edge_id']]]
                else:
                    data['edges'] = []

                if relay_list.has_key(data['mproxy_edge_id']):
                    for relay in relay_list[data['mproxy_edge_id']]:
                        if relay['city_name'] in relay_city_chk.keys():
                            relay_city_chk[relay['city_name']] = relay_city_chk[relay['city_name']] + 1
                            relay['city_name'] = str(relay['city_name']) + '(' + str(relay_city_chk[relay['city_name']]) + ')'
                        else:
                            relay_city_chk.update({relay['city_name']:1})

                    data['relays'] = [{'relay_domain_id': relay['relay_domain_id'],
                                      'relay_domain_name': relay['relay_domain_name'],
                                      'pop_id': relay['pop_id'],
                                      'pop_name': relay['pop_name'],
                                      'city_name': relay['city_name'],
                                      'pop_status': edge['pop_status'],
                                      'vips': relay['vips']
                                      } for relay in relay_list[data['mproxy_edge_id']]]
                else:
                    data['relays'] = []

                if shield_list.has_key(data['mproxy_edge_id']):
                    for shield in shield_list[data['mproxy_edge_id']]:
                        if shield['city_name'] in shield_city_chk.keys():
                            shield_city_chk[shield['city_name']] = shield_city_chk[shield['city_name']] + 1
                            shield['city_name'] = str(shield['city_name']) + '(' + str(shield_city_chk[shield['city_name']]) + ')'
                        else:
                            shield_city_chk.update({shield['city_name']:1})

                    data['shields'] = [{'shield_domain_id': shield['shield_domain_id'],
                                      'shield_domain_name': shield['shield_domain_name'],
                                      'pop_id': shield['pop_id'],
                                      'pop_name': shield['pop_name'],
                                      'city_name': shield['city_name'],
                                      'pop_status': edge['pop_status'],
                                      'vips': shield['vips']
                                      } for shield in shield_list[data['mproxy_edge_id']]]
                else:
                    data['shields'] = []

                if origin_list.has_key(data['mproxy_edge_id']):
                    for origin in origin_list[data['mproxy_edge_id']]:
                        if origin['city_name'] in origin_city_chk.keys():
                            origin_city_chk[origin['city_name']] = origin_city_chk[origin['city_name']] + 1
                            origin['city_name'] = str(origin['city_name']) + '(' + str(origin_city_chk[origin['city_name']]) + ')'
                        else:
                            origin_city_chk.update({origin['city_name']:1})

                    data['origins'] = [{'origin_domain_id': origin['origin_domain_id'],
                                      'origin_domain_name': origin['origin_domain_name'],
                                      'pop_id': origin['pop_id'],
                                      'pop_name': origin['pop_name'],
                                      'city_name': origin['city_name'],
                                      'pop_status': edge['pop_status'],
                                      'vips': origin['vips']
                                      } for origin in origin_list[data['mproxy_edge_id']]]
                else:
                    data['origins'] = []

        return Response(mproxy_info)
