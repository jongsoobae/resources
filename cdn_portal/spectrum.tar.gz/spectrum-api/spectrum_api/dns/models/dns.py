from datetime import datetime, timedelta
from django.db import models
from django.db.models import Q
from spectrum_api.shared_components.models import BaseModel, HistoryModel
from spectrum_api.configuration.models import Model
from spectrum_api.configuration.models.base import Vip, Pop
from spectrum_api.shared_components.models import StatMaster
from spectrum_api.shared_components.models.customer import CustomerDisplay, CustomerItem
from django.utils.translation import ugettext_lazy as _

TIMEOUT = 30  # minutes
DEFAULT_SOA_EMAIL = "dnsadmin@cdnetworks.com"
DEFAULT_NS = ('ns1.cdnetdns.net', 'ns2.cdnetdns.net')
DEFAULT_STAGING_NS = ('staging.cdnetdns.net',)

class InvalidAction(Exception):
    """ CUSTOM EXCEPTION HANDLING """
    def __init__(self, msg=None):
        if msg is None:
            msg = _(u"This zone is in pending state, please wait until it completes.")
        super(InvalidAction, self).__init__(msg)

class InvalidAccount(Exception):
    """ AURORA: CUSTOM EXCEPTION HANDLING FOR INVALID ACCOUNT """
    def __init__(self, msg=None):
        if msg is None:
            msg = _(u"Your account is invalid. Please contact our support at support@cdnetworks.com.")
        super(InvalidAccount, self).__init__(msg)

ZONE_STATUS = (
            (0, 'Modified'),
            (1, 'Pending Testing'),
            (2, 'Sent to Stage'),
            (3, 'Promote to Production'),
            (4, 'In Production'),
            (-2, 'Pending Failed'),
            (-4, 'Production Failed'),
)
class DNSZone(HistoryModel):
    zone_id = models.AutoField(primary_key=True)
    domain_name = models.CharField(max_length=255, unique=True)
    ttl = models.IntegerField(default=86400)
    obj_state = models.PositiveSmallIntegerField(default=1)
    status = models.PositiveSmallIntegerField(default=0, choices=ZONE_STATUS)
    time_updated = models.DateTimeField(auto_now=True, auto_now_add=True)
    time_deployed = models.DateTimeField(null=True)
    customer = models.ForeignKey(CustomerDisplay, db_column='customer_id')
    # stat = models.ManyToManyField(StatMaster, db_table='dns_zone_stat_master', related_name='dnszone_set')

    class Meta:
        db_table = 'dns_zone'
        ordering = ['domain_name']
        verbose_name = 'DNS Zone'

    class SpectrumMeta:
        track = True
        keep_latest_change_action_id = True
        log_diff_skip_fields = ['status']

    def __unicode__(self):
        return self.domain_name

    def get_zone_attrib(self):
        try:
            item = {'zone_id': str(self.zone_id),
                     'domain_name': self.domain_name,
                     'ttl': str(self.ttl),
                     'status': str(self.status)
                     # 'customer': self.customer
                     }
        except:
            item = None
        return item


    def get_timeout(self):
        # compare time
        right_now = datetime.now()
        dns_updated = self.time_updated
        time2compare = timedelta(minutes=TIMEOUT)

        timeout = False
        if (right_now - dns_updated) > time2compare:
            timeout = True
        return timeout

    def get_statmaster(self):
        statmaster = None
        try:
            dnsstatmasters = DNSStatMaster.objects.filter(dnszone=self)
            if dnsstatmasters:
                statmaster = dnsstatmasters[0].statmaster
        except:
            pass
        return statmaster

    def get_statmasterid(self):
        statmasterid = None
        try:
            dnsstatmasters = DNSStatMaster.objects.filter(dnszone=self)
            if dnsstatmasters:
                statmasterid = dnsstatmasters[0].statmaster.pk
        except:
            pass
        return statmasterid

    def get_statmaster_objstate(self):
        statmaster_objstate = None
        try:
            dnsstatmasters = DNSStatMaster.objects.filter(dnszone=self)
            if dnsstatmasters:
                statmaster_objstate = dnsstatmasters[0].statmaster.obj_state
        except:
            pass
        return statmaster_objstate

    def get_itemid(self):
        itemid = None
        try:
            dnsstatmasters = DNSStatMaster.objects.filter(dnszone=self)
            if dnsstatmasters:
                itemid = dnsstatmasters[0].statmaster.item.item_id
        except:
            pass
        return itemid

    def get_contractname(self):
        contractname = None
        try:
            dnsstatmasters = DNSStatMaster.objects.filter(dnszone=self)
            if dnsstatmasters:
                contractname = dnsstatmasters[0].statmaster.item.contract.contract_name
        except:
            pass
        return contractname

    def is_modifiable(self):
        '''if zone deploy status is 'pending testing' or 'promote to production', interpreted as 'locked', it won't be modifiable
        '''
        if not (self.status == 1 or self.status == 3):
            return True
        else:  # 1,3
            # if self.obj_state != 0 and settings.DEBUG and self.get_timeout(): #this generally not happen at production servers where be_config running all the time. Bug in dev environment where be_config not running, this needs to be accounted.
            #    return True
            return False

    def get_clb_domains(self):
        from spectrum_api.dna.models.domain import Domain
        clb_domains = Domain.objects.filter(clb_dns_zone=self)
        return clb_domains

    def get_related_domain_deploy_status_text(self):
        msg = ''
        if self.get_clb_domains().exists():
            domain_deploy_status, deploy_failed_domains = self.get_clb_domain_deploy_status()
            if domain_deploy_status < 0:
                msg = "(related domain deploy failed)"

            if self.is_related_clb_domain_pending():
                msg = "(related domain deploy pending)"
        return msg

    def get_deploy_status(self):
        ''' return zone deploy status. if zone has clb domains, domain status will also be accounted.
        '''
        deploy_status = self.status
        gslb_deploy_status, deploy_failed_domains = self.get_clb_domain_deploy_status()
        if deploy_status > gslb_deploy_status:
            deploy_status = gslb_deploy_status
        return deploy_status, deploy_failed_domains

    def get_clb_domain_deploy_status(self):
        ''' retrun minimun domain_status among self.clb_domains, deploy_failed_domains as list
        '''
        domain_status = self.status  # if not having clb domains, it should return zone status
        deploy_failed_domains = []
        clb_domains = self.get_clb_domains()

        for clb_domain in clb_domains:
            if clb_domain.status < 0:
                deploy_failed_domains.append(clb_domain.name)
            if clb_domain.status < domain_status:
                domain_status = clb_domain.status
        return domain_status, deploy_failed_domains

    def is_related_clb_domain_pending(self):
        clb_domains = self.get_clb_domains()
        for clb_domain in clb_domains:
            # zone_status = int(clb_zone.status)
            if clb_domain.status == 1 or clb_domain.status == 3:
                return True
        return False

    def get_clb_servergroups(self):
        from spectrum_api.configuration.models.clb import CustomerContractPop
        cust_clb_pop_list = CustomerContractPop.all_objects.filter(use_type=1).all()
        cust_clb_pop_list = cust_clb_pop_list.filter(customer=self.customer)
        return cust_clb_pop_list

    def get_myinfra_deploy_status(self):
        pop_status = 4
        clb_pops = self.get_clb_servergroups()
        for clb_pop in clb_pops:
            if int(clb_pop.pop.status) < pop_status:
                pop_status = int(clb_pop.pop.status)
        return pop_status

    def get_myinfra_deploy_timeout(self):
        pop_status = 4
        timeout = False
        clb_pops = self.get_clb_servergroups()
        for clb_pop in clb_pops:
            if int(clb_pop.pop.status) < pop_status:
                pop_status = int(clb_pop.pop.status)
                timeout = clb_pop.pop.get_timeout()
        return timeout

    def snapshot_of_base_relation(self):
        """
        Make snapshot of between zone (clb domains) and related POP
        """
        from spectrum_api.dna.models.domain import DomainVip, BasePopDNSZoneRelation
        from spectrum_api.configuration.models.base import Vip, Pop

        # cleanup snapshot production zones
        try:
            cleanup = BasePopDNSZoneRelation.objects.select_related('zone')\
                                    .filter(zone__customer=self.customer, zone__status=4)\
                                    .delete()
        except:
            #ignore cleanup
            pass

        domainvips = DomainVip.objects.select_related('domain__clb_dns_zone')\
                                .filter(domain__clb_dns_zone=self)\
                                .distinct('vip')
        if domainvips.exists():
            related_vips = [d.vip.pk for d in domainvips]
            pops = Pop.objects.filter(system__host__vip_host_set__vip__in=related_vips)\
                            .distinct('pop')

            for pop in pops:
                try:
                    rel = BasePopDNSZoneRelation(pop=pop, zone=self)
                    rel.save()
                except:
                    pass

    def has_clb_contract(self):
        CLB_MATERIAL = 1199
        if self.customer:
            # should include invalid contract
            contracts = CustomerItem.all_objects.filter(Q(contract__account__account_no=self.customer.account.account_no),
                                                    Q(material_no=CLB_MATERIAL))
            return contracts.exists()
        else:
            return False

    def save(self, *args, **kwargs):
        track = kwargs.pop('track', True)
        if not track:
            self.SpectrumMeta.track = False

        push = kwargs.pop('push', None)
        customer = kwargs.pop('customer', None)
        contract_no = kwargs.pop('contract_no', None)
        user = kwargs.pop('user', None)
        product = kwargs.pop('product', None)
        overwrite_lock = kwargs.pop('overwrite_soa_lock', False)

        status_msg = ''

        allow_saving = kwargs.pop('allow_saving', False)
        if not (self.status == 1 or self.status == 3) and not self.pk:
            pass
        elif self.is_modifiable():
            try:
                # for previous status check.
                from spectrum_api.dns.models.dns import DNSZone as oDNSZone
                _dnszone = oDNSZone.all_objects.get(pk=self.pk)
                if _dnszone.status in (2, 4):
                    try:
                        self.snapshot_of_base_relation()
                    except:
                        pass
            except:
                pass

        super(DNSZone, self).save(*args, **kwargs)

class DNSStatMaster(HistoryModel):
    dnsstatmaster_id = models.AutoField(primary_key=True, db_column='id')
    dnszone = models.ForeignKey(DNSZone)
    statmaster = models.ForeignKey(StatMaster)

    def __unicode__(self):
        return '%s' % (self.dnszone)

    class Meta:
        app_label = 'dns'
        db_table = 'dns_zone_stat_master'

    class SpectrumMeta:
        parent = 'dnszone'
        allow_delete = True

    def clean(self):
        pass
