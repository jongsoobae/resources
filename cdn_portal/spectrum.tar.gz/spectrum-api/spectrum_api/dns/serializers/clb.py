# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        CLB Domain Serializer
"""

import re
import copy
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db.models import F, Q
from django.utils.translation import ugettext as _
from django.core.exceptions import ObjectDoesNotExist
from rest_framework import serializers
from rest_framework.exceptions import APIException
from rest_framework.status import HTTP_404_NOT_FOUND, HTTP_412_PRECONDITION_FAILED
from rest_framework.fields import get_component, is_simple_callable
from spectrum_api.shared_components.fields import MultipleChoiceField
from spectrum_api.shared_components.utils.common import notice_operator_event_email
from spectrum_api.shared_components.utils.user_util import is_request_from_aurora
from spectrum_api.configuration.models.base import Vip, BaseProbeConfig
from spectrum_api.dna.models.domain import DomainVip, Domain, DomainStaticRuleCondition,\
    DomainStaticRuleAction, DomainVip,\
    STATIC_RULE_CONDITION_TYPE, STATIC_RULE_ACTION_TYPE, LB_TYPES

from spectrum_api.dna.models.stats import DnaLocationContinentMap, DnaLocationCountryMap,\
    DnaLocationRegionMap, DnaLocationIspMap
from spectrum_api.dns.models.dns import DNSZone
from spectrum_api.dna.models.regex import regex_host_ns, regex_ip, regex_ip_cidr, regex_cname_policy
from spectrum_api.dns.serializers.myinfra import ServerProbeSerializer
from spectrum_api.shared_components.models import log_queryset_delete


GSLB_CHOICES = (
    (0, 'GSLB'),
    (1, 'RR'),
    (2, 'RANDOM'),
)
CONDITION_CHOICES = (('1', 'IP Range',), ('2', 'Geo data',), ('3', '%',))
GEO_TYPE_CHOICES = (('0', 'country',), ('1', 'continent',), ('2', 'region',), ('3', 'isp',))
STATUS_CHOICES = ((0, 'Disabled',), (1, 'Enabled',))
ETC_POLICY_CHOICES = ((0, 'Dynamic Selection From All IPs'), (1, 'Fixed Record'), (2, 'Deny'),)

__SPLITER__ = ","
__SEQ_MAX__ = 2147483647
__CONDITION_TYPE_OF_IPRANGE__ = 0
__CONDITION_TYPE_OF_GEO__ = 1
__CONDITION_TYPE_OF_PERCENT__ = 2

# conditions
__PREFIX_COND_IPRANGE_POLICY__ = "client.ip"
__PREFIX_COND_GEO_CONTINENT__ = "client.continent"
__PREFIX_COND_GEO_COUNTRY__ = "client.country"
__PREFIX_COND_GEO_REGION__ = "client.region"
__PREFIX_COND_GEO_ISP__ = "client.isp"
__PREFIX_COND_GEO_ASN__ = "client.asn"
__PREFIX_COND_PERCENT_POLICY__ = "request.portion"
__PREFIX_COND_ETC_POLICY__ = "always"

__PREFIX_COND_GEO_POLICY__ = (__PREFIX_COND_GEO_CONTINENT__,
                              __PREFIX_COND_GEO_COUNTRY__,
                              __PREFIX_COND_GEO_REGION__,
                              __PREFIX_COND_GEO_ISP__,
                              __PREFIX_COND_GEO_ASN__,)

__ACTION_TYPE_OF_DENY__ = 0
__ACTION_TYPE_OF_VIP__ = 1
__ACTION_TYPE_OF_SET_CNAME__ = 2
__ACTION_TYPE_OF_SET_A__ = 3

# actions
__PREFIX_ACT_VIP__ = 'system.vip'  # 1
__PREFIX_ACT_SET__ = 'response.answer'  # 2(cname),3(ip)
__PREFIX_ACT_DENY__ = 'ignore'  # 0

re_ip = re.compile(r"^client.ip\s*=\s*(.*)", re.IGNORECASE | re.MULTILINE)
re_geo_condition = re.compile(r"^client.(continent|country|region|isp|asn)\s*=\s*(.*)$", re.IGNORECASE | re.MULTILINE)
re_percent_condition = re.compile(r"^request.portion\s*=\s*(.*)", re.IGNORECASE | re.MULTILINE)
re_etc_condition = re.compile(r"^always", re.IGNORECASE | re.MULTILINE)

re_vip_action = re.compile(r"^system.vip\s*=\s*(.*)", re.IGNORECASE | re.MULTILINE)
re_set_action = re.compile(
    r"^response.answer\s*=\s*(?P<record_type>A|CNAME)\s*,\s*(?P<ttl>.*)\s*,\s*(?P<data>.*)", re.IGNORECASE | re.MULTILINE)
re_deny_action = re.compile(r"^ignore", re.IGNORECASE | re.MULTILINE)

CHOICE_RTYPE = (
    ("CNAME", "CNAME"),
    ("A", "A"),
)


def validate_host_name(host_name, regex_function, field=None):
    #host_name = self.cleaned_data[field_name]
    if not host_name or host_name == '':
        host_name = '@'

    if host_name != '@':
        if not regex_function.match(host_name):
            if field is not None:
                raise serializers.ValidationError({field: [_(u"'%(host_name)s' is not valid." % {"host_name":host_name})]})
            else:
                raise serializers.ValidationError(_(u"'%(host_name)s' is not valid." % {"host_name":host_name}))
    return host_name


class StaticRuleParseError(APIException):
    status_code = HTTP_404_NOT_FOUND
    default_detail = _(u"Occured an error when static rule parsing")

class UnableToLoadStatID(APIException):
    status_code = HTTP_412_PRECONDITION_FAILED
    default_detail = _(u"Multiple contract items are found when mapping with your configuration. Unable to determine which is right one. Please contact Customer Support Center.")

class CLBProbeSerializer(serializers.ModelSerializer):
    probe = serializers.IntegerField(source="probeconfig_id")
    probe_name = serializers.IntegerField(source="name")

    class Meta:
        model = BaseProbeConfig
        fields = ("probe",
                  "probe_name",
                  "description",)


class SubDomainVipSerializer(serializers.ModelSerializer):
    vip_name = serializers.RelatedField(source="vip", read_only=True)
    server_id = serializers.RelatedField(source="vip.vip")
    server_name = serializers.CharField(source="vip.vip_alias_name", read_only=True)
    probe_name = serializers.RelatedField(source="probe", read_only=True)
    ip = serializers.CharField(source="vip.vip_addr", read_only=True)
    is_active = serializers.SerializerMethodField('get_activate_state')
    group_id = serializers.SerializerMethodField('get_group_id')
    group_name = serializers.SerializerMethodField('get_group_name')
    region = serializers.SerializerMethodField('get_region')
    region_name = serializers.SerializerMethodField('get_region_name')
    healthcheckers = ServerProbeSerializer(source="vip.probeconfigs", read_only=True)

    class Meta:
        model = DomainVip
        fields = ("domain_vip_id",
                  "server_id",
                  "vip",
                  "vip_name",
                  "server_name",
                  "ip",
                  "is_active",
                  "group_id",
                  "group_name",
                  "region",
                  "region_name",
                  "healthcheckers",
                  "probe",
                  "probe_name",
                  #"probe_increment",
                  #"probe_scaling_factor",
                  #"weight",
                  #"priority",
                  )

    def get_identity(self, data):
        try:
            return data.get('domain_vip_id', None)
        except AttributeError:
            return None

    def from_native(self, data, files):
        if data.get("server_id", None) is not None \
            and data.get("vip", None) == None:
            data.update({"vip": data.get("server_id")})

        instance = super(SubDomainVipSerializer, self).from_native(data, files)
        return instance

    def get_activate_state(self, obj):
        try:
            group_state = obj.host.system.pop.customercontractpop_set.all()[0].obj_state

            if group_state is True and obj.enable_gslb == 1:
                state = True
            else:
                state = False
        except Exception as e:
            # logging
            state = False

        return state

    def get_region(self, obj):
        try:
            region = obj.vip.host.system.pop.customercontractpop_set.all()[0].region_id
        except Exception as e:
            # logging
            region = None
        return region

    def get_region_name(self, obj):
        try:
            region = obj.vip.host.system.pop.customercontractpop_set.all()[0].region.region_name
        except Exception as e:
            # logging
            region = ""
        return region

    def get_group_id(self, obj):
        try:
            group_id = obj.vip.host.system.pop.customercontractpop_set.all()[0].pk
        except Exception as e:
            # logging
            group_id = None
        return group_id

    def get_group_name(self, obj):
        try:
            group_name = obj.vip.host.system.pop.customercontractpop_set.all()[0].pop_alias
        except Exception as e:
            # logging
            group_name = ""
        return group_name

    def validate(self, attrs):
        vip = attrs["vip"]
        if not vip.host.system.pop.rttserver:
            try:
                group_name = vip.host.system.pop.customercontractpop_set.all()[0].pop_alias
            except:
                group_name = "%s"%(vip.host.system.pop)

            raise serializers.ValidationError({'__all__':[_("%s is mis-configured. Please ask to Technical support team." % group_name)],
                    "ip": [vip.vip_addr]})

        return attrs


class ActionResponseSerializer(serializers.Serializer):
    rtype = serializers.ChoiceField(choices=CHOICE_RTYPE)
    ttl = serializers.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(4294967295)],)
    data = serializers.CharField()

    def field_from_native(self, data, files, field_name, into):
        try:
            action_type = int(data["action_type"])
            value = data[field_name]
        except KeyError:
            action_type = None
            if self.default is not None and not self.partial:
                value = copy.deepcopy(self.default)
            else:
                if self.required:
                    raise self.ValidationError(self.error_messages['required'])
                return

        if action_type in (__ACTION_TYPE_OF_SET_CNAME__, __ACTION_TYPE_OF_SET_A__):
            obj = self.parent.object.get("answer", None) if self.parent.object else None

            if value in (None, '', []):
                into[field_name] = None
            else:
                if isinstance(value, list):
                    buf = []
                    for item in value:
                        if action_type == __ACTION_TYPE_OF_SET_CNAME__:
                            item["rtype"] = "CNAME"
                        elif action_type == __ACTION_TYPE_OF_SET_A__:
                            item["rtype"] = "A"
                        buf.append(item)
                    value = buf
                else:
                    pass

                kwargs = {
                    'instance': obj,
                    'data': value,
                    'context': self.context,
                    'partial': self.partial,
                    'many': self.many,
                    'allow_add_remove': self.allow_add_remove
                }
                serializer = self.__class__(**kwargs)

                if serializer.is_valid():
                    into[field_name] = serializer.object
                else:
                    raise serializers.NestedValidationError(serializer.errors)
        else:
            into[field_name] = None

    def validate_data(self, attrs,source):
        data = attrs.get(source,None)
        if data is not None:
            attrs[source] = data.strip()
        return attrs

    def validate(self, attrs):
        if attrs.get("rtype") == "CNAME":
            data_ = attrs.get("data", None)
            cname = data_.strip()

            if len(cname.strip()) == 0:
                raise serializers.ValidationError({"data": [_(u'This field is required.')]})

            cname = validate_host_name(attrs["data"], regex_cname_policy, "data")
            attrs["data"] = cname
        elif attrs.get("rtype") == "A":
            data_ = attrs.get("data", None)
            if regex_ip.match(data_):
                pass
            else:
                raise serializers.ValidationError({"data": [_(u"'%(data)s' is not valid ip address." % {"data":data_})]})
        return attrs


class ActionVipRelatedField(serializers.PrimaryKeyRelatedField):

    def field_to_native(self, obj, field_name):
        if self.many:
            # To-many relationship
            queryset = None
            if not self.source:
                # Prefer obj.serializable_value for performance reasons
                try:
                    #queryset = obj.serializable_value(field_name)
                    vips = obj.get("vip", None)
                    if vips is not None:
                        queryset = Vip.objects.filter(vip__in=vips)
                    else:
                        return None
                except AttributeError:
                    pass
            if queryset is None:
                # RelatedManager (reverse relationship)
                source = self.source or field_name
                queryset = obj
                for component in source.split('.'):
                    if queryset is None:
                        return []
                    queryset = get_component(queryset, component)

            # Forward relationship
            if is_simple_callable(getattr(queryset, 'all', None)):
                return [self.to_native(item.pk) for item in queryset.all()]
            else:
                # Also support non-queryset iterables.
                # This allows us to also support plain lists of related items.
                return [self.to_native(item.pk) for item in queryset]

        # To-one relationship
        try:
            # Prefer obj.serializable_value for performance reasons
            pk = obj.serializable_value(self.source or field_name)
        except AttributeError:
            # RelatedObject (reverse relationship)
            try:
                pk = getattr(obj, self.source or field_name).pk
            except (ObjectDoesNotExist, AttributeError):
                return None

        # Forward relationship
        return self.to_native(pk)


class EtcActionSerializer(serializers.Serializer):
    domain_staticrule_action_id = serializers.IntegerField(read_only=True)
    action_type = serializers.ChoiceField(choices=STATIC_RULE_ACTION_TYPE)
    sequence = serializers.IntegerField(required=False)
    condition_id = serializers.RelatedField(source="condition")
    vip = ActionVipRelatedField(many=True, required=False, queryset=Vip.objects.all())
    answer = ActionResponseSerializer(many=True, required=False, allow_add_remove=True)

    class Meta:
        model = DomainStaticRuleAction
        fields = ("domain_staticrule_action_id",
                  "action_type",
                  "sequence",
                  "condition_id",
                  "vip",
                  "answer",
                  )

    def get_identity(self, data):
        try:
            return data.get('domain_staticrule_action_id', None)
        except AttributeError:
            return None

    def field_from_native(self, data, files, field_name, into):
        try:
            value = data[field_name]
        except KeyError:
            if self.default is not None and not self.partial:
                value = copy.deepcopy(self.default)
            else:
                if self.required:
                    raise self.ValidationError(self.error_messages['required'])
                return

        if isinstance(self.parent.object, object):
            try:
                for item in parse_rule_action(self.parent.object.domainstaticruleaction_set.all()):
                    obj = item
            except:
                obj = None
        else:
            obj = self.parent.object.get("actions", None) if self.parent.object else None

        if (self.many and
            not hasattr(obj, '__iter__') and
            is_simple_callable(getattr(obj, 'all', None))):
            obj = obj.all()

        if self.source == '*':
            if value:
                reverted_data = self.restore_fields(value, {})
                if not self._errors:
                    into.update(reverted_data)
        else:
            if value in (None, '', []):
                into[field_name] = None
            else:
                kwargs = {
                    'instance': obj,
                    'data': value,
                    'context': self.context,
                    'partial': self.partial,
                    'many': self.many,
                    'allow_add_remove': self.allow_add_remove
                }
                serializer = self.__class__(**kwargs)

                if serializer.is_valid():
                    into[field_name] = serializer.object
                else:
                    raise serializers.NestedValidationError(serializer.errors)

    def validate(self, attrs):
        action_type = attrs.get("action_type")
        if action_type in (__ACTION_TYPE_OF_SET_CNAME__, __ACTION_TYPE_OF_SET_A__):
            pass
        elif action_type == __ACTION_TYPE_OF_DENY__:
            pass
        return attrs

    def from_native(self, data, files):
        if isinstance(data, list):
            buf = []
            for item in data:
                action_type = item.get("action_type", None)

                if action_type == __ACTION_TYPE_OF_VIP__:
                    item["answer"] = None
                elif action_type in (__ACTION_TYPE_OF_SET_CNAME__, __ACTION_TYPE_OF_SET_A__):
                    item["vip"] = None
                elif action_type == __ACTION_TYPE_OF_DENY__:
                    item["vip"] = None
                    item["answer"] = None
                data = item
        else:
            action_type = data.get("action_type", None)

            if action_type == __ACTION_TYPE_OF_VIP__:
                data["answer"] = None
            elif action_type in (__ACTION_TYPE_OF_SET_CNAME__, __ACTION_TYPE_OF_SET_A__):
                data["vip"] = None
            elif action_type == __ACTION_TYPE_OF_DENY__:
                data["vip"] = None
                data["answer"] = None

        return super(EtcActionSerializer, self).from_native(data, files)


class DomainEtcPolicySerializer(serializers.Serializer):
    domain_staticrule_condition_id = serializers.IntegerField(read_only=True)
    policy_name = serializers.CharField(default="always")
    condition_type = serializers.ChoiceField(choices=STATIC_RULE_CONDITION_TYPE)
    domain = serializers.RelatedField(source="domain")
    sequence = serializers.IntegerField(default=__SEQ_MAX__)
    is_enabled = serializers.BooleanField(required=False)
    invert = serializers.BooleanField(required=False)
    iprange = serializers.CharField(required=False)
    continent = MultipleChoiceField(required=False, choices=DnaLocationContinentMap.objects.filter(is_visible=True)
                                    .order_by('continent_name')
                                    .values_list('continent_name', 'continent_name'))
    country = MultipleChoiceField(required=False, choices=DnaLocationCountryMap.objects.filter(is_visible=True)
                                  .order_by('country_name')
                                  .values_list('ihms_country', 'country_name'))
    region = MultipleChoiceField(required=False, choices=DnaLocationRegionMap.objects.filter(is_visible=True)
                                 .order_by('region_name')
                                 .values_list('region_name', 'region_name'))
    isp = MultipleChoiceField(required=False, choices=DnaLocationIspMap.objects.filter(is_visible=True)
                              .order_by('isp_name')
                              .values_list('isp_name', 'isp_name'))
    asn = serializers.CharField(required=False)
    percent = serializers.IntegerField(required=False,)
    actions = EtcActionSerializer(many=True)

    class Meta:
        model = DomainStaticRuleCondition
        fields = ("domain_staticrule_condition_id",
                  "policy_name",
                  "condition_type",
                  "domain",
                  "sequence",
                  "is_enabled",
                  "invert",
                  "iprange",
                  "country",
                  "continent",
                  "region",
                  "isp",
                  "asn",
                  "percent",
                  "actions"
                  )

    def get_identity(self, data):
        try:
            return data.get('domain_staticrule_condition_id', None)
        except AttributeError:
            return None

    def from_native(self, data, files):
        if data is not None:
            if isinstance(data, list):
                data = data[0]
            dummy = build_etc_rule_set(data)
            data["policy_name"] = dummy["policy_name"]
            data["sequence"] = dummy["sequence"]
            data["condition_type"] = 0  # always
        return super(DomainEtcPolicySerializer, self).from_native(data, files)

    def field_from_native(self, data, files, field_name, into):
        try:
            value = data[field_name]
        except KeyError:
            if self.default is not None and not self.partial:
                value = copy.deepcopy(self.default)
            else:
                if self.required:
                    raise self.ValidationError(self.error_messages['required'])
                return

        obj = self.parent.object.etc_policy if self.parent.object else None

        if value in (None, '', []):
            into[field_name] = []
        else:
            if obj is not None:
                for rule_item in parse_rule_conditions(obj):
                    obj = rule_item
            else:
                obj = None

            kwargs = {
                'instance': [obj],
                'data': [value],
                'context': self.context,
                'partial': self.partial,
                'many': self.many,
                'allow_add_remove': self.allow_add_remove
            }
            serializer = self.__class__(**kwargs)

            if serializer.is_valid():
                into[field_name] = serializer.object
            else:
                raise serializers.NestedValidationError(serializer.errors)

    def vaildate_iprange(self, attrs, source):
        iprange = attrs.get(source, None)
        if iprange is not None:
            iprange = iprange.strip()
            attrs['iprange'] = iprange.strip()

        return attrs

    def validate(self, attrs):
        return attrs


class ActionSerializer(serializers.Serializer):
    domain_staticrule_action_id = serializers.IntegerField(read_only=True)
    action_type = serializers.ChoiceField(choices=STATIC_RULE_ACTION_TYPE)
    sequence = serializers.IntegerField(required=False)
    condition_id = serializers.RelatedField(source="condition")
    vip = ActionVipRelatedField(many=True, required=False, queryset=Vip.objects.all())
    answer = ActionResponseSerializer(many=True, required=False, allow_add_remove=True)

    class Meta:
        fields = ("domain_staticrule_action_id",
                  "action_type",
                  "sequence",
                  "condition_id",
                  "vip",
                  "answer",
                  )

    def field_from_native(self, data, files, field_name, into):
        try:
            value = data[field_name]
        except KeyError:
            if self.default is not None and not self.partial:
                value = copy.deepcopy(self.default)
            else:
                if self.required:
                    raise serializers.ValidationError(self.error_messages['required'])
                return

        obj = self.parent.object.get("actions", None) if self.parent.object else None

        if (self.many and
            not hasattr(obj, '__iter__') and
            is_simple_callable(getattr(obj, 'all', None))):
            obj = obj.all()

        if self.source == '*':
            if value:
                reverted_data = self.restore_fields(value, {})
                if not self._errors:
                    into.update(reverted_data)
        else:
            if value in (None, '', []):
                into[field_name] = []
            else:
                kwargs = {
                    'instance': obj,
                    'data': value,
                    'context': self.context,
                    'partial': self.partial,
                    'many': self.many,
                    'allow_add_remove': self.allow_add_remove
                }
                serializer = self.__class__(**kwargs)

                if serializer.is_valid():
                    into[field_name] = serializer.object
                else:
                    raise serializers.NestedValidationError(serializer.errors)

    def get_identity(self, data):
        try:
            return data.get('domain_staticrule_action_id', None)
        except AttributeError:
            return None

    def validate(self, attrs):
        action_type = attrs.get("action_type")
        if action_type == __ACTION_TYPE_OF_VIP__:
            vips = attrs.get("vip", None)
        elif action_type in (__ACTION_TYPE_OF_SET_CNAME__, __ACTION_TYPE_OF_SET_A__):
            answers = attrs.get("answer", None)
            if answers is not None:
                pass
            else:
                raise serializers.ValidationError({"answer": [self.error_messages['required']]})

        elif action_type == __ACTION_TYPE_OF_DENY__:
            pass
        return attrs

    def from_native(self, data, files):
        action_type = data.get("action_type", None)

        if action_type == __ACTION_TYPE_OF_VIP__:
            data["answer"] = None
        elif action_type in (__ACTION_TYPE_OF_SET_CNAME__, __ACTION_TYPE_OF_SET_A__):
            data["vip"] = None
        elif action_type == __ACTION_TYPE_OF_DENY__:
            data["vip"] = None
            data["answer"] = None

        return super(ActionSerializer, self).from_native(data, files)


class DomainPolicySerializer(serializers.Serializer):
    domain_staticrule_condition_id = serializers.IntegerField(read_only=True)
    policy_name = serializers.CharField(max_length=100)
    condition_type = serializers.ChoiceField(choices=STATIC_RULE_CONDITION_TYPE)
    domain = serializers.RelatedField(source="domain")
    sequence = serializers.IntegerField()
    is_enabled = serializers.BooleanField(required=False)
    invert = serializers.BooleanField(required=False)
    iprange = serializers.CharField(required=False)
    continent = MultipleChoiceField(required=False, choices=DnaLocationContinentMap.objects.filter(is_visible=True)
                                    .order_by('continent_name')
                                    .values_list('continent_name', 'continent_name'))
    country = MultipleChoiceField(required=False, choices=DnaLocationCountryMap.objects.filter(is_visible=True)
                                  .order_by('country_name')
                                  .values_list('ihms_country', 'country_name'))
    region = MultipleChoiceField(required=False, choices=DnaLocationRegionMap.objects.filter(is_visible=True)
                                 .order_by('region_name')
                                 .values_list('region_name', 'region_name'))
    isp = MultipleChoiceField(required=False, choices=DnaLocationIspMap.objects.filter(is_visible=True)
                              .order_by('isp_name')
                              .values_list('isp_name', 'isp_name'))
    asn = serializers.CharField(required=False)
    percent = serializers.IntegerField(required=False,)
    actions = ActionSerializer(many=True, source="domainstaticruleaction_set", allow_add_remove=True)

    class Meta:
        model = DomainStaticRuleCondition
        fields = ("domain_staticrule_condition_id",
                  "policy_name",
                  "condition_type",
                  "domain",
                  "sequence",
                  "is_enabled",
                  "invert",
                  "iprange",
                  "continent",
                  "country",
                  "region",
                  "isp",
                  "asn",
                  "percent",
                  "actions"
                  )

    def get_identity(self, data):
        try:
            return data.get('domain_staticrule_condition_id', None)
        except AttributeError:
            return None

    def field_from_native(self, data, files, field_name, into):
        try:
            value = data[field_name]
        except KeyError:
            if self.default is not None and not self.partial:
                value = copy.deepcopy(self.default)
            else:
                if self.required:
                    raise self.ValidationError(self.error_messages['required'])
                return

        obj = self.parent.object.policies if self.parent.object else None

        if value in (None, '', []):
            # policies always return list
            into[field_name] = []
        else:
            if obj:
                action_buf = []
                for rule_item in parse_rule_conditions(obj):
                    action_buf.append(rule_item)
            else:
                action_buf = None

            kwargs = {
                'instance': action_buf,
                'data': value,
                'context': self.context,
                'partial': self.partial,
                'many': self.many,
                'allow_add_remove': self.allow_add_remove
            }
            serializer = self.__class__(**kwargs)

            if serializer.is_valid():
                into[field_name] = serializer.object
            else:
                raise serializers.NestedValidationError(serializer.errors)

    def vaildate_iprange(self, attrs, source):
        iprange = attrs.get(source, None)
        if iprange is not None:
            iprange = iprange.strip()
            attrs['iprange'] = iprange.strip()

        return attrs

    def validate(self, attrs):
        condition = int(attrs.get('condition_type'))
        percent = attrs.get('percent', None)
        ip_range = attrs.get('iprange', None)
        actions = attrs.get('actions', None)
        policy_name = attrs.get('policy_name', None)

        if policy_name:
            if "|" in str(policy_name):
                raise serializers.ValidationError({"policy_name": [_(u'A policy name cannot contain vertical bar(|).')]})
            elif "^:^" in str(policy_name):
                raise serializers.ValidationError({"policy_name": [_(u'A policy-name cannot contain specific combinations of the signs.(such as ^:^)')]})
        else:
            raise serializers.ValidationError({"policy_name": [_(u'Policy Name is required')]})

        if condition == __CONDITION_TYPE_OF_IPRANGE__:
            _error_field_ = "iprange"
            if ip_range == '':
                raise serializers.ValidationError({_error_field_: [_(u'IP range is required')]})
            else:

                ip_range_arr = ip_range.split(',')
                for ip in ip_range_arr:
                    is_range = False
                    ip_range_arr = ip.split('-')
                    if len(ip_range_arr) > 2:
                        raise serializers.ValidationError(
                            {_error_field_: [_(u'Not a IP address range pattern [%(ip)s]'%{"ip":ip})]})
                    if len(ip_range_arr) == 2:
                        is_range = True
                        if not regex_ip.match(ip_range_arr[0]):
                            raise serializers.ValidationError(
                                {_error_field_: [_(u'Not a IP address range pattern [%(ip)s]'%{"ip":ip})]})
                        if not regex_ip.match(ip_range_arr[1]):
                            raise serializers.ValidationError(
                                {_error_field_: [_(u'Not a IP address range pattern [%(ip)s]'%{"ip":ip})]})

                    ip_range_arr = ip.split('~')
                    if len(ip_range_arr) > 2:
                        raise serializers.ValidationError(
                            {_error_field_: [_(u'Not a IP address range pattern [%(ip)s]'%{"ip":ip})]})
                    if len(ip_range_arr) == 2:
                        is_range = True
                        if not regex_ip.match(ip_range_arr[0]):
                            raise serializers.ValidationError(
                                {_error_field_: [_(u'Not a IP address range pattern [%(ip)s]'%{"ip":ip})]})
                        if not regex_ip.match(ip_range_arr[1]):
                            raise serializers.ValidationError(
                                {_error_field_: [_(u'Not a IP address range pattern [%(ip)s]'%{"ip":ip})]})

                    if is_range == False:
                        is_ip = True
                        is_cidr = True
                        if not regex_ip.match(ip):
                            is_ip = False
                        if not regex_ip_cidr.match(ip):
                            is_cidr = False

                        if is_ip == False and is_cidr == False:
                            raise serializers.ValidationError(
                                {_error_field_: [_(u'Not a IP address pattern [%(ip)s]'%{"ip":ip})]})

        elif condition == __CONDITION_TYPE_OF_GEO__:
            if len(attrs.get('country')) == 0 and len(attrs.get('continent')) == 0 and \
                len(attrs.get('region')) == 0 and len(attrs.get('isp')) == 0 and len(attrs.get('asn')) == 0:
                raise serializers.ValidationError(_(u'Least one is required'))

            # if geo_select_asn:
            asn_data = attrs.get('asn', None)
            if asn_data:
                ASN_LIST = [asn.strip() for asn in asn_data.split(',')]
                valid_asn = []
                if ASN_LIST.__len__() > 0:
                    try:
                        for reqASN in ASN_LIST:
                            c_asn = long(reqASN)
                            # ASN format : http://www.iana.org/assignments/as-numbers/as-numbers.xml
                            if 1 <= c_asn and c_asn <= 4294967295:
                                valid_asn.append(long(reqASN))
                            else:
                                raise serializers.ValidationError(
                                    {"asn": [_(u'ASN(Autonomous System Number) is allow 32 bit Integer type only. (1~4294967295)')]})
                        attrs['asn'] = ",".join([str(v_asn) for v_asn in valid_asn])
                    except:
                        raise serializers.ValidationError(
                            {"asn": [_(u'Entered ASN(Autonomous System Number) format is not valid. allow only numbers(1~4294967295) separated by comma.')]})
                else:
                    raise serializers.ValidationError(
                        {"asn": [_(u'You have to insert ASN(Autonomous System Number) more than one.')]})

        elif condition == __CONDITION_TYPE_OF_PERCENT__:
            _error_field_ = "percent"
            if percent == '':
                raise serializers.ValidationError({_error_field_: [_(u'Percent is required')]})
            else:
                try:
                    int_num = int(percent)
                except:
                    raise serializers.ValidationError({_error_field_: [_(u'This is not a num')]})

                if int_num > 100 or int_num < 0:
                    raise serializers.ValidationError(
                        {_error_field_: [_(u'Ensure percent is greater than or equal to 0')]})
        else:
            _error_field_ = "General"
            raise serializers.ValidationError(
                {_error_field_: [_(u'You choose invalid condition type. Please check Cloud Load balancer Domain config API document.')]})

        try:
            if hasattr(actions, "__iter__") and len(actions) > 0:
                pass
            else:
                raise Exception
        except:
            raise serializers.ValidationError({"actions": [_("Policy must have more than one valid action")]})

        return attrs


class DummyCLBDomainSerializer(serializers.ModelSerializer):
    answer_count = serializers.IntegerField(
        source="answer_count",
        required=True,
        validators=[MinValueValidator(1), MaxValueValidator(30)]
    )
    answer_ttl = serializers.IntegerField(
        source="answer_ttl",
        required=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)]
    )
    delay_start_time = serializers.IntegerField(
        required=False,
        validators=[MinValueValidator(1), MaxValueValidator(172800)]
    )
    slowstart_period = serializers.IntegerField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)]
    )

    host_name = serializers.CharField(source="host_name", required=False,)
    zone_name = serializers.CharField(read_only=True, source="clb_dns_zone")
    domain_type = serializers.IntegerField(default=1)
    domain_type_display = serializers.ChoiceField(source="get_domain_type_display", read_only=True)
    probe_name = serializers.ChoiceField(source="probe", read_only=True)
    customer_name = serializers.RelatedField(source="customer", read_only=True)
    load_balancing_type = serializers.ChoiceField(source="load_balancing_type", choices=LB_TYPES, required=True)
    load_balancing_type_display = serializers.ChoiceField(source="get_load_balancing_type_display", read_only=True)
    policies = DomainPolicySerializer(source="policies", many=True, required=False, allow_add_remove=True)
    etc_policy = DomainEtcPolicySerializer(source="etc_policy", required=False, many=True, allow_add_remove=True)
    domainvips = SubDomainVipSerializer(source="domainvip_set", required=True, many=True, allow_add_remove=True)
    is_valid = serializers.SerializerMethodField('get_is_valid')
    is_admin = serializers.BooleanField(source="is_admin", required=False)
    latest_updater = serializers.ChoiceField(source="latest_updater", read_only=True)
    status_display = serializers.ChoiceField(source="get_status_display", read_only=True)

    class Meta:
        model = Domain
        fields = ("domain_id",
                  "clb_dns_zone",
                  "name",
                  "zone_name",
                  "host_name",
                  "answer_ttl",
                  "answer_count",
                  "customer",
                  "customer_name",
                  "date_created",
                  "date_modified",
                  "description",
                  "domain_type",
                  "domain_type_display",
                  "policies",
                  "etc_policy",
                  "domainvips",
                  "enable_gslb",
                  "is_admin",
                  "is_valid",
                  "latest_updater",
                  "load_balancing_type",
                  "load_balancing_type_display",
                  "probe",
                  "probe_name",
                  "status",
                  "status_display",
                  "time_deployed",
                  "vips",
                  "delay_start_time",
                  "slowstart_period")
        depth = 0

    def get_identity(self, data):
        try:
            return data.get('domain_id', None)
        except AttributeError:
            return None

    def get_is_valid(self, obj):
        try:
            if obj.is_valid_config():
                return 'ok'
            else:
                return ''
        except:
            return ''

    def validate(self, attrs):
        domain_name = attrs.get("name", None)
        host_name = attrs.get("host_name", None)
        clb_dns_zone = attrs.get("clb_dns_zone", None)
        probe = attrs.get("probe", None)

        customer = attrs.get("customer", None)
        if customer is None:
            # if gslb_domain.customer is null
            # try to copy from clb_dns_zone.customer
            attrs["customer"] = clb_dns_zone.customer
        else:
            pass

        if domain_name == None and host_name == None:
            raise serializers.ValidationError(_(u"Domain name is required."))
        elif domain_name == None:
            attrs["name"] = host_name
        else:
            attrs["host_name"] = domain_name

        try:
            if clb_dns_zone is None:
                raise serializers.ValidationError(_(u"clb_dns_zone is required."))
        except DNSZone.DoesNotExist:
            raise serializers.ValidationError(_(u"Invalid DNS zone configuration"))
        except Exception as e:
            # logging
            pass

        if not clb_dns_zone.dnsstatmaster_set.exists():
            receivers = ['eng-portal@cdnetworks.com']
            try:
                request = self.context.get("request", None)
                if request is not None:
                    if is_request_from_aurora(request) and not request.enduser.is_superuser:
                        pass
                    else:
                        receivers.append(request.enduser.email)
            except:
                pass
            message_list = []
            title = "CLB Domain can not create. because dnszone_stat_master.item_id is invaild."
            message_list.append("Customer id: %s " % (clb_dns_zone.customer.customer_name))
            message_list.append("Zone id: %s" % (str(clb_dns_zone.pk)))
            message_list.append("Zone Name: %s" % (domain_name))
            message_list.append("Current stat_master item for the Dns Zone is 'N/A'.")
            message_list.append("If you find stat_master item as 'N/A' or incorrect, \
                please make sure that customer item per contract should be uniquely 1 item.")
            message_list.append("")
            notice_operator_event_email({}, receivers, title, "<br>".join(message_list))

            raise UnableToLoadStatID

        if probe:
            if probe.use_clb:
                own_probes = probe.customerallowprobeconfig_set.filter(Q(customer=customer)|Q(customer__isnull=True))
                base_probes = BaseProbeConfig.objects.select_related("customerallowprobeconfig").filter(use_clb=1, pk=probe.pk)
                if own_probes.exists() or base_probes.exists():
                    pass
                else:
                    raise serializers.ValidationError({"probe" : [_(u"probe (Server Health Check) configuration is incorrectly.")]})
            else:
                raise serializers.ValidationError({"probe" : [_(u"probe (Server Health Check) configuration is incorrectly.")]})

        policies = attrs.get("policies", None)
        if policies:
            total_percent = sum(filter(None, map(lambda x: x["percent"] \
                                        if int(x["condition_type"]) == __CONDITION_TYPE_OF_PERCENT__\
                                        else None, attrs.get("policies"))))

            if total_percent > 100:
                default_error_message = _(u"Sum of Every percent(%) type policy's value do not over 100%.")
                error_messages = []
                for item in attrs["policies"]:
                    if int(item["condition_type"]) == __CONDITION_TYPE_OF_PERCENT__:
                        error_messages.append({"percent": [default_error_message]})
                    else:
                        error_messages.append({})
                raise serializers.ValidationError({"policies" : error_messages})
        return attrs

    def validate_clb_dns_zone(self, attrs, source):
        clb_dns_zone = attrs.get(source)
        if clb_dns_zone is None:
            raise serializers.ValidationError(_(u"clb_dns_zone is required."))
        return attrs

    def validate_name(self, attrs, source):
        clb_dns_zone = attrs.get("clb_dns_zone")
        domain_name = attrs.get(source)

        if clb_dns_zone is None:
            raise serializers.ValidationError(_(u"clb_dns_zone is required."))

        root_name = clb_dns_zone.domain_name
        domain_name = domain_name.strip()

        host_name = None
        if domain_name.endswith(root_name):
            host_name = domain_name.replace(root_name, "")
            host_name = host_name.strip(".")
            if len(host_name) == 0:
                host_name = root_name
            else:
                host_name = "%s.%s" % (host_name, root_name)
        else:
            if len(domain_name) == 0:
                host_name = root_name
            else:
                host_name = "%s.%s" % (domain_name, root_name)

        if regex_cname_policy.match(host_name) is None:
            raise serializers.ValidationError(_(u"'%(host_name)s' is not valid."% {"host_name": host_name}) )

        clb_domain = Domain.objects.filter(name=host_name)
        if self.object:
            clb_domain = clb_domain.exclude(pk=self.object.pk)

        if clb_domain.exists():
            # clb domain aleady exists
            raise serializers.ValidationError(_(u"clb domain name '%s' is duplicated."% (host_name)))

        # pe_dns_dynamic_zones check
        PE_DNS_DYNAMIC_ZONES = ['cdngc.net', 'cdngm.net', 'gccdn.net', 'gccdn.cn']
        for pe_dnszone_suffix in  PE_DNS_DYNAMIC_ZONES:
            if host_name.strip().lower().endswith(pe_dnszone_suffix):
                raise serializers.ValidationError(_(u"Invalid domain name %s. Domain name ends with PE DNS Dynamic Zone name." % (host_name)))

        attrs[source] = host_name
        return attrs

    def validate_domainvips(self, attrs, source):
        vips = attrs.get(source)

        try:
            action_type = int(attrs["etc_policy"][0]["actions"][0]["action_type"])
            if action_type in (__ACTION_TYPE_OF_SET_CNAME__, __ACTION_TYPE_OF_SET_A__, __ACTION_TYPE_OF_DENY__):
                check_empty_vips = False
            else:
                check_empty_vips = True
        except:
            check_empty_vips = True

        if len(vips) == 0:
            if check_empty_vips == True:
                raise serializers.ValidationError(
                    _(u"Domain need at least one or more VIPs."))

        return attrs

    def validate_delay_start_time(self, attrs, source):
        domain_probe = attrs.get("probe", None)
        delay_start_time = attrs.get(source, None)

        if domain_probe is None and delay_start_time is not None:
            raise serializers.ValidationError(
                _(u"If do not set the Server Health Check Rules, can not set the Delay start time."))

        return attrs

    def validate_slowstart_period(self, attrs, source):
        domain_probe = attrs.get("probe", None)
        slowstart_period = attrs.get(source, None)

        if domain_probe is None and slowstart_period is not None:
            raise serializers.ValidationError(
                _(u"If do not set the Server Health Check Rules, can not set the Slowstart period."))

        if domain_probe is not None and slowstart_period is not None and slowstart_period < 0:
            raise serializers.ValidationError(
                _(u"Ensure this value is greater than or equal to 0."))

        return attrs

    def from_native(self, data, files):
        self._errors = {}

        if data.get("name", None) in ("", None):
            host_name = data.get("host_name", None)
            host_name = host_name.strip()
            if host_name is not None and len(host_name) > 0:
                data.update({"name": data.get("host_name")})
            else:
                try:
                    zone_id = data.get("clb_dns_zone", None)
                    clb_root_dns = DNSZone.objects.get(pk=zone_id)
                    data.update({"name": clb_root_dns.domain_name.strip(".")})
                except:
                    # it will be raise empty name
                    pass
        
        if data is not None or files is not None:
            attrs = self.restore_fields(data, files)
            if attrs is not None:
                attrs = self.perform_validation(attrs)
        else:
            self._errors['non_field_errors'] = ['No input provided']

        try:
            domainvips = data.get("domainvips", None)
            dns_zone = DNSZone.objects.get(pk=data.get("clb_dns_zone"))
            server_ids = [vip['server_id'] for vip in domainvips]
            vips = Vip.objects.filter(pk__in=server_ids)

            customer_vips = vips.filter(host__system__pop__customercontractpop__customer=dns_zone.customer)
            if customer_vips.count() != len(server_ids):
                error_message = [_(u"Server configuration is incorrectly. Please check your available servers.")]
                self._errors['domainvips'] = self._errors.get("domainvips", []) + error_message

        except DNSZone.DoesNotExist:
            error_message = [_(u"Invalid DNS zone configuration")]
            self._errors['clb_dns_zone'] = self._errors.get("clb_dns_zone", []) + error_message
        except TypeError:
            error_message = [_(u"Server configuration is incorrectly")]
            self._errors['domainvips'] = self._errors.get("domainvips", []) + error_message
        
        if not self._errors:
            return self.restore_object(attrs, instance=getattr(self, 'object', None))

def parse_rule_conditions(conditions):
    def _parse_rule_conditon(value):
        domain = value.domain
        policy = value.condition.strip()
        actions = value.domainstaticruleaction_set.all()
        parsed = [a for a in parse_rule_action(actions)]

        data = {
            "domain_staticrule_condition_id": value.pk,
            "policy_name": value.policy_name,
            "domain": domain.pk,
            "condition_type": 0,
            "is_enabled": value.is_enabled,
            "invert": value.invert,
            "sequence": value.sequence,
            "iprange": None,
            "continent": [],
            "country": [],
            "region": [],
            "isp": [],
            "asn": None,
            "percent": None,
            "actions": parsed
        }

        if re_ip.match(policy):
            data["condition_type"] = __CONDITION_TYPE_OF_IPRANGE__
            rule = re_ip.match(policy)

            data.update({"iprange": rule.group(1)})
            return data

        elif re_geo_condition.match(policy):
            data["condition_type"] = __CONDITION_TYPE_OF_GEO__
            try:
                geo_policies = policy.split("\n")
            except:
                geo_policies = ""

            for p in geo_policies:
                rule = re_geo_condition.match(p)
                if rule.group(1) != "asn":
                    data.update({rule.group(1): rule.group(2).split(__SPLITER__)})
                else:
                    data.update({rule.group(1): rule.group(2)})

            return data

        elif re_percent_condition.match(policy):
            data["condition_type"] = __CONDITION_TYPE_OF_PERCENT__
            rule = re_percent_condition.match(policy)

            data.update({"percent": int(rule.group(1))})
            return data

        elif re_etc_condition.match(policy):
            rule = re_etc_condition.match(policy)
            data["condition_type"] = None
            return data
        else:
            pass

    if hasattr(conditions, '__iter__'):
        for condition in conditions:
            yield _parse_rule_conditon(condition)
    else:
        yield _parse_rule_conditon(conditions)


def parse_rule_action(actions):
    for action in actions:
        parsed_action = {
            "domain_staticrule_action_id": action.pk,
            "sequence": 0,
            "condition_id": action.condition_id,
            "action_type": 0,
            "vip": None,
            "answer": []
        }

        parsed_action["sequence"] = action.sequence
        action_text = action.action.strip()
        if re_vip_action.match(action_text):
            act = re_vip_action.match(action_text)
            parsed_action["action_type"] = 1
            try:
                vip_ids = act.group(1)
                vips = vip_ids.split(__SPLITER__)
                vip = Vip.objects.filter(vip_addr__in=vips)
                if vip.count() == 0:
                    raise Vip.DoesNotExist
            except Vip.DoesNotExist:
                raise StaticRuleParseError(detail=_(u"%(vip)s is not exist VIP" % {"vip":vip_ids}))
            except Exception as e:
                raise APIException(detail=_(u"Occure system failure (%(err)s)" % {"err": e}))

            parsed_action["vip"] = [v.pk for v in vip]
            yield parsed_action
        elif re_set_action.match(action_text):
            m_actions = action_text.split("\n")
            for action_line in m_actions:
                resp = {}
                act = re_set_action.match(action_line)
                if act.group("record_type") == "CNAME":
                    parsed_action["action_type"] = 2
                    resp["rtype"] = act.group("record_type")
                    resp["ttl"] = act.group("ttl")
                    resp["data"] = act.group("data")
                elif act.group("record_type") == "A":
                    parsed_action["action_type"] = 3
                    resp["rtype"] = act.group("record_type")
                    resp["ttl"] = act.group("ttl")
                    resp["data"] = act.group("data")
                else:
                    continue
                parsed_action["answer"].append(resp)
            yield parsed_action
        elif re_deny_action.match(action_text):
            act = re_deny_action.match(action_text)
            parsed_action["action_type"] = 0
            yield parsed_action
        else:
            continue


class PolicyField(serializers.RelatedField, serializers.WritableField):

    """
    Static Rule condition
    """

    def from_native(self, value):
        return value

    def to_native(self, value):
        domain = value.domain
        policy = value.condition
        actions = value.domainstaticruleaction_set.all()
        parsed = [a for a in parse_rule_action(actions)]

        policy_name = value.policy_name
        if policy_name is not None or policy_name != '':
            policy_name = policy_name.replace('^:^', ' ')

        data = {
            "domain_staticrule_condition_id": value.pk,
            "policy_name": policy_name,
            "domain": domain.pk,
            "condition_type": 0,
            "is_enabled": value.is_enabled,
            "invert": value.invert,
            "sequence": value.sequence,
            "iprange": None,
            "continent": [],
            "country": [],
            "region": [],
            "isp": [],
            "asn": None,
            "percent": None,
            "actions": parsed
        }

        if re_ip.match(policy):
            data["condition_type"] = __CONDITION_TYPE_OF_IPRANGE__
            rule = re_ip.match(policy)

            data.update({"iprange": rule.group(1)})
            return data

        elif re_geo_condition.match(policy):
            data["condition_type"] = __CONDITION_TYPE_OF_GEO__
            try:
                geo_policies = policy.split("\n")
            except:
                geo_policies = ""

            for p in geo_policies:
                rule = re_geo_condition.match(p)
                if rule.group(1) != "asn":
                    data.update({rule.group(1): rule.group(2).split(__SPLITER__)})
                else:
                    data.update({rule.group(1): rule.group(2)})

            return data

        elif re_percent_condition.match(policy):
            data["condition_type"] = __CONDITION_TYPE_OF_PERCENT__
            rule = re_percent_condition.match(policy)

            data.update({"percent": int(rule.group(1))})
            return data

        elif re_etc_condition.match(policy):
            rule = re_etc_condition.match(policy)
            data["condition_type"] = None
            return [data]
        else:
            pass


class CLBDomainSerializer(serializers.ModelSerializer):
    answer_count = serializers.IntegerField(
        source="answer_count",
        required=True,
        validators=[MinValueValidator(1), MaxValueValidator(30)]
    )
    answer_ttl = serializers.IntegerField(
        source="answer_ttl",
        required=True,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)]
    )
    delay_start_time = serializers.IntegerField(
        required=False,
        validators=[MinValueValidator(1), MaxValueValidator(172800)]
    )
    slowstart_period = serializers.IntegerField(
        required=False,
        validators=[MinValueValidator(0), MaxValueValidator(4294967295)]
    )

    host_name = serializers.CharField(source="host_name", required=False,)
    zone_name = serializers.CharField(read_only=True, source="clb_dns_zone")
    domain_type = serializers.IntegerField(default=1)
    domain_type_display = serializers.ChoiceField(source="get_domain_type_display", read_only=True)
    probe_name = serializers.ChoiceField(source="probe", read_only=True)
    customer_name = serializers.RelatedField(source="customer", read_only=True)
    load_balancing_type = serializers.ChoiceField(source="load_balancing_type", choices=LB_TYPES, required=True)
    load_balancing_type_display = serializers.ChoiceField(source="get_load_balancing_type_display", read_only=True)
    policies = PolicyField(many=True, required=False, source="policies")
    etc_policy = PolicyField(required=False, source="etc_policy")
    domainvips = SubDomainVipSerializer(many=True, source="domainvip_set", required=True, allow_add_remove=True)
    is_valid = serializers.SerializerMethodField('get_is_valid')
    is_admin = serializers.BooleanField(source="is_admin", read_only=True)
    latest_updater = serializers.ChoiceField(source="latest_updater", read_only=True)
    status_display = serializers.ChoiceField(source="get_status_display", read_only=True)

    class Meta:
        model = Domain
        fields = ("domain_id",
                  "clb_dns_zone",
                  "name",
                  "zone_name",
                  "host_name",
                  "answer_ttl",
                  "answer_count",
                  "customer",
                  "customer_name",
                  "date_created",
                  "date_modified",
                  "description",
                  "domain_type",
                  "domain_type_display",
                  "policies",
                  "etc_policy",
                  "domainvips",
                  "enable_gslb",
                  "is_admin",
                  "is_valid",
                  "latest_updater",
                  "load_balancing_type",
                  "load_balancing_type_display",
                  "probe",
                  "probe_name",
                  "status",
                  "status_display",
                  "time_deployed",
                  "vips",
                  "delay_start_time",
                  "slowstart_period")
        depth = 0

    def get_identity(self, data):
        try:
            return data.get('domain_id', None)
        except AttributeError:
            return None

    def get_is_valid(self, obj):
        try:
            if obj.is_valid_config():
                return 'ok'
            else:
                return ''
        except:
            return ''

    def validate(self, attrs):
        domain_name = attrs.get("name", None)
        host_name = attrs.get("host_name", None)
        clb_dns_zone = attrs.get("clb_dns_zone", None)
        probe = probe = attrs.get('probe', None)

        customer = attrs.get("customer", None)

        if customer is None:
            # if gslb_domain.customer is null
            # try to copy from clb_dns_zone.customer
            attrs["customer"] = clb_dns_zone.customer
        else:
            pass

        if domain_name == None and host_name == None:
            raise serializers.ValidationError(_(u"Domain name is required."))
        elif domain_name == None:
            attrs["name"] = host_name
        else:
            attrs["host_name"] = domain_name

        try:
            if clb_dns_zone is None:
                raise serializers.ValidationError(_(u"clb_dns_zone is required."))
        except DNSZone.DoesNotExist:
            raise serializers.ValidationError(_(u"Invalid DNS zone configuration"))
        except Exception as e:
            # logging
            pass

        if not clb_dns_zone.dnsstatmaster_set.exists():
            raise UnableToLoadStatID

        if probe:
            if probe.use_clb:
                own_probes = probe.customerallowprobeconfig_set.filter(Q(customer=customer)|Q(customer__isnull=True))
                base_probes = BaseProbeConfig.objects.select_related("customerallowprobeconfig").filter(use_clb=1, pk=probe.pk)
                if own_probes.exists() or base_probes.exists():
                    pass
                else:
                    raise serializers.ValidationError({"probe" : [_(u"probe (Server Health Check) configuration is incorrectly.")]})
            else:
                raise serializers.ValidationError({"probe" : [_(u"probe (Server Health Check) configuration is incorrectly.")]})

        return attrs

    def validate_name(self, attrs, source):
        clb_dns_zone = attrs.get("clb_dns_zone")
        domain_name = attrs.get(source)

        if clb_dns_zone is None:
            raise serializers.ValidationError(_(u"clb_dns_zone is required."))

        root_name = clb_dns_zone.domain_name
        domain_name = domain_name.strip()

        host_name = None
        if domain_name.endswith(root_name):
            host_name = domain_name.replace(root_name, "")
            host_name = host_name.strip(".")
            if len(host_name) == 0:
                host_name = root_name
            else:
                host_name = "%s.%s" % (host_name, root_name)
        else:
            if len(domain_name) == 0:
                host_name = root_name
            else:
                host_name = "%s.%s" % (domain_name, root_name)

        if regex_host_ns.match(host_name) is None:
            raise serializers.ValidationError(_(u"'%(host_name)s' is not valid."% {"host_name": host_name}))

        clb_domain = Domain.objects.filter(name=host_name)
        if self.object:
            clb_domain = clb_domain.exclude(pk=self.object.pk)

        if clb_domain.exists():
            # clb domain aleady exists
            raise serializers.ValidationError(_(u"clb domain name '%s' is duplicated."% (host_name)))

        # pe_dns_dynamic_zones check
        PE_DNS_DYNAMIC_ZONES = ['cdngc.net', 'cdngm.net', 'gccdn.net', 'gccdn.cn']
        for pe_dnszone_suffix in  PE_DNS_DYNAMIC_ZONES:
            if host_name.strip().lower().endswith(pe_dnszone_suffix):
                raise serializers.ValidationError(_(u"Invalid domain name %s. Domain name ends with PE DNS Dynamic Zone name." % (host_name)))

        attrs[source] = host_name
        return attrs

    def validate_delay_start_time(self, attrs, source):
        domain_probe = attrs.get("probe", None)
        delay_start_time = attrs.get(source, None)

        if domain_probe is None and delay_start_time is not None:
            raise serializers.ValidationError(
                _(u"If do not set the Server Health Check Rules, can not set the Delay Start time."))

        return attrs

    def validate_slowstart_period(self, attrs, source):
        domain_probe = attrs.get("probe", None)
        slowstart_period = attrs.get(source, None)

        if domain_probe is None and slowstart_period is not None:
            raise serializers.ValidationError(
                _(u"If do not set the Server Health Check Rules, can not set the Slowstart Period."))

        if domain_probe is not None and slowstart_period is not None and slowstart_period < 0:
            raise serializers.ValidationError(
                _(u"Ensure this value is greater than or equal to 0."))

        return attrs

    def from_native(self, data, files):
        self._errors = {}

        if data.get("name", None) in ("", None):
            host_name = data.get("host_name", None)
            host_name = host_name.strip()
            if host_name is not None and len(host_name) > 0:
                data.update({"name": data.get("host_name")})
            else:
                try:
                    zone_id = data.get("clb_dns_zone", None)
                    clb_root_dns = DNSZone.objects.get(pk=zone_id)
                    data.update({"name": clb_root_dns.domain_name.strip(".")})
                except:
                    # it will be raise empty name
                    pass

        if data is not None or files is not None:
            attrs = self.restore_fields(data, files)
            if attrs is not None:
                attrs = self.perform_validation(attrs)
        else:
            self._errors['non_field_errors'] = ['No input provided']

        try:
            domainvips = data.get("domainvips", None)
            dns_zone = DNSZone.objects.get(pk=data.get("clb_dns_zone"))
            server_ids = [vip['server_id'] for vip in domainvips]
            vips = Vip.objects.filter(pk__in=server_ids)

            customer_vips = vips.filter(host__system__pop__customercontractpop__customer=dns_zone.customer)
            if customer_vips.count() != len(server_ids):
                error_message = [_(u"Server configuration is incorrectly. Please check your available servers.")]
                self._errors['domainvips'] = self._errors.get("domainvips", []) + error_message

        except DNSZone.DoesNotExist:
            error_message = [_(u"Invalid DNS zone configuration")]
            self._errors['clb_dns_zone'] = self._errors.get("clb_dns_zone", []) + error_message
        except TypeError:
            error_message = [_(u"Server configuration is incorrectly")]
            self._errors['domainvips'] = self._errors.get("domainvips", []) + error_message

        if not self._errors:
            return self.restore_object(attrs, instance=getattr(self, 'object', None))

def build_etc_rule_set(data):
    if isinstance(data, list):
        data = data[0]
    condition_set = {
        "domain_staticrule_condition_id": data.get("domain_staticrule_condition_id", None),
        "domain": data.get("domain", None),
        "sequence": __SEQ_MAX__,
        "condition": __PREFIX_COND_ETC_POLICY__,
        "policy_name": __PREFIX_COND_ETC_POLICY__,
        "is_enabled": True,
        "invert": None
    }
    return condition_set

def get_identity(data, key=None):
    if key == None:
        key = "domain_staticrule_condition_id"

    try:
        return data.get(key, None)
    except AttributeError:
        pass


def _static_rule_condtion(data, context=None):
    """
    This function is convert policy dict to condtion strings
    """
    request = context.get("request", None)

    condition_type = int(data["condition_type"])
    input_invert_opt = data.get("invert", None)
    condition_buf = []
    if condition_type == __CONDITION_TYPE_OF_IPRANGE__:
        commend = __PREFIX_COND_IPRANGE_POLICY__
        iprange = data.get("iprange")

        tmp_ = "%s=%s" % (commend, iprange)
        condition_buf.append(tmp_)
    elif condition_type == __CONDITION_TYPE_OF_GEO__:
        geo_continent = data.get("continent", [])
        geo_country = data.get("country", [])
        geo_region = data.get("region", [])
        geo_isp = data.get("isp", [])
        geo_asn = data.get("asn", None)

        if len(geo_continent) > 0:
            commend = __PREFIX_COND_GEO_CONTINENT__
            continents = ",".join(geo_continent)
            tmp_ = "%s=%s" % (commend, continents)
            condition_buf.append(tmp_)
        if len(geo_country) > 0:
            commend = __PREFIX_COND_GEO_COUNTRY__
            countries = ",".join(geo_country)
            tmp_ = "%s=%s" % (commend, countries)
            condition_buf.append(tmp_)
        if len(geo_region) > 0:
            commend = __PREFIX_COND_GEO_REGION__
            regions = ",".join(geo_region)
            tmp_ = "%s=%s" % (commend, regions)
            condition_buf.append(tmp_)
        if len(geo_isp) > 0:
            commend = __PREFIX_COND_GEO_ISP__
            isps = ",".join(geo_isp)
            tmp_ = "%s=%s" % (commend, isps)
            condition_buf.append(tmp_)
        if geo_asn is not None and len(geo_asn) > 0:
            commend = __PREFIX_COND_GEO_ASN__
            tmp_ = "%s=%s" % (commend, geo_asn)
            condition_buf.append(tmp_)
    elif condition_type == __CONDITION_TYPE_OF_PERCENT__:
        commend = __PREFIX_COND_PERCENT_POLICY__
        percent = data.get("percent")
        tmp_ = "%s=%s" % (commend, percent)
        condition_buf.append(tmp_)
        input_invert_opt = None

    condition_set = {
        "domain_staticrule_condition_id": data.get("domain_staticrule_condition_id", None),
        "domain": data.get("domain", None),
        "sequence": data["sequence"],
        "condition": "\n".join(condition_buf),
        "policy_name": data.get("policy_name", None),
        "is_enabled": data.get("is_enabled", None),
        "invert": input_invert_opt
    }

    if condition_set["domain_staticrule_condition_id"] is not None:
        # exists
        static_rule = DomainStaticRuleCondition.objects.get(pk=data.get("domain_staticrule_condition_id"))
        static_rule.policy_name = condition_set["policy_name"]
        static_rule.sequence = condition_set["sequence"]
        static_rule.condition = condition_set["condition"]
        static_rule.is_enabled = condition_set["is_enabled"]
        static_rule.invert = condition_set["invert"]
        try:
            if data.has_key('previous_sequence'):
                static_rule.previous_sequence = data["previous_sequence"]
        except:
            pass
        static_rule.save(request=request)
    else:
        condition_set.pop("domain_staticrule_condition_id")
        static_rule = DomainStaticRuleCondition(**condition_set)
        static_rule.save(request=request)

    exists = DomainStaticRuleAction.objects.filter(condition=static_rule)\
        .exclude(condition__condition="always")

    originals = {}
    updated_act_ids = []
    for item in data.get("actions"):
        if get_identity(item, "domain_staticrule_action_id") is not None:
            updated_act_ids.append(get_identity(item, "domain_staticrule_action_id"))

    for item in exists:
        if item.pk in updated_act_ids:
            originals.update({item.pk:item.sequence})

    remove_action_rules = exists.exclude(domain_staticrule_action_id__in=updated_act_ids)
    log_queryset_delete(remove_action_rules)
    remove_action_rules.delete()

    exists.update(sequence=((__SEQ_MAX__ - 1) - F('sequence')))

    seq_counter = 1
    for i, a in enumerate(data.get("actions")):
        seq_id = a.get("sequence", None)
        if i == 0:
            start_seq = seq_id
            if start_seq is not None and start_seq > 0:
                seq_counter = start_seq

        a["sequence"] = seq_counter + i
        a["condition_id"] = static_rule
        try:
            a["previous_sequence"] = originals.get(get_identity(a, "domain_staticrule_action_id"))
        except:
            pass
        _static_rule_action(a, context=context)

    return static_rule


def _static_rule_action(data, context=None):
    """
    Build static rule action
    """
    request = context.get("request", None)

    action_buf = []
    action_type = int(data["action_type"])
    if action_type == __ACTION_TYPE_OF_DENY__:
        commend = __PREFIX_ACT_DENY__
        action_buf.append(commend)
    elif action_type == __ACTION_TYPE_OF_VIP__:
        commend = __PREFIX_ACT_VIP__
        vip_ids = data.get("vip", [])
        if len(vip_ids) > 0:
            vips = Vip.objects.filter(vip__in=vip_ids)\
                .values("vip_addr")
            if len(vips) > 0:
                ips = [vip["vip_addr"] for vip in vips]
                tmp_ = "%s=%s" % (commend, ",".join(ips))
                action_buf.append(tmp_)
    elif action_type in (__ACTION_TYPE_OF_SET_CNAME__, __ACTION_TYPE_OF_SET_A__):
        answers = data.get("answer", [])
        if action_type == __ACTION_TYPE_OF_SET_CNAME__:
            commend = "%s=%s" % (__PREFIX_ACT_SET__, "CNAME")
        elif action_type == __ACTION_TYPE_OF_SET_A__:
            commend = "%s=%s" % (__PREFIX_ACT_SET__, "A")

        for answer in answers:
            ttl = answer.get("ttl")
            data_ = answer.get("data")
            tmp_ = "%s,%s,%s" % (commend, ttl, data_)
            action_buf.append(tmp_)

    action_set = {
        "domain_staticrule_action_id": data.get("domain_staticrule_action_id", None),
        "condition": data.get("condition_id", None),
        "action": "\n".join(action_buf),
        "sequence": data.get("sequence")
    }

    if action_set["domain_staticrule_action_id"] is not None:
        static_rule_act = DomainStaticRuleAction.objects\
            .get(pk=action_set["domain_staticrule_action_id"])
        static_rule_act.action = action_set["action"]
        static_rule_act.sequence = action_set["sequence"]
        try:
            if data.has_key('previous_sequence'):
                static_rule_act.previous_sequence = data.get("previous_sequence")
        except:
            pass

        static_rule_act.save(request=request)
    else:
        action_set.pop("domain_staticrule_action_id")
        static_rule_act = DomainStaticRuleAction(**action_set)
        static_rule_act.save(request=request)

    return static_rule_act


def _etc_policy(data, context=None):
    request = context.get("request", None)
    domain = context.get("domain")
    etc_action_id = None
    if data is not None:
        try:
            if isinstance(data, list):
                data = data[0]

            etc_cond = build_etc_rule_set(data)
            etc_cond["domain"] = domain
            etc_cond["invert"] = None

            try:
                rule_obj = DomainStaticRuleCondition.objects\
                                    .select_related('domainstaticruleaction_set')\
                                    .get(domain=domain, condition="always")
                etc_actions = rule_obj.domainstaticruleaction_set.all()
                if etc_actions.exists():
                    etc_action_id = etc_actions[0].pk
                    if etc_actions.count() > 1:
                        etc_actions.exclude(domain_staticrule_action_id=etc_action_id).delete()
            except DomainStaticRuleCondition.DoesNotExist:
                rule_obj = DomainStaticRuleCondition(**etc_cond)
            except DomainStaticRuleCondition.MultipleObjectsReturned:
                # cleanup.
                DomainStaticRuleCondition.objects\
                    .select_related('domainstaticruleaction_set')\
                    .filter(domain=domain, condition="always")\
                    .delete()
                rule_obj = DomainStaticRuleCondition(**etc_cond)
            except:
                pass

            # etc policy set sequence max
            rule_obj.sequence = __SEQ_MAX__
            rule_obj.save(request=request)

            try:
                action_type = int(data["actions"][0].get("action_type", None))
            except:
                action_type = 1  # if invalid action_type , set delete

            if action_type is not None:
                action_type = int(action_type)
            else:
                action_type = None

            if action_type in (2, 3):
                etc_act = data["actions"][0]
                etc_act["condition_id"] = rule_obj
                etc_act["sequence"] = __SEQ_MAX__
                if etc_action_id is not None:
                    etc_act["domain_staticrule_action_id"] = etc_action_id

                rule_action = _static_rule_action(etc_act, context=context)

                rule_action.save(request=request)
                return rule_obj
            elif action_type == 0:
                etc_act = data["actions"][0]
                etc_act["condition_id"] = rule_obj
                etc_act["sequence"] = __SEQ_MAX__
                if etc_action_id is not None:
                    etc_act["domain_staticrule_action_id"] = etc_action_id

                rule_action = _static_rule_action(etc_act, context=context)
                rule_action.save(request=request)
                return rule_obj
            else:
                # remove all always
                rule_obj.delete()
                return None
        except Exception as e:
            raise e
    else:
        try:
            rule_obj = DomainStaticRuleCondition.objects.get(domain=domain, condition="always")
            rule_obj.delete()
            return None
        except:
            return None



def build_rule(data, context=None):
    """
    @ desc : Build CLB domain config static rule
    """
    many = isinstance(data, list)
    domain = context["domain"]
    updated_ids = []
    originals = {}

    exists = DomainStaticRuleCondition.objects.filter(domain=domain).exclude(condition="always")

    for item in data:
        if get_identity(item) is not None:
            updated_ids.append(get_identity(item))

    # remove un-listed items
    remove_rules = exists.exclude(domain_staticrule_condition_id__in=updated_ids)
    log_queryset_delete(remove_rules)
    remove_rules.delete()

    for item in exists:
        if item.pk in updated_ids:
            originals.update({item.pk:item.sequence})
    # re-order (negetive)
    exists.update(sequence=((__SEQ_MAX__ - 1) - F('sequence')))

    if many:
        seq_counter = 1
        for i, item in enumerate(data):
            seq_id = item.get("sequence", None)
            if i == 0:
                start_seq = seq_id
                if start_seq is not None and start_seq > 0:
                    seq_counter = start_seq

            item["domain"] = domain
            item["sequence"] = seq_counter + i
            try:
                item["previous_sequence"] = originals.get(get_identity(item))
            except:
                pass

            yield _static_rule_condtion(item, context=context)
    else:
        data["domain"] = domain
        yield _static_rule_condtion(data, context=context)
