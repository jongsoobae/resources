from rest_framework import serializers
from spectrum_api.configuration.models.base import Pop, Vip, VipProbeConfigs, Host, BaseProbeConfig
from spectrum_api.configuration.models.clb import CLBLocationRegion, CustomerContractPop
from django.utils.translation import ugettext as _

from spectrum_api.dna.models.regex import IP_RE
import re

STATUS_TO_STAGE = 1
STATUS_TO_PRODUCTION = 3
STATUS_IN_PRODUCTION = 4

"""""""""""""""""""""""""""""""""""""""""""""
  MyInfra Location
"""""""""""""""""""""""""""""""""""""""""""""


class CLBLocationRegionSerializer(serializers.ModelSerializer):
    continent_name = serializers.RelatedField(source="continent", read_only=True)

    class Meta:
        model = CLBLocationRegion
        fields = ('region', 'region_name', 'region_alias', 'continent', 'continent_name',
                  'date_created', 'date_modified', 'obj_state')


"""""""""""""""""""""""""""""""""""""""""""""
  MyInfra ServerGroup
"""""""""""""""""""""""""""""""""""""""""""""


class ServerProbeSerializer(serializers.ModelSerializer):
    class Meta:
        model = BaseProbeConfig
        fields = ("probeconfig_id", "name")


class ServerSerializer(serializers.ModelSerializer):
    server_id = serializers.IntegerField(source="pk", read_only=True)
    server_name = serializers.CharField(source="vip_alias_name")
    ip = serializers.CharField(source="vip_addr")
    is_active = serializers.BooleanField(source="enable_gslb")
    group_id = serializers.SerializerMethodField('get_group_id')
    group_name = serializers.SerializerMethodField('get_group_name')
    region = serializers.SerializerMethodField('get_region')
    region_name = serializers.SerializerMethodField('get_region_name')
    healthcheckers = ServerProbeSerializer(many=True, source="probeconfigs")

    class Meta:
        model = Vip
        fields = ("server_id",
                "server_name",
                "ip",
                "is_active",
                "group_id",
                "group_name",
                "region",
                "region_name",
                "healthcheckers",)

    def get_domains(self, obj):
        domains = []
        """
        try:
            domains = [{"domain": d[0], "domain_name":d[1]}
                       for d in Domain.objects.select_related()
                       .filter(domainvip__vip=obj)
                       .distinct().values_list('pk', 'name')]
            domains = sorted(domains, key=lambda k: k["domain_name"])
        except Exception, e:
            # logging
            pass
        """
        return domains

    def get_status(self, obj):
        pop_status_code = 0
        try:
            pop_status_code, status_text = convert_pop_status(obj.host.system.pop)
        except Exception, e:
            # logging e
            pop_status_code = 0

        return pop_status_code

    def get_status_text(self, obj):
        status_text = ""
        try:
            pop_status_code, status_text = convert_pop_status(obj.host.system.pop)
        except Exception, e:
            # logging e
            status_text = ""

        return status_text

    def get_server_display(self, obj):
        try:
            return "%s (%s)" % (obj.vip_addr, obj.vip_alias_name)
        except Exception, e:
            # logging
            return ""

    def get_region(self, obj):
        try:
            region = obj.host.system.pop.customercontractpop_set.all()[0].region_id
        except Exception as e :
            # logging
            region = None
        return region

    def get_region_name(self, obj):
        try:
            region = obj.host.system.pop.customercontractpop_set.all()[0].region.region_name
        except Exception as e :
            # logging
            region = ""
        return region

    def get_group_id(self, obj):
        try:
            group_id = obj.host.system.pop.customercontractpop_set.all()[0].pk
        except Exception as e :
            # logging
            group_id = None
        return group_id

    def get_group_name(self, obj):
        try:
            group_name = obj.host.system.pop.customercontractpop_set.all()[0].pop_alias
        except Exception as e :
            # logging
            group_name = ""
        return group_name


class ServerGroupSerializer(serializers.ModelSerializer):
    group_id = serializers.RelatedField(source="id", read_only=True)
    group_name = serializers.CharField(source="pop_alias")
    is_active = serializers.CharField(source="obj_state")
    region_name = serializers.RelatedField(source="region", read_only=True)
    customer_name = serializers.RelatedField(source="customer", read_only=True)
    status = serializers.RelatedField('pop.status')
    status_text = serializers.RelatedField('pop.get_status_display')

    class Meta:
        model = CustomerContractPop
        fields = ("group_id",
                  "group_name",
                  "is_active",
                  "customer_name",
                  "customer",
                  "region",
                  "region_name",
                  "status",
                  "status_text"
                  )

    def get_domains(self, obj):
        domains = []
        """
        try:
            domains = [{"domain": d[0], "domain_name":d[1]}
                       for d in Domain.objects.select_related()
                       .filter(domainvip__vip__host__system__pop__customercontractpop=obj)
                       .distinct().values_list('pk', 'name')]
            domains = sorted(domains, key=lambda k: k["domain_name"])
        except Exception, e:
            # logging
            pass
        """
        return domains

    def get_deploy_t(self, obj):
        try:
            deploy_t = obj.pop.time_deployed.strftime('%Y-%m-%d %H:%M:%S')
        except Exception, e:
            deploy_t = None
        return deploy_t


class PopSerializer(serializers.ModelSerializer):
    timeout = serializers.Field('get_timeout')
    status_text = serializers.Field('get_deploy_status_text')
    related_zone_deploy_status_text = serializers.Field('get_related_zone_deploy_status_text')
    vip_set = serializers.SerializerMethodField('get_vip_set')
    host = serializers.SerializerMethodField('get_host')

    class Meta:
        model = Pop
        fields = (
            'pop',
            'status', 'enable_gslb', 'time_deployed', 'timeout', 'status_text',
            'related_zone_deploy_status_text', 'vip_set', 'host'
        )

    @staticmethod
    def get_vip_set(data):
        ret = []

        try:
            cust_pop = CustomerContractPop.all_objects.get(pop=data)
        except CustomerContractPop.DoesNotExist:
            cust_pop = None
            return ret

        avail_probes = cust_pop.get_avaliable_probes(cust_pop.customer)
        avail_probe_array = []
        for probe in avail_probes:
            avail_probe_array.append(probe['probeconfig_id'])

        vip_set = data.get_vips()
        for vip_obj in vip_set:
            ret_vip_obj = {}

            vipprobe_objs = VipProbeConfigs.all_objects.filter(vip=vip_obj)
            ret_vip_obj['vip'] = vip_obj.pk
            ret_vip_obj['vip_addr'] = vip_obj
            ret_vip_obj['vip_alias_name'] = vip_obj.vip_alias_name
            ret_vip_obj['enable_gslb'] = vip_obj.enable_gslb
            ret_vip_obj['vipprobe_set'] = []
            for vp_obj in vipprobe_objs:
                if vp_obj.vip.pk in avail_probe_array:
                    ret_vip_obj['vipprobe_set'].append(vp_obj.probe)
            ret.append(ret_vip_obj)

        return ret

    @staticmethod
    def get_host(data):
        host_objs = Host.all_objects.filter(system__pop=data.pk)
        if host_objs:
            return host_objs[0].pk
        else:
            return None


class MyInfraServerGroupSimpleSerializer(serializers.ModelSerializer):
    group_id = serializers.CharField(source="id")
    group_name = serializers.CharField(source="pop_alias")

    class Meta:
        model = CustomerContractPop
        fields = ('group_id', 'group_name', 'customer')


#############################################################################################
#
# 2017.03 Speed improvement
# modify : hyejun.yim
#
#############################################################################################
class MyInfraServerGroupReSerializer(serializers.ModelSerializer):
    group_id = serializers.RelatedField(source="id", read_only=True)
    group_name = serializers.CharField(source="pop_alias")
    group_state = serializers.CharField(source="obj_state", read_only=True)
    region_name = serializers.RelatedField(source="region", read_only=True)
    customer_name = serializers.RelatedField(source="customer", read_only=True)
    status = serializers.RelatedField('pop.status')
    health_check = serializers.IntegerField(source='probe_agent_selection_type', default=0)
    vip_count = serializers.SerializerMethodField('get_vip_count')
    timeout = serializers.RelatedField('pop.get_timeout')
    time_deployed = serializers.RelatedField('pop.time_deployed')
    enable_gslb = serializers.RelatedField('pop.enable_gslb')
    host = serializers.SerializerMethodField('get_host')
    pop = serializers.RelatedField('pop.pk')

    class Meta:
        model = CustomerContractPop
        fields = ('group_id',
                  'group_name',
                  'group_state',
                  'customer_name',
                  'customer',
                  'region',
                  'region_name',
                  'status',
                  'health_check',
                  'vip_count',
                  'timeout',
                  'time_deployed',
                  'enable_gslb',
                  'host',
                  'pop'
                  )

    @staticmethod
    def get_vip_count(data):
        try:
            return data.pop.get_vips().count()
        except (Exception,):
            return 0

    @staticmethod
    def get_host(data):
        host_objs = Host.all_objects.filter(system__pop=data.pop)
        if host_objs:
            return host_objs[0].pk
        else:
            return None
#############################################################################################


class MyInfraServerGroupSerializer(serializers.ModelSerializer):
    group_id = serializers.RelatedField(source="id", read_only=True)
    group_name = serializers.CharField(source="pop_alias")
    group_state = serializers.CharField(source="obj_state", read_only=True)
    region_name = serializers.RelatedField(source="region", read_only=True)
    customer_name = serializers.RelatedField(source="customer", read_only=True)
    status = serializers.RelatedField('pop.status')
    status_text = serializers.RelatedField('pop.get_deploy_status_text')
    health_check = serializers.IntegerField(source='probe_agent_selection_type', default=0)
    vip_count = serializers.SerializerMethodField('get_vip_count')
    timeout = serializers.RelatedField('pop.get_timeout')
    time_deployed = serializers.RelatedField('pop.time_deployed')
    enable_gslb = serializers.RelatedField('pop.enable_gslb')
    related_zone_deploy_status_text = serializers.RelatedField('pop.get_related_zone_deploy_status_text')
    vip_set = serializers.RelatedField('get_vip_set')
    host = serializers.SerializerMethodField('get_host')
    pop = serializers.RelatedField('pop.pk')

    class Meta:
        model = CustomerContractPop
        fields = ('group_id',
                  'group_name',
                  'group_state',
                  'customer_name',
                  'customer',
                  'region',
                  'region_name',
                  'status',
                  'status_text',
                  'health_check',
                  'vip_count',
                  'timeout',
                  'time_deployed',
                  'enable_gslb',
                  'related_zone_deploy_status_text',
                  'vip_set',
                  'host',
                  'pop'
                  )

    def validate_group_name(self, attrs, source):
        group_name = attrs.get(source, None)
        if group_name is None:
            raise serializers.ValidationError({'group_name': 'This field is required.'})

        _length = len(group_name.encode('euc-kr'))
        if _length > 45:
            raise serializers.ValidationError(
                {'group_name': 'Ensure this value has at most 45 bytes (it has %s).' % str(_length)})
        return attrs

    def validate_region(self, attrs, source):
        if attrs.get(source, None) is None:
            raise serializers.ValidationError({source: 'This field is required.'})

        return attrs

    def validate_customer(self, attrs, source):
        if attrs.get(source, None) is None:
            raise serializers.ValidationError({source: 'This field is required.'})

        return attrs

    def validate(self, attrs):
        if not self.object:
            pass
        else:
            if not self.object.pop.is_modifiable():
                raise serializers.ValidationError(
                    {'detail': [
                        'Server group is in pending and locked(%s). please wait until the lock is released.'
                        % (self.object.pop.get_deploy_status())
                    ]})

            if self.object.pop.is_related_clb_zone_pending():
                raise serializers.ValidationError(
                    {'detail': [
                        "Related zone '%s' is locked(pending status). Please wait until the lock is released."
                        % (self.object.pop.get_related_pending_clb_zones())
                    ]})

        return attrs

    @staticmethod
    def get_vip_count(data):
        try:
            return data.pop.get_vips().count()
        except (Exception,):
            return 0

    @staticmethod
    def get_host(data):
        host_objs = Host.all_objects.filter(system__pop=data.pop)
        if host_objs:
            return host_objs[0].pk
        else:
            return None


class MyInfraServerGroupDeletableSerializer(serializers.ModelSerializer):
    is_deletable = serializers.Field('is_deletable')

    class Meta:
        model = CustomerContractPop
        fields = ('is_deletable', )


class MyInfraServerProbeSerializer(serializers.ModelSerializer):
    probe_name = serializers.RelatedField(source='probe')

    class Meta:
        model = VipProbeConfigs
        fields = ('vip_probe_id', 'probe', 'vip', 'probe_name',)
        read_only_fields = ('vip',)

    def get_identity(self, data):
        try:
            return data.get('vip_probe_id', None)
        except AttributeError:
            return None


#############################################################################################
#
# 2017.03 Speed improvement
# modify : hyejun.yim
#
#############################################################################################
class MyInfraServerReSerializer(serializers.ModelSerializer):
    server_id = serializers.PrimaryKeyRelatedField(source="pk", read_only=True)
    server_name = serializers.CharField(source="vip_alias_name", required=True)
    ip = serializers.CharField(source="vip_addr", required=True)
    server_state = serializers.IntegerField(source="enable_gslb", required=True)
    server_health_checks = MyInfraServerProbeSerializer(
        many=True, required=False, read_only=False,
        source="vipprobeconfigs_set", allow_add_remove=True)

    class Meta:
        model = Vip
        fields = ("server_id",
                  "server_name",
                  "ip",
                  "server_state",
                  "server_health_checks",
                  "host"
                  )
        read_only_fields = ("host", )
#############################################################################################


class MyInfraServerSerializer(serializers.ModelSerializer):
    server_id = serializers.PrimaryKeyRelatedField(source="pk", read_only=True)
    server_name = serializers.CharField(source="vip_alias_name", required=True)
    ip = serializers.CharField(source="vip_addr", required=True)
    server_state = serializers.IntegerField(source="enable_gslb", required=True)
    group_id = serializers.RelatedField(source="host.system.pop.customercontractpop_set.get.pk")
    #group_id = serializers.SerializerMethodField('get_group_id')
    group_name = serializers.SerializerMethodField('get_group_name')
    region = serializers.SerializerMethodField('get_region')
    region_name = serializers.SerializerMethodField('get_region_name')
    server_health_checks = MyInfraServerProbeSerializer(
        many=True, required=False, read_only=False,
        source="vipprobeconfigs_set", allow_add_remove=True)

    class Meta:
        model = Vip
        fields = ("server_id",
                  "server_name",
                  "ip",
                  "server_state",
                  "group_id",
                  "group_name",
                  "region",
                  "region_name",
                  "server_health_checks",
                  "host"
                  )
        read_only_fields = ("host", )

    def validate_group_id(self, attrs, source):
        group_id = self.context['request'].DATA.get('group_id')
        try:
            vip_id = self.object.vip
        except AttributeError:
            vip_id = None

        if not group_id:
            raise serializers.ValidationError(_('This field is required.'))
        try:
            cust_pop = CustomerContractPop.all_objects.get(pk=group_id)
            if vip_id is not None:
                vip = Vip.objects.get(pk=int(vip_id))
                before_cust_pop = CustomerContractPop.all_objects.get(pop=vip.host.system.pop)
                if cust_pop.customer_id != before_cust_pop.customer_id:
                    raise serializers.ValidationError(_('This field is invalid.'))

        except CustomerContractPop.DoesNotExist:
            raise serializers.ValidationError(_('This field is invalid.'))
        except Vip.DoesNotExist:
            pass

        attrs['host'] = cust_pop.get_host()
        try:
            host1 = self.object.host
        except AttributeError:
            host1 = None
        host2 = attrs['host']
        if host1 != host2:
            # 1. when created  2. when modified and host changed
            attrs['vip_name'] = cust_pop.get_host().get_next_vip_name()
        return attrs

    def validate_ip(self, attrs, source):
        value = attrs.get(source)

        if not bool(re.match(IP_RE, value)):
            raise serializers.ValidationError(_('Ip value is invalid.'))

        return attrs

    def validate_server_health_checks(self, attrs, source):
        group_id = self.context['request'].DATA.get('group_id')
        server_health_checks = self.context['request'].DATA.get('server_health_checks')
        try:
            cust_pop = CustomerContractPop.all_objects.get(pk=group_id)
            avail_probes = cust_pop.get_avaliable_probes(cust_pop.customer)
            avail_probe_array = []
            for probe in avail_probes:
                avail_probe_array.append(probe['probeconfig_id'])

            for shc in server_health_checks:
                if shc['probe'] not in avail_probe_array:
                    raise serializers.ValidationError(_('probe value is invalid.'))

        except CustomerContractPop.DoesNotExist:
            raise serializers.ValidationError(_('Group ID value is invalid.'))

        return attrs

    def get_group_name(self, obj):
        try:
            group_name = obj.host.system.pop.customercontractpop_set.all()[0].pop_alias
        except Exception as e:
            # logging
            group_name = ""
        return group_name

    def get_region(self, obj):
        try:
            region = obj.host.system.pop.customercontractpop_set.all()[0].region_id
        except Exception as e:
            # logging
            region = None
        return region

    def get_region_name(self, obj):
        try:
            region = obj.host.system.pop.customercontractpop_set.all()[0].region.region_name
        except Exception as e:
            # logging
            region = ""
        return region


class MyInfraServerDetailRelatedDomainSerializer(serializers.ModelSerializer):
    server_id = serializers.PrimaryKeyRelatedField(source="pk", read_only=True)
    server_name = serializers.CharField(source="vip_alias_name", required=True)

    related_domains = serializers.RelatedField(source='get_related_domains')
    related_actions = serializers.RelatedField(source='get_related_domain_actions')

    class Meta:
        model = Vip
        fields = ("server_id",
                  "server_name",
                  "related_domains",
                  "related_actions"
                  )


def convert_pop_status(pop_obj):
    if pop_obj.status == 0:
        if pop_obj.time_deployed is None:
            return pop_obj.status, _(u'New')

    if pop_obj.status in [STATUS_TO_STAGE, STATUS_TO_PRODUCTION]:
        if pop_obj.get_timeout():
            if pop_obj.status == STATUS_TO_STAGE:
                pop_status_code = -2
            elif pop_obj.status == STATUS_TO_PRODUCTION:
                pop_status_code = -4
            else:
                pop_status_code = -2
        else:
            pop_status_code = pop_obj.status
    else:
        pop_status_code = pop_obj.status

    zone_status = pop_obj.get_deploy_status_text()
    # return pop_status_code , "%s %s"%(display_pop_status_text(pop_status_code),zone_status)
    return pop_status_code, zone_status