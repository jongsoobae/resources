'''
Created on Nov 29, 2013

@author: kookheon.kwon
'''
import unittest
from spectrum_api.dns.forms import dns


class TestDns(unittest.TestCase):

    dns_zone_lists = [];

    def setUp(self):
        self.dns_zone_lists = dns.DNSZone.objects.all()


    def tearDown(self):
        pass


    def test_dns_domain_db_lists_is_matches(self):
        for row in self.dns_zone_lists:
            self.assertTrue(dns.regex_tld_domain.match(row.domain_name), True)


    def test_dns_domain_regexp_is_match(self):
        self.assertTrue(dns.regex_tld_domain.match('kucuny.com'), True)
        self.assertTrue(dns.regex_tld_domain.match('kucuny.com'), True)
        self.assertTrue(dns.regex_tld_domain.match('abc.com123'), True)
        self.assertTrue(dns.regex_tld_domain.match('abc.123'), True)
        self.assertTrue(dns.regex_tld_domain.match('com123'), True)
        self.assertTrue(dns.regex_tld_domain.match('1dollar'), True)
        self.assertTrue(dns.regex_tld_domain.match('gift4u'), True)
        self.assertTrue(dns.regex_tld_domain.match('123'), True)
        self.assertTrue(dns.regex_tld_domain.match('1-2-3'), True)

    def test_dns_domain_regexp_is_not_match(self):
        self.assertFalse(dns.regex_tld_domain.match('.kucuny.com'), True)

if __name__ == "__main__":
    unittest.main()
