from django.contrib.auth.models import User
from rest_framework import status
from rest_framework.test import APIClient

from django.utils import unittest
from spectrum_api.configuration.models.base import Host, Vip
from spectrum_api.configuration.models.clb import CustomerContractPop

import random

__author__ = 'root'


class ServerCreateTests(unittest.TestCase):
    def setUp(self):
        user = User.objects.get(username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=user)

    def tearDown(self):
        if not self.server_id:
            pass
        else:
            delete_url = '/api/myinfra/server/'+str(self.server_id)+'/'
            res = self.client.delete(delete_url)
            self.assertEqual(res.status_code, status.HTTP_204_NO_CONTENT)
            print 'delete success'

    def test(self):
        insert_url = '/api/myinfra/server/'
        data = {
            "ip": "10.10.2.255",
            "group_id": "7",
            "server_name": "UnitTest Server",
            "server_state": 1
        }

        response = self.client.post(insert_url, data, format='json')
        self.server_id = response.data['server_id']

        db_vip = Vip.objects.get(pk=self.server_id)

        cust_pop = CustomerContractPop.objects.get(pk=data['group_id'])
        hosts = Host.objects.filter(system__pop=cust_pop.pop)

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(self.server_id, db_vip.pk)
        self.assertEqual(data['ip'], db_vip.vip_addr)
        self.assertEqual(data['server_state'], db_vip.enable_gslb)
        self.assertEqual(hosts[0].pk, db_vip.host.pk)
        self.assertEqual(data['server_name'], db_vip.vip_alias_name)
        self.assertTrue(db_vip.vip_name)

    def assertEqual(self, first, second, msg=None):
        super(ServerCreateTests, self).assertEqual(str(first), str(second), msg)


class ServerEditTests(unittest.TestCase):
    def setUp(self):
        user = User.objects.get(username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=user)

    def tearDown(self):
        if not self.server_id:
            pass
        else:
            delete_url = '/api/myinfra/server/'+str(self.server_id)+'/'
            res = self.client.delete(delete_url)
            self.assertEqual(res.status_code, status.HTTP_204_NO_CONTENT)
            print 'delete success'

    def test(self):
        insert_url = '/api/myinfra/server/'
        data = {
            "ip": "10.10.2.255",
            "group_id": "7",
            "server_name": "UnitTest Server",
            "server_state": 1
        }

        response = self.client.post(insert_url, data, format='json')
        self.server_id = response.data['server_id']

        b_cust_pop = CustomerContractPop.objects.get(pk=8)
        b_cust_pop.pop.status = 4
        #b_cust_pop.pop.save()

        self.assertEqual(4, b_cust_pop.pop.status)

        data = {
            "ip": "10.10.2.254",
            "group_id": "8",
            "server_name": "Test Server Group",
            "server_state": 0
        }

        update_url = '/api/myinfra/server/' + str(self.server_id) + '/'
        response = self.client.put(update_url, data, format='json')

        db_vip = Vip.objects.get(pk=self.server_id)

        cust_pop = CustomerContractPop.objects.get(pk=data['group_id'])
        hosts = Host.objects.filter(system__pop=cust_pop.pop)

        self.assertEqual(status.HTTP_200_OK, response.status_code)
        self.assertEqual(b_cust_pop.pop.pk, cust_pop.pop.pk)
        self.assertEqual(self.server_id, db_vip.pk)
        self.assertEqual(data['ip'], db_vip.vip_addr)
        self.assertEqual(data['server_state'], db_vip.enable_gslb)
        self.assertEqual(hosts[0].pk, db_vip.host.pk)
        self.assertEqual(data['server_name'], db_vip.vip_alias_name)
        self.assertTrue(db_vip.vip_name)

        # normalize and pop status check
        self.assertEqual(cust_pop.pop.pk, db_vip.host.system.pop.pk)
        self.assertEqual(0, db_vip.host.system.pop.status)

    def assertEqual(self, first, second, msg=None):
        super(ServerEditTests, self).assertEqual(str(first), str(second), msg)


class ServerCreateRequiredTests(unittest.TestCase):
    def setUp(self):
        user = User.objects.get(username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=user)

    def tearDown(self):
        if not self.server_id:
            pass
        else:
            delete_url = '/api/myinfra/server/'+str(self.server_id)+'/'
            res = self.client.delete(delete_url)
            self.assertEqual(res.status_code, status.HTTP_204_NO_CONTENT)
            print 'delete success'

    def test(self):
        insert_url = '/api/myinfra/server/'
        data = {
            "ip": "10.10.2.255",
            "group_id": "7",
            "server_name": "Test Server Group",
            "server_state": 1
        }

        sub_datas = get_datas_for_check_required(data)

        for sub_data in sub_datas:
            response = self.client.post(insert_url, sub_data, format='json')
            print sub_data
            self.server_id = response.data.get('server_id')
            self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
            self.assertEqual(len(data)-len(sub_data), len(response.data))

    def assertEqual(self, first, second, msg=None):
        super(ServerCreateRequiredTests, self).assertEqual(str(first), str(second), msg)


class ServerEditRequiredTests(unittest.TestCase):
    def setUp(self):
        user = User.objects.get(username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=user)

    def tearDown(self):
        if not self.server_id:
            pass
        else:
            delete_url = '/api/myinfra/server/'+str(self.server_id)+'/'
            res = self.client.delete(delete_url)
            self.assertEqual(res.status_code, status.HTTP_204_NO_CONTENT)
            print 'delete success'

    def test(self):
        insert_url = '/api/myinfra/server/'
        data = {
            "ip": "10.10.2.255",
            "group_id": "7",
            "server_name": "Test Server Group",
            "server_state": 1
        }

        response = self.client.post(insert_url, data, format='json')
        self.server_id = response.data.get('server_id')
        sub_datas = get_datas_for_check_required(data)
        update_url = '/api/myinfra/server/' + str(self.server_id) + '/'

        for sub_data in sub_datas:
            response = self.client.put(update_url, sub_data, format='json')
            self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
            self.assertEqual(len(data)-len(sub_data), len(response.data))

    def assertEqual(self, first, second, msg=None):
        super(ServerEditRequiredTests, self).assertEqual(str(first), str(second), msg)


class ServerDeleteTests(unittest.TestCase):
    def setUp(self):
        user = User.objects.get(username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=user)

    def tearDown(self):
        pass

    def test(self):
        insert_url = '/api/myinfra/server/'
        data = {
            "ip": "10.10.2.255",
            "group_id": "7",
            "server_name": "Test Server Group",
            "server_state": 1
        }

        response = self.client.post(insert_url, data, format='json')
        self.server_id = response.data.get('server_id')

        delete_url = '/api/myinfra/server/' + str(self.server_id) + '/'
        response = self.client.delete(delete_url)

        self.assertEqual(status.HTTP_204_NO_CONTENT, response.status_code)

    def assertEqual(self, first, second, msg=None):
        super(ServerDeleteTests, self).assertEqual(str(first), str(second), msg)


"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
common functions
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""


def get_datas_for_check_required(data):
    return_data = []
    data_array = [{e: data[e]} for e in data]
    data_length = len(data_array)

    for i in range(0, data_length):
        index_set = set()
        while True:
            index_set.add(random.randint(0, data_length-1))
            if len(index_set) >= i:
                break

        temp_data = {}
        for j in index_set:
            temp_data.update(data_array[j])
        return_data.append(temp_data)

    return return_data