import json
from django.utils import unittest
from django.contrib.auth.models import User
from rest_framework import status
from rest_framework.test import APIClient

# [AURORAUI-3046]
### TEST ENV ###
customer_id = 1  # CDNetworks Product Management
group_id = 4  # Location1
page_no = 1
page_size = 10
### TEST ENV ###

class ServerGroupListTests(unittest.TestCase):
    def setUp(self):
        user = User.objects.get(username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=user)

    def test(self):
        params = {
            'customer': customer_id,
            'page': page_no,
            'page_size': page_size
        }

        old_url = '/api/myinfra/server_group/'
        new_url = '/api/myinfra/server_group/re/'

        old_response = self.client.get(old_url, params, format='json')
        new_response = self.client.get(new_url, params, format='json')

        self.assertEqual(old_response.status_code, status.HTTP_200_OK)
        self.assertEqual(new_response.status_code, status.HTTP_200_OK)
        self.assertEqual(old_response.data.count, new_response.data.count)

        old_data = json.loads(old_response.data.results)
        new_data = json.loads(new_response.data.results)

        for i in (0, page_size):
            self.assertEqual(old_data[i]['group_id'], new_data[i]['group_id'])
            self.assertEqual(old_data[i]['group_name'], new_data[i]['group_name'])
            self.assertEqual(old_data[i]['group_state'], new_data[i]['group_state'])
            self.assertEqual(old_data[i]['region'], new_data[i]['region'])
            self.assertEqual(old_data[i]['region_name'], new_data[i]['region_name'])
            self.assertEqual(old_data[i]['customer'], new_data[i]['customer'])
            self.assertEqual(old_data[i]['customer_name'], new_data[i]['customer_name'])
            self.assertEqual(old_data[i]['pop'], new_data[i]['pop'])
            self.assertEqual(old_data[i]['host'], new_data[i]['host'])
            self.assertEqual(old_data[i]['status'], new_data[i]['status'])
            self.assertEqual(old_data[i]['health_check'], new_data[i]['health_check'])
            self.assertEqual(old_data[i]['enable_gslb'], new_data[i]['enable_gslb'])
            self.assertEqual(old_data[i]['timeout'], new_data[i]['timeout'])
            self.assertEqual(old_data[i]['time_deployed'], new_data[i]['time_deployed'])
            self.assertEqual(old_data[i]['vip_count'], new_data[i]['vip_count'])
            self.assertEqual(len(old_data[i]['vip_set']), len(new_data[i]['vip_set']))

            self.assertEqual(old_data[i]['vip_count'], len(old_data[i]['vip_set']))
            self.assertEqual(new_data[i]['vip_count'], len(new_data[i]['vip_set']))
#             self.assertEqual(old_data[i]['related_zone_deploy_status_text'], new_data[i]['related_zone_deploy_status_text'])

class ServerGroupDetailInfoTests(unittest.TestCase):
    def setUp(self):
        user = User.objects.get(username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=user)

    def test(self):
        params = {
            'customer': customer_id
        }

        old_url = '/api/myinfra/server_group/'+str(group_id)+'/'
        new_url = '/api/myinfra/server_group/re/'+str(group_id)+'/'

        old_response = self.client.get(old_url, params, format='json')
        new_response = self.client.get(new_url, params, format='json')

        self.assertEqual(old_response.status_code, status.HTTP_200_OK)
        self.assertEqual(new_response.status_code, status.HTTP_200_OK)

        old_data = json.loads(old_response.data)
        new_data = json.loads(new_response.data)

        self.assertEqual(old_data['group_id'], new_data['group_id'])
        self.assertEqual(old_data['group_name'], new_data['group_name'])
        self.assertEqual(old_data['group_state'], new_data['group_state'])
        self.assertEqual(old_data['region'], new_data['region'])
        self.assertEqual(old_data['region_name'], new_data['region_name'])
        self.assertEqual(old_data['customer'], new_data['customer'])
        self.assertEqual(old_data['customer_name'], new_data['customer_name'])
        self.assertEqual(old_data['pop'], new_data['pop'])
        self.assertEqual(old_data['host'], new_data['host'])
        self.assertEqual(old_data['status'], new_data['status'])
        self.assertEqual(old_data['health_check'], new_data['health_check'])
        self.assertEqual(old_data['enable_gslb'], new_data['enable_gslb'])
        self.assertEqual(old_data['timeout'], new_data['timeout'])
        self.assertEqual(old_data['time_deployed'], new_data['time_deployed'])
        self.assertEqual(old_data['vip_count'], new_data['vip_count'])
        self.assertEqual(len(old_data['vip_set']), len(new_data['vip_set']))

        self.assertEqual(old_data['vip_count'], len(old_data['vip_set']))
        self.assertEqual(new_data['vip_count'], len(new_data['vip_set']))
#         self.assertEqual(old_data['related_zone_deploy_status_text'], new_data['related_zone_deploy_status_text'])

class ServerGroupServerListTests(unittest.TestCase):
    def setUp(self):
        user = User.objects.get(username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=user)

    def test(self):
        params = {
            'group_id': group_id,
            'page_size': 'max',
            'customer': customer_id,
            'o': 'server_id'
        }

        old_url = '/api/myinfra/server/'
        new_url = '/api/myinfra/server/re/'

        old_response = self.client.get(old_url, params, format='json')
        new_response = self.client.get(new_url, params, format='json')

        self.assertEqual(old_response.status_code, status.HTTP_200_OK)
        self.assertEqual(new_response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(old_response.data), len(new_response.data))

        list_count(len(new_response.data))

        old_data = json.loads(old_response.data)
        new_data = json.loads(new_response.data)

        for i in (0, list_count):
            self.assertEqual(old_data[i]['group_id'], new_data[i]['group_id'])
            self.assertEqual(old_data[i]['group_name'], new_data[i]['group_name'])
            self.assertEqual(old_data[i]['server_id'], new_data[i]['server_id'])
            self.assertEqual(old_data[i]['server_name'], new_data[i]['server_name'])
            self.assertEqual(old_data[i]['server_state'], new_data[i]['server_state'])
            self.assertEqual(old_data[i]['region'], new_data[i]['region'])
            self.assertEqual(old_data[i]['region_name'], new_data[i]['region_name'])
            self.assertEqual(old_data[i]['ip'], new_data[i]['ip'])
            self.assertEqual(old_data[i]['host'], new_data[i]['host'])
            self.assertEqual(len(old_data[i]['server_health_checks']), len(new_data[i]['server_health_checks']))

            server_health_checks_count = len(new_data[i]['server_health_checks'])
            for j in (0, server_health_checks_count):
                self.assertEqual(old_data[i]['server_health_checks'][j]['vip'], 
                                 new_data[i]['server_health_checks'][j]['vip'])
                self.assertEqual(old_data[i]['server_health_checks'][j]['probe'], 
                                 new_data[i]['server_health_checks'][j]['probe'])
                self.assertEqual(old_data[i]['server_health_checks'][j]['probe_name'], 
                                 new_data[i]['server_health_checks'][j]['probe_name'])
                self.assertEqual(old_data[i]['server_health_checks'][j]['vip_probe_id'], 
                                 new_data[i]['server_health_checks'][j]['vip_probe_id'])

