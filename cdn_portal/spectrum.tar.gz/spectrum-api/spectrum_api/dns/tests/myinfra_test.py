from django.contrib.auth.models import User
from rest_framework import status
from rest_framework.test import APIClient

from django.utils import unittest
from spectrum_api.configuration.models.base import PopPacketlossProbeAgentConfig, Pop, PopProbeAgentConfig, System, Host, \
    Vip, VipProbeConfigs
from spectrum_api.configuration.models.clb import CustomerContractPop, CLBLocationRegionBasePop

import random

__author__ = 'root'


class ServerGroupCreateTests(unittest.TestCase):
    def setUp(self):
        user = User.objects.get(username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=user)

    def tearDown(self):
        if not self.group_id:
            pass
        else:
            delete_url = '/api/myinfra/server_group/'+str(self.group_id)+'/'
            res = self.client.delete(delete_url)
            self.assertEqual(res.status_code, status.HTTP_204_NO_CONTENT)
            print 'delete success'

    def test(self):
        insert_url = '/api/myinfra/server_group/'
        data = {
            "group_state": 1,
            "customer": 1,
            "region": 2,
            "health_check": 1,
            "group_name": "test server group_1409_1"
        }

        response = self.client.post(insert_url, data, format='json')

        self.group_id = response.data['id']

        db_cust_pop = CustomerContractPop.objects.get(pk=self.group_id)

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(self.group_id, db_cust_pop.pk)
        self.assertEqual(data['customer'], db_cust_pop.customer.pk)
        self.assertEqual(True, db_cust_pop.obj_state)
        self.assertEqual(data['group_state'], db_cust_pop.pop.enable_gslb)
        self.assertEqual(data['region'], db_cust_pop.region.pk)
        self.assertEqual(data['health_check'], db_cust_pop.probe_agent_selection_type)
        self.assertEqual(data['group_name'], db_cust_pop.pop_alias)

        primary_pop = CLBLocationRegionBasePop.all_objects.get(
            region=data['region'], is_primary=True, obj_state=1).pop

        self.assertEqual(primary_pop.rttserver, db_cust_pop.pop.rttserver)

        clb_location_pops = CLBLocationRegionBasePop.all_objects.filter(region=data['region'], obj_state=1)

        pop_arr = []
        for clb_location_pop in clb_location_pops:
            pop_arr.append(clb_location_pop.pop)

        self.check_probeagent_servers(data['region'], db_cust_pop.pop)
        self.assertTrue(System.objects.filter(pop=db_cust_pop.pop).exists())
        self.assertTrue(Host.objects.filter(system__pop=db_cust_pop.pop).exists())

    def assertEqual(self, first, second, msg=None):
        super(ServerGroupCreateTests, self).assertEqual(str(first), str(second), msg)

    def check_probeagent_servers(self, region, pop):

        clb_location_pops = CLBLocationRegionBasePop.all_objects.filter(region=region, obj_state=1)

        pop_arr = []
        for clb_location_pop in clb_location_pops:
            pop_arr.append(clb_location_pop.pop)

        db_pktloss = list(set(
            zip(*PopPacketlossProbeAgentConfig.objects.filter(pop=pop).values_list('probeagent'))[0]
        ))
        db_pktloss.sort()
        ori_pktloss = list(set(
            zip(*PopPacketlossProbeAgentConfig.objects.filter(pop__in=pop_arr).values_list('probeagent'))[0]
        ))
        ori_pktloss.sort()
        self.assertListEqual(db_pktloss, ori_pktloss)

        db_probeagent = list(set(
            zip(*PopProbeAgentConfig.objects.filter(pop=pop).values_list('probeagent'))[0]
        ))
        db_probeagent.sort()
        ori_probeagent = list(set(
            zip(*PopProbeAgentConfig.objects.filter(pop__in=pop_arr).values_list('probeagent'))[0]
        ))
        ori_probeagent.sort()
        self.assertListEqual(db_probeagent, ori_probeagent)


class ServerGroupEditTests(unittest.TestCase):
    def setUp(self):
        user = User.objects.get(username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=user)

    def tearDown(self):
        if not self.group_id:
            pass
        else:
            delete_url = '/api/myinfra/server_group/'+str(self.group_id)+'/'
            res = self.client.delete(delete_url)
            self.assertEqual(res.status_code, status.HTTP_204_NO_CONTENT)
            print 'delete success'

    def test(self):
        insert_url = '/api/myinfra/server_group/'
        data = {
            "group_state": 1,
            "customer": 1,
            "region": 2,
            "health_check": 1,
            "group_name": "test server group_1409_1"
        }

        response = self.client.post(insert_url, data, format='json')

        data = {
            "group_state": 1,
            "customer": 1,
            "region": 3,
            "health_check": 1,
            "group_name": "test server group_1409_3"
        }

        self.group_id = response.data['id']

        update_url = '/api/myinfra/server_group/' + str(self.group_id) + '/'
        response = self.client.put(update_url, data, format='json')

        db_cust_pop = CustomerContractPop.objects.get(pk=self.group_id)

        self.assertEqual(status.HTTP_200_OK, response.status_code)
        self.assertEqual(self.group_id, db_cust_pop.pk)
        self.assertEqual(data['customer'], db_cust_pop.customer.pk)
        self.assertEqual(True, db_cust_pop.obj_state)
        self.assertEqual(data['group_state'], db_cust_pop.pop.enable_gslb)
        self.assertEqual(data['region'], db_cust_pop.region.pk)
        self.assertEqual(data['health_check'], db_cust_pop.probe_agent_selection_type)
        self.assertEqual(data['group_name'], db_cust_pop.pop_alias)

        primary_pop = CLBLocationRegionBasePop.all_objects.get(
            region=data['region'], is_primary=True, obj_state=1).pop

        self.assertEqual(primary_pop.rttserver, db_cust_pop.pop.rttserver)

        clb_location_pops = CLBLocationRegionBasePop.all_objects.filter(region=data['region'], obj_state=1)

        pop_arr = []
        for clb_location_pop in clb_location_pops:
            pop_arr.append(clb_location_pop.pop)

        db_pktloss = list(set(
            zip(*PopPacketlossProbeAgentConfig.objects.filter(pop=db_cust_pop.pop).values_list('probeagent'))[0]
        ))
        db_pktloss.sort()
        ori_pktloss = list(set(
            zip(*PopPacketlossProbeAgentConfig.objects.filter(pop__in=pop_arr).values_list('probeagent'))[0]
        ))
        ori_pktloss.sort()
        self.assertListEqual(db_pktloss, ori_pktloss)

        db_probeagent = list(set(
            zip(*PopProbeAgentConfig.objects.filter(pop=db_cust_pop.pop).values_list('probeagent'))[0]
        ))
        db_probeagent.sort()
        ori_probeagent = list(set(
            zip(*PopProbeAgentConfig.objects.filter(pop__in=pop_arr).values_list('probeagent'))[0]
        ))
        ori_probeagent.sort()
        self.assertListEqual(db_probeagent, ori_probeagent)

        self.assertTrue(System.objects.filter(pop=db_cust_pop.pop).exists())
        self.assertTrue(Host.objects.filter(system__pop=db_cust_pop.pop).exists())

    def assertEqual(self, first, second, msg=None):
        super(ServerGroupEditTests, self).assertEqual(str(first), str(second), msg)


class ServerGroupCreateRequiredTests(unittest.TestCase):
    def setUp(self):
        user = User.objects.get(username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=user)

    def tearDown(self):
        if not self.group_id:
            pass
        else:
            delete_url = '/api/myinfra/server_group/'+str(self.group_id)+'/'
            res = self.client.delete(delete_url)
            self.assertEqual(res.status_code, status.HTTP_204_NO_CONTENT)
            print 'delete success'

    def test(self):
        insert_url = '/api/myinfra/server_group/'
        data = {
            "group_state": 1,
            "customer": 1,
            "region": 2,
            "health_check": 1,
            "group_name": "test server group_1409_1"
        }

        sub_datas = get_datas_for_check_required(data)

        for sub_data in sub_datas:
            response = self.client.post(insert_url, sub_data, format='json')
            self.group_id = response.data.get('id')
            self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
            self.assertEqual(5-len(sub_data), len(response.data))

    def assertEqual(self, first, second, msg=None):
        super(ServerGroupCreateRequiredTests, self).assertEqual(str(first), str(second), msg)


class ServerGroupEditRequiredTests(unittest.TestCase):
    def setUp(self):
        user = User.objects.get(username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=user)

    def tearDown(self):
        if not self.group_id:
            pass
        else:
            delete_url = '/api/myinfra/server_group/'+str(self.group_id)+'/'
            res = self.client.delete(delete_url)
            self.assertEqual(res.status_code, status.HTTP_204_NO_CONTENT)
            print 'delete success'

    def test(self):
        insert_url = '/api/myinfra/server_group/'
        data = {
            "group_state": 1,
            "customer": 1,
            "region": 2,
            "health_check": 1,
            "group_name": "test server group_1409_1"
        }

        response = self.client.post(insert_url, data, format='json')
        self.group_id = response.data.get('id')
        sub_datas = get_datas_for_check_required(data)
        update_url = '/api/myinfra/server_group/' + str(self.group_id) + '/'

        for sub_data in sub_datas:
            response = self.client.put(update_url, sub_data, format='json')
            self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
            self.assertEqual(5-len(sub_data), len(response.data))

    def assertEqual(self, first, second, msg=None):
        super(ServerGroupEditRequiredTests, self).assertEqual(str(first), str(second), msg)


class ServerGroupDeleteTests(unittest.TestCase):
    def setUp(self):
        user = User.objects.get(username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=user)

    def tearDown(self):
        pass

    def test(self):
        insert_url = '/api/myinfra/server_group/'
        data = {
            "group_state": 1,
            "customer": 1,
            "region": 2,
            "health_check": 1,
            "group_name": "test server group_1409_1"
        }

        response = self.client.post(insert_url, data, format='json')
        self.group_id = response.data.get('id')
        delete_url = '/api/myinfra/server_group/' + str(self.group_id) + '/'

        #before delete, get must deleted items.
        db_cust_pop = CustomerContractPop.objects.get(pk=self.group_id)
        pop = db_cust_pop.pop

        #
        pop_id = pop.pk
        vips_objs = Vip.all_objects.filter(host__system__pop=pop_id)

        response = self.client.delete(delete_url)
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)

        self.assertFalse(Vip.all_objects.filter(host__system__pop=pop_id).exists())
        self.assertFalse(VipProbeConfigs.all_objects.filter(vip__in=vips_objs).exists())
        self.assertFalse(Host.all_objects.filter(system__pop=pop_id).exists())
        self.assertFalse(System.all_objects.filter(pop=pop_id).exists())
        self.assertFalse(PopProbeAgentConfig.all_objects.filter(pop=pop_id).exists())
        self.assertFalse(Pop.all_objects.filter(pop=pop_id, obj_state=1).exists())
        self.assertFalse(CustomerContractPop.all_objects.filter(pop=self.group_id).exists())

    def assertEqual(self, first, second, msg=None):
        super(ServerGroupDeleteTests, self).assertEqual(str(first), str(second), msg)


"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
common functions
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""


def get_datas_for_check_required(data):
    return_data = []
    data_array = [{e: data[e]} for e in data]
    data_length = len(data_array)

    for i in range(0, data_length):
        index_set = set()
        while True:
            index_set.add(random.randint(0, data_length-1))
            if len(index_set) >= i:
                break

        temp_data = {}
        for j in index_set:
            temp_data.update(data_array[j])
        return_data.append(temp_data)

    return return_data