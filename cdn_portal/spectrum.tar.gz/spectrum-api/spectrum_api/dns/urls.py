# -*- coding: utf-8 -*-

from django.conf.urls.defaults import patterns, url
from rest_framework.urlpatterns import format_suffix_patterns

from spectrum_api.dna.views.geo import GeoLocationAPI, GeoLocationContinentAPI, \
    GeoLocationCountryAPI, GeoLocationRegionAPI, GeoLocationISPAPI
from spectrum_api.dns.views.clb import CLBDomainAPI, CLBDomainDetailAPI
from spectrum_api.dns.views.clb_probe import CLBProbeAPI
from spectrum_api.dns.views.myinfra import CLBLocationRegionAPI, MyInfraServerGroupAPI, \
    MyInfraServerGroupSimpleAPI, MyInfraServerGroupDetailAPI, MyInfraServerGroupStatusAPI, \
    MyInfraServerGroupDeletableAPI, MyInfraServerAPI, MyInfraServerDetailAPI, MyInfraAvailableProbeAPI, \
    MyInfraServerGroupReAPI, MyInfraServerGroupDetailReAPI, MyInfraServerReAPI, \
    MyInfraServerDetailRelatedDomainAPI, MyinfraStatusAPI, CLBServerGroupAPI, CLBServerAPI
from spectrum_api.dns.views.mockup_myinfra import MockupMyInfraServerGroupAPI


restfw_api_urlpatterns = patterns(
    'spectrum_api.dns.views',
    url(r'^clb_domains/$', CLBDomainAPI.as_view(), name="clb_domains"),
    url(r'^clb_domains/(?P<domain_id>[0-9]+)/$', CLBDomainDetailAPI.as_view(),
        name="clb_domains-detail"),

    url(r'^cdns/(?P<zone_id>[0-9]+)/clb/$', CLBDomainAPI.as_view(),
        name="zone_clb_domains"),
    url(r'^cdns/(?P<zone_id>[0-9]+)/clb/(?P<domain_id>[0-9]+)/$',
        CLBDomainDetailAPI.as_view(), name="zone_clb_domain-detail"),

    # other apis
    url(r'^geo/continents/$', GeoLocationContinentAPI.as_view(), name="geo_continents"),
    url(r'^geo/countries/$', GeoLocationCountryAPI.as_view(), name="geo_countries"),
    url(r'^geo/regions/$', GeoLocationRegionAPI.as_view(), name="geo_regions"),
    url(r'^geo/isps/$', GeoLocationISPAPI.as_view(), name="geo_isps"),
    url(r'^geo/$', GeoLocationAPI.as_view(), name="geo_data"),

    url(r'^clb_heartbeats/$', CLBProbeAPI.as_view(), name="clb_healthchecker"),

    url(r'^clb/locationregion/$', CLBLocationRegionAPI.as_view(),
        name="clb-location-region"),
    url(r'^myinfra/server_group/$', MyInfraServerGroupAPI.as_view(), name="myinfra-servergroup"),
    url(r'^myinfra/server_group/simple/$', MyInfraServerGroupSimpleAPI.as_view(),
        name="myinfra-servergroup-simple"),
    url(r'^myinfra/server_group/(?P<id>[0-9]+)/$', MyInfraServerGroupDetailAPI.as_view(),
        name="myinfra-servergroup-detail"),
    url(r'^myinfra/server_group/status/$', MyInfraServerGroupStatusAPI.as_view(),
        name="myinfra-servergroup-status"),
    url(r'^myinfra/status/$', MyinfraStatusAPI.as_view(),
        name="myinfra-servergroup-status"),
    url(r'^myinfra/server_group/re/$', MyInfraServerGroupReAPI.as_view(), name="myinfra-servergroup-re"),
    url(r'^myinfra/server_group/re/(?P<id>[0-9]+)/$', MyInfraServerGroupDetailReAPI.as_view(),
        name="myinfra-servergroup-detail-re"),

    url(r'^myinfra/server_group/(?P<id>[0-9]+)/deletable/$',
        MyInfraServerGroupDeletableAPI.as_view(), name="myinfra-servergroup-deletable"),

    url(r'^myinfra/mockup_server_group/$',
        MockupMyInfraServerGroupAPI.as_view(), name="mockup-myinfra-servergroup"),

    url(r'^myinfra/server/$', MyInfraServerAPI.as_view(), name="myinfra-server"),
    url(r'^myinfra/server/(?P<server_id>[0-9]+)/$', MyInfraServerDetailAPI.as_view(),
        name="myinfra-server-detail"),
    url(r'myinfra/server/(?P<server_id>[0-9]+)/related/$',
        MyInfraServerDetailRelatedDomainAPI.as_view(), name="myinfra-server-related"),
    url(r'^myinfra/get_available_probes/$', MyInfraAvailableProbeAPI.as_view(),
        name="myinfra-server-available-probes"),
    url(r'^myinfra/server/re/$', MyInfraServerReAPI.as_view(), name="myinfra-server"),

    url(r'^servergroups/$', CLBServerGroupAPI.as_view(), name="clb_server_groups"),
    url(r'^servers/$', CLBServerAPI.as_view(), name="clb_servers"),

)
urlpatterns = format_suffix_patterns(restfw_api_urlpatterns)
