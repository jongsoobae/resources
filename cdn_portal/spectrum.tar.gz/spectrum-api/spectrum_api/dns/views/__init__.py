# -*- coding: utf-8 -*-
from django.utils.translation import ugettext as _
from rest_framework import exceptions
from rest_framework.status import HTTP_403_FORBIDDEN

class RequireCustomerID(exceptions.APIException):
    status_code = HTTP_403_FORBIDDEN
    default_detail = _(u"You miss customer Information.")