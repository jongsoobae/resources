# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Cloud Lood Balancer Domain Rest API
"""
from __future__ import absolute_import
import re
import logging
from django.db import transaction
from django.utils.translation import ugettext as _
from rest_framework import exceptions
from rest_framework.response import Response
from rest_framework.status import HTTP_404_NOT_FOUND, HTTP_400_BAD_REQUEST, \
                                HTTP_403_FORBIDDEN,\
                                HTTP_406_NOT_ACCEPTABLE, HTTP_500_INTERNAL_SERVER_ERROR, \
                                HTTP_201_CREATED, HTTP_202_ACCEPTED, HTTP_204_NO_CONTENT

from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.mixins import UpdateModelMixin, \
                                        DestroyModelMixin, RetrieveModelMixin,\
                                        ListModelMixin
from spectrum_api.shared_components.utils.user_util import is_request_from_aurora

from spectrum_api.dna.models.domain import Domain
from spectrum_api.dns.serializers.clb import CLBDomainSerializer, DummyCLBDomainSerializer,\
                                    build_rule, _etc_policy
from spectrum_api.dns.views import RequireCustomerID

logger = logging.getLogger(__name__)

class CLBDomainSystemFailure(exceptions.APIException):
    status_code = HTTP_500_INTERNAL_SERVER_ERROR
    default_detail = _(u"Occured system failure")

class CLBDomainDoseNotExist(exceptions.APIException):
    status_code = HTTP_404_NOT_FOUND
    default_detail = _(u"You access does not exists Cloud Load balancer domain")

class isAdminModeDomain(exceptions.APIException):
    status_code = HTTP_403_FORBIDDEN
    default_detail = _(u"Policies are locked and only can be managed by admin user. If you want to change policy, please contact our domain administrator at support@cdnetworks.com")

class isAdminModeDomainDelete(exceptions.APIException):
    status_code = HTTP_403_FORBIDDEN
    default_detail = _(u"This domain is in Admin Mode. please contact our domain administrator at support@cdnetworks.com")

class BlockCLBConfigModify(exceptions.APIException):
    status_code = HTTP_406_NOT_ACCEPTABLE
    default_detail = _(u"This CLB domain is in pending lock status. Please wait until the lock is released.")

class BadRequestData(exceptions.APIException):
    status_code = HTTP_400_BAD_REQUEST

__DOMAIN_URL_LOOKUP_KEY__ = "domain_id"
__DOMAIN_ZONE_URL_LOOKUP_KEY__ = "zone_id"
__DOMAIN_CONDITION_URL_LOOKUP_KEY__ = "domain_staticrule_condition_id"

__STATUS_MODIFIED__ = 0

class CLBDomainAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = Domain.objects.select_related("domainvip_set", "customer",).filter(clb_dns_zone__isnull=False)
    serializer_class = CLBDomainSerializer
    lookup_url_kwarg = __DOMAIN_URL_LOOKUP_KEY__
    search_fields = ("name", "clb_dns_zone__customer__customer_name")
    filter_fields = ("domain_id", "name", "domain_type", "description", {"customer":"clb_dns_zone__customer"},
                    {"customer_name": "clb_dns_zone__customer__customer_name"},
                    {"zone_id":"clb_dns_zone"}, {"zone_name":"clb_dns_zone__name"})

    def get_queryset(self):
        filter_kwargs = {}
        queryset = self.filter_queryset(self.queryset)

        set_limit = is_request_from_aurora(self.request)

        if set_limit:
            try:
                customer = self.request.QUERY_PARAMS.get('customer', None)
                if customer is not None:
                    queryset = queryset.filter(**{"clb_dns_zone__customer": customer})
                else:
                    raise RequireCustomerID
            except:
                raise RequireCustomerID
        else:
            pass

        if self.kwargs is not None:
            domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
            zone_id = self.kwargs.get(__DOMAIN_ZONE_URL_LOOKUP_KEY__, None)
            if domain_id:
                filter_kwargs = {"domain": domain_id}

            if zone_id:
                filter_kwargs = {"clb_dns_zone": zone_id}

        if len(filter_kwargs) > 0:
            queryset = queryset.filter(**filter_kwargs)

        return queryset

    def get(self, request, *args, **kwargs):
        return super(CLBDomainAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.DATA)
        dummy_serializer = DummyCLBDomainSerializer(data=request.DATA, context={"request": request})

        if dummy_serializer.is_valid() and serializer.is_valid():
            with transaction.commit_on_success():
                serializer.save(request=request)
                if serializer.many:
                    post_data = _build_post_data(serializer.object, request.DATA)

                    for clb_domain in serializer.object:
                        result = _clb_post_data_process(clb_domain, post_data[clb_domain.name], request)
                else:
                    result = _clb_post_data_process(serializer.object, request.DATA, request)

                return Response(serializer.data, status=HTTP_201_CREATED)
        else:
            # Sometimes occurred ValidationError caused by zone deploy status when create clb domain.
            try:
                err_message = dummy_serializer.errors["detail"]
                regex_err_holding = re.compile("^This CLB domain")
                if regex_err_holding.match(err_message):
                    raise BlockCLBConfigModify
            except:
                pass
            return Response(dummy_serializer.errors, status=HTTP_400_BAD_REQUEST)

    def put(self, request, *args, **kwargs):
        try:
            objects = self.get_object(self.get_queryset())
            serializer = self.get_serializer(objects, data=request.DATA)
            dummy_serializer = DummyCLBDomainSerializer(objects, data=request.DATA, context={"request": request})

            is_modifiable = _check_modifiable_domains(serializer.object)

            if dummy_serializer.is_valid() and serializer.is_valid():
                with transaction.commit_on_success():
                    serializer.save(request=request)
                    if serializer.many:
                        post_data = _build_post_data(serializer.object, request.DATA)

                        for clb_domain in serializer.object:
                            result = _clb_post_data_process(clb_domain, post_data[clb_domain.name], request)
                    else:
                        result = _clb_post_data_process(serializer.object, request.DATA, request)

                    return Response(serializer.data, status=HTTP_202_ACCEPTED)
            else:
                return Response(dummy_serializer.errors, status=HTTP_400_BAD_REQUEST)
        except isAdminModeDomain:
            raise isAdminModeDomain
        except BlockCLBConfigModify:
            raise BlockCLBConfigModify
        except Exception as e:
            logger.error("CLB Domain update Fail : %s" % e)
            raise CLBDomainSystemFailure

    def delete(self, request, *args, **kwargs):
        objects = self.get_object(self.get_queryset())
        serializer = self.get_serializer(objects, data=request.DATA)
        many = isinstance(serializer.object, list)

        if _check_modifiable_domains(serializer.object):
            with transaction.commit_on_success():
                if many:
                    for obj in objects:
                        if obj.is_modifiable() and obj.is_deletable():
                            obj.clb_dns_zone.status = __STATUS_MODIFIED__
                            obj.clb_dns_zone.save(request=request)
                            obj.delete(request=request)
                        else:
                            raise BlockCLBConfigModify(detail=_(u"%(domain)s is not allow to delete" % {"domain":obj}))
                else:
                    obj = objects

                    if obj.is_modifiable() and obj.is_deletable():
                        obj.clb_dns_zone.status = __STATUS_MODIFIED__
                        obj.clb_dns_zone.save(request=request)
                        obj.delete(request=request)
                    else:
                        raise BlockCLBConfigModify(detail=_(u"%(domain)s is not allow to delete" % {"domain":obj}))
                return Response("", status=HTTP_204_NO_CONTENT)


class CLBDomainDetailAPI(RetrieveModelMixin,
                    UpdateModelMixin,
                    DestroyModelMixin,
                    SpectrumGenericAPIView):
    queryset = Domain.objects.filter(clb_dns_zone__isnull=False)
    serializer_class = CLBDomainSerializer
    lookup_url_kwarg = __DOMAIN_URL_LOOKUP_KEY__
    filter_fields = ("domain_id", "name", "domain_type", "description", {"customer":"clb_dns_zone__customer"},
                    {"customer_name": "clb_dns_zone__customer__customer_name"},
                    {"zone_id":"clb_dns_zone"}, {"zone_name":"clb_dns_zone__name"})

    def get_queryset(self):
        filter_kwargs = {}
        queryset = self.filter_queryset(self.queryset)

        set_limit = is_request_from_aurora(self.request)

        if set_limit:
            try:
                customer = self.request.QUERY_PARAMS.get('customer', None)
                if customer is not None:
                    queryset = queryset.filter(**{"clb_dns_zone__customer": customer})
                else:
                    raise RequireCustomerID
            except:
                raise RequireCustomerID
        else:
            pass

        if self.kwargs is not None:
            domain_id = self.kwargs.get(__DOMAIN_URL_LOOKUP_KEY__, None)
            zone_id = self.kwargs.get(__DOMAIN_ZONE_URL_LOOKUP_KEY__, None)

            if zone_id:
                filter_kwargs = {"clb_dns_zone": zone_id}

        if len(filter_kwargs) > 0:
            queryset = queryset.filter(**filter_kwargs)

        return queryset

    def get(self, request, *args, **kwargs):
        return super(CLBDomainDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        objects = self.get_object(self.get_queryset())
        serializer = self.get_serializer(objects, data=request.DATA)
        dummy_serializer = DummyCLBDomainSerializer(objects, data=request.DATA, context={"request": request})

        is_modifiable = _check_modifiable_domains(serializer.object)

        if dummy_serializer.is_valid() and serializer.is_valid():
            with transaction.commit_on_success():
                serializer.save(request=request)
                if serializer.many:
                    post_data = _build_post_data(serializer.object, request.DATA)

                    for clb_domain in serializer.object:
                        result = _clb_post_data_process(clb_domain, post_data[clb_domain.name], request)
                else:
                    result = _clb_post_data_process(serializer.object, request.DATA, request)

            return Response(serializer.data, status=HTTP_202_ACCEPTED)
        else:
            return Response(dummy_serializer.errors, status=HTTP_400_BAD_REQUEST)

    def delete(self, request, *args, **kwargs):
        objects = self.get_object(self.get_queryset())
        serializer = self.get_serializer(objects, data=request.DATA)
        many = isinstance(serializer.object, list)

        if _check_modifiable_domains(serializer.object):
            with transaction.commit_on_success():
                if many:
                    for obj in objects:
                        if obj.is_modifiable() and obj.is_deletable():
                            obj.clb_dns_zone.status = __STATUS_MODIFIED__
                            obj.clb_dns_zone.save(request=request)
                            obj.delete(request=request)
                        else:
                            raise BlockCLBConfigModify
                else:
                    obj = objects

                    if obj.is_modifiable() and obj.is_deletable():
                        obj.clb_dns_zone.status = __STATUS_MODIFIED__
                        obj.clb_dns_zone.save(request=request)
                        obj.delete(request=request)
                    else:
                        raise BlockCLBConfigModify(detail=_(u"%(domain)s is not allow to delete" % {"domain":obj}))
                return Response("", status=HTTP_204_NO_CONTENT)


def _check_modifiable_domains(target_domains):
    """
    More efficiently check the modifiable or not in multiple CLB domains.

    This function check follow conditions.

     * Domains.is_modifiable()
     * Domains.is_admin

    :param target_domains Domain model instance ( list or object )
    :return boolean if any domains can't modifiable. this function will be return exception
    """

    if not target_domains:
        raise BadRequestData(_(u"POST DATA is not correctly. Please check the requested POST DATA."))

    is_multiple = isinstance(target_domains, list)

    if is_multiple:
        domain_id_list = [domain.pk for domain in target_domains]
        if len(domain_id_list) > 0:
            clb_domains = Domain.objects.filter(domain_id__in=domain_id_list)

            pending_domains = clb_domains.filter(status__in=[1, 3])
            if pending_domains.exists():
                raise BlockCLBConfigModify

            in_admin_mode_domains = clb_domains.filter(is_admin=True)
            if in_admin_mode_domains.exists():
                raise isAdminModeDomain
        else:
            raise BadRequestData
    else:
        if not target_domains.is_modifiable():
            raise BlockCLBConfigModify

        if target_domains.is_admin:
            raise isAdminModeDomain

    return True


def _build_post_data(clb_domains, post_data):
    """
    convert from post_data to dict[domain_key] = val

    :param clb_domains clb domain objects list
    :param post_data request.DATA
    :return dict = {"domain name 1" : matched post_data,
                    "domain name 2" : matched post_data,}
    """

    buf = {}
    for clb_domain in clb_domains:
        for item in post_data:
            if item["name"] == clb_domain.host_name or\
                item["name"] == clb_domain.name:

                buf[clb_domain.name] = item

    return buf


def _clb_post_data_process(clb_domain, post_data, request=None):
    """
    Update clb domain policies & etc_policy and assign probe config.

    clb domain create/modify process has two step phases.
     * First, create/update clb domain with serializers
     * Second, update gslb_staticrule ( policies and etc_policy) update dns_zone status.

    This function process second phase.
    CLB domain's domain static rules ( policies and etc_policy )

    :param clb_domain domain object
    :param request_data request data of clb domains's
    :param django request dict
    :return process clb_domain object or any kind of exceptions
    """
    if post_data["name"] == clb_domain.host_name or\
                                post_data["name"] == clb_domain.name:
        try:
            is_valid, check_message = clb_domain.check_probe_constraint(request,
                                                                        required_probe=clb_domain.probe,
                                                                        force_update=True)
        except Exception as e:
            logger.error("_process_staticrule() : exception %e" %(e))
            raise CLBDomainSystemFailure

        policies = post_data.get("policies", None)
        try:
            if policies is not None:
                conds = [c for c in build_rule(policies, context={"request":request, "domain": clb_domain})]
            else:
                conds = [c for c in build_rule([], context={"request":request, "domain": clb_domain})]
        except TypeError:
            logger.error("Invalid CLB domain Policies : %s" %(policies))
            raise BadRequestData(_(u"CLB Domain policy are invalid."))

        try:
            etc_policy = post_data.get("etc_policy", None)
            _etc_policy(etc_policy, {"request":request, "domain": clb_domain})
        except TypeError:
            logger.error("Invalid CLB domain etc policy  : %s" %(etc_policy))
            raise BadRequestData(_(u"CLB Domain etc policy is invalid."))

        clb_domain.clb_dns_zone.status = __STATUS_MODIFIED__
        clb_domain.clb_dns_zone.save(request=request)

        return clb_domain
    else:
        logger.error("Post data is not for %s" % (clb_domain.name))
        return None
