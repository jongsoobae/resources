# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Cloud Lood Balancer Domain Probe Rest API
"""
from __future__ import absolute_import
from django.db.models import Q
from rest_framework import mixins

from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.utils.user_util import is_request_from_aurora
from spectrum_api.configuration.models.base import BaseProbeConfig
from spectrum_api.dns.serializers.clb import CLBProbeSerializer

from spectrum_api.dns.views import RequireCustomerID

__CUSTOMER_QPARAM_LOOKUP_KEY__ = "customer"


class CLBProbeAPI(mixins.ListModelMixin, SpectrumGenericAPIView):
    queryset = BaseProbeConfig.objects.select_related("customerallowprobeconfig").filter(use_clb=1)
    serializer_class = CLBProbeSerializer
    paginate_by = None

    def get_queryset(self):
        queryset = self.queryset
        customer = self.request.QUERY_PARAMS.get(__CUSTOMER_QPARAM_LOOKUP_KEY__, None)

        set_limit = is_request_from_aurora(self.request)

        if set_limit:
            try:
                if customer is not None:
                    customer = int(customer)
                else:
                    raise RequireCustomerID
            except:
                raise RequireCustomerID
        else:
            pass

        if customer is not None:
            queryset = queryset.filter(Q(customerallowprobeconfig__customer=customer)
                                    | Q(customerallowprobeconfig__customer__isnull=True)).distinct('name')

        return queryset.order_by("name")

    def get(self, request, *args, **kwargs):
        return super(CLBProbeAPI, self).list(request, *args, **kwargs)
