from datetime import datetime
from spectrum_api import settings

from rest_framework.response import Response
from rest_framework import status

from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.configuration.models.clb import CustomerContractPop
from spectrum_api.configuration.models.base import Pop

# This class is created for selenium test.
class MockupMyInfraServerGroupAPI(SpectrumGenericAPIView):

    def __init__(self):
        super(MockupMyInfraServerGroupAPI, self).__init__()

    def put(self, request, *args, **kwages):
        def change_status(executor):
            for pop_name in request.DATA['pop_names']:
                customer_contract_pop_query_set = CustomerContractPop.objects \
                    .filter(pop_alias=pop_name) \
                    .values('pop_id')

                customer_contract_pop_qeury_set_length = len(customer_contract_pop_query_set)

                if 0 >= customer_contract_pop_qeury_set_length or 1 < customer_contract_pop_qeury_set_length:
                    return Response(status=status.HTTP_400_BAD_REQUEST)

                executor(customer_contract_pop_query_set[0]['pop_id'])

            return Response(status=status.HTTP_200_OK)

        if not settings.IS_PRODUCTION:
            if 0 == request.DATA.get('behavior', -1):
                return change_status(
                    lambda pop_id: Pop.objects.filter(pk=int(pop_id)).update(status=4, time_deployed=datetime.now()))
            elif 1 == request.DATA.get('behavior', -1):
                def executor(pop_id):
                    pop = Pop.objects.get(pk=int(pop_id))
                    pop.time_deployed = None
                    pop.save()

                return change_status(executor)
            else:
                raise Exception()
        else:
            return Response(status=status.HTTP_501_NOT_IMPLEMENTED)
