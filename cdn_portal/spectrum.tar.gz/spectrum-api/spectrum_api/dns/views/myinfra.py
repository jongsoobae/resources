# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Cloud Lood Balancer Domain MyInfra Rest API
"""
from datetime import datetime
import json
import re
from django.db import transaction, connections

from django.db.models import Q
from rest_framework import exceptions, status
from rest_framework.response import Response
from django.utils.translation import ugettext as _

from spectrum_api.configuration.models.base import PopProbeAgentConfig, Host, Vip, VipProbeConfigs, System
from spectrum_api.configuration.models.clb import CLBLocationRegion, CustomerContractPop, CLBLocationRegionBasePop
from spectrum_api.configuration.models.base import Pop
from spectrum_api.dns.serializers.myinfra import CLBLocationRegionSerializer, MyInfraServerGroupSerializer, \
    MyInfraServerGroupDeletableSerializer, MyInfraServerSerializer, MyInfraServerGroupSimpleSerializer, \
    MyInfraServerDetailRelatedDomainSerializer, ServerGroupSerializer, ServerSerializer, \
    MyInfraServerGroupReSerializer, MyInfraServerReSerializer
from spectrum_api.dna.models.domain import DomainStaticRuleNormalizedAction, DomainVip, Domain, DomainStaticRuleAction,\
    DomainStaticRuleCondition
from spectrum_api.dna.models.regex import IP_RE
from spectrum_api.dns.views import RequireCustomerID
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.mixins \
    import ListModelMixin, CreateModelMixin, RetrieveModelMixin, UpdateModelMixin, DestroyModelMixin
from spectrum_api.shared_components.models.customer import CustomerItem, CustomerDisplay
from spectrum_api.shared_components.utils.user_util import is_request_from_aurora

__CUSTOMER_QPARAM_LOOKUP_KEY__ = "customer"
__SERVER_GROUP_LOOKUP_KEY__ = "group_id"
__SERVER_LOOKUP_KEY__ = "server_id"

_CLB_POP_ = 1
LB_TYPES = None
regex_ip = re.compile(IP_RE)

STATUS_TO_STAGE = 1
STATUS_TO_PRODUCTION = 3
STATUS_IN_PRODUCTION = 4
__STATUS_OF_PRODUCTION_ERR__ = -4
__ERR_MSG_NOT_EXISTS_SERVER__ = _(u"There is not exists server")
__ERR_MSG_INVAILD_PROBE__ = _(u"You choose Invalid Healthchecker. Please check available Server Healthcheckers.")
__ERR_MSG_INVAILD_SERVER_GROUP__ = _(u"Server group is not valid")
__ERR_MSG_DEPLOY_WAIT__ = _(u"Previous publishing has not been completed yet. Please wait until the push is completed.")
__ERR_MSG_ALREADY_EXISTS_PROBE__ = _(u"This healthchecker is already configured")
__ERR_MSG_DELETE_NOT_EXIST_PROBE__ = _(u"This healthchecker is not exists")
__ERR_MSG_UNKNOWN_ERROR__ = _(u"Operation is Failed. Please contact CDNetworks Technical Supports")
__ERR_MSG_EMPTY_PARAMS__ = _(u"You couldn't update without any parameters")
__ERR_MSG_ZONE_FAILED__ = _(
    u"My Infra configuration deployed successfully, "
    u"but occurred an error while deploying the Cloud DNS configuration. "
    u"Please check your Cloud DNS configuration.")

DEFAULT_STAGING_NS = ('staging.cdnetdns.net',)

def cleanup_enable_gslb(config_enable_gslb):
    try:
        if config_enable_gslb is not None:
            config_enable_gslb = int(config_enable_gslb)
            if config_enable_gslb not in (0, 1):
                raise Exception(_("invalid enable_gslb parameter"))
        else:
            config_enable_gslb =1
    except Exception as e:
        config_enable_gslb = 1

    return config_enable_gslb

class CLBServerGroupAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = CustomerContractPop.all_objects.filter(use_type=_CLB_POP_)
    lookup_url_kwarg = __SERVER_GROUP_LOOKUP_KEY__
    paginate_by = None

    search_fields = ("pop_alias",
                     "pop__system__host__vip_host_set__vip_addr",
                     "pop__system__host__vip_host_set__vip_alias_name")
    filter_fields = ("pop_alias",
                     {"vip_addr": "pop__system__host__vip_host_set__vip_addr"},
                     {"vip_alias_name": "pop__system__host__vip_host_set__vip_alias_name"},
                     {"customer": "host__system__pop__customercontractpop__customer"},)
    serializer_class = ServerGroupSerializer

    def get_queryset(self):
        queryset = self.queryset
        customer = self.request.QUERY_PARAMS.get(__CUSTOMER_QPARAM_LOOKUP_KEY__, None)

        set_limit = is_request_from_aurora(self.request)

        if set_limit:
            try:
                if customer is not None:
                    queryset = queryset.filter(**{"customer": customer})
                else:
                    raise RequireCustomerID
            except:
                raise RequireCustomerID
        else:
            pass

        return queryset

    def get(self, request, *args, **kwargs):
        return super(CLBServerGroupAPI, self).list(request, *args, **kwargs)


class CLBServerAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = Vip.all_objects.select_related("host__system__pop__customercontractpop")\
                        .filter(host__system__pop__customercontractpop__use_type=_CLB_POP_)
    lookup_url_kwarg = __SERVER_LOOKUP_KEY__
    paginate_by = None
    filter_fields = ("probeconfigs",{"customer": "host__system__pop__customercontractpop__customer"},
                     {"group_name": "host__system__pop__customercontractpop__pop_alias"},
                     {"group_id": "host__system__pop__customercontractpop__pk"},
                     {"server_name": "vip_alias_name"},
                     {"ip": "vip_addr"},
                     {"region_name": "host__system__pop__customercontractpop__region__region_name"},
                     {"healthchecker": "probeconfigs"},
                     {"is_active": "enable_gslb"},
                     {"region_name": "host__system__pop__customercontractpop__region__region_name"},)
    serializer_class = ServerSerializer

    def get_queryset(self):
        filter_kwargs = {}
        queryset = self.queryset

        customer = self.request.QUERY_PARAMS.get(__CUSTOMER_QPARAM_LOOKUP_KEY__, None)

        set_limit = is_request_from_aurora(self.request)

        if set_limit:
            try:
                if customer is not None:
                    queryset = queryset.filter(**{"host__system__pop__customercontractpop__customer": customer})
                else:
                    raise RequireCustomerID
            except:
                raise RequireCustomerID
        else:
            pass

        group = self.kwargs.get(__SERVER_GROUP_LOOKUP_KEY__, None)
        if group is not None:
            filter_kwargs = {"host__system__pop__customercontractpop__pk": group}

        queryset = queryset.filter(**filter_kwargs)
        return queryset

    def get(self, request, *args, **kwargs):
        return super(CLBServerAPI, self).list(request, *args, **kwargs)


class CLBAPIException(exceptions.APIException):
    def __init__(self, status_code, detail):
        if isinstance(detail, Exception):
            detail_message = detail.message
            if not detail_message:
                if len(detail.args) > 0:
                    detail_message = _(detail.args[len(detail.args)-1])
                else:
                    detail_message = 'Something is technically wrong. Please try again.'
        else:
            detail_message = detail
        self.status_code = status_code
        super(CLBAPIException, self).__init__(_(detail_message))


class CLBAPICustomException(Exception):
    def __init__(self, fail_data):
        super(CLBAPICustomException, self).__init__()
        self.fail_data = fail_data


class CLBLocationRegionAPI(ListModelMixin,
                           SpectrumGenericAPIView):
    def __init__(self):
        super(CLBLocationRegionAPI, self).__init__()
        self.queryset = CLBLocationRegion.objects.all()
        self.serializer_class = CLBLocationRegionSerializer
        self.lookup_url_kwarg = 'region'
        self.search_fields = ('region_name',)
        self.filter_fields = ('continent',)

    def get(self, request, *args, **kwargs):
        return super(CLBLocationRegionAPI, self).list(request, *args, **kwargs)


class MyInfraServerGroupSimpleAPI(ListModelMixin,
                                  SpectrumGenericAPIView):

    def __init__(self):
        super(MyInfraServerGroupSimpleAPI, self).__init__()
        self.queryset = CustomerContractPop.all_objects.filter(use_type=1).all()
        self.serializer_class = MyInfraServerGroupSimpleSerializer
        self.lookup_url_kwarg = 'group_id'
        self.filter_fields = ('customer',)

    def get(self, request, *args, **kwargs):
        return super(MyInfraServerGroupSimpleAPI, self).list(request, *args, **kwargs)


##################################################################################################################
#
# 2017.03 Speed improvement
# modify : hyejun.yim
#
##################################################################################################################
def get_related_zone_deploy_status_text(clb_list):
    related_zone_status_list = {}
    zone_deploy_status = 4
    stage_deploy_failed = False
    is_clb_zone_status_pending = False
    msg = ''

    temp_group_id = None
    zone_status = None
    for i, clb_zone in enumerate(clb_list):
        if i == 0:
            temp_group_id = clb_zone['group_id']

        if temp_group_id != clb_zone['group_id']:
            if stage_deploy_failed:
                zone_deploy_status = -2

            if zone_deploy_status < 0:  # commented code block because long text cropped into iframe at aurora
                msg = "(related zone deploy failed)"

            if is_clb_zone_status_pending:  # commented code block because long text cropped into iframe at aurora
                msg = "(related zone deploy pending)"

            related_zone_status_list[temp_group_id] = {"group_id":temp_group_id,
                                                       "related_zone_deploy_status_text":msg
                                                       }

            # initailize with change group_id
            zone_deploy_status = 4
            stage_deploy_failed = False
            is_clb_zone_status_pending = False
            msg = ''
            temp_group_id = clb_zone['group_id']

        zone_status = int(clb_zone['zone_deploy_status'])
        if zone_deploy_status > zone_status:
            zone_deploy_status = zone_status
        if zone_status == -2:
            stage_deploy_failed = True
        if zone_status == 1 or zone_status == 3:
            is_clb_zone_status_pending = True

        if (i+1) == len(clb_list):
            if stage_deploy_failed:
                zone_deploy_status = -2

            if zone_deploy_status < 0:  # commented code block because long text cropped into iframe at aurora
                msg = "(related zone deploy failed)"

            if is_clb_zone_status_pending:  # commented code block because long text cropped into iframe at aurora
                msg = "(related zone deploy pending)"

            related_zone_status_list[temp_group_id] = {"group_id":temp_group_id,
                                                       "related_zone_deploy_status_text":msg
                                                       }

    return related_zone_status_list

def get_servergroup_status_info(servergroup_list):
    servergroup_info = {}

    if len(servergroup_list) <= 0:
        return servergroup_info

    sql = """
            SELECT DISTINCT *
                , if(aa.zone_status > aa.clb_domain_status, aa.clb_domain_status, aa.zone_status) as zone_deploy_status
            FROM (
                SELECT
                    cbp.id as group_id
                    , cbp.pop_id
                    , bp.`status` as pop_status
                    , dz.zone_id, dz.domain_name, dz.status as zone_status
                    , (select min(a.status) from spectrum.gslb_domain a where a.clb_dns_zone = dz.zone_id) as clb_domain_status
                FROM spectrum.customer_contract_base_pop cbp
                    LEFT JOIN spectrum.base_pop bp ON cbp.pop_id = bp.pop_id
                    LEFT JOIN spectrum.base_system bs ON bs.obj_state = 1 AND bp.pop_id = bs.pop_id
                    LEFT JOIN spectrum.base_host bh ON bh.obj_state = 1 AND bs.system_id = bh.system_id
                    LEFT JOIN spectrum.base_vip bv ON bv.obj_state = 1 AND bh.host_id = bv.host_id
                    LEFT JOIN spectrum.gslb_domain_vip gdv ON bv.vip_id = gdv.vip_id
                    LEFT JOIN spectrum.gslb_domain gd ON gd.clb_dns_zone is not null AND gdv.domain_id = gd.domain_id
                    RIGHT JOIN spectrum.dns_zone dz ON dz.obj_state = 1 AND gd.clb_dns_zone = dz.zone_id
                WHERE cbp.id in (%s)

                UNION ALL

                SELECT
                    cbp.id as group_id
                    , cbp.pop_id
                    , bp.`status` as pop_status
                    , dz.zone_id, dz.domain_name, dz.status as zone_status
                    , (select min(a.status) from spectrum.gslb_domain a where a.clb_dns_zone = dz.zone_id) as clb_domain_status
                FROM spectrum.customer_contract_base_pop cbp
                    LEFT JOIN spectrum.base_pop bp ON cbp.pop_id = bp.pop_id
                    LEFT JOIN spectrum.base_pop_dns_zone_relation bpdz ON cbp.pop_id = bpdz.pop_id
                    RIGHT JOIN spectrum.dns_zone dz ON dz.obj_state = 1 AND bpdz.zone_id = dz.zone_id
                WHERE cbp.id in (%s)
            ) aa
            ORDER BY aa.group_id, aa.zone_id;
        """

    format_strings = ','.join(map(lambda x: '%s', servergroup_list))
    sql = sql % (format_strings, format_strings)
    params = []
    params.extend(servergroup_list)
    params.extend(servergroup_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, params)
    rs = cursor.fetchall()

    clb_list = []
    try:
        for obj in rs:
            clb_list.append({"group_id":obj[0],
                             "pop_id":obj[1],
                             "pop_status":obj[2],
                             "zone_id":obj[3],
                             "domain_name":obj[4],
                             "zone_status":obj[5],
                             "clb_domain_status":obj[6],
                             "zone_deploy_status":obj[7]
                             })
    finally:
        cursor.close()
        connections['default'].close()

    return get_related_zone_deploy_status_text(clb_list)

def get_probe_set(customer):
    avail_probe_array = []

    sql = """
            SELECT 
                probe.probeconfig_id,
                probe.name,
                probe.description,
                probe.alert_message
            FROM base_probeconfig probe
            WHERE (
                probe.use_clb = True 
                AND NOT probe.probeconfig_id IN (
                            SELECT cap.probeconfig_id
                            FROM spectrum.customer_allow_probeconfig cap
                            WHERE cap.obj_state = True 
                                AND NOT cap.customer_id = %s
                                AND NOT cap.probeconfig_id IN (
                                            SELECT probeconfig_id
                                            FROM spectrum.customer_allow_probeconfig
                                            WHERE customer_id = %s AND obj_state = True
                                        )
                        )
            );
        """
    cursor = connections['default'].cursor()
    cursor.execute(sql, [int(customer), int(customer)])
    rs = cursor.fetchall()

    try:
        for obj in rs:
            avail_probe_array.append({"probeconfig_id":obj[0],
                                      "name":obj[1],
                                      "description":obj[2],
                                      "alert_message":obj[3]
                                      })
    finally:
        cursor.close()
        connections['default'].close()

    return avail_probe_array

def get_vip_set(servergroup_list, customer):
    vipset_list = {}

    if len(servergroup_list) <= 0:
        return vipset_list

    avail_probes = get_probe_set(customer)
    probe_set = [probe.get('probeconfig_id') for probe in avail_probes]

    sql = """
            SELECT
                cbp.id as group_id
                , bv.vip_id, bv.vip_addr, bv.vip_alias_name, bv.enable_gslb
                , bvp.probe_id, probe.name
            FROM spectrum.customer_contract_base_pop cbp
                LEFT JOIN spectrum.base_pop bp ON cbp.pop_id = bp.pop_id
                INNER JOIN spectrum.base_system bs ON bs.obj_state = 1 AND bp.pop_id = bs.pop_id
                INNER JOIN spectrum.base_host bh ON bh.obj_state = 1 AND bs.system_id = bh.system_id
                INNER JOIN spectrum.base_vip bv ON bv.obj_state = 1 AND bh.host_id = bv.host_id
                LEFT JOIN spectrum.base_vip_probe bvp ON bv.vip_id = bvp.vip_id
                LEFT JOIN spectrum.base_probeconfig probe ON bvp.probe_id = probe.probeconfig_id
            WHERE cbp.id in (%s)
            ORDER BY cbp.id, bv.vip_id;
        """

    format_strings = ','.join(map(lambda x: '%s', servergroup_list))
    sql = sql % (format_strings)
    params = []
    params.extend(servergroup_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, tuple(params))
    rs = cursor.fetchall()

    try:
        temp_group_id = None
        temp_vip_id = None
        temp_vip_addr = None
        temp_vip_alias_name = None
        temp_enable_gslb = None
        temp_vip_probe_set = []

        for i, obj in enumerate(rs):
            if i == 0:  # forloop first
                temp_group_id = obj[0]
                vipset_list[temp_group_id] = {"vip_set":[]}
            elif temp_group_id != obj[0] or temp_vip_id != obj[1]:  # group_id, vip_id check
                vipset_list[temp_group_id]['vip_set'].append({"vip":temp_vip_id,
                                                              "vip_addr":temp_vip_addr,
                                                              "vip_alias_name":temp_vip_alias_name,
                                                              "enable_gslb":temp_enable_gslb,
                                                              "vipprobe_set":temp_vip_probe_set
                                                              })
                # initailize with change vip_id
                temp_vip_probe_set = []
                if temp_group_id != obj[0]:  # group_id check
                    vipset_list[obj[0]] = {"vip_set":[]}
                    temp_group_id = obj[0]

            temp_vip_id = obj[1]
            temp_vip_addr = obj[2]
            temp_vip_alias_name = obj[3]
            temp_enable_gslb = obj[4]

            if obj[5] in probe_set:
                temp_vip_probe_set.append(obj[6])

            if (i+1) == len(rs):
                vipset_list[obj[0]]['vip_set'].append({"vip":obj[1],
                                                       "vip_addr":obj[2],
                                                       "vip_alias_name":obj[3],
                                                       "enable_gslb":obj[4],
                                                       "vipprobe_set":temp_vip_probe_set
                                                       })

    finally:
        cursor.close()
        connections['default'].close()

    return vipset_list

def get_server_servergroup_info(server_list):
    server_info = {}

    if len(server_list) <= 0:
        return server_info

    sql = """
            SELECT
                bv.vip_id, bv.vip_addr
                , bh.host_id, bh.host_name
                , bs.system_id, bs.system_name
                , bp.pop_id, bp.pop_name
                , cbp.id as group_id, cbp.pop_alias as group_name
                , clr.region_id, clr.region_name
            FROM spectrum.base_vip bv
                LEFT JOIN spectrum.base_host bh ON bh.host_id = bv.host_id 
                LEFT JOIN spectrum.base_system bs ON bs.system_id = bh.system_id
                LEFT JOIN spectrum.base_pop bp ON bp.pop_id = bs.pop_id
                LEFT JOIN spectrum.customer_contract_base_pop cbp ON cbp.pop_id = bp.pop_id
                LEFT JOIN spectrum.clb_location_region clr ON cbp.region_id = clr.region_id
            WHERE bv.vip_id in (%s);
        """

    format_strings = ','.join(map(lambda x: '%s', server_list))
    sql = sql % (format_strings)
    params = []
    params.extend(server_list)

    cursor = connections['default'].cursor()
    cursor.execute(sql, params)
    rs = cursor.fetchall()

    clb_list = []
    try:
        for obj in rs:
            server_info[obj[0]] = {"vip_id":obj[0],
                                   "vip_addr":obj[1],
                                   "host_id":obj[2],
                                   "host_name":obj[3],
                                   "system_id":obj[4],
                                   "system_name":obj[5],
                                   "pop_id":obj[6],
                                   "pop_name":obj[7],
                                   "group_id":obj[8],
                                   "group_name":obj[9],
                                   "region_id":obj[10],
                                   "region_name":obj[11]
                                   }
    finally:
        cursor.close()
        connections['default'].close()

    return server_info

class MyInfraServerGroupReAPI(ListModelMixin, SpectrumGenericAPIView):
    def __init__(self):
        super(MyInfraServerGroupReAPI, self).__init__()
        self.queryset = CustomerContractPop.all_objects.filter(use_type=1).all()
        self.serializer_class = MyInfraServerGroupReSerializer
        self.lookup_url_kwarg = 'id'
        self.search_fields = ('group_name',)
        self.filter_fields = ('customer',)

    def get(self, request, *args, **kwargs):
        ret = super(MyInfraServerGroupReAPI, self).list(request, *args, **kwargs)

        if isinstance(ret.data, list):
            ret_data = ret.data
        elif isinstance(ret.data, dict):
            ret_data = ret.data.get('results')
        else:
            ret_data = []

        servergroup_list = []
        for result in ret_data:
            servergroup_list.append(str(result['group_id']))

        customer = request.GET.get('customer')
        servergroup_status_info = get_servergroup_status_info(servergroup_list)
        vip_set_info = get_vip_set(servergroup_list, customer)

        for result in ret_data:
            if servergroup_status_info.has_key(result['group_id']):
                result['related_zone_deploy_status_text'] = servergroup_status_info[result['group_id']]['related_zone_deploy_status_text']
            else:
                result['related_zone_deploy_status_text'] = ''
            if vip_set_info.has_key(result['group_id']):
                result['vip_set'] = vip_set_info[result['group_id']]['vip_set']
            else:
                result['vip_set'] = []

        return ret

class MyInfraServerGroupDetailReAPI(RetrieveModelMixin, SpectrumGenericAPIView):

    def __init__(self):
        super(MyInfraServerGroupDetailReAPI, self).__init__()
        self.queryset = CustomerContractPop.all_objects.all()
        self.serializer_class = MyInfraServerGroupReSerializer
        self.lookup_url_kwarg = 'id'
        self.search_fields = ('contract_no', 'pop_alias',)
        self.filter_fields = ('region', 'use_type', 'probe_agent_selection_type',)

    def get(self, request, *args, **kwargs):
        ret = super(MyInfraServerGroupDetailReAPI, self).retrieve(request, *args, **kwargs)

        results = ret.data
        group_id = results['group_id']

        customer = request.GET.get('customer', '')
        if customer == '':
            try:
                customer_contract_pop = CustomerContractPop.all_objects.get(pk=group_id)
                customer = customer_contract_pop.customer.customer_id
            except CustomerContractPop.DoesNotExist:
                raise CLBAPIException(status.HTTP_404_NOT_FOUND,
                                      _('This Server Group is not exist.'))

        servergroup_status_info = get_servergroup_status_info([group_id])
        vip_set_info = get_vip_set([group_id], customer)

        if len(servergroup_status_info) > 0:
            results['related_zone_deploy_status_text'] = servergroup_status_info[group_id]['related_zone_deploy_status_text']
        else:
            results['related_zone_deploy_status_text'] = ''

        if len(vip_set_info) > 0:
            results['vip_set'] = vip_set_info[group_id]['vip_set']
        else:
            results['vip_set'] = []

        ret.data = results

        return ret

class MyInfraServerReAPI(ListModelMixin, SpectrumGenericAPIView):

    def __init__(self):
        super(MyInfraServerReAPI, self).__init__()
        self.object = None
        self.queryset = Vip.objects.select_related('host__system__pop__customercontractpop').all()
        self.serializer_class = MyInfraServerReSerializer
        self.lookup_url_kwarg = 'server_id'
        self.filter_fields = ('host',
                              {'pop': 'host__system__pop'},
                              {'group_id': 'host__system__pop__customercontractpop'})

    def get(self, request, *args, **kwargs):
        response = super(MyInfraServerReAPI, self).list(request, *args, **kwargs)

        if isinstance(response.data, list):
            ret_data = response.data
        elif isinstance(response.data, dict):
            ret_data = response.data.get('results')
        else:
            ret_data = []

        server_list = []
        for result in ret_data:
            server_list.append(str(result['server_id']))

        server_info = get_server_servergroup_info(server_list)

        for result in ret_data:
            if server_info.has_key(result['server_id']):
                result['group_id'] = server_info[result['server_id']]['group_id']
                result['group_name'] = server_info[result['server_id']]['group_name']
                result['region'] = server_info[result['server_id']]['region_id']
                result['region_name'] = server_info[result['server_id']]['region_name']
            else:
                result['group_id'] = None
                result['group_name'] = ''
                result['region'] = None
                result['region_name'] = ''

        customer = request.GET.get('customer')
        avail_probes = CustomerContractPop.get_avaliable_probes(customer)

        avail_probe_array = []
        for probe in avail_probes:
            avail_probe_array.append(probe['probeconfig_id'])

        for data in ret_data:
            server_health_checks = data.get('server_health_checks')
            for shc in server_health_checks:
                if shc['probe'] not in avail_probe_array:
                    server_health_checks.remove(shc)

        return response
##################################################################################################################

class MyInfraServerGroupAPI(ListModelMixin,
                            CreateModelMixin,
                            SpectrumGenericAPIView):
    def __init__(self):
        super(MyInfraServerGroupAPI, self).__init__()
        self.queryset = CustomerContractPop.all_objects.filter(use_type=1).all()
        self.serializer_class = MyInfraServerGroupSerializer
        self.lookup_url_kwarg = 'id'
        self.search_fields = ('group_name',)
        self.filter_fields = ('customer',)

    def get(self, request, *args, **kwargs):
        return super(MyInfraServerGroupAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.DATA, files=request.FILES)
            if not serializer.is_valid():
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            group_state = cleanup_enable_gslb(request.DATA.get("enable_gslb", None))
            health_check = serializer.object.probe_agent_selection_type
            group_name = serializer.object.pop_alias
            customer = serializer.object.customer
            region = serializer.object.region

            #if len(error_dict) >= 1:
            #    raise CLBAPICustomException(error_dict)

            try:
                clb_location_primary_pop = CLBLocationRegionBasePop.all_objects.get(
                    region=region, is_primary=True, obj_state=1)
                primary_pop = clb_location_primary_pop.pop
            except CLBLocationRegionBasePop.DoesNotExist:
                raise CLBAPIException(status.HTTP_400_BAD_REQUEST, _('primary location pop does not exist.'))

            customer_pop, pop_iscreated = clb_location_primary_pop.create_customer_pop(request, customer, group_state)

            pop_arr = clb_location_primary_pop.get_pop_list_from_region()
            customer_pop.set_pkloss_servers(request, pop_arr)
            customer_pop.mapping_probeagent_for_clb_region_pop(request, pop_arr, primary_pop)

            if not pop_iscreated:
                raise CLBAPIException(status.HTTP_500_INTERNAL_SERVER_ERROR,
                                      _('Cannot make more server_group > 9999. Please Contact to Administrator!'))
            else:
                customer_pop.enable_gslb = group_state
                customer_pop.save(request=request)

                contracts = CustomerItem.all_objects.filter(
                    Q(contract__account__account_no=customer.account.account_no),
                    Q(material_no=1199),
                    Q(contract__contract_terminate__gte=datetime.today(),
                      contract__contract_end__gte=datetime.today()) |
                    Q(contract__contract_terminate__isnull=True,
                      contract__contract_end__gte=datetime.today())
                )
                if contracts.count() == 1:
                    contract_obj = contracts[0].contract
                else:
                    contract_obj = None

                system_obj = customer_pop.create_new_customer_system(request)
                host_obj = system_obj.create_new_customer_host(request)

                cust_clb_pop = CustomerContractPop(contract_no=contract_obj,
                                                   customer=customer,
                                                   pop_alias=group_name,
                                                   pop=customer_pop, region=region, use_type=1,
                                                   obj_state=1,
                                                   probe_agent_selection_type=health_check)
                cust_clb_pop.save(request=request)
                return Response(json.loads(cust_clb_pop.toJSON()), status=status.HTTP_201_CREATED)
        except CLBAPICustomException, ce:
            return Response(data=ce.fail_data, status=status.HTTP_400_BAD_REQUEST)
        except Exception, e:
            raise CLBAPIException(status.HTTP_500_INTERNAL_SERVER_ERROR, e)


class MyInfraServerGroupDetailAPI(RetrieveModelMixin,
                                  UpdateModelMixin,
                                  DestroyModelMixin,
                                  SpectrumGenericAPIView):

    def __init__(self):
        super(MyInfraServerGroupDetailAPI, self).__init__()
        self.queryset = CustomerContractPop.all_objects.all()
        self.serializer_class = MyInfraServerGroupSerializer
        self.lookup_url_kwarg = 'id'
        self.search_fields = ('contract_no', 'pop_alias',)
        self.filter_fields = ('region', 'use_type', 'probe_agent_selection_type',)

    def get(self, request, *args, **kwargs):
        return super(MyInfraServerGroupDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(self.get_object(), data=request.DATA, files=request.FILES)
            if not serializer.is_valid():
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            group_name = serializer.object.pop_alias
            group_state = cleanup_enable_gslb(request.DATA.get("enable_gslb", None))
            customer = serializer.object.customer
            region = serializer.object.region

            cust_clb_pop = self.get_object()
            before_region = cust_clb_pop.region

            cust_clb_pop.pop_alias = group_name
            cust_clb_pop.region = region
            cust_clb_pop.save(request=request)

            customer_pop = cust_clb_pop.pop

            cust_clb_pop.get_or_create_host(request=request)

            try:
                clb_location_primary_pop = CLBLocationRegionBasePop.all_objects.get(
                    region=region, is_primary=True, obj_state=1)
                primary_pop = clb_location_primary_pop.pop
            except CLBLocationRegionBasePop.DoesNotExist:
                raise CLBAPIException(status.HTTP_400_BAD_REQUEST, _('primary location pop does not exist.'))

            customer_pop.enable_gslb = group_state
            customer_pop.rttserver = primary_pop.rttserver
            customer_pop.save(request=request)

            # add request ##################
            if before_region != region:
                pop_xml_changed = False
                #### delete old seting
                pakloss_server_set = customer_pop.pktlossserver.select_related('pakloss_server_set')
                for obj in pakloss_server_set:
                    customer_pop.pktlossserver.remove(obj)
                    pop_xml_changed = True

                popagentconf_set = PopProbeAgentConfig.all_objects.filter(pop=customer_pop)
                for popabentconf_obj in popagentconf_set:
                    popabentconf_obj.delete(request=request)
                    pop_xml_changed = True

                pop_arr = clb_location_primary_pop.get_pop_list_from_region()
                customer_pop.set_pkloss_servers(request, pop_arr)
                customer_pop.mapping_probeagent_for_clb_region_pop(request, pop_arr, primary_pop)

                if pop_xml_changed:
                    customer_pop.save(request=request)
                    # pop level change does not affect gslb domain xml change
                    # pop_obj.update_status_modified_related_clb_zones(request=request)

            return Response(json.loads(cust_clb_pop.toJSON()), status=status.HTTP_200_OK)
        except CLBAPICustomException, ce:
            return Response(data=ce.fail_data, status=status.HTTP_400_BAD_REQUEST)
        except Exception, e:
            raise CLBAPIException(status.HTTP_500_INTERNAL_SERVER_ERROR, e)

    def delete(self, request, *args, **kwargs):
        cust_clb_pop = self.get_object()
        customer_pop = cust_clb_pop.pop

        if customer_pop:
            vips_objs = Vip.all_objects.filter(host__system__pop=cust_clb_pop.pop_id)
            for vips_obj in vips_objs:
                vips_obj.delete(request=request)

            vips_probe_objs = VipProbeConfigs.all_objects.filter(vip__in=vips_objs)
            for vips_probe_obj in vips_probe_objs:
                vips_probe_obj.delete(request=request)

            hosts_objs = Host.all_objects.filter(system__pop=cust_clb_pop.pop_id)
            for hosts_obj in hosts_objs:
                hosts_obj.delete(request=request)

            systems_objs = System.all_objects.filter(pop=cust_clb_pop.pop_id)
            for systems_obj in systems_objs:
                systems_obj.delete(request=request)

            popagentconf_set = PopProbeAgentConfig.all_objects.filter(pop=cust_clb_pop.pop)
            for popabentconf_obj in popagentconf_set:
                popabentconf_obj.delete(request=request)

            pop = cust_clb_pop.pop
            # pop level change does not affect gslb domain xml change
            # pop.update_status_modified_related_clb_zones(request=request)

            cust_clb_pop_deleted = super(MyInfraServerGroupDetailAPI, self).destroy(request, *args, **kwargs)
            pop.delete(request=request)
        else:
            cust_clb_pop_deleted = super(MyInfraServerGroupDetailAPI, self).destroy(request, *args, **kwargs)
        return cust_clb_pop_deleted


class MyInfraServerGroupDeletableAPI(RetrieveModelMixin,
                                     SpectrumGenericAPIView):

    def __init__(self):
        super(MyInfraServerGroupDeletableAPI, self).__init__()
        self.queryset = CustomerContractPop.all_objects.filter(use_type=1).all()
        self.serializer_class = MyInfraServerGroupDeletableSerializer
        self.lookup_url_kwarg = 'id'
        self.search_fields = ('contract_no', 'pop_alias',)
        self.filter_fields = ('region', 'use_type', 'probe_agent_selection_type',)

    def get(self, request, *args, **kwargs):
        return super(MyInfraServerGroupDeletableAPI, self).retrieve(request, *args, **kwargs)


class MyInfraServerGroupStatusAPI(SpectrumGenericAPIView):

    def get(self, request, *args, **kwargs):
        customer = request.GET.get('customer', None)
        cust_clb_pop = CustomerContractPop.all_objects.filter(use_type=1).all()
        if customer:
            cust_clb_pop = cust_clb_pop.filter(customer=customer)

        pop_status = 4
        for cust_clb in cust_clb_pop:
            if pop_status > cust_clb.pop.status:
                pop_status = cust_clb.pop.status
            if cust_clb.pop.status == -4:
                break

        return Response({'status': pop_status, 'customer': customer})


class MyInfraServerAPI(ListModelMixin,
                       CreateModelMixin,
                       SpectrumGenericAPIView):

    def __init__(self):
        super(MyInfraServerAPI, self).__init__()
        self.object = None
        self.queryset = Vip.objects.select_related('host__system__pop__customercontractpop').all()
        #self.queryset = Vip.objects.all()
        self.serializer_class = MyInfraServerSerializer
        self.lookup_url_kwarg = 'server_id'
        self.filter_fields = ('host',
                              {'pop': 'host__system__pop'},
                              {'group_id': 'host__system__pop__customercontractpop'})

    def get(self, request, *args, **kwargs):
        response = super(MyInfraServerAPI, self).list(request, *args, **kwargs)

        if isinstance(response.data, list):
            ret_data = response.data
        elif isinstance(response.data, dict):
            ret_data = response.data.get('results')
        else:
            ret_data = []

        customer = request.GET.get('customer')
        avail_probes = CustomerContractPop.get_avaliable_probes(customer)

        avail_probe_array = []
        for probe in avail_probes:
            avail_probe_array.append(probe['probeconfig_id'])

        for data in ret_data:
            server_health_checks = data.get('server_health_checks')
            for shc in server_health_checks:
                if shc['probe'] not in avail_probe_array:
                    server_health_checks.remove(shc)

        return response

    @transaction.commit_on_success
    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.DATA, files=request.FILES)

        if not serializer.is_valid():
            if 'vip_addr' in serializer.errors:
                serializer.errors.update({'ip': serializer.errors['vip_addr']})
            if 'vip_name' in serializer.errors:
                serializer.errors.update({'detail': serializer.errors['vip_name']})
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        return super(MyInfraServerAPI, self).create(request, *args, **kwargs)

    def post_save(self, obj, created=False):
        """
        if obj.host and not obj.vip_name:
            vip_name = obj.host.get_next_vip_name()
            obj.vip_name = vip_name
            obj.save(request=self.request)
        """

        if created:
            obj.host.system.pop.save(request=self.request)


class MyInfraServerDetailAPI(RetrieveModelMixin,
                             UpdateModelMixin,
                             DestroyModelMixin,
                             SpectrumGenericAPIView):

    def __init__(self):
        super(MyInfraServerDetailAPI, self).__init__()
        self.queryset = Vip.objects.all()
        self.serializer_class = MyInfraServerSerializer
        self.lookup_url_kwarg = 'server_id'
        self.pop_changed = False

    def get(self, request, *args, **kwargs):
        return super(MyInfraServerDetailAPI, self).retrieve(request, *args, **kwargs)

    @transaction.commit_on_success
    def put(self, request, *args, **kwargs):
        self.request = request
        self.object = self.get_object_or_none()
        serializer = self.get_serializer(self.object, data=request.DATA,
                                         files=request.FILES, partial=False)
        if not serializer.is_valid():
            if 'vip_addr' in serializer.errors:
                serializer.errors.update({'ip': serializer.errors['vip_addr']})
            if 'vip_name' in serializer.errors:
                if isinstance(serializer.errors['vip_name'], list):
                    serializer.errors.update({'detail': serializer.errors['vip_name'][0]})
                else:
                    serializer.errors.update({'detail': serializer.errors['vip_name']})
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        try:
            server_health_checks = request.DATA.get('server_health_checks')
            for shc in server_health_checks:
                vip_id = int(self.object.pk)
                probe_id = int(shc['probe'])
                try:
                    # vip_probe search
                    vip_probe_id = VipProbeConfigs.all_objects.get(vip__pk=int(vip_id), probe__pk=probe_id).pk
                except:
                    vip_probe_id = None

                # There are "vip_probe" has already been registered, 
                # and if there is no additional "server health checks" "vip probe id" directory.
                if vip_probe_id is not None and 'vip_probe_id' not in dir(shc):
                    shc['vip_probe_id'] = vip_probe_id

            request.DATA['server_health_checks'] = server_health_checks
        except Exception, e:
            raise CLBAPIException(status.HTTP_400_BAD_REQUEST, e)

        return_data = super(MyInfraServerDetailAPI, self).update(request, *args, **kwargs)
        return return_data

    @transaction.commit_on_success
    def patch(self, request, *args, **kwargs):
        return_data = super(MyInfraServerDetailAPI, self).partial_update(request, *args, **kwargs)
        return return_data

    def delete(self, request, *args, **kwargs):
        try:
            delete_vip = kwargs[self.lookup_url_kwarg]
            check_delete_vip(delete_vip)
            check_delete_actions(delete_vip)

            reg = super(MyInfraServerDetailAPI, self).destroy(request, *args, **kwargs)
        except Exception, e:
            raise CLBAPIException(status.HTTP_500_INTERNAL_SERVER_ERROR, e)
        return reg

    def pre_save(self, obj):
        try:
            original_vip = Vip.objects.get(pk=obj.pk)
            if original_vip.vip_alias_name != obj.vip_alias_name \
                    or original_vip.vip_addr != obj.vip_addr \
                    or original_vip.enable_gslb != obj.enable_gslb:
                self.pop_changed = True

            # [AURORAUI-2318]
            # The following code will check between previous modified data and modified data.
            # If 'group_id' is different each other, previous modified data will save to change deploy status 'On Staging Server' to 'Modified'
            if original_vip.host.system.pop.pop != obj.host.system.pop.pop:
                original_vip.host.system.pop.status = 0
                original_vip.host.system.pop.save(request=self.request)

        except Vip.DoesNotExist:
            raise CLBAPIException(status.HTTP_404_NOT_FOUND, _('Does not exist.'))

    def post_save(self, obj, created=False):
        if not created:
            if self.pop_changed:
                obj.host.system.pop.save(request=self.request)
            self.normilize()

    def normilize(self):
        normalized_actions = DomainStaticRuleNormalizedAction.objects.filter(vip=self.object)
        if normalized_actions.exists():
            rule_actions = []
            for normalized_action in normalized_actions:
                if normalized_action.domain_staticrule_action not in rule_actions:
                    action_string = normalized_action.domain_staticrule_action.get_denormalized_action()
                    normalized_action.domain_staticrule_action.action = action_string
                    normalized_action.domain_staticrule_action.save(request=self.request)
                    rule_actions.append(normalized_action.domain_staticrule_action)


class MyInfraServerDetailRelatedDomainAPI(RetrieveModelMixin,
                                          SpectrumGenericAPIView):

    def __init__(self):
        super(MyInfraServerDetailRelatedDomainAPI, self).__init__()
        self.queryset = Vip.objects.all()
        self.serializer_class = MyInfraServerDetailRelatedDomainSerializer
        self.lookup_url_kwarg = 'server_id'
        self.pop_changed = False

    def get(self, request, *args, **kwargs):
        return super(MyInfraServerDetailRelatedDomainAPI, self).retrieve(request, *args, **kwargs)


class MyInfraAvailableProbeAPI(SpectrumGenericAPIView):

    def __init__(self):
        super(MyInfraAvailableProbeAPI, self).__init__()

    def get(self, request, *args, **kwargs):
        customer = request.GET.get('customer')
        data = CustomerContractPop.get_avaliable_probes(customer)

        return Response(data)


class MyinfraStatusAPI(RetrieveModelMixin,
                       SpectrumGenericAPIView):

    def __init__(self):
        super(MyinfraStatusAPI, self).__init__()

    def get(self, request, *args, **kwargs):
        customer_pk = request.GET.get('customer')
        try:
            customer = CustomerDisplay.objects.get(pk=customer_pk)
        except CustomerDisplay.DoesNotExist:
            return Response(status=status.HTTP_400_BAD_REQUEST, data={'customer': 'This field is required.'})

        cust_clb_pops = CustomerContractPop.all_objects.filter(use_type=1).all().filter(customer=customer)
        pop_status, related_zone_status, timeout, time_deployed, errmsg, failed_zones, failed_domains = customer.get_clb_pop_deploy_status(request)
        if pop_status == -4:
            cust_clb_pops = cust_clb_pops.filter(pop__status=-4)
        elif pop_status == -2:
            cust_clb_pops = cust_clb_pops.filter(pop__status=-2)
        elif pop_status == 0:
            cust_clb_pops = cust_clb_pops.filter(pop__status=0)
        elif pop_status == 1:
            cust_clb_pops = cust_clb_pops.filter(pop__status=1)
        elif pop_status == 2:
            cust_clb_pops = cust_clb_pops.filter(pop__status=2)
        elif pop_status == 3:
            cust_clb_pops = cust_clb_pops.filter(pop__status=3)
        elif pop_status == 4:
            cust_clb_pops = cust_clb_pops.filter(pop__status=4)

        cust_clb_pops_arr = []
        for z in cust_clb_pops:
            cust_clb_pops_arr.append({
                'group_id': z.pk,
                'group_name': z.pop_alias
            })

        if len(errmsg) > 0:
            msg = "<br>".join(errmsg)
        else:
            msg = ''
        return_data = {
            'customer_pk': customer_pk,
            'domain_name': '',
            'cust_clb_pops': cust_clb_pops_arr,
            'default_staging_ns': DEFAULT_STAGING_NS,
            'status': pop_status,
            'related_zone_status': related_zone_status,
            'timeout': timeout,
            'time_deployed': str(time_deployed),
            'msg': msg}

        return Response(status=status.HTTP_200_OK, data=return_data)


def check_delete_vip(delete_vip):
    try:
        vip = Vip.objects.get(pk=delete_vip)
    except Vip.DoesNotExist:
        raise CLBAPIException(status.HTTP_404_NOT_FOUND,
                              _('This vip is not exist.'))

    if not vip.is_deletable():
        msg = 'Failed to delete. Server %s is internally in use. ' \
              'If you want to proceed, please contact support center' % vip.vip_alias_name
        raise CLBAPIException(status.HTTP_500_INTERNAL_SERVER_ERROR, _(msg))

    domains = Domain.objects.filter(vips__vip=delete_vip)

    deletable = True
    check_domain_arr = []
    for domain in domains:
        domain_vip = DomainVip.objects.filter(domain=domain).exclude(vip=delete_vip)
        if not domain_vip.exists() and domain.etc_policy is None:
            deletable = False
            check_domain_arr.append(domain.name)

    if deletable is False:
        raise CLBAPIException(
            status.HTTP_400_BAD_REQUEST,
            _('This ip is uniquely bound to clb domain [%s]. Please remove the IP from the specified domain first.'
              % ', '.join(check_domain_arr)))


def check_delete_actions(delete_vip):
    deletable = True
    actions = DomainStaticRuleNormalizedAction.objects.filter(vip=delete_vip)
    if not actions.exists():
        return deletable

    exclude_actions = actions.values_list('domain_staticrule_action__condition', 'domain_staticrule_action')
    (cond_ids, ex_act_ids) = zip(*exclude_actions)

    check_domain_arr = []
    for cond_id in cond_ids:
        if not DomainStaticRuleAction.objects.filter(condition=cond_id).\
                exclude(domain_staticrule_action_id__in=ex_act_ids).exists():
            deletable = False
            domain_name = DomainStaticRuleCondition.objects.\
                get(domain_staticrule_condition_id=cond_id).domain.name
            check_domain_arr.append(domain_name)

    if deletable is False:
        raise CLBAPIException(
            status.HTTP_400_BAD_REQUEST,
            _('This ip is uniquely bound to clb domain [%s]. Please remove the IP from the specified domain first.'
            % ', '.join(check_domain_arr)))
