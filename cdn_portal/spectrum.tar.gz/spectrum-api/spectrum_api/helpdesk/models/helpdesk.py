import datetime
from django.db import models
from spectrum_api.shared_components.models.customer import CustomerAccount
from spectrum_api.shared_components.models import BaseModel


class HelpDesk(BaseModel):
    help_id = models.AutoField(primary_key=True, db_column='help_id')
    account_no = models.PositiveIntegerField(blank=False)
    user_id = models.PositiveIntegerField(blank=False)
    user_name = models.CharField(max_length=100, null=True)
    user_email = models.CharField(max_length=100, null=True)
    result_inform = models.CharField(max_length=5, null=True)
    result_mail = models.CharField(max_length=50, null=True)
    result_sms = models.CharField(max_length=50, null=True)
    error_case_cd = models.PositiveSmallIntegerField(blank=False)
    end_user = models.CharField(max_length=20, null=True)
    os_cd = models.PositiveSmallIntegerField(blank=False)
    mediaplayer_cd = models.PositiveSmallIntegerField(blank=False)
    directx_cd = models.PositiveSmallIntegerField(blank=False)
    cpu_cd = models.PositiveSmallIntegerField(blank=False)
    memory_cd = models.PositiveSmallIntegerField(blank=False)
    help_desc = models.TextField(blank=False)
    error_url = models.CharField(max_length=50, null=True)
    end_user_phone = models.CharField(max_length=20, null=True)
    end_user_id = models.CharField(max_length=50, null=True)
    urgency_call = models.PositiveSmallIntegerField(default=0)
    explorer_cd = models.PositiveSmallIntegerField(null=True)
    city_cd = models.PositiveSmallIntegerField(null=True)
    end_user_type_cd = models.PositiveSmallIntegerField(null=True)
    hope_time_cd = models.PositiveSmallIntegerField(null=True)
    date_created = models.DateTimeField(
        editable=False,
        default=lambda: datetime.datetime.utcnow() + datetime.timedelta(hours=9))
    date_modified = models.DateTimeField(
        default=lambda: datetime.datetime.utcnow() + datetime.timedelta(hours=9))
    latest_updater = models.CharField(max_length=100, null=True)
    register_case_cd = models.PositiveSmallIntegerField(blank=False)

    def get_account_name(self):
        try:
            customer_account = CustomerAccount.objects.using('aurora').get(
                account_no=self.account_no)
            return customer_account.account_name_local
        except:
            return None

    account_name = property(get_account_name)

    class Meta:
        app_label = 'helpdesk'
        db_table = 'help_desk'
        ordering = ['-date_created']

    # noinspection PyClassHasNoInit
    class SpectrumMeta:
        allow_delete = True

    def __unicode__(self):
        return '%s' % self.help_id

    def save(self, **kwargs):
        request = kwargs.get('request', None)
        super(HelpDesk, self).save(**kwargs)


class HelpDeskAccept(BaseModel):
    help_id = models.OneToOneField(HelpDesk, primary_key=True,
                                   related_name='helpdeskaccept',
                                   db_column='help_id')
    user_name = models.CharField(max_length=100, null=True)
    error_cause_cd = models.PositiveSmallIntegerField(blank=False)
    result_cd = models.PositiveSmallIntegerField(blank=False)
    result_desc = models.TextField()
    contact_time_cd = models.PositiveSmallIntegerField(null=True)
    success_time_cd = models.PositiveSmallIntegerField(null=True)
    note = models.CharField(max_length=20, null=True)
    transact_time_cd = models.PositiveSmallIntegerField(null=True)
    request_total = models.PositiveSmallIntegerField(default=1)
    comm_cd = models.PositiveSmallIntegerField(null=True)
    place_cd = models.PositiveSmallIntegerField(null=True)
    owner_cd = models.PositiveSmallIntegerField(null=True)
    date_created = models.DateTimeField(
        editable=False,
        default=lambda: datetime.datetime.utcnow() + datetime.timedelta(hours=9))
    date_modified = models.DateTimeField(
        default=lambda: datetime.datetime.utcnow() + datetime.timedelta(hours=9))
    creator = models.CharField(max_length=100, null=True)
    latest_updater = models.CharField(max_length=100, null=True)

    class Meta:
        app_label = 'helpdesk'
        db_table = 'help_desk_accept'
        ordering = ['-date_created']

    # noinspection PyClassHasNoInit
    class SpectrumMeta:
        allow_delete = True

    def __unicode__(self):
        return u'%s' % self.help_id

    def save(self, **kwargs):
        super(HelpDeskAccept, self).save(**kwargs)


class HelpDeskCd(BaseModel):
    help_cd = models.AutoField(primary_key=True)
    parent_help_cd = models.PositiveSmallIntegerField(blank=False)
    code_depth = models.PositiveSmallIntegerField(default=1)
    code_name = models.CharField(max_length=100, blank=False)
    code_type = models.PositiveSmallIntegerField(blank=False)
    obj_state = models.PositiveSmallIntegerField(default=1)
    sort_key = models.PositiveSmallIntegerField(blank=False)

    class Meta:
        app_label = 'helpdesk'
        db_table = 'help_desk_cd'

    # noinspection PyClassHasNoInit
    class SpectrumMeta:
        allow_delete = False

    def __unicode__(self):
        return u'%s' % self.help_cd

    def save(self, **kwargs):
        super(HelpDeskCd, self).save(**kwargs)


class HelpDeskAcceptTransactCodes(BaseModel):
    transact_id = models.AutoField(primary_key=True, db_column='transact_id')
    help_id = models.ForeignKey(HelpDeskAccept,
                                related_name='helpdeskaccepttransactcodes',
                                db_column='help_id')
    transact_cd = models.PositiveSmallIntegerField(blank=False)
    date_created = models.DateTimeField(
        editable=False,
        default=lambda: datetime.datetime.utcnow() + datetime.timedelta(hours=9))
    date_modified = models.DateTimeField(
        default=lambda: datetime.datetime.utcnow() + datetime.timedelta(hours=9))

    class Meta:
        app_label = 'helpdesk'
        db_table = 'help_desk_accept_transact_codes'
        unique_together = ("help_id", "transact_cd")

    # noinspection PyClassHasNoInit
    class SpectrumMeta:
        allow_delete = True

    def __unicode__(self):
        return u'%s' % self.help_id

    def save(self, **kwargs):
        super(HelpDeskAcceptTransactCodes, self).save(**kwargs)
