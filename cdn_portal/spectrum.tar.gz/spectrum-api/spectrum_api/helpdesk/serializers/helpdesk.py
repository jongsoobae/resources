from rest_framework import serializers
from spectrum_api.helpdesk.models.helpdesk import HelpDesk, HelpDeskAccept, \
    HelpDeskCd, HelpDeskAcceptTransactCodes


class HelpDeskAcceptTransactCodesSerializer(serializers.ModelSerializer):
    help_id = serializers.PrimaryKeyRelatedField()

    class Meta:
        model = HelpDeskAcceptTransactCodes
        fields = (
            "transact_id",
            "transact_cd",
            "date_created",
            "date_modified"
        )

    def get_identity(self, data):
        try:
            return data.get("transact_cd", None)
        except AttributeError:
            return None


class HelpDeskAcceptSerializer(serializers.ModelSerializer):
    help_id = serializers.PrimaryKeyRelatedField()
    transact_list = \
        HelpDeskAcceptTransactCodesSerializer(many=True,
                                              required=False,
                                              read_only=False,
                                              source="helpdeskaccepttransactcodes",
                                              allow_add_remove=True)

    class Meta:
        model = HelpDeskAccept
        fields = (
            "help_id",
            "user_name",
            "error_cause_cd",
            "result_cd",
            "result_desc",
            "contact_time_cd",
            "success_time_cd",
            "note",
            "transact_time_cd",
            "request_total",
            "comm_cd",
            "place_cd",
            "owner_cd",
            "date_created",
            "date_modified",
            "transact_list",
            "creator",
            "latest_updater"
        )


class HelpDeskSerializer(serializers.ModelSerializer):
    account_name = serializers.Field()
    help_desk_accept = HelpDeskAcceptSerializer(source='helpdeskaccept',
                                                required=False, read_only=False)

    class Meta:
        model = HelpDesk
        fields = (
            "help_id",
            "account_no",
            "user_id",
            "user_name",
            "user_email",
            "result_inform",
            "result_mail",
            "result_sms",
            "error_case_cd",
            "end_user",
            "os_cd",
            "mediaplayer_cd",
            "directx_cd",
            "cpu_cd",
            "memory_cd",
            "help_desc",
            "error_url",
            "end_user_phone",
            "end_user_id",
            "urgency_call",
            "explorer_cd",
            "city_cd",
            "end_user_type_cd",
            "hope_time_cd",
            "date_created",
            "date_modified",
            "account_name",
            "latest_updater",
            "help_desk_accept",
            "register_case_cd",
        )


class HelpDeskCdSerializer(serializers.ModelSerializer):
    class Meta:
        model = HelpDeskCd
        fields = (
            "help_cd",
            "parent_help_cd",
            "code_depth",
            "code_name",
            "code_type",
            "obj_state",
            "sort_key",
        )
