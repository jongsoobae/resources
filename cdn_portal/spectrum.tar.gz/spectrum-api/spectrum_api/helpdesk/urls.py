# -*- coding: utf-8 -*-
from django.conf.urls.defaults import *
from rest_framework.urlpatterns import format_suffix_patterns
from spectrum_api.helpdesk.views.helpdesk import HelpDeskAPI, HelpDeskCdAPI, \
    HelpDeskAcceptAPI, HelpDeskStatisticsAPI, change_result_cd


restfw_api_urlpatterns = patterns(
    'spectrum_api.helpdesk.views',
    url(r'^helpdesk/requests/$', HelpDeskAPI.as_view(),
        name="helpdesk-requests"),
    url(r'^helpdesk/requests/(?P<help_id>[0-9]+)/$', HelpDeskAPI.as_view(),
        name="helpdesk-requests-detail"),
    url(r'^helpdesk/request_acceptions/change_result_cd/$', change_result_cd,
        name="helpdesk-requests-detail"),
    url(r'^helpdesk/request_acceptions/$', HelpDeskAcceptAPI.as_view(),
        name="helpdesk-request-acceptions"),
    url(r'^helpdesk/request_acceptions/(?P<help_id>[0-9]+)/$',
        HelpDeskAcceptAPI.as_view(), name="helpdesk-request-acceptions-detail"),
    url(r'^helpdesk/codes/$', HelpDeskCdAPI.as_view(), name="helpdesk-codes"),
    url(r'^helpdesk/statistics/$', HelpDeskStatisticsAPI.as_view(),
        name="helpdesk-statistics"),
)
urlpatterns = format_suffix_patterns(restfw_api_urlpatterns)
