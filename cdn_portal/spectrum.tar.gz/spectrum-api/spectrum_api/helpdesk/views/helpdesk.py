import datetime
import traceback
import urllib2
import re
from xml.dom import minidom
from django.template.loader import render_to_string
from spectrum_api.shared_components.utils.send_mail import MailObject
from django.utils import simplejson
from rest_framework.filters import BaseFilterBackend
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.status import HTTP_400_BAD_REQUEST, \
    HTTP_500_INTERNAL_SERVER_ERROR
from django.utils.translation import ugettext as _
from django.db import connections
from spectrum_api.helpdesk.models.helpdesk import HelpDesk, HelpDeskAccept, \
    HelpDeskCd, HelpDeskAcceptTransactCodes
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.mixins \
    import CreateModelMixin, UpdateModelMixin, DestroyModelMixin, \
    ListModelMixin, RetrieveModelMixin
from spectrum_api.helpdesk.serializers.helpdesk \
    import HelpDeskSerializer, HelpDeskAcceptSerializer, HelpDeskCdSerializer
import re
from rest_framework.exceptions import APIException
from spectrum_api.shared_components.utils.common import log_error
from spectrum_api.config_constants import SUPPORT_CENTER_TEL_NUMBER, \
                                            REPORT_MAIL_SENDER


__MSG_EMAIL_TITLE__ = _(u"HELPDESK.MAIL_TITLE")

RESULT_CODE_EXCEPT_SUPPORT_DONE = {
    'CUSTOMER_DELAY': 58,
    'CENTER_PROCESS': 59,
    'RECEIVE_WAITING': 63,
    'WAITING_CALL': 64,
    'CANNOT_CALL': 193,
}

class HelpDesk500Exception(APIException):
    status_code = HTTP_500_INTERNAL_SERVER_ERROR
    default_detail = _(u'API call failed.')


# Filter
class HelpDeskCustomFilter(BaseFilterBackend):
    """
        This is only for HelpDeskAPI
    """

    def filter_queryset(self, request, queryset, view):
        filter_arguments = {}
        min_date = request.GET.get('date_from', None)
        date_to = request.GET.get('date_to', None)
        if date_to:
            max_date = (datetime.datetime.strptime(date_to, '%Y-%m-%d') +
                        datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        else:
            max_date = date_to

        if min_date and max_date:
            if min_date == max_date:
                filter_arguments['date_created__gte'] = min_date
            else:
                filter_arguments['date_created__range'] = [min_date, max_date]
        elif min_date:
            filter_arguments['date_created__gte'] = min_date
        elif max_date:
            filter_arguments['date_created__lte'] = max_date
        else:
            pass

        if request.GET.get('account_no', None):
            filter_arguments['account_no'] = request.GET.get('account_no', None)
        if request.GET.get('error_case_cd', None):
            filter_arguments['error_case_cd__in'] = \
                request.GET.get('error_case_cd', None).split(",")
        if request.GET.get('helpdeskaccept__error_cause_cd', None):
            filter_arguments['helpdeskaccept__error_cause_cd'] = \
                request.GET.get('helpdeskaccept__error_cause_cd', None)
        if request.GET.get('helpdeskaccept__helpdeskaccepttransactcodes__transact_cd', None):
            filter_arguments['helpdeskaccept__helpdeskaccepttransactcodes__transact_cd'] = \
                request.GET.get('helpdeskaccept__helpdeskaccepttransactcodes__transact_cd', None)
        if request.GET.get('helpdeskaccept__result_cd', None):
            if request.GET['helpdeskaccept__result_cd'] != "0":
                filter_arguments['helpdeskaccept__result_cd__in'] = \
                    request.GET.get('helpdeskaccept__result_cd', None).split(",")
            else:
                filter_arguments['helpdeskaccept__result_cd'] = None
        if request.GET.get('helpdeskaccept__note', None):
            filter_arguments['helpdeskaccept__note__icontains'] = \
                request.GET.get('helpdeskaccept__note', None)
        if request.GET.get('end_user', None):
            filter_arguments['end_user__icontains'] = \
                request.GET.get('end_user', None)
        if request.GET.get('end_user_id', None):
            filter_arguments['end_user_id__icontains'] = \
                request.GET.get('end_user_id', None)
        if request.GET.get('end_user_phone', None):
            filter_arguments['end_user_phone__icontains'] = \
                request.GET.get('end_user_phone', None)
        if request.GET.get('user_name', None):
            filter_arguments['user_name__icontains'] = \
                request.GET.get('user_name', None)
        if request.GET.get('help_desc', None):
            filter_arguments['help_desc__icontains'] = \
                request.GET.get('help_desc', None)
        if request.GET.get('helpdeskaccept__result_desc', None):
            filter_arguments['helpdeskaccept__result_desc__icontains'] = \
                request.GET.get('helpdeskaccept__result_desc', None)
        if request.GET.get('helpdeskaccept__user_name', None):
            filter_arguments['helpdeskaccept__user_name__icontains'] = \
                request.GET.get('helpdeskaccept__user_name', None)
        if request.GET.get('register_case_cd', None):
            filter_arguments['register_case_cd__in'] = \
                request.GET.get('register_case_cd', None).split(",")
        return queryset.filter(**filter_arguments)


class HelpDeskAPI(ListModelMixin, CreateModelMixin, UpdateModelMixin,
                  DestroyModelMixin, RetrieveModelMixin, SpectrumGenericAPIView):
    queryset = HelpDesk.objects.all()
    serializer_class = HelpDeskSerializer
    filter_backends = (HelpDeskCustomFilter,)
    lookup_url_kwarg = "help_id"

    def __init__(self):
        super(HelpDeskAPI, self).__init__()

    def get(self, request, *args, **kwargs):
        try:
            if kwargs.get('help_id', None):
                return super(HelpDeskAPI, self).\
                    retrieve(request, *args, **kwargs)
            else:
                return super(HelpDeskAPI, self).list(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle GET request on 'HelpDeskAPI'."
            log_error(request, msg, e=e)
            raise HelpDesk500Exception

    def post(self, request, *args, **kwargs):
        try:
            return super(HelpDeskAPI, self).create(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle POST request on 'HelpDeskAPI'."
            log_error(request, msg, e=e)
        except:
            raise HelpDesk500Exception

    def put(self, request, *args, **kwargs):
        try:
            request.DATA['date_modified'] = datetime.datetime.utcnow() + \
                                            datetime.timedelta(hours=9)
            return super(HelpDeskAPI, self).update(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle PUT request on 'HelpDeskAPI'."
            log_error(request, msg, e=e)
            raise HelpDesk500Exception

    def delete(self, request, *args, **kwargs):
        try:
            return super(HelpDeskAPI, self).destroy(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle DELETE request on 'HelpDeskAPI'."
            log_error(request, msg, e=e)
            raise HelpDesk500Exception


@api_view(['PUT'])
def change_result_cd(request):
    try:
        put_params = simplejson.loads(request.raw_post_data)
        print put_params
        if 'help_ids' in put_params and 'result_cd' in put_params:
            help_ids = put_params['help_ids']
            result_cd = put_params['result_cd']
            user_name = put_params['user_name']
        else:
            data = {
                'detail': _(u"API call failed.('help_ids' and 'result_cd' both are required.)")
            }
            return Response(data=data, status=HTTP_400_BAD_REQUEST)
        for help_id in help_ids:
            if HelpDeskAccept.objects.filter(help_id=help_id).exists():
                HelpDeskAccept.objects.filter(help_id__exact=help_id).\
                    update(result_cd=result_cd, latest_updater=user_name)
            else:
                new_help_request_acception = HelpDeskAccept()
                new_help_request_acception.help_id = \
                    HelpDesk.objects.get(help_id=help_id)
                new_help_request_acception.user_name = _(u'HELPDESK.NOT_DECIDED')
                new_help_request_acception.error_cause_cd = 27
                new_help_request_acception.result_cd = result_cd
                new_help_request_acception.result_desc = ' '
                new_help_request_acception.creator = user_name
                new_help_request_acception.latest_updater = user_name
                new_help_request_acception.save()

        result_queryset = HelpDeskAccept.objects.filter(help_id__in=help_ids)
        serializable_json = [o for o in result_queryset.values()]
        return Response({'results': serializable_json})
    except Exception as e:
        msg = "Failed to handle PUT request on 'change_result_cd()'."
        log_error(request, msg, e=e)
        raise HelpDesk500Exception


class HelpDeskAcceptAPI(CreateModelMixin, UpdateModelMixin,
                        RetrieveModelMixin, SpectrumGenericAPIView):
    queryset = HelpDeskAccept.objects.all()
    serializer_class = HelpDeskAcceptSerializer
    lookup_url_kwarg = "help_id"
    search_fields = ()

    def __init__(self):
        super(HelpDeskAcceptAPI, self).__init__()

    def get(self, request, *args, **kwargs):
        try:
            return super(HelpDeskAcceptAPI, self).\
                retrieve(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle GET request on 'HelpDeskAcceptAPI'."
            log_error(request, msg, e=e)
            raise HelpDesk500Exception

    def post(self, request, *args, **kwargs):
        try:
            return super(HelpDeskAcceptAPI, self).\
                create(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle POST request on 'HelpDeskAcceptAPI'."
            log_error(request, msg, e=e)
            raise HelpDesk500Exception

    def put(self, request, *args, **kwargs):
        try:
            request.DATA['date_modified'] = datetime.datetime.utcnow() + \
                                            datetime.timedelta(hours=9)
            return super(HelpDeskAcceptAPI, self).\
                update(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle PUT request on 'HelpDeskAcceptAPI'."
            log_error(request, msg, e=e)
            raise HelpDesk500Exception

    def pre_save(self, obj):
        if obj.help_id and obj.result_cd not in RESULT_CODE_EXCEPT_SUPPORT_DONE.values():
            phone_regex_format = '(0\d{1,2}[-. )]?)(\d{3,4})([-. ]?)(\d{3,4})'

            help_desk = HelpDesk.objects.get(help_id=str(obj.help_id))

            help_desk.result_sms = re.sub(phone_regex_format, '\\1****\\3\\4', help_desk.result_sms)
            help_desk.end_user_phone = re.sub(phone_regex_format, '\\1****\\3\\4', help_desk.end_user_phone)
            help_desk.end_user = help_desk.end_user[:1] + ("*" * (len(help_desk.end_user) - 1))
            help_desk.end_user_id = help_desk.end_user_id[:4] + ("*" * (len(help_desk.end_user_id) - 4))

            help_desk.save()

    def post_save(self, obj, created=False):
        try:
            result_cd_codes = HelpDeskCd.objects.filter(code_type=4,
                                                        obj_state=1)
            help_request = obj.help_id
            parent_help_cd = result_cd_codes.get(help_cd=obj.result_cd)\
                .parent_help_cd
            if help_request.result_inform[0] == '1' \
                    and parent_help_cd == 53:
                send_completion_mail(self.request, obj)
            if help_request.result_inform[1] == '1' \
                    and parent_help_cd == 53:
                send_completion_sms(self.request, obj)
        except Exception as e:
            msg = "post_save() is failed in 'HelpDeskAcceptAPI'."
            log_error(self.request, msg, e=e)
            raise HelpDesk500Exception


class HelpDeskCdAPI(ListModelMixin, SpectrumGenericAPIView):
    queryset = HelpDeskCd.objects.filter(obj_state=1)
    serializer_class = HelpDeskCdSerializer
    lookup_url_kwarg = "help_cd"
    ordering_fields = ('code_type', 'sort_key')
    paginate_by = None

    def __init__(self):
        super(HelpDeskCdAPI, self).__init__()

    def get(self, request, *args, **kwargs):
        try:
            return super(HelpDeskCdAPI, self).list(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle GET request on 'HelpDeskCdAPI'."
            log_error(request, msg, e=e)
            raise HelpDesk500Exception


class HelpDeskStatisticsAPI(SpectrumGenericAPIView):
    report_names = ('error_case_cd', 'error_cause_cd', 'transact_cd',
                    'contact_time_cd', 'urgency_call',)
    report_sql_queries = {
        'error_case_cd': "SELECT hdce.help_cd AS error_case_cd\
                          , hdcr.help_cd AS result_cd\
                          , COUNT(*) AS count\
                          FROM help_desk hd\
                              LEFT JOIN help_desk_accept hda\
                                  ON hd.help_id = hda.help_id\
                              LEFT JOIN help_desk_cd hdcr \
                                  ON hda.result_cd = hdcr.help_cd\
                              LEFT JOIN help_desk_cd hdce\
                                  ON hd.error_case_cd = hdce.help_cd\
                          WHERE hdcr.code_type = 4 AND hdce.code_type = 1\
                              AND hdcr.obj_state = 1 AND hdce.obj_state = 1\
                              %(account_no_filter)s\
                              %(date_filter)s\
                          GROUP BY hdce.help_cd, hdcr.help_cd\
                          ORDER BY hdce.sort_key, hdcr.sort_key;",
        'error_cause_cd': "SELECT hdcp.help_cd AS error_cause_cd\
                           , hdc.help_cd AS result_cd\
                           , COUNT(*) AS count\
                           FROM help_desk hd\
                               LEFT JOIN help_desk_accept hda\
                                  ON hd.help_id = hda.help_id\
                               LEFT JOIN help_desk_cd hdcp\
                                  ON hda.error_cause_cd = hdcp.help_cd\
                               LEFT JOIN help_desk_cd hdc\
                                  ON hda.result_cd = hdc.help_cd\
                           WHERE hdcp.code_type = 2 AND hdc.code_type = 4\
                               AND hdcp.obj_state = 1 AND hdc.obj_state = 1\
                               %(account_no_filter)s\
                               %(date_filter)s\
                           GROUP BY hdcp.help_cd, hdc.help_cd\
                           ORDER BY hdcp.sort_key, hdc.sort_key;",
        'transact_cd': "SELECT hdcp.help_cd AS transact_cd\
                        , hdc.help_cd AS result_cd\
                        , COUNT(*) AS count\
                        FROM help_desk hd\
                            LEFT JOIN help_desk_accept hda\
                               ON hd.help_id = hda.help_id\
                            LEFT JOIN help_desk_accept_transact_codes hdatc\
                               ON hdatc.help_id = hda.help_id\
                            LEFT JOIN help_desk_cd hdcp\
                               ON hdatc.transact_cd = hdcp.help_cd\
                            LEFT JOIN help_desk_cd hdc\
                               ON hda.result_cd = hdc.help_cd\
                            %(account_no_filter)s\
                            %(date_filter)s\
                        WHERE hdcp.code_type = 3 AND hdc.code_type = 4\
                            AND hdcp.obj_state = 1 AND hdc.obj_state = 1\
                        GROUP BY hdcp.help_cd, hdc.help_cd\
                        ORDER BY hdcp.sort_key, hdc.sort_key;",
        'contact_time_cd': "SELECT hdcp.help_cd AS contact_time_cd\
                            , hdc.help_cd AS success_time_cd\
                            , COUNT(*) AS count\
                            FROM help_desk hd\
                                LEFT JOIN help_desk_accept hda\
                                   ON hd.help_id = hda.help_id\
                                LEFT JOIN help_desk_cd hdcp\
                                   ON hda.contact_time_cd = hdcp.help_cd\
                                LEFT JOIN help_desk_cd hdc\
                                   ON hda.success_time_cd = hdc.help_cd\
                            WHERE hdcp.code_type = 11 AND hdc.code_type = 12\
                                AND hdcp.obj_state = 1 AND hdc.obj_state = 1\
                                %(account_no_filter)s\
                                %(date_filter)s\
                            GROUP BY hdcp.help_cd, hdc.help_cd\
                            ORDER BY hdcp.sort_key, hdc.sort_key;",
        'urgency_call': "SELECT COUNT(left_joined.result_cd) AS count\
                         FROM (\
                             SELECT hda.result_cd\
                             FROM help_desk_accept AS hda\
                             LEFT JOIN help_desk AS hd\
                                 ON hda.help_id = hd.help_id\
                             WHERE hda.result_cd IS NOT NULL \
                                    AND hd.urgency_call = 1 \
                                    %(account_no_filter)s\
                                    %(date_filter)s\
                         ) AS left_joined\
                         RIGHT JOIN help_desk_cd AS hdc\
                         ON left_joined.result_cd = hdc.help_cd\
                         WHERE hdc.code_type = 4 AND hdc.obj_state = 1\
                         GROUP BY left_joined.result_cd, hdc.help_cd,\
                                   hdc.sort_key\
                         ORDER BY hdc.sort_key;"
    }

    def __init__(self):
        super(HelpDeskStatisticsAPI, self).__init__()

    def get(self, request):
        bad_parameters = []
        try:
            account_no = request.GET.get('account_no', None)
            report_name = request.GET.get('report_name', None)
            date_from = request.GET.get('date_from', None)
            date_to = request.GET.get('date_to', None)

            if report_name and report_name in self.report_names:
                pass
            else:
                bad_parameters.append('report_name')

            if date_from == ''\
                or re.match(r'^[0-9]{4}\-[0-1][0-9]\-[0-3][0-9]$', date_from)\
                    is not None:
                pass
            else:
                bad_parameters.append('date_from')

            if date_to == ''\
                or re.match(r'^[0-9]{4}\-[0-1][0-9]\-[0-3][0-9]$', date_to)\
                    is not None:
                pass
            else:
                bad_parameters.append('date_to')

            if bad_parameters:
                data = {
                    'detail': _(u'API call failed.(You inputted wrong parameters.)'),
                    'wrong_input_list': bad_parameters
                }
                return Response(data=data, status=HTTP_400_BAD_REQUEST)

            if account_no:
                account_no_filter = 'AND hd.account_no = %s' % str(account_no)
            else:
                account_no_filter = ''

            if date_from and date_to:
                date_filter = "AND DATE(hda.date_created) BETWEEN '%s' AND '%s'"\
                              % (date_from, date_to)
            elif date_from:
                date_filter = "AND DATE(hda.date_created) >= '%s'" % date_from
            elif date_to:
                date_filter = "AND DATE(hda.date_created) <= '%s'" % date_to
            else:
                date_filter = ''

            cursor = connections['aurora'].cursor()
            cursor.execute(self.report_sql_queries[report_name]
                           % {
                                'date_filter': date_filter,
                                'account_no_filter': account_no_filter
                            })
            results = cursor.fetchall()

            return Response({'results': results})
        except Exception as e:
            msg = "Failed to handle GET request on 'HelpDeskStatisticsAPI'."
            log_error(request, msg, e=e)
            raise HelpDesk500Exception


def send_completion_mail(request, help_request_acception):
    try:
        transact_list = []
        help_codes = HelpDeskCd.objects.filter(obj_state=1)
        help_request = help_request_acception.help_id.__dict__
        account_name = help_request_acception.help_id.account_name
        help_request_acception = help_request_acception.__dict__
        receive_mail = [help_request['result_mail']]
        from_email = REPORT_MAIL_SENDER
        # Translate code
        for k in help_request.keys():
            if isinstance(help_request[k], int):
                try:
                    help_request[k] = help_codes.get(help_cd=help_request[k]).code_name
                    if k == 'error_case_cd':
                        mail_title = __MSG_EMAIL_TITLE__ + help_request[k]
                except:
                    pass
        for k in help_request_acception.keys():
            if isinstance(help_request_acception[k], int):
                try:
                    help_request_acception[k] = help_codes.get(help_cd=help_request_acception[k]).code_name
                except:
                    pass
        for row in HelpDeskAcceptTransactCodes.objects.\
            filter(help_id=help_request['help_id']).values('transact_cd'):
            try:
                result = HelpDeskCd.objects.get(help_cd=row['transact_cd'])
                transact_list.append(result.code_name)
            except:
                pass
        email_msg = render_to_string("email_template.html",
                                     {
                                         'title': mail_title,
                                         'account_name': account_name,
                                         'help_request': help_request,
                                         'help_request_acception':
                                             help_request_acception,
                                         'transact_list': transact_list
                                     })
        mailobj = MailObject(from_email, receive_mail, mail_title, email_msg)
        mailobj.send_mail()
    except Exception as e:
        title = 'Help Request Email Report send failed.'
        message_format = 'HTTP HOST: {host}\nSERVER NAME: {server}\n\n' + \
                         'Email report send failed\n\nStack Trace:\n{trace}'
        message = message_format.format(host=request.get_host(),
                                        server=request.META['SERVER_NAME'],
                                        trace=traceback.format_exc(e))
        log_error(request, message, e, None, title)


def send_completion_sms(request, help_request_acception):
    try:
        help_request = help_request_acception.help_id
        recipient_phone_number = help_request.result_sms
        message = _(u'HELPDESK.COMPLETTION_MSG')
        url_format = "http://msg.kr.cdnetworks.com/MsgService.asmx/SendSMS?" + \
            "app_code=00000018&TargetRegion=kr1&MessageType=0&OrgAddress=&" + \
            "DstAddress=%(recipient)s&Callback=%(sender)s&Content=%(message)s"
        sender_phone_number = SUPPORT_CENTER_TEL_NUMBER
        url = url_format % {
                                "recipient": recipient_phone_number,
                                "sender": sender_phone_number,
                                "message": urllib2.quote(message.encode('utf-8'))
                            }
        result = urllib2.urlopen(url)
        dom = minidom.parse(result)
        result = dom.getElementsByTagName("RESULT").item(
            0).lastChild.nodeValue
        if result != '200000':
            raise Exception
    except Exception as e:
        title = 'Help Request completion SMS send failed.'
        message_format = 'HTTP HOST: {host}\nSERVER NAME: {server}\n\n' + \
                         'SMS send failed\n\nStack Trace:\n{trace}'
        message = message_format.format(host=request.get_host(),
                                        server=request.META['SERVER_NAME'],
                                        trace=traceback.format_exc(e))
        log_error(request, message, e, None, title)
