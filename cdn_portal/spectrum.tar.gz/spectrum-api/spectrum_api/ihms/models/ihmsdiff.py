from django.utils.translation import ugettext as _
from django.db import models

from spectrum_api.shared_components.models import BaseModel


class IhmsSyncManager(BaseModel):
    sync_running_type = models.IntegerField(primary_key=True, verbose_name='sync type')
    sync_running_status = models.IntegerField(verbose_name='sync status')
    sync_running_time = models.DateTimeField()
    lastupdate = models.DateTimeField()
    username = models.CharField(max_length=30, verbose_name=_("user name"), blank=True)
    sync_last_start_time = models.DateTimeField()
    sync_last_end_time = models.DateTimeField()

    def __unicode__(self):
        return u'%s-%s' % (str(self.sync_running_type), self.sync_running_status)

    class Meta:
        app_label = 'ihmssync'
        db_table = 'sync_running_status'