from django.db import models
from spectrum_api.shared_components.models import BaseModel, HistoryModel
from spectrum_api.shared_components.models.user import AuroraUser


class MailItemCd(BaseModel):
    mail_item_cd = models.AutoField(primary_key=True, db_column='mail_item_cd')
    mail_item_en = models.CharField(max_length=200, blank=False)
    mail_item_ko = models.CharField(max_length=200, blank=False)
    mail_item_ja = models.CharField(max_length=200, blank=False)
    mail_item_zh = models.CharField(max_length=200, blank=False)
    mail_item_ru = models.CharField(max_length=200, blank=False)
    mail_item_tr = models.CharField(max_length=200, blank=False)
    default_send = models.PositiveSmallIntegerField(blank=False)
    admin_only = models.PositiveSmallIntegerField(blank=False)
    obj_state = models.PositiveSmallIntegerField(default=1, blank=False)
    date_created = models.DateTimeField(auto_now_add=True)
    date_modified = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = 'mail_notification'
        db_table = 'mail_item_cd'
        ordering = ['mail_item_cd']

    # noinspection PyClassHasNoInit
    class SpectrumMeta:
        allow_delete = False

    def __unicode__(self):
        return '%s' % self.mail_item_cd

    def save(self, **kwargs):
        request = kwargs.get('request', None)
        super(MailItemCd, self).save(**kwargs)


class AuthUserMailNotification(HistoryModel):
    id = models.AutoField(primary_key=True, db_column='id')
    auth_user = models.ForeignKey(AuroraUser,
                                     db_column='auth_user_id',
                                     related_name='authusermailnotification',
                                     blank=False)
    mail_item = models.ForeignKey(MailItemCd,
                                     db_column='mail_item_cd',
                                     related_name='authusermailnotification',
                                     blank=False)
    date_created = models.DateTimeField(auto_now_add=True)
    date_modified = models.DateTimeField(auto_now=True)
    latest_updater = models.CharField(max_length=100, null=True)

    class Meta:
        app_label = 'mail_notification'
        db_table = 'auth_user_mail_notification'
        unique_together = ("auth_user", "mail_item")

    # noinspection PyClassHasNoInit
    class SpectrumMeta:
        allow_delete = True

    def __unicode__(self):
        return '%s' % self.id

    def save(self, **kwargs):
        request = kwargs.get('request', None)

        super(AuthUserMailNotification, self).save(**kwargs)
