from rest_framework import serializers
from spectrum_api.mail_notification.models.mail_notification \
    import MailItemCd, AuthUserMailNotification


class DefaultSendField(serializers.RelatedField):
    def to_native(self, value):
        return value.default_send


class MailItemCdSerializer(serializers.ModelSerializer):
    class Meta:
        model = MailItemCd
        fields = (
            "mail_item_cd",
            "mail_item_en",
            "mail_item_ko",
            "mail_item_ja",
            "mail_item_zh",
            "mail_item_ru",
            "mail_item_tr",
            "default_send",
            "admin_only",
            "obj_state",
            "date_created",
            "date_modified",
        )


class AuthUserMailNotificationSerializer(serializers.ModelSerializer):
    default_send = DefaultSendField(source="mail_item", read_only=True)

    class Meta:
        model = AuthUserMailNotification
        fields = (
            "id",
            "auth_user",
            "mail_item",
            "date_created",
            "date_modified",
            "latest_updater",
            "default_send",
        )


class AuthUserMailNotificationBulkSerializer(serializers.ModelSerializer):
    class Meta:
        model = AuthUserMailNotification
        fields = (
            "id",
            "auth_user",
            "mail_item",
            "date_created",
            "date_modified",
            "latest_updater",
        )
        read_only_fields = ('auth_user',)

    def get_identity(self, data):
        try:
            return data.get("mail_item", None)
        except AttributeError:
            return None