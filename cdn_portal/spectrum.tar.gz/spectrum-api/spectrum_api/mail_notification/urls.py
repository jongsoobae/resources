from django.conf.urls.defaults import *
from rest_framework.urlpatterns import format_suffix_patterns
from spectrum_api.mail_notification.views.mail_notification \
    import MailItemCdAPI, AuthUserMailNotificationAPI


restfw_api_urlpatterns = patterns(
    'spectrum_api.mail_notification.views',
    url(r'^mail_notification/codes/$', MailItemCdAPI.as_view(),
        name="mail_notification-codes"),
    url(r'^mail_notification/codes/(?P<mail_item_cd>[0-9]+)/$',
        MailItemCdAPI.as_view(),
        name="mail_notification-codes-detail"),
    url(r'^mail_notification/items/$',
        AuthUserMailNotificationAPI.as_view(),
        name="mail_notification-items"),
    url(r'^mail_notification/items/(?P<id>[0-9]+)/$',
        AuthUserMailNotificationAPI.as_view(),
        name="mail_notification-items-detail"),
)
urlpatterns = format_suffix_patterns(restfw_api_urlpatterns)
