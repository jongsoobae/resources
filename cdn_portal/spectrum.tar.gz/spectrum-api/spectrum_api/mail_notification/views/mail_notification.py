from rest_framework.filters import BaseFilterBackend
from rest_framework.status import HTTP_500_INTERNAL_SERVER_ERROR
from spectrum_api.shared_components.utils.common import log_error
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.mail_notification.models.mail_notification \
    import MailItemCd, AuthUserMailNotification
from spectrum_api.mail_notification.serializers.mail_notification \
    import MailItemCdSerializer, AuthUserMailNotificationSerializer
from spectrum_api.shared_components.mixins \
    import CreateModelMixin, UpdateModelMixin, DestroyModelMixin, \
    ListModelMixin, RetrieveModelMixin
from django.utils.translation import ugettext as _
from rest_framework.exceptions import APIException
from rest_framework.response import Response


class MailNotification500Exception(APIException):
    status_code = HTTP_500_INTERNAL_SERVER_ERROR
    default_detail = _(u'API call failed.')


# Filter
class AuthUserMailNotificationCustomFilter(BaseFilterBackend):
    """
        This is only for AuthUserMailNotificationAPI
    """

    def filter_queryset(self, request, queryset, view):
        filter_arguments = {}
        if request.GET.get('mail_item', None):
            filter_arguments['mail_item'] = \
                request.GET.get('mail_item', None)
        if request.GET.get('auth_user', None):
            auth_user_ids = request.GET['auth_user'].split(",")
            # It needs '__in' lookup
            filter_arguments['auth_user__in'] = auth_user_ids
        return queryset.filter(**filter_arguments)


class MailItemCdAPI(CreateModelMixin, UpdateModelMixin, DestroyModelMixin,
                    ListModelMixin, RetrieveModelMixin, SpectrumGenericAPIView):
    queryset = MailItemCd.objects.filter(obj_state=1)
    serializer_class = MailItemCdSerializer
    filter_fields = ('default_send', 'admin_only')
    search_fields = ('mail_item_en', 'mail_item_ko', 'mail_item_ja',
                     'mail_item_zh', 'mail_item_ru', 'mail_item_tr',)
    lookup_url_kwarg = "mail_item_cd"
    paginate_by = None

    def __init__(self):
        super(MailItemCdAPI, self).__init__()

    def get(self, request, *args, **kwargs):
        try:
            if kwargs.get('mail_item_cd', None):
                return super(MailItemCdAPI, self).\
                    retrieve(request, *args, **kwargs)
            else:
                return super(MailItemCdAPI, self).list(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle GET request on 'MailItemCdAPI'."
            log_error(request, msg, e=e)
            raise MailNotification500Exception

    def post(self, request, *args, **kwargs):
        try:
            return super(MailItemCdAPI, self).create(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle POST request on 'MailItemCdAPI'."
            log_error(request, msg, e=e)
        except:
            raise MailNotification500Exception

    def put(self, request, *args, **kwargs):
        try:
            return super(MailItemCdAPI, self).update(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle PUT request on 'MailItemCdAPI'."
            log_error(request, msg, e=e)
            raise MailNotification500Exception

    def delete(self, request, *args, **kwargs):
        try:
            # Delete action bot allowed, but change obj_state to 0.
            if kwargs.get('mail_item_cd', None):
                mail_item_cd = kwargs['mail_item_cd']
                if MailItemCd.objects.filter(mail_item_cd=mail_item_cd).exists():
                    MailItemCd.objects.filter(mail_item_cd__exact=mail_item_cd).\
                        update(obj_state=0)
            else:
                raise MailNotification500Exception
            return Response()
        except Exception as e:
            msg = "Failed to handle DELETE request on 'MailItemCdAPI'."
            log_error(request, msg, e=e)
            raise MailNotification500Exception


class AuthUserMailNotificationAPI(CreateModelMixin, UpdateModelMixin, DestroyModelMixin,
                    ListModelMixin, RetrieveModelMixin, SpectrumGenericAPIView):
    queryset = AuthUserMailNotification.objects.all()
    serializer_class = AuthUserMailNotificationSerializer
    filter_backends = (AuthUserMailNotificationCustomFilter,)
    lookup_url_kwarg = "id"
    paginate_by = None

    def __init__(self):
        super(AuthUserMailNotificationAPI, self).__init__()

    def get(self, request, *args, **kwargs):
        try:
            if kwargs.get('id', None):
                return super(AuthUserMailNotificationAPI, self).\
                    retrieve(request, *args, **kwargs)
            else:
                return super(AuthUserMailNotificationAPI, self)\
                    .list(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle GET request on 'AuthUserMailNotificationAPI'."
            log_error(request, msg, e=e)
            raise MailNotification500Exception

    def post(self, request, *args, **kwargs):
        try:
            return super(AuthUserMailNotificationAPI, self)\
                .create(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle POST request on 'AuthUserMailNotificationAPI'."
            log_error(request, msg, e=e)
            raise MailNotification500Exception

    def put(self, request, *args, **kwargs):
        try:
            return super(AuthUserMailNotificationAPI, self).\
                update(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle PUT request on 'AuthUserMailNotificationAPI'."
            log_error(request, msg, e=e)
            raise MailNotification500Exception

    def delete(self, request, *args, **kwargs):
        try:
            return super(AuthUserMailNotificationAPI, self).\
                destroy(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle DELETE request on 'AuthUserMailNotificationAPI'."
            log_error(request, msg, e=e)
            raise MailNotification500Exception