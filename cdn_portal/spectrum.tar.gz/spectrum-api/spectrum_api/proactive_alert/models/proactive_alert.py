from django.db import models
from spectrum_api.shared_components.models import BaseModel
from spectrum_api.shared_components.models.customer import CustomerItem

class ProactiveAlert(BaseModel):
    id = models.AutoField(primary_key=True, db_column='id')
    customer_item = models.ForeignKey(CustomerItem, db_column='item_id', unique=True)
    email_title = models.CharField(db_column='email_title', max_length=100)
    email_addr = models.CharField(db_column='email_addr', max_length=4000)
    alert_start_date = models.CharField(db_column='alert_start_date', max_length=10)
    alert_end_date = models.CharField(db_column='alert_end_date', max_length=10)
    warning_limit = models.PositiveIntegerField(db_column='warning_limit')
    critical_limit = models.PositiveIntegerField(db_column='critical_limit')
    alert_use_flag = models.SmallIntegerField(db_column='alert_use_flag', default=1)
    reg_date = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'proactive_alert'

    def __unicode__(self):
        return '%s' % self.id

    def save(self, **kwargs):
        request = kwargs.get('request', None)
        super(ProactiveAlert, self).save(**kwargs)
