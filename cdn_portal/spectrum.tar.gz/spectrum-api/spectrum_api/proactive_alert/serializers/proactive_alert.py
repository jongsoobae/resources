from rest_framework import serializers
from spectrum_api.proactive_alert.models.proactive_alert import ProactiveAlert
from spectrum_api.shared_components.models.customer import CustomerItem

class ProactiveAlertSerializer(serializers.ModelSerializer):
    item_id = serializers.PrimaryKeyRelatedField(source='customer_item',many=False)
    contract_no = serializers.RelatedField(source="customer_item.contract.contract_no", read_only=True)
    item_no = serializers.RelatedField(source="customer_item.item_no", read_only=True)
    product_name = serializers.RelatedField(source="customer_item.material_desc", read_only=True)
    billing_method = serializers.RelatedField(source="customer_item.billing_method_code", read_only=True)
    sales_org = serializers.RelatedField(source="customer_item.contract.sales_org", read_only=True)
    billing_start_date = serializers.RelatedField(source="customer_item.contract.billing_start_date", read_only=True)
    contract_end_date = serializers.RelatedField(source="customer_item.contract.contract_end", read_only=True)
    billing_date = serializers.RelatedField(source="customer_item.contract.billing_date", read_only=True)

    class Meta:
        model = ProactiveAlert
        fields = (
            "id",
            "item_id",
            "contract_no",
            "item_no",
            "product_name",
            "email_title",
            "email_addr",
            "alert_start_date",
            "alert_end_date",
            "warning_limit",
            "critical_limit",
            "billing_method",
            "sales_org",
            "billing_start_date",
            "contract_end_date",
            "billing_date",
            "alert_use_flag",
            "reg_date",
        )

    def get_identity(self, data):
        try:
            return data.get("id", None)
        except AttributeError:
            return None
