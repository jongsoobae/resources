from django.conf.urls.defaults import *
from rest_framework.urlpatterns import format_suffix_patterns
from spectrum_api.proactive_alert.views.proactive_alert import ProactiveAlertAPI, ProactiveAlertDetailAPI


restfw_api_urlpatterns = patterns(
    'spectrum_api.proactive_alert.views',
    url(r'^proactivealert/$', ProactiveAlertAPI.as_view(), name="proactivealert"),
    url(r'^proactivealert/(?P<id>[0-9]+)/$', ProactiveAlertDetailAPI.as_view(), name="proactivealert-detail"),
)
urlpatterns = format_suffix_patterns(restfw_api_urlpatterns)