from rest_framework.filters import BaseFilterBackend
from rest_framework.status import HTTP_404_NOT_FOUND, HTTP_403_FORBIDDEN, HTTP_400_BAD_REQUEST
from spectrum_api.shared_components.utils.common import log_error
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.proactive_alert.models.proactive_alert import ProactiveAlert
from spectrum_api.proactive_alert.serializers.proactive_alert import ProactiveAlertSerializer
from spectrum_api.shared_components.mixins \
    import CreateModelMixin, UpdateModelMixin, DestroyModelMixin, \
    ListModelMixin, RetrieveModelMixin
from django.utils.translation import ugettext as _
from rest_framework.exceptions import APIException
from rest_framework.response import Response

class ProactiveAlertDoseNotExist(APIException):
    status_code = HTTP_404_NOT_FOUND
    default_detail = _('You access does not exists Proactive Alert')

class AccessInvalidID(APIException):
    status_code = HTTP_400_BAD_REQUEST
    default_detail = 'ID Missing'


class ProactiveAlertAPI(ListModelMixin,
            CreateModelMixin,
            SpectrumGenericAPIView):

    queryset = ProactiveAlert.objects.all()
    search_fields = ('customer_item',)
    filter_fields = ({'item_id': 'customer_item'}, {'sales_org':'customer_item__contract__sales_org'}, 'alert_use_flag',)

    serializer_class = ProactiveAlertSerializer
    lookup_url_kwarg = "id"

    def get(self, request, *args, **kwargs):
        return super(ProactiveAlertAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(ProactiveAlertAPI, self).create(request, *args, **kwargs)


class ProactiveAlertDetailAPI(RetrieveModelMixin,
                    UpdateModelMixin,
                    DestroyModelMixin,
                    SpectrumGenericAPIView):

    queryset = ProactiveAlert.objects.all()
    search_fields = ('customer_item',)
    filter_fields = ({'item_id': 'customer_item'}, {'sales_org':'customer_item__contract__sales_org'}, 'alert_use_flag',)

    serializer_class = ProactiveAlertSerializer
    lookup_url_kwarg = 'id'

    def get(self, request, *args, **kwargs):
        return super(ProactiveAlertDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ProactiveAlertDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ProactiveAlertDetailAPI, self).partial_update(request, *args, **kwargs)