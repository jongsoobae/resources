'''
Created on 2013. 5. 10.

@author: Wonho Choi
'''
from spectrum_api.shared_components.models import StatMaster
from spectrum_api.shared_components.models.customer import CustomerItem
from django.db import models
from spectrum_api.shared_components.models import BaseModel

def getContractListByStatList(statList):
    statMasterList = StatMaster.all_objects.filter(stat_id__in=statList).values('item__item_id')
    statMasterList = [i.get('item__item_id') for i in statMasterList]

    statMasterList = set(statMasterList)

    contractList = []
    for i in statMasterList :
        item = CustomerItem.objects.get(pk=i)
        contractList.append(str(item.contract.contract_no) + '-' + str(item.item_no))

    return contractList



class TbISP(BaseModel):
    isp_cd = models.CharField(primary_key=True)
    isp_name_en = models.CharField()
    isp_name_ko = models.CharField()
    isp_name_ja = models.CharField()
    isp_name_zh = models.CharField()
    ihms_isp_id = models.CharField()
    ihms_isp_cd = models.CharField()
    use_flag = models.IntegerField()

    class Meta:
        db_table = 'tb_ispcd'

    class SpectrumMeta:
        read_only = True
        router = 'one_stat'


class TbCountry(BaseModel):
    country_cd = models.CharField(primary_key=True)
    country_name_en = models.CharField()
    country_name_ko = models.CharField()
    country_name_ja = models.CharField()
    country_name_zh = models.CharField()
    continent_cd = models.CharField()
    ihms_country_cd = models.CharField()
    ihms_continent_cd = models.CharField()
    use_flag = models.IntegerField()

    class Meta:
        db_table = 'tb_countrycd'

    class SpectrumMeta:
        read_only = True
        router = 'one_stat'


class TbState(BaseModel):
    state_cd = models.CharField(primary_key=True)
    state_name_en = models.CharField()
    state_name_ko = models.CharField()
    state_name_ja = models.CharField()
    state_name_zh = models.CharField()
    country_cd = models.CharField()
    ihms_state_id = models.CharField()
    ihms_state_cd = models.CharField()
    ihms_country_cd = models.CharField()
    use_flag = models.IntegerField()

    class Meta:
        db_table = 'tb_statecd'

    class SpectrumMeta:
        read_only = True
        router = 'one_stat'


class TbCity(BaseModel):
    city_cd = models.CharField(primary_key=True)
    city_name_en = models.CharField()
    city_name_ko = models.CharField()
    city_name_ja = models.CharField()
    city_name_zh = models.CharField()
    state_cd = models.CharField()
    country_cd = models.CharField()
    ihms_city_id = models.CharField()
    ihms_city_cd = models.CharField()
    ihms_state_id = models.CharField()
    ihms_country_cd = models.CharField()
    use_flag = models.IntegerField()

    class Meta:
        db_table = 'tb_citycd'

    class SpectrumMeta:
        read_only = True
        router = 'one_stat'
