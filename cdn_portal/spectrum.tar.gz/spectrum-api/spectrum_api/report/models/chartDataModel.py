'''
Created on 2013. 5. 14.

@author: Wonho.Choi
'''

class chartDataModel:
    stat_item = ""
    chartContainer = ""
    tableContainer = ""
    container = ""
    chart_width = 0
    chart_height = 0
    chart_data = None
    real_date_to = 0
    table_data = None

    chart_type = False
    type = ""
    seriesName = ""
    yAxisName = ""
    xAxisName = ""
    avgDayUnit = ""
    data95Unit = ""
    numDivision = ""
    defaultUnit = ""
    unitPrefix = ""
    summury_data = None
    is_95per = False
    is_avg_daily = False
    tableData = None
    report_type = "MB"
    yAxisDataTransName = ""
    numDataTransDivision = ""
    
    totalHits = 0
    successHits = 0

    def __init__(self, stat_item="", chartContainer="", tableContainer="", container="", chart_width=0, chart_height=0, chart_data=None, real_date_to=0,
    chart_type=False, type="", seriesName="", yAxisName="", xAxisName="", avgDayUnit="", data95Unit="", numDivision="", defaultUnit="", unitPrefix="",
    summury_data=None, is_95per=False, is_avg_daily=False, table_data=None, tableData=None, report_type="", yAxisDataTransName="", numDataTransDivision="",
    totalHits=0, successHits=0):
        self.stat_item = stat_item
        self.chartContainer = chartContainer
        self.tableContainer = tableContainer
        self.container = container
        self.chart_width = chart_width
        self.chart_height = chart_height
        self.chart_data = chart_data
        self.real_date_to = real_date_to
        self.chart_type = chart_type
        self.type = type
        self.seriesName = seriesName
        self.yAxisName = yAxisName
        self.xAxisName = xAxisName
        self.avgDayUnit = avgDayUnit
        self.data95Unit = data95Unit
        self.numDivision = numDivision
        self.defaultUnit = defaultUnit
        self.unitPrefix = unitPrefix
        self.summury_data = summury_data
        self.is_95per = is_95per
        self.is_avg_daily = is_avg_daily
        self.table_data = table_data
        self.tableData = tableData
        self.report_type = report_type
        self.yAxisDataTransName = yAxisDataTransName
        self.numDataTransDivision = numDataTransDivision
        self.totalHits = totalHits
        self.successHits = successHits

    def getChartDataDictionary(self):
        chart_data_dictionary = {}
        if self.stat_item != "":
            chart_data_dictionary['stat_item'] = self.stat_item
        if self.chartContainer != "":
            chart_data_dictionary['chartContainer'] = self.chartContainer
        if self.tableContainer != "":
            chart_data_dictionary['tableContainer'] = self.tableContainer
        if self.container != "":
            chart_data_dictionary['container'] = self.container
        if self.chart_width != 0:
            chart_data_dictionary['chart_width'] = self.chart_width
        if self.chart_height != 0:
            chart_data_dictionary['chart_height'] = self.chart_height
        if self.real_date_to != 0:
            chart_data_dictionary['real_date_to'] = self.real_date_to
        if self.chart_data != None:
            chart_data_dictionary['chart_data'] = self.chart_data
        if self.table_data != None:
            chart_data_dictionary['table_data'] = self.table_data
        if self.chart_type != False:
            chart_data_dictionary['chart_type'] = {}
            if self.type != "":
                chart_data_dictionary['chart_type']['type'] = self.type
            if self.seriesName != "":
                chart_data_dictionary['chart_type']['seriesName'] = self.seriesName
            if self.yAxisName != "":
                chart_data_dictionary['chart_type']['yAxisName'] = self.yAxisName
            if self.xAxisName != "":
                chart_data_dictionary['chart_type']['xAxisName'] = self.xAxisName
            if self.avgDayUnit != "":
                chart_data_dictionary['chart_type']['avgDayUnit'] = self.avgDayUnit
            if self.data95Unit != "":
                chart_data_dictionary['chart_type']['data95Unit'] = self.data95Unit
            if self.numDivision != "":
                chart_data_dictionary['chart_type']['numDivision'] = self.numDivision
            if self.defaultUnit != "":
                chart_data_dictionary['chart_type']['defaultUnit'] = self.defaultUnit
            # default unutPrefix value is ""
            # so do not compare below
            # if self.unitPrefix != "":
            if self.unitPrefix != None:
                chart_data_dictionary['chart_type']['unitPrefix'] = self.unitPrefix
            if self.summury_data != None:
                chart_data_dictionary['chart_type']['summury_data'] = self.summury_data
            if self.is_95per != False:
                chart_data_dictionary['chart_type']['is_95per'] = self.is_95per
            if self.is_avg_daily != False:
                chart_data_dictionary['chart_type']['is_avg_daily'] = self.is_avg_daily
            if self.tableData != None:
                chart_data_dictionary['chart_type']['tableData'] = self.tableData
            if self.report_type != "":
                chart_data_dictionary['chart_type']['report_type'] = self.report_type
            if self.yAxisDataTransName != "":
                chart_data_dictionary['chart_type']['yAxisDataTransName'] = self.yAxisDataTransName
            if self.numDataTransDivision != "":
                chart_data_dictionary['chart_type']['numDataTransDivision'] = self.numDataTransDivision
            if self.numDataTransDivision != "":
                chart_data_dictionary['chart_type']['numDataTransDivision'] = self.numDataTransDivision

            if self.totalHits != 0:
                chart_data_dictionary['chart_type']['totalHits'] = self.totalHits
            if self.successHits != 0:
                chart_data_dictionary['chart_type']['successHits'] = self.successHits

        return chart_data_dictionary
