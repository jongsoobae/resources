from spectrum_api.shared_components.models import StatMaster, LegacyStatMaster
from django.db import connections
from spectrum_api.report.utils.byte_conv_utils import to_timestamp_gmt, generate_traffic, data_to_roundup
from datetime import timedelta
from spectrum_api.report.utils.ordered_dict import OrderedDict
from spectrum_api.shared_components.models.customer import CustomerItem
from spectrum_api.report.models import getContractListByStatList
from spectrum_api.report.utils.common import getErp_contract
from datetime import datetime

LAST_TRAFFIC_UPDATE_RATE = 85
    
def lastUpdatedTime():
    sql = """
        select timestamp from legacy_last_logging_time where name = 'wms_fms';
        """
    try:
        cursor = connections['legacy_stat'].cursor()
        cursor.execute(sql)
        rslist = cursor.fetchall()
    finally:
        cursor.close()
        del cursor

    lastTime = None
    try:
        if len(rslist) > 0:
            lastTime = rslist[0][0]
    except:
        return None

    return lastTime


def get_data_type(stat_ids, is_contract_stat=False):
    is_95per = False
    is_95per_switch = True
    is_avg_daily = False
    is_avg_daily_switch = True
    contractList = []
    if is_contract_stat == True:
        item = CustomerItem.objects.get(pk=stat_ids[0])
        contractList.append(str(item.contract.contract_no) + '-' + str(item.item_no))
    else :
#         statList = StatMaster.all_objects.filter(stat_id__in = stat_ids)
#         for i in statList:
#             if contractList.count(str(i.item.contract.contract_no) + '-' + str(i.item.item_no)) <= 0 :
#                 contractList.append(str(i.item.contract.contract_no) + '-' + str(i.item.item_no))
#
        contractList = getContractListByStatList(stat_ids)
    if contractList :
        for contract in contractList :
            erp_contract = getErp_contract(contract)
            if len(erp_contract) > 0 :
                if erp_contract[0]['billing_type'] == '61':
                    if is_95per_switch == True:
                        is_95per = True
                else:
                    is_95per = False
                    is_95per_switch = False
                if erp_contract[0]['billing_type'] == '20':
                    if is_avg_daily_switch == True:
                        is_avg_daily = True
                else:
                    is_avg_daily = False
                    is_avg_daily_switch = False
    return_value = {'is_95per' : is_95per, 'is_avg_daily' : is_avg_daily}
    return return_value

def get95Data(stats):
    return_dic = {}

    for q in stats.keys():
        q_data_list = stats[q]["value_list"]
        if len(q_data_list) > 0 :
            q_95_data = get95DataByList(q_data_list)
            return_dic[q + "_95_data"] = q_95_data
        else :
            return_dic[q + "_95_data"] = 0

    return return_dic

def get_total_traffic(*basic_args, **kwargs):
    val_list = []
    totalVal = 0
    totalCnt = 0
    minVal = 0
    maxVal = 0
    args = []

    for q in basic_args:
        if q != [] and q is not None:
            args.append(q)
    sum_list = kwargs.get('sum_list', None)
    if sum_list:
        for q in sum_list:
            args.append(q)
    idxData = -1
    for i in range(args.__len__()):
        if (args[i]).__len__() > 0 :
            idxData = i

    if idxData == -1 :
        return {'value_list' : [], 'avgValue' : 0, 'totValue' : 0, 'maxVal' : 0, 'minVal' : 0}
    for loop1 in range(args[idxData].__len__()) :
        tmpVal = 0
        for loop2 in range(args.__len__()):
            if (args[loop2]).__len__() > 0 :
                tmpVal += (args[loop2])[loop1][1]
        val_list.append([(args[idxData])[loop1][0], tmpVal])
        totalVal += tmpVal
        totalCnt += 1

        if tmpVal > maxVal :
            maxVal = tmpVal
        if tmpVal < minVal :
            minVal = tmpVal

    return {'value_list' : val_list, 'avgValue' : totalVal / totalCnt, 'totValue' : totalVal, 'maxVal' : maxVal, 'minVal' : minVal}


def seperate_5min_data(rs, q):
    q_size = q.__len__()
    q0_datetime = datetime.strptime(str(q[0]),"%Y%m%d%H")
    if q_size > 14 :
        rs.append([q0_datetime, int(q[1]), int(q[13])])
        rs.append([q0_datetime + timedelta(seconds=300), q[2], q[14]])
        rs.append([q0_datetime + timedelta(seconds=600), q[3], q[15]])
        rs.append([q0_datetime + timedelta(seconds=900), q[4], q[16]])
        rs.append([q0_datetime + timedelta(seconds=1200), q[5], q[17]])
        rs.append([q0_datetime + timedelta(seconds=1500), q[6], q[18]])
        rs.append([q0_datetime + timedelta(seconds=1800), q[7], q[19]])
        rs.append([q0_datetime + timedelta(seconds=2100), q[8], q[20]])
        rs.append([q0_datetime + timedelta(seconds=2400), q[9], q[21]])
        rs.append([q0_datetime + timedelta(seconds=2700), q[10], q[22]])
        rs.append([q0_datetime + timedelta(seconds=3000), q[11], q[23]])
        rs.append([q0_datetime + timedelta(seconds=3300), q[12], q[24]])
    else:
        rs.append([q0_datetime, int(q[1])])
        rs.append([q0_datetime + timedelta(seconds=300), q[2]])
        rs.append([q0_datetime + timedelta(seconds=600), q[3]])
        rs.append([q0_datetime + timedelta(seconds=900), q[4]])
        rs.append([q0_datetime + timedelta(seconds=1200), q[5]])
        rs.append([q0_datetime + timedelta(seconds=1500), q[6]])
        rs.append([q0_datetime + timedelta(seconds=1800), q[7]])
        rs.append([q0_datetime + timedelta(seconds=2100), q[8]])
        rs.append([q0_datetime + timedelta(seconds=2400), q[9]])
        rs.append([q0_datetime + timedelta(seconds=2700), q[10]])
        rs.append([q0_datetime + timedelta(seconds=3000), q[11]])
        rs.append([q0_datetime + timedelta(seconds=3300), q[12]])

    return rs

def get95DataSingleItem(stats):
    if len(stats["value_list"]) > 0 :
        return get95DataByList(stats["value_list"])
    else :
        return 0

def getRealDateTo(date_to, tz_offset):
    real_date_to = to_timestamp_gmt(date_to + timedelta(days=1) + timedelta(hours=tz_offset))
    last_update_time = lastUpdatedTime()
    if last_update_time != None:
        real_date_to = to_timestamp_gmt(last_update_time + timedelta(hours=tz_offset))
    return real_date_to

def get95DataByList(user_list):
    if len(user_list) == 0:
        return 0
    sorted_user_list = sorted(user_list, key=lambda edge_data: edge_data[1], reverse=True)
    sorted_user_95_sequence = int(data_to_roundup(len(sorted_user_list) * 0.05, 0)) #billing : Roundup((Days * 288) * 0.05) 
    user_data_95 = sorted_user_list[sorted_user_95_sequence-1][1]
    return user_data_95

def get_data_total_traffic(stat_ids, from_date, to_date, time_span, tz_offset, return_time_type='utc',
                           return_type='chart', material_group_code=None, is_shield=False, is_contract_stat=False):
    edge_data = get_type5_data(stat_ids=stat_ids, table='tb_traffic_data_transferred', from_date=from_date, to_date=to_date, time_span=time_span,
                                   tz_offset=tz_offset, return_time_type=return_time_type, is_contract_stat=is_contract_stat)

    if return_type == 'chart':
        ordedDic = OrderedDict()
        ordedDic['edge_data'] = edge_data

        sum_list = []
        trans_list = []
        for key in ordedDic.keys():
            if ordedDic[key].get('value_list').__len__() > 0:
                sum_list.append(ordedDic[key].get('value_list'))
                trans_list.append(ordedDic[key].get('transferred_list'))
        total_data = get_total_traffic(**{'sum_list' : sum_list})
        total_trans_data = get_total_traffic(**{'sum_list' : trans_list})

        ordedDic['total_data'] = total_data
        ordedDic['total_trans_data'] = total_trans_data

        ret_val = ordedDic
    elif return_type == 'excel':
        dataHeader = []
        data = []
        if len(edge_data.get('value_list')) > 0 :
            dataHeader.append('Edge Bandwidth(bps)')
            data.append(edge_data.get('value_list'))
        if len(edge_data.get('value_list')) > 0 :
            dataHeader.append('Edge Data Transferred(bytes)')
            data.append(edge_data.get('transferred_list'))
        ret_val = {'dataHeader' : dataHeader, 'data':data}
    elif return_type == 'api':
        ordedDic = OrderedDict()
        ordedDic['edge_data'] = edge_data
        ret_val = ordedDic

    return ret_val


def get_type5_data(stat_ids, table, from_date, to_date, time_span, tz_offset, return_time_type='utc', is_contract_stat=False):
    stat_condition = ''

    if stat_ids.__len__() > 0 :
        for i in range(stat_ids.__len__()):
            stat_condition = stat_condition + stat_ids[i].__str__()
            if(i != stat_ids.__len__() - 1) :
                stat_condition = stat_condition + ','

    
    from_date = from_date - timedelta(hours=tz_offset)
    to_date = to_date + timedelta(days=1) - timedelta(hours=tz_offset)
    idColumnName = "stat_id"
    if is_contract_stat :
        table = table + "_item"
        idColumnName = "item_id"

    if time_span == "5" :
        sql = """
                SELECT stat_datehour,
                sum(m00)*8/300 as e0_traffic,
                sum(m05)*8/300 as e1_traffic,
                sum(m10)*8/300 as e2_traffic,
                sum(m15)*8/300 as e3_traffic,
                sum(m20)*8/300 as e4_traffic,
                sum(m25)*8/300 as e5_traffic,
                sum(m30)*8/300 as e6_traffic,
                sum(m35)*8/300 as e7_traffic,
                sum(m40)*8/300 as e8_traffic,
                sum(m45)*8/300 as e9_traffic,
                sum(m50)*8/300 as e10_traffic,
                sum(m55)*8/300 as e11_traffic,
                sum(m00) as e0,
                sum(m05) as e1,
                sum(m10) as e2,
                sum(m15) as e3,
                sum(m20) as e4,
                sum(m25) as e5,
                sum(m30) as e6,
                sum(m35) as e7,
                sum(m40) as e8,
                sum(m45) as e9,
                sum(m50) as e10,
                sum(m55) as e11
                FROM %s
                WHERE %s in (%s)
                AND stat_datehour >= %s and stat_datehour < %s
                GROUP BY stat_datehour
                ORDER BY stat_datehour
               """%(table,
                     idColumnName,
                     stat_condition,
                     from_date.strftime("%Y%m%d%H"),
                     to_date.strftime("%Y%m%d%H"))

    elif time_span == "hourly" :
        sql = """
                SELECT stat_datehour,
                    greatest(sum(m00), sum(m05), sum(m10), sum(m15), sum(m20), sum(m25), sum(m30), sum(m35), sum(m40), sum(m45), sum(m50), sum(m55))*8/300 as hour_traffic,
                    (sum(m00)+sum(m05)+sum(m10)+sum(m15)+sum(m20)+sum(m25)+sum(m30)+sum(m35)+sum(m40)+sum(m45)+sum(m50)+sum(m55)) as hour_transfer
                FROM %s
                WHERE %s in (%s)
                AND stat_datehour >= %s and stat_datehour < %s
                GROUP BY stat_datehour
                ORDER BY stat_datehour
               """%(table,
                     idColumnName,
                     stat_condition,
                     from_date.strftime("%Y%m%d%H"),
                     to_date.strftime("%Y%m%d%H"))

    elif time_span == "daily" :
        sql = """
                select substring(stat_time,1,10) as stat_time, max(hour_traffic) as day_traffic, sum(hour_transfer) as day_transfer
                from (
                    SELECT DATE_ADD(STR_TO_DATE(CAST(stat_datehour AS CHAR(10)),"%s"), INTERVAL %s HOUR) AS stat_time, 
                        greatest(sum(m00), sum(m05), sum(m10), sum(m15), sum(m20), sum(m25), sum(m30), sum(m35), sum(m40), sum(m45), sum(m50), sum(m55))*8/300 as hour_traffic,
                        (sum(m00)+sum(m05)+sum(m10)+sum(m15)+sum(m20)+sum(m25)+sum(m30)+sum(m35)+sum(m40)+sum(m45)+sum(m50)+sum(m55)) as hour_transfer
                    FROM %s
                    WHERE %s in (%s)
                    AND stat_datehour >= %s and stat_datehour < %s
                    GROUP BY DATE_ADD(STR_TO_DATE(CAST(stat_datehour AS CHAR(10)),"%s"), INTERVAL %s HOUR)
                ) hour_tmp
                GROUP BY substring(stat_time,1,10)
                ORDER BY substring(stat_time,1,10)""" % ('%Y%m%d%H',
                                                         tz_offset,
                                                         table,
                                                         idColumnName,
                                                         stat_condition,
                                                         from_date.strftime("%Y%m%d%H"),
                                                         to_date.strftime("%Y%m%d%H"),
                                                         '%Y%m%d%H',
                                                         tz_offset)
    else :
        raise Exception("Invalid Time Span..")

    try:
        #cursor = connections['one_stat'].cursor()
        cursor = connections['legacy_stat'].cursor()
        cursor.execute(sql)
        rslist = cursor.fetchall()
    finally:
        cursor.close()
        del cursor

    if rslist.__len__() <= 0 :
        return {'value_list' : [], 'transferred_list' : []}
    if time_span == "5" :
        retlist = []
        for q in rslist:
            seperate_5min_data(retlist, q)
        rslist = retlist
    elif time_span == "hourly":
        retlist = []
        for q in rslist:
            retlist.append([datetime.strptime(str(q[0]),"%Y%m%d%H"), q[1], q[2]])
        rslist = retlist

        
#    print relist
    if len(rslist[0]) == 3 :
        stats = generate_traffic(time_span, from_date, to_date, rslist, return_time_type, tz_offset, transferredData=True)
    else :
        stats = generate_traffic(time_span, from_date, to_date, rslist, return_time_type, tz_offset)
    return stats


def get_data_traffic_by_service(stat_ids, from_date, to_date, time_span, tz_offset, return_time_type='utc',
                           return_type='chart', material_group_code=None, is_shield=False, is_contract_stat=False):
    if is_contract_stat :
        statList = StatMaster.all_objects.filter(item__in=stat_ids)
        is_contract_stat = False
    else :
        statList = StatMaster.all_objects.filter(stat_id__in=stat_ids)

    by_service_result = []
    by_service_chart_result = {}

    for stat_id in statList :
        tmpDict = {}

        try :
            domain = LegacyStatMaster.objects.get(statmaster_id=stat_id.pk).stat_svc_name
        except :
            continue

        tmpDict['stat_id'] = stat_id.pk
        tmpDict['service'] = domain

        edge_data_5m = get_type5_data(stat_ids=[stat_id.pk], table='tb_traffic_data_transferred', from_date=from_date, to_date=to_date, time_span='5',
                                       tz_offset=tz_offset, return_time_type=return_time_type, is_contract_stat=is_contract_stat)

        tmpDict['data_95'] = get95DataSingleItem(edge_data_5m)
        tmpDict['data_min'] = edge_data_5m.get('minVal') if edge_data_5m.get('minVal') != None else 0
        tmpDict['data_max'] = edge_data_5m.get('maxVal') if edge_data_5m.get('maxVal') != None else 0
        tmpDict['data_avg'] = edge_data_5m.get('avgValue') if edge_data_5m.get('avgValue') != None else 0
        tmpDict['data_trans'] = edge_data_5m.get('totalTransffered') if edge_data_5m.get('totalTransffered') != None else 0

        by_service_result.append(tmpDict)
        by_service_chart_result[domain] = edge_data_5m


    from operator import itemgetter
    sorted_by_service_result = sorted(by_service_result, key=itemgetter('data_trans'), reverse=True)
    # print sorted_by_service_result

    if return_type == 'chart':
        chart_data = OrderedDict()
        for data in sorted_by_service_result[0:15] :
            service = data['service']

            if time_span == 5 :
                edge_data = by_service_chart_result.get(service)
            else :
                stat_id = long(data['stat_id'])

                edge_data = get_type5_data(stat_ids=[stat_id], table='tb_traffic_data_transferred', from_date=from_date, to_date=to_date, time_span=time_span,
                                                   tz_offset=tz_offset, return_time_type=return_time_type, is_contract_stat=is_contract_stat)

            chart_data[service] = edge_data

        # print chart_data
        ret_val = {'chartData' : chart_data, 'tableData' : sorted_by_service_result}

    elif return_type == 'excel':
        dataHeader = []
        dataFormat = []
        data = []

        dataHeader = ['URL', 'MIN(bps)', 'MAX(bps)', 'AVG(bps)', '95th(bps)', 'Data Transferred(bytes)']
        dataFormat = ['', 'addCommaAfterFloor', 'addCommaAfterFloor', 'addCommaAfterFloor', 'addCommaAfterFloor', 'addCommaAfterFloor']

        for item in sorted_by_service_result :
            data.append([item.get('service'), item.get('data_min'), item.get('data_max'), item.get('data_avg'), item.get('data_95'), item.get('data_trans')])

        ret_val = {'dataHeader' : dataHeader, 'dataFormat': dataFormat, 'data':data}
    elif return_type == 'api':
        ret_val = sorted_by_service_result

    return ret_val


def get_data_transfer_by_service(stat_ids, from_date, to_date, time_span, tz_offset, return_time_type='utc',
                           return_type='chart', material_group_code=None, is_shield=False, is_contract_stat=False):
    if is_contract_stat :
        statList = StatMaster.all_objects.filter(item__in=stat_ids)
        is_contract_stat = False
    else :
        statList = StatMaster.all_objects.filter(stat_id__in=stat_ids)

    by_service_result = []
    by_service_chart_result = {}

    for stat_id in statList :
        tmpDict = {}

        try :
            domain = LegacyStatMaster.objects.get(statmaster_id=stat_id.pk).stat_svc_name
        except :
            continue

        tmpDict['stat_id'] = stat_id.pk
        tmpDict['service'] = domain

        edge_data = get_type5_data(stat_ids=[stat_id.pk], table='tb_traffic_data_transferred', from_date=from_date, to_date=to_date, time_span=time_span,
                                       tz_offset=tz_offset, return_time_type=return_time_type, is_contract_stat=is_contract_stat)

        tmpDict['data_trans'] = edge_data.get('totalTransffered') if edge_data.get('totalTransffered') != None else 0

        by_service_result.append(tmpDict)
        by_service_chart_result[domain] = edge_data

    from operator import itemgetter
    sorted_by_service_result = sorted(by_service_result, key=itemgetter('data_trans'), reverse=True)
    # print sorted_by_service_result

    if return_type == 'chart':
        chart_data = OrderedDict()

        for data in sorted_by_service_result[0:15] :
            stat_id = long(data['stat_id'])

            service = data['service']

            chart_data[service] = by_service_chart_result.get(service)

        # print chart_data
        ret_val = {'chartData' : chart_data, 'tableData' : sorted_by_service_result}

    elif return_type == 'excel':
        dataHeader = []
        dataFormat = []
        data = []

        dataHeader = ['URL', 'Data Transferred(bytes)']
        dataFormat = ['', 'addCommaAfterFloor']

        for item in sorted_by_service_result :
            data.append([item.get('service'), item.get('data_trans')])

        ret_val = {'dataHeader' : dataHeader, 'dataFormat':dataFormat, 'data':data}
    elif return_type == 'api':
        ret_val = sorted_by_service_result

    return ret_val


def get_type5_data_hit(stat_ids, table, from_date, to_date, time_span, tz_offset, return_time_type='utc', is_contract_stat=False):

    stat_condition = ''

    if stat_ids.__len__() > 0 :
        for i in range(stat_ids.__len__()):
            stat_condition = stat_condition + stat_ids[i].__str__()
            if(i != stat_ids.__len__() - 1) :
                stat_condition = stat_condition + ','

    from_date = from_date - timedelta(hours=tz_offset)
    to_date = to_date + timedelta(days=1) - timedelta(hours=tz_offset)

    idColumnName = "stat_id"
    if is_contract_stat :
        table = table + "_item"
        idColumnName = "item_id"

    if time_span == "5" :
        sql = """
                SELECT stat_datehour,
                sum(m00) as e0,
                sum(m05) as e1,
                sum(m10) as e2,
                sum(m15) as e3,
                sum(m20) as e4,
                sum(m25) as e5,
                sum(m30) as e6,
                sum(m35) as e7,
                sum(m40) as e8,
                sum(m45) as e9,
                sum(m50) as e10,
                sum(m55) as e11
                FROM %s
                WHERE %s in (%s)
                AND stat_datehour >= '%s' and stat_datehour < '%s'
                GROUP BY stat_datehour
                ORDER BY stat_datehour""" % (table, 
                                             idColumnName, 
                                             stat_condition, 
                                             from_date.strftime("%Y%m%d%H"), 
                                             to_date.strftime("%Y%m%d%H"))
    elif time_span == "hourly" :
        sql = """
                SELECT stat_datehour,
                    greatest(sum(m00), sum(m05), sum(m10), sum(m15), sum(m20), sum(m25), sum(m30), sum(m35), sum(m40), sum(m45), sum(m50), sum(m55)) as val
                FROM %s
                WHERE %s in (%s)
                AND stat_datehour >= '%s' and stat_datehour < '%s'
                GROUP BY stat_datehour
                ORDER BY stat_datehour""" % (table, 
                                         idColumnName, 
                                         stat_condition, 
                                         from_date.strftime("%Y%m%d%H"), 
                                         to_date.strftime("%Y%m%d%H"))
    elif time_span == "daily" :
        sql = """
                select substring(stat_time,1,10) as stat_time, max(hour_val) as day_val
                from (
                    SELECT DATE_ADD(STR_TO_DATE(CAST(stat_datehour AS CHAR(10)),"%s"), INTERVAL %s HOUR) as stat_time,
                        greatest(sum(m00), sum(m05), sum(m10), sum(m15), sum(m20), sum(m25), sum(m30), sum(m35), sum(m40), sum(m45), sum(m50), sum(m55)) as hour_val
                    FROM %s
                    WHERE %s in (%s)
                    AND stat_datehour >= '%s' and stat_datehour < '%s'
                    GROUP BY DATE_ADD(STR_TO_DATE(CAST(stat_datehour AS CHAR(10)),"%s"), INTERVAL %s HOUR)
                ) hour_tmp
                GROUP BY substring(stat_time,1,10)
                ORDER BY substring(stat_time,1,10)""" % ('%Y%m%d%H',
                                                         tz_offset, 
                                                         table, 
                                                         idColumnName, 
                                                         stat_condition, 
                                                         from_date.strftime("%Y%m%d%H"), 
                                                         to_date.strftime("%Y%m%d%H"),
                                                         '%Y%m%d%H',
                                                         tz_offset)
    else :
        raise Exception("Invalid Time Span..")

#    print sql
    try:
        cursor = connections['legacy_stat'].cursor()
        cursor.execute(sql)
        rslist = cursor.fetchall()
    finally:
        cursor.close()
        del cursor
    if rslist.__len__() <= 0 :
        return {'value_list' : []}
    if time_span == "5" :
        retlist = []

        for q in rslist:
            seperate_5min_data(retlist, q)
        rslist = retlist
    elif time_span == "hourly":
        retlist = []
        for q in rslist:
            retlist.append([datetime.strptime(str(q[0]),"%Y%m%d%H"), q[1]])
        rslist = retlist

    stats = generate_traffic(time_span, from_date, to_date, rslist, return_time_type, tz_offset)
    return stats

def get_data_origin_hits(stat_ids, from_date, to_date, time_span, tz_offset, return_time_type='utc', return_type='chart', is_contract_stat=False):
    origin_hits = get_type5_data_hit(stat_ids=stat_ids, table='tb_traffic_peak_hits', from_date=from_date, to_date=to_date, time_span=time_span,
                                     tz_offset=tz_offset, return_time_type=return_time_type, is_contract_stat=is_contract_stat)

    if time_span != "5" and len(origin_hits.get('value_list')) > 0 :
        origin_hits_5m = get_type5_data_hit(stat_ids=stat_ids, table='tb_traffic_peak_hits', from_date=from_date, to_date=to_date, time_span="5",
                                     tz_offset=tz_offset, return_time_type=return_time_type, is_contract_stat=is_contract_stat)
        origin_hits['totValue'] = origin_hits_5m.get('totValue') if origin_hits_5m.get('totValue') != None else 0

    if return_type == 'chart':
        result = {'origin_hits' : origin_hits}
    elif return_type == 'excel':
        dataHeader = []
        data = []
        if len(origin_hits.get('value_list')) > 0 :
            dataHeader.append('Origin Hits')
            data.append(origin_hits.get('value_list'))
        result = {'dataHeader' : dataHeader, 'data' : data}
    elif return_type == 'api':
        result = []

        if origin_hits == None or len(origin_hits.get('value_list')) == 0 :
            return result

        for r in origin_hits.get('value_list'):
            result.append({'dateTime':r[0], 'peakHits':r[1]})

    return result