import sys, os

sys.path.insert(0, '/home/jongsoobae/portal3/spectrum-api/')
os.environ['DJANGO_SETTINGS_MODULE'] = 'spectrum_api.settings'

from django.utils import unittest
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.test import APIClient, APITransactionTestCase, APITestCase

from spectrum_api.shared_components.models import FakeRequest
from spectrum_api.shared_components.utils.user_util import putActualUserInfo
from spectrum_api.report.utils.common import get_timezone_info



def check_response_data_chart(response):
    result_factor = response.data['factor']
    if result_factor == 'failure':
        return True if response.data['msg'] == 'No Data.' else False
    elif result_factor == 'success':
        return True
    else:
        return False

class TestICMonitoringClusterAPI(unittest.TestCase):

    def setUp(self):

        self.auth_token = Token.objects.get(user__username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=self.auth_token.user)

        self.legacy_traffic_data = {"tz_cd":"GMT_15",
            "date_from":"2016-01-16",
            "date_to":"2016-01-16",
            "time_span":"daily",
            "customer_stat_unit":["248199","248376"]}

        self.legacy_visitor_data = {"tz_cd":"GMT_15",
            "date_from":"2015-01-01",
            "date_to":"2015-01-04",
            "time_span":"daily",
            "is_detail":"true",
            "customer_stat_unit":["237780"]}

        self.GMT_CODE = {'GMT_15':('GMT9',9),
                        'GMT_61':('GMT0',0)}

    def test_unit_get_timezone_info(self):
        for gmt_obj in self.GMT_CODE.iteritems():
            result = get_timezone_info(gmt_obj[0])
            self.assertEqual(result, gmt_obj[1])


    def test_legacy_traffic_trafficbyservice(self):
        request = FakeRequest()
        putActualUserInfo(request, self.auth_token.user)

        response = self.client.post('/api/report/legacy/traffic/trafficbyservice/', self.legacy_traffic_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(check_response_data_chart(response))


    def test_legacy_traffic_transferredbyservice(self):

        request = FakeRequest()
        putActualUserInfo(request, self.auth_token.user)

        response = self.client.post('/api/report/legacy/traffic/transferredbyservice/', self.legacy_traffic_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(check_response_data_chart(response))

    def test_legacy_traffic_totaltraffic(self):

        request = FakeRequest()
        putActualUserInfo(request, self.auth_token.user)

        response = self.client.post('/api/report/legacy/traffic/totaltraffic/', self.legacy_traffic_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(check_response_data_chart(response))

    def test_legacy_traffic_originhits(self):

        request = FakeRequest()
        putActualUserInfo(request, self.auth_token.user)

        response = self.client.post('/api/report/legacy/traffic/originhits/', self.legacy_traffic_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(check_response_data_chart(response))

    def test_legacy_visitor_uniquevisitors(self):

        request = FakeRequest()
        putActualUserInfo(request, self.auth_token.user)

        response = self.client.post('/api/report/legacy/visitor/uniquevisitors/', self.legacy_visitor_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(check_response_data_chart(response))

    def test_legacy_visitor_edgeresponsecode(self):

        request = FakeRequest()
        putActualUserInfo(request, self.auth_token.user)

        response = self.client.post('/api/report/legacy/visitor/edgeresponsecode/', self.legacy_visitor_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(check_response_data_chart(response))

    def test_legacy_visitor_responsebandwidth(self):

        request = FakeRequest()
        putActualUserInfo(request, self.auth_token.user)

        response = self.client.post('/api/report/legacy/visitor/responsebandwidth/', self.legacy_visitor_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(check_response_data_chart(response))

if __name__ == "__main__":
    unittest.main()
