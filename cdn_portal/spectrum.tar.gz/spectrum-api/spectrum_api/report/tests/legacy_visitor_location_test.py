import json
from django.utils import unittest
from django.contrib.auth.models import User
from rest_framework import status
from rest_framework.test import APIClient

# [AURORAUI-3191]
### TEST ENV ###
# contract_group_id = 6502
# account_no = 42595
# account_name_eng = 'Kofac'
legacy_visitor_location_data = {
    'tz_cd': 'GMT_15',
    'date_from': '2016-10-01',
    'date_to': '2016-11-30',
    'time_span': 'daily',
    'item_id': 'null',
    'customer_stat_unit': ['244794']
}
### TEST ENV ###

def check_response_data_chart(response):
    result_factor = response.data['factor']
    if result_factor == 'failure':
        return True if response.data['msg'] == 'No Data.' else False
    elif result_factor == 'success':
        return True
    else:
        return False

class LegacyVisitorLocationTEST(unittest.TestCase):

    def setUp(self):
        user = User.objects.get(username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=user)

    def test_legacy_traffic_originhits(self):
        url = '/api/report/legacy/visitor/location/'

        response = self.client.get('/api/report/legacy/visitor/location/', legacy_visitor_location_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(check_response_data_chart(response))

