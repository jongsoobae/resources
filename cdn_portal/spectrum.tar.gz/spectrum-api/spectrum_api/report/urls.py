# -*- coding: utf-8 -*-

from django.conf.urls.defaults import patterns, url
from rest_framework.urlpatterns import format_suffix_patterns

from spectrum_api.report.views.legacy_traffic import GetChartTotalTraffic, GetChartTransferByService, \
                                                    GetChartTrafficByService, GetChartOriginHits
from spectrum_api.report.views.legacy_visitor import GetUniqueVisitors, GetEdgeResponseCode, \
                                                    GetLocation, GetResponseBandwidth, \
                                                    GetBrowser, GetOperatingSystem, GetPlayer, GetTop10Isp

restfw_api_urlpatterns = patterns('spectrum_api.report.views',
    url(r'^report/legacy/traffic/totaltraffic/$', GetChartTotalTraffic.as_view(), name="GetChartTotalTraffic"),
    url(r'^report/legacy/traffic/transferredbyservice/$', GetChartTransferByService.as_view(), name="GetChartTransferByService"),
    url(r'^report/legacy/traffic/trafficbyservice/$', GetChartTrafficByService.as_view(), name="GetChartTrafficByService"),
    url(r'^report/legacy/traffic/originhits/$', GetChartOriginHits.as_view(), name="GetChartOriginHits"),

    url(r'^report/legacy/visitor/uniquevisitors/$', GetUniqueVisitors.as_view(), name="GetUniqueVisitors"),
    url(r'^report/legacy/visitor/edgeresponsecode/$', GetEdgeResponseCode.as_view(), name="GetEdgeResponseCode"),
    url(r'^report/legacy/visitor/location/$', GetLocation.as_view(), name="GetLocation"),
    url(r'^report/legacy/visitor/responsebandwidth/$', GetResponseBandwidth.as_view(), name="GetResponseBandwidth"),
    url(r'^report/legacy/visitor/browser/$', GetBrowser.as_view(), name="GetBrowser"),
    url(r'^report/legacy/visitor/operatingsystem/$', GetOperatingSystem.as_view(), name="GetOperatingSystem"),
    url(r'^report/legacy/visitor/player/$', GetPlayer.as_view(), name="GetPlayer"),
    url(r'^report/legacy/visitor/top10isp/$', GetTop10Isp.as_view(), name="GetTop10Isp"),

)
urlpatterns = format_suffix_patterns(restfw_api_urlpatterns)
