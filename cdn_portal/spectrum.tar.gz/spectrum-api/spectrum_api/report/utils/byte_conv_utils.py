from datetime import datetime, timedelta
from decimal import Decimal, ROUND_UP, ROUND_DOWN
from time import mktime
import calendar
import time

"""
def bytes_to_mb_prec_rounddown(value,precision):
    perc = Decimal(str(10**(-1*precision)))
    return Decimal(str(float(value)/1000000.0)).quantize(perc, rounding=ROUND_DOWN)
"""


def data_to_rounddown(value, precision):
    perc = Decimal(str(10 ** (-1 * precision)))
    return Decimal(str(float(value) / 1.0)).quantize(perc, rounding=ROUND_DOWN)

def data_to_roundup(value, precision):
    perc = Decimal(str(10 ** (-1 * precision)))
    return Decimal(str(float(value) / 1.0)).quantize(perc, rounding=ROUND_UP)

def bytes_to_gb_prec_roundup(value, precision):
    perc = Decimal(str(10 ** (-1 * precision)))
    return Decimal(str(float(value) / 1000000000.0)).quantize(perc, rounding=ROUND_UP)

def get_percent_val_rounddown(val, sum_val, precision):
    if sum_val == 0 :
        return 0
    perc = Decimal(str(10 ** (-1 * precision)))
    return Decimal(str(float(val) / sum_val * 100)).quantize(perc, rounding=ROUND_DOWN)

def convert_traffic(transfer):
    return transfer * 8 / 300

def to_timestamp(date_obj):
    return int(mktime(date_obj.timetuple()) * 1000)

def timestamp_to_datetime(timestamp):
    return datetime.datetime.fromtimestamp(timestamp / 1000)

def to_timestamp_gmt(date_obj):
    return int(calendar.timegm(date_obj.timetuple()) * 1000)

def minus_days(date_obj, days):
    return date_obj - timedelta(days=days)

def generate_null_traffic(time_span, from_date, to_date, base_traffic, return_time_type="utc", tz_offset="0", transferredData=False):
    ret_list = []
    transferred_list = []

    from_date = from_date + timedelta(hours=tz_offset)
    to_date = to_date + timedelta(hours=tz_offset)
    temp_date = from_date

    if time_span == "5" :
        seq = 300
    elif time_span == "hourly" :
        seq = 300 * 12
    elif time_span == "daily" :
        seq = 300 * 12 * 24
    else :
        return None

    totalCnt = 0
    while temp_date < to_date :
        totalCnt += 1

        if "utc" == return_time_type :
            ret_list.append((to_timestamp_gmt(temp_date), 0))
            if transferredData:
                transferred_list.append((to_timestamp_gmt(temp_date), 0))
        elif "str" == return_time_type :
            ret_list.append((temp_date.strftime('%Y%m%d%H%M'), 0))
            if transferredData:
                transferred_list.append((temp_date.strftime('%Y%m%d%H%M'), 0))
        else :
            ret_list.append((temp_date, 0))
            if transferredData:
                transferred_list.append((temp_date, 0))

        temp_date = temp_date + timedelta(seconds=seq)

    # print ret_list
    return {'value_list' : ret_list, 'avgValue' : 0, 'totValue' : 0, 'maxVal' : 0, 'minVal' : 0, 'totalTransffered' : 0, 'transferred_list':transferred_list}



def generate_traffic(time_span, from_date, to_date, base_traffic, return_time_type="utc", tz_offset="0", transferredData=False):
    ret_list = []
    ret_trans_list = []
    from_date = from_date + timedelta(hours=tz_offset)
    to_date = to_date + timedelta(hours=tz_offset)
    temp_date = from_date

    if time_span == "5" :
        seq = 300
    elif time_span == "hourly" :
        seq = 300 * 12
    elif time_span == "daily" :
        seq = 300 * 12 * 24
    else :
        return None

    totalVal = 0
    totalTransferred = 0
    totalCnt = 0
    minVal = 0
    maxVal = 0

    if base_traffic and temp_date < to_date:
        for s in base_traffic:
            while 1 :
                totalCnt += 1

                if not isinstance(s[0], datetime) :
                    curDate = datetime.strptime(s[0], '%Y-%m-%d')
                else :
                    curDate = s[0]

                if time_span == "5" or time_span == "hourly" :
                    diffDate = curDate + timedelta(hours=tz_offset)
                else :
                    diffDate = curDate

                if temp_date == diffDate :
                    if isinstance(s[1], Decimal) :
                        tmpVal = float(s[1])
                    else :
                        tmpVal = s[1]

                    if transferredData:
                        if isinstance(s[1], Decimal) :
                            tmpTransferredVal = float(s[2])
                        else :
                            tmpTransferredVal = s[2]

                        totalTransferred += tmpTransferredVal

                    totalVal += tmpVal

                    if tmpVal > maxVal : maxVal = tmpVal

                    if totalCnt == 1 :
                        minVal = tmpVal
                    elif tmpVal < minVal :
                        minVal = tmpVal

                    if "utc" == return_time_type :
                        ret_list.append((to_timestamp_gmt(temp_date), tmpVal))
                        if transferredData:
                            ret_trans_list.append((to_timestamp_gmt(temp_date), tmpTransferredVal))
                    elif "str" == return_time_type :
                        ret_list.append((temp_date.strftime('%Y%m%d%H%M'), tmpVal))
                        if transferredData:
                            ret_trans_list.append((temp_date.strftime('%Y%m%d%H%M'), tmpTransferredVal))
                    else :
                        ret_list.append((temp_date, tmpVal))
                        if transferredData:
                            ret_trans_list.append((temp_date, tmpTransferredVal))
                    temp_date = temp_date + timedelta(seconds=seq)

                    break
                else :
                    if "utc" == return_time_type :
                        ret_list.append((to_timestamp_gmt(temp_date), 0))
                        if transferredData:
                            ret_trans_list.append((to_timestamp_gmt(temp_date), 0))
                    elif "str" == return_time_type :
                        ret_list.append((temp_date.strftime('%Y%m%d%H%M'), 0))
                        if transferredData:
                            ret_trans_list.append((temp_date.strftime('%Y%m%d%H%M'), 0))
                    else :
                        ret_list.append((temp_date, 0))
                        if transferredData:
                            ret_trans_list.append((temp_date, 0))

                temp_date = temp_date + timedelta(seconds=seq)

        while temp_date < to_date :
            totalCnt += 1

            if "utc" == return_time_type :
                ret_list.append((to_timestamp_gmt(temp_date), 0))
                if transferredData:
                    ret_trans_list.append((to_timestamp_gmt(temp_date), 0))
            elif "str" == return_time_type :
                ret_list.append((temp_date.strftime('%Y%m%d%H%M'), 0))
                if transferredData:
                    ret_trans_list.append((temp_date.strftime('%Y%m%d%H%M'), 0))
            else :
                ret_list.append((temp_date, 0))
                if transferredData:
                    ret_trans_list.append((temp_date, 0))

            temp_date = temp_date + timedelta(seconds=seq)

        # print ret_list
        return {'value_list' : ret_list, 'transferred_list':ret_trans_list, 'avgValue' : totalVal / totalCnt, 'totValue' : totalVal, 'maxVal' : maxVal, 'minVal' : minVal, 'totalTransffered' : totalTransferred, 'avgTransferValue' : totalTransferred / totalCnt}
    else :
        return {'value_list' : [], 'transferred_list': [], 'avgValue' : 0, 'totValue' : 0, 'maxVal' : 0, 'minVal' : 0}

""" default list at any search condition. return type list = [(date, 0), ....]"""
def generate_base_traffic(time_type, from_date, to_date, return_time_type='default'):
    ret_list = []
    temp_date = from_date

    if time_type == '5' :
        seq = 300
    elif time_type == 'h' :
        seq = 300 * 12
    elif time_type == 'day' :
        seq = 300 * 12 * 24
    while 1:
        if return_time_type == 'default':
            ret_list.append([temp_date, 0])
        elif return_time_type == 'utc' :
            ret_list.append((to_timestamp_gmt(temp_date), 0))
        if temp_date >= to_date:
            break
        temp_date = temp_date + timedelta(seconds=seq)
    return ret_list

def convert_return_data(input_list, time_span='5m', time_type='utc', value_type='bps', cal_type='sum'):
    ret_list = []
    if time_span == '5m':
        for q in input_list:
            time_key = q[0]
            traffic_value = q[1]
            if time_type == 'utc':
                time_key = to_timestamp_gmt(time_key)
            elif time_type == 'str':
                time_key = time.strftime('%Y-%m-%d %H:%M:%S', time_key.timetuple())
            if value_type == 'byte':
                traffic_value = bytes_to_mbps(traffic_value)
            ret_list.append([time_key, traffic_value])
    else:
        add_offset = 1
        if time_span == 'day':
            add_offset = 24
        temp_time = None
        loop_cnt = 0
        traffic_sum = 0
        traffic_peak = 0
        for q in input_list:
            if loop_cnt == 0 :
                temp_time = q[0]
            if temp_time <= q[0] and temp_time + timedelta(hours=add_offset) > q[0] :
                traffic_sum = traffic_sum + q[1]
                if traffic_peak < q[1]:
                    traffic_peak = q[1]

            else:
                time_key = temp_time
                traffic_value = traffic_sum
                if cal_type == 'peak':
                    traffic_value = traffic_peak
                if time_type == 'utc':
                    time_key = to_timestamp(time_key)
                elif time_type == 'str':
                    time_key = time.strftime('%Y-%m-%d %H:%M:%S', time_key.timetuple())
                ret_list.append([time_key, traffic_value])
                traffic_sum = 0
                traffic_peak = 0
                temp_time = q[0]
            loop_cnt = loop_cnt + 1

#            if loop_cnt == len(input_list) :
#                print loop_cnt
#                time_key = temp_time
#                traffic_value = traffic_sum
#                if cal_type == 'peak':
#                    traffic_value = traffic_peak
#
#                if time_type == 'utc':
#                    time_key = to_timestamp(time_key)
#                elif time_type == 'str':
#                    time_key = time.strftime('%Y-%m-%d %H:%M:%S', time_key.timetuple())
#                if value_type == 'byte':
#                    traffic_value = bytes_to_mbps(traffic_value)
#                ret_list.append([time_key, traffic_value])
    return ret_list

def bytes_to_mbps(bytes):
    """given total bytes in a 5-minute period, return average mbps"""
    return bytes * 8 / 300. / 1000000.



def get_avg(obj):
    total_sum = 0
    total_cnt = 0
    for q in obj:
        total_cnt = total_cnt + 1
        total_sum = total_sum + q[1]

    if total_cnt == 0 :
        return 0

    return total_sum / total_cnt

def get_total(obj):
    total_sum = 0
    for q in obj:
        total_sum = total_sum + q[1]
    return total_sum

def getMaxMin(obj):
    ret_list = []
    for q in obj:
        ret_list.append([q[1], q[0]])
    ret_list.sort()

#     print ret_list
    dic = {"min" : ret_list[0][0], "max" : ret_list[-1][0], "maxTime" : ret_list[-1][1]}
    return dic
