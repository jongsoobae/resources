from datetime import timedelta
from django.db import connections
from django.utils import translation
from spectrum_api.shared_components.models.common_code import GMTCD

def dictfetchall(cursor):
    "Returns all rows from a cursor as a dict"
    desc = cursor.description
    return [
        dict(zip([col[0] for col in desc], row))
        for row in cursor.fetchall()
    ]


def getErp_contract(contract):
    contract_no = contract[:contract.find('-')]
    item_no = contract[contract.find('-') + 1:]

    # print 'contract_no = %s  , item_no = %s'%(contract_no, item_no)
    sql = """
        SELECT *,
            IFNULL((SELECT MAX('Y')    FROM customer_item ci WHERE ci.contract_no=aa.contract_no AND (ci.item_no=aa.item_no OR ci.parent_item_id=aa.item_id) AND relay_traffic='5'), 'N') AS shield_yn,
            IFNULL((SELECT MAX('Y')    FROM customer_item ci WHERE ci.contract_no=aa.contract_no AND (ci.item_no=aa.item_no OR ci.parent_item_id=aa.item_id) AND relay_traffic IN ('6','7')), 'N' ) AS dynamic_yn,
            IFNULL((SELECT MAX('Y')    FROM customer_item ci WHERE ci.contract_no=aa.contract_no AND ci.item_no=aa.item_no AND material_no='1115'), 'N') AS numberHits_yn
        FROM
         (
            SELECT DISTINCT concat(a.contract_no, '-', a.item_no) AS product_key,
                 a.contract_no,
                 a.item_no,
                 a.material_no,
                 a.billing_method_code AS billing_type, a.billing_method AS billing_method, CASE a.SDABW WHEN 'Z' THEN 'Y' ELSE 'N' END AS perzone_yn,
                 sales_org,
                 a.item_id,
                 a.bill_to_account
            FROM customer_item a
                INNER JOIN customer_contract b ON a.contract_no = b.contract_no
            WHERE ((a.billing_standards IN ('1', '2') AND a.SDABW <> 'Z') OR (
                LEFT(a.service_type,1)<>'X' AND a.SDABW = 'Z')) AND a.product <> '13' AND (a.service_type='1' OR a.service_type='2' OR
                LEFT(a.service_type,1)='R') AND a.hierarchy_no <> '' AND b.contract_no = '%s'
                AND a.item_no = '%s'
        ) aa
        ORDER BY aa.product_key""" % (contract_no, item_no)
    # print sql
    try:
        cursor = connections['default'].cursor()
        cursor.execute(sql)
        rslist = dictfetchall(cursor)
    finally:
        cursor.close()
        del cursor
    return rslist




def periodToTimeSpan(date_from, date_to) :
    date_tmp = date_from + timedelta(days=3)

    if date_tmp > date_to :
        return "5"

    date_tmp = date_from + timedelta(days=31)

    if date_tmp > date_to :
        return "hourly"

    return "daily"

def getDataUnit(nAvg, _postUnit, maxUnitVal=1000000000000, doNotConvert=False):
    avgUnit = ""
    numDivision = 0
    unitPrefix = ""

    if doNotConvert == True :
        return {'avgUnit':_postUnit, 'numDivision':1, 'unitPrefix':unitPrefix}

    if nAvg >= 1000000000000 and maxUnitVal >= 1000000000000:
        avgUnit = "T" + _postUnit
        numDivision = 1000000000000;
        unitPrefix = "T";
    elif nAvg >= 1000000000 and maxUnitVal >= 1000000000 :
        avgUnit = "G" + _postUnit
        numDivision = 1000000000
        unitPrefix = "G";
    elif nAvg >= 1000000 and maxUnitVal >= 1000000 :
        avgUnit = "M" + _postUnit
        numDivision = 1000000
        unitPrefix = "M";
    elif nAvg >= 1000 and maxUnitVal >= 1000 :
        avgUnit = "K" + _postUnit
        numDivision = 1000
        unitPrefix = "K";
    else :
        avgUnit = _postUnit
        numDivision = 1

    return {'avgUnit':avgUnit, 'numDivision':numDivision, 'unitPrefix':unitPrefix}

def statListToString(stat_list):
    result = ""
    if stat_list.__len__() > 0 :
        for i in range(stat_list.__len__()):
            result = result + stat_list[i].__str__()
            if(i != stat_list.__len__() - 1) :
                result = result + ','

    return result


def get_timezone_info(tz_cd):
    gmt_obj = GMTCD.objects.get(pk=tz_cd)
        
    if translation.get_language() == 'en-us' :
        gmtname_obj = gmt_obj.gmt_name_en
    elif translation.get_language() == 'ko-kr' :
        gmtname_obj = gmt_obj.gmt_name_ko
    elif translation.get_language() == 'ja-jp' :
        gmtname_obj = gmt_obj.gmt_name_ja
    elif translation.get_language() == 'zh-cn' :
        gmtname_obj = gmt_obj.gmt_name_zh
    elif translation.get_language() == 'ru-ua' :
        gmtname_obj = gmt_obj.gmt_name_ru
    else :
        gmtname_obj = gmt_obj.gmt_name_en

    return 'GMT'+str(gmt_obj.gmt_hh), gmt_obj.gmt_hh
