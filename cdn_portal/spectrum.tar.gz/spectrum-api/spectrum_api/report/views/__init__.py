def nulltoEmpty(val):
    if val == None :
        return ''

    return val

def getStatList(cgID, item_id, stat_unit):
    if '' == nulltoEmpty(item_id) and 0 == len(stat_unit) :
        raise Exception('Invalid input (item_id, stat_unit)')

    if 0 != len(stat_unit) :
        return {'stat_list': stat_unit, 'is_contract_stat': False}

    if 0 != len(item_id) :
        return {'stat_list': [item_id], 'is_contract_stat': True}
