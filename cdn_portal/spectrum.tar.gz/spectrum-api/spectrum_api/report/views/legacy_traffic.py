# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Rest API
"""
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from rest_framework.response import Response
from datetime import datetime

#from spectrum_api.shared_components.requests.packages.urllib3.packages.ordered_dict import OrderedDict
from spectrum_api.report.utils.ordered_dict import OrderedDict
from spectrum_api.report.models.chartDataModel import chartDataModel
from django.utils import simplejson

from spectrum_api.report.models.traffic import get_data_traffic_by_service, getRealDateTo, \
                                                get_data_total_traffic, get95Data, get_data_type, \
                                                get_data_transfer_by_service, get_data_origin_hits
from spectrum_api.report.utils.common import getDataUnit, get_timezone_info
from spectrum_api.report.views import getStatList
from django.utils.translation import ugettext as _

def cs_ajax_chart_traffic_by_service(request):

    try :
        tz_cd = request.DATA.get('tz_cd')
        xAxisName, tz_offset = get_timezone_info(tz_cd)
        time_span = request.DATA.get('time_span')
        report_type = "MB"

        stat_list = getStatList(request.DATA.get('filter_cust', None), request.DATA.get('item_id', None), request.DATA.get('customer_stat_unit'))
        
        date_from = datetime.strptime(request.DATA.get('date_from', None), '%Y-%m-%d')
        date_to = datetime.strptime(request.DATA.get('date_to', None), '%Y-%m-%d')

        stats = get_data_traffic_by_service(stat_list.get('stat_list'), 
                                            date_from, 
                                            date_to, 
                                            time_span,
                                            tz_offset,
                                            material_group_code=None , 
                                            is_shield=False, 
                                            is_contract_stat=stat_list.get('is_contract_stat'))

        real_date_to = getRealDateTo(date_to, tz_offset)

        chart_data = OrderedDict({})

        if len(stats.get('chartData')) == 0 :
            empty_cdm = chartDataModel()
            ret_json = {'factor':'failure', 'msg':_(u'No Data.'), 'items' : empty_cdm.getChartDataDictionary()}
        else :
            tmp = stats.get('chartData')

            defaultUnit = "bps"
            dataUnit = getDataUnit(1000, defaultUnit)
            dataTransUnit = getDataUnit(1000, "byte")

            dataKey = 'value_list'
            if "GB" == report_type :
                dataKey = 'transferred_list'

            for q in tmp.keys():
                if tmp[q][dataKey].__len__() <= 0 :
                    pass
                else :
                    chart_data[q] = tmp[q][dataKey]

            cdm = chartDataModel(chart_width=934, chart_height=350,
                    chart_data=chart_data, chart_type=True, type='line', seriesName='Edge traffic by service', yAxisName=dataUnit.get('avgUnit'), 
                    xAxisName=xAxisName,
                    numDataTransDivision=dataTransUnit.get('numDivision'), yAxisDataTransName=dataTransUnit.get('avgUnit'),
                    numDivision=dataUnit.get('numDivision'), defaultUnit=defaultUnit, unitPrefix=dataUnit.get('unitPrefix'),
                    table_data={'header':['URL', 'MIN(Kbps)', 'MAX(Kbps)', 'AVG(Kbps)', '95th(Kbps)', 'Data Transferred(KB)'], 'data':stats.get('tableData') },
                    real_date_to=real_date_to)

            ret_json = {'factor':'success', 'items' : cdm.getChartDataDictionary()}
        return ret_json
    except Exception as e:
        error_cdm = chartDataModel()
        ret_json = {'factor':'failure', 'msg':_(u'Something is technically wrong. Please try again.'), 'items' : error_cdm.getChartDataDictionary()}
    return ret_json

def cs_ajax_chart_transfer_by_service(request):

    try :
        tz_cd = request.DATA.get('tz_cd')
        xAxisName, tz_offset = get_timezone_info(tz_cd)
        time_span = request.DATA.get('time_span')
        report_type = "GB"
        
        stat_list = getStatList(request.DATA.get('filter_cust', None), request.DATA.get('item_id', None), request.DATA.get('customer_stat_unit'))

        date_from = datetime.strptime(request.DATA.get('date_from', None), '%Y-%m-%d')
        date_to = datetime.strptime(request.DATA.get('date_to', None), '%Y-%m-%d')

        time_span = request.DATA.get('time_span')
        material_group_cd = 'CA'
        is_shield = True

        stats = get_data_transfer_by_service(stat_list.get('stat_list'), date_from, date_to, time_span,
                                       tz_offset, material_group_code=material_group_cd , is_shield=is_shield, is_contract_stat=stat_list.get('is_contract_stat'))

        real_date_to = getRealDateTo(date_to, tz_offset)

        chart_data = OrderedDict({})

        if len(stats.get('chartData')) == 0 :
            empty_cdm = chartDataModel()
            ret_json = {'factor':'failure', 'msg':_(u'No Data.'), 'items' : empty_cdm.getChartDataDictionary()}
        else :
            tmp = stats.get('chartData')

            defaultUnit = "byte"
            dataUnit = getDataUnit(1000, defaultUnit)
            dataTransUnit = getDataUnit(1000, "byte")

            dataKey = 'value_list'
            if "GB" == report_type :
                dataKey = 'transferred_list'

            for q in tmp.keys():
                if tmp[q][dataKey].__len__() <= 0 :
                    pass
                else :
                    chart_data[q] = tmp[q][dataKey]

            cdm = chartDataModel(chart_width=934, chart_height=350,
                    chart_data=chart_data, chart_type=True, type='line', seriesName='Edge traffic by service', yAxisName=dataUnit.get('avgUnit'), 
                    xAxisName=xAxisName,
                    numDataTransDivision=dataTransUnit.get('numDivision'), yAxisDataTransName=dataTransUnit.get('avgUnit'),
                    numDivision=dataUnit.get('numDivision'), defaultUnit=defaultUnit, unitPrefix=dataUnit.get('unitPrefix'),
                    table_data={'header':['URL', 'Data Transferred(KB)'], 'data':stats.get('tableData') },
                    real_date_to=real_date_to)

            ret_json = {'factor':'success', 'items' : cdm.getChartDataDictionary()}
        return ret_json
    except Exception as e:
        error_cdm = chartDataModel()
        ret_json = {'factor':'failure', 'msg':_(u'Something is technically wrong. Please try again.'), 'items' : error_cdm.getChartDataDictionary()}
    return ret_json



def cs_ajax_chart_total_traffic(request):
    try :
        # MB : The customer who is using Mbps billing method
        # GB : The customer who is using Gbyte billing method
        tz_cd = request.DATA.get('tz_cd')
        xAxisName, tz_offset = get_timezone_info(tz_cd)
        time_span = request.DATA.get('time_span')
        report_type = request.DATA.get('report_type')

        stat_list = getStatList(request.DATA.get('filter_cust', None), request.DATA.get('item_id', None), request.DATA.get('customer_stat_unit'))

        is_data_type = get_data_type(stat_list.get('stat_list'), stat_list.get('is_contract_stat'))

        date_from = datetime.strptime(request.DATA.get('date_from', None), '%Y-%m-%d')
        date_to = datetime.strptime(request.DATA.get('date_to', None), '%Y-%m-%d')

        is_95per = False
        is_avg_daily = False

        if "MB" == report_type and is_data_type.get('is_95per') :
            is_95per = True
        if "MB" == report_type and is_data_type.get('is_avg_daily') and not (date_to - date_from).days == 0:
            is_avg_daily = True

        material_group_cd = None
        is_shield = False
        
        stats = get_data_total_traffic(stat_list.get('stat_list'), date_from, date_to, time_span,
                                       tz_offset, material_group_code=material_group_cd , is_shield=is_shield, is_contract_stat=stat_list.get('is_contract_stat'))

        if is_95per :
            min_stats = get_data_total_traffic(stat_list.get('stat_list'), date_from, date_to, "5",
                                           tz_offset, material_group_code=material_group_cd , is_shield=is_shield, is_contract_stat=stat_list.get('is_contract_stat'))
            data_95 = get95Data(min_stats)

        if is_avg_daily :
            day_stats = get_data_total_traffic(stat_list.get('stat_list'), date_from, date_to, "daily",
                                           tz_offset, material_group_code=material_group_cd , is_shield=is_shield, is_contract_stat=stat_list.get('is_contract_stat'))

        real_date_to = getRealDateTo(date_to, tz_offset)

        chart_data = OrderedDict({})

        if len(stats['total_data'].get('value_list')) == 0 :
            empty_cdm = chartDataModel()
            ret_json = {'factor':'failure', 'msg':_(u'No Data.'), 'items' : empty_cdm.getChartDataDictionary()}
        else :
            sumtransffered = 0
            summury_data = OrderedDict({})

            dataKey = 'value_list'
            if "GB" == report_type :
                dataKey = 'transferred_list'
            for q in stats.keys():
                if q != 'total_data' and q != 'total_trans_data':
                    if stats[q][dataKey].__len__() <= 0 :
                        pass
                    else :
                        data_title = 'Edge'
                        stats[q]['avgDayValue'] = 0
                        if is_avg_daily :
                            stats[q]['avgDayValue'] = day_stats[q]['avgValue']

                        stats[q]['data95Value'] = 0
                        if is_95per :
                            stats[q]['data95Value'] = data_95[q + '_95_data']
                        chart_data[data_title] = stats[q][dataKey]

                        summury_data[data_title] = {'avgValue': stats[q]['avgValue'], 'avgDayValue':stats[q]['avgDayValue'], 'data95Value': stats[q]['data95Value'],
                                                    'peak':stats[q]['maxVal'], 'totalTransffered':stats[q]['totalTransffered']  }

                        sumtransffered += stats[q]['totalTransffered']

            defaultUnit = "bps"

            if "MB" == report_type :
                dataUnit = getDataUnit(stats['total_data']['avgValue'], defaultUnit)
            else :
                defaultUnit = "byte"
                dataUnit = getDataUnit(stats['total_trans_data']['avgValue'], defaultUnit)

            dataTransUnit = getDataUnit(sumtransffered / len(summury_data), "byte")
            
            cdm = chartDataModel(chart_width=934, chart_height=350,
                        chart_data=chart_data, chart_type=True, type='area', seriesName='total', yAxisName=dataUnit.get('avgUnit'), 
                        xAxisName=xAxisName,
                        numDataTransDivision=dataTransUnit.get('numDivision'), yAxisDataTransName=dataTransUnit.get('avgUnit'),
                        numDivision=dataUnit.get('numDivision'), defaultUnit=defaultUnit, unitPrefix=dataUnit.get('unitPrefix'),
                        summury_data=summury_data, is_95per=is_95per, is_avg_daily=is_avg_daily, real_date_to=real_date_to, report_type=report_type)

            ret_json = {'factor':'success', 'items' : cdm.getChartDataDictionary()}
        return ret_json
    except Exception as e:
        error_cdm = chartDataModel()
        ret_json = {'factor':'failure', 'msg':_(u'Something is technically wrong. Please try again.'), 'items' : error_cdm.getChartDataDictionary()}
    return ret_json


def cs_ajax_chart_origin_hits(request):

    try :
        tz_cd = request.DATA.get('tz_cd')
        xAxisName, tz_offset = get_timezone_info(tz_cd)
        time_span = request.DATA.get('time_span')

        stat_list = getStatList(request.DATA.get('filter_cust', None), request.DATA.get('item_id', None), request.DATA.get('customer_stat_unit'))

        date_from = datetime.strptime(request.DATA.get('date_from', None), '%Y-%m-%d')
        date_to = datetime.strptime(request.DATA.get('date_to', None), '%Y-%m-%d')

        stats = get_data_origin_hits(stat_list.get('stat_list'), date_from, date_to, time_span, tz_offset, is_contract_stat=stat_list.get('is_contract_stat'))

        real_date_to = getRealDateTo(date_to, tz_offset)
        if len(stats['origin_hits'].get('value_list')) == 0 :   
            empty_cdm = chartDataModel()
            ret_json = {'factor':'failure', 'msg':_(u'No Data.'), 'items' : empty_cdm.getChartDataDictionary()}
        else :
            dataUnit = getDataUnit(stats['origin_hits']['avgValue'], "Hits", doNotConvert=True)
            cdm = chartDataModel(chart_width=460, chart_height=350,
            chart_data=stats['origin_hits'].get('value_list'), chart_type=True, seriesName='Origin Hits', yAxisName=dataUnit.get('avgUnit'), xAxisName=xAxisName,
            numDivision=dataUnit.get('numDivision'), defaultUnit="hits", summury_data={'totValue': stats['origin_hits']['totValue'], 'peak':stats['origin_hits']['maxVal']}, real_date_to=real_date_to)
            ret_json = {'factor':'success', 'items' : cdm.getChartDataDictionary()}
    except Exception as e:
        error_cdm = chartDataModel()
        ret_json = {'factor':'failure', 'msg':_(u'Something is technically wrong. Please try again.'), 'items' : error_cdm.getChartDataDictionary()}
    return ret_json


class GetChartTotalTraffic(SpectrumGenericAPIView):
    def post(self, request, *args, **kwargs):
        ret = cs_ajax_chart_total_traffic(request)
        return Response(ret)

class GetChartTransferByService(SpectrumGenericAPIView):
    def post(self, request, *args, **kwargs):
        ret = cs_ajax_chart_transfer_by_service(request)
        return Response(ret)
    

class GetChartTrafficByService(SpectrumGenericAPIView):
    def post(self, request, *args, **kwargs):
        ret = cs_ajax_chart_traffic_by_service(request)
        return Response(ret)

class GetChartOriginHits(SpectrumGenericAPIView):
    def post(self, request, *args, **kwargs):
        ret = cs_ajax_chart_origin_hits(request)
        return Response(ret)




