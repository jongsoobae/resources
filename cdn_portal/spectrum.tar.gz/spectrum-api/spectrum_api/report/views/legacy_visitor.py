# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Rest API
"""
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from rest_framework.response import Response
from datetime import datetime
from django.db import connections
from datetime import timedelta
from spectrum_api.report.utils.byte_conv_utils import generate_traffic, get_total, getMaxMin, get_avg
from spectrum_api.report.views import getStatList
from spectrum_api.report.utils.common import statListToString, dictfetchall, getDataUnit
from spectrum_api.report.utils.common import get_timezone_info
from django.utils.translation import ugettext as _

from spectrum_api.report.models.traffic import getRealDateTo
from spectrum_api.report.models.chartDataModel import chartDataModel
from spectrum_api.report.utils.byte_conv_utils import get_percent_val_rounddown, data_to_rounddown
from spectrum_api.report.models.traffic import seperate_5min_data

from spectrum_api.report.models import TbState, TbCountry, TbCity

# AURORAUI-3191 - Location Search API
from spectrum_api.shared_components.utils.visitor_location_report import get_location_api_response

def get_type6_data_response_code(stat_ids, from_date, to_date, time_span, tz_offset, return_time_type='utc', is_contract_stat=False, is_detail=False):
    stat_condition = ''
    if stat_ids.__len__() > 0 :
        for i in range(stat_ids.__len__()):
            stat_condition = stat_condition + stat_ids[i].__str__()
            if(i != stat_ids.__len__() - 1) :
                stat_condition = stat_condition + ','

    if time_span == "daily" :
        tz_offset = 0
        from_date = from_date
        to_date = to_date + timedelta(days=1)
    else :
        from_date = from_date - timedelta(hours=tz_offset)
        to_date = to_date + timedelta(days=1) - timedelta(hours=tz_offset)

    table_name = 'tb_visitors_response_code'
    idColumnName = "stat_id"
    if is_contract_stat :
        idColumnName = "item_id"

    if time_span == "hourly" :
        str_date_columns = "stat_datehour"
        str_group_field = "stat_datehour"
        if is_contract_stat :
            table_name = "tb_visitors_response_code_item"
        else :
            table_name = "tb_visitors_response_code"
    elif time_span == "daily" :
        str_date_columns = """STR_TO_DATE(Substring(CAST(stat_datehour AS CHAR(10)),1,8),"%s") stat_date """ % ('%%Y%%m%%d')
        str_group_field = "stat_date "
        if is_contract_stat :
            table_name = "tb_visitors_response_code_item"
        else :
            table_name = "tb_visitors_response_code"
    else :
        raise Exception("Invalid Time Span..")

    if is_detail:
        str_columns = """
                sum(total_hits) as val,
                response_code code_group
                """
        str_group_and_order = """
                GROUP BY code_group
                ORDER BY code_group
                """
    else:
        str_columns = """
                %s,
                sum(total_hits) as val,
                (
                    case when response_code>=200 and response_code<300 then 'Success'
                    when response_code=408 then 'Success'
                    when response_code=401 then 'Permission'
                    when response_code=404 then 'Not-Found'
                    when response_code>=500 and response_code<600 then 'Server Error'
                    else 'other'
                    end
                ) as code_group
                """%str_date_columns
        str_group_and_order = """
                GROUP BY %s, code_group
                ORDER BY %s, code_group
                """%(str_group_field,str_group_field)

    if time_span == "hourly" :
        sql = """
                SELECT
                %s
                FROM %s
                WHERE %s in (%s)
                AND stat_datehour >= %s and stat_datehour < %s
                %s
               """%(str_columns,
                    table_name,
                    idColumnName,
                    stat_condition,
                    from_date.strftime("%Y%m%d%H"),
                    to_date.strftime("%Y%m%d%H"),
                    str_group_and_order)

    elif time_span == "daily" :
        sql = """
                SELECT
                %s
                FROM %s
                WHERE %s in (%s)
                AND stat_datehour >= %s and stat_datehour < %s
                %s
               """%(str_columns,
                    table_name,
                    idColumnName,
                    stat_condition,
                    from_date.strftime("%Y%m%d%H"),
                    to_date.strftime("%Y%m%d%H"),
                    str_group_and_order)

    else :
        raise Exception("Invalid Time Span..")

    try:
        cursor = connections['legacy_stat'].cursor()
        cursor.execute(sql)
        rslist = cursor.fetchall()
    finally:
        cursor.close()
        del cursor

    code_list = ['Success', 'Permission', 'Not-Found', 'Server Error', 'other']

    if rslist.__len__() <= 0 :
        return {}

    retlist = {}
    if is_detail:
        idx = 0
        for rs in rslist:
            idx = idx + 1
            retlist[rs[1]] = {"totValue":float(rs[0]),"order":idx,"value_list":[]}

        return retlist

    for key in code_list:
        templist = []
        for rs in rslist:
            if time_span == "5" and rs[13] == key :
                seperate_5min_data(templist, rs)
            elif time_span == "hourly" and rs[2] == key:
                templist.append([datetime.strptime(str(rs[0]),"%Y%m%d%H"), rs[1], rs[2]])
            elif rs[2] == key :
                templist.append([datetime.combine(rs[0], datetime.min.time()), rs[1], rs[2]])

        retlist[key] = generate_traffic(time_span, from_date, to_date, templist, return_time_type, tz_offset)

        for key in retlist.keys():
            if key == 'Success':
                retlist['OK hit 2XX'] = retlist.pop('Success')
                retlist['OK hit 2XX']['order'] = 1
            if key == 'Permission':
                retlist['Permission 401'] = retlist.pop('Permission')
                retlist['Permission 401']['order'] = 2
            if key == 'Not-Found':
                retlist['Not-Found 404'] = retlist.pop('Not-Found')
                retlist['Not-Found 404']['order'] = 3
            if key == 'Server Error':
                retlist['Server Error 5xx'] = retlist.pop('Server Error')
                retlist['Server Error 5xx']['order'] = 4
            if key == 'other':
                retlist['Others'] = retlist.pop('other')
                retlist['Others']['order'] = 5

    return retlist

def get_data_edge_response_code(stat_ids, from_date, to_date, time_span, tz_offset, return_time_type='utc', return_type='chart', is_contract_stat=False, is_detail=False):
    edge_response_cd = get_type6_data_response_code(stat_ids=stat_ids, from_date=from_date, to_date=to_date, time_span=time_span,
                                                    tz_offset=tz_offset, return_time_type=return_time_type,
                                                    is_contract_stat=is_contract_stat, is_detail=is_detail)
    if return_type == 'chart':
        result = edge_response_cd
    elif return_type == 'excel' :
        dataHeader = []
        data = []
        sorted_keys = sorted(edge_response_cd.keys(), key=lambda y : (edge_response_cd[y]['order']))
        for key in sorted_keys:
            if edge_response_cd[key].get('value_list', []) != []:
                dataHeader.append(key)
                data.append(edge_response_cd[key]['value_list'])
        result = {'dataHeader' : dataHeader, 'data' : data}
    elif return_type == 'api':
        result = []

        tempKey = ''
        sorted_keys = sorted(edge_response_cd.keys(), key=lambda y : (edge_response_cd[y]['order']))
        for key in sorted_keys:
            if edge_response_cd[key].get('value_list', []) != []:
                tempKey = key
                break

        if tempKey == '' :
            return result

        mapper = {'OK hit 2XX':'successHits',
                  'Permission 401':'permissionHits', 'Not-Found 404':'notFoundHits', 'Server Error 5xx':'serverErrorHits', 'Others':'etcHits'}

        for idx, val in enumerate(edge_response_cd.get(tempKey).get('value_list')):
            tempDict = {}
            tempDict['dateTime'] = val[0]

            for key in sorted_keys:
                if edge_response_cd[key].get('value_list', []) != []:
                    tempDict[mapper.get(key, '')] = edge_response_cd[key].get('value_list')[idx][1]
                else :
                    tempDict[key] = 0

            result.append(tempDict)

    return result


def get_data_unique_visitors_per_hour(stat_list, date_from, date_to, time_span="hourly", tz_offset="0", return_type="chart", is_contract_stat=False):
    if time_span == "daily" :
        tz_offset = 0
        date_from = date_from
        date_to = date_to + timedelta(days=1)
    else :
        date_from = date_from - timedelta(hours=tz_offset)
        date_to = date_to + timedelta(days=1) - timedelta(hours=tz_offset)

    stat_condition = statListToString(stat_list)

    idColumnName = "stat_id"

    if is_contract_stat :
        idColumnName = "item_id"

    table_name = "tb_visitors_unique_visitors"

    if time_span == "hourly" :
        if is_contract_stat :
            table_name = "tb_visitors_unique_visitors_item"
        else :
            table_name = "tb_visitors_unique_visitors"
    elif time_span == "daily" :
        if is_contract_stat :
            table_name = "tb_visitors_unique_visitors_days_item"
        else :
            table_name = "tb_visitors_unique_visitors_days"
    else :
        raise Exception("Invalid Time Span..")

    if time_span == "hourly" :
        sql = """
            SELECT stat_datehour as stat_time, 
            sum(visitors) as visitor__sum
            from legacy_stat. % s
            where %s in (%s) 
            AND stat_datehour >= %s and stat_datehour < %s
            group by stat_datehour
            order by stat_datehour""" % (table_name,
                     idColumnName,
                     stat_condition,
                     date_from.strftime("%Y%m%d%H"),
                     date_to.strftime("%Y%m%d%H"))
    elif time_span == "daily" :
        sql = """
            SELECT stat_date as stat_time, 
            sum(visitors) as visitor__sum
            from legacy_stat.%s
            where %s in (%s) 
            AND stat_date >= '%s' and stat_date < '%s'
            group by stat_time
            order by stat_time""" % (table_name,
                     idColumnName,
                     stat_condition,
                     date_from,
                     date_to)
    else :
        raise Exception("Invalid Time Span..")

    try:
        cursor = connections['legacy_stat'].cursor()
        cursor.execute(sql)
        stats = dictfetchall(cursor)
    finally:
        cursor.close()
        del cursor

    if "chart" == return_type :
        rs = []
        result = {'value_list' : [], 'avgValue' : 0}

        if stats:
            for v in stats:
                if time_span == "hourly" :
                    rs.append([datetime.strptime(str(v['stat_time']),"%Y%m%d%H"), long(v["visitor__sum"])])
                else:
                    rs.append([datetime.combine(v['stat_time'], datetime.min.time()), long(v["visitor__sum"])])
            result = generate_traffic(time_span, date_from, date_to, rs, "utc", tz_offset)
        return result
    elif "excel" == return_type :
        data = []
        dataHeader = []
        result = {'value_list' : [], 'avgValue' : 0}
        rs = []

        dataHeader.append(['dateTime', 'Visitors'])

        if stats:
            for v in stats:
                if time_span == "hourly" :
                    rs.append([datetime.strptime(str(v['stat_time']),"%Y%m%d%H"), long(v["visitor__sum"])])
                else:
                    rs.append([datetime.strptime(str(v['stat_time']),"%Y%m%d"), long(v["visitor__sum"])])

            result = generate_traffic(time_span, date_from, date_to, rs, "", tz_offset)

        return {'header':dataHeader, 'data':result.get('value_list')}
    elif "api" == return_type :
        data = []

        if stats == None or len(stats) == 0 :
            return data

        rs = []
        if stats:
            for v in stats:
                if time_span == "hourly" :
                    rs.append([datetime.strptime(str(v['stat_time']),"%Y%m%d%H"), long(v["visitor__sum"])])
                else:
                    rs.append([datetime.strptime(str(v['stat_time']),"%Y%m%d"), long(v["visitor__sum"])])

            result = generate_traffic(time_span, date_from, date_to, rs, "str", tz_offset)

        for r in result.get('value_list'):
            data.append({'dateTime':r[0], 'uniqueVisitors':r[1]})

        return data
    else :
        raise Exception("Invalid Return Type..")


def visitor_ajax_uniqueVisitors(request):

    try :
        tz_cd = request.DATA.get('tz_cd')
        xAxisName, tz_offset = get_timezone_info(tz_cd)
        time_period = request.DATA.get('time_span')
        
        date_from = datetime.strptime(request.DATA.get('date_from', None), '%Y-%m-%d')
        date_to = datetime.strptime(request.DATA.get('date_to', None), '%Y-%m-%d')

        stat_list = getStatList(request.DATA.get('filter_cust', None), request.DATA.get('item_id', None), request.DATA.get('customer_stat_unit'))

        if time_period == "5" or time_period == "hourly" :
            time_period = "hourly"

        stats = get_data_unique_visitors_per_hour(stat_list.get('stat_list'), date_from, date_to, time_period, tz_offset, "chart", is_contract_stat=stat_list.get('is_contract_stat'))

        if len(stats.get('value_list')) == 0 :
            chartData = {}
            ret_json = {'factor':'failure', 'msg':_(u'No Data.'), 'items' : chartData}
        else :
            totalVisitor = get_total(stats.get('value_list'))
            peakVisitor = getMaxMin(stats.get('value_list')).get('max')
            avgVisitor = get_avg(stats.get('value_list'))

            dataUnit = getDataUnit(stats.get('avgValue'), "Visitors", doNotConvert=True)

            chartData = {'chart_width' : 934,
                              'chart_height' : 350,
                              'chart_data' : stats.get('value_list'),
                              'chart_type' : {
                                              'type' : 'column',
                                              'seriesName' : 'Unique Visitors',
                                              'yAxisName' : dataUnit.get('avgUnit'),
                                              'xAxisName' : xAxisName,
                                              'totalVisitor' : totalVisitor,
                                              'peakVisitor' : peakVisitor,
                                              'avgVisitor' : avgVisitor,
                                              'numDivision' : dataUnit.get('numDivision'),
                                              'defaultUnit' : "visitors",
                                              }
                              }

            ret_json = {'factor':'success', 'items' : chartData}
    except Exception as e:
        chartData = {}

        ret_json = {'factor':'failure', 'msg':_(u'Something is technically wrong. Please try again.'), 'items' : chartData}

    return ret_json


def cs_ajax_chart_edge_response_code(request):
    try :
        tz_cd = request.DATA.get('tz_cd')
        xAxisName, tz_offset = get_timezone_info(tz_cd)
        time_span = request.DATA.get('time_span')
        is_detail = True if request.DATA.get('is_detail', "false") == "true" else False
        stat_list = getStatList(request.DATA.get('filter_cust', None), request.DATA.get('item_id', None), request.DATA.get('customer_stat_unit'))

        date_from = datetime.strptime(request.DATA.get('date_from', None), '%Y-%m-%d')
        date_to = datetime.strptime(request.DATA.get('date_to', None), '%Y-%m-%d')

        stats = get_data_edge_response_code(stat_list.get('stat_list'), date_from, date_to, time_span, tz_offset, is_contract_stat=stat_list.get('is_contract_stat'), is_detail=is_detail)
        real_date_to = getRealDateTo(date_to, tz_offset)

        table_data = {}
        if stats.__len__() == 0:
            empty_cdm = chartDataModel()
            ret_json = {'factor':'failure', 'msg':_(u'No Data.'), 'items' : empty_cdm.getChartDataDictionary()}
        else :
            chart_data = []
            dataUnit = getDataUnit(100000, "Hits", doNotConvert=True)

            for key in stats.keys() :
                table_data[key] = stats[key]['totValue']
            sum_hit = sum(table_data.values())
            td = []
            sorted_keys = sorted(stats.keys(), key=lambda y : (stats[y]['order']))

            totalHits = 0
            successHits = 0
            for key in sorted_keys:
                chart_data.append({ key : stats[key]['value_list']})
                td.append({'name':key, 'hits':table_data[key], 'ratio': str(get_percent_val_rounddown(table_data[key], sum_hit, 2))})
                totalHits += table_data[key]
                if key == 'OK hit 2XX':
                    successHits += table_data[key]
            if totalHits > 0 :
                td.append({'name':"Total", 'hits':totalHits, 'ratio': "100.00"})

            cdm = chartDataModel(chart_width=460, chart_height=350, successHits=successHits, totalHits=totalHits,
            chart_data=chart_data, chart_type=True, type='area', seriesName='Edge response code', yAxisName=dataUnit.get('avgUnit'), xAxisName=xAxisName,
            numDivision=dataUnit.get('numDivision'), defaultUnit="hits", table_data={'header':['Code', 'Hits', '% Hits'], 'data':td }, real_date_to=real_date_to)
            ret_json = {'factor':'success', 'items' : cdm.getChartDataDictionary()}
            
    except Exception as e:
        error_cdm = chartDataModel()
        ret_json = {'factor':'failure', 'msg':_(u'Something is technically wrong. Please try again.'), 'items' : error_cdm.getChartDataDictionary()}

    return ret_json

def get_data_location_country(stat_list, date_from, date_to, time_span="daily", tz_offset="0", return_type="chart", material_group_code=None, is_contract_stat=False):
    date_to = date_to + timedelta(days=1)

    # get location stat data from location search api
    stats = get_location_api_response(
        stat_list=stat_list,
        from_date=date_from, to_date=date_to,
        is_contract_stat=is_contract_stat)

    # set country, name pair dictionary
    country_val_list = [item.country for item in stats]

    country_t = TbCountry.objects.using('one_stat').filter(ihms_country_cd__in=country_val_list)
    country_dic = {}
    for q in country_t:
        country_dic[q.ihms_country_cd] = q.country_name_en.strip()

    others_cnt = 0
    others_TotalHits = 0
    others_OKHits = 0
    others_ErrorHits = 0
    others_UniqueVisitors = 0
    others_DataTransferred = 0
    others_countries = ['OTHERS','ETC']

    if "chart" == return_type :
        data = []
        dataTotal = []

        sumUniqueVisitors = 0
        sumDataTransferred = 0
        sumOKHits = 0
        sumHits = 0
        sumPv = 0

        if stats :
            for s in stats:
                tmpTotalHits = (long(s.error_hits) + long(s.success_hit))

                sumUniqueVisitors += long(s.visitor)
                sumDataTransferred += long(s.transfer)
                sumOKHits += long(s.success_hit)
                sumHits += tmpTotalHits
                if s.country.upper() in others_countries:
                    others_cnt += 1
                    others_TotalHits += tmpTotalHits
                    others_OKHits += long(s.success_hit)
                    others_ErrorHits += long(s.error_hits)
                    others_UniqueVisitors += long(s.visitor)
                    others_DataTransferred += long(s.transfer)
                else:
                    data.append({'country_cd' : s.country,
                         'Location' : country_dic.get(s.country, s.country),
                         'TotalHits' : tmpTotalHits,
                         'OKHits' : long(s.success_hit),
                         'ErrorHits' : long(s.error_hits),
                         'SuccessRate' : str(get_percent_val_rounddown(long(s.success_hit), tmpTotalHits, 2)),
                         'UniqueVisitors' : long(s.visitor),
                         'DataTransferred' : long(s.transfer),
                         })

            if others_cnt > 0:
                data.append({'country_cd' : 'Others',
                     'Location' : 'Others',
                     'TotalHits' : others_TotalHits,
                     'OKHits' : others_OKHits,
                     'ErrorHits' : others_ErrorHits,
                     'SuccessRate' : str(get_percent_val_rounddown(others_OKHits, others_TotalHits, 2)),
                     'UniqueVisitors' : others_UniqueVisitors,
                     'DataTransferred' : others_DataTransferred,
                     })

            dataTotal.append(["Total", sumHits, sumOKHits, sumHits - sumOKHits, str(get_percent_val_rounddown(sumOKHits, sumHits, 2)), sumUniqueVisitors, sumDataTransferred])
        return [data, dataTotal]

    elif "excel" == return_type :
        data = []
        dataHeader = []
        result = {}

        dataHeader.append(['Location', 'Total Hits', 'OK Hits', 'Error Hits', 'SuccessRate', 'UniqueVisitors', 'DataTransferred(byte)'])

        for s in stats:
            tmpTotalHits = (long(s.error_hits) + long(s.success_hit))
            data.append([country_dic.get(s.country, s.country),
                         tmpTotalHits,
                         long(s.success_hit),
                         long(s.error_hits),
                         str(get_percent_val_rounddown(long(s.success_hit), tmpTotalHits, 2)),
                         long(s.visitor),
                         long(s.transfer),
                         ])

        result = {'header':dataHeader, 'data':data}

        return result
    elif "api" == return_type :
        data = []

        seq = 0

        if stats == None or len(stats) == 0 :
            return data

        for s in stats:
            seq = seq + 1
            tmpTotalHits = (long(s.error_hits) + long(s.success_hit))
            data.append({'rank' : seq,
                         'location' : country_dic.get(s.country, s.country),
                         'totalHits' : tmpTotalHits,
                         'succHits' : long(s.success_hit),
                         'failHits' : long(s.error_hits),
                         'uniqueVisitors' : long(s.visitor),
                         'dataTransferred' : long(s.transfer),
                         })

        return data
    else :
        raise Exception("Invalid Return Type..")

def get_data_location_state(stat_list, date_from, date_to, time_span="daily", tz_offset="0", return_type="chart", country="US", material_group_code=None, is_contract_stat=False):
    date_to = date_to + timedelta(days=1)

    # get location stat data from location search api
    stats = get_location_api_response(
        stat_list=stat_list, country=country,
        from_date=date_from, to_date=date_to,
        is_contract_stat=is_contract_stat)

    # set state code, name pair dictionary
    state_val_list = [dic.country for dic in stats]

    state_t = TbState.objects.using('one_stat').filter(ihms_country_cd=country, ihms_state_id__in=state_val_list)
    state_dic = {}
    state_cd_dic = {}
    for q in state_t:
        state_dic[q.ihms_state_id] = q.state_name_en.strip()
        state_cd_dic[q.ihms_state_id] = country + "-" + q.ihms_state_cd.strip()

    others_cnt = 0
    others_TotalHits = 0
    others_OKHits = 0
    others_ErrorHits = 0
    others_UniqueVisitors = 0
    others_DataTransferred = 0
    others_states = ['OTHERS','121017000','48035000']

    if "chart" == return_type :
        data = []
        dataTotal = []

        sumUniqueVisitors = 0
        sumDataTransferred = 0
        sumOKHits = 0
        sumHits = 0

        if stats :
            for s in stats:
                tmpTotalHits = (long(s.error_hits) + long(s.success_hit))

                sumUniqueVisitors += long(s.visitor)
                sumDataTransferred += long(s.transfer)
                sumOKHits += long(s.success_hit)
                sumHits += tmpTotalHits

                if s.country.upper() in others_states:
                    others_cnt += 1
                    others_TotalHits += tmpTotalHits
                    others_OKHits += long(s.success_hit)
                    others_ErrorHits += long(s.error_hits)
                    others_UniqueVisitors += long(s.visitor)
                    others_DataTransferred += long(s.transfer)
                else:
                    data.append({'state_cd' : state_cd_dic.get(s.country, s.country),
                         'Location' : state_dic.get(s.country, s.country),
                         'TotalHits' : tmpTotalHits,
                         'OKHits' : long(s.success_hit),
                         'ErrorHits' : long(s.error_hits),
                         'SuccessRate' : str(get_percent_val_rounddown(long(s.success_hit), tmpTotalHits, 2)),
                         'UniqueVisitors' : long(s.visitor),
                         'DataTransferred' : long(s.transfer),
                         })

            if others_cnt > 0:
                data.append({'state_cd' : 'Others',
                     'Location' : 'Others',
                     'TotalHits' : others_TotalHits,
                     'OKHits' : others_OKHits,
                     'ErrorHits' : others_ErrorHits,
                     'SuccessRate' : str(get_percent_val_rounddown(others_OKHits, others_TotalHits, 2)),
                     'UniqueVisitors' : others_UniqueVisitors,
                     'DataTransferred' : others_DataTransferred,
                     })

            dataTotal.append(["Total", sumHits, sumOKHits, sumHits - sumOKHits, str(get_percent_val_rounddown(sumOKHits, sumHits, 2)), sumUniqueVisitors, sumDataTransferred])

        return [data, dataTotal]

    else :
        raise Exception("Invalid Return Type..")


def get_data_location_city(stat_list, date_from, date_to, time_span="daily", tz_offset="0", return_type="chart", country="", state="", material_group_code=None, is_contract_stat=False):
    date_to = date_to + timedelta(days=1)

    # get location stat data from location search api
    stats = get_location_api_response(
        stat_list=stat_list, country=country, state=state,
        from_date=date_from, to_date=date_to,
        is_contract_stat=is_contract_stat)

    # set city id, name pair dictionary
    city_val_list = [dic.country for dic in stats]

    if state == "" or state == None:
        city_t = TbCity.objects.using('one_stat').filter(ihms_country_cd=country, ihms_city_id__in=city_val_list)
    else :
        city_t = TbCity.objects.using('one_stat').filter(ihms_state_id=state, ihms_city_id__in=city_val_list)

    city_dic = {}
    for q in city_t:
        city_dic[q.ihms_city_id] = q.city_name_en

    others_cnt = 0
    others_TotalHits = 0
    others_OKHits = 0
    others_ErrorHits = 0
    others_UniqueVisitors = 0
    others_DataTransferred = 0
    others_cities = ['OTHERS','48036001']

    if "chart" == return_type:
        data = []
        dataTotal = []

        sumUniqueVisitors = 0
        sumDataTransferred = 0
        sumOKHits = 0
        sumHits = 0

        if stats :
            for s in stats:
                tmpTotalHits = (long(s.error_hits) + long(s.success_hit))

                sumUniqueVisitors += long(s.visitor)
                sumDataTransferred += long(s.transfer)
                sumOKHits += long(s.success_hit)
                sumHits += tmpTotalHits

                if s.country.upper() in others_cities:
                    others_cnt += 1
                    others_TotalHits += tmpTotalHits
                    others_OKHits += long(s.success_hit)
                    others_ErrorHits += long(s.error_hits)
                    others_UniqueVisitors += long(s.visitor)
                    others_DataTransferred += long(s.transfer)
                else:
                    data.append({'Location' : city_dic.get(s.country, s.country),
                         'TotalHits' : tmpTotalHits,
                         'OKHits' : long(s.success_hit),
                         'ErrorHits' : long(s.error_hits),
                         'SuccessRate' : str(get_percent_val_rounddown(long(s.success_hit), tmpTotalHits, 2)),
                         'UniqueVisitors' : long(s.visitor),
                         'DataTransferred' : long(s.transfer),
                         })

            if others_cnt > 0:
                data.append({'Location' : 'Others',
                     'TotalHits' : others_TotalHits,
                     'OKHits' : others_OKHits,
                     'ErrorHits' : others_ErrorHits,
                     'SuccessRate' : str(get_percent_val_rounddown(others_OKHits, others_TotalHits, 2)),
                     'UniqueVisitors' : others_UniqueVisitors,
                     'DataTransferred' : others_DataTransferred,
                     })

            dataTotal.append(["Total", sumHits, sumOKHits, sumHits - sumOKHits, str(get_percent_val_rounddown(sumOKHits, sumHits, 2)), sumUniqueVisitors, sumDataTransferred])

        return [data, dataTotal]
    else :
        raise Exception("Invalid Return Type..")


def visitor_ajax_location_country(request):

    try:
        date_from = datetime.strptime(request.DATA.get('date_from', None), '%Y-%m-%d')
        date_to = datetime.strptime(request.DATA.get('date_to', None), '%Y-%m-%d')

        stat_list = getStatList(request.DATA.get('filter_cust', None), request.DATA.get('item_id', None), request.DATA.get('customer_stat_unit'))

        stats = get_data_location_country(stat_list.get('stat_list'), date_from, date_to, return_type="chart", material_group_code=None, is_contract_stat=stat_list.get('is_contract_stat'))

        if len(stats[0]) == 0 :
            chartData = {}
            ret_json = {'factor':'failure', 'msg':_(u'No Data.'), 'items' : chartData}
        else :
            mapData = []

            mapData.append(['Country', 'Total Hits  ', 'Unique Visitors  '])

            for i in stats[0] :
                if i.get('country') == "" :
                    continue
                mapData.append([i.get('country_cd'), i.get('TotalHits'), i.get('UniqueVisitors')])

            chartData = {'chart_width' : 934,
                              'chart_height' : 325,
                              'table_data' : {
                                             'data' : stats[0],
                                             'dataTotal' : stats[1]
                                        },
                              'mapData' : {
                                             'data' : mapData,
                                             'dataMode': 'regions',
                                             'resolution': 'countries',
                                        },
                              }

            ret_json = {'factor':'success', 'items' : chartData, 'is_state':True}
    except Exception as e:
        chartData = {}

        ret_json = {'factor':'failure', 'msg':_(u'Something is technically wrong. Please try again.'), 'items' : chartData, 'is_state':True}

    return ret_json

def visitor_ajax_location_state(request):

    try:
        date_from = datetime.strptime(request.DATA.get('date_from', None), '%Y-%m-%d')
        date_to = datetime.strptime(request.DATA.get('date_to', None), '%Y-%m-%d')

        stat_list = getStatList(request.DATA.get('filter_cust', None), request.DATA.get('item_id', None), request.DATA.get('customer_stat_unit'))
        country = request.DATA.get('country', None)

        stats = get_data_location_state(stat_list.get('stat_list'), date_from, date_to, return_type="chart", country=country, is_contract_stat=stat_list.get('is_contract_stat'))

        if len(stats[0]) == 0 :
            chartData = {}
            ret_json = {'factor':'failure', 'msg':_(u'No Data.'), 'items' : chartData}
        else :
            mapData = []

            mapData.append(['Country', 'Total Hits  ', 'Unique Visitors  '])

            for i in stats[0] :
                if i.get('country') == "" :
                    continue;
                mapData.append([i.get('state_cd'), i.get('TotalHits'), i.get('UniqueVisitors')])

            chartData = {'chart_width' : 934,
                              'chart_height' : 325,
                              'table_data' : {
                                             'data' : stats[0],
                                             'dataTotal' : stats[1]
                                        },
                              'mapData' : {
                                             'data' : mapData,
                                             'dataMode': 'regions',
                                             'resolution': 'provinces',
                                        },
                              }

            ret_json = {'factor':'success', 'items' : chartData, 'is_state':True}
    except Exception as e:
        chartData = {}

        ret_json = {'factor':'failure', 'msg':_(u'Something is technically wrong. Please try again.'), 'items' : chartData, 'is_state':True}

    return ret_json

def visitor_ajax_location_city(request):
    try:
        date_from = datetime.strptime(request.DATA.get('date_from', None), '%Y-%m-%d')
        date_to = datetime.strptime(request.DATA.get('date_to', None), '%Y-%m-%d')

        stat_list = getStatList(request.DATA.get('filter_cust', None), request.DATA.get('item_id', None), request.DATA.get('customer_stat_unit'))

        state = request.DATA.get('state', None)
        country = request.DATA.get('country', None)
        state_id = None
        if state != "" and state != None :
            state_id = TbState.objects.using('one_stat').get(ihms_country_cd=country, ihms_state_cd=state.replace(country + '-', '')).ihms_state_id

        stats = get_data_location_city(stat_list.get('stat_list'), date_from, date_to, return_type="chart", country=country, state=state_id, material_group_code=None, is_contract_stat=stat_list.get('is_contract_stat'))

        if len(stats[0]) == 0 :
            chartData = {}
            ret_json = {'factor':'failure', 'msg':_(u'No Data.'), 'items' : chartData}
        else :
            mapData = []

            mapData.append(['City', 'Total Hits  ', 'Unique Visitors  '])

            for i in stats[0] :
                if i.get('country') == "" :
                    continue;
                mapData.append([i.get('Location'), i.get('TotalHits'), i.get('UniqueVisitors')])

            chartData = {'chart_width' : 934,
                              'chart_height' : 325,
                              'table_data' : {
                                             'data' : stats[0],
                                             'dataTotal' : stats[1]
                                        },
                              'mapData' : {
                                             'data' : mapData,
                                             'dataMode': 'regions',
                                             'resolution': 'metros',
                                        },
                              }

            ret_json = {'factor':'success', 'items' : chartData, 'is_state':True}
    except Exception as e:
        chartData = {}

        ret_json = {'factor':'failure', 'msg':_(u'Something is technically wrong. Please try again.'), 'items' : chartData, 'is_state':True}

    return ret_json



def get_data_browser(stat_list, date_from, date_to, time_span="daily", tz_offset="0", return_type="chart", is_contract_stat=False):
    date_to = date_to + timedelta(days=1)

    stat_condition = statListToString(stat_list)

    idColumnName = "stat_id"

    if is_contract_stat :
        idColumnName = "item_id"

    table_name = "tb_visitors_browser"

    if is_contract_stat :
        table_name = "tb_visitors_browser_item"

    sql = """
        select browser, sum(visitors) as visitor
        from %s
        where % s in (% s) AND stat_date >= '%s' and stat_date < '%s'
        group by browser
        order by visitor desc
        """ % (table_name, idColumnName, stat_condition, date_from, date_to)


    try:
        cursor = connections['legacy_stat'].cursor()
        cursor.execute(sql)
        stats = dictfetchall(cursor)
    finally:
        cursor.close()
        del cursor

    others_cnt = 0
    others_visitors = 0
    others_browser = ['OTHERS','ETC']
    if "chart" == return_type :
        data = []
        tableData = []
        totalVisitor = 0.0

        for s in stats:
            totalVisitor = totalVisitor + long(s["visitor"])

        total_val = 0
        for s in stats:
            if s["browser"].upper() in others_browser:
                others_cnt += 1
                others_visitors += long(s["visitor"])
            else:
                data.append([s["browser"], long(s["visitor"])])
                tableData.append({'Browser' : s["browser"],
                         'Visitors' : long(s["visitor"]),
                         'ratio' : str(get_percent_val_rounddown(long(s["visitor"]), totalVisitor, 2)),
                         })
            total_val += long(s["visitor"])

        if others_cnt > 0:
            data.append(['Others', others_visitors])
            tableData.append({'Browser' : 'Others',
                     'Visitors' : others_visitors,
                     'ratio' : str(get_percent_val_rounddown(others_visitors, totalVisitor, 2)),
                     })

        tableData.append({'Browser' : 'Total',
                     'Visitors' : total_val,
                     'ratio' : 100,
                     })

        result = []
        result.append(data)
        result.append(tableData)
        return result

    elif "excel" == return_type :
        data = []
        dataHeader = []
        result = {}
        totalVisitor = 0.0

        dataHeader.append(['Browser', 'Visitors', 'ratio'])

        for s in stats:
            totalVisitor = totalVisitor + long(s["visitor"])

        for s in stats:
            data.append([s["browser"],
                         long(s["visitor"]),
                         str(get_percent_val_rounddown(long(s["visitor"]), totalVisitor, 2))
                         ])
        result = {'header':dataHeader, 'data':data}

        return result
    elif "api" == return_type :
        data = []
        totalVisitor = 0.0

        for s in stats:
            totalVisitor = totalVisitor + long(s["visitor"])

        for s in stats:
            data.append({'browserName' : s["browser"],
                         'totalHits' : long(s["visitor"]),
                         })
        return data
    else :
        raise Exception("Invalid Return Type..")

def visitor_ajax_browser(request):

    try:
        date_from = datetime.strptime(request.DATA.get('date_from', None), '%Y-%m-%d')
        date_to = datetime.strptime(request.DATA.get('date_to', None), '%Y-%m-%d')

        stat_list = getStatList(request.DATA.get('filter_cust', None), request.DATA.get('item_id', None), request.DATA.get('customer_stat_unit'))

        stats = get_data_browser(stat_list.get('stat_list'), date_from, date_to, return_type="chart", is_contract_stat=stat_list.get('is_contract_stat'))

        chartData = []

        if len(stats[0]) == 0 :
            chartData = {}
            ret_json = {'factor':'failure', 'msg':_(u'No Data.'), 'items' : chartData}
        else :
            chartData = {'chart_width' : 460,
                              'chart_height' : 300,
                              'chart_data' :  stats[0],
                              'table_data' : {'header':['Visitors', '% Visitors','Browser'],
                                             'data' : stats[1]
                                        },
                              'chart_type' : {
                                              'type' : 'pie',
                                              'seriesName' : 'Browser'
                                              }
                              }

            ret_json = {'factor':'success', 'items' : chartData}
    except Exception as e:
        chartData = {}

        ret_json = {'factor':'failure', 'msg':_(u'Something is technically wrong. Please try again.'), 'items' : chartData}

    return ret_json


def get_data_operating_system(stat_list, date_from, date_to, time_span="daily", tz_offset="0", return_type="chart", is_contract_stat=False):
    date_to = date_to + timedelta(days=1)

    stat_condition = statListToString(stat_list)

    idColumnName = "stat_id"

    if is_contract_stat :
        idColumnName = "item_id"

    table_name = "tb_visitors_operation_system"

    if is_contract_stat :
        table_name = "tb_visitors_operation_system_item"
    else :
        table_name = "tb_visitors_operation_system"

    sql = """
        select operation_system as os, sum(visitors) as visitor
        from %s
        where % s in (% s) AND stat_date >= '%s' and stat_date < '%s'
        group by os
        order by visitor desc
        """ % (table_name, idColumnName, stat_condition, date_from, date_to)

    try:
        cursor = connections['legacy_stat'].cursor()
        cursor.execute(sql)
        stats = dictfetchall(cursor)
    finally:
        cursor.close()
        del cursor


    others_cnt = 0
    others_visitors = 0
    others_os = ['OTHERS','ETC']

    if "chart" == return_type :
        data = []
        tableData = []
        totalVisitor = 0.0

        for s in stats:
            totalVisitor = totalVisitor + long(s["visitor"])

        total_val = 0
        for s in stats:
            if s["os"].upper() in others_os:
                others_cnt += 1
                others_visitors += long(s["visitor"])
            else:
                data.append([s["os"], long(s["visitor"])])
                tableData.append({'OS' : s["os"],
                         'Visitors' : long(s["visitor"]),
                         'ratio' : str(get_percent_val_rounddown(long(s["visitor"]), totalVisitor, 2)),
                         })

            total_val += long(s["visitor"])

        if others_cnt > 0:
            data.append(['Others', others_visitors])
            tableData.append({'OS' : 'Others',
                     'Visitors' : others_visitors,
                     'ratio' : str(get_percent_val_rounddown(others_visitors, totalVisitor, 2)),
                     })

        tableData.append({'OS' : 'Total',
                     'Visitors' : total_val,
                     'ratio' : 100,
                     })

        result = []
        result.append(data)
        result.append(tableData)
        return result

    elif "excel" == return_type :
        data = []
        dataHeader = []
        result = {}
        totalVisitor = 0.0

        dataHeader.append(['OS', 'Visitors', 'ratio'])

        for s in stats:
            totalVisitor = totalVisitor + long(s["visitor"])

        for s in stats:
            data.append([s["os"],
                         long(s["visitor"]),
                         str(get_percent_val_rounddown(long(s["visitor"]), totalVisitor, 2))
                         ])
        result = {'header':dataHeader, 'data':data}

        return result
    elif "api" == return_type :
        data = []
        totalVisitor = 0.0

        for s in stats:
            totalVisitor = totalVisitor + long(s["visitor"])

        for s in stats:
            data.append({'osName' : s["os"],
                         'totalHits' : long(s["visitor"]),
                         })
        return data
    else :
        raise Exception("Invalid Return Type..")



def get_data_player(stat_list, date_from, date_to, time_span="daily", tz_offset="0", return_type="chart", is_contract_stat=False):
    date_to = date_to + timedelta(days=1)

    stat_condition = statListToString(stat_list)

    idColumnName = "stat_id"

    if is_contract_stat :
        idColumnName = "item_id"

    table_name = "tb_visitors_player"

    if is_contract_stat :
        table_name = "tb_visitors_player_item"
    else :
        table_name = "tb_visitors_player"

    sql = """
        select player as player, sum(visitors) as visitor
        from %s
        where % s in (% s) AND stat_date >= '%s' and stat_date < '%s'
        group by player
        order by visitor desc
        """ % (table_name, idColumnName, stat_condition, date_from, date_to)

    try:
        cursor = connections['legacy_stat'].cursor()
        cursor.execute(sql)
        stats = dictfetchall(cursor)
    finally:
        cursor.close()
        del cursor

    others_cnt = 0
    others_visitors = 0
    others_player = ['OTHERS','ETC']

    if "chart" == return_type :
        data = []
        tableData = []
        totalVisitor = 0.0

        for s in stats:
            totalVisitor = totalVisitor + long(s["visitor"])

        total_val = 0
        for s in stats:
            if s["player"].upper() in others_player:
                others_cnt += 1
                others_visitors += long(s["visitor"])
            else:
                data.append([s["player"], long(s["visitor"])])
                tableData.append({'Player' : s["player"],
                         'Visitors' : long(s["visitor"]),
                         'ratio' : str(get_percent_val_rounddown(long(s["visitor"]), totalVisitor, 2)),
                         })

            total_val += long(s["visitor"])

        if others_cnt > 0:
            data.append(['Others', others_visitors])
            tableData.append({'Player' : 'Others',
                     'Visitors' : others_visitors,
                     'ratio' : str(get_percent_val_rounddown(others_visitors, totalVisitor, 2)),
                     })

        tableData.append({'Player' : 'Total',
                     'Visitors' : total_val,
                     'ratio' : 100,
                     })

        result = []
        result.append(data)
        result.append(tableData)
        return result

    elif "excel" == return_type :
        data = []
        dataHeader = []
        result = {}
        totalVisitor = 0.0

        dataHeader.append(['Player', 'Visitors', 'ratio'])

        for s in stats:
            totalVisitor = totalVisitor + long(s["visitor"])

        for s in stats:
            data.append([s["os"],
                         long(s["visitor"]),
                         str(get_percent_val_rounddown(long(s["visitor"]), totalVisitor, 2))
                         ])
        result = {'header':dataHeader, 'data':data}

        return result
    elif "api" == return_type :
        data = []
        totalVisitor = 0.0

        for s in stats:
            totalVisitor = totalVisitor + long(s["visitor"])

        for s in stats:
            data.append({'PlayerName' : s["player"],
                         'totalHits' : long(s["visitor"]),
                         })
        return data
    else :
        raise Exception("Invalid Return Type..")


def visitor_ajax_operatingSystem(request):

    try:
        date_from = datetime.strptime(request.DATA.get('date_from', None), '%Y-%m-%d')
        date_to = datetime.strptime(request.DATA.get('date_to', None), '%Y-%m-%d')

        stat_list = getStatList(request.DATA.get('filter_cust', None), request.DATA.get('item_id', None), request.DATA.get('customer_stat_unit'))

        stats = get_data_operating_system(stat_list.get('stat_list'), date_from, date_to, return_type="chart", is_contract_stat=stat_list.get('is_contract_stat'))

        chartData = []

        if len(stats[0]) == 0 :
            chartData = {}
            ret_json = {'factor':'failure', 'msg':_(u'No Data.'), 'items' : chartData}
        else :
            chartData = {'chart_width' : 460,
                              'chart_height' : 300,
                              'chart_data' :  stats[0] ,
                              'table_data' : {'header':['Visitors', 'OS', '% Visitors'],
                                             'data' : stats[1]
                                        },
                              'chart_type' : {
                                              'type' : 'pie',
                                              'seriesName' : 'Operating System'
                                              }
                              }

            ret_json = {'factor':'success', 'items' : chartData}
    except Exception as e:
        chartData = {}

        ret_json = {'factor':'failure', 'msg':_(u'Something is technically wrong. Please try again.'), 'items' : chartData}

    return ret_json


def visitor_ajax_player(request):

    try:
        date_from = datetime.strptime(request.DATA.get('date_from', None), '%Y-%m-%d')
        date_to = datetime.strptime(request.DATA.get('date_to', None), '%Y-%m-%d')

        stat_list = getStatList(request.DATA.get('filter_cust', None), request.DATA.get('item_id', None), request.DATA.get('customer_stat_unit'))

        stats = get_data_player(stat_list.get('stat_list'), date_from, date_to, return_type="chart", is_contract_stat=stat_list.get('is_contract_stat'))

        chartData = []

        if len(stats[0]) == 0 :
            chartData = {}
            ret_json = {'factor':'failure', 'msg':_(u'No Data.'), 'items' : chartData}
        else :
            chartData = {'chart_width' : 460,
                              'chart_height' : 300,
                              'chart_data' :  stats[0] ,
                              'table_data' : {'header':['Player', '% Visitors', 'Visitors'],
                                             'data' : stats[1]
                                        },
                              'chart_type' : {
                                              'type' : 'pie',
                                              'seriesName' : 'Player'
                                              }
                              }

            ret_json = {'factor':'success', 'items' : chartData}
    except Exception as e:
        chartData = {}

        ret_json = {'factor':'failure', 'msg':_(u'Something is technically wrong. Please try again.'), 'items' : chartData}

    return ret_json


def get_data_top_10_isp(stat_list, date_from, date_to, time_span="daily", 
                        tz_offset="0", return_type="chart", is_contract_stat=False):
    date_to = date_to + timedelta(days=1)

    stat_condition = statListToString(stat_list)

    idColumnName = "stat_id"

    if is_contract_stat :
        idColumnName = "item_id"

    table_name = "tb_visitors_isp"

    if is_contract_stat :
        table_name = "tb_visitors_isp_item"
    else :
        table_name = "tb_visitors_isp"

    sql = """
            select isp, sum(unique_visitors) as visitor, sum(total_hits) as hit, 
            sum(data_transferred) as transfer 
            from %s
            where % s in (% s) AND stat_date >= '%s' and stat_date < '%s'
            group by isp
            """ % (table_name, idColumnName, stat_condition, date_from, date_to)

    try:
        cursor = connections['legacy_stat'].cursor()
        cursor.execute(sql)
        stats = dictfetchall(cursor)
    finally:
        cursor.close()
        del cursor

    isp_val_list = ["'%s'"%dic['isp'] for dic in stats]
    isp_dic = {}
    if len(isp_val_list) > 0:
        try:
            cursor = connections['one_stat'].cursor()
            sql = """select ihms_isp_id, isp_name_en from tb_ispcd where ihms_isp_id in (%s)"""%','.join(isp_val_list)
            cursor.execute(sql)
            isp_t = dictfetchall(cursor)
            for q in isp_t:
                isp_dic[q['ihms_isp_id']] = q['isp_name_en']
        finally:
            cursor.close()
            del cursor

    others_cnt = 0
    others_TotalHits = 0
    others_UniqueVisitors = 0
    others_DataTransferred = 0
    others_isps = ["OTHERS", "167"]

    if "chart" == return_type :
        data = []
        chartdata = []
        dataTotal = []

        sumUniqueVisitors = 0
        sumDataTransferred = 0
        sumHits = 0

        for s in stats:
            sumHits = sumHits + long(s["hit"])

        if stats :
            for s in stats:
                sumDataTransferred += long(s["transfer"])
                sumUniqueVisitors += long(s["visitor"])
                if isp_dic.get(s["isp"], s["isp"]).upper() in others_isps:
                    others_cnt += 1
                    others_TotalHits += long(s["hit"])
                    others_UniqueVisitors += long(s["visitor"])
                    others_DataTransferred += long(s["transfer"])
                else :
                    data.append({'ISP' : isp_dic.get(s["isp"], s["isp"]),
                     'TotalHits' : long(s["hit"]),
                     'UniqueVisitors' : long(s["visitor"]),
                     'ratio' : str(get_percent_val_rounddown(long(s["hit"]), sumHits, 2)),
                     'DataTransferred' : long(s["transfer"]),
                     })

            if others_cnt > 0:
                data.append({'ISP' : 'Others',
                     'TotalHits' : others_TotalHits,
                     'UniqueVisitors' : others_UniqueVisitors,
                     'ratio' : str(get_percent_val_rounddown(others_TotalHits, sumHits, 2)),
                     'DataTransferred' : others_DataTransferred,
                     })

            for s in data:
                chartdata.append([s['ISP'],float(s['ratio'])])

            chartdata.sort(lambda a,b: -cmp(a[1], b[1]))
            data.sort(lambda a,b: -cmp(a['TotalHits'], b['TotalHits']))

            data.append({'ISP' : 'Total',
                 'TotalHits' : sumHits,
                 'UniqueVisitors' : sumUniqueVisitors,
                 'ratio' : 100,
                 'DataTransferred' : sumDataTransferred,
                 })

            dataTotal.append(["Total", sumHits, sumUniqueVisitors, str(get_percent_val_rounddown(sumUniqueVisitors, sumUniqueVisitors, 2)), sumDataTransferred])

        #return [data, dataTotal, chartdata]
        return [data, chartdata]

    else :
        raise Exception("Invalid Return Type..")



def visitor_ajax_top10Isp(request):

    try:
        date_from = datetime.strptime(request.DATA.get('date_from', None), '%Y-%m-%d')
        date_to = datetime.strptime(request.DATA.get('date_to', None), '%Y-%m-%d')

        stat_list = getStatList(request.DATA.get('filter_cust', None), request.DATA.get('item_id', None), request.DATA.get('customer_stat_unit'))

        stats = get_data_top_10_isp(stat_list.get('stat_list'), date_from, date_to, return_type="chart", is_contract_stat=stat_list.get('is_contract_stat'))

        chartData = []

        if len(stats[0]) == 0 :
            chartData = {}
            ret_json = {'factor':'failure', 'msg':_(u'No Data.'), 'items' : chartData}
        else :
            chartData = {'chart_width' : 460,
                              'chart_height' : 300,
                              'chart_data' :  stats[1] ,
                              'table_data' : {'header':['Total Hits', 'Visitors', 'ISP', '% Visitors', 'Transferred (MB)'],
                                             'data' : stats[0]
                                        },
                              'chart_type' : {
                                              'type' : 'pie',
                                              'seriesName' : 'ISP'
                                              }
                         }

            ret_json = {'factor':'success', 'items' : chartData}
    except Exception as e:
        chartData = {}

        ret_json = {'factor':'failure', 'msg':_(u'Something is technically wrong. Please try again.'), 'items' : chartData}

    return ret_json

def get_data_average_client_response_bandwidth(stat_list, date_from, date_to, time_span="hourly", tz_offset="0", return_type="chart", is_contract_stat=False):
    if time_span == "daily" :
        tz_offset = 0
        date_from = date_from
        date_to = date_to + timedelta(days=1)
    else :
        date_from = date_from - timedelta(hours=tz_offset)
        date_to = date_to + timedelta(days=1) - timedelta(hours=tz_offset)

    stat_condition = statListToString(stat_list)

    idColumnName = "stat_id"

    if is_contract_stat :
        idColumnName = "item_id"

    table_name = "tb_visitors_avg_client_bandwidth"

    if time_span == "hourly" :
        if is_contract_stat :
            table_name = "tb_visitors_avg_client_bandwidth_item"
        else :
            table_name = "tb_visitors_avg_client_bandwidth"
    elif time_span == "daily" :
        if is_contract_stat :
            table_name = "tb_visitors_avg_client_bandwidth_days_item"
        else :
            table_name = "tb_visitors_avg_client_bandwidth_days"
    else :
        raise Exception("Invalid Time Span..")

    if time_span == "hourly" :
        sql = """
            SELECT stat_datehour as stat_time, 
            sum(speed) as total_speed__sum,
            sum(hits) as total_count__sum
            from legacy_stat. % s
            where %s in (%s) 
            AND stat_datehour >= %s and stat_datehour < %s
            group by stat_time
            order by stat_time""" % (table_name,
                     idColumnName,
                     stat_condition,
                     date_from.strftime("%Y%m%d%H"),
                     date_to.strftime("%Y%m%d%H"))
    elif time_span == "daily" :
        sql = """
            SELECT stat_date as stat_time, 
            sum(speed) as total_speed__sum,
            sum(hits) as total_count__sum
            from legacy_stat.%s
            where %s in (%s) 
            AND stat_date >= '%s' and stat_date < '%s'
            group by stat_time
            order by stat_time""" % (table_name,
                     idColumnName,
                     stat_condition,
                     date_from,
                     date_to)
    else :
        raise Exception("Invalid Time Span..")

    try:
        cursor = connections['legacy_stat'].cursor()
        cursor.execute(sql)
        stats = dictfetchall(cursor)
    finally:
        cursor.close()
        del cursor

    if "chart" == return_type :
        rs = []
        result = {'value_list' : [], 'avgValue' : 0}

        if stats:
            for v in stats:
                if long(v["total_count__sum"]) == 0 :
                    totalCnt = 1
                else :
                    totalCnt = long(v["total_count__sum"])

                if time_span == "hourly" :
                    rs.append([datetime.strptime(str(v['stat_time']),"%Y%m%d%H"), data_to_rounddown(long(v["total_speed__sum"]) * 8.0 / totalCnt, 2)])
                else:
                    rs.append([datetime.combine(v['stat_time'], datetime.min.time()), data_to_rounddown(long(v["total_speed__sum"]) * 8.0 / totalCnt, 2)])

            result = generate_traffic(time_span, date_from, date_to, rs, "utc", tz_offset)
        return result

    elif "excel" == return_type :
        data = []
        dataHeader = []
        result = {'value_list' : [], 'avgValue' : 0}
        rs = []

        dataHeader.append(['dateTime', 'Bandwidth(bps)'])

        if stats:
            for v in stats:
                if long(v["total_count__sum"]) == 0 :
                    totalCnt = 1
                else :
                    totalCnt = long(v["total_count__sum"])

                rs.append([v["stat_time"], data_to_rounddown(long(v["total_speed__sum"]) * 8.0 / totalCnt, 2)])

            result = generate_traffic(time_span, date_from, date_to, rs, "", tz_offset)

        return {'header':dataHeader, 'data':result.get('value_list')}


        return result
    elif "api" == return_type :
        data = []

        if stats == None or len(stats) == 0 :
            return data

        rs = []
        if stats:
            for v in stats:
                if long(v["total_count__sum"]) == 0 :
                    totalCnt = 1
                else :
                    totalCnt = long(v["total_count__sum"])

                rs.append([v["stat_time"], data_to_rounddown(long(v["total_speed__sum"]) * 8.0 / totalCnt, 2)])

            result = generate_traffic(time_span, date_from, date_to, rs, "str", tz_offset)

        for r in result.get('value_list'):
            data.append({'dateTime':r[0], 'avgClientBandwidth':r[1]})

        return data
    else :
        raise Exception("Invalid Return Type..")

def visitor_ajax_responseBandwidth(request):

    try:
        tz_cd = request.DATA.get('tz_cd')
        xAxisName, tz_offset = get_timezone_info(tz_cd)
        time_period = request.DATA.get('time_span')
        
        date_from = datetime.strptime(request.DATA.get('date_from', None), '%Y-%m-%d')
        date_to = datetime.strptime(request.DATA.get('date_to', None), '%Y-%m-%d')

        stat_list = getStatList(request.DATA.get('filter_cust', None), request.DATA.get('item_id', None), request.DATA.get('customer_stat_unit'))

        if time_period == "5" or time_period == "hourly" :
            time_period = "hourly"

        stats = get_data_average_client_response_bandwidth(stat_list.get('stat_list'), date_from, date_to, time_period, tz_offset, return_type="chart", is_contract_stat=stat_list.get('is_contract_stat'))

        if len(stats.get('value_list')) == 0 :
            chartData = {}
            ret_json = {'factor':'failure', 'msg':_(u'No Data.'), 'items' : chartData}
        else :
            avgBandwidth = get_avg(stats.get('value_list'))
            peakTmp = getMaxMin(stats.get('value_list'))

            peakBandwidth = peakTmp.get('max')

            if peakBandwidth > 0 :
                peakBandwidthTime = peakTmp.get('maxTime')
            else :
                peakBandwidthTime = 0

            dataUnit = getDataUnit(stats.get('avgValue'), "bps")

            chartData = {'chart_width' : 934,
                              'chart_height' : 300,
                              'chart_data' : stats.get('value_list'),
                              'chart_type' : {
                                              'type' : 'line',
                                              'seriesName' : 'Average Client Bandwidth',
                                              'yAxisName' : dataUnit.get('avgUnit'),
                                              'xAxisName' : xAxisName,
                                              'avgBandwidth' : avgBandwidth,
                                              'peakBandwidth' : peakBandwidth,
                                              'peakBandwidthTime' : peakBandwidthTime,
                                              'numDivision' : dataUnit.get('numDivision'),
                                              'defaultUnit' : "bps",
                                              }
                              }

            ret_json = {'factor':'success', 'items' : chartData}
    except Exception as e:
        chartData = {}

        ret_json = {'factor':'failure', 'msg':_(u'Something is technically wrong. Please try again.'), 'items' : chartData}

    return ret_json

class GetUniqueVisitors(SpectrumGenericAPIView):
    def post(self, request, *args, **kwargs):
        ret = visitor_ajax_uniqueVisitors(request)
        return Response(ret)

class GetEdgeResponseCode(SpectrumGenericAPIView):
    def post(self, request, *args, **kwargs):
        ret = cs_ajax_chart_edge_response_code(request)
        return Response(ret)

class GetLocation(SpectrumGenericAPIView):
    def post(self, request, *args, **kwargs):
        location_range = request.DATA.get('location_range', None)
        if location_range == 'world':
            ret = visitor_ajax_location_country(request)
        if location_range == 'countries':
            ret = visitor_ajax_location_state(request)
        if location_range == 'states':
            ret = visitor_ajax_location_city(request)
        return Response(ret)

class GetResponseBandwidth(SpectrumGenericAPIView):
    def post(self, request, *args, **kwargs):
        ret = visitor_ajax_responseBandwidth(request)
        return Response(ret)

class GetBrowser(SpectrumGenericAPIView):
    def post(self, request, *args, **kwargs):
        ret = visitor_ajax_browser(request)
        return Response(ret)

class GetOperatingSystem(SpectrumGenericAPIView):
    def post(self, request, *args, **kwargs):
        ret = visitor_ajax_operatingSystem(request)
        return Response(ret)

class GetPlayer(SpectrumGenericAPIView):
    def post(self, request, *args, **kwargs):
        ret = visitor_ajax_player(request)
        return Response(ret)

class GetTop10Isp(SpectrumGenericAPIView):
    def post(self, request, *args, **kwargs):
        ret = visitor_ajax_top10Isp(request)
        return Response(ret)
