
from datetime import datetime

from django.contrib.auth.models import User
from django.db import models

from spectrum_api.shared_components.models import BaseModel


MAX_DATE = '2038-01-18 00:00:00'

RMS_ACTION_TYPE = (
    (1, 'Snoozed'),
    (2, 'RT Ticket Created'),
    (3, 'Snoozed Again'),
    (4, 'Snooze Disabled'),
    (5, 'RT Ticket Resolved'),
)

RMS_ACTION_LEVEL = (
    (1, 'Pop'),
    (2, 'System'),
    (3, 'Host'),
    (4, 'Vip'),
    (5, 'Vip/Probe'),
    (6, 'RT System'),
)

RMS_ERROR_MSG = {
    -1: 'Threshold exceeded',
    -2: 'Timed out',
    -3: 'Could not connect',
    -4: 'Aggregation failed',
    -5: 'Step function failed',
    -6: 'Scaling failed',
    -7: 'Invalid response',
    -8: 'Could not send data',
    -9: 'Could not recv data',
    -10: 'SSL specific error',
    -11: 'Invalid parameter',
    -12: 'Internal error',
    -13: 'Unknown error',
    -14: 'Unreachable',
    -15: 'Unsupported response',
    -16: 'Error responded',
    -17: 'Regex not matched',
    -18: 'Resp code not matched',
    -19: 'Disconnected',
    -20: 'Session closed',
    -21: 'Not found',
    -22: 'Login failed',
    -23: 'Verification failed',
    -24: 'RTMP version mismatch',
    -25: 'No peer certificate',
    -26: 'Internal epoll error',
    -27: 'Internal socket error',
    -28: 'Internal memory error',
    -29: 'Internal CURL error',
    -30: 'Internal RTMP error',
    -31: 'Internal SNMP error',
    -32: 'Internal SSL error',
    -33: 'Internal BIO error',
    'default':'Wrong error code'
}

DISPLAY_FORMAT_CHOICES = ((1, 1), (2, 2))
SECONDARY_FORMAT_CHOICES = ((1, 1), (2, 2))
POSITION_CHOICES = tuple([(i, i) for i in range(1, 32)])
PERCENT_CHOICES = tuple([(i, i) for i in range(0, 101)])


def get_translated_rms_message(probe_value):
    ''' It returns translated rms probe value

        param:
            probe_value <integer> : value from rms probe

        returns:
            <string> : human redable message.
    '''

    if probe_value == 0:
        return 'Normal'

    else:
        try:
            return RMS_ERROR_MSG[probe_value]

        except KeyError:
            return RMS_ERROR_MSG['default']


def check_success(val):
    if val < 0:
        return False
    return True


class RMSAirport(BaseModel):

    airport_id = models.IntegerField(max_length=10, null=False)
    airport_name = models.CharField(max_length=50, null=False)
    airport_city = models.CharField(max_length=50, null=False)
    airport_country = models.CharField(max_length=50, null=False)
    airport_iata = models.CharField(max_length=50, null=True)
    airport_lat = models.FloatField(null=False)
    airport_lng = models.FloatField(null=False)

    class Meta(object):
        db_table = 'airport'
        app_label = 'rms'
        managed = False

    class SpectrumMeta(object):
        router = 'read-only'
        track = True


class RMSDisplayProbes(BaseModel):

    display_probes_id = models.AutoField(primary_key=True)
    for_probe_name = models.CharField(max_length=45, db_index=True)
    probe_name = models.CharField(max_length=45)
    priority = models.SmallIntegerField()
    position = models.SmallIntegerField(unique=True, choices=POSITION_CHOICES)
    warning_percent = models.SmallIntegerField(choices=PERCENT_CHOICES)
    failure_percent = models.SmallIntegerField(choices=PERCENT_CHOICES)
    visual_name = models.CharField(max_length=45, null=True, default=None)
    drill_down = models.BooleanField()
    display_format = models.SmallIntegerField(choices=DISPLAY_FORMAT_CHOICES)
    secondary_format = models.SmallIntegerField(choices=SECONDARY_FORMAT_CHOICES)

    class Meta(object):
        db_table = 'rms_display_probes'
        app_label = 'rms'
        unique_together = (
            ('for_probe_name', 'probe_name'),
            ('for_probe_name', 'position')
        )
        managed = False

    class SpectrumMeta(object):
        router = 'read-only'
        track = True
        allow_delete = True


class RMSPop(BaseModel):
    pop_id = models.PositiveIntegerField(primary_key=True)
    name = models.CharField(max_length=45)

    class Meta(object):
        db_table = 'rms_pop'
        app_label = 'rms'
        managed = False

    class SpectrumMeta(object):
        read_only = True
        router = 'read-only'


class RMSServer(BaseModel):
    server_id = models.IntegerField(primary_key=True, db_column='server_id')
    name = models.CharField(max_length=45)
    pop = models.ForeignKey(RMSPop, db_index=True, db_column='pop_id')

    class Meta(object):
        db_table = 'rms_server'
        app_label = 'rms'
        managed = False

    class SpectrumMeta(object):
        read_only = True
        router = 'read-only'


class RMSHost(BaseModel):
    host_id = models.IntegerField(primary_key=True, db_column='host_id')
    name = models.CharField(max_length=45)
    server = models.ForeignKey(RMSServer, db_index=True, db_column='server_id')

    class Meta(object):
        db_table = 'rms_host'
        app_label = 'rms'
        managed = False

    class SpectrumMeta(object):
        read_only = True
        router = 'read-only'


class RMSVip(BaseModel):
    vip_id = models.IntegerField(primary_key=True)
    ip = models.CharField(max_length=45)
    server = models.ForeignKey(RMSServer, db_index=True, db_column='server_id')
    host = models.ForeignKey(RMSHost, db_index=True, db_column='host_id')
    isUplink = models.SmallIntegerField(db_index=True)

    class Meta(object):
        db_table = 'rms_vip'
        app_label = 'rms'
        managed = False

    class SpectrumMeta(object):
        read_only = True
        router = 'read-only'


class RMSVipProbe(BaseModel):
    vip_probe_id = models.PositiveIntegerField(primary_key=True)
    name = models.CharField(max_length=45)
    probe_id = models.PositiveIntegerField()
    vip = models.ForeignKey(RMSVip, db_index=True, db_column='vip_id')
    intervals = models.IntegerField()
    ttl_factor = models.IntegerField()


    class Meta(object):
        db_table = 'rms_vip_probe'
        app_label = 'rms'
        managed = False

    class SpectrumMeta(object):
        read_only = True
        router = 'read-only'

    @property
    def alive_factor(self):
        return self.intervals * self.ttl_factor


class RMSPacketLossVipPopMap(BaseModel):
    vip = models.ForeignKey(RMSVip, primary_key=True, db_column='vip_id')
    pop = models.ForeignKey(RMSPop, db_column='pop_id')
    threshold = models.FloatField()

    class Meta(object):
        db_table = 'rms_packet_loss_vip_pop_map'
        unique_together = ('vip', 'pop')
        app_label = 'rms'
        managed = False

    class SpectrumMeta(object):
        read_only = True
        router = 'read-only'


class RMSPacketLoss(BaseModel):
    probe_agent_vip = models.ForeignKey(RMSVip, primary_key=True, db_column='probe_agent_vip_id')
    vip = models.ForeignKey(RMSPacketLossVipPopMap, null=False, db_column='vip_id')
    timestamp = models.DateTimeField(default='0000-00-00 00:00:00')
    loss = models.CharField(max_length=11)
    time = models.DateTimeField(auto_now=True, auto_now_add=True)

    class Meta(object):
        db_table = 'rms_packet_loss'
        app_label = 'rms'
        unique_together = ('probe_agent_vip', 'vip')
        managed = False

    class SpectrumMeta(object):
        read_only = True
        router = 'read-only'


class RMSPacketLossHistory(BaseModel):
    probe_agent_vip = models.ForeignKey(RMSVip, primary_key=True, db_column='probe_agent_vip_id')
    vip = models.ForeignKey(RMSPacketLossVipPopMap, null=False, db_column='vip_id')
    timestamp = models.DateTimeField(default='0000-00-00 00:00:00')
    loss = models.IntegerField()
    time = models.DateTimeField(auto_now=True, auto_now_add=True, db_index=True)

    class Meta(object):
        app_label = 'rms'
        db_table = 'rms_packet_loss_history'
        unique_together = ('vip', 'probe_agent_vip')
        managed = False

    class SpectrumMeta(object):
        read_only = True
        router = 'read-only'


class RMSMessageAbstract(BaseModel):
    timestamp = models.DateTimeField(default='0000-00-00 00:00:00')
    val = models.IntegerField()
    time = models.DateTimeField(auto_now=True, auto_now_add=True, db_index=True)
    probe_agent_vip = models.ForeignKey(RMSVip, db_column='probe_agent_vip_id', null=True)

    class Meta(object):
        abstract = True
        managed = False

    def check_success(self):
        return check_success(self.val)

    # returns description for corresponding value
    def get_desc(self):
        if self.val < 0:
            return RMS_ERROR_MSG.get(self.val, RMS_ERROR_MSG['default'])
        return ""


class RMSMessage(RMSMessageAbstract):
    vip = models.ForeignKey(RMSVip, db_column='vip_id', related_name='rmsmessage_vip_set')

    expired = models.BooleanField()
    vip_probe = models.OneToOneField(
        RMSVipProbe, primary_key=True,
        db_column='vip_probe_id', related_name="message")

    class Meta(object):
        app_label = 'rms'
        db_table = 'rms_message_expired_view'
        unique_together = ('vip', 'vip_probe')
        managed = False

    class SpectrumMeta(object):
        router = 'read-only'
        read_only = True

    def get_desc(self):
        val = super(RMSMessage, self).get_desc()
        if not val and self.expired:
            return "Expired"
        return val

    def check_success(self):
        if not self.expired:
            return super(RMSMessage, self).check_success()
        return False


class RMSMessageHistory(RMSMessageAbstract):

    vip = models.ForeignKey(RMSVip, db_column='vip_id', related_name='rmsmessagehistory_vip_set')

    vip_probe = models.ForeignKey(
        RMSVipProbe, primary_key=True,
        db_column='vip_probe_id', related_name='rmsmessagehistory_vipprobe_set')

    class Meta(object):
        app_label = 'rms'
        db_table = 'rms_message_history'
        unique_together = ('vip', 'vip_probe')
        managed = False

    class SpectrumMeta(object):
        router = 'read-only'
        read_only = True


class RMSAcknowledge(BaseModel):

    ack_id = models.AutoField(primary_key=True)
    vip_probe = models.ForeignKey(RMSVipProbe, db_column='vip_probe_id')
    ack_type = models.PositiveSmallIntegerField(null=True)
    probe_name = models.CharField(max_length=45, null=True)
    level = models.PositiveSmallIntegerField(choices=RMS_ACTION_LEVEL)
    time_created = models.DateTimeField(auto_now_add=True)
    time_updated = models.DateTimeField(auto_now_add=True, auto_now=True)
    end_date = models.DateTimeField(default=MAX_DATE)
    rt_ticket = models.IntegerField(null=True)

    class Meta(object):
        app_label = 'rms'
        db_table = 'rms_acknowledge'
        unique_together = ('vip_probe', 'level', 'probe_name')
        managed = False

    class SpectrumMeta(object):
        router = 'read-only'
        allow_delete = True
        track = True


class RMSActionHistory(BaseModel):
    action_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User)
    rt_ticket = models.IntegerField(null=True)
    action_level = models.PositiveSmallIntegerField(choices=RMS_ACTION_LEVEL)
    action_type = models.SmallIntegerField(choices=RMS_ACTION_TYPE)
    action_obj_id = models.PositiveIntegerField(db_column='action_obj_id')
    action_obj = models.CharField(max_length=30)
    action_time = models.DateTimeField()

    class Meta(object):
        app_label = 'rms'
        db_table = 'rms_action_history'
        managed = False


class RawRMSMessage(RMSMessageAbstract):

    vip_ip = models.PositiveIntegerField(db_column='vip')

    vip_probe = models.OneToOneField(
        RMSVipProbe, primary_key=True,
        db_column='vip_probe_id', related_name="raw_message")

    val_secondary = models.IntegerField()
    timestamp_secondary = models.DateTimeField()
    is_primary = models.IntegerField()

    class Meta(object):
        app_label = 'rms'
        db_table = 'rms_message'
        managed = False

    class SpectrumMeta(object):
        router = 'read-only'
        read_only = True

    def is_expired_primary(self, date_now):
        return date_now - self.timestamp > self.vip_probe.alive_factor

    def is_expired_secondary(self, date_now):
        return date_now - self.timestamp_secondary > self.vip_probe.alive_factor

    def is_expired(self):
        utc_now = datetime.utcnow()

        if not self.is_expired_primary(utc_now) and not self.is_expired_secondary(utc_now):
            return True
        else:
            return False

    @property
    def probe_value(self):
        utc_now = datetime.utcnow()

        if not self.is_expired_primary(utc_now):
            return self.val
        elif not self.is_expired_secondary(utc_now):
            return self.val_secondary
        else:
            return None
