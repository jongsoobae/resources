from django.db import connections


class RMSPoPStatus(object):
    def __init__(self):
        """
        Note
        ----
        Initiate RMSPoPStatus class
        """
        self.db_name = 'read-only'

    def get_pop_status_list(self, probe_name='', show_alive=False):
        """
        Note
        ----
        When probe_name is empty string, It returns all PoP statuses.
        If probe_name exists, It returns PoP statuses by probe_name.

        Parameters
        ----------
        probe_name : string
        show_alive : boolean

        Returns
        -------
        dict
        """
        try:
            if isinstance(probe_name, basestring) is not True:
                raise Exception("'probe_name' value allows 'string' type only.")

            if isinstance(show_alive, bool) is not True:
                raise Exception("'show_alive' value allows 'boolean' type only.")

            if probe_name == '' and show_alive is False:
                # In case of getting all PoP status list, API only allows when 'show_alive' is 'true'.
                # because there is an performance issue when 'show_alive' is 'false'.(It takes about 20 seconds.)
                raise Exception("'show_alive' value must be True. In case of getting all PoP status.")

            where_clause = ''
            if probe_name != '':
                where_clause = 'WHERE rms_vip_probe.name = %s'

            inner_or_left = 'INNER' if show_alive else 'LEFT'

            sql = """
                SELECT rms_pop.name, count(rms_message.vip)
                FROM rms.rms_pop
                INNER JOIN rms.rms_server ON rms_pop.pop_id = rms_server.pop_id
                INNER JOIN rms.rms_vip ON rms_server.server_id = rms_vip.server_id
                INNER JOIN rms.rms_vip_probe ON rms_vip.vip_id = rms_vip_probe.vip_id
                %(inner_or_left)s JOIN rms.rms_message ON rms_message.vip_probe_id = rms_vip_probe.vip_probe_id
                                              AND (rms_message.val >= 0 OR rms_message.val_secondary >= 0)
                %(where_clause)s
                GROUP BY rms_pop.pop_id
            """ % {
                'inner_or_left': inner_or_left,
                'where_clause': where_clause
            }

            cursor = connections[self.db_name].cursor()

            try:
                if probe_name != '':
                    cursor.execute(sql, (probe_name,))
                else:
                    cursor.execute(sql)

                query_result = cursor.fetchall()

                result = {'alive_pop': []}
                if show_alive is False:
                    result['dead_pop'] = []

                for row in query_result:
                    if row[1] > 0:  # alive vip is exists
                        result['alive_pop'].append(row[0])
                    else:  # dead
                        if show_alive is False:
                            result['dead_pop'].append(row[0])

                return result
            except Exception as e:
                raise e
            finally:
                cursor.close()
                del cursor
        except Exception as e:
            raise e