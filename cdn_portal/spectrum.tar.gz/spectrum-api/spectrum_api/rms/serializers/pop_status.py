from rest_framework import serializers


class RMSPoPStatusSerializer(serializers.Serializer):
    probe_name = serializers.CharField(required=False)
    show_alive = serializers.BooleanField(required=False)

    def validate(self, kwargs):
        """
        Note
        ----
        1. It must needs 'probe_name' parameter. but allows empty string for 'probe_name'.

        Parameters
        ----------
        kwargs : dict

        Returns
        -------
        ValidationError or validated_data
        """
        if 'probe_name' not in kwargs:
            raise serializers.ValidationError({'probe_name': ['This field is required.']})

        if kwargs.get('probe_name') == '' and kwargs.get('show_alive') is not True:
            raise serializers.ValidationError({
                'show_alive': ['You must set this value to \'true\' to get all PoP status.']
            })

        validated_data = {
            'probe_name': kwargs.pop('probe_name'),
            'show_alive': kwargs.pop('show_alive')
        }

        return validated_data