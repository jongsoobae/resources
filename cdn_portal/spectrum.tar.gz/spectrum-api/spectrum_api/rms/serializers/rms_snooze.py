
import re

from rest_framework import serializers

from spectrum_api.rms.models.gslb_rms import RMSAcknowledge
from spectrum_api.rms.models.gslb_rms import RMSVipProbe


class RMSVipProbeSerializer(serializers.Serializer):
    vip_probe_id_list = serializers.CharField(required=True)

    def validate(self, attr):
        comma_separated_number_regex = re.compile(r'(^(\d*\,?)*$)')

        if not comma_separated_number_regex.match(attr['vip_probe_id_list']):
            raise serializers.NestedValidationError(
                '\'vip_probe_id_list\' must be comma separated number value (ex. \'13,2456,7\')')

        try:
            vip_probe_list = RMSVipProbe.objects.filter(vip_probe_id__in=attr['vip_probe_id_list'].split(','))
            return vip_probe_list

        except RMSVipProbe.DoesNotExist:
            raise serializers.ValidationError('There is no matched vip-probe node')


class RMSSnoozeAPISerializer(RMSVipProbeSerializer):

    end_date = serializers.DateTimeField(required=True)
    action_level = serializers.IntegerField(required=True)

    def validate(self, attr):
        vip_probe_list = RMSVipProbeSerializer.validate(self, attr)

        valid_vip_probe_list = []

        for vip_probe in vip_probe_list:
            args = {
                'vip_probe': vip_probe,
                'probe_name': vip_probe.name,
                'level': attr['action_level']
            }

            try:
                acknowledge = RMSAcknowledge.objects.get(**args)

            except RMSAcknowledge.DoesNotExist:
                args['end_date'] = attr['end_date']
                args['ack_type'] = 1

                acknowledge = RMSAcknowledge(**args)

            valid_vip_probe_list.append(acknowledge)

        return valid_vip_probe_list


class RMSSnozeReleaseAPISerializer(RMSVipProbeSerializer):

    def validate(self, attr):
        vip_probe_list = RMSVipProbeSerializer.validate(self, attr)

        return RMSAcknowledge.objects.filter(vip_probe__in=vip_probe_list)

