import os

os.environ['DJANGO_SETTINGS_MODULE'] = 'spectrum_api.settings'

from django.contrib.auth.models import User
from django.db.models.query import QuerySet
from rest_framework.test import APIClient

import json
import jsonschema
import unittest

class TestConfigSetting(unittest.TestCase):
    @classmethod
    def setUpClass(self):
        self.client = APIClient()
        user = User.objects.get(username='jaeyoung.cho')
        self.client.force_authenticate(user=user)

        self.json_schema = json.loads(open('./config_setting_schema.json').read())

    @classmethod
    def tearDownClass(self):
        print 'teardownClass'

    def setUp(self):
        print 'setUp'

    def tearDown(self):
        print 'tearDown'

    def test_get(self):
        response = self.client.get('/api/rms/config_setting/')

        data = response.data

        try:
            jsonschema.validate(response.data, self.json_schema)
        except jsonschema.ValidationError as e:
            self.assertTrue(False, e.message)
        except jsonschema.SchemaError as e:
            self.assertTrue(False, e.message)