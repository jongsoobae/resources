import os
os.environ['DJANGO_SETTINGS_MODULE'] = 'spectrum_api.settings'

from django.contrib.auth.models import User
from rest_framework.test import APIClient

import unittest
import json
import pickle


class TestRMSInfo(unittest.TestCase):
    @classmethod
    def setUpClass(self):
        self.client = APIClient()
        user = User.objects.get(username='jaeyoung.cho')
        self.client.force_authenticate(user=user)

        pkl_file = open('origin_data.pkl', 'rb')
        self.origin_rms_tree_node_list = pickle.load(pkl_file)
        pkl_file.close()

        pkl_file = open('origin_rms_settings_data.pkl', 'rb')
        self.origin_rms_settings = pickle.load(pkl_file)
        pkl_file.close()

    @classmethod
    def tearDownClass(self):
        print 'teardownClass'

    def setUp(self):
        self.assertIsNotNone(self.origin_rms_tree_node_list)
        self.assertTrue(type(self.origin_rms_tree_node_list) is list)

    def tearDown(self):
        print 'tearDown'

    def test_request_rms_settings(self):
        response = self.client.get('/api/rms/setting/')

        self.assertEquals(len(response.data), len(self.origin_rms_settings))

        DISPLAY_PROBES_ID = 'display_probes_id'
        FOR_PROBE_NAME = 'for_probe_name'
        PROBE_NAME = 'probe_name'
        PRIORITY = 'priority'
        POSITION = 'position'
        WARNING_PERCENT = 'warning_percent'
        FAILURE_PERCENT = 'failure_percent'
        VISUAL_NAME = 'visual_name'
        DRILL_DOWN = 'drill_down'
        SECONDARY_FORMAT = 'secondary_format'
        DISPLAY_FORAMT = 'display_format'

        for idx in range(0, len(response.data)):
            origin = self.origin_rms_settings[idx]
            current = response.data[idx]

            self.assertEqual(origin[DISPLAY_PROBES_ID], current[DISPLAY_PROBES_ID])
            self.assertEqual(origin[FOR_PROBE_NAME], current[FOR_PROBE_NAME])
            self.assertEqual(origin[PROBE_NAME], current[PROBE_NAME])
            self.assertEqual(origin[PRIORITY], current[PRIORITY])
            self.assertEqual(origin[POSITION], current[POSITION])
            self.assertEqual(origin[WARNING_PERCENT], current[WARNING_PERCENT])
            self.assertEqual(origin[FAILURE_PERCENT], current[FAILURE_PERCENT])
            self.assertEqual(origin[VISUAL_NAME], current[VISUAL_NAME])
            self.assertEqual(origin[DRILL_DOWN], current[DRILL_DOWN])
            self.assertEqual(origin[SECONDARY_FORMAT], current[SECONDARY_FORMAT])
            self.assertEqual(origin[DISPLAY_FORAMT], current[DISPLAY_FORAMT])

    def test_request_rms_info(self):
        response = self.client.get('/api/rms/info/')
        rms_tree_node_list = response.data['pop_nodes']

        self.assertIsNotNone(rms_tree_node_list)
        self.assertTrue(type(rms_tree_node_list) is list)

        self.assertEquals(len(self.origin_rms_tree_node_list), len(rms_tree_node_list))

        probe_names = set()

        def get_probe_name_set(items):
            for item in items:
                try:
                    get_probe_name_set(item['children'])
                except KeyError:
                    probe_names.add(item['probe_name'])

        get_probe_name_set(rms_tree_node_list)

        origin_probe_name_list = []

        for probe_item in self.origin_rms_settings:
            origin_probe_name_list.append(probe_item['probe_name'])

        self.assertLessEqual(len(probe_names), len(origin_probe_name_list))

        for probe_name in probe_names:
            self.assertTrue(probe_name in origin_probe_name_list)






