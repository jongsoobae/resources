
import unittest

from spectrum_api.rms.models.gslb_rms import get_translated_rms_message
from spectrum_api.rms.models.gslb_rms import RMS_ERROR_MSG


class TestRMSTranslatedMessageFunction(unittest.TestCase):

    def test_get_translated_rms_message_should_returns_normal_when_got_zero(self):
        self.assertEqual(get_translated_rms_message(0), 'Normal')

    def test_get_translated_rms_message_should_returns_valid_message_when_got_valid_value(self):

        valid_values = range(0, -33)

        for value in valid_values:
            self.assertEqual(get_translated_rms_message(value), RMS_ERROR_MSG[value])

    def test_get_translated_rms_message_should_returns_default_message_when_got_invalid_value(self):

        invalid_values_a = range(-34, -100)
        invalid_values_b = range(1, 100)

        for value in invalid_values_a:
            self.assertEqual(get_translated_rms_message(value), RMS_ERROR_MSG['default'])

        for value in invalid_values_b:
            self.assertEqual(get_translated_rms_message(value), RMS_ERROR_MSG['default'])
