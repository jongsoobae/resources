from django.conf.urls.defaults import url, patterns
from rest_framework.urlpatterns import format_suffix_patterns
from spectrum_api.rms.views.pop_status import RMSPoPStatusAPI

from spectrum_api.rms.views.monitor.info import RMSInfoAPIView
from spectrum_api.rms.views.monitor.setting import RMSSettingAPIView
from spectrum_api.rms.views.monitor.config_setting import RMSConfigSettingAPIView
from spectrum_api.rms.views.reporting.snooze import RMSSnoozeAPIView
from spectrum_api.rms.views.reporting.rt import RMSRtAPIView


restfw_api_urlpatterns = patterns(
    'spectrum_api.rms.views',

    # Portal 2.8.10 Service Status Dashboard.
    url(r'^rms/pop_status/$', RMSPoPStatusAPI.as_view(), name="rms_pop_status"),

    # Portal 2.8.40 - RMS Renewal

    ## RMS Information API
    url(r'^rms/info/$', RMSInfoAPIView.as_view(), name="rms_root_info_api"),
    url(r'^rms/setting/$', RMSSettingAPIView.as_view(), name="rms_setting_api"),
    url(r'^rms/config_setting/$', RMSConfigSettingAPIView.as_view(), name='rms_config_setting_api'),
    url(r'^rms/snooze/$', RMSSnoozeAPIView.as_view(), name="rms_snooze_api"),
    url(r'^rms/reporting/$', RMSRtAPIView.as_view(), name="rms_rt_api"),
)

urlpatterns = format_suffix_patterns(restfw_api_urlpatterns)
