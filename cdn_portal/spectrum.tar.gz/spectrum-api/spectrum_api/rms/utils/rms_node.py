
from collections import namedtuple
import datetime

RMS_POP_TYPE = {
    'P': 0,
    'C': 1,
    'V': 2,
}
RMS_POP_TYPE_UNKNOWN = -1

RMS_NODE_INFO_SCHEMA = {
    'RMSAirportNodeInfo': (
        'airport_name', 'airport_city', 'airport_country',
        'airport_lat', 'airport_lng', 'airport_iata'
    ),
    'RMSPopNodeInfo': (
        'pop_id', 'pop_name', 'pop_type', 'pop_iata'
    ),
    'RMSHostNodeInfo': (
        'pop_id', 'host_id', 'host_name', 'system_id', 'system_name'
    ),
    'RMSVipNodeInfo': (
        'host_id', 'vip_id', 'ip_addr', 'uplink'
    ),
    'RMSProbeNodeInfo': (
        'vip_id', 'instance_id', 'probe_id', 'probe_name', 'intervals', 'ttl_factor'
    ),
    'RMSProbeAckNodeInfo': (
        'instance_id', 'ack_id', 'ack_type', 'probe_name', 'level', 'time_created',
        'time_updated', 'end_date', 'rt_ticket'
    ),
    'RMSProbeMessageNodeInfo': (
        'instance_id', 'observer', 'observe_value', 'timestamp', 'expired'
    ),
    'RMSSettingInfo': (
        'secondary_format', 'for_probe_name', 'failure_percent',
        'visual_name', 'priority', 'drill_down', 'display_probes_id',
        'position', 'display_format', 'warning_percent', 'probe_name'
    ),
    'RMSConfigSettingInfo': (
        'rms_settings_id', 'visual_name', 'probe_name'
    )
}


def generate_tuple(schema_name):
    '''
        Generate Namedtuple Object with RMS_NODE_INFO_SCHEMA

        @params
            (string)schema_name : schema_name in RMS_NODE_INFO_SCHEMA

        @returns
            namedtuple<?> : named with schema_name, and field is defined to
                RMS_NODE_INFO_SCHEMA dict's value matched by schema_name.
    '''

    return namedtuple(schema_name, ','.join(RMS_NODE_INFO_SCHEMA[schema_name]))


def get_pop_type(pop_name):
    '''
        returns PopNode's type character
    '''

    pop_prefix = pop_name[0].upper()

    return RMS_POP_TYPE.get(pop_prefix, RMS_POP_TYPE_UNKNOWN)


def get_cleaned_dict(dictionary):
    return dict((key, value) for key, value in dictionary.iteritems() if value is not None)


class RMSNodeSerializerFactory(object):

    RMSAirportNodeInfo = generate_tuple('RMSAirportNodeInfo')
    RMSPopNodeInfo = generate_tuple('RMSPopNodeInfo')
    RMSHostNodeInfo = generate_tuple('RMSHostNodeInfo')
    RMSVipNodeInfo = generate_tuple('RMSVipNodeInfo')
    RMSProbeNodeInfo = generate_tuple('RMSProbeNodeInfo')
    RMSProbeAckNodeInfo = generate_tuple('RMSProbeAckNodeInfo')
    RMSProbeMessageNodeInfo = generate_tuple('RMSProbeMessageNodeInfo')

    RMSSettingInfo = generate_tuple('RMSSettingInfo')
    RMSConfigSettingInfo = generate_tuple('RMSConfigSettingInfo')

    def airport_node(self, airport):
        return get_cleaned_dict(self.RMSAirportNodeInfo(
            airport_name=airport.get('airport_name'), airport_country=airport.get('airport_country'),
            airport_city=airport.get('airport_city'), airport_iata=airport.get('airport_iata'),
            airport_lat=airport.get('airport_lat'), airport_lng=airport.get('airport_lng')
        )._asdict())

    def pop_node(self, pop):
        pop_name = pop.get('name')

        if pop_name:
            pop_type = get_pop_type(pop_name)
            pop_iata = pop_name.split('-')[-1].upper()

        else:
            pop_type = None
            pop_iata = None

        return get_cleaned_dict(self.RMSPopNodeInfo(
            pop_id=pop.get('pop_id'), pop_name=pop_name,
            pop_type=pop_type, pop_iata=pop_iata
        )._asdict())

    def host_node(self, host):

        return get_cleaned_dict(self.RMSHostNodeInfo(
            pop_id=host.get('server__pop'), host_id=host.get('host_id'),
            host_name=host.get('name'), system_id=host.get('server'),
            system_name=host.get('server__name')
        )._asdict())

    def vip_node(self, vip):

        return get_cleaned_dict(self.RMSVipNodeInfo(
            host_id=vip.get('host__host_id'), vip_id=vip.get('vip_id'),
            ip_addr=vip.get('ip'), uplink=vip.get('isUplink')
        )._asdict())

    def probe_node(self, probe):

        return get_cleaned_dict(self.RMSProbeNodeInfo(
            vip_id=probe.get('vip'), instance_id=probe.get('vip_probe_id'),
            probe_id=probe.get('probe_id'), probe_name=probe.get('name'),
            intervals=probe.get('intervals'), ttl_factor=probe.get('ttl_factor')
        )._asdict())

    def probe_ack_node(self, probe_ack):
        return get_cleaned_dict(self.RMSProbeAckNodeInfo(
            ack_id=probe_ack.get('ack_id'), instance_id=probe_ack.get('vip_probe'),
            ack_type=probe_ack.get('ack_type'), probe_name=probe_ack.get('probe_name'),
            level=probe_ack.get('level'), time_created=probe_ack.get('time_created'),
            time_updated=probe_ack.get('time_updated'), end_date=probe_ack.get('end_date'),
            rt_ticket=probe_ack.get('rt_ticket')
        )._asdict())

    def probe_message_node(self, probe_message):

        return get_cleaned_dict(self.RMSProbeMessageNodeInfo(
            instance_id=probe_message.get('vip_probe__vip_probe_id'),
            observer=probe_message.get('probe_agent_vip'), observe_value=probe_message.get('val'),
            timestamp=probe_message.get('timestamp'), expired=probe_message.get('expired')
        )._asdict())

    def raw_probe_message_node(self, raw_probe_message):

        time_now = datetime.datetime.utcnow()

        vip_probe_intervals = raw_probe_message.get('vip_probe__intervals')
        vip_probe_ttl_factor = raw_probe_message.get('vip_probe__ttl_factor')
        timestamp_primary = raw_probe_message.get('timestamp')
        timestamp_secondary = raw_probe_message.get('timestamp_secondary')

        probe_alive_factor = vip_probe_intervals * vip_probe_ttl_factor
        timedelta_primary = time_now - timestamp_primary
        timedelta_secondary = time_now - timestamp_secondary

        cond_expired_primary = probe_alive_factor < timedelta_primary.days * 1440 + timedelta_primary.seconds
        cond_expired_secondary = probe_alive_factor < timedelta_secondary.days * 1440 + timedelta_secondary.seconds

        probe_expired = cond_expired_primary and cond_expired_secondary
        probe_value = None
        probe_report_timestamp = raw_probe_message.get('time')

        if not cond_expired_primary:
            probe_value = raw_probe_message.get('val')
            probe_report_timestamp = timestamp_primary

        elif not cond_expired_secondary:
            probe_value = raw_probe_message.get('val_secondary')
            probe_report_timestamp = timestamp_secondary

        return get_cleaned_dict(self.RMSProbeMessageNodeInfo(
            instance_id=raw_probe_message.get('vip_probe'),
            observer=raw_probe_message.get('probe_agent_vip'), observe_value=probe_value,
            timestamp=probe_report_timestamp, expired=probe_expired
        )._asdict())

    def rms_setting_node(self, rms_setting):
        return get_cleaned_dict(self.RMSSettingInfo(
            display_probes_id=rms_setting.display_probes_id,
            for_probe_name=rms_setting.for_probe_name,
            failure_percent=rms_setting.failure_percent,
            warning_percent=rms_setting.warning_percent,
            probe_name=rms_setting.probe_name,
            visual_name=rms_setting.visual_name,
            priority=rms_setting.priority,
            drill_down=rms_setting.drill_down,
            position=rms_setting.position,
            display_format=rms_setting.display_format,
            secondary_format=rms_setting.secondary_format
        )._asdict())


    def rms_config_setting_node(self, rms_config_setting):
        return get_cleaned_dict(self.RMSConfigSettingInfo(
            rms_settings_id = rms_config_setting.rms_settings_id,
            visual_name = rms_config_setting.visual_name,
            probe_name = rms_config_setting.base_probeconfig.name
        )._asdict())
