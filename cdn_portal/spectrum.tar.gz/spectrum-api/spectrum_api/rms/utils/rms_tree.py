
from collections import namedtuple


RMSTreeNode = namedtuple('RMSTreeNode', 'node_data, children')

RMS_NODE_SOURCE_SCHEMA = {
    'RMSAirport': (
        'airport_id', 'airport_name', 'airport_city', 'airport_country',
        'airport_lat', 'airport_lng', 'airport_iata'
    ),
    'RMSPop': (
        'pop_id', 'name'
    ),
    'RMSHost': (
        'host_id', 'name', 'server', 'server__name', 'server__pop'
    ),
    'RMSVip': (
        'vip_id', 'ip', 'isUplink', 'host__host_id'
    ),
    'RMSVipProbe': (
        'vip_probe_id', 'probe_id', 'vip', 'name', 'intervals', 'ttl_factor'
    ),
    'RMSAcknowledge': (
        'ack_id', 'vip_probe', 'ack_type', 'probe_name', 'level',
        'time_created', 'time_updated', 'end_date', 'rt_ticket'
    ),
    'RMSMessage': (
        'vip', 'expired', 'val', 'timestamp', 'probe_agent_vip', 'vip_probe__vip_probe_id'
    ),
    'RawRMSMessage': (
        'vip_ip', 'time', 'probe_agent_vip', 'vip_probe',
        'vip_probe__intervals', 'vip_probe__ttl_factor',
        'val', 'timestamp', 'is_primary',
        'val_secondary', 'timestamp_secondary'
    ),
    'RMSMessageHistory': (
        'vip', 'val', 'timestamp', 'probe_agent_vip', 'vip_probe__vip_probe_id'
    )
}

def generate_treenode(node_data):
    '''
        Generate Initialized RMSTreeNode which initialized by node_data

        @params
            (namedtuple) node_data : namedtuple instance which initialized by RMS_NODE_INFO_SCHEMA

        @returns
            namedtuple<RMSTreeNode>
    '''

    return RMSTreeNode(node_data=node_data, children=[])


def generate_rms_treenode_dict(key_scheme, source_list, serializer, terminal=False):
    '''
        Gererate dictionary which value is <RMSTreenode>

        @params
            (list) source_list : list data which contains RMS Model's values dict.
            (string) key_scheme : key value of tree_dict. generally key_scheme is RMS Model's PK.
            (function) serializer : serialize function of source in source_list.
            (bool) terminal : condition value.

        @returns
            (dict) tree_dict : dict instance which contains <RMSTreeNode>
    '''

    tree_dict = {}

    for source in source_list:
        if terminal:
            tree_dict[source.get(key_scheme)] = serializer(source)
        else:
            tree_dict[source.get(key_scheme)] = generate_treenode(serializer(source))

    return tree_dict


def get_rms_treenode_dict(model, model_filter, key_scheme, serializer, terminal=False, values=None):

    value_filter = RMS_NODE_SOURCE_SCHEMA[model.__name__]

    if values:
        value_filter = tuple(set(value_filter) & set(values))

    model_values_list = model.objects.filter(
        **model_filter
    ).values(
        *value_filter
    )

    treenode_dict = generate_rms_treenode_dict(
        key_scheme=key_scheme,
        source_list=model_values_list,
        serializer=serializer,
        terminal=terminal)

    return treenode_dict


def link_rms_treenode(parent_node, child_node, key):

    for node_key in child_node.keys():
        node = child_node[node_key]

        if type(node) is RMSTreeNode:
            parent_id = node.node_data.get(key)
            parent_node[parent_id].children.append(node._asdict())

            # pop childnode's parent key
            node.node_data.pop(key)

        else:
            parent_id = node.get(key)
            parent_node[parent_id].children.append(node)

            # pop childnode's parent key
            node.pop(key)


def treenode_to_list(treenode_dict):

    treenode_list = []
    for key in treenode_dict.keys():
        treenode = treenode_dict[key]
        try:
            treenode_list.append(treenode._asdict())
        except AttributeError:
            treenode_list.append(treenode)

    return treenode_list
