
from rest_framework.response import Response

from spectrum_api.shared_components.generics import SpectrumGenericAPIView

from spectrum_api.rms.utils.rms_node import RMSNodeSerializerFactory
from spectrum_api.alerting.models.probe import RMSSettings


class RMSConfigSettingAPIView(SpectrumGenericAPIView):

    node_serializer = RMSNodeSerializerFactory()

    def get(self, request):

        all_settings = RMSSettings.objects.all()

        response = []
        for setting in all_settings:
            response.append(self.node_serializer.rms_config_setting_node(setting))

        return Response(response)
