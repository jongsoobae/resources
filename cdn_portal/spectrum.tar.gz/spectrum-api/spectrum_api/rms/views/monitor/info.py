
from collections import namedtuple

from rest_framework.status import HTTP_400_BAD_REQUEST
from rest_framework.exceptions import APIException
from rest_framework.response import Response

from spectrum_api.shared_components.generics import SpectrumGenericAPIView

from spectrum_api.rms.models.gslb_rms import RMSPop
from spectrum_api.rms.models.gslb_rms import RMSAirport
from spectrum_api.rms.models.gslb_rms import RMSHost
from spectrum_api.rms.models.gslb_rms import RMSVip
from spectrum_api.rms.models.gslb_rms import RMSVipProbe
from spectrum_api.rms.models.gslb_rms import RawRMSMessage
from spectrum_api.rms.models.gslb_rms import RMSAcknowledge

from spectrum_api.rms.utils.rms_node import RMSNodeSerializerFactory
from spectrum_api.rms.utils.rms_tree import get_rms_treenode_dict
from spectrum_api.rms.utils.rms_tree import link_rms_treenode
from spectrum_api.rms.utils.rms_tree import treenode_to_list
from spectrum_api.rms.models.gslb_rms import RMSDisplayProbes


def clamp(value, minimum, maximum):
    if value < minimum:
        value = minimum

    if value > maximum:
        value = maximum

    return value


class RMSInfoAPIView(SpectrumGenericAPIView):

    node_serializer = RMSNodeSerializerFactory()

    def build_pop_nodes(self, parent_node_dict=None, parent_key_scheme=None):
        '''
            Build Pop level RMS Treenode and link with parent_node_dict by key_scheme
            if parent_node_dict exists.
        '''

        pop_filter = {}

        child_node_dict = get_rms_treenode_dict(
            model=RMSPop,
            model_filter=pop_filter,
            key_scheme='pop_id',
            serializer=self.node_serializer.pop_node)

        # depth 0-1 : add airport info to pop_node
        airport_query_filter = {
            'airport_iata__in': [
                child_node_dict[pop_id].node_data.get('pop_iata')
                for pop_id in child_node_dict.keys()
            ]
        }

        pop_location = get_rms_treenode_dict(
            model=RMSAirport,
            model_filter=airport_query_filter,
            key_scheme='airport_iata',
            serializer=self.node_serializer.airport_node,
            terminal=True)

        # attach airport info data
        for pop_id in child_node_dict.keys():
            pop_iata = child_node_dict[pop_id].node_data.get('pop_iata')
            airport_info = pop_location.get(pop_iata)
            child_node_dict[pop_id].node_data.update({
                'iata_info': airport_info
            })

        if all((parent_node_dict, parent_key_scheme)):
            link_rms_treenode(
                parent_node=parent_node_dict,
                child_node=child_node_dict,
                key=parent_key_scheme)

        return parent_node_dict, child_node_dict

    def build_host_nodes(self, parent_node_dict=None, parent_key_scheme=None):
        '''
            Build Host-System level RMS Treenode and link with parent_node_dict by key_scheme
            if parent_node_dict exists.
        '''

        host_filter = {}

        if parent_node_dict:
            host_filter['server__pop__in'] = parent_node_dict.keys()

        child_node_dict = get_rms_treenode_dict(
            model=RMSHost,
            model_filter=host_filter,
            key_scheme='host_id',
            serializer=self.node_serializer.host_node)
        # print 'depth 1 complete'

        if all((parent_node_dict, parent_key_scheme)):
            link_rms_treenode(
                parent_node=parent_node_dict,
                child_node=child_node_dict,
                key=parent_key_scheme)

        return parent_node_dict, child_node_dict

    def build_vip_nodes(self, parent_node_dict=None, parent_key_scheme=None):
        '''
            Build VIP level RMS Treenode and link with parent_node_dict by key_scheme
            if parent_node_dict exists.
        '''

        vip_filter = {}

        if parent_node_dict:
            vip_filter['host__in'] = parent_node_dict.keys()

        child_node_dict = get_rms_treenode_dict(
            model=RMSVip,
            model_filter=vip_filter,
            key_scheme='vip_id',
            serializer=self.node_serializer.vip_node)
        # print 'depth 2 complete'

        if all((parent_node_dict, parent_key_scheme)):
            link_rms_treenode(
                parent_node=parent_node_dict,
                child_node=child_node_dict,
                key=parent_key_scheme)

        return parent_node_dict, child_node_dict

    def build_probe_nodes(self, parent_node_dict=None, parent_key_scheme=None):
        '''
            Build Probe level RMS Treenode and link with parent_node_dict by key_scheme
            if parent_node_dict exists.
        '''

        probe_filter = {}

        if parent_node_dict:
            probe_filter['vip__in'] = parent_node_dict.keys()

        # [PRISMUI-2690]
        # Filtering probes which are set alert through 'RMS Settings & Alerts for probes' menu.
        probe_filter['name__in'] = RMSDisplayProbes.objects.values('probe_name')

        child_node_dict = get_rms_treenode_dict(
            model=RMSVipProbe,
            model_filter=probe_filter,
            key_scheme='vip_probe_id',
            serializer=self.node_serializer.probe_node,
            terminal=True)

        # depth 3-1 : get probe instance's acknowledge status data
        probe_acknowledge_filter = {
            'vip_probe__in': child_node_dict.keys()
        }
        probe_ack_node_dict = get_rms_treenode_dict(
            model=RMSAcknowledge,
            model_filter=probe_acknowledge_filter,
            key_scheme='ack_id',
            serializer=self.node_serializer.probe_ack_node,
            terminal=True)

        # reform probe acknowledge data
        reformed_probe_ack_dict = {}
        for probe_ack_key in probe_ack_node_dict.keys():
            probe_ack_node = probe_ack_node_dict.get(probe_ack_key)
            probe_instance_id = probe_ack_node.get('instance_id')

            if reformed_probe_ack_dict.get(probe_instance_id) is None:
                reformed_probe_ack_dict[probe_instance_id] = []

            reformed_probe_ack_dict[probe_instance_id].append(probe_ack_node)

        # attach probe acknowledge data to probe node
        for probe_node_key in child_node_dict.keys():
            probe_ack_node = reformed_probe_ack_dict.get(probe_node_key)

            child_node_dict[probe_node_key].update({
                'acknowledge': probe_ack_node
            })

        # depth 3-2 : get probe messages
        probe_message_filter = {
            'vip_probe__in': child_node_dict.keys()
        }
        probe_message_node_dict = get_rms_treenode_dict(
            model=RawRMSMessage,
            model_filter=probe_message_filter,
            key_scheme='vip_probe',
            serializer=self.node_serializer.raw_probe_message_node,
            terminal=True)

        # attach probe message data to probe node
        for probe_node_key in child_node_dict.keys():
            message_node = probe_message_node_dict.get(probe_node_key, {})
            child_node_dict[probe_node_key].update(message_node)

        if all((parent_node_dict, parent_key_scheme)):
            link_rms_treenode(
                parent_node=parent_node_dict,
                child_node=child_node_dict,
                key=parent_key_scheme)

        return parent_node_dict, child_node_dict

    def get(self, request):

        rms_treenode_build_sequence = [
            (self.build_pop_nodes, None),
            (self.build_host_nodes, 'pop_id'),
            (self.build_vip_nodes, 'host_id'),
            (self.build_probe_nodes, 'vip_id')
        ]

        build_sequence_length = len(rms_treenode_build_sequence)

        try:
            level_from = int(request.GET['level_from'])
            level_from = clamp(level_from, 0, build_sequence_length)
        except Exception:
            level_from = 0

        try:
            level_to = int(request.GET['level_to']) + 1
            level_to = clamp(level_to, 0, build_sequence_length)
        except Exception:
            level_to = build_sequence_length

        root_node = None
        parent_node_dict = None
        child_node_dict = None

        args = {}

        for index in range(level_from, level_to):

            if child_node_dict:
                args['parent_node_dict'] = child_node_dict
                args['parent_key_scheme'] = rms_treenode_build_sequence[index][1]

            parent_node_dict, child_node_dict = rms_treenode_build_sequence[index][0](**args)

            if parent_node_dict is None:
                root_node = child_node_dict

        serialized_list = {
            'pop_nodes': treenode_to_list(root_node)
        }

        return Response(serialized_list)
