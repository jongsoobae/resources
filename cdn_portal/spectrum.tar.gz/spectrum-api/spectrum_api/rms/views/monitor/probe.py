from rest_framework.status import HTTP_400_BAD_REQUEST
from rest_framework.exceptions import APIException
from rest_framework.response import Response

from spectrum_api.shared_components.generics import SpectrumGenericAPIView


class RMSProbeInfoAPIView(SpectrumGenericAPIView):

    def get(self, request):
        return Response('probe')
