
from rest_framework.response import Response

from spectrum_api.shared_components.generics import SpectrumGenericAPIView

from spectrum_api.rms.models.gslb_rms import RMSDisplayProbes
from spectrum_api.rms.utils.rms_node import RMSNodeSerializerFactory


class RMSSettingAPIView(SpectrumGenericAPIView):

    node_serializer = RMSNodeSerializerFactory()

    def get(self, request):

        probe_name_list = []

        filter_dict = {}
        try:
            probe_name_list = request.GET['probe_name'].split(',')
            filter_dict['probe_name__in'] = probe_name_list

        except Exception:
            pass

        all_settings = RMSDisplayProbes.objects.filter(**filter_dict)

        response = []
        for setting in all_settings:
            response.append(self.node_serializer.rms_setting_node(setting))

        return Response(response)
