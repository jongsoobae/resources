from rest_framework.status import HTTP_400_BAD_REQUEST
from rest_framework.exceptions import APIException
from rest_framework.response import Response

from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.rms.models.rms import RMSPoPStatus
from spectrum_api.rms.serializers.pop_status import RMSPoPStatusSerializer


class RMSPoPStatusAPI400Exception(APIException):
    """
    Note
    ----
    Exception class for bad request(400)
    """
    status_code = HTTP_400_BAD_REQUEST


class RMSPoPStatusAPI(SpectrumGenericAPIView):
    """
    Note
    ----
    API Document URL: https://wiki.cdnetworks.com/confluence/display/engportal/%5BSPECTRUM_API%5D+RMS+PoP+Status+API+Document?moved=true
    """
    dataset = RMSPoPStatus()
    serializer = RMSPoPStatusSerializer

    def get(self, request):
        """
        Note
        ----
        Getting PoP statuses through serializer.

        Parameters
        ----------
        request : class

        Returns
        -------
        Response or RMSPoPStatusAPI400Exception
        """
        serializer_class = self.serializer(data=request.QUERY_PARAMS)

        if serializer_class.is_valid():
            result = self.dataset.get_pop_status_list(**serializer_class.data)
            return Response(result)
        else:
            raise RMSPoPStatusAPI400Exception(serializer_class.errors)
