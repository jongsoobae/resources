from django.db import IntegrityError
from django.db import transaction

from rest_framework.status import HTTP_400_BAD_REQUEST
from rest_framework.exceptions import APIException
from rest_framework.response import Response

from spectrum_api.rms.models.gslb_rms import RMSAcknowledge
from spectrum_api.rms.serializers.rms_snooze import RMSSnoozeAPISerializer
from spectrum_api.rms.serializers.rms_snooze import RMSSnozeReleaseAPISerializer

from spectrum_api.rms.utils.rms_node import RMSNodeSerializerFactory
from spectrum_api.shared_components.generics import SpectrumGenericAPIView


class RMSSnoozeAPIException(APIException):
    status_code = HTTP_400_BAD_REQUEST


class RMSSnoozeAPIView(SpectrumGenericAPIView):

    node_serializer = RMSNodeSerializerFactory()

    def post(self, request):
        ''' Register Snooze '''

        request_serializer = RMSSnoozeAPISerializer
        serializer_instance = request_serializer(data=request.DATA)

        if serializer_instance.is_valid():
            acknowledge_bulk = serializer_instance.object

            response_data = []

            # django 1.3 does not support bulk_create.
            # so using transaction, solve bulk insert.
            with transaction.commit_on_success():
                for acknowledge in acknowledge_bulk:
                    try:
                        exists_acknowledge = RMSAcknowledge.objects.filter(
                            vip_probe=acknowledge.vip_probe, level=acknowledge.level)

                        if not exists_acknowledge:
                            raise RMSAcknowledge.DoesNotExist
                        else:
                            exists_acknowledge.update(ack_type=1, end_date=acknowledge.end_date)
                    except RMSAcknowledge.DoesNotExist:
                        RMSAcknowledge.objects.create(
                            vip_probe=acknowledge.vip_probe, ack_type=1,
                            level=acknowledge.level, end_date=acknowledge.end_date)

                    response_data.append(self.node_serializer.probe_ack_node(acknowledge.__dict__))

            return Response(response_data)

        else:
            raise RMSSnoozeAPIException(serializer_instance.errors)

    def delete(self, request):
        ''' Release Snooze '''

        request_serializer = RMSSnozeReleaseAPISerializer
        serializer_instance = request_serializer(data=request.DATA)

        if serializer_instance.is_valid():
            acknowledge_bulk = serializer_instance.object
            response_data = []

            for acknowledge in acknowledge_bulk:
                response_data.append(acknowledge.vip_probe.vip_probe_id)

            acknowledge_bulk.update(ack_type=4)

            return Response(response_data)

        else:
            raise RMSSnoozeAPIException(serializer_instance.errors)
