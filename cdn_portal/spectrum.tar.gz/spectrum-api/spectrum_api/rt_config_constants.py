ALERTING_RT_QUEUES = (# second value is for display purpose
    ('US :: Incoming', 'US Incoming'),
    ('US :: Alerting', 'US Alerting'),
    ('young-test', 'Test Queue'),
)
