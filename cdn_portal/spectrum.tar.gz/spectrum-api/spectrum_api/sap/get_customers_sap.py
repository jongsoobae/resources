#!/usr/local/cdnet/shared/python/python2.6/bin/python


import os, sys

if os.name == 'nt':
    os.environ['DJANGO_SETTINGS_MODULE'] = 'prism_fe.settings'
    cwd = os.path.abspath(os.path.dirname(__file__))
    cdr = os.path.dirname(os.path.dirname(cwd))
    sys.path.insert(0, cdr)
else:
    sys.path.insert(0, '/usr/local/cdnet/spectrum/prism')
    os.environ['DJANGO_SETTINGS_MODULE'] = 'prism_fe.settings'

import sapnwrfc
from spectrum_api.sap.sap_calls import sync_customer_data, sync_contact_data, use_existing_or_open
from django.contrib.auth.models import User
from spectrum_api.shared_components.models.customer import CustomerAccount

#S-------------------------------- aurora item -----------------------------------
import logging
import logging.handlers

logger = logging.getLogger("simple_example")
logger.setLevel(logging.DEBUG)
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)

if os.name == 'nt':
    fh = logging.FileHandler(cwd + "/batch_sfa_sync.log")
else:
    fh = logging.FileHandler("/usr/local/cdnet/spectrum/prism/spectrum_api.sap/batch_sfa_sync.log")
fh.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s %(levelname)s: %(message)s')
ch.setFormatter(formatter)
fh.setFormatter(formatter)
logger.addHandler(ch)
logger.addHandler(fh)


accounts = None

#E-------------------------------- aurora item -----------------------------------#E-------------------------------- aurora item -----------------------------------
class FakeRequest(object):
    user = None
    META = {'REMOTE_ADDR':'127.0.0.1'}

class Order():
    def __init__(self):
        self.contract_no = ''
        self.item_no = '0'
        self.work_type = '11'


def func_customer_account_sync (request, str_step):
    template1, connection1, close_conn1 = use_existing_or_open('ZSFA_RFC_CUSTOMER_DASHBOAD', connection=None, template=None)
    item = template1.create_function_call()
    item.invoke()
    item.RETURN.value
    msg = ''

    if item.RETURN.value.get('TYPE').strip() in ["", "S"]:
        accounts = item.PT_CUSTOMER.value
        totalcnt = len(accounts)
        cnt = 0
        for account in accounts:
            try:
                try:
                    obj_account = CustomerAccount.objects.get(account_no=int(account.get('KUNNR')))
                    msg = 'updated'
                except Exception, e:
                    obj_account = CustomerAccount()
                    msg = 'created'
                obj_account.account_no = int(account.get('KUNNR'))
                obj_account.account_name_eng = account.get('NAME2').strip()
                obj_account.account_name_local = account.get('NAME1').strip()
                obj_account.sales_org = int(account.get('VKORG'))
                obj_account.save(request=request)
                cnt = cnt + 1
                logger.debug("%s (%s/%s) account was %s : %s" % (str_step, str(cnt), str(totalcnt), msg, account.get('KUNNR').strip()))
            except Exception, e1:
                logger.debug("%s Error Msg[1] : %s" % (str_step, e1.args[0]))
    else:
        logger.debug("%s Error occured from loading SFA(ZSFA_RFC_CUSTOMER_DASHBOAD_US) : %s" % (str_step, item.RETURN.value.get('MESSAGE', "No error message found")))

    if close_conn1:
        connection1.close()

def func_customer_contact_sync1 (request, str_step):
    template = None
    connection = None
    close_conn = None
    msg = ''

    accounts = CustomerAccount.objects.all().values('pk')
    template, connection, close_conn = use_existing_or_open('ZSD_RFC_PERSON_GET_OCSP', connection=None, template=None)
    totalcnt = len(accounts)
    cnt = 0
    for account in accounts:
        try:
            cnt = cnt + 1
            for i in range(3):
                try:
                    data = sync_contact_data(request=request, account_no=account['pk'], connection=connection, template=template)
                    logger.debug("%s (%s/%s) %s contact synced count : %s" % (str_step, str(cnt), str(totalcnt), str(account['pk']).zfill(10), str(data)))
                    break
                except Exception, e:
                    logger.debug("%s (%s/%s) error occured : %s, (%s)" % (str_step, str(cnt), str(totalcnt), str(account['pk']).zfill(10), e.args[0]))
                    connection.close()
                    template = None
                    connection = None
                    close_conn = None
                    template, connection, close_conn = use_existing_or_open('ZSD_RFC_PERSON_GET_OCSP', connection=None, template=None)
        except Exception, e1:
            logger.debug("%s Error Msg[1] : %s" % (str_step, e1.args[0]))

    if close_conn:
        connection.close()


def func_customer_contact_sync (request, str_step):
    template = None
    connection = None
    close_conn = None
    template3, connection3, close_conn3 = use_existing_or_open('ZSFA_RFC_CUSTOMER_DASHBOAD', connection=None, template=None)
    item = template3.create_function_call()
    item.invoke()
    item.RETURN.value
    msg = ''
    if item.RETURN.value.get('TYPE').strip() in ["", "S"]:
        accounts = item.PT_CUSTOMER.value
        template, connection, close_conn = use_existing_or_open('ZSD_RFC_PERSON_GET_OCSP', connection=None, template=None)
        totalcnt = len(accounts)
        cnt = 0
        for account in accounts:
            try:
                cnt = cnt + 1
                for i in range(3):
                    try:
                        data = sync_contact_data(request=request, account_no=account.get('KUNNR').strip(), connection=connection, template=template)
                        logger.debug("%s (%s/%s) %s contact synced count : %s" % (str_step, str(cnt), str(totalcnt), account.get('KUNNR').strip(), str(data)))
                        break
                    except Exception, e:
                        logger.debug("%s (%s/%s) error occured : %s, (%s)" % (str_step, str(cnt), str(totalcnt), account.get('KUNNR').strip(), e.args[0]))
                        connection.close()
                        template = None
                        connection = None
                        close_conn = None
                        template, connection, close_conn = use_existing_or_open('ZSD_RFC_PERSON_GET_OCSP', connection=None, template=None)
            except Exception, e1:
                logger.debug("%s Error Msg[1] : %s" % (str_step, e1.args[0]))
    else:
        logger.debug("%s Error occured from loading SFA(ZSFA_RFC_CUSTOMER_DASHBOAD) : %s" % (str_step, item.RETURN.value.get('MESSAGE', "No error message found")))

    if close_conn:
        connection.close()

    if close_conn3:
        connection3.close()



def func_customer_trial_contract_sync (request, str_step):
    template = None
    connection = None
    close_conn = None
    template2, connection2, close_conn2 = use_existing_or_open('ZSD_RFC_CONTRACT_GET_HL01', connection=None, template=None)
    item = template2.create_function_call()
    item.PS_LOGIN({'BUKRS':'1000', 'LAND1':'KR', 'SPRAS_USE':'3', 'PERNR':'21000097'})
    # a.PS_SHOPT({'KUNNR':'00020133','PERNR':'00000000','TECNO':'00000000' })
    item.P_AUART('YC1')
    item.invoke()
    item.RETURN.value
    order = Order()
    if item.RETURN.value.get('TYPE').strip() in ["", "S"]:
        contracts = item.PT_CONTRACT.value
        template, connection, close_conn = use_existing_or_open('ZSD_COP_CONTRACT_GET', connection=None, template=None)
        totalcnt = len(contracts)
        cnt = 0
        for contract in contracts:
            try:
                order.contract_no = contract.get('VBELN')
                cnt = cnt + 1
                for i in range(3):
                    try:
                        sync_customer_data(request=request, order=order, connection=connection, template=template)
                        logger.debug("%s (%s/%s) contract synced : %s" % (str_step, str(cnt), str(totalcnt), contract.get('VBELN')))
                        break
                    except Exception, e:
                        logger.debug("%s (%s/%s) error occured : %s, (%s)" % (str_step, str(cnt), str(totalcnt), contract.get('VBELN'), e.args[0]))
                        connection.close()
                        template = None
                        connection = None
                        close_conn = None
                        template, connection, close_conn = use_existing_or_open('ZSD_COP_CONTRACT_GET', connection=None, template=None)
            except Exception, e1:
                logger.debug("%s Error Msg[1] : %s" % (str_step, e1.args[0]))
    else:
        logger.debug("%s Error occured from loading SFA(ZSD_RFC_CONTRACT_GET_HL01) : %s" % (str_step, item.RETURN.value.get('MESSAGE', "No error message found")))

    if close_conn:
        connection.close()

    if close_conn2:
        connection2.close()

def func_customer_contract_sync (request, str_step):

    template = None
    connection = None
    close_conn = None
    template2, connection2, close_conn2 = use_existing_or_open('ZSD_RFC_CONTRACT_GET_HL01', connection=None, template=None)
    item = template2.create_function_call()
    item.PS_LOGIN({'BUKRS':'1000', 'LAND1':'KR', 'SPRAS_USE':'3', 'PERNR':'21000097'})
    # a.PS_SHOPT({'KUNNR':'00020133','PERNR':'00000000','TECNO':'00000000' })
    item.P_AUART('YC2')
    item.invoke()
    item.RETURN.value
    order = Order()
    if item.RETURN.value.get('TYPE').strip() in ["", "S"]:
        contracts = item.PT_CONTRACT.value
        template, connection, close_conn = use_existing_or_open('ZSD_COP_CONTRACT_GET', connection=None, template=None)
        totalcnt = len(contracts)
        cnt = 0
        for contract in contracts:
            try:
                order.contract_no = contract.get('VBELN')
                cnt = cnt + 1
                for i in range(3):
                    try:
                        sync_customer_data(request=request, order=order, connection=connection, template=template)
                        logger.debug("%s (%s/%s) contract synced : %s" % (str_step, str(cnt), str(totalcnt), contract.get('VBELN')))
                        break
                    except Exception, e:
                        logger.debug("%s (%s/%s) error occured : %s, (%s)" % (str_step, str(cnt), str(totalcnt), contract.get('VBELN'), e.args[0]))
                        connection.close()
                        template = None
                        connection = None
                        close_conn = None
                        template, connection, close_conn = use_existing_or_open('ZSD_COP_CONTRACT_GET', connection=None, template=None)
            except Exception, e1:
                logger.debug("%s Error Msg[1] : %s" % (str_step, e1.args[0]))
    else:
        logger.debug("%s Error occured from loading SFA(ZSD_RFC_CONTRACT_GET_HL01) : %s" % (str_step, item.RETURN.value.get('MESSAGE', "No error message found")))

    if close_conn:
        connection.close()

    if close_conn2:
        connection2.close()


if __name__ == '__main__':
    request = FakeRequest()
    request.user = User.objects.get(username='sfauser3')  # change from young.park

    str_step = '[Step 1]'
    logger.debug("%s ###### account sync was started               ##############" % (str_step))
    try:
        func_customer_account_sync(request=request, str_step=str_step)
    except Exception, e:
        logger.debug("%s  Error Msg[1] : %s" % (str_step, e.args[0]))

    str_step = '[Step 2]'
    logger.debug("%s ###### contact sync was started               ##############" % (str_step))
    try:
        func_customer_contact_sync(request=request, str_step=str_step)
    except Exception, e:
        logger.debug("%s Error Msg[1] : %s" % (str_step, e.args[0]))

    str_step = '[Step 3]'
    logger.debug("%s ###### trial sync was started                 ##############" % (str_step))
    try:
        func_customer_trial_contract_sync(request=request, str_step=str_step)
    except Exception, e:
        logger.debug("%s Error Msg[1] : %s" % (str_step, e.args[0]))

    str_step = '[Step 4]'
    logger.debug("%s ###### contract and no pay sync was started   ##############" % (str_step))
    try:
        func_customer_contract_sync(request=request, str_step=str_step)
    except Exception, e:
        logger.debug("%s Error Msg[1] : %s" % (str_step, e.args[0]))


