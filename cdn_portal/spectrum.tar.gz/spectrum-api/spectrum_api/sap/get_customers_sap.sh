#!/bin/bash

export PYTHONPATH=$PYTHONPATH:/usr/local/cdnet/spectrum/prism:/usr/local/cdnet/shared/django/Django-1.2.1:/usr/local/cdnet/shared/django/Django-1.2.1/django/bin:/usr/local/cdnet/shared/python/python2.6:/usr/local/cdnet/spectrum/prism
export DJANGO_SETTINGS_MODULE=prism_api.settings

/usr/local/cdnet/spectrum/prism/spectrum_fe/sap/get_customers_sap.py
