import datetime
from spectrum_api.shared_components.models.customer import CustomerAccount, CustomerContract, CustomerItem, CustomerSfaOrder, CustomerDisplay, CustomerContractPartner
from django.utils.encoding import smart_str
from spectrum_api.shared_components.models.dashboard import CustomerContact, CustomerContractContact
from django.conf import settings

class OrderItem():
    def __init__(self, order_no, noti):
        self.order_no = order_no
        self.contract_no = noti.get('LS_KDAUF')
        self.item_no = noti.get('LS_KDPOS')
        self.work_type = noti.get('QMGRP').strip()

def get_connection():
    import os
    import tempfile
    tmpdir = os.getcwd()
    # os.chdir('/tmp')
    os.chdir(tempfile.gettempdir())  # os compatible
    import sapnwrfc
    sapnwrfc.base.config_location = settings.SAPYML_LOCATION
    sapnwrfc.base.load_config()
    os.chdir(tmpdir)
    return sapnwrfc.base.rfc_connect()

def use_existing_or_open(template_name, connection=None, template=None):
    if template and template_name == template.name:
        return (template, connection, False)
    close_conn = False
    if not connection:
        connection = get_connection()
        close_conn = True
    template = connection.discover(template_name)
    return (template, connection, close_conn)

def get_order_information(order_no, connection=None, template=None):
    """takes a order_no and returns a tuple of work_type, contract_no, item_no
    if template is passed will use that, if connection is passed will use that, else will make connection & template"""
    template, connection, close_conn = use_existing_or_open('ZSD_GET_CS', connection=connection, template=template)
    cs = template.create_function_call()
    cs.I_QMNUM(order_no)
    cs.I_SPRAS('E')
    cs.invoke()
    if cs.O_RETURN.value.get('TYPE').strip() not in ["", "S"]:
        raise Exception("Unexpected return type '" + cs.O_RETURN.value.get('TYPE').strip() + "': " + cs.O_RETURN.value.get('MESSAGE', "No error message found"))
    order = OrderItem(order_no, cs.O_NOTI.value)
    if close_conn:
        connection.close()
    return order

def update_sap_cs_stats(request, order_no, status, connection=None, template=None):

    template, connection, close_conn = use_existing_or_open('ZSD_CHANGE_CS_STATS2', connection=connection, template=template)
    zs = template.create_function_call()
    zs.I_QMNUM(str(order_no).zfill(12))
    zs.I_STATS(str(status))  # 9: Completed / 3: Request to Reject / 2: Connection Success
    zs.I_NAME1('Prism API')
    zs.invoke()
    return_val = False
    if zs.O_RETURN.value.get('TYPE').strip() not in ["", "S"]:
        if zs.O_RETURN.value.get('TYPE').strip() == "E":
            try:
                this_order = CustomerSfaOrder.objects.get(csorderno=int(order_no), status=0)
            except:
                this_order = None

            if this_order:
                this_order.status = 9
                this_order.save(request=request)

        raise Exception("Unexpected return type '" + zs.O_RETURN.value.get('TYPE').strip() + "': " + zs.O_RETURN.value.get('MESSAGE', "No error message found"))
    else:
        return_val = True

    if close_conn:
        connection.close()
    return return_val

def update_customer_data(request, order, connection=None, template=None):

    template, connection, close_conn = use_existing_or_open('ZSD_COP_CONTRACT_GET', connection=connection, template=template)
    item = template.create_function_call()
    item.P_SPRAS('E')
    item.P_VBELN(order.contract_no)
    item.P_POSNR(order.item_no)
    item.invoke()
    if item.RETURN.value.get('TYPE').strip() not in ["", "S"]:
        raise Exception("Unexpected return type: " + item.RETURN.value.get('MESSAGE', "No error message found"))

    cop_contracts = item.PT_CONTRACT.value
    cop_contract = cop_contracts[0]

    # first do customer account...
    try:
        account = CustomerAccount.objects.get(account_no=cop_contract['KUNNR'])
    except:
        account = CustomerAccount()
        account.account_no = cop_contract['KUNNR']
    account.account_name_eng = cop_contract.get('NAME2')
    account.account_name_local = cop_contract.get('NAME1')
    account.sales_org = int(int(cop_contract.get('VKORG')))
    account.save(request=request)

    # now do contract...
    try:
        contract = CustomerContract.objects.get(account=account, contract_no=int(cop_contract.get('VBELN')))
    except:
        contract = CustomerContract()
        contract.account = account
        contract.contract_no = int(cop_contract.get('VBELN'))
    contract.contract_name = cop_contract.get('KTEXT', '')
    contract.ocsp_region = int(account.sales_org if cop_contract.get('BZIRK').strip() == '1' and int(account.sales_org) in [1000, 2000, 3000] else 4000)
    contract.service_type = cop_contract.get('BZIRK').strip()
    contract.contract_type = cop_contract.get('AUART').strip()
    start_string = cop_contract.get('GUEBG')
    contract.contract_start = datetime.datetime(int(start_string[0:4]), int(start_string[4:6]), int(start_string[6:8]))
    end_string = cop_contract.get('GUEEN')
    contract.contract_end = datetime.datetime(int(end_string[0:4]), int(end_string[4:6]), int(end_string[6:8]))
    contract.tz_offset = 0
    if contract.ocsp_region in [1000, 2000]:
        contract.tz_offset = 9
    elif contract.ocsp_region == 3000:
        contract.tz_offset = 8
    if order.work_type == '12':
        term_string = cop_contract.get('ENDDT')
        contract.contract_terminate = datetime.datetime(int(term_string[0:4]), int(end_string[4:6]), int(term_string[6:8]))

    if  item.PS_TC_INFO.value.get('TECNM'):
        contract.sales_engineer_name = item.PS_TC_INFO.value.get('TECNM').strip()
    if item.PS_TC_INFO.value.get('TECNO'):
        contract.sales_engineer_no = item.PS_TC_INFO.value.get('TECNO').strip()
    if item.PS_TC_INFO.value.get('TECEM'):
        contract.sales_engineer_email = item.PS_TC_INFO.value.get('TECEM').strip()
    if item.PS_TC_INFO.value.get('TECNM2'):
        contract.sales_engineer_name2 = item.PS_TC_INFO.value.get('TECNM2').strip()
    if item.PS_TC_INFO.value.get('TECNO2'):
        contract.sales_engineer_no2 = item.PS_TC_INFO.value.get('TECNO2').strip()
    if item.PS_TC_INFO.value.get('TECEM2'):
        contract.sales_engineer_email2 = item.PS_TC_INFO.value.get('TECEM2').strip()

    contract.sales_org = int(int(cop_contract.get('VKORG')))

    for i in item.PT_PARTNER.value:
        if i.get('PARVW').strip() == 'VE' and i.get('NAMEP') and  i.get('NAMEV'):
            contract.sales_rep_name = i.get('NAMEP').strip() + " " + i.get('NAMEV').strip()

        if i.get('PARVW').strip() == 'PY' and cop_contract.get('VTWEG').strip() == '12':
            contract.reseller_account_no = int(i.get('KUNNR').strip())

    #S-------------------------------- aurora contract -----------------------------------
    contract.contract_type_tx = cop_contract.get('AUART_TXT').strip()
    contract.sales_org_tx = cop_contract.get('VKORG_TXT').strip()
    contract.market_channel = cop_contract.get('VTWEG').strip()
    contract.market_channel_tx = cop_contract.get('VTWEG_TXT').strip()
    contract.product = cop_contract.get('SPART').strip()
    contract.product_tx = cop_contract.get('SPART_TXT').strip()
    contract.business_place = cop_contract.get('VKBUR').strip()
    contract.business_place_tx = cop_contract.get('VKBUR_TXT').strip()
    contract.business_team = cop_contract.get('VKGRP').strip()
    contract.business_team_tx = cop_contract.get('VKGRP_TXT').strip()
    #E-------------------------------- aurora contract -----------------------------------

    contract.save(request=request)

    #S-------------------------------- aurora contact -----------------------------------
    contractcontactpartnerlist = []
    for i in item.PT_PARTNER.value :
        try:
            obj_partner = CustomerContractPartner.objects.get(contract=contract, partner_type=str(i.get('PARVW').strip()))
            obj_partner.item_no = i.get('POSNR').strip()
            obj_partner.partner_type_tx = i.get('VTEXT').strip()
            obj_partner.suppliers_no = i.get('LIFNR').strip()
            obj_partner.am_no = i.get('PERNR').strip()
            obj_partner.am_name = i.get('NAMES').strip()
            obj_partner.contact_no = i.get('PARNR').strip()
            obj_partner.name1 = i.get('NAMEP').strip()
            obj_partner.name = i.get('NAMEV').strip()
            obj_partner.address = i.get('ADRNR').strip()
            obj_partner.land = i.get('LAND1').strip()
        except:
            obj_partner = CustomerContractPartner (contract=contract,
                                                    partner_type=str(i.get('PARVW').strip()),
                                                    item_no=i.get('POSNR').strip(),
                                                    partner_type_tx=i.get('VTEXT').strip(),
                                                    suppliers_no=i.get('LIFNR').strip(),
                                                    am_no=i.get('PERNR').strip(),
                                                    am_name=i.get('NAMES').strip(),
                                                    contact_no=i.get('PARNR').strip(),
                                                    name1=i.get('NAMEP').strip(),
                                                    name=i.get('NAMEV').strip(),
                                                    address=i.get('ADRNR').strip(),
                                                    land=i.get('LAND1').strip())
        obj_partner.save(request=request)
        contractcontactpartnerlist.append(obj_partner.pk)

    del_partners = CustomerContractPartner.objects.filter(contract=contract).exclude(pk__in=contractcontactpartnerlist)
    for del_partner in del_partners:
        del_partner.delete(request=request)
    #E-------------------------------- aurora contact -----------------------------------

    contractcontactlist = []
    for i in item.PT_PERSON.value :
        try:
            obj_account = CustomerAccount.objects.get(account_no=int(i.get('KUNNR')))
        except:
            obj_account = None

        if obj_account :
            contactlist = []
            contactlist.append(str(i.get('PARNR')))
            # contact_datas = get_contact_data(request, str(i.get('KUNNR')).zfill(10), '', contactlist, connection=None, template=None)

            try:
                contact = CustomerContact.all_objects.get(contact_no=int(i['PARNR']))
                #S-------------------------------- aurora contact -----------------------------------
                contact.first_name = i['NAMEV'].strip()
                contact.last_name = i['NAME1'].strip()
                #E-------------------------------- aurora contact -----------------------------------
                contact.email = i['SMTP_ADDR'].strip()
                contact.phone = i['TELF1'].strip()
                contact.mobile = i['TEL_NUMBER'].strip()
                contact.account = obj_account
                #S-------------------------------- aurora contact -----------------------------------
                contact.contact_role = i['PAFKT'].strip()
                contact.contact_role_desc = i['PAFKT_TXT'].strip()
                contact.use_contact = i['PAVIP'].strip()
                #E-------------------------------- aurora contact -----------------------------------
            except:
                contact = CustomerContact(account=obj_account,
                            contact_no=int(i['PARNR']),
                            #S-------------------------------- aurora contact -----------------------------------
                            first_name=i['NAMEV'].strip(),
                            last_name=i['NAME1'].strip(),
                            #E-------------------------------- aurora contact -----------------------------------
                            email=i['SMTP_ADDR'].strip(),
                            phone=i['TELF1'].strip(),
                            #S-------------------------------- aurora contact -----------------------------------
                            contact_role=i['PAFKT'].strip(),
                            contact_role_desc=i['PAFKT_TXT'].strip(),
                            use_contact=i['PAVIP'].strip(),
                            #E-------------------------------- aurora contact -----------------------------------
                            mobile=i['TEL_NUMBER'].strip())

            if i['PAVIP'].strip() == 'X' :
                contact.obj_state = 0
            else :
                contact.obj_state = 1
            contact.save(request=request)

            try:
                obj_contractcontact = CustomerContractContact.objects.get(contract__contract_no=contract.contract_no, contact__contact_no=contact.contact_no, contact_role=str(i.get('PAFKT')))
            except:
                obj_contractcontact = CustomerContractContact(contract=contract, contact=contact, contact_role=str(i.get('PAFKT')))
            obj_contractcontact.save(request=request)
            contractcontactlist.append(obj_contractcontact.pk)

    del_contractcontacts = CustomerContractContact.objects.filter(contract=contract).exclude(pk__in=contractcontactlist)
    for del_contractcontact in del_contractcontacts:
        del_contractcontact.delete(request=request)

    # now do customer display account (note will add one per ocsp region)
    try:
        customer = CustomerDisplay.objects.get(account=account, ocsp_region=contract.ocsp_region, tz_offset=contract.tz_offset)
    except:
        customer = CustomerDisplay()
        customer.account = account
        customer.ocsp_region = contract.ocsp_region
        customer.tz_offset = contract.tz_offset
        customer.customer_name = account.account_name_local
        customer.save(request=request)

    primary_item = None
    requested_item = None
    created_items = {}
    delayed_parents = {}
    for cop_contract in cop_contracts:
        # now do item...
        try:
            item = CustomerItem.all_objects.get(item_no=int(cop_contract.get('POSNR')), contract=contract)
        except:
            item = CustomerItem()
            item.item_no = int(cop_contract.get('POSNR'))
            item.contract = contract

        # cloud storage billing method added
        try:
            if cop_contract.get('CHARG'):
                item.sales_charge = cop_contract.get('CHARG').strip()
            if cop_contract.get('CHARG_TXT'):
                item.sales_charge_txt = cop_contract.get('CHARG_TXT').strip()
        except:
            pass

        item.service_type = cop_contract.get('BZIRK').strip()
        item.service_type_txt = cop_contract.get('BZIRK_TXT').strip()

        item.material_no = int(cop_contract.get('MATNR'))
        item.material_desc = cop_contract.get('MAKTX')
        item.hierarchy_no = cop_contract.get('PRODH3')
        item.hierarchy_desc = cop_contract.get('PRODH3_TXT')
        parent_item_no = int(cop_contract.get('UEPOS'))
        if  parent_item_no != 0:
            parent = created_items.get(parent_item_no)
            if parent:
                item.parent_item = parent
            else:
                if not delayed_parents.has_key(parent_item_no):
                    delayed_parents[parent_item_no] = []
                delayed_parents[parent_item_no].append(item)
        else:  # if int(cop_contract.get('POSNR')) == int(order.item_no):
            primary_item = item
        if  int(cop_contract.get('POSNR')) == int(order.item_no):
            requested_item = item
        # else:
        #    raise Exception("ERROR?"+  str(order.item_no) +",Parentless Item:"+str(cop_contract.get('POSNR'))+",Requested Item:"+str(order.item_no))


        #S-------------------------------- aurora item -----------------------------------
        item.sales_doc_category = cop_contract.get('PSTYV').strip()
        item.material_tx = cop_contract.get('MAKTX').strip()
        item.price = cop_contract.get('NETPR').strip()
        item.committed_amount = cop_contract.get('NETWR').strip()
        item.currency = cop_contract.get('WAERK').strip()
        item.commitment = cop_contract.get('ZMENG').strip()
        item.unit = cop_contract.get('ZIEME').strip()
        item.status_code = cop_contract.get('ABGRU').strip()
        item.status_code_tx = cop_contract.get('ABGRU_TXT').strip()
        item.billing_method_code = cop_contract.get('PLTYP').strip()
        item.billing_method = cop_contract.get('PLTYP_TXT').strip()
        item.billing_standards = cop_contract.get('KONDM').strip()
        item.billing_standards_tx = cop_contract.get('KONDM_TXT').strip()
        item.relay_traffic = cop_contract.get('MVGR1').strip()
        item.relay_traffic_tx = cop_contract.get('MVGR1_TXT').strip()
        item.weighted_grade_code = cop_contract.get('MVGR2').strip()
        item.weighted_grade_code_tx = cop_contract.get('MVGR2_TXT').strip()
        item.rounding_rule_code = cop_contract.get('MVGR3').strip()
        item.rounding_rule_code_tx = cop_contract.get('MVGR3_TXT').strip()
        item.rounding_unit_code = cop_contract.get('MVGR4').strip()
        item.rounding_unit_code_tx = cop_contract.get('MVGR4_TXT').strip()
        item.option = cop_contract.get('MVGR5').strip()
        item.option_tx = cop_contract.get('MVGR5_TXT').strip()
        item.price_type = cop_contract.get('PROVG').strip()
        item.record_tx = cop_contract.get('PROVG_TXT').strip()
        item.cpu = cop_contract.get('ZCPU').strip()
        item.ram = cop_contract.get('ZRAM').strip()
        item.disk = cop_contract.get('ZDISK').strip()
        item.others = ''
        item.rate = cop_contract.get('RSRAT').strip()
        item.rate_unit = cop_contract.get('KOEIN').strip()
        item.update_orderer = cop_contract.get('UPDKZ').strip()
        item.value_added_service = cop_contract.get('MTPOS').strip()
        item.product = cop_contract.get('SPART').strip()
        item.option_code = cop_contract.get('CHARG').strip()
        item.option_name = cop_contract.get('CHARG_TXT').strip()
        item.sdabw = cop_contract.get('SDABW').strip()
        # item.portal_flag = cop_contract.get('PORTF').strip()
        #E-------------------------------- aurora item -----------------------------------
        item.bill_to_account = int(cop_contract.get('KUNNR_RE').strip())

        # delete_flag = cop_contract.get('ABGRU')
        # if delete_flag == 11 or delete_flag == 92 or delete_flag == 93:
        #    item.obj_state = 0
        # else :
        #    item.obj_state = 1
        item.save(request=request)
        created_items[item.item_no] = item
        for child_item in delayed_parents.get(int(item.item_no), []):
            child_item.parent_item = item
            child_item.save(request=request)

        # if there is one customer_display objects where parent_customer_id is null, insert data into interim (many-to-many) table
        check_customer = CustomerDisplay.objects.filter (account=account, ocsp_region=contract.ocsp_region, parent_customer__isnull=True)
        if check_customer.count() == 1:
            if check_customer[0].items.filter(item_id=item.pk).count() == 0:  # if there is no existing then save
                check_customer[0].items.add(item)
                check_customer[0].save(request=request)

    # now do sfa order...
    try:
        sfaorder = CustomerSfaOrder.objects.get(pk=order.order_no)
        # if no exception orderno is a duplicate....how should we handle? for now ignore
        pass
    except:
        sfaorder = CustomerSfaOrder()
        sfaorder.csorderno = order.order_no
    sfaorder.item = requested_item
    sfaorder.work_type = order.work_type
    sfaorder.save(request=request)
    if close_conn:
        connection.close()
    return primary_item

def create_contact_data(request, account_no, contact, connection=None, template=None):
    template, connection, close_conn = use_existing_or_open('ZSD_RFC_PERSON_CREATE_OCSP', connection=connection, template=template)
    item = template.create_function_call()
    item.PS_LOGIN({'BUKRS':'1000', 'LAND1':'KR', 'SPRAS_USE':'3', 'PERNR':'21000097'})
    # item.P_KUNNR('20133')
    item.P_KUNNR(str(account_no))
    # item.PS_PERSON({'KUNNR':'4120','PARNR':'','PAFKT':'Z2','NAMEV':'CHRIS1','NAME1':'LIEBMAN1','TITEL_AP':'manager','SMTP_ADDR':'enmaster@dreawiz.com','TELF1':'02-333-3333','TEL_NUMBER':'010-00022-222'})
    item.PS_PERSON(contact)  # for structure
    item.invoke()
    return_val = 0
    if item.RETURN.value.get('TYPE').strip() not in ["", "S"]:
        raise Exception("Unexpected return type: " + item.RETURN.value.get('MESSAGE', "No error message found"))

    return_val = item.P_PARNR.value
    if close_conn:
        connection.close()
    return return_val

def update_contact_data(request, account_no, contact, connection=None, template=None):
    template, connection, close_conn = use_existing_or_open('ZSD_RFC_PERSON_CHANGE_OCSP', connection=connection, template=template)
    item = template.create_function_call()
    item.PS_LOGIN({'BUKRS':'1000', 'LAND1':'KR', 'SPRAS_USE':'3', 'PERNR':'21000097'})
    # item.P_KUNNR('20133')
    item.P_KUNNR(str(account_no))
    # item.PS_PERSON({'KUNNR':'20133','PARNR':'','PAFKT':'Z2','NAMEV':'CHRIS1','NAME1':'LIEBMAN1'})
    # item.PS_PERSON({'KUNNR':'20133','PARNR':'47859','PAFKT':'Z2','NAMEV':'CHRIS9','NAME1':'LIEBMAN9','TITEL_AP':'manager','SMTP_ADDR':'enmaster19@dreawiz.com','TELF1':'02-333-3333','TEL_NUMBER':'010-00022-222'})
    item.PS_PERSON(contact)  # for structure
    item.invoke()
    return_val = True
    if item.RETURN.value.get('TYPE').strip() not in ["", "S"]:
        raise Exception("Unexpected return type: " + item.RETURN.value.get('MESSAGE', "No error message found"))

    if close_conn:
        connection.close()
    return return_val

def change_contract_contact_data(request, account_no, contract, select_contact, connection=None, template=None):
    if contract.sales_org in [1000, 2000, 3000]:
        template_name = 'ZSD_RFC_CONTRACT_CHANGE09'
    else:
        template_name = 'ZSD_RFC_CONTRACT_CHANGE09_US'

    template, connection, close_conn = use_existing_or_open(template_name, connection=connection, template=template)
    item = template.create_function_call()
    item.PS_LOGIN({'BUKRS':'1000', 'LAND1':'KR', 'SPRAS_USE':'3', 'PERNR':'21000097'})
    # item.PS_CONTRACT_HEAD({'VBELN':'0040007269','KUNNR':'20133'}) # should be text type like as '0040007269', not '40007269'
    item.PS_CONTRACT_HEAD({'VBELN':str(contract.contract_no).zfill(10), 'KUNNR':str(account_no)})
    # item.PT_PERSON([{'KUNNR':'20133','PARNR':'47859','PAFKT':'Z2','NAMEV':'CHRIS','NAME1':'LIEBMAN'},
    #                {'KUNNR':'20133','PARNR':'14711','PAFKT':'Z2','NAMEV':'Jay','NAME1':'Budzik'}])
    item.PT_PERSON(select_contact)  # for table
    item.invoke()
    return_val = True
    if item.RETURN.value.get('TYPE').strip() not in ["", "S"]:
        raise Exception("Unexpected return type: " + item.RETURN.value.get('MESSAGE', "No error message found"))

    if close_conn:
        connection.close()
    return return_val

# select_contact = ["0000014710", "0000014711"]
def get_contact_data(request, account_no, contact_no, select_contact, connection=None, template=None):
    template, connection, close_conn = use_existing_or_open('ZSD_RFC_PERSON_GET_OCSP', connection=connection, template=template)
    item = template.create_function_call()
    item.PS_LOGIN({'BUKRS':'1000', 'LAND1':'KR', 'SPRAS_USE':'3', 'PERNR':'21000097'})
    item.P_KUNNR(str(account_no).zfill(10))  # should be text type like as '0000020133', not '20133'
    item.P_PARNR(str(contact_no))  # should be text type like as '48975'
    item.invoke()
    if item.RETURN.value.get('TYPE').strip() not in ["", "S"]:
        raise Exception("Unexpected return type: " + item.RETURN.value.get('MESSAGE', "No error message found"))

    data = []
    persons = item.PT_PERSONS.value
    for person in persons:
        if person.get('PARNR').strip() in select_contact:
            data.append({'KUNNR':person.get('KUNNR').strip(),
                         'PARNR':person.get('PARNR').strip(),
                         'PAFKT':'Z2',
                         'NAMEV':person.get('NAMEV').strip(),
                         'NAME1':person.get('NAME1').strip(),
                         'TITEL_AP':person.get('TITEL_AP').strip(),
                         'SMTP_ADDR':person.get('SMTP_ADDR').strip(),
                         'TELF1':person.get('TELF1').strip(),
                         'TEL_NUMBER':person.get('TEL_NUMBER').strip()})


    if close_conn:
        connection.close()
    return data

# type 1:only contract, 2:include contact
def sync_customer_data(request, order, type=1, connection=None, template=None):
    # #
    template, connection, close_conn = use_existing_or_open('ZSD_COP_CONTRACT_GET', connection=connection, template=template)
    item = template.create_function_call()
    item.P_SPRAS('E')
    item.P_VBELN(str(order.contract_no))
    item.P_POSNR(str(order.item_no))
    item.invoke()
    if item.RETURN.value.get('TYPE').strip() not in ["", "S"]:
        raise Exception("Unexpected return type: " + item.RETURN.value.get('MESSAGE', "No error message found"))

    cop_contracts = item.PT_CONTRACT.value
    cop_contract = cop_contracts[0]
    # first do customer account...
    try:
        account = CustomerAccount.objects.get(account_no=cop_contract['KUNNR'])
    except:
        account = CustomerAccount()
        account.account_no = cop_contract['KUNNR']
    account.account_name_eng = cop_contract.get('NAME2')
    account.account_name_local = cop_contract.get('NAME1')
    account.sales_org = int(int(cop_contract.get('VKORG')))
    account.save(request=request)
    # print str(type)
    if str(type) == '2':
        # print 'exe ' + cop_contract['KUNNR'].strip()
        sync_contact_data(request, cop_contract['KUNNR'].strip(), connection=connection)

    # now do contract...
    is_update = False
    try:
        contract = CustomerContract.objects.get(account=account, contract_no=int(cop_contract.get('VBELN')))
        is_update = True
    except:
        contract = CustomerContract()
        contract.account = account
        contract.contract_no = int(cop_contract.get('VBELN'))
    contract.contract_name = cop_contract.get('KTEXT', '')
    contract.ocsp_region = int(account.sales_org if cop_contract.get('BZIRK').strip() == '1' and int(account.sales_org) in [1000, 2000, 3000] else 4000)
    contract.service_type = cop_contract.get('BZIRK').strip()
    contract.contract_type = cop_contract.get('AUART').strip()
    start_string = cop_contract.get('GUEBG')
    contract.contract_start = datetime.datetime(int(start_string[0:4]), int(start_string[4:6]), int(start_string[6:8]))
    end_string = cop_contract.get('GUEEN')
    if is_update:  # check if contract_end is updated and renewed, then nullify and initialize contract_teminate
        previous_contract_end = contract.contract_end
        try :
            contract.contract_end = datetime.datetime(int(end_string[0:4]), int(end_string[4:6]), int(end_string[6:8]))
            if contract.contract_end > datetime.datetime.fromordinal(previous_contract_end.toordinal()):
                contract.contract_terminate = None
        except:
            pass
    else:
        contract.contract_end = datetime.datetime(int(end_string[0:4]), int(end_string[4:6]), int(end_string[6:8]))

    contract.tz_offset = 0
    if contract.ocsp_region in [1000, 2000]:
        contract.tz_offset = 9
    elif contract.ocsp_region == 3000:
        contract.tz_offset = 8
    if order.work_type == '12':
        term_string = cop_contract.get('ENDDT')
        contract.contract_terminate = datetime.datetime(int(term_string[0:4]), int(end_string[4:6]), int(term_string[6:8]))

    if item.PS_TC_INFO.value.get('TECNM'):
        contract.sales_engineer_name = item.PS_TC_INFO.value.get('TECNM').strip()
    if item.PS_TC_INFO.value.get('TECNO'):
        contract.sales_engineer_no = item.PS_TC_INFO.value.get('TECNO').strip()
    if item.PS_TC_INFO.value.get('TECEM'):
        contract.sales_engineer_email = item.PS_TC_INFO.value.get('TECEM').strip()

    if item.PS_TC_INFO.value.get('TECNM2'):
        contract.sales_engineer_name2 = item.PS_TC_INFO.value.get('TECNM2').strip()
    if item.PS_TC_INFO.value.get('TECNO2'):
        contract.sales_engineer_no2 = item.PS_TC_INFO.value.get('TECNO2').strip()
    if item.PS_TC_INFO.value.get('TECEM2'):
        contract.sales_engineer_email2 = item.PS_TC_INFO.value.get('TECEM2').strip()

    contract.sales_org = int(int(cop_contract.get('VKORG')))

    for i in item.PT_PARTNER.value:
        if i.get('PARVW').strip() == 'VE' and i.get('NAMEP') and  i.get('NAMEV'):
            contract.sales_rep_name = i.get('NAMEP').strip() + " " + i.get('NAMEV').strip()
#
        if i.get('PARVW').strip() == 'RG' and cop_contract.get('VTWEG').strip() == '12':
            contract.reseller_account_no = int(i.get('KUNNR').strip())

    #S-------------------------------- aurora contract -----------------------------------
    contract.contract_type_tx = cop_contract.get('AUART_TXT').strip()
    contract.sales_org_tx = cop_contract.get('VKORG_TXT').strip()
    contract.market_channel = cop_contract.get('VTWEG').strip()
    contract.market_channel_tx = cop_contract.get('VTWEG_TXT').strip()
    contract.product = cop_contract.get('SPART').strip()
    contract.product_tx = cop_contract.get('SPART_TXT').strip()
    contract.business_place = cop_contract.get('VKBUR').strip()
    contract.business_place_tx = cop_contract.get('VKBUR_TXT').strip()
    contract.business_team = cop_contract.get('VKGRP').strip()
    contract.business_team_tx = cop_contract.get('VKGRP_TXT').strip()
    #E-------------------------------- aurora contract -----------------------------------
    contract.save(request=request)
    #S-------------------------------- aurora contact -----------------------------------
    contractcontactpartnerlist = []
    for i in item.PT_PARTNER.value :
        try:
            obj_partner = CustomerContractPartner.objects.get(contract=contract, partner_type=str(i.get('PARVW').strip()))
            obj_partner.item_no = i.get('POSNR').strip()
            obj_partner.partner_type_tx = i.get('VTEXT').strip()
            obj_partner.suppliers_no = i.get('LIFNR').strip()
            obj_partner.am_no = i.get('PERNR').strip()
            obj_partner.am_name = i.get('NAMES').strip()
            obj_partner.contact_no = i.get('PARNR').strip()
            obj_partner.name1 = i.get('NAMEP').strip()
            obj_partner.name = i.get('NAMEV').strip()
            obj_partner.address = i.get('ADRNR').strip()
            obj_partner.land = i.get('LAND1').strip()
        except:
            obj_partner = CustomerContractPartner (contract=contract,
                                partner_type=str(i.get('PARVW').strip()),
                                item_no=i.get('POSNR').strip(),
                                partner_type_tx=i.get('VTEXT').strip(),
                                suppliers_no=i.get('LIFNR').strip(),
                                am_no=i.get('PERNR').strip(),
                                am_name=i.get('NAMES').strip(),
                                contact_no=i.get('PARNR').strip(),
                                name1=i.get('NAMEP').strip(),
                                name=i.get('NAMEV').strip(),
                                address=i.get('ADRNR').strip(),
                                land=i.get('LAND1').strip())
        obj_partner.save(request=request)
        contractcontactpartnerlist.append(obj_partner.pk)

    del_partners = CustomerContractPartner.objects.filter(contract=contract).exclude(pk__in=contractcontactpartnerlist)
    for del_partner in del_partners:
        del_partner.delete(request=request)
    #E-------------------------------- aurora contact -----------------------------------

    contractcontactlist = []
    for i in item.PT_PERSON.value :
        try:
            obj_account = CustomerAccount.objects.get(account_no=int(i.get('KUNNR')))
        except:
            obj_account = None

        if obj_account :
            contactlist = []
            contactlist.append(str(i.get('PARNR')))
            # contact_datas = get_contact_data(request, str(i.get('KUNNR')).zfill(10), '', contactlist, connection=None, template=None)

            try:
                contact = CustomerContact.objects.get(contact_no=int(i['PARNR']))
                #S-------------------------------- aurora contact -----------------------------------
                contact.first_name = i['NAMEV'].strip()
                contact.last_name = i['NAME1'].strip()
                #E-------------------------------- aurora contact -----------------------------------
                contact.email = i['SMTP_ADDR'].strip()
                contact.phone = i['TELF1'].strip()
                contact.mobile = i['TEL_NUMBER'].strip()
                contact.account = obj_account
                #S-------------------------------- aurora contact -----------------------------------
                contact.contact_role = i['PAFKT'].strip()
                contact.contact_role_desc = i['PAFKT_TXT'].strip()
                contact.use_contact = i['PAVIP'].strip()
                #E-------------------------------- aurora contact -----------------------------------
            except:
                contact = CustomerContact(account=obj_account,
                            contact_no=int(i['PARNR']),
                            #S-------------------------------- aurora contact -----------------------------------
                            first_name=i['NAMEV'].strip(),
                            last_name=i['NAME1'].strip(),
                            #E-------------------------------- aurora contact -----------------------------------
                            email=i['SMTP_ADDR'].strip(),
                            phone=i['TELF1'].strip(),
                            #S-------------------------------- aurora contact -----------------------------------
                            contact_role=i['PAFKT'].strip(),
                            contact_role_desc=i['PAFKT_TXT'].strip(),
                            use_contact=i['PAVIP'].strip(),
                            #E-------------------------------- aurora contact -----------------------------------
                            mobile=i['TEL_NUMBER'].strip())
            contact.save(request=request)

            try:
                obj_contractcontact = CustomerContractContact.objects.get(contract__contract_no=contract.contract_no, contact__contact_no=contact.contact_no, contact_role=str(i.get('PAFKT')))
            except:
                obj_contractcontact = CustomerContractContact(contract=contract, contact=contact, contact_role=str(i.get('PAFKT')))
            obj_contractcontact.save(request=request)
            contractcontactlist.append(obj_contractcontact.pk)

    del_contractcontacts = CustomerContractContact.objects.filter(contract=contract).exclude(pk__in=contractcontactlist)
    for del_contractcontact in del_contractcontacts:
        del_contractcontact.delete(request=request)

    # now do customer display account (note will add one per ocsp region)
    try:
        customer = CustomerDisplay.objects.get(account=account, ocsp_region=contract.ocsp_region, tz_offset=contract.tz_offset)
    except:
        customer = CustomerDisplay()
        customer.account = account
        customer.ocsp_region = contract.ocsp_region
        customer.tz_offset = contract.tz_offset
        customer.customer_name = account.account_name_local
        customer.save(request=request)

    primary_item = None
    requested_item = None
    created_items = {}
    delayed_parents = {}

    for cop_contract in cop_contracts:
        # now do item...
        try:
            item = CustomerItem.all_objects.get(item_no=int(cop_contract.get('POSNR')), contract=contract)
        except Exception , e:
            item = CustomerItem()
            item.item_no = int(cop_contract.get('POSNR'))
            item.contract = contract

        # cloud storage billing method added
        try:
            if cop_contract.get('CHARG'):
                item.sales_charge = cop_contract.get('CHARG').strip()
            if cop_contract.get('CHARG_TXT'):
                item.sales_charge_txt = cop_contract.get('CHARG_TXT').strip()
        except:
            pass

        item.service_type = cop_contract.get('BZIRK').strip()
        item.service_type_txt = cop_contract.get('BZIRK_TXT').strip()

        item.material_no = int(cop_contract.get('MATNR'))
        item.material_desc = cop_contract.get('MAKTX')
        item.hierarchy_no = cop_contract.get('PRODH3')
        item.hierarchy_desc = cop_contract.get('PRODH3_TXT')
        parent_item_no = int(cop_contract.get('UEPOS'))
        if  parent_item_no != 0:
            parent = created_items.get(parent_item_no)
            if parent:
                item.parent_item = parent
            else:
                if not delayed_parents.has_key(parent_item_no):
                    delayed_parents[parent_item_no] = []
                delayed_parents[parent_item_no].append(item)
        else:  # if int(cop_contract.get('POSNR')) == int(order.item_no):
            primary_item = item

        if  int(cop_contract.get('POSNR')) == int(order.item_no):
            requested_item = item
        # else:
        #    raise Exception("ERROR?"+  str(order.item_no) +",Parentless Item:"+str(cop_contract.get('POSNR'))+",Requested Item:"+str(order.item_no))

        #S-------------------------------- aurora item -----------------------------------
        item.sales_doc_category = cop_contract.get('PSTYV').strip()
        item.material_tx = cop_contract.get('MAKTX').strip()
        item.price = cop_contract.get('NETPR').strip()
        item.committed_amount = cop_contract.get('NETWR').strip()
        item.currency = cop_contract.get('WAERK').strip()
        item.commitment = cop_contract.get('ZMENG').strip()
        item.unit = cop_contract.get('ZIEME').strip()
        item.status_code = cop_contract.get('ABGRU').strip()
        item.status_code_tx = cop_contract.get('ABGRU_TXT').strip()
        item.billing_method_code = cop_contract.get('PLTYP').strip()
        item.billing_method = cop_contract.get('PLTYP_TXT').strip()
        item.billing_standards = cop_contract.get('KONDM').strip()
        item.billing_standards_tx = cop_contract.get('KONDM_TXT').strip()
        item.relay_traffic = cop_contract.get('MVGR1').strip()
        item.relay_traffic_tx = cop_contract.get('MVGR1_TXT').strip()
        item.weighted_grade_code = cop_contract.get('MVGR2').strip()
        item.weighted_grade_code_tx = cop_contract.get('MVGR2_TXT').strip()
        item.rounding_rule_code = cop_contract.get('MVGR3').strip()
        item.rounding_rule_code_tx = cop_contract.get('MVGR3_TXT').strip()
        item.rounding_unit_code = cop_contract.get('MVGR4').strip()
        item.rounding_unit_code_tx = cop_contract.get('MVGR4_TXT').strip()
        item.option = cop_contract.get('MVGR5').strip()
        item.option_tx = cop_contract.get('MVGR5_TXT').strip()
        item.price_type = cop_contract.get('PROVG').strip()
        item.record_tx = cop_contract.get('PROVG_TXT').strip()
        item.cpu = cop_contract.get('ZCPU').strip()
        item.ram = cop_contract.get('ZRAM').strip()
        item.disk = cop_contract.get('ZDISK').strip()
        item.others = ''
        item.rate = cop_contract.get('RSRAT').strip()
        item.rate_unit = cop_contract.get('KOEIN').strip()
        item.update_orderer = cop_contract.get('UPDKZ').strip()
        item.value_added_service = cop_contract.get('MTPOS').strip()
        item.product = cop_contract.get('SPART').strip()
        item.option_code = cop_contract.get('CHARG').strip()
        item.option_name = cop_contract.get('CHARG_TXT').strip()
        item.sdabw = cop_contract.get('SDABW').strip()
        # item.portal_flag = cop_contract.get('PORTF').strip()
        #E-------------------------------- aurora item -----------------------------------
        item.bill_to_account = int(cop_contract.get('KUNNR_RE').strip())

        # delete_flag = cop_contract.get('ABGRU')
        # if delete_flag == 11 or delete_flag == 92 or delete_flag == 93:
        #    item.obj_state = 0
        # else :
        #    item.obj_state = 1
        item.save(request=request)

        created_items[item.item_no] = item
        for child_item in delayed_parents.get(int(item.item_no), []):
            child_item.parent_item = item
            child_item.save(request=request)

        # if there is one customer_display objects where parent_customer_id is null, insert data into interim (many-to-many) table
        check_customer = CustomerDisplay.objects.filter(account=account, ocsp_region=contract.ocsp_region, parent_customer__isnull=True)
        if check_customer.count() == 1:
            if check_customer[0].items.filter(item_id=item.pk).count() == 0:  # if there is no existing then save
                check_customer[0].items.add(item)
                check_customer[0].save(request=request)

    if close_conn:
        connection.close()
    return

def sync_contact_data(request, account_no, connection=None, template=None):
    # #
    template, connection, close_conn = use_existing_or_open('ZSD_RFC_PERSON_GET_OCSP', connection=connection, template=template)
    item = template.create_function_call()
    # item.PS_LOGIN({'BUKRS':'1000','LAND1':'KR','SPRAS_USE':'3', 'PERNR':'21000097'})
    item.P_KUNNR(str(account_no).zfill(10))  # should be text type like as '0000020133', not '20133'
    item.P_PARNR('')  # should be text type like as '48975'
    item.invoke()
    if item.RETURN.value.get('TYPE').strip() not in ["", "S"]:
        raise Exception("Unexpected return type: " + item.RETURN.value.get('MESSAGE', "No error message found"))

    data = 0
    persons = item.PT_PERSONS.value

    for person in persons:
        try:
            obj_account = CustomerAccount.objects.get(account_no=int(person.get('KUNNR')))
        except:
            obj_account = None

        if obj_account :
            try:
                contact = CustomerContact.all_objects.get(contact_no=int(person.get('PARNR')))
                contact.first_name = person.get('NAMEV').strip()
                contact.last_name = person.get('NAME1').strip()
                contact.title = person.get('TITEL_AP').strip()
                contact.email = person.get('SMTP_ADDR').strip()
                contact.phone = person.get('TELF1').strip()
                contact.mobile = person.get('TEL_NUMBER').strip()
                contact.account = obj_account
                #S-------------------------------- aurora contact -----------------------------------
                contact.contact_role = person.get('PAFKT').strip()
                contact.contact_role_desc = person.get('PAFKT_TXT').strip()
                contact.use_contact = person.get('PAVIP').strip()
                #E-------------------------------- aurora contact -----------------------------------
            except:
                contact = CustomerContact(account=obj_account,
                                contact_no=int(person.get('PARNR')),
                                first_name=person.get('NAMEV').strip(),
                                last_name=person.get('NAME1').strip(),
                                title=person.get('TITEL_AP').strip(),
                                email=person.get('SMTP_ADDR').strip(),
                                phone=person.get('TELF1').strip(),
                                #S-------------------------------- aurora contact -----------------------------------
                                contact_role=person.get('PAFKT').strip(),
                                contact_role_desc=person.get('PAFKT_TXT').strip(),
                                use_contact=person.get('PAVIP').strip(),
                                #E-------------------------------- aurora contact -----------------------------------
                                mobile=person.get('TEL_NUMBER').strip())

            if person.get('PAVIP').strip() == 'X' :
                contact.obj_state = 0
            else :
                contact.obj_state = 1
            contact.save(request=request)
            data = data + 1

    if close_conn:
        connection.close()
    return data

def _get_account_contact_data(request, account_no, connection=None, template=None):
    # #
    template, connection, close_conn = use_existing_or_open('ZSD_RFC_PERSON_GET_OCSP', connection=connection, template=template)
    item = template.create_function_call()
    # item.PS_LOGIN({'BUKRS':'1000','LAND1':'KR','SPRAS_USE':'3', 'PERNR':'21000097'})
    item.P_KUNNR(str(account_no).zfill(10))  # should be text type like as '0000020133', not '20133'
    item.P_PARNR('')  # should be text type like as '48975'
    item.invoke()
    if item.RETURN.value.get('TYPE').strip() not in ["", "S"]:
        raise Exception("Unexpected return type: " + item.RETURN.value.get('MESSAGE', "No error message found"))

    data = []
    persons = item.PT_PERSONS.value
    for person in persons:
        data.append({'KUNNR':person.get('KUNNR').strip(),
                     'PARNR':person.get('PARNR').strip(),
                     'PAFKT':'Z2',
                     'NAMEV':smart_str(person.get('NAMEV').strip()),
                     'NAME1':smart_str(person.get('NAME1').strip()),
                     'TITEL_AP':smart_str(person.get('TITEL_AP').strip()),
                     'SMTP_ADDR':person.get('SMTP_ADDR').strip(),
                     'TELF1':person.get('TELF1').strip(),
                     'TEL_NUMBER':person.get('TEL_NUMBER').strip()})
    if close_conn:
        connection.close()
    return data

def get_account_contact_data(request, account_no, connection=None, template=None):
    template, connection, close_conn = use_existing_or_open('ZSD_RFC_CUSTOMER_GET_COP', connection=connection, template=template)
    item = template.create_function_call()
    item.P_KUNNR(str(account_no).zfill(10))  # should be text type like as '0000020133', not '20133'
    item.invoke()
    if item.RETURN.value.get('TYPE').strip() not in ["", "S"]:
        raise Exception("Unexpected return type: " + item.RETURN.value.get('MESSAGE', "No error message found"))

    customers = item.PT_CUSTOMER.value
    customer = customers[0]
    contactdatas = _get_account_contact_data(request, customer['KUNNR'].strip(), connection=connection)

    if close_conn:
        connection.close()

    return contactdatas

def sync_account_data(request, account_no, connection=None, template=None):
    template, connection, close_conn = use_existing_or_open('ZSD_RFC_CUSTOMER_GET_COP', connection=connection, template=template)
    item = template.create_function_call()
    # item.PS_LOGIN({'BUKRS':'1000','LAND1':'KR','SPRAS_USE':'3', 'PERNR':'21000097'})
    item.P_KUNNR(str(account_no).zfill(10))  # should be text type like as '0000020133', not '20133'
    item.invoke()
    if item.RETURN.value.get('TYPE').strip() not in ["", "S"]:
        raise Exception("Unexpected return type: " + item.RETURN.value.get('MESSAGE', "No error message found"))

    customers = item.PT_CUSTOMER.value
    customer = customers[0]

    # first do customer account...
    try:
        account = CustomerAccount.objects.get(account_no=customer.get('KUNNR').strip())
    except:
        account = CustomerAccount()
        account.account_no = customer.get('KUNNR').strip()
    account.account_name_eng = customer.get('NAME2').strip()
    account.account_name_local = customer.get('NAME1').strip()
    account.sales_org = int(int(customer.get('VKORG')))
    account.save(request=request)

    sync_contact_data(request, customer['KUNNR'].strip(), connection=connection)

    if close_conn:
        connection.close()


if __name__ == '__main__':
    import sys
    class A():
        pass
    from django.contrib.auth.models import User
    request = A()
    request.user = User.objects.all()[0]
    request.META = {'REMOTE_ADDR':'127.0.0.1'}
    c = get_connection()
    order = get_order_information(sys.argv[1], connection=c)
    item = update_customer_data(request, order, connection=c)
    print item.contract.account.account_name_eng
    print item.contract.account.account_name_local
    print item.contract.contract_name
    print item.material_desc
    print item.hierarchy_desc
    print item.item_no
    print "success"
    c.close()
