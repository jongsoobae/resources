# -*- coding: utf-8 -*-
# Django settings for ngp_portal project.
import os
import sys

ROOT = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, os.path.dirname(ROOT))

from spectrum_api import __version__

import config_constants
import config_db_constants

IS_PRODUCTION = config_constants.IS_PRODUCTION
DEBUG = config_constants.DEBUG
TEMPLATE_DEBUG = DEBUG
PROJECT_NAME = 'spectrum_api'
PROJECT_LOCATION = ROOT + '/'

VERSION_NUMBER = __version__
AURORA_URL= "https://control.cdnetworks.com/"

DATABASES = {
    'default':config_db_constants.DEFAULT,
    'aurora':config_db_constants.AURORA,
    'read-only':config_db_constants.READONLY,
    'stats':config_db_constants.STATS,
    'centraldb':config_db_constants.CENTRALDB,
    'fulmendb':config_db_constants.FULMENDB,
    'one_stat':config_db_constants.ONE_STAT,
    'legacy_stat':config_db_constants.LEGACY_STAT,
    'spectrum':config_db_constants.SPECTRUM,
}

DATABASE_ROUTERS = ['spectrum_api.shared_components.routers.SpectrumRouter']

ADMINS = config_constants.ADMINS
MANAGERS = ADMINS

EMAIL_ALERTS = config_constants.EMAIL_ALERTS

TIME_ZONE = None

# Language code for this installation. All choices can be found here:
# http://www.i18nguy.com/unicode/language-identifiers.html
LANGUAGE_CODE = 'en-us'

LOCALE_PATHS = (
    PROJECT_LOCATION + 'locale/',
)

SITE_ID = 1

# If you set this to False, Django will make some optimizations so as not
# to load the internationalization machinery.
USE_I18N = True

_ = lambda s:s
LANGUAGES = (
    ('ko_kr', _('Korean')),
    ('en_us', _('English')),
)

MEDIA_ROOT = PROJECT_LOCATION + 'resources/'

# URL that handles the media served from MEDIA_ROOT. Make sure to use a
# trailing slash if there is a path component (optional in other cases).
# Examples: "http://media.lawrence.com", "http://example.com/media/"
MEDIA_URL = '/op_media/'
ADMIN_MEDIA_PREFIX = '/media/'

# Make this unique, and don't share it with anybody.
SECRET_KEY = 'r*a9b)h-_(*mp($ecdw=%&$td*ojcxh31r0x%rzyue0c$0$j&n'

# List of callables that know how to import templates from various sources.
TEMPLATE_LOADERS = (
    'django.template.loaders.filesystem.Loader',
    'django.template.loaders.app_directories.Loader',
)

MIDDLEWARE_CLASSES = (
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.locale.LocaleMiddleware',
    PROJECT_NAME + '.shared_components.middleware.RequestIDMiddleware',
    PROJECT_NAME + '.shared_components.backends.set_lang.SetLang',
)

ROOT_URLCONF = PROJECT_NAME + '.urls'

TEMPLATE_DIRS = (
    # Put strings here, like "/home/html/django_templates" or "C:/www/django/templates".
    # Always use forward slashes, even on Windows.
    # Don't forget to use absolute paths, not relative paths.
    PROJECT_LOCATION + '/shared_components/templates/',
    os.path.join(os.path.dirname(__file__), 'templates').replace('\\', '/'),
)

INSTALLED_APPS = (
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.sessions',
    'django.contrib.humanize',
    'rest_framework',
    'rest_framework.authtoken',
)

if os.name == 'nt':
    LOG_FILE = "D:/spectrum_api/spectrum_api/spectrum_api.log"
    DEBUG_LOG_FILE = "D:/spectrum_api/spectrum_api/spectrum_api_debug.log"
else:
    LOG_FILE = "/usr/local/cdnet/logs/spectrum_api/spectrum_api.log"
    DEBUG_LOG_FILE = "/usr/local/cdnet/logs/spectrum_api/spectrum_api_debug.log"

LOGGING = {
        'version': 1,
        'disable_existing_loggers': True,
        'filters': {
                    'require_debug_false': {
                                            '()': 'spectrum_api.shared_components.utils.logger.RequireDebugFalse',
                                            },
                    'require_debug_true': {
                                           '()': 'spectrum_api.shared_components.utils.logger.RequireDebugTrue',
                                           },
                    },
        'formatters': {
                    'spectrum_logging': {
                                'format': '%(levelname)s [%(asctime)s] [%(requestpath)s] '
                                            '[%(filename)s, %(funcName)s, %(lineno)s] '
                                            '[%(process)d, %(thread)d] [%(message)s] '
                                            '[%(requestuser)s:%(app_name)s:%(actualuser)s:%(actualuserip)s] '
                                            '[%(requestmethod)s:%(requestmeta)s:%(requestparams)s] '
                                            '[%(responsecode)s:%(responsedetail)s:%(responsedump)s]',
                                'datefmt':'%Y-%m-%d %H:%M:%S'
                    },
         },
        'handlers': {
                'null': {
                                'level':'DEBUG',
                                'class':'django.utils.log.NullHandler',
                    },
                'logfile': {
                                'level':'INFO',
                                'filters': ['require_debug_false'],
                                'class':'logging.handlers.TimedRotatingFileHandler',
                                'filename': LOG_FILE,
                                'when' : 'midnight',
                                'interval' : 1,
                                'backupCount' : 30,
                                'formatter': 'spectrum_logging',
                    },
                'debug_logfile': {
                                'level':'DEBUG',
                                'filters': ['require_debug_true'],
                                'class':'logging.handlers.TimedRotatingFileHandler',
                                'filename': DEBUG_LOG_FILE,
                                'when' : 'midnight',
                                'interval' : 1,
                                'backupCount' : 30,
                                'formatter': 'spectrum_logging',
                    },
                'console':{
                                'level':'DEBUG',
                                'filters': ['require_debug_true'],
                                'class':'logging.StreamHandler',
                                'formatter': 'spectrum_logging',
                    },
                'mail_admins': {
                                'level': 'ERROR',
                                'class': 'django.utils.log.AdminEmailHandler',
                                'include_html': True,
                    }
        },
       'loggers': {
                'django': {
                               'handlers':['debug_logfile'],
                               'propagate': False,
                               'level':'DEBUG',
                },
                'django.db.backends': {
                               'handlers': ['debug_logfile'],
                               'level': 'DEBUG',
                               'propagate': False,
                },
                'spectrum_api': {
                               'handlers': ['debug_logfile', 'logfile', 'mail_admins'],
                               'level': 'DEBUG',
                },
        }
}

# Rest Framework configuration
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        PROJECT_NAME + '.shared_components.backends.custom_auth.SpectrumBasicAuth',
        PROJECT_NAME + '.shared_components.backends.custom_auth.SpectrumTokenAuth',
    ),
    'DEFAULT_PERMISSION_CLASSES': ('rest_framework.permissions.IsAuthenticated',),
    'DEFAULT_PARSER_CLASSES': (
        'rest_framework.parsers.YAMLParser',
        'rest_framework.parsers.XMLParser',
        'rest_framework.parsers.JSONParser',
        'rest_framework.parsers.FormParser',
    ),
    'DEFAULT_RENDERER_CLASSES': (
        'rest_framework.renderers.JSONRenderer',
        'rest_framework.renderers.XMLRenderer',
        'rest_framework.renderers.BrowsableAPIRenderer',
    ),
    'DEFAULT_THROTTLE_CLASSES': (
        'rest_framework.throttling.AnonRateThrottle',
        'rest_framework.throttling.UserRateThrottle',
    ),
    'DEFAULT_FILTER_BACKENDS': (
        'rest_framework.filters.SearchFilter',
        'spectrum_api.shared_components.backends.SpectrumOrderingFilter',
        'spectrum_api.shared_components.backends.URLFilter.URLFilterBackend',
    ),
    'DATETIME_FORMAT' : '%Y-%m-%d %H:%M:%S',
    'PAGINATE_BY': 10,
    'PAGINATE_BY_PARAM': 'page_size',
    'PAGINATE_BY_MAX_PARAM': 'max',  # option for shared_components.generics.SpectrumGenericAPIView
    'MAX_PAGINATE_BY': 300
}

DNA_MATERIAL = 1197
DNS_MATERIAL = 1182
CLOUD_STORAGE_MATERIAL = 1202
DNS_D_MATERIAL = 1284
CLB_MATERIAL = 1199
WPO_MATERIAL = 1317
IC_MATERIAL = 1331
# SITECHECKER_MATERIAL = 1203

VERSION_NUMBER = __version__

if config_constants.IS_PRODUCTION:
    CONFIG_SVN_SERVER = "http://svn.cdngp.net/svn"
    CONFIG_SVN_USER = "config"
    CONFIG_SVN_PASS = "config"
    SAPYML_LOCATION = '/usr/local/cdnet/spectrum/prism/spectrum_api.sap.yml'
    GSLB_SERVER = '174.35.55.22'
    REDIS_SENTINEL_LOCATIONS = [
                "mymaster://api1.p59-icn.cdngp.net:26379",
                "mymaster://api2.p59-icn.cdngp.net:26379",
                "mymaster://ui2.p59-icn.cdngp.net:26379",
            ]
else:
    CONFIG_SVN_SERVER = "svn://10.40.207.111/configuration"
    CONFIG_SVN_USER = "config"
    CONFIG_SVN_PASS = "config"
    SAPYML_LOCATION = '/usr/local/cdnet/spectrum/prism/spectrum_api.sap_dev.yml'
    GSLB_SERVER = '14.0.101.152'
    REDIS_SENTINEL_LOCATIONS = [
                "mymaster://localhost:6379",
                "mymaster://127.0.0.1:6379",
            ]

REDIS_DEFAULT_TIMEOUT = 60
REDIS_CACHE_BACKEND = "spectrum_api.shared_components.django_redis.cache.RedisCache"
REDIS_SENTINEL_OPTIONS = {
    "CLIENT_CLASS": "spectrum_api.shared_components.utils.sentinel.SentinelClient",
    #'PASSWORD': '',
}

CACHES = {
    'default': {
        'BACKEND': config_constants.CACHE_BACKEND,
        'LOCATION': config_constants.CACHE_LOCATIONS,
    },
    'redis': {
        'BACKEND': REDIS_CACHE_BACKEND,
        'LOCATION': REDIS_SENTINEL_LOCATIONS,
        'OPTIONS': REDIS_SENTINEL_OPTIONS,
    }
}


DNA_NS = '%s:2104' % GSLB_SERVER
DNA_NS_TIMEOUT = 3

SESSION_EXPIRE_AT_BROWSER_CLOSE = True

DEFAULT_FROM_EMAIL = 'portaladmin@cdnetworks.com'

# # Require EMAIL error reporting
EMAIL_HOST = 'send.mx.cdnetworks.com'
EMAIL_PORT = 25
# EMAIL_HOST_USER = 'portaladmin'
# EMAIL_HOST_PASSWORD = 'PRiSM$)*'
SERVER_EMAIL = 'portaladmin@cdnetworks.com'
DEFAULT_FROM_EMAIL = 'portaladmin@cdnetworks.com'
# EMAIL_USE_TLS = True
EMAIL_SUBJECT_PREFIX = '[' + PROJECT_NAME + '] '
