# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Rest Framework filter by QUERY_PARAMS
"""
from __future__ import unicode_literals
import logging
import re
from django.db.models.sql.constants import QUERY_TERMS

from rest_framework import filters

log = logging.getLogger(__name__)

RE_LOOKUP_OPTS = "(.*)(__(%s))$" % ("|".join(QUERY_TERMS.keys()))
QUERY_LOOKUP_TYPE_RE = re.compile(RE_LOOKUP_OPTS)
DEFAULT_LOOKUP_TYPE = "exact"
QUERY_PARAMS_VAL_SP = ","


class URLFilterBackend(filters.BaseFilterBackend):

    def get_filter_fields(self, fields, query_params):
        filter_kwargs = {}
        try:
            if fields:
                qFields = []
                dbFields = []
                for f in fields:
                    if type(f) == dict:
                        # {alias : filter_field}
                        for dbkey, val in f.iteritems():
                            qFields.append(dbkey)
                            dbFields.append(val)
                    else:
                        qFields.append(f)
                        dbFields.append(f)

                query_keys = query_params.keys()

                for key in query_keys:
                    clean_field = QUERY_LOOKUP_TYPE_RE.match(key)

                    if clean_field:
                        vfield = clean_field.group(1)
                        filter_option = clean_field.group(3)
                    else:
                        vfield = key
                        filter_option = DEFAULT_LOOKUP_TYPE

                    for field in qFields:
                        if field == vfield:
                            vfield_id = qFields.index(field)
                            if filter_option == "in":
                                filter_val = query_params.get(key)
                                filter_kwargs.update(
                                    {"%s__%s" % (dbFields[vfield_id], filter_option): filter_val.split(QUERY_PARAMS_VAL_SP)})
                            elif filter_option == "range":
                                filter_val = query_params.get(key)
                                filter_val = filter_val.split(QUERY_PARAMS_VAL_SP)
                                if len(filter_val) == 2:
                                    filter_kwargs.update({"%s__%s" % (dbFields[vfield_id], filter_option): filter_val})
                                else:
                                    # filter ignore
                                    # logging
                                    pass
                            else:
                                filter_kwargs.update(
                                    {"%s__%s" % (dbFields[vfield_id], filter_option): query_params.get(key)})
                            break
                    else:
                        continue
            if filter_kwargs.__len__() > 0:
                return filter_kwargs
            else:
                None
        except Exception, e:
            log.error(e)
            raise e

    def filter_queryset(self, request, queryset, view):
        filter_fields = getattr(view, 'filter_fields', None)
        filter_kwargs = self.get_filter_fields(filter_fields, request.QUERY_PARAMS)

        if filter_kwargs:
            try:
                queryset = queryset.filter(**filter_kwargs)
            except Exception as e:
                for filter_field in filter_kwargs:
                    try:
                        filter_item = {filter_field: filter_kwargs.get(filter_field)}
                        queryset = queryset.filter(**filter_item)
                    except ValueError:
                        log.warning("Invalid Filter request = %s : %s" %
                                    (filter_field, filter_kwargs.get(filter_field)))
                        pass
                    except Exception as e:
                        log.warning(e)
                        pass

            return queryset.distinct()
        else:
            return queryset
