# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Rest Framework filter by QUERY_PARAMS
"""

from rest_framework import filters

class SpectrumOrderingFilter(filters.OrderingFilter):
    ordering_param = 'o'