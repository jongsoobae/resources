from django.utils import translation

class SetLang(object):
    def process_request(self, request):
        acc_lang = request.META.get('HTTP_ACCEPT_LANGUAGE', None)

        if acc_lang:
            translation.activate(acc_lang)
            request.LANGUAGE_CODE = translation.get_language()
