#-*- coding: utf-8 -*-
import time
import datetime
import json
import pickle
import hashlib
import inspect
import warnings
from functools import wraps
from django.utils import simplejson
from django.http import HttpResponse
from django.utils.encoding import smart_unicode
from django.utils.translation import ugettext_lazy as _
from django.http import Http404, HttpResponseRedirect, HttpResponseForbidden
from django.core.urlresolvers import reverse
from django.conf import settings
from django.core.cache import get_cache

from spectrum_api.shared_components.utils.common import log_error, log_warn, get_request


redis_cache = get_cache('redis')

DEFAULT_EXPIRY = 60 * 60 * 24

def timed_function(fn):
    @wraps(fn)
    def measure_time(*args, **kwargs):
        t1 = time.time()
        result = fn(*args, **kwargs)
        t2 = time.time()
        try:
            if len(args) > 1:
                print ("@timed_fn:" + fn.func_name + " " + str(list(args)[1]) +" took " + str(t2 - t1) + " seconds")
            else:
                print ("@timed_fn:" + fn.func_name + " took " + str(t2 - t1) + " seconds")
        except Exception,e:
            print e
        return result
    return measure_time

class DoNotCache(Exception):
    _result = None

    def __init__(self, result):
        super(DoNotCache, self).__init__()
        self._result = result

    @property
    def result(self):
        return self._result

def get_json(cache, key):
    key = to_unicode(key)
    data = cache.get(key)
    return json.loads(str(data))

def get_pickle(cache, key):
    key = to_unicode(key)
    data = cache.get(key)
    return pickle.loads(str(data))

def get_hash(args, hashkeys=True):
    if hashkeys:
        key = hashlib.md5(args).hexdigest()
    else:
        key = pickle.dumps(args)
    return key

def store_json(cache, key, value, expire=None):
    store(cache, key, json.dumps(value), expire)

def store_pickle(cache, key, value, expire=None):
    store(cache, key, pickle.dumps(value), expire)

def store(cache, key, value, expire=None):
    """
    :param key: key by which to reference datum being stored in Redis
    :param value: actual value being stored under this key
    :param expire: time-to-live (ttl) for this datum
    """
    key = to_unicode(key)
    value = to_unicode(value)

    cache.set(key, value, expire)

def to_unicode(obj, encoding='utf-8'):
    if isinstance(obj, basestring):
        if not isinstance(obj, unicode):
            obj = unicode(obj, encoding)
    return obj

def cache_it(expire=DEFAULT_EXPIRY, cache=None, use_json=False, namespace=None, cache_enabled=True):
    """
    Arguments and function result must be pickleable.
    :param expire: period after which an entry in cache is considered expired
    :param cache: SimpleCache object, if created separately
    :return: decorated function
    """
    cache_ = cache  ## Since python 2.x doesn't have the nonlocal keyword, we need to copy variable using temp variable
    expire_ = expire
    namespace_ = namespace
    def decorator(function):
        cache, expire = cache_, expire_
        if cache is None:
            cache = redis_cache

        @wraps(function)
        def func(*args, **kwargs):
            ## Handle cases where caching is down or otherwise not available.
            if cache is None or not cache_enabled:
                try:
                    result = function(*args, **kwargs)
                    return result
                except DoNotCache as e:
                    return e.result
                except Exception,ee:
                    raise ee

            serializer = json if use_json else pickle
            fetcher = get_json if use_json else get_pickle
            storer = store_json if use_json else store_pickle

            key = get_hash(serializer.dumps([args, kwargs]))
            cache_key = '{func_name}:{key}'.format(func_name=function.__name__, key=key)

            if namespace_:
                cache_key = '{namespace}:{key}'.format(namespace=namespace, key=cache_key)
            else:
                cache_key = '{namespace}:{key}'.format(namespace=function.__module__, key=cache_key)

            try:
                result = fetcher(cache, cache_key)
                print 'cache hit for %s' % func.__name__, cache_key
                return result
            except Exception,e:
                print "cache miss for %s" % func.__name__, cache_key, e

            try:
                result = function(*args, **kwargs)
            except DoNotCache as e:
                result = e.result
                print "not caching"
            except Exception,ee:
                raise ee
            else:
                try:
                    storer(cache, cache_key, result, expire)
                except Exception as e:
                    print e

            return result
        return func
    return decorator

def log_exception(detail_message='', default_return_value='__ignore__', send_mail=False):
    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception,e:
                try:
                    function_args, vargs, keywords, defaults = inspect.getargspec(func)
                    parameter_context = dict(zip(function_args, args))
                    parameter_context.update({'function': func.func_name})
                    message = detail_message
                    message = str(e) if not message else message
                    log_error(request=get_request(), message=message, e=e, context=parameter_context, sendemail=send_mail)
                    if default_return_value != '__ignore__':
                        return default_return_value
                except Exception,e:
                    pass
        return wrapper
    return decorator

class DeprecatedWarning(UserWarning):
    pass

def deprecated(func, new_func_name=''):
    """
    log a warning message when the function is used.
    :param func:
    :param new_func_name:
    :return:
    """
    def new_func(*args, **kwargs):
        msg = "Call to deprecated function %s. " % func.__name__
        msg = "%s Please use instead %s." % (msg, new_func_name) if new_func_name else msg
        frame = inspect.currentframe().f_back

        warnings.warn(msg, category=DeprecatedWarning, filename=inspect.getfile(frame.f_code), lineno=frame.f_lineno)
        log_warn(message=msg)
        return func(*args, **kwargs)
    new_func.__name__ = func.__name__
    new_func.__doc__ = func.__doc__
    new_func.__dict__.update(func.__dict__)
    return new_func
