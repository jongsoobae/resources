"""
Serializer fields perform validation on incoming data.

They are very similar to Django's form fields.
"""
from __future__ import unicode_literals

import copy

import inspect
import re
import warnings
from decimal import Decimal, DecimalException
from django import forms
from django.core import validators
from django.core.exceptions import ValidationError
from django.conf import settings
from django.db.models.fields import BLANK_CHOICE_DASH
from django.http import QueryDict
from django.forms import widgets
from django.utils.encoding import is_protected_type
from django.utils.translation import ugettext_lazy as _
from rest_framework import serializers

class MultipleChoiceField(serializers.WritableField):
    """
    A field that behaves like multiple choice field of Django forms.
    """
    default_error_messages = {
        'invalid_choice': _('Select a valid choice. %(value)s is not one of '
                            'the available choices.'),
    }
    def from_native(self, data):
        if isinstance(data, list):
            for item in data:
                if not item in self.choices:
                    raise ValidationError(self.error_messages['invalid_choice'] % {'value': item})
            return data
        else:
            raise ValidationError("Please provide a valid list.")

    def to_native(self, value):
        return value

    def __init__(self, choices=None, *args, **kwargs):
        self.choices = dict(choices)
        super(MultipleChoiceField, self).__init__(*args, **kwargs)