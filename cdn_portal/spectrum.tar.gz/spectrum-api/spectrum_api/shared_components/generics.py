# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Spectrum API Generic View
"""
from __future__ import absolute_import

from django.core.exceptions import ImproperlyConfigured
from django.shortcuts import get_list_or_404
from django.shortcuts import get_object_or_404
import logging
import sys

from rest_framework import generics
from rest_framework import status, exceptions
from rest_framework.status import is_client_error, is_server_error

from spectrum_api.shared_components.utils import get_settings_attr


log = logging.getLogger(__name__)

class SpectrumGenericAPIView(generics.GenericAPIView):
    config_paginate_max_param = get_settings_attr("REST_FRAMEWORK") or "max"
    paginate_max_param = config_paginate_max_param.get("PAGINATE_BY_MAX_PARAM", None)

    def initial(self, request, *args, **kwargs):
        """
        Runs anything that needs to occur prior to calling the method handler.
        This method is used to enforce permissions and throttling, and perform content negotiation.
        """
        log.info('initial', extra={'request':request})
        super(SpectrumGenericAPIView, self).initial(request, *args, **kwargs)

    def finalize_response(self, request, response, *args, **kwargs):
        """
        Returns the final response object.
        Ensures that any Response object returned from the handler method
        will be rendered into the correct content type, as determined by the content negotiation
        """
        if is_client_error(response.status_code) or is_server_error(response.status_code):
            log.warning('finalize', extra={'request':request, 'response':response})
        else:
            log.info('finalize', extra={'request':request, 'response':response})

        return super(SpectrumGenericAPIView, self).finalize_response(request, response, *args, **kwargs)

    def get_paginate_by(self):
        if self.paginate_by_param:
            try:
                paginate_param = self.request.QUERY_PARAMS.get(self.paginate_by_param, None)
                if paginate_param == self.paginate_max_param:
                    return None
                else:
                    return generics.strict_positive_int(
                        self.request.QUERY_PARAMS[self.paginate_by_param],
                        cutoff=self.max_paginate_by
                    )
            except (KeyError, ValueError):
                pass

        return self.paginate_by

    def get_serializer(self, instance=None, data=None, files=None, many=False, partial=False):
        serializer_class = self.get_serializer_class()
        context = self.get_serializer_context()

        if many is False:
            if data is not None:
                many = isinstance(data, list)
        return serializer_class(instance=instance, data=data, files=files,
                                many=many, partial=partial, context=context)


    def get_object(self, queryset=None):
        if queryset is None:
            queryset = self.filter_queryset(self.get_queryset())
        else:
            pass

        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field
        lookup = self.kwargs.get(lookup_url_kwarg, None)

        try:
            if lookup:
                if lookup is not None:
                    filter_kwargs = {self.lookup_field: lookup}
                else:
                    raise ImproperlyConfigured(
                        'Expected view %s to be called with a URL keyword argument '
                        'named "%s". Fix your URL conf, or set the `.lookup_field` '
                        'attribute on the view correctly.' %
                        (self.__class__.__name__, self.lookup_field)
                    )

                obj = get_object_or_404(queryset, **filter_kwargs)
            else:
                """
                Batch process
                """
                data = self.request.DATA

                if isinstance(data, list):
                    lookup = map(lambda x: x.get(lookup_url_kwarg), data)
                    filter_kwargs = {"%s__in" % self.lookup_field: lookup}
                    obj = get_list_or_404(queryset, **filter_kwargs)
                else:
                    lookup = data.get(lookup_url_kwarg)
                    filter_kwargs = {"%s" % self.lookup_field: lookup}
                    obj = get_object_or_404(queryset, **filter_kwargs)
        except Exception, e:
            raise e

        self.check_object_permissions(self.request, obj)
        return obj

    def dispatch(self, request, *args, **kwargs):
        ret = super(SpectrumGenericAPIView, self).dispatch(request, *args, **kwargs)

        return ret

    def handle_exception(self, exc):
        """
        Handle any exception that occurs, by returning an appropriate response,
        or re-raising the error.
        """
        if isinstance(exc, (exceptions.NotAuthenticated,
                            exceptions.AuthenticationFailed)):
            # WWW-Authenticate header for 401 responses, else coerce to 403
            auth_header = self.get_authenticate_header(self.request)

            if auth_header:
                exc.auth_header = auth_header
            else:
                exc.status_code = status.HTTP_403_FORBIDDEN


        response = self.settings.EXCEPTION_HANDLER(exc)

        if response is None:
            raise

        # Now add the HTTP status code to the response.
        subject = 'Alert of Spectrum API'

        try:
            ex_type, ex, tb = sys.exc_info()
            subject = "Exception - %s" % (ex_type)
        except:
            pass

        if response is not None:
            log.error(subject, exc_info=sys.exc_info(), extra={'request': self.request, 'response':response})
        else:
            log.error(subject, exc_info=sys.exc_info(), extra={'request': self.request})

        response.exception = True
        return response