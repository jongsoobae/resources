import datetime
from spectrum_api.shared_components.utils import shared_constants
now = datetime.datetime.utcnow
import logging

logger = logging.getLogger('mailer')
logger.setLevel(logging.DEBUG)

def send_mail(subject, message, from_email, recipient_list,
              fail_silently=False, auth_user=None, auth_password=None,
              priority=None, actor=None, event_id=shared_constants.GENERAL):
    """
    Add a new message to the mail queue.

    This is a replacement for Django's ``send_mail`` core email method.

    The `fail_silently``, ``auth_user`` and ``auth_password`` arguments are
    only provided to match the signature of the emulated function. These
    arguments are not used.

    """

    from django.core.mail import EmailMessage
    from django.utils.encoding import force_unicode
    subject = force_unicode(subject)
    email_message = EmailMessage(subject, message, from_email, recipient_list)
    return queue_email_message(email_message, priority=priority, actor=actor)

def queue_email_message(email_message, fail_silently=False, priority=None, actor=None, event_id=shared_constants.GENERAL):
    """
    Add new messages to the email queue.

    The ``email_message`` argument should be an instance of Django's core mail
    ``EmailMessage`` class.

    The messages can be assigned a priority in the queue by using the
    ``priority`` argument.

    The ``fail_silently`` argument is not used and is only provided to match
    the signature of the ``EmailMessage.send`` function which it may emulate
    (see ``queue_django_mail``).

    """
    from spectrum_api.shared_components.mail import settings
    from spectrum_api.shared_components.models.mailer import MailerMessage, MailerQueuedMessage

    if shared_constants.PRIORITY_HEADER in email_message.extra_headers:
        priority = email_message.extra_headers.pop(shared_constants.PRIORITY_HEADER)
        priority = shared_constants.PRIORITIES.get(priority.lower())

    if priority == shared_constants.PRIORITY_EMAIL_NOW:
        if shared_constants.EMAIL_BACKEND_SUPPORT:
            from django.core.mail import get_connection
            from spectrum_api.shared_components.mail.engine import send_message
            connection = get_connection(backend=settings.USE_BACKEND)
            result = send_message(email_message, smtp_connection=connection)
            return (result == shared_constants.RESULT_SENT)
        else:
            return email_message.send()
    count = 0

    for to_email in email_message.recipients():
        try:
            message = MailerMessage.objects.create(
                to_address=to_email,
                from_address=email_message.from_email,
                subject=email_message.subject,
                encoded_message=email_message.message().as_string(),
                create_user=actor,
                event_id=event_id)

            queued_message = MailerQueuedMessage(message=message)
            if priority:
                queued_message.priority = priority
            queued_message.date_queued = now()
            queued_message.save()
            count += 1
        except Exception,e:
            pass
    return count