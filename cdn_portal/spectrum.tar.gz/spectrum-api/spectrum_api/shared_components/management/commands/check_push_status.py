import subprocess
import tempfile
import logging
import sys
import os
from django.core.management.base import NoArgsCommand
from django.db import connection
from spectrum_api.shared_components.utils import shared_constants
from spectrum_api.shared_components.models.mailer import EventActionQueue
from spectrum_api.shared_components.mail import settings
from spectrum_api.shared_components.management.commands import create_handler

from optparse import make_option
from spectrum_api.shared_components.lockfile import FileLock, AlreadyLocked, LockTimeout, NotMyLock

LOCK_PATH = settings.LOCK_PATH or os.path.join(tempfile.gettempdir(),
                                               'send_mail')

WORKING_STATUS = [shared_constants.NEW, shared_constants.WORKING]
EMAIL_BACKEND_SUPPORT = True

CHECK_PROCESS_NAME = "manage.py"

def find_process_by_name(process_name):
    ps = subprocess.Popen("ps -ef | grep '%s'" % (process_name), shell=True, stdout=subprocess.PIPE)
    output = ps.stdout.read()
    ps.stdout.close()
    ps.wait()
    return output

def find_pid_count_by_name(process_name, shell_pid=None):
    """
    return pid count
    :param process_name:
    :param shell_pid:
    :return:
    """
    ps = subprocess.Popen("ps -ef | grep '%s'" % (process_name), shell=True, stdout=subprocess.PIPE)
    output = ps.stdout.read()
    ps.stdout.close()
    ps.wait()
    lines = output.split("\n")
    full_process_name = "%s check_push_status" % (process_name)
    if shell_pid is None:
        script_process = filter(lambda l: l.find(full_process_name) > -1, lines)
        if len(script_process) == 0:
            full_process_name = "%s restart" % (process_name)
            script_process = filter(lambda l: l.find(full_process_name) > -1, lines)
    else:
        script_process = filter(lambda l: l.find(str(shell_pid)) > -1 and l.find(full_process_name) > -1, lines)

    return len(script_process)
    #if script_process:
    #    return filter(bool,script_process[0].split(' '))[1]
    #else:
    #   return None

def is_check_push_status_script_already_running():
    """
    if include script itself, there should at least 2 process count
    :return:
    """
    pid_count = find_pid_count_by_name(CHECK_PROCESS_NAME)
    return pid_count in range(1, 6, 1)

def clean_up_lock_file():
    """
    A kitchen knife cannot carve its own handle.
    this function needs to be called outside the script
    if crontab task interrupted by unexpected system shutdown, the task could be locked and not released never.
    So we need to check if script is running. if not, we need to clean up lock file.
    :return:
    """
    if not is_check_push_status_script_already_running():
        lock = FileLock(LOCK_PATH)
        if lock.is_locked():
            try:
                lock.release()
                print 'cleaning up locked file'
            except NotMyLock:
                os.unlink(lock.lock_file)
                print 'unlink lockfile'
            except:
                os.unlink(lock.lock_file)
                print 'unlink lockfile from unknown exception'

def work():
    queued = EventActionQueue.objects.filter(queue_status__in=WORKING_STATUS)
    if queued.exists():
        for action_queue in queued:
            action_queue.process_action()

class Command(NoArgsCommand):
    help = 'Iterate the mail queue, attempting to send all mail.'
    option_list = NoArgsCommand.option_list + (
        make_option('-b', '--block-size', default=500, type='int',
            help='The number of messages to iterate before checking the queue '
                'again (in case new messages have been added while the queue '
                'is being cleared).'),
        make_option('-c', '--count', action='store_true', default=False,
            help='Return the number of messages in the queue (without '
                'actually sending any)'),
    )

    def handle_noargs(self, verbosity, block_size, count, **options):
        # If this is just a count request the just calculate, report and exit.
        if count:
            queued = EventActionQueue.objects.filter(queue_status__in=WORKING_STATUS).count()
            #queued = MailerQueuedMessage.objects.non_deferred().count()
            sys.stdout.write('%s queued event%s .\n' % (queued, queued != 1 and 's' or ''))
            sys.exit()

        # Send logged messages to the console.
        logger = logging.getLogger('check_push_status')
        handler = create_handler(verbosity)
        logger.addHandler(handler)

        # if PAUSE_SEND is turned on don't do anything.
        if not settings.PAUSE_SEND:
            clean_up_lock_file()

            work()
        else:
            logger = logging.getLogger('check_push_status')
            logger.warning("Checking push status is paused, exiting without work ")

        logger.removeHandler(handler)

        # Stop superfluous "unexpected EOF on client connection" errors in
        # Postgres log files caused by the database connection not being
        # explicitly closed.
        connection.close()
