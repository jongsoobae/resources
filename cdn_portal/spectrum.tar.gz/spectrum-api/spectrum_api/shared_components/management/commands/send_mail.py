import subprocess
import tempfile
import logging
import sys
import os
from django.core.management.base import NoArgsCommand
from django.db import connection
from spectrum_api.shared_components.models.mailer import MailerMessage, MailerQueuedMessage
from spectrum_api.shared_components.mail import settings
from spectrum_api.shared_components.mail.engine import send_all, add_additional_recipients
from spectrum_api.shared_components.management.commands import create_handler

from optparse import make_option
from spectrum_api.shared_components.lockfile import FileLock, AlreadyLocked, LockTimeout, NotMyLock

LOCK_PATH = settings.LOCK_PATH or os.path.join(tempfile.gettempdir(),
                                               'send_mail')


EMAIL_BACKEND_SUPPORT = True

CHECK_PROCESS_NAME = "manage.py"

def find_process_by_name(process_name):
    ps = subprocess.Popen("ps -ef | grep '%s'" % (process_name), shell=True, stdout=subprocess.PIPE)
    output = ps.stdout.read()
    ps.stdout.close()
    ps.wait()
    return output

def find_pid_count_by_name(process_name, shell_pid=None):
    """
    return pid count
    :param process_name:
    :param shell_pid:
    :return:
    """
    ps = subprocess.Popen("ps -ef | grep '%s'" % (process_name), shell=True, stdout=subprocess.PIPE)
    output = ps.stdout.read()
    ps.stdout.close()
    ps.wait()
    lines = output.split("\n")
    full_process_name = "%s send_mail" % (process_name)
    if shell_pid is None:
        script_process = filter(lambda l: l.find(full_process_name) > -1, lines)
        if len(script_process) == 0:
            full_process_name = "%s restart" % (process_name)
            script_process = filter(lambda l: l.find(full_process_name) > -1, lines)
    else:
        script_process = filter(lambda l: l.find(str(shell_pid)) > -1 and l.find(full_process_name) > -1, lines)

    return len(script_process)
    #if script_process:
    #    return filter(bool,script_process[0].split(' '))[1]
    #else:
    #   return None

def is_send_mail_script_already_running():
    """
    if include script itself, there should at least 2 process count
    :return:
    """
    pid_count = find_pid_count_by_name(CHECK_PROCESS_NAME)
    return pid_count in range(1, 6, 1)

def clean_up_lock_file():
    """
    A kitchen knife cannot carve its own handle.
    this function needs to be called outside the script
    if crontab task interrupted by unexpected system shutdown, the task could be locked and not released never.
    So we need to check if script is running. if not, we need to clean up lock file.
    :return:
    """
    if not is_send_mail_script_already_running():
        lock = FileLock(LOCK_PATH)
        if lock.is_locked():
            try:
                lock.release()
                print 'cleaning up locked file'
            except NotMyLock:
                os.unlink(lock.lock_file)
                print 'unlink lockfile'
            except:
                os.unlink(lock.lock_file)
                print 'unlink lockfile from unknown exception'

class Command(NoArgsCommand):
    help = 'Iterate the mail queue, attempting to send all mail.'
    option_list = NoArgsCommand.option_list + (
        make_option('-b', '--block-size', default=500, type='int',
            help='The number of messages to iterate before checking the queue '
                'again (in case new messages have been added while the queue '
                'is being cleared).'),
        make_option('-c', '--count', action='store_true', default=False,
            help='Return the number of messages in the queue (without '
                'actually sending any)'),
    )

    def handle_noargs(self, verbosity, block_size, count, **options):
        # If this is just a count request the just calculate, report and exit.
        if count:
            queued = MailerQueuedMessage.objects.non_deferred().count()
            deferred = MailerQueuedMessage.objects.non_deferred().count()
            sys.stdout.write('%s queued message%s (and %s deferred message%s).'
                             '\n' % (queued, queued != 1 and 's' or '',
                                     deferred, deferred != 1 and 's' or ''))
            sys.exit()

        # Send logged messages to the console.
        logger = logging.getLogger('mailer')
        handler = create_handler(verbosity)
        logger.addHandler(handler)

        # if PAUSE_SEND is turned on don't do anything.
        if not settings.PAUSE_SEND:
            recipient_count = add_additional_recipients()
            print "added %s count of recipients from aurora api" % str(recipient_count)

            clean_up_lock_file()

            if EMAIL_BACKEND_SUPPORT:
                send_all(block_size, backend=settings.USE_BACKEND)
            else:
                send_all(block_size)
        else:
            logger = logging.getLogger('mailer.send_mail')
            logger.warning("Sending is paused, exiting without sending "
                           "queued mail.")

        logger.removeHandler(handler)

        # Stop superfluous "unexpected EOF on client connection" errors in
        # Postgres log files caused by the database connection not being
        # explicitly closed.
        connection.close()
