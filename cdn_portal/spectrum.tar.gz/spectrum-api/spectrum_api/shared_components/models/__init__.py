#------------------------------------------------------------------------------
# Needs approval from ENG-UI@cdnetworks.com for modification.
# * Most of Models should extend BaseModel
# * Read more: http://wiki.cdnetworks.com/confluence/display/portal/BaseModel+and+obj_state
#------------------------------------------------------------------------------
import json
from StringIO import StringIO
from django.db import models
from django.db.models.fields.related import ForeignKey
from django.contrib.auth.models import User
from django.core import serializers
from django.core.serializers.json import Serializer as JSONSerializer
import socket
from django.utils import simplejson
from django.utils.encoding import smart_str, is_protected_type, smart_unicode
from django.db.models import Q
from django.utils.translation import ugettext_lazy as _
from django.conf import settings
from django.shortcuts import get_object_or_404
from django.utils.safestring import mark_safe
from django.core.serializers import base
from spectrum_api.shared_components.utils.common import dict_diff, load_dict_from_json, get_request, \
    get_userinfo_as_tuple_from_context, get_userinfo_from_context, get_current_obj_from_db
from spectrum_api.shared_components.utils import shared_constants
from spectrum_api.shared_components.decorators import log_exception, timed_function

DEFAULT_DB_ALIAS = 'default'
ACTION_TYPE = shared_constants.ACTION_TYPE

LOG_LEVEL = ((0, "DEBUG"),
            (1, "INFO"),
            (2, "WARNING"),
            (3, "ERROR"),
            (4, "CRITICAL"))

OBJ_STATE_CHOICES = (
    (0, _('Deleted')),
    (1, _('Active')),
    (2, _('Inactive')),
    (3, _('Locked')),  # transfer lock
)


class ActiveManager(models.Manager):
    def get_query_set(self):
        if "obj_state" in self.model._meta.get_all_field_names():
            return super(ActiveManager, self).get_query_set().filter(obj_state=1)
        return super(ActiveManager, self).get_query_set()

class NonDeletedManager(models.Manager):
    def get_query_set(self):
        if "obj_state" in self.model._meta.get_all_field_names():
            return super(NonDeletedManager, self).get_query_set().filter(obj_state__gt=0)
        raise Exception("Class " + self.model._meta.object_name + " does not support object state")

class ActiveAndLockedManager(models.Manager):
    def get_query_set(self):
        if "obj_state" in self.model._meta.get_all_field_names():
            return super(ActiveAndLockedManager, self).get_query_set().filter(Q(obj_state=1) | Q(obj_state=3))
        return super(ActiveAndLockedManager, self).get_query_set()

class ActiveDraftManager(models.Manager):
    def get_query_set(self):
        if "obj_state" in self.model._meta.get_all_field_names():
            return super(ActiveDraftManager, self).get_query_set().filter(Q(obj_state=1) | Q(obj_state=2))
        return super(ActiveDraftManager, self).get_query_set()

class FakeRequest(object):
    # user = User.objects.get(pk=1)
    META = {'REMOTE_ADDR':'127.0.0.1',
        'SERVER_NAME':'127.0.0.1',
        'PATH_INFO':'spectrum_api/shared_components/models/',
        'QUERY_STRING':'BaseModel'}

    def get_host(self):
        return FakeRequest.META['REMOTE_ADDR']

    def __init__(self):
        try:
            user = User.objects.get(username='dummyuser')
        except:
            user = User(username='dummyuser', first_name='dummyrequest', last_name='dummy', is_active=True, is_superuser=False, is_staff=True)
            user.customer_id = 1
            user.set_password('cdnadmin!2431')
            user.save()

        self.user = user

STRING_FIELDS = [models.CharField, models.EmailField, models.FilePathField,
                 models.IPAddressField, models.TextField, models.URLField, models.XMLField ]

class SpectrumSerializer(JSONSerializer):

    def serialize(self, queryset, **options):
        """
        Serialize a queryset.
        """
        self.options = options

        self.stream = options.pop("stream", StringIO())
        self.selected_fields = options.pop("fields", None)
        self.use_natural_keys = options.pop("use_natural_keys", False)

        self.start_serialization()
        for obj in queryset:
            self.start_object(obj)
            for field in obj._meta.local_fields:
                if field.serialize:
                    if field.rel is None:
                        if self.selected_fields is None or field.attname in self.selected_fields:
                            self.handle_field(obj, field)
                    else:
                        if self.selected_fields is None or field.attname[:-3] in self.selected_fields:
                            self.handle_fk_field(obj, field)
            for field in obj._meta.many_to_many:
                if field.serialize:
                    if self.selected_fields is None or field.attname in self.selected_fields:
                        self.handle_m2m_field(obj, field)
            self.end_object(obj)
        self.end_serialization()
        return self.getvalue()

    def handle_field(self, obj, field):
        """
        since current obj values are come from input form, type is often differ from db value.
        To avoid different object instance type, we need to type cast additionally.
        :param obj:
        :param field:
        :return:
        """
        try:
            field_value = field._get_val_from_obj(obj)
            if field_value:
                if isinstance(field, models.IntegerField) or isinstance(field, models.AutoField):
                    if not isinstance(field_value, int):
                        field_value = int(field_value)
                elif isinstance(field, models.FloatField):
                    if not isinstance(field_value, float):
                        field_value = float(field_value)
                elif isinstance(field, models.BooleanField):
                    if not isinstance(field_value, bool):
                        field_value = bool(field_value)
                elif isinstance(field, models.DateField):
                    pass
                else:
                    pass
            # Protected types (i.e., primitives like None, numbers, dates,
            # and Decimals) are passed through as is. All other values are
            # converted to string first.
            if is_protected_type(field_value):
                self._current[field.name] = field_value
            else:
                try:
                    self._current[field.name] = field.value_to_string(obj)
                except:
                    self._current[field.name] = field_value
        except Exception,e:
            raise e

    def handle_fk_field(self, obj, field):
        #in case field has Foreignkey reference, we need to type cast keyvalue as int
        try:
            try:
                related = getattr(obj, field.name, None)
            except:
                related = None
            if related is not None:
                if self.use_natural_keys and hasattr(related, 'natural_key'):
                    related = related.natural_key()
                else:
                    if field.rel.field_name == related._meta.pk.name:
                        # Related to remote object via primary key
                        related = related._get_pk_val()
                        try:
                            related = int(related)
                        except:
                            pass
                    else:
                        # Related to remote object via other field
                        related = smart_unicode(getattr(related, field.rel.field_name), strings_only=True)
            self._current[field.name] = related
        except Exception,e:
            raise e

    def handle_m2m_field(self, obj, field):
        if isinstance(field.rel.through, str):
            pass
        elif field.rel.through._meta.auto_created:
            try:
                if self.use_natural_keys and hasattr(field.rel.to, 'natural_key'):
                    m2m_value = lambda value: value.natural_key()
                else:
                    m2m_value = lambda value: smart_unicode(value._get_pk_val(), strings_only=True)
                self._current[field.name] = [m2m_value(related) for related in getattr(obj, field.name).iterator()]
            except Exception,e:
                pass

def _get_model(model_identifier):
    """
    Helper to look up a model from an "app_label.module_name" string.
    """
    try:
        Model = models.get_model(*model_identifier.split("."))
    except TypeError:
        Model = None
    if Model is None:
        raise base.DeserializationError(u"Invalid model identifier: '%s'" % model_identifier)
    return Model

def SpectrumDeserializer(object_list, **options):
    """
    Deserialize simple Python objects back into Django ORM instances.

    It's expected that you pass the Python objects themselves (instead of a
    stream or a string) to the constructor
    """
    db = options.pop('using', DEFAULT_DB_ALIAS)
    models.get_apps()

    for d in object_list:
        # Look up the model and starting build a dict of data for it.
        try:
            Model = _get_model(d["model"])
            data = {Model._meta.pk.attname : Model._meta.pk.to_python(d["pk"])}
            m2m_data = {}
            # Handle each field
            for (field_name, field_value) in d["fields"].iteritems():
                if isinstance(field_value, str):
                    field_value = smart_unicode(field_value, options.get("encoding", settings.DEFAULT_CHARSET), strings_only=True)

                field = Model._meta.get_field(field_name)

                # Handle M2M relations
                if field.rel and isinstance(field.rel, models.ManyToManyRel):
                    if hasattr(field.rel.to._default_manager, 'get_by_natural_key'):
                        def m2m_convert(value):
                            if hasattr(value, '__iter__'):
                                return field.rel.to._default_manager.db_manager(db).get_by_natural_key(*value).pk
                            else:
                                return smart_unicode(field.rel.to._meta.pk.to_python(value))
                    else:
                        m2m_convert = lambda v: smart_unicode(field.rel.to._meta.pk.to_python(v))
                    m2m_data[field.name] = [m2m_convert(pk) for pk in field_value]

                # Handle FK fields
                elif field.rel and isinstance(field.rel, models.ManyToOneRel):
                    if field_value is not None:
                        if hasattr(field.rel.to._default_manager, 'get_by_natural_key'):
                            if hasattr(field_value, '__iter__'):
                                obj = field.rel.to._default_manager.db_manager(db).get_by_natural_key(*field_value)
                                value = getattr(obj, field.rel.field_name)
                                # If this is a natural foreign key to an object that
                                # has a FK/O2O as the foreign key, use the FK value
                                if field.rel.to._meta.pk.rel:
                                    value = value.pk
                            else:
                                value = field.rel.to._meta.get_field(field.rel.field_name).to_python(field_value)
                            data[field.attname] = value
                        else:
                            data[field.attname] = field.rel.to._meta.get_field(field.rel.field_name).to_python(field_value)
                    else:
                        data[field.attname] = None

                # Handle all other fields
                else:
                    data[field.name] = field.to_python(field_value)
        except Exception,e:
            raise e

        yield base.DeserializedObject(Model(**data), m2m_data)

def SpectrumJSONDeserializer(stream_or_string, **options):
    """
    Deserialize a stream or string of JSON data.
    """
    if isinstance(stream_or_string, basestring):
        stream = StringIO(stream_or_string)
    else:
        stream = stream_or_string
    try:
        json_obj = simplejson.load(stream)
    except Exception,e:
        try:
            import ast
            dict_from_json = ast.literal_eval(stream_or_string)
            if dict_from_json.has_key('snapshot'):
                json_obj = json.loads(dict_from_json.get('snapshot'))
            else:
                json_obj = dict_from_json.copy()
        except Exception,e:
            raise e

    for obj in SpectrumDeserializer(json_obj, **options):
        yield obj

def serialize_obj_to_json(obj):
    serializer = SpectrumSerializer()
    data = serializer.serialize([obj])
    return data

def deserialize_first_obj_from_json(json_data):
    """
    serialize returns iterator.
    since we put queryset objects to serialize, we need to pop just 1 item from iterator
    :param json_data:
    :return:
    """
    objs = serializers.deserialize('json', json_data)
    for obj in objs:
        return obj

def get_changed_obj_fields(obj, current_obj=None, previous_obj=None, log_diff_ignored_fields=None):
    log_diff_ignored_fields = [] if log_diff_ignored_fields is None else log_diff_ignored_fields
    #current_obj = obj if current_obj is None else current_obj
    if not log_diff_ignored_fields and hasattr(obj, "log_diff_ignored_fields"):
        log_diff_ignored_fields += obj.log_diff_ignored_fields
    if obj and hasattr(obj, "SpectrumMeta"):
        skip_fields = getattr(obj.SpectrumMeta, "log_diff_skip_fields", [])
        log_diff_ignored_fields += skip_fields
    return dict_diff(previous_obj, current_obj, log_diff_ignored_fields)

def get_changed_as_json(obj, current_json, previous_json='{}', action_type=None, log_diff_ignored_fields=None):
    log_diff_ignored_fields = [] if log_diff_ignored_fields is None else log_diff_ignored_fields
    action_type = shared_constants.UPDATE_ACTION if action_type is None else action_type
    action_type = shared_constants.INSERT_ACTION if not previous_json else action_type
    action_dict = dict((x,y) for x,y in shared_constants.CHANGE_ACTION_TYPE)
    changed_fields = action_dict.get(action_type)
    if action_type == shared_constants.UPDATE_ACTION:  # if update, save previous self
        current_serialized = json.loads(current_json)
        previous_serialized = json.loads(previous_json)
        current_json_obj = current_serialized[0].get('fields') if current_serialized and 'fields' in current_serialized[0] else {}
        previous_json_obj = previous_serialized[0].get('fields') if previous_serialized and 'fields' in previous_serialized[0] else {}
        changed_obj_fields = get_changed_obj_fields(obj, current_json_obj, previous_json_obj, log_diff_ignored_fields)
        changed_fields = json.dumps(changed_obj_fields)
    return changed_fields

def get_parent_obj_model_as_tuple(obj):
    parent_model = obj._meta.db_table
    parent_pk = obj.pk if obj.pk else 0
    if hasattr(obj, 'SpectrumMeta'):
        parent_obj_name = getattr(obj.SpectrumMeta, 'parent', None)
        if parent_obj_name:
            parent_instance = getattr(obj, parent_obj_name, None)
            if parent_instance:
                parent_model = parent_instance._meta.db_table
                parent_pk = parent_instance.pk
    return parent_model,parent_pk


def save_snapshot_obj(objs, parent_model, parent_pk, action_id):
    """
    related object may not override 'HistoryModel'
    So don't use related_object.serialize_to_json()
    :param objs:
    :param parent_model:
    :param parent_pk:
    :param action_id:
    :return:
    """
    try:
        serializer = SpectrumSerializer()
        data = serializer.serialize(objs)
        snapshot = ActionRelatedSnapshot(action_id=action_id,
                                     obj_model=objs[0]._meta.db_table,
                                     obj_pk=objs[0].pk,
                                     parent_model=parent_model,
                                     parent_pk=parent_pk,
                                     obj_snapshot=data)
        snapshot.save()
    except:
        pass

def serialize_and_save_included_objects(obj, parent_model, parent_pk, action_id):
    """
    serialize obj and save.
    If obj implements HistoryModel, serialize child objects which has 'SpectrumMeta' attribute 'related_to_serialize'
    However, this function does not support m2m relation, in which case use HistoryModel.save_related_object_as_snapshot
    :param obj:
    :param parent_model:
    :param parent_pk:
    :param action_id:
    :return:
    """
    stack_list = []
    def save_serialized_object(obj, parent_model, parent_pk):
        """
        use stacklist to avoid infinite recursive serialize action.
        :param obj:
        :param parent_model:
        :param parent_pk:
        :return:
        """
        if obj not in stack_list and len(stack_list) < 100:
            save_snapshot_obj([obj], parent_model, parent_pk, action_id)
            stack_list.append(obj)

    def save_serialized_object_list(obj, parent_model, parent_pk):
        save_serialized_object(obj, parent_model, parent_pk)
        if isinstance(obj, HistoryModel):
            related_objects = obj.get_related_objects_to_serialize()
            if related_objects:
                parent_model = obj._meta.db_table
                parent_pk = obj.pk
                for related_object in related_objects:
                    save_serialized_object_list(related_object, parent_model, parent_pk)

    save_serialized_object_list(obj, parent_model, parent_pk)

def log_queryset_delete(queryset, request=None):
    #TODO: improve performance using bulk update. There is a reason for multi queryset delete
    try:
        for obj in queryset:
            try:
                is_allowed_to_log = (hasattr(obj, "SpectrumMeta") and getattr(obj.SpectrumMeta, "track", True)) \
                   or not hasattr(obj, "SpectrumMeta")
                if is_allowed_to_log:
                    ChangeActionHistory.log_change_action(obj, action_type=shared_constants.DELETE_ACTION, request=request)
            except Exception,e:
                print e
    except Exception, e:
        from spectrum_api.shared_components.utils.common import log_error
        log_error(e)

class HistoryModel(models.Model):
    all_objects = models.Manager()
    objects = ActiveManager()
    active_locked_objects = ActiveAndLockedManager()
    active_draft_objects = ActiveDraftManager()
    nondeleted_objects = NonDeletedManager()
    log_diff_ignored_fields = ['date_modified', 'date_updated', 'latest_history_id', 'modify_time','create_time',
                          'update_time', 'latest_updater', 'time_updated','time_created']

    class Meta:
        abstract = True

    def admin_link(self):
        if self.pk:
            if self._meta.object_name.lower() == 'vip':
                base_link = u'<a href="/config/base/#/%s/config/%s/">%s</a>'
            else:
                base_link = u'<a href="/config/base/#/%s/%s/">%s</a>'

            return mark_safe(base_link % (self._meta.object_name.lower() + 's', self.pk, self))
        else:
            return mark_safe(u'')

    def get_locked_model(self):
        if hasattr(self, "SpectrumMeta") and getattr(self.SpectrumMeta, "locked_model", False):
            locked_model = getattr(self.SpectrumMeta, "locked_model")
        else:
            locked_model = None
        return locked_model

    def get_locked_field(self):
        if hasattr(self, "SpectrumMeta") and getattr(self.SpectrumMeta, "locked_field", False):
            locked_field = getattr(self.SpectrumMeta, "locked_field")
        else:
            locked_field = None
        return locked_field

    @log_exception(default_return_value=shared_constants.UPDATE_ACTION)
    def validate_obj_state(self, overwrite_lock):
        locked_model = self.get_locked_model()
        locked_field = self.get_locked_field()

        action_type = self.get_action_type()
        for field in self._meta.fields:
            try:
                field_value = getattr(self, field.attname)
            except:
                field_value = None

            if not is_protected_type(field_value):
                try:
                    field_value = field.value_to_string(self)
                except Exception,e:
                    pass

            if field.name == 'obj_state':
                if field_value == 0:
                    action_type = shared_constants.DISABLE_ACTION
                elif field_value == 3 and overwrite_lock == False:
                    raise Exception("This object is locked.")

            if field.name == locked_field:
                locked_obj = locked_model.all_objects.get(pk=field.value_from_object(self))
                if locked_obj.obj_state == 3 and overwrite_lock == False:
                    raise Exception("This object is locked")
        return action_type

    def validate_read_only_state(self):
        """
        if SpectrumMeta class exists and has read_only block save
        :return:
        """
        if hasattr(self, "SpectrumMeta") and getattr(self.SpectrumMeta, "read_only", False):
            raise Exception("Save is prohibited")

    def is_allowed_to_log(self, request=None):
        """
        if you want to avoid request when you save, make model like below:
            class SpectrumMeta:
                track=False
        :return:
        """
        is_track_enabled = (hasattr(self, "SpectrumMeta") and getattr(self.SpectrumMeta, "track", True))
        is_allowed_to_log = is_track_enabled or not hasattr(self, "SpectrumMeta")
        return is_allowed_to_log

    def is_allowed_to_delete(self):
        delete_allowed = hasattr(self, "SpectrumMeta") and getattr(self.SpectrumMeta, "allow_delete", False)
        if delete_allowed:
            return delete_allowed
        else:
            field_names = [field.name for field in self._meta.fields]
            has_state_field = 'obj_state' in field_names or 'use_flag' in field_names
            return not has_state_field

    def get_previous_obj(self):
        if self.pk:
            try:
                myobj = get_object_or_404(self.__class__, pk=self.pk)
                return myobj
            except:
                return None
        else:
            return None

    def get_action_type(self):
        if self.pk:
            action_type = shared_constants.UPDATE_ACTION
        else:
            action_type = shared_constants.INSERT_ACTION
        return action_type

    def save(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        overwrite_lock = kwargs.pop('overwrite_lock', False)
        previous_self = kwargs.pop('previous_self',None)
        if request is None:
            request = get_request()

        action_type = self.validate_obj_state(overwrite_lock)
        self.validate_read_only_state()
        previous_self = self.get_previous_obj() if previous_self is None else previous_self

        super(HistoryModel, self).save(*args, **kwargs)
        if self.is_allowed_to_log():
            self.update_history(previous_obj=previous_self, request=request, action_type=action_type)


    def delete(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        if request is None:
            request = get_request()

        if self.is_allowed_to_delete():
            if self.is_allowed_to_log():
                self.update_history(request=request, action_type=shared_constants.DELETE_ACTION)
            super(HistoryModel, self).delete(*args, **kwargs)
        else:
            raise Exception("Delete action is prohibited.")

    def save_old_log_for_legacy_view(self, previous_obj, request, action_type):
        try:
            user_id, user_email, user_ip, app_name = get_userinfo_as_tuple_from_context(request)
            if action_type == shared_constants.UPDATE_ACTION:
                json_action_obj = previous_obj.toJSON()
            else:
                json_action_obj = self.toJSON()
            action_history = ActionHistory(user=request.user,
                                        action_obj=json_action_obj,
                                        action_model=self._meta.db_table,
                                        action_pk=self.pk,
                                        user_ip=user_ip,
                                        action_type=action_type)
            action_history.save()
        except Exception,e:
            pass

    def update_history(self, previous_obj=None, request=None, action_type=None):
        """
        if size of action_obj and change_diff is larger than 4096, save snapshot data separately
        :param previous_obj:
        :param request:
        :param action_type:
        :return:
        """
        result = None
        if action_type == shared_constants.DELETE_ACTION:
            self.save_old_log_for_legacy_view(self, request, action_type=action_type)
            result = ChangeActionHistory.log_change_action(obj=self,
                                                      action_type=action_type,
                                                      request=request)
        else:
            self.save_old_log_for_legacy_view(previous_obj, request, action_type)
            result = ChangeActionHistory.log_change_action(obj=self, previous_obj=previous_obj,
                                              action_type=action_type,
                                              request=request,
                                              log_diff_ignored_fields=HistoryModel.log_diff_ignored_fields)
        return result

    @log_exception()
    def update_latest_change_action(self, latest_action_id=None):
        ChangeActionHistory.update_latest_change_action(obj=self, latest_action_id=latest_action_id)

    def get_latest_change_action_id(self):
        """
        get latest change action id of model instance
        :return:
        """
        return ChangeActionHistory.get_latest_change_action_id(self)

    def get_changed_field(self, current_obj=None, previous_obj=None):
        return get_changed_obj_fields(obj=self, current_obj=current_obj, previous_obj=previous_obj)

    def serialize_to_json(self):
        serializer = SpectrumSerializer()
        data = serializer.serialize([self])
        return data

    def deserialize_from_json(self, json_data):
        """
        serialize returns iterator.
        since we put queryset objects to serialize, we need to pop just 1 item from iterator
        :param json_data:
        :return:
        """
        #objs = serializers.deserialize('json', json_data) #
        objs = SpectrumJSONDeserializer(json_data)
        for obj in objs:
            return obj
            #obj.object.save(request=get_request())

    def toJSON(self):
        """
        for legacy logging
        :return:
        """
        try:
            opts = self._meta
            action_obj = {}
            for field in opts.fields:
                try:
                    field_name = getattr(self, field.name)
                except:
                    field_name = None
                if type(field_name) != str and type(field_name) != int:
                    field_name = smart_str(field_name)
                action_obj[field.name] = field_name

            jsondata = simplejson.dumps(action_obj)
            return jsondata
        except Exception, e:
            return ''

    def get_related_objects_to_serialize(self):
        opts = self._meta
        results = []
        related_list_to_serialize = getattr(self.SpectrumMeta, 'related_to_serialize', [])

        for field in opts.fields:
            if field.rel and field.name in related_list_to_serialize:
                related_obj = getattr(self, field.name)
                if related_obj:
                    results.append(related_obj)
        return results

class DatedHistoryModel(HistoryModel):
    create_user = models.CharField(max_length=30, editable=False)
    modify_user = models.CharField(max_length=30, editable=False)
    modify_time = models.DateTimeField(auto_now=True, editable=False)
    create_time = models.DateTimeField(auto_now_add=True, editable=False)

    log_diff_ignored_fields = ['create_user','modify_user','modify_time','create_time']

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        if kwargs.has_key('request'):
            request = kwargs.pop('request')
            self.modify_user = request.user.username
            if not self.pk:
                self.create_user = self.modify_user
        else:
            request = None
            if kwargs.has_key('user') and isinstance(kwargs['user'],(str,unicode)):
                self.modify_user = kwargs.pop('user')[0:30]
                if not self.pk:
                    self.create_user = self.modify_user
            else:
                user_id, user_email, user_ip, app_name = get_userinfo_as_tuple_from_context(request=request)
                self.modify_user = user_email
                if not self.pk:
                    self.create_user = self.modify_user

        super(DatedHistoryModel,self).save(*args,**kwargs)

class BaseModel(models.Model):
    all_objects = models.Manager()
    objects = ActiveManager()
    active_locked_objects = ActiveAndLockedManager()
    active_draft_objects = ActiveDraftManager()
    nondeleted_objects = NonDeletedManager()

    class Meta:
        abstract = True

    def get_locked_model(self):
        if hasattr(self, "SpectrumMeta") and getattr(self.SpectrumMeta, "locked_model", False):
            locked_model = getattr(self.SpectrumMeta, "locked_model")
        else:
            locked_model = None
        return locked_model

    def get_locked_field(self):
        if hasattr(self, "SpectrumMeta") and getattr(self.SpectrumMeta, "locked_field", False):
            locked_field = getattr(self.SpectrumMeta, "locked_field")
        else:
            locked_field = None
        return locked_field

    def save(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        if request == None:
            try:
                request = FakeRequest()
            except:
                request = None
        overwrite_lock = kwargs.pop('overwrite_lock', False)
        if hasattr(settings, "TEST_MODE"):
            super(BaseModel, self).save(*args, **kwargs)
            return

        if hasattr(self, "SpectrumMeta") and getattr(self.SpectrumMeta, "with_no_request", False):
            super(BaseModel, self).save(*args, **kwargs)
            return

        locked_model = self.get_locked_model()
        locked_field = self.get_locked_field()

        for field in self._meta.fields:
            try:
                field_name = getattr(self, field.name)
            except:
                field_name = None
            if type(field_name) != str and type(field_name) != int:
                try:
                    field_name = smart_str(field_name)
                except:
                    field_name = ''
                    pass
            if field.name == 'obj_state' and field_name == 3 and overwrite_lock == False:
                raise Exception("This object is locked.")

            if field.name == locked_field:
                # locked_obj = locked_model.all_objects.get(pk=field.value_from_object(self))
                locked_obj = locked_model.all_objects.get(pk=field.value_from_object(self))
                if locked_obj.obj_state == 3 and overwrite_lock == False:
                    raise Exception("This object is locked")

        # if SpectrumMeta class exists and has read_only block save
        if hasattr(self, "SpectrumMeta") and getattr(self.SpectrumMeta, "read_only", False):
            raise Exception("Save is prohibited")

        # track is default
        action_type = None
        if (hasattr(self, "SpectrumMeta") and getattr(self.SpectrumMeta, "track", True)) or not hasattr(self, "SpectrumMeta"):
            if not isinstance(request, bool):
                """
                'request' value type must be WSGIRequest class.
                if not, that is saved by db_validater command
                for validation. or the other reason. nomally, if you want
                to avoid request when you save, make model like below:
                    class SpectrumMeta:
                        track=False
                """
                if not request:
                    raise Exception("Request object required to save")
                if not request.user:
                    raise Exception("Authenticated user required to save")
                action_type = None
                if self.pk:
                    action_type = 2  # UPDATE
                    # actions = ActionHistory.objects.filter(action_model=self._meta.db_table,action_pk=self.pk)[:1]
                    # if not actions:
                    #    self.update_history(request, action_type)
                else:
                    action_type = 1  # INSERT

        super(BaseModel, self).save(*args, **kwargs)
        if action_type:
            self.update_history(request, action_type)

    def delete(self, *args, **kwargs):
        if hasattr(self, "SpectrumMeta") and getattr(self.SpectrumMeta, "allow_delete", False):
            request = kwargs.pop('request', None)
            if request:
                if not request.user:
                    raise Exception("Authenticated user required to delete")
                self.update_history(request, 3)
            super(BaseModel, self).delete(*args, **kwargs)
        else:
            raise Exception("Delete is prohibited.")

    def update_history(self, request, actiontype=None):
        try:
            try:
                if actiontype == None:
                    action_type = 2
                else:
                    action_type = int(actiontype)
            except:
                action_type = 2

            if action_type == 2:  # if update, save previous self
                previous_self = get_object_or_404(self.__class__, pk=self.pk)
                json_action_obj = previous_self.toJSON()
            else:
                json_action_obj = self.toJSON()

            if self.pk:  # update
                obj_pk = self.pk
            else:
                obj_pk = 0

            action_history = ActionHistory(user=request.enduser,
                                        action_obj=json_action_obj,
                                        action_model=self._meta.db_table,
                                        action_pk=obj_pk,
                                        user_ip=request.enduser.ip,
                                        action_type=action_type)

            action_history.save(using=request.enduser.db_name)
        except Exception, e:
            print e

    def toJSON(self):
        try:
            opts = self._meta
            action_obj = {}
            for field in opts.fields:
                try:
                    field_name = getattr(self, field.name)
                except:
                    field_name = None
                if type(field_name) != str and type(field_name) != int:
                    field_name = smart_str(field_name)
                action_obj[field.name] = field_name

            jsondata = simplejson.dumps(action_obj)
            return jsondata
        except Exception, e:
            print e
            return ''

class BaseActionHistory(BaseModel):
    action_id = models.AutoField(primary_key=True)
    action_model = models.CharField(max_length=50)
    action_pk = models.IntegerField()
    action_obj = models.TextField()
    user_ip = models.IPAddressField()
    action_time = models.DateTimeField(auto_now_add=True)
    action_type = models.IntegerField(choices=shared_constants.ACTION_TYPE)

    def __unicode__(self):
        return self.action_model

    class Meta:
        abstract = True

class ActionHistory(BaseActionHistory):
    user = models.ForeignKey(User, db_column='user_id')

    def __unicode__(self):
        return self.action_model

    def getjsondict(self):
        import json
        # previous_action = self.getPreviousAction()
        # current_action = self.getCurrentJsondata()
        return json.loads(self.action_obj)

    def getPreviousAction(self):
        actions = ActionHistory.objects.filter(
            action_model=self.action_model,
            action_pk=self.action_pk,
            action_id__lt=self.action_id).order_by('-action_id')[:1]
        if len(actions) >= 1:
            return actions[0]
        else:
            return None

    def getNextAction(self):
        actions = ActionHistory.objects.filter(
            action_model=self.action_model,
            action_pk=self.action_pk,
            action_id__gt=self.action_id).order_by('action_id')[:1]
        if len(actions) >= 1:
            return actions[0]
        else:
            return None

    def getjsondata(self):
        import json
        result = []
        dicts = json.loads(self.action_obj)
        for key in dicts:
            result.append("%s:<b>%s</b>, " % (smart_str(key), smart_str(dicts[key])))
        return ''.join(result)

    def getjsonitem(self, query):
        result = ''
        try:
            dicts = self.getjsondict()
            for key in dicts:
                if key == query:
                    result = smart_str(dicts[key])
                    break
        except Exception, e:
            pass
        return result

    class Meta:
        db_table = 'core_action_history'

    class SpectrumMeta:
        track = False
        with_no_request = True


class ActionEventLog(BaseModel):
    id = models.AutoField(primary_key=True, db_column='id')
    username = models.CharField(max_length=100)
    event_sender = models.CharField(max_length=200)
    app_name = models.CharField(max_length=100)
    request_message = models.CharField(max_length=2048)
    message_log = models.TextField(max_length=4096)
    result_message = models.CharField(max_length=2048)
    post_message = models.CharField(max_length=2048)
    stack_error_message = models.CharField(max_length=2048)
    event_description = models.TextField(max_length=2048, blank=True)
    log_level = models.IntegerField(null=True)
    user_ip = models.IPAddressField()
    date_created = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'action_event_log'

    class SpectrumMeta:
        track = False
        with_no_request = True

    def __unicode__(self):
        return "%s %s by %s" % (str(self.id), self.event_sender, self.user)

    @classmethod
    def create_action_event(cls, message='', error_message='', request=None, context=None, user_info=None,
                            request_message='', event_sender='', app_name='', post_message='', log_level=1):
        if not user_info:
            user_info = get_userinfo_from_context(request)
        error_message = error_message[:2047] if len(error_message) > 2047 else error_message

        action_event = ActionEventLog()
        action_event.username = user_info.get('user_email', '')
        action_event.app_name = app_name if app_name else user_info.get('app_name','')
        action_event.message_log = message
        action_event.user_ip = user_info.get('user_ip','')
        action_event.post_message = post_message if post_message else user_info.get('post_message')
        action_event.event_sender = event_sender if event_sender else user_info.get('request_path','')
        action_event.request_message = request_message if request_message else user_info.get('request_message','')
        action_event.log_level = 3 if error_message else log_level
        action_event.stack_error_message = error_message[:2047] if len(error_message) > 2047 else error_message
        try:
            parameter_context = context.copy() if context else None
            if 'password' in parameter_context:
                parameter_context.update({'password':'******'})
            action_event.event_description = parameter_context
        except:
            pass
        action_event.save()
        return action_event.pk


class BaseStatMaster(BaseModel):
    from spectrum_api.shared_components.models.customer import CustomerItem, CustomerDisplay
    stat_id = models.AutoField(primary_key=True)
    obj_state = models.PositiveSmallIntegerField(default=1, choices=OBJ_STATE_CHOICES)
    material_no = models.PositiveIntegerField()
    keyword = models.CharField(max_length=255)
    display_name = models.CharField(max_length=255)
    platform_no = models.IntegerField(null=True, blank=True)
    platform_cd = models.SmallIntegerField(default=0)
    ocsp_keyword_idx = models.IntegerField(null=True, blank=True)
    ocsp_keyword_region = models.IntegerField(null=True, blank=True)
    parent_stat_id = models.PositiveIntegerField(null=True)
    daemon_type_cd = models.CharField(null=True, max_length=1)
    top_dir_depth = models.IntegerField(null=True)
    date_created = models.DateTimeField(auto_now=True)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    completion_rate_flag = models.IntegerField(null=True, max_length=4)
    service_remove_flag = models.SmallIntegerField(null=True, blank=True)

    class Meta:
        db_table = 'stat_master'
        abstract = True
        ordering = ['display_name']

    def __unicode__(self):
        return self.display_name

class StatMaster(BaseStatMaster):
    from spectrum_api.shared_components.models.customer import CustomerItem, CustomerDisplay
    item = models.ForeignKey(CustomerItem, null=True, db_column='item_id',
                            related_name='statmaster_item')
    customer = models.ForeignKey(CustomerDisplay, null=True,
                                db_column='customer_id',
                                related_name='statmaster_customer')
    class SpectrumMeta:
        router = 'default'
        allow_delete = True

    def __unicode__(self):
        # pending deactivation should show deactivated as well? get obj_state for that
        return self.display_name + (" (DEACTIVATED)" if self.obj_state != 1 else "")


class csStatMaster(BaseModel):
    csStatMaster_id = models.AutoField(primary_key=True, db_column='id')
    statmaster_id = models.ForeignKey(StatMaster, db_column='statmaster_id')
    obj_state = models.PositiveSmallIntegerField(default=1, choices=OBJ_STATE_CHOICES)
    domain = models.CharField(max_length=200)


    class Meta:
        db_table = 'cs_stat_master'


class LegacyStatMaster(BaseModel):
    statmaster_id = models.ForeignKey(StatMaster, primary_key=True, db_column='statmaster_id')
    obj_state = models.SmallIntegerField(blank=False, default=1)
    stat_svc_name = models.CharField(max_length=200, default=None)
    date_created = models.DateTimeField(auto_now_add=True)
    date_modified = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'legacy_stat_master'

    def __unicode__(self):
        return u"%s" % self.statmaster_id

class ChangeActionHistory(models.Model):
    action_id = models.AutoField(primary_key=True, editable=False)
    action_model = models.CharField(max_length=50, editable=False)
    parent_model = models.CharField(max_length=50, editable=False)
    user_email = models.CharField(max_length=100, editable=False)
    app_name = models.CharField(max_length=100, editable=False)
    request_id = models.CharField(max_length=32)
    action_pk = models.IntegerField(editable=False)
    parent_pk = models.IntegerField(editable=False)
    change_diff = models.CharField(max_length=4096, editable=False)
    action_obj = models.CharField(max_length=4096, editable=False)
    user_ip = models.IPAddressField(blank=True, editable=False)
    action_time = models.DateTimeField(auto_now_add=True, editable=False)
    action_type = models.IntegerField(choices=shared_constants.CHANGE_ACTION_TYPE, editable=False)

    def __unicode__(self):
        return "%s %s" % (self.action_model, str(self.action_pk))

    class Meta:
        db_table = 'change_action_history'
        ordering = ['-action_id']

    @classmethod
    @log_exception(default_return_value=None)
    def log_change_action(cls, obj, previous_obj=None, previous_obj_json=None,
                          action_type=None, request=None, log_diff_ignored_fields=None):
        """
        log change action
        :param obj:
        :param previous_obj: previous object before change.
        :param previous_obj_json: if model fields has m2m field, those values are need to evaluated earlier rather than compare time.
        :param action_type:
        :param request:
        :param log_diff_ignored_fields: ignored to compare
        :return:
        """
        result = None
        if request is None:
            request = get_request()
        if previous_obj is None and previous_obj_json is None:
            previous_obj = get_current_obj_from_db(obj)
        if not action_type:
            action_type = shared_constants.INSERT_ACTION if not previous_obj else action_type
            action_type = shared_constants.UPDATE_ACTION if previous_obj and action_type is None else action_type

        current_json = serialize_obj_to_json(obj)
        previous_json = previous_obj_json if previous_obj_json else serialize_obj_to_json(previous_obj) if previous_obj else '{}'
        change_comment = get_changed_as_json(obj, current_json, previous_json, action_type, log_diff_ignored_fields)
        #action_obj = {'snapshot': current_json, 'change_diff': change_comment}
        action_obj = current_json if len(current_json) < 4096 else ''
        change_diff = change_comment if len(change_comment) < 4096 else ''

        user_info = get_userinfo_from_context(request)
        parent_model, parent_pk = get_parent_obj_model_as_tuple(obj)

        if change_comment and change_comment != '{}':
            action_history = ChangeActionHistory(user_email=user_info.get('user_email'),
                                        app_name=user_info.get('app_name'),
                                        change_diff=change_diff,
                                        action_obj=action_obj,
                                        action_model=obj._meta.db_table,
                                        parent_model=parent_model,
                                        parent_pk=parent_pk,
                                        action_pk=obj.pk if obj.pk else 0,
                                        request_id=getattr(request,'id',None),
                                        user_ip=user_info.get('user_ip'),
                                        action_type=action_type)
            action_history.save()
            result = action_history.pk

            if action_obj == '' or change_diff == '':
                action_snapshot = ActionSnapshotLongtext(action_id=action_history.pk,
                                         obj_model=obj._meta.db_table,
                                         obj_pk=obj.pk if obj.pk else 0,
                                         parent_model=parent_model,
                                         parent_pk=parent_pk,
                                         obj_snapshot=action_obj)
                action_snapshot.save()

            if action_type == shared_constants.SNAPSHOT_ACTION:
                snapshot_func = getattr(obj, "save_related_object_as_snapshot", None)
                if callable(snapshot_func):
                    obj.save_related_object_as_snapshot(action_history.pk)
                else:
                    serialize_and_save_included_objects(obj, parent_model, parent_pk, action_history.pk)
        if action_type in [shared_constants.INSERT_ACTION, shared_constants.UPDATE_ACTION]:
            cls.update_latest_change_action(obj=obj, latest_action_id=result)
        UserActionHistory.log_action(action_type, request, user_info, action_id=result, obj=obj)
        return result

    def get_action_type(self):
        return shared_constants.ACTION_TYPE[self.action_type-1][1]

    @log_exception(default_return_value=None)
    def get_object_from_action_model(self):
        obj = self.deserialize_from_json()
        return obj.object

    def deserialize_from_json(self, obj_json=None):
        """
        serialize returns iterator.
        since we put queryset objects to serialize, we need to pop just 1 item from iterator
        :param json_data:
        :return:
        """
        obj_json = obj_json if obj_json else self._get_action_obj()
        #objs = serializers.deserialize('json', obj_json) #
        objs = SpectrumJSONDeserializer(obj_json)
        for obj in objs:
            return obj

    @log_exception(default_return_value='')
    def _get_action_obj(self):
        if self.action_obj:
            return self.action_obj
        else:
            action_snapshot = ActionSnapshotLongtext.objects.get(action_id=self.pk,
                                                 obj_pk=self.action_pk,
                                                 obj_model=self.action_model)
            return action_snapshot.obj_snapshot

    def get_action_obj_snapshot(self):
        """
        if action_obj value is '', this indicates size of action_obj is larger thant 4096.
        In this case, it needs to lookup ActionSnapshotLongtext table
        """
        if len(self.action_obj) > 0:
            return load_dict_from_json(self.action_obj)
        else:
            try:
                action_snapshot = ActionSnapshotLongtext.objects.get(action_id=self.pk,
                                                                 obj_pk=self.action_pk,
                                                                 obj_model=self.action_model)
                return load_dict_from_json(action_snapshot.obj_snapshot)
            except:
                return {}

    def get_action_obj_changed_comment(self):
        """
        if change_diff value is '', this indicates size of change_diff is larger thant 4096.
        In this case, it needs to lookup ActionSnapshotLongtext table and generate diff on the spot
        """
        if len(self.change_diff) > 0:
            return self.change_diff
        else:
            #use get_action_obj_change_comment_ext()
            return 'Too many changes'

    def get_action_obj_change_comment_ext(self):
        """
        if change_diff value is '', this indicates size of change_diff is larger thant 4096.
        In this case, it needs to lookup ActionSnapshotLongtext table and generate diff on the spot
        """
        if len(self.change_diff) > 0:
            return self.change_diff
        else:
            try:
                action_snapshots = ActionSnapshotLongtext.objects.filter(action_id__lte=self.pk,
                                                                     obj_pk=self.action_pk,
                                                                     obj_model=self.action_model)[:2]
                if action_snapshots.count() > 1:
                    object = self.deserialize_from_json(action_snapshots[0].obj_snapshot)
                    #previous_object = self.deserialize_from_json(action_snapshots[1].ob_snapshot)

                    current_serialized = load_dict_from_json(action_snapshots[0].obj_snapshot)
                    previous_serialized = load_dict_from_json(action_snapshots[1].obj_snapshot)

                    current_json_obj = current_serialized[0].get('fields') if 'fields' in current_serialized[0] else {}
                    previous_json_obj = previous_serialized[0].get('fields') if 'fields' in previous_serialized[0] else {}
                    changed_fields = object.get_changed_field(current_json_obj, previous_json_obj)
                    return json.dumps(changed_fields)
            except:
                return ''

    @classmethod
    def get_histories_by_obj(cls, obj):
        if obj:
            change_actions = ChangeActionHistory.objects.filter(action_model=obj._meta.db_table,
                                                            action_pk=obj.pk).order_by("-action_id")
            return change_actions
        else:
            return ChangeActionHistory.objects.none()

    @classmethod
    def get_latest_change_action_id(cls, obj):
        """
        get latest change action id of model instance
        :return:
        """
        action_histories = ChangeActionHistory.objects.filter(action_model=obj._meta.db_table,
                                                              action_pk=obj.pk).order_by('-action_id')[:1]
        if action_histories.exists():
            return action_histories[0].action_id
        else:
            return None


    @classmethod
    @log_exception()
    def update_latest_change_action(cls, obj, latest_action_id=None):
        if not latest_action_id:
            latest_action_id = cls.get_latest_change_action_id(obj)

        try:
            latest_action = LatestChangeAction.objects.get(model_name=obj._meta.db_table, model_pk=obj.pk)
            latest_action.chage_action_history_id = latest_action_id
            latest_action.save()
        except LatestChangeAction.DoesNotExist:
            latest_action = LatestChangeAction(model_name=obj._meta.db_table,
                                               model_pk=obj.pk,
                                               change_action_history_id=latest_action_id)
            latest_action.save()


class ActionRelatedSnapshot(models.Model):
    id = models.AutoField(primary_key=True, editable=False)
    action_id = models.IntegerField(editable=False)
    obj_model = models.CharField(max_length=50, editable=False)
    parent_model = models.CharField(max_length=50, editable=False)
    obj_pk = models.IntegerField(editable=False)
    parent_pk = models.IntegerField(editable=False)
    obj_snapshot = models.CharField(max_length=4096, editable=False)

    def __unicode__(self):
        return "Snapshot(%s): %s %s" % (str(self.action_id), self.obj_model, str(self.obj_pk))

    class Meta:
        db_table = 'action_related_snapshot'

class ActionSnapshotLongtext(models.Model):
    """
    use this model if size of obj_snapshot is larger than 4096
    """
    id = models.AutoField(primary_key=True, editable=False)
    action_id = models.IntegerField(editable=False)
    obj_model = models.CharField(max_length=50, editable=False)
    parent_model = models.CharField(max_length=50, editable=False)
    obj_pk = models.IntegerField(editable=False)
    parent_pk = models.IntegerField(editable=False)
    obj_snapshot = models.TextField(editable=False)

    def __unicode__(self):
        return "Snapshot(%s): %s %s" % (str(self.action_id), self.obj_model, str(self.obj_pk))

    class Meta:
        db_table = 'action_snapshot_longtext'

class UserActionHistory(models.Model):
    id = models.AutoField(primary_key=True)
    user_id = models.IntegerField()
    user_email = models.CharField(max_length=100)
    app_name = models.CharField(max_length=100)
    request_path = models.CharField(max_length=100)
    request_id = models.CharField(max_length=32)
    action_type = models.SmallIntegerField(choices=shared_constants.USER_ACTION_TYPE)
    related_action_id = models.BigIntegerField()
    action_dict = models.CharField(max_length=512)
    user_ip = models.CharField(max_length=15)
    action_time = models.DateTimeField(auto_now_add=True)

    def __unicode__(self):
        return "%s - %s" % (self.user_email, str(self.action_type))

    class Meta:
        db_table = 'user_action_history'
        app_label = 'shared_components'

    @classmethod
    @log_exception()
    def log_action(cls, action_type, request=None, user_info=None, action_id=None, obj=None):
        user_info = get_userinfo_from_context(request) if user_info is None else user_info
        app_name=user_info.get('app_name')
        if action_id is None and app_name in ['prism_api']:
            #logging with no change is pointless for operator
            pass
        else:
            action_dict = json.dumps({obj._meta.db_table: obj.pk}) if obj else '{}'
            request = get_request() if request is None else request
            user_action = UserActionHistory(user_id=user_info.get('user_id'),
                                        user_email=user_info.get('user_email'),
                                        app_name=user_info.get('app_name'),
                                        request_path=user_info.get('request_path'),
                                        request_id=getattr(request,'id',None),
                                        action_type=action_type,
                                        related_action_id = action_id,
                                        action_dict=action_dict,
                                        user_ip=user_info.get('user_ip'))
            user_action.save()

    def get_event_manager(self):
        try:
            from spectrum_api.shared_components.models.mailer import EventManager
            is_myinfra_push = self.is_myinfra_push_action()
            if self.action_type == shared_constants.PUSH_TO_PRODUCTION:
                if is_myinfra_push:
                    event_name = shared_constants.EVENT_MYINFRA_PUSH_TO_PRODUCTION
                else:
                    event_name = shared_constants.EVENT_CDNS_PUSH_TO_PRODUCTION
            else:
                if is_myinfra_push:
                    event_name = shared_constants.EVENT_MYINFRA_PUSH_TO_STAGING
                else:
                    event_name = shared_constants.EVENT_CDNS_PUSH_TO_STAGING

            event_manager = EventManager.objects.get(event_type=self.action_type, event_name=event_name)
            return event_manager
        except:
            return None


    def is_myinfra_push_action(self):
        from spectrum_api.configuration.models.config import ConfigDistAction
        action = self.get_related_action()
        if isinstance(action, ConfigDistAction):
            return action.is_CLB_Myinfra_push()
        else:
            return False

    def get_related_action(self):
        """
        return ChangeActionHistory or ConfigDistAction
        :return:
        """
        action = None
        if self.action_type in shared_constants.CHANGE_ACTIONS:
            action = ChangeActionHistory.objects.get(pk=self.related_action_id)
        elif self.action_type in shared_constants.PUSH_ACTIONS:
            from spectrum_api.configuration.models.config import ConfigDistAction
            action = ConfigDistAction.objects.get(pk=self.related_action_id)
        else:
            action = None

        return action

    def get_customer_related_zone_list(self):
        result_list = []
        if self.action_type in shared_constants.PUSH_ACTIONS:
            dist_action = self.get_related_action()
            result_list = dist_action.get_related_zone_list(self)

        return result_list



class LatestChangeAction(models.Model):
    id = models.AutoField(primary_key=True)
    model_name = models.CharField(max_length=50)
    model_pk = models.PositiveIntegerField()
    change_action_history_id = models.PositiveIntegerField()
    modify_time = models.DateTimeField(auto_now=True)
    create_time = models.DateTimeField(auto_now_add=True)

    def __unicode__(self):
        return "%s(%s) - %s" % (self.model_name, str(self.model_pk), str(self.change_action_history_id))

    class Meta:
        db_table = 'latest_change_action'


class StatMasterForStorage(BaseStatMaster):
    from spectrum_api.shared_components.models.customer import CustomerItem, CustomerDisplay
    cs_stat_master = models.ManyToManyField(csStatMaster,
                                            db_table='cs_stat_master',
                                            related_name='cs_stat_master_set')
    legacy_stat_master = models.ManyToManyField(LegacyStatMaster,
                                                db_table='legacy_stat_master',
                                                related_name='legacy_stat_master_set')
    item = models.ForeignKey(CustomerItem, null=True, db_column='item_id',
                             related_name='statmaster_item')
    customer = models.ForeignKey(CustomerDisplay, null=True,
                                 db_column='customer_id',
                                 related_name='statmaster_customer')


class HermesMapStatMaster(BaseModel):
    id = models.AutoField(primary_key=True, db_column='hermesmap_id')
    stat_id = models.ForeignKey(StatMaster, db_column='stat_id')
    corporation_cd = models.CharField(max_length=5)
    service_set = models.CharField(max_length=100)
    isBilling = models.PositiveSmallIntegerField(default=1)
    obj_state = models.PositiveSmallIntegerField(default=1, choices=OBJ_STATE_CHOICES)  # 0 , 1 , 2 , 3 default : 1
    date_created = models.DateField(auto_now_add=True)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)

    class Meta:
        db_table = 'hermesmap_stat_master'

    class SpectrumMeta:
        allow_delete = True


# LegacyServiceDomainStatMap belong to models.customer but LegacyStatMaster class has to import problem.
# So, We move LegacyServiceDomainStatMap class to here.
#   - See the definition of 'BaseStatMaster'
#   - This file and models.customer are to import each other.
class LegacyServiceDomainStatMap(BaseModel):
    from spectrum_api.shared_components.models.customer import LegacyServiceDomain
    id = models.AutoField(primary_key=True, db_column='svc_domain_stat_map_id')
    svc_domain = models.ForeignKey(LegacyServiceDomain, db_column='svc_domain_id')
    legacy_stat = models.ForeignKey(LegacyStatMaster, db_column='legacy_stat_id')

    class Meta:
        db_table = 'legacy_service_domain_stat_map'

    class SpectrumMeta:
        allow_delete = True

