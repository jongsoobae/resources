from datetime import date, timedelta
from django.db import models
from django.db.models import Q
from django.utils import simplejson
from django.utils.encoding import smart_str
from django.utils.translation import ugettext as _
from django.core.validators import MaxValueValidator, MinValueValidator
from spectrum_api.shared_components.models import BaseModel, DatedHistoryModel, HistoryModel
from spectrum_api.shared_components.utils.customer_utils import get_region_nm

class CustomerAccount(BaseModel):
    account_no = models.PositiveIntegerField(primary_key=True, db_column='account_no')
    account_name_eng = models.CharField(max_length=255, null=True)
    account_name_local = models.CharField(max_length=255, null=True)
    sales_org = models.IntegerField()
    telco_type = models.SmallIntegerField(null=True)
    create_time = models.DateTimeField(auto_now_add=True)
    description = models.TextField()

    class Meta:
        app_label = 'shared_components'
        db_table = 'customer_account'

    class SpectrumMeta:
        track = False

    def __unicode__(self):
        return u"%s" % (self.account_name_eng)

    def get_accountno(self):
        return str(self.account_no).zfill(10)

    def sync_contact_data(self, request):
        from spectrum_api.sap.sap_calls import sync_contact_data
        try:
            sync_contact_data(request, self.account_no, None)
        except Exception, e:
            raise e

    def getContracts(self, material_no=None):
        if material_no:
            contracts = CustomerContract.objects.filter(account=self, account__customercontract__customeritem__material_no=material_no)
        else:
            contracts = CustomerContract.objects.filter(account=self)
        return contracts

    def getContactlist(self):
        from spectrum_api.shared_components.models.dashboard import CustomerContact  # , CustomerContractContact
        return CustomerContact.objects.filter(account__pk=int(self.account_no))

    def hasContactEmail(self, email):
        # from spectrum_api.shared_components.models.dashboard import CustomerContact
        result = False
        contactlist = self.getContactlist()
        for contact in contactlist:
            if contact.email.strip() == email.strip():
                result = True
                break;
        return result

    def get_accountinfo_changed(self, accountlist):
        try:
            for account in accountlist:
                if not self.is_accountinfo_identical(account):
                    return account
        except:
            pass
        return None

    def is_accountinfo_identical(self, account):
        if self.get_accountno() != account.get_accountno():
            return False
        return True


    def getContractItems(self):
        return CustomerItem.objects.filter(contract__account=self) \
            .values('item_id', 'contract__account__account_name_local', 'contract__contract_name', 'contract__contract_no', 'item_no', 'material_no', 'contract__contract_type')

    def getResellerType(self):
        if self.telco_type:
            if self.telco_type == 1:
                return 'TELCO'
            elif self.telco_type == 2:
                return 'VAR'
            else:
                return ''
        else:
            return ''

class AbstractCustomerAccount(BaseModel):
    account_no = models.PositiveIntegerField(primary_key=True, db_column='account_no')
    account_name_eng = models.CharField(max_length=255, null=True)
    account_name_local = models.CharField(max_length=255, null=True)
    sales_org = models.IntegerField()
    create_time = models.DateTimeField(auto_now_add=True)

    class Meta:
        abstract = True
        db_table = 'customer_account'


class CustomerContract(BaseModel):
    contract_no = models.PositiveIntegerField(primary_key=True)
    contract_name = models.CharField(max_length=255)
    account = models.ForeignKey(CustomerAccount, db_column='account_no')
    service_type = models.CharField(max_length=255)
    ocsp_region = models.PositiveIntegerField()
    create_time = models.DateTimeField(auto_now_add=True)
    contract_type = models.CharField(max_length=255)
    contract_start = models.DateField()
    contract_end = models.DateField()
    contract_terminate = models.DateField(null=True)
    tz_offset = models.IntegerField(default=0)
    sales_rep_name = models.CharField(max_length=100, null=True)
    sales_engineer_no = models.PositiveIntegerField(null=True)
    sales_engineer_name = models.CharField(max_length=100, null=True)
    sales_engineer_email = models.CharField(max_length=255, null=True)
    sales_engineer_no2 = models.PositiveIntegerField(null=True)
    sales_engineer_name2 = models.CharField(max_length=100, null=True)
    sales_engineer_email2 = models.CharField(max_length=255, null=True)
    sales_org = models.IntegerField()
    # sales_charge =  models.CharField(max_length=100, null=True)
    # sales_charge_txt =  models.CharField(max_length=100, null=True)
    reseller_account_no = models.PositiveIntegerField(null=True);
    telco_account_no = models.PositiveIntegerField(null=True);

    contract_type_tx = models.CharField(max_length=40, null=True)  # 3 AUART_TX(contract_type_tx)
    sales_org_tx = models.CharField(max_length=40, null=True)  # 5 VKORG_TX (sales_org_tx)
    market_channel = models.CharField(max_length=4, null=True)  # 6 VTWEG (market_channel)
    market_channel_tx = models.CharField(max_length=40, null=True)  # 7 VTWEG_TX (market_channel_tx)
    product = models.CharField(max_length=4, null=True)  # 8 SPART (product)
    product_tx = models.CharField(max_length=40, null=True)  # 9 SPART_TX (product_tx)
    business_place = models.CharField(max_length=4, null=True)  # 10 VKBUR (business_place)
    business_place_tx = models.CharField(max_length=40, null=True)  # 11 VKBUR_TX (business_place_tx)
    business_team = models.CharField(max_length=6, null=True)  # 12 VKGRP (business_team)
    business_team_tx = models.CharField(max_length=40, null=True)  # 13 VKGRP_TX (business_team_tx)
    update_time = models.DateTimeField(auto_now=True)  # 24 update_date
    billing_start_date = models.DateField() # FBUDA billing start date
    billing_date = models.CharField(max_length=3, null=True) # KVGR2 billing date ex(01, 20, 25, PT)
    #------------------- aurora --------------------------

    class Meta:
        app_label = 'shared_components'
        db_table = 'customer_contract'

    class SpectrumMeta:
        track = False

    def is_valid_contract(self, material_no):
        today = date.today()
        yesterday = today - timedelta(days=1)

        if ((self.contract_terminate and yesterday <= self.contract_terminate) and \
            yesterday <= self.contract_end) or (yesterday <= self.contract_end and \
            self.contract_terminate == None):
            customer_items = CustomerItem.objects.filter(contract=self, material_no=material_no).\
                                                filter(Q(status_code__isnull=True) | Q(status_code=''))
            if customer_items.exists():
                return True
            else:
                return False
        else:
            return False

    def __unicode__(self):
        return u"%s" % (self.contract_name)

    def getFullName(self):
        return "%s (%s)" % (self.contract_name, self.account.account_name_eng)

    def getTelcoAccount(self):
        if self.telco_account_no:
            try:
                account = CustomerAccount.objects.get(pk=self.telco_account_no)
            except:
                account = None
        else:
            account = None
        return account

    @property
    def ocsp_region_name(self):
        return get_region_nm(self.ocsp_region)

    @property
    def sales_org_name(self):
        return get_region_nm(self.sales_org)


class CustomerItem(BaseModel):
    item_id = models.AutoField(primary_key=True)
    item_no = models.PositiveIntegerField()
    contract = models.ForeignKey(CustomerContract, db_column='contract_no')
    parent_item = models.ForeignKey('CustomerItem',
                                db_column='parent_item_id',
                                null=True)
    material_no = models.PositiveIntegerField()
    material_desc = models.CharField(max_length=255, null=True)
    hierarchy_no = models.CharField(max_length=50, null=True)
    hierarchy_desc = models.CharField(max_length=255, null=True)
    create_time = models.DateTimeField(auto_now_add=True)
    service_type = models.CharField(max_length=10, null=True)
    service_type_txt = models.CharField(max_length=100, null=True)
    sales_charge = models.CharField(max_length=20, null=True)
    sales_charge_txt = models.CharField(max_length=40, null=True)
    #------------------- aurora --------------------------
    sales_doc_category = models.CharField(max_length=16, null=True)  # 5 PSTYV (sales_doc_category)
    material_tx = models.CharField(max_length=160, null=True)  # 7 MAKTX (material_tx)
    price = models.CharField(max_length=44, null=True)  # 8 NETPR (price)
    committed_amount = models.CharField(max_length=60, null=True)  # 9 NETWR (committed_amount)
    currency = models.CharField(max_length=20, null=True)  # 10 WAERK (currency)
    commitment = models.CharField(max_length=52, null=True)  # 11 ZMENG (commitment)
    unit = models.CharField(max_length=12, null=True)  # 12 ZIEME (unit)
    status_code = models.CharField(max_length=8, null=True)  # 13 ABGRU (status_code)
    status_code_tx = models.CharField(max_length=80, null=True)  # 14 ABGRU_TX (status_code_tx)
    billing_method_code = models.CharField(max_length=8, null=True)  # 17 PLTYP (billing_method_code)
    billing_method = models.CharField(max_length=80, null=True)  # 18 PLTYP_TX (billing_method )
    billing_standards = models.CharField(max_length=8, null=True)  # 19 KONDM (billing_standards)
    billing_standards_tx = models.CharField(max_length=80, null=True)  # 20 KONDM_TX (billing_standards_tx)
    relay_traffic = models.CharField(max_length=12, null=True)  # 21 MVGR1 (relay_traffic )
    relay_traffic_tx = models.CharField(max_length=80, null=True)  # 22 MVGR1_TX (relay_traffic_tx )
    weighted_grade_code = models.CharField(max_length=12, null=True)  # 23 MVGR2  (weighted_grade_code )
    weighted_grade_code_tx = models.CharField(max_length=80, null=True)  # 24 MVGR2_TX  (weighted_grade_code_tx )
    rounding_rule_code = models.CharField(max_length=12, null=True)  # 25 MVGR3  (rounding_rule_code )
    rounding_rule_code_tx = models.CharField(max_length=80, null=True)  # 26 MVGR3_TX  (rounding_rule_code_tx)
    rounding_unit_code = models.CharField(max_length=12, null=True)  # 27 MVGR4 (rounding_unit_code )
    rounding_unit_code_tx = models.CharField(max_length=80, null=True)  # 28 MVGR4_TX (rounding_unit_code_tx )
    option = models.CharField(max_length=12, null=True)  # 29 MVGR5 (option)
    option_tx = models.CharField(max_length=80, null=True)  # 30 MVGR5_TX (option_tx)
    price_type = models.CharField(max_length=8, null=True)  # 31 PROVG (price_type)
    record_tx = models.CharField(max_length=80, null=True)  # 32 PROVG_TX (record_tx)
    cpu = models.CharField(max_length=80, null=True)  # 33 ZCPU (cpu)
    ram = models.CharField(max_length=80, null=True)  # 34 ZRAM (ram)
    disk = models.CharField(max_length=80, null=True)  # 35 ZDISK (disk)
    others = models.CharField(max_length=80, null=True)  # 36 ZOTHERS (others)
    rate = models.CharField(max_length=44, null=True)  # 37 RSRAT (rate)
    rate_unit = models.CharField(max_length=20, null=True)  # 38 KOEIN (rate_unit)
    update_orderer = models.CharField(max_length=4, null=True)  # 39 UPDKZ (update_orderer)
    value_added_service = models.CharField(max_length=16, null=True)  # 40 MTPOS (value_added_service)
    product = models.CharField(max_length=8, null=True)  # 41 SPART (product)
    option_code = models.CharField(max_length=40, null=True)  # 44 CHARG (option_code)
    option_name = models.CharField(max_length=160, null=True)  # 45 CHARG_TX (option_name)
    update_time = models.DateTimeField(auto_now=True)  # 47 update_date
    sdabw = models.CharField(max_length=4, null=True)  # 48 SDABW (sdabw)
    portal_flag = models.CharField(max_length=2, null=True)  # 48 PORTF (portal_flag)
    #------------------- aurora --------------------------
    bill_to_account = models.PositiveIntegerField(null=True)
#     obj_state = models.PositiveSmallIntegerField(max_length=1 , null=True)

    class Meta:
        app_label = 'shared_components'
        db_table = 'customer_item'
        unique_together = ('item_no', 'contract')

    class SpectrumMeta:
        track = False

    def __unicode__(self):
        return u"%s (%s)" % (self.contract.contract_name, self.item_no)

    def getBillToAccount(self):
        if self.bill_to_account:
            try:
                account = CustomerAccount.objects.get(pk=self.bill_to_account)
            except:
                account = None
        else:
            account = None
        return account

    @property
    def expired(self):
        if self.status_code is None or self.status_code == '':
            valid = self.contract.is_valid_contract(self.material_no)
            return not valid
        else:
            return True


    def getContractDisplayName(self):
        return u"[%s-%s] %s" % (self.contract.contract_no, self.item_no, self.contract.contract_name)

    @property
    def contract_name(self):
        return self.contract.contract_name

    def get_cloudstorage_cluster_limit(self):
        try:
            cluster_count = str(self.sales_charge).upper().strip()

            if cluster_count[-1] == 'P':
                cluster_count_limit = int(cluster_count[:-1])
            else:
                cluster_count_limit = int(cluster_count)
        except:
            cluster_count_limit = 0

        return cluster_count_limit


class CustomerDisplay(BaseModel):
    customer_id = models.AutoField(primary_key=True)
    account = models.ForeignKey(CustomerAccount, db_column='account_no')
    obj_state = models.PositiveSmallIntegerField(default=1)
    parent_customer = models.ForeignKey('CustomerDisplay',
                        db_column='parent_customer_id',
                        null=True)
    ocsp_region = models.PositiveIntegerField()
    tz_offset = models.IntegerField(default=0)
    customer_name = models.CharField(max_length=255)
    service_group_key = models.PositiveIntegerField()
    items = models.ManyToManyField(CustomerItem,
                    db_table='customer_display_customer_item',
                    related_name='items_set')

    class Meta:
        app_label = 'shared_components'
        db_table = 'customer_display'

    class SpectrumMeta:
        track = False

    def __unicode__(self):
        return u"%s [%s]" % (self.customer_name, self.getRegionName())

    def getContracts(self, material_no=None):
        if material_no:
            contracts = self.account.getContracts(material_no)
        else:
            contracts = self.account.getContracts()
        return contracts

    def getRegionName(self):
        return get_region_nm(self.ocsp_region)

    def getAccountRegionName(self):
        return get_region_nm(self.account.sales_org)

    def getCanonicalName(self):
        customername = "%s[%s]" % (self.account.account_name_eng, self.getRegionName())
        return customername

    def get_or_create_customer_pop(self, request, airport, rttserver, enable_glsb):
        from spectrum_api.configuration.models.base import Pop
        pop_prefix = 'C0' + str(self.account_id).zfill(10)

        is_created = False
        for i in range(1, 9999):
            cust_idx = str(i).zfill(4)
            pop_name = pop_prefix + cust_idx + '-' + airport
            try:
                pop_obj = Pop.all_objects.get(pop_name=pop_name)
            except:
                pop_obj = None

            if pop_obj == None:
                pop_obj = Pop(pop_name=pop_name)
                if not rttserver is None:
                    pop_obj.rttserver = rttserver
                pop_obj.enable_gslb = enable_glsb
                pop_obj.save(request=request)
                is_created = True
                break;
        return pop_obj, is_created

    def get_clb_pop_deploy_status(self, request=None):
        '''get pop status among clb related pops which belongs to customer
        return min_pop_status,related_zone_status,timeout,time_deployed,errmsg,all_failed_zones,all_failed_clb_domains
        priority: 1 > 3 > 0(new,modified:time_deployed) > -2(1:timeout) > 2 > -4(3:timeout) > 4
        '''
        from django.db.models import Min
        from spectrum_api.configuration.models.base import Pop
        from spectrum_api.configuration.models.clb import CustomerContractPop

        min_pop_status = 4
        related_zone_status = 4
        all_failed_zones = []
        all_failed_clb_domains = []
        timeout = False
        time_deployed = ''
        errmsg = []
        try:
            cust_clb_contract_pops = CustomerContractPop.all_objects.filter(customer=self).filter(use_type=1).all()
            cust_clb_pops = Pop.objects.filter(pk__in=cust_clb_contract_pops.values('pop'))

            if cust_clb_pops.exists():
                cust_clb_pops = cust_clb_pops.filter(status__in=[-4, -2, 0, 1, 2, 3, 4])  # all status
                staging_pops = cust_clb_pops.filter(status__in=[-2, 0, 1])  # reday to deploayed to production
                pending_pops = cust_clb_pops.filter(status__in=[1, 3])  # pending
                new_modified_pops = cust_clb_pops.filter(status=0)
                new_staged_pops = cust_clb_pops.filter(status=2)

                new_modified_exist = False
                if new_modified_pops.exists():
                    new_modified_exist = True

                staged_exist = False
                if new_staged_pops.exists():
                    staged_exist = True

                # pop_status = cust_clb_pops.aggregate(min_pop_status = Min('pop__status')).get('min_pop_status')
                is_related_zone_stage_pending = False
                is_related_zone_production_pending = False
                for pop in cust_clb_pops:
                    is_related_zone_stage_pending, is_related_zone_production_pending, zone_deploy_status, \
                        zone_deploy_failed, failed_zones, failed_clb_domains = pop.has_related_clb_zone_deploy_failed()
                    if zone_deploy_failed:
                        # if min_zone_status > zone_deploy_status:
                        #    min_zone_status = zone_deploy_status
                        # min_pop_status = zone_deploy_status
                        for failed_zone in failed_zones:
                            if failed_zone not in all_failed_zones:
                                all_failed_zones.append(failed_zone)
                        for failed_clb_domain in failed_clb_domains:
                            if failed_clb_domain not in all_failed_clb_domains:
                                all_failed_clb_domains.append(failed_clb_domain)

                    popstatus = pop.status
                    if popstatus == 2 and is_related_zone_stage_pending:# cust_clb.pop.is_related_clb_zone_domain_stage_pending():
                        related_zone_status = 1  # this should be interpreted as push action not completed
                    if popstatus == 4 and is_related_zone_production_pending:  # cust_clb.pop.is_related_clb_zone_domain_production_pending():
                        related_zone_status = 3  # this should be interpreted as push action not completed

                    if min_pop_status > popstatus:
                        min_pop_status = popstatus

                pending_pop_exist = False
                if pending_pops.exists():  # 1,3
                    for pending_pop in pending_pops:
                        if pending_pop.get_timeout():  # 1,3 (timeout)
                            timeout = True
                        else:  # 1,3
                            pending_pop_exist = True

                staging_exist = False
                staging_failed = False
                for staging_pop in staging_pops:  # -2,0,1
                    staging_exist = True
                    if staging_pop.status == 1:
                        if staging_pop.get_timeout():
                            staging_failed = True
                            timeout = True
                        else:
                            timeout = False  # override timeout false if set true by when pop status = 3
                    elif staging_pop.status == -2:
                        staging_failed = True

                ### start of exceptional case handling for min pop status###
                # min_pop_status: -4,-2,0,1,2,3,4
                if staging_failed:  # -2, 1(timeout)
                    if min_pop_status in [-4, -2]:
                        if not timeout:  # if production fail exist, staging fail precdedes
                            min_pop_status = -2
                    else:
                        min_pop_status = 1  # timeout
                        # timout = True

                    if min_pop_status == -2 and new_modified_exist:
                        min_pop_status = 0
                else:  # -4,0,1,2,3
                    if staging_exist:  # -2,0,1 - (-2,1(timeout))  ==> 0,1
                        min_pop_status = 0
                    else:  # -4,2,3
                        if timeout:  # 3(timeout)
                            min_pop_status = 3
                            if staged_exist:  # 2
                                min_pop_status = 2
                        if min_pop_status == -4:  # -4(production failed),2 (staging)
                            if staged_exist:  # 2
                                min_pop_status = 2

                if min_pop_status == 0:  # make it clear whether pop is new or modified by setting time_deployed
                    if new_modified_exist:
                        time_deployed = new_modified_pops[0].time_deployed

                # pending status overrides all previous status
                if pending_pop_exist:  # 1,3
                    if staging_exist:  # -2,0,1
                        min_pop_status = 1  # this case would override staging failed case
                    else:
                        min_pop_status = 3
                ### end of exceptional case handling for min pop status###

                if len(all_failed_zones) > 0:
                    errmsg.append("Deploy failed zone:%s" % (','.join(all_failed_zones)))
                    if len(all_failed_clb_domains) > 0:
                        errmsg.append("Deploy failed domain:%s" % (','.join(all_failed_clb_domains)))
                # -4(production failed),2 (staging),4(published) case
        except Exception, e:
            pass

        return min_pop_status, related_zone_status, \
               timeout, time_deployed, errmsg, all_failed_zones, all_failed_clb_domains


class CustomerDisplayItem(BaseModel):
    customerdisplay = models.ForeignKey(CustomerDisplay)
    customeritem = models.ForeignKey(CustomerItem)

    def __unicode__(self):
        return u"%s" % (self.customeritem)

    class Meta:
        db_table = 'customer_display_customer_item'

    class SpectrumMeta:
        track = False


class CustomerItemOperator(BaseModel):
    item_operator_id = models.AutoField(primary_key=True)
    item = models.ForeignKey(CustomerItem, db_column='item_id')
    email = models.CharField(max_length=255)
    prime = models.IntegerField()
    date_created = models.DateTimeField(auto_now_add=True, editable=False)
    date_modified = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'customer_item_operator'


class PlatformNo(BaseModel):
    platform_no = models.IntegerField(primary_key=True)
    platform_name = models.CharField(max_length=64)
    date_created = models.DateTimeField(auto_now_add=True, editable=False)

    class Meta:
        db_table = 'platform_no'


class CustomerItemPlatform(BaseModel):
    item_platform_id = models.AutoField(primary_key=True)
    item = models.ForeignKey(CustomerItem, db_column='item_id')
    platform = models.ForeignKey(PlatformNo, db_column='platform_no')
    date_created = models.DateTimeField(auto_now_add=True, editable=False)

    class Meta:
        db_table = 'customer_item_platform'


class CustomerSfaOrder(BaseModel):
    csorderno = models.PositiveIntegerField(primary_key=True)
    item = models.ForeignKey(CustomerItem, db_column='item_id')
    work_type = models.CharField(max_length=50)
    work_type_code = models.CharField(max_length=50)
    create_time = models.DateTimeField(auto_now_add=True)
    status = models.SmallIntegerField(default=0)
    platform = models.ForeignKey(PlatformNo, db_column='platform_no', null=True)

    class Meta:
        app_label = 'shared_components'
        db_table = 'customer_sfa_order'

    class SpectrumMeta:
        track = False

    def get_platform_name(self):
        try:
            return self.platform.platform_name
        except:
            return ''

#------------------- aurora --------------------------
class CustomerContractPartner(BaseModel):
    partner_id = models.AutoField(primary_key=True)
    contract = models.ForeignKey(CustomerContract, db_column='contract_no')  # 1 VBELN (contract_no)
    item_no = models.PositiveIntegerField()  # 2 POSNR (item_no)
    partner_type = models.CharField(max_length=8, null=True)  # 3 PARVW (partner_type)
    partner_type_tx = models.CharField(max_length=80, null=True)  # 4 VTEXT (partner_type_tx)
    suppliers_no = models.CharField(max_length=40, null=True)  # 7 LIFNR (suppliers_no)
    am_no = models.CharField(max_length=40, null=True)  # 9 PERNR (am_no)
    am_name = models.CharField(max_length=140, null=True)  # 10 NAMES (am_name)
    contact_no = models.CharField(max_length=40, null=True)  # 11 PARNR (contact_no)
    name1 = models.CharField(max_length=140, null=True)  # 12 NAMEP (name1)
    name = models.CharField(max_length=140, null=True)  # 13 NAMEV (name)
    address = models.CharField(max_length=40, null=True)  # 14 ADRNR (address)
    land = models.CharField(max_length=12, null=True)  # 15 LAND1 (land)
    create_time = models.DateTimeField(auto_now_add=True)  # 16 create_time
    update_time = models.DateTimeField(auto_now=True)  # 17 update_time

    class Meta:
        app_label = 'shared_components'
        db_table = 'customer_contract_partner'
        unique_together = ('contract', 'partner_type')

    class SpectrumMeta:
        track = False
#------------------- aurora --------------------------

class IhmsZone(BaseModel):
    zone_id = models.AutoField(primary_key=True)
    zone_code = models.CharField(max_length=10)
    zone_name = models.CharField(max_length=200)

    class Meta:
        app_label = 'shared_components'
        db_table = 'ihms_zone'

class SFAZone(BaseModel):
    zone_id = models.AutoField(primary_key=True)
    zone_code = models.CharField(max_length=10)
    zone_name = models.CharField(max_length=200)
    sort_order = models.PositiveSmallIntegerField()

    class Meta:
        app_label = 'shared_components'
        db_table = 'sfa_zone'

class SFAZoneHasIhmsZone(BaseModel):
    id = models.AutoField(primary_key=True)
    sfa_zone_id = models.ForeignKey(SFAZone, db_column='sfa_zone_id')
    ihms_zone_id = models.ForeignKey(IhmsZone, db_column='ihms_zone_id')
    service_area = models.PositiveIntegerField()

    class Meta:
        app_label = 'shared_components'
        db_table = 'sfa_zone_has_ihms_zone'

class OcspMigCustomer(BaseModel):
    account_no = models.ForeignKey(CustomerAccount, db_column='account_no')
    ocsp_corporation_cd = models.CharField(max_length=2)

    class Meta:
        app_label = 'shared_components'
        db_table = 'ocsp_mig_customer'

class CustomerPush(HistoryModel):
    from spectrum_api.configuration.models.config import ConfigDistAction

    customer_push_id = models.AutoField(primary_key=True)
    customer = models.ForeignKey(CustomerDisplay, db_column='customer_id')
    config_dist_action = models.ForeignKey(ConfigDistAction, db_column='config_dist_action_id')
    time_updated = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = 'shared_components'
        db_table = 'customer_push'
        ordering = ['-time_updated']

INTERNAL_USER = 0
CUSTOMER_USER = 1
PUSH_USER_TYPE = ((INTERNAL_USER,'INTERNAL'),(CUSTOMER_USER,'CUSTOMER'),)
NGP_PUSH = 0
CS_PUSH = 1
PUSH_TYPE = ((NGP_PUSH, 'NGP PUSH'),(CS_PUSH,'CS PUSH'),)
H_USER_NAME = _('''
User Name of aurora user in case user_type is 'CUSTOMER'.
User Name of prism user in case user_type is 'INTERNAL'.
''')
H_PUSH_RATE_COUNT = _('''
Threshold count value for 'push rate unit' minute.
* Acceptable range: 0 ~ 32767
<strong>Value 0 means that user is not allowed to push at all.</strong>
''')
H_PUSH_RATE_UNIT = _('''
Minutes of unit value for 'push rate count'. ex) 60 minute
* Acceptable range: 1 ~ 32767
<strong>Maximum value should be less than settings.PUSH_RATE_REDIS_CACHE_TTL</strong>
''')

class UserPushRateThreshold(DatedHistoryModel):
    id = models.AutoField(primary_key=True)
    user_type = models.SmallIntegerField(choices=PUSH_USER_TYPE, default=1)
    user_id = models.IntegerField(blank=True, null=True, editable=False)
    user_name = models.CharField(help_text=H_USER_NAME, max_length=100)
    push_type = models.SmallIntegerField(choices=PUSH_TYPE, default=0)
    push_rate_count = models.SmallIntegerField(validators=[MinValueValidator(0), MaxValueValidator(32767)],
                                               help_text=H_PUSH_RATE_COUNT)
    push_rate_unit = models.SmallIntegerField(validators=[MinValueValidator(1),
                                                          MaxValueValidator(32767)],
                                              help_text=H_PUSH_RATE_UNIT)
    description = models.CharField(max_length=1024, blank=True, default='')

    class Meta:
        db_table = 'user_push_rate_threshold'
        app_label = 'shared_components'
        managed = False

    class SpectrumMeta:
        allow_delete = True

    def __unicode__(self):
        return "%s: %s (%s)" % (PUSH_USER_TYPE[self.user_type][1], self.get_user_name(), self.user_id)

    def get_user_name(self):
        try:
            return "%s" % (self.user_name)
        except:
            return ''

    def save(self):
        super(UserPushRateThreshold, self).save()

class ServiceTypeCd(BaseModel):
    service_type_cd = models.PositiveIntegerField(primary_key=True, db_column='service_type_cd')
    service_type_name = models.CharField(max_length=100, blank=False)
    material_group_cd = models.CharField(max_length=10, blank=False)
    obj_state = models.SmallIntegerField(blank=False, default=1)

    class Meta:
        db_table = 'service_type_cd'

    def __unicode__(self):
        return u"%s" % self.service_type_cd


class LegacyAddService(BaseModel):
    SERVICE_TYPE_CHOICES = (
        ('D', 'Aqua director'),
        ('P', 'Aqua player'),
        ('M', 'Monitoring'),
    )
    add_svc_id = models.AutoField(primary_key=True, db_column='add_svc_id')
    add_svc_type = models.CharField(max_length=1, blank=False, choices=SERVICE_TYPE_CHOICES)
    service_type_cd = models.ForeignKey(ServiceTypeCd, default=None, db_column='service_type_cd')
    account = models.ForeignKey(CustomerAccount, blank=False, db_column='account_no')
    add_svc_name = models.CharField(max_length=200, blank=False)
    item = models.ForeignKey(CustomerItem, default=None, db_column='item_id')
    obj_state = models.SmallIntegerField(blank=False, default=1)
    date_created = models.DateTimeField(auto_now_add=True)
    date_modified = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'legacy_add_service'
        unique_together = ('add_svc_type', 'account', 'add_svc_name', 'service_type_cd')

    def __unicode__(self):
        return u"%s" % self.add_svc_id

    def get_service_by_account_id(self, account_id, service_type):
        return LegacyAddService.objects.filter(account=account_id, add_svc_type=service_type)

    class SpectrumMeta:
        allow_delete = True


class LegacyServiceDomain(BaseModel):
    svc_domain_id = models.AutoField(primary_key=True)
    svc_domain_name = models.CharField(max_length=256)
    item = models.ForeignKey(CustomerItem, db_column='item_id')
    date_created = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'legacy_service_domain'

    class SpectrumMeta:
        allow_delete = True

