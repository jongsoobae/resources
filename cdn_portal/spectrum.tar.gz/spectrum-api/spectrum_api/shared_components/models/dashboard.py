from django.db import models
from spectrum_api.shared_components.models import BaseModel
from spectrum_api.shared_components.models.customer import CustomerAccount, \
    CustomerContract, CustomerItem, CustomerDisplay
from spectrum_api.shared_components.models import BaseStatMaster

class StatMaster(BaseStatMaster):
    item = models.ForeignKey(CustomerItem, null=True, db_column='item_id',
                            related_name='statmasterdashboard_item')
    customer = models.ForeignKey(CustomerDisplay, null=True,
                                db_column='customer_id',
                                related_name='statmasterdashboard_customer')
    class SpectrumMeta:
        router = 'default'
        track = False  # request object not required to save

# 5
class CustomerContact(BaseModel):
    contact_no = models.PositiveIntegerField(primary_key=True, db_column='contact_no')  #
    account = models.ForeignKey(CustomerAccount, db_column='account_no')
    first_name = models.CharField(max_length=250, null=True)
    last_name = models.CharField(max_length=250, null=True)
    title = models.CharField(max_length=50, null=True)
    email = models.CharField(max_length=255, null=True)
    phone = models.CharField(max_length=50, null=True)
    mobile = models.CharField(max_length=50, null=True)
    obj_state = models.PositiveSmallIntegerField(default=1)
    #------------------- aurora --------------------------
    contact_role = models.CharField(max_length=20, null=True)  # pafkt
    contact_role_desc = models.CharField(max_length=100, null=True)  # pafkt_Tx
    use_contact = models.CharField(max_length=20, null=True)  # pavip
    #------------------- aurora --------------------------

    class Meta:
        db_table = 'customer_contact'

    class SpectrumMeta:
        track = False

class CustomerContractContact(BaseModel):
    customer_contract_contact_id = models.AutoField(primary_key=True)
    contract = models.ForeignKey(CustomerContract, db_column='contract_no')
    contact = models.ForeignKey(CustomerContact, db_column='contact_no')
    contact_role = models.CharField(max_length=20, null=True)
    contact_role_desc = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = 'customer_contract_contact'

    def save(self, *args, **kwargs):
        super(CustomerContractContact, self).save(*args, **kwargs)

    class SpectrumMeta:
        allow_delete = True
        track = True

