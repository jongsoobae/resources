#
# Copyright (c) 2011 CDNetworks Co., Ltd.
# All rights reserved.
#
# $Id: __init__.py 11864 2014-01-02 02:15:00Z kookheon.kwon $
#

from django.core.exceptions import ValidationError
from django.db.models.fields import FloatField


class InfinityFloatField(FloatField):
    """ We assume Infinity is 4294967295(4G). """

    def to_python(self, value):
        if value is None:
            return value
        try:
            if value == float('inf'):
                return 4294967295
            return float(value)
        except (TypeError, ValueError):
            raise ValidationError(self.error_messages['invalid'])
