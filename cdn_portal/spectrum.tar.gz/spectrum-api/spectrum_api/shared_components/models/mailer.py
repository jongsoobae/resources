import datetime
import json
from django.db import models
from django.core.cache import cache
from django.utils.encoding import smart_str
from spectrum_api.shared_components.mail import managers
from spectrum_api.shared_components.utils import shared_constants
from spectrum_api.shared_components.mail import send_mail
#from spectrum_api.shared_components.utils.api import AuroraAPIManager
now = datetime.datetime.utcnow


class EventManager(models.Model):
    id = models.AutoField(primary_key=True)
    event_name = models.CharField(max_length=200)
    event_type = models.SmallIntegerField(default=shared_constants.GENERAL, choices=shared_constants.ACTION_TYPE)
    relation_rules = models.CharField(max_length=1024, blank=True)
    description = models.CharField(max_length=1024, blank=True)
    date_created = models.DateTimeField(default=now, editable=False)

    class Meta:
        db_table='event_manager'
        ordering = ('-id',)
        app_label = 'shared_components'

    def __unicode__(self):
        return self.event_name

    def get_subscribers(self, user_action=None):
        data = []
        subscribers = MailerSubscriber.objects.filter(event_manager=self).values_list('email', flat=True)
        #try:
            #if user_action and self.event_type == shared_constants.PUSH_TO_PRODUCTION:
                #zone_list = [str(x) for x in user_action.get_customer_related_zone_list()]
                #uri = 'rest/user/email/list/zones/'
                #response = aurora_api.request(uri,{'zone_list':','.join(zone_list)})
                #data = json.loads(response._content).get('data')
        #except Exception,e:
        #    pass

        return list(subscribers) + data

    def generate_message(self):
        """
        return email title and message body template
        """
        title = ''
        template_manager = EventMessageTemplate.objects.get(event_manager=self)
        message_list = template_manager.template.replace("\r\n","\n").split('\n')
        if message_list[0].strip().lower()[:6] == 'title:':
            title = message_list[0][7:]
        return title, template_manager.template

class MailerSubscriber(models.Model):
    event_manager = models.ForeignKey(EventManager, db_column='event_id')
    corp_code = models.PositiveSmallIntegerField(default=0, editable=False)
    email = models.EmailField(max_length=200)
    date_created = models.DateTimeField(default=now, editable=False)

    class Meta:
        db_table='mailer_subscriber'
        ordering = ('-date_created',)
        app_label = 'shared_components'

class EventActionQueue(models.Model):
    id = models.AutoField(primary_key=True)
    event_key = models.CharField(max_length=512)
    event_manager = models.ForeignKey(EventManager, db_column='event_id')
    action_type = models.SmallIntegerField(choices=shared_constants.ACTION_TYPE)
    related_action_id = models.BigIntegerField()
    queue_status = models.SmallIntegerField(choices=shared_constants.EVENT_QUEUE_STATUS, default=0)
    description = models.CharField(max_length=1024, blank=True)
    create_user = models.CharField(max_length=200)
    date_created = models.DateTimeField(default=now, editable=False)

    class Meta:
        db_table='event_action_queue'
        ordering = ('-id',)
        app_label = 'shared_components'

    def __unicode__(self):
        return "%s %s %s" % (self.event_manager, self.related_action_id, self.event_key)

    def get_action_user_mail(self):
        try:
            if self.action_type <= shared_constants.PUSH_TO_PRODUCTION:
                from spectrum_api.shared_components.models import UserActionHistory
                user_action = UserActionHistory.objects.get(pk=self.related_action_id)
                return user_action.user_email
            else:
                return None
        except:
            pass
        return None

    def get_related_actions(self):
        user_action = None
        action = None
        if self.action_type <= shared_constants.PUSH_TO_PRODUCTION:
            from spectrum_api.shared_components.models import UserActionHistory
            user_action = UserActionHistory.objects.get(pk=self.related_action_id)
            action = user_action.get_related_action()
        else:
            action = None
        return user_action, action

    def is_condition_matched(self):
        result = False

        return result

    def process_action(self):
        """
        get recipients
        generate message
        check push status
        if push is done send mail
        """
        self.queue_status = shared_constants.WORKING
        try:
            from spectrum_api.configuration.models.config import ConfigDistAction
            user_action, related_action = self.get_related_actions()
            if related_action and isinstance(related_action, ConfigDistAction):
                if related_action.is_push_task_done():
                    recipients = []
                    invoker = self.get_action_user_mail()
                    recipients.append(invoker)
                    subscribers = self.event_manager.get_subscribers(user_action)
                    recipients += list(subscribers)
                    title, message = related_action.generate_notification_message(self.event_manager)

                    if title and message:
                        try:
                            from django.conf import settings
                            if settings.IS_TEST_USER_MAIL:
                                appended = "This email is test mail which was intended to be sent to %s" % str(recipients)
                                message = "%s \r\n %s" % (appended, message)
                                recipients = settings.TEST_MAIL_ACCOUNT
                        except:
                            pass
                        send_mail(title, message, invoker, recipients, actor=invoker)
                    self.queue_status = shared_constants.DONE
            self.save()
        except Exception,e:
            try:
                self.queue_status = shared_constants.FAILED
                self.description = str(e)[:1024]
                self.save()
            except Exception,ee:
                print ee


class EventMessageTemplate(models.Model):
    id = models.AutoField(primary_key=True)
    event_manager = models.ForeignKey(EventManager, db_column='event_id')
    template_type = models.SmallIntegerField(default=0, choices=shared_constants.TEMPLATE_TYPE)
    template = models.CharField(max_length=4096, blank=True)
    template_rule = models.CharField(max_length=4096, blank=True)
    template_file = models.CharField(max_length=200, blank=True)
    description = models.CharField(max_length=1024, blank=True)
    date_created = models.DateTimeField(default=now, editable=False)

    class Meta:
        db_table='mailer_event_message_template'
        ordering = ('-id',)
        app_label = 'shared_components'

    def __unicode__(self):
        return "message template %s %s" % (self.pk, self.template_type)

class MailerMessage(models.Model):
    """
    The ``to_address``, ``from_address`` and ``subject`` fields are merely for
    easy of access for these common values. The ``message_dict`` field
    contains the entire message as dictionary ready to be encoded as email message.
    """
    parent_id = models.BigIntegerField(blank=True,null=True)
    event_id = models.IntegerField(default=shared_constants.GENERAL)
    to_address = models.CharField(max_length=200)
    from_address = models.CharField(max_length=200)
    subject = models.CharField(max_length=255)
    context_parameters = models.CharField(max_length=4096, blank=True)
    encoded_message = models.TextField(db_column='message')
    create_user = models.CharField(max_length=200)
    date_created = models.DateTimeField(default=now,editable=False)

    class Meta:
        db_table='mailer_message'
        ordering = ('date_created',)
        app_label = 'shared_components'

    def __unicode__(self):
        return '%s: %s' % (self.to_address, self.subject)

    def get_status(self):
        status = 'Unknown'
        try:
            MailerQueuedMessage.objects.get(message=self)
            status = 'Pending'
        except MailerQueuedMessage.DoesNotExist:
            pass
        try:
            log = MailerLog.objects.get(message=self)
            status = log.get_status()
        except MailerLog.DoesNotExist:
            pass
        return status

    def get_date_sent(self):
        try:
            log = MailerLog.objects.get(message=self)
            return log.date
        except MailerLog.DoesNotExist:
            return None

    def is_ready_to_be_sent(self):
        """
        return ready_to_be_sent, is_sucess_event
        """
        return True, True

    def is_publish_event(self):
        return self.event_id == shared_constants.PUSH_TO_PRODUCTION

class MailerQueuedMessage(models.Model):
    """
    A queued message.

    Messages in the queue can be prioritised so that the higher priority
    messages are sent first (secondarily sorted by the oldest message).
    """
    message = models.OneToOneField(MailerMessage, editable=False)
    priority = models.PositiveSmallIntegerField(choices=shared_constants.PRIORITIES,
                                            default=shared_constants.PRIORITY_NORMAL)
    deferred = models.DateTimeField(null=True, blank=True)
    retries = models.PositiveIntegerField(default=0)
    date_queued = models.DateTimeField(default=now, editable=False)

    objects = managers.QueueManager()

    class Meta:
        db_table='mailer_queuedmessage'
        ordering = ('priority', 'date_queued')
        app_label = 'shared_components'

    def defer(self):
        self.deferred = now()
        self.save()

    def pre_process(self):
        self.message.pre_process()

class MailerBlacklist(models.Model):
    """
    A blacklisted email address.

    Messages attempted to be sent to e-mail addresses which appear on this
    blacklist will be skipped entirely.
    """
    email = models.EmailField(max_length=200)
    date_created = models.DateTimeField(default=now, editable=False)

    class Meta:
        db_table='mailer_blacklist'
        ordering = ('-date_created',)
        verbose_name = 'blacklisted e-mail address'
        verbose_name_plural = 'blacklisted e-mail addresses'
        app_label = 'shared_components'

    def __unicode__(self):
        return self.email

    def is_deletable(self):
        return True

class MailerLog(models.Model):
    """
    A log used to record the activity of a queued message.

    """
    message = models.ForeignKey(MailerMessage, editable=False)
    result = models.PositiveSmallIntegerField(choices=shared_constants.RESULT_CODES)
    date_created = models.DateTimeField(default=now, editable=False)
    log_message = models.TextField()

    class Meta:
        db_table='mailer_log'
        ordering = ('-date_created',)
        app_label = 'shared_components'

    def get_status(self):
        return shared_constants.RESULT_CODES[self.result][1]

