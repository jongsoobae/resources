from django.db import models
from spectrum_api.shared_components.models import BaseModel, BaseActionHistory
from django.contrib.auth.models import User
from django.utils.translation import ugettext as _
import datetime

class AuroraUser(BaseModel):
    username = models.CharField(_('username'), max_length=100, unique=True, help_text=_("Required. 30 characters or fewer. Letters, numbers and @/./+/-/_ characters"))
    first_name = models.CharField(_('first name'), max_length=30, blank=True)
    last_name = models.CharField(_('last name'), max_length=30, blank=True)
    email = models.EmailField(_('e-mail address'), blank=True)
    password = models.CharField(_('password'), max_length=128, help_text=_("Use '[algo]$[salt]$[hexdigest]' or use the <a href=\"password/\">change password form</a>."))
    is_staff = models.BooleanField(_('staff status'), default=False, help_text=_("Designates whether the user can log into this admin site."))
    is_active = models.BooleanField(_('active'), default=True, help_text=_("Designates whether this user should be treated as active. Unselect this instead of deleting accounts."))
    is_superuser = models.BooleanField(_('superuser status'), default=False, help_text=_("Designates that this user has all permissions without explicitly assigning them."))
    last_login = models.DateTimeField(_('last login'), default=datetime.datetime.now)
    date_joined = models.DateTimeField(_('date joined'), default=datetime.datetime.now)

    class Meta:
        db_table = 'aurora_auth_user'
        verbose_name = _('user')
        verbose_name_plural = _('users')

    def __unicode__(self):
        return self.username

    class SpectrumMeta:
        track = False
        read_only = True

class AuroraActionHistory(BaseActionHistory):
    user = models.ForeignKey(AuroraUser, db_column='user_id')

    class Meta:
        db_table = 'aurora_core_action_history'

    class SpectrumMeta:
        track = False
        read_only = True
