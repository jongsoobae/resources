from django.db import models
from datetime import datetime


class ProductionSnapshot(models.Model):
    username = models.CharField(max_length=128, db_column='user_name')
    snapshot_obj = models.CharField()
    user_ip = models.CharField(max_length=15)
    snapshot_model = models.CharField(max_length=128)
    model_pk = models.IntegerField()
    parent_model = models.CharField(max_length=128)
    parent_model_pk = models.IntegerField()
    obj_state = models.IntegerField()
    date_created = models.DateTimeField(default=datetime.now)
    date_modified = models.DateTimeField(default=datetime.now)

    class Meta:
        db_table = 'production_snapshot'

    def __unicode__(self):
        return u"%s %s" % (self.snapshot_model, str(self.model_pk))
