from django.db import models
from datetime import datetime


class User(models.Model):
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=128, blank=True)
    first_name = models.CharField(max_length=30, blank=True)
    last_name = models.CharField(max_length=30, blank=True)
    email = models.CharField(max_length=100, blank=True)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_superuser = models.BooleanField(default=False)
    last_login = models.DateTimeField(default=datetime.now)
    date_joined = models.DateTimeField(default=datetime.now)

    class Meta:
        db_table = 'auth_user'

    def __unicode__(self):
        return u"%s" % (self.username)


class AuroraUser(models.Model):
    id = models.AutoField(primary_key=True, db_column='id')
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=128, blank=True)
    first_name = models.CharField(max_length=30, blank=True)
    last_name = models.CharField(max_length=30, blank=True)
    email = models.CharField(max_length=100, blank=True)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_superuser = models.BooleanField(default=False)
    last_login = models.DateTimeField(auto_now=True)
    date_joined = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'auth_user'
        app_label = 'aurora'

    def __unicode__(self):
        return u"%s" % self.username

    def save(self, **kwargs):
        kwargs.pop('request', None)
        super(AuroraUser, self).save(**kwargs)

