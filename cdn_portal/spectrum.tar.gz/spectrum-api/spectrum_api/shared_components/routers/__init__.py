class SpectrumRouter(object):

    def db_for_read(self, model, **hints):
        if model._meta.app_label in ('helpdesk', 'mail_notification', 'aurora'):
            return 'aurora'
        elif model._meta.app_label == 'spectrum':
            return 'spectrum'
        elif model._meta.app_label == 'cloudsecurity':
            return 'stats'
        elif hasattr(model, "SpectrumMeta") and getattr(model.SpectrumMeta, "router", False):
            return model.SpectrumMeta.router
        return 'default'

    def db_for_write(self, model, **hints):
        if model._meta.app_label in ('helpdesk', 'mail_notification', 'aurora'):
            return 'aurora'
        elif model._meta.app_label == 'spectrum':
            return 'spectrum'
        elif model._meta.app_label == 'cloudsecurity':
            return 'stats'
        elif hasattr(model, "SpectrumMeta") and getattr(model.SpectrumMeta, "router", False):
            return model.SpectrumMeta.router

        return 'default'
