# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Domain Serializer
"""
from rest_framework import serializers

from spectrum_api.shared_components.models.customer import CustomerDisplay, \
    CustomerAccount, \
    CustomerContract, CustomerItem


class CustomerDisplaySimpleSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerDisplay
        fields = ("customer_id",
                  "customer_name",)

    @staticmethod
    def transform_customer_name(obj, value):
        return "%s [%s]" % (value.strip(), obj.getRegionName())


class CustomerDisplaySerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerDisplay
        fields = (
            "customer_id",
            "account",
            "obj_state",
            "parent_customer",
            "ocsp_region",
            "tz_offset",
            "customer_name",
            "service_group_key",
            # "items"
        )


class CustomerAccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerAccount
        fields = ("account_no",
                  "account_name_eng",
                  "account_name_local",
                  "sales_org",
                  "telco_type",
                  "create_time",
                  "description",)


class CustomerContractSerializer(serializers.ModelSerializer):
    ocsp_region_name = serializers.Field()

    class Meta:
        model = CustomerContract
        fields = ("contract_no",
                  "contract_name",
                  "account",
                  "service_type",
                  "ocsp_region",
                  "ocsp_region_name",
                  "create_time",
                  "contract_type",
                  "contract_start",
                  "contract_end",
                  "contract_terminate",
                  "tz_offset",
                  "sales_rep_name",
                  "sales_engineer_no",
                  "sales_engineer_name",
                  "sales_engineer_email",
                  "sales_engineer_no2",
                  "sales_engineer_name2",
                  "sales_engineer_email2",
                  "sales_org",
                  "reseller_account_no",
                  "telco_account_no",
                  "contract_type_tx",
                  "sales_org_tx",
                  "market_channel",
                  "market_channel_tx",
                  "product",
                  "product_tx",
                  "business_place",
                  "business_place_tx",
                  "business_team",
                  "business_team_tx",
                  "update_time",)


class CustomerItemSerializer(serializers.ModelSerializer):
    expired = serializers.Field()
    contract_name = serializers.Field()

    class Meta:
        model = CustomerItem
        fields = ()


class CustomerItemSimpleSerializer(serializers.ModelSerializer):
    contract_name = serializers.RelatedField(source="contract", read_only=True)

    class Meta:
        model = CustomerItem
        fields = ('item_id', 'item_no', 'contract', 'material_no', 'material_desc', 'contract_name')
        # depth = 1
