# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Domain Serializer
"""

from rest_framework import serializers
from spectrum_api.shared_components.models import ActionHistory
from django.utils import simplejson

class ActionObjField(serializers.WritableField):
    def to_native(self, obj):
        return simplejson.loads(obj)

class ActionHistorySerializer(serializers.ModelSerializer):
    action_type_display = serializers.RelatedField(source="get_action_type_display")
    username = serializers.RelatedField(source="user")
    action_obj = ActionObjField(source="action_obj")
    class Meta:
        model = ActionHistory