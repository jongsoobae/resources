from rest_framework import serializers
from spectrum_api.shared_components.models.user import AuroraUser
from spectrum_api.mail_notification.serializers.mail_notification \
    import AuthUserMailNotificationBulkSerializer


class AuroraUserSerializer(serializers.ModelSerializer):
    mail_notification = AuthUserMailNotificationBulkSerializer(
        many=True,
        required=False,
        read_only=False,
        source="authusermailnotification",
        allow_add_remove=True)

    class Meta:
        model = AuroraUser
        fields = (
            "id",
            "username",
            "mail_notification",
        )