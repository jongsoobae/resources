
import json
import unittest
from collections import namedtuple

from django.contrib.auth.models import User
from rest_framework.test import APIClient

from spectrum_api.shared_components.views.customer import CustomerItemAPI

SPECTRUM_API_PAGINATION_RESPONSE = namedtuple(
    'SpectrumApiPagenationResponse',
    'count, previous, next, results')

SPECTRUM_API_CUSTOMER_ITEM = namedtuple(
    'SpectrumAPICustomerItem',
    ', '.join([
        'relay_traffic', 'status_code', 'billing_method_code', 'option_tx',
        'status_code_tx', 'commitment', 'portal_flag', 'sales_charge_txt',
        'rate', 'create_time', 'cpu', 'option_code', 'billing_standards_tx',
        'unit', 'value_added_service', 'material_no', 'weighted_grade_code',
        'relay_traffic_tx', 'option_name', 'hierarchy_desc', 'disk', 'sdabw',
        'rate_unit', 'rounding_rule_code_tx', 'sales_doc_category', 'others',
        'rounding_rule_code', 'rounding_unit_code_tx', 'rounding_unit_code',
        'sales_charge', 'service_type', 'bill_to_account', 'committed_amount',
        'contract_name', 'product', 'option', 'service_type_txt', 'currency',
        'billing_standards', 'material_desc', 'hierarchy_no', 'record_tx',
        'weighted_grade_code_tx', 'item_id', 'expired', 'contract', 'price',
        'billing_method', 'item_no', 'update_time', 'update_orderer', 'ram',
        'material_tx', 'parent_item','price_type',
    ]))


class TestCustomerItemAPI(unittest.TestCase):

    def test_customer_item_should_have_contract_name(self):

        client = APIClient()
        user = User.objects.get(username='aurorauser')

        client.force_authenticate(user=user)
        response = client.get('/api/customer_items/', format='json')
        response_json = json.loads(response.content)

        # response code should be 200 when user authentication success
        self.assertEqual(response.status_code, 200)

        # spectrum api pagination result
        response_tuple = SPECTRUM_API_PAGINATION_RESPONSE(**response_json)

        # all of result's list should be customer item
        for result_item in response_tuple.results:
            customer_item_tuple = SPECTRUM_API_CUSTOMER_ITEM(**result_item)
