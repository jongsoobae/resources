import os, sys
import unittest
import uuid
from datetime import datetime
if 'DJANGO_SETTINGS_MODULE' not in os.environ or os.environ['DJANGO_SETTINGS_MODULE'] is None:
    os.environ['DJANGO_SETTINGS_MODULE'] = 'spectrum_api.settings'
from django.test.client import RequestFactory
from django.conf import settings
from django.contrib.auth.models import User as AuthUser
import json
from django.utils.importlib import import_module
from spectrum_api.dna.models.domain import Domain
from spectrum_api.shared_components.models import _get_model, deserialize_first_obj_from_json, serialize_obj_to_json, \
    get_changed_obj_fields, get_changed_as_json, get_parent_obj_model_as_tuple, log_queryset_delete, ChangeActionHistory
from spectrum_api.shared_components.utils.common import get_userinfo_from_context, get_current_obj_as_json_from_db, \
    get_userinfo_as_tuple_from_context, get_parameter_info_from_request, log_error, get_current_obj_from_db

USERNAME = 'injune.hwang'
PASSWORD = 'cdnadmin'

def is_authenticated():
    return True

class TestUtilCommon(unittest.TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.request = self.factory.get('')
        self.request.user = AuthUser.objects.get(username=USERNAME)
        self.request.enduser = AuthUser.objects.get(username=USERNAME)
        self.request.user.is_authenticated = is_authenticated

    def tearDown(self):
        pass

    def test_domain_diff(self):
        mydomain = Domain.objects.all()[:1][0]
        print mydomain
        previous_obj = get_current_obj_from_db(mydomain)
        previous_json = serialize_obj_to_json(previous_obj)
        mydomain.description = uuid.uuid4()
        current_json = serialize_obj_to_json(mydomain)
        changed_fields = get_changed_as_json(mydomain, current_json=current_json, previous_json= previous_json)
        self.assertIn("description", changed_fields)


    def test_parent_obj_model(self):
        mydomain = Domain.objects.filter(clb_dns_zone__isnull = False)[:1][0]
        parent = get_parent_obj_model_as_tuple(mydomain)
        print parent
        self.assertIn('dns_zone',parent)

    def test_log_queryset_delete(self):
        mydomains = Domain.objects.all()[:1]
        previous_histories = ChangeActionHistory.get_histories_by_obj(mydomains[0])
        previous_count = previous_histories.count()
        log_queryset_delete(mydomains, self.request)
        current_histories = ChangeActionHistory.get_histories_by_obj(mydomains[0])
        self.assertIsNot(previous_count, current_histories.count())

    def test_history_save(self):
        mydomain = Domain.objects.all()[:1][0]
        temp_guid = str(uuid.uuid4())
        mydomain.description = temp_guid
        mydomain.save(request=self.request)
        current_histories = ChangeActionHistory.get_histories_by_obj(mydomain)[:1]
        self.assertIn(temp_guid, current_histories[0].change_diff)

    def test_mail_notification_history_save(self):
        from spectrum_api.mail_notification.models.mail_notification import AuthUserMailNotification
        mail_notification = AuthUserMailNotification.objects.all()[:1][0]

        if mail_notification.mail_item_id > 2:
            mail_notification.mail_item_id -= 1
        else:
            mail_notification.mail_item_id += 1
        mail_notification.save(request=self.request)
        current_histories = ChangeActionHistory.get_histories_by_obj(mail_notification)[:1]
        self.assertIn('mail_item',current_histories[0].change_diff)

