# -*- coding: utf-8 -*-
from django.conf.urls.defaults import patterns, url

from spectrum_api.shared_components.views.main import SpectrumVersionAPI
from spectrum_api.shared_components.views.token import TokenAPI
from spectrum_api.shared_components.views.customer import CustomerAPI, CustomerDetailAPI, \
    CustomerAccountAPI, \
    CustomerAccountDetailAPI, \
    CustomerContractAPI, \
    CustomerContractDetailAPI, CustomerItemAPI, CustomerItemDetailAPI
from spectrum_api.shared_components.views.history import ChangeHistoryAPI
from spectrum_api.shared_components.views.user import AuroraUserAPI


urlpatterns = patterns('spectrum_api.shared_components.views',
                       url(r'^version/$', SpectrumVersionAPI.as_view(), name="version"),
                       url(r'^token/$', TokenAPI.as_view(), name="token"),
                       url(r'^users/(?P<id>[0-9]+)/$', AuroraUserAPI.as_view(), name="aurora-user-detail"),
                       url(r'^customers/$', CustomerAPI.as_view(), name="customer"),
                       url(r'^customers/(?P<customer_id>[0-9]+)/$', CustomerDetailAPI.as_view(),
                           name="customer-detail"),
                       url(r'^customer_accounts/$', CustomerAccountAPI.as_view(), name="customer_accounts"),
                       url(r'^customer_accounts/(?P<account_no>[0-9]+)/$', CustomerAccountDetailAPI.as_view(),
                           name="customer_account-detail"),
                       url(r'^customer_contracts/$', CustomerContractAPI.as_view(), name="customer_contracts"),
                       url(r'^customer_contracts/(?P<contract_no>[0-9]+)/$', CustomerContractDetailAPI.as_view(),
                           name="customer_contracts-detail"),
                       url(r'^changehistories/$', ChangeHistoryAPI.as_view(), name="changehistories"),
                       url(r'^changehistories/(?P<action_id>[0-9]+)/$', ChangeHistoryAPI.as_view(),
                           name="changehistory-detail"),
                       url(r'^customer_items/$', CustomerItemAPI.as_view(), name="customer_items"),
                       url(r'^customer_items/(?P<item_id>[0-9]+)/$', CustomerItemDetailAPI.as_view(),
                           name="customer_items-detail"),
                       )
