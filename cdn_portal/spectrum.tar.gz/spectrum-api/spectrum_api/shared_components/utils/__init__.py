# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Global Util Functions
"""
from rest_framework import exceptions
from rest_framework.status import HTTP_401_UNAUTHORIZED
from spectrum_api import settings

def get_settings_attr(attr, default=None):
    """
        Get global settings attributes
    """
    return getattr(settings, attr, default)
