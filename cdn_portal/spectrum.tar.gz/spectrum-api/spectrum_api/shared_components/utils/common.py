import gc
import time
import hashlib
import re
import socket
import struct
import traceback
import urllib
import urllib2
import inspect
from functools import wraps
from itertools import izip
from django.conf import settings
from django.core.mail import send_mail
from django.core.urlresolvers import reverse
from django.utils.functional import lazy
from django.utils import translation, simplejson
from django.utils.translation import ugettext as _
from django.utils.encoding import smart_str
from django.core.cache import cache
from django.db import connections, connection
from django.shortcuts import get_object_or_404

#beware of circular import before import spectrum_api

CACHE_KEY_IP_POP_DICTS = 'ip_pop_dicts'
CACHE_KEY_POP_CITY_DICTS ='pop_city_dict'
CACHE_KEY_IATA_CITY_DICTS ='iata_pop_city_dict'

class FakeRequest(object):
    user = None
    META = {'REMOTE_ADDR':'127.0.0.1',
        'SERVER_NAME':'127.0.0.1'}

    def get_host(self):
        return FakeRequest.META['REMOTE_ADDR']

def get_request():
    """Walk up the stack, return the nearest first argument named "request"."""
    import inspect
    frame = None
    try:
        for f in inspect.stack()[1:]:
            frame = f[0]
            code = frame.f_code
            if code.co_varnames:
                if code.co_varnames[0] == "request":
                    return frame.f_locals['request']

                if code.co_varnames[:1] == ("request",):
                    return frame.f_locals["request"]
                elif code.co_varnames[:2] == ("self", "request",):
                    return frame.f_locals["request"]
    except:
        return None
    finally:
        del frame

def get_userinfo_from_context(request=None):
    user_info = {}
    try:
        if request is None:
            request = get_request()
        user_id, user_email, user_ip, app_name = get_userinfo_as_tuple_from_context(request)
        hostname = request.META['HTTP_HOST'] if hasattr(request, 'META') and hasattr(request.META, 'HTTP_HOST') else ''
        pos = hostname.find(":")
        hostname = hostname[:pos] if pos > 0 else hostname
        post_message = get_parameter_info_from_request(request)
        request_path = '%s' % (request.META['PATH_INFO']) if hasattr(request, 'META') else ''
        request_message = '%s' % (request.META['QUERY_STRING']) if hasattr(request, 'META') else ''

        user_info.update({'user_id': user_id,
                          'user_email': user_email,
                          'user_ip':user_ip,
                          'app_name': app_name,
                          'host_name': hostname,
                          'post_message': post_message,
                          'request_path': request_path,
                          'request_message': request_message})
    except Exception,e:
        pass
    return user_info

def get_userinfo_as_tuple_from_context(request=None):
    user_id = None
    user_email = ''
    user_ip = ''
    app_name = settings.PROJECT_NAME
    try:
        if request is None:
            request = get_request()
        if request:
            xforwarded_ip = request.META.get('HTTP_X_FORWARDED_IP', None)
            remote_ipaddr = request.META.get('REMOTE_ADDR', None)
            user_ip = xforwarded_ip if xforwarded_ip else remote_ipaddr
            if hasattr(request,'enduser'):
                user_id = request.enduser.pk
                user_email = request.enduser.email if request.enduser.email else request.enduser.username
                user_ip = request.enduser.ip
                app_name = "%s - %s" % (request.enduser.app_name, settings.PROJECT_NAME)
            else:
                user_email = request.user.email if request.user.email else request.user.username
    except:
        pass

    return user_id, user_email, user_ip, app_name

KEYNOTFOUND = '<KEYNOTFOUND>'       # KeyNotFound for dictDiff

def dict_diff(first, second, ignored_fields=None):
    """ Return a dict of keys that differ with another config object.  If a value is
        not found in one fo the configs, it will be represented by KEYNOTFOUND.
        @param first:   Fist dictionary to diff.
        @param second:  Second dicationary to diff.
        @return diff:   Dict of Key => (first.val, second.val)
    """
    diff = {}
    ignored_fields = [] if ignored_fields is None else ignored_fields
    # Check all keys in first dict
    for key in first.keys():
        if (not second.has_key(key)):
            diff[key] = (first[key], KEYNOTFOUND)
        elif (first[key] != second[key]):
            if key not in ignored_fields:
                diff[key] = (first[key], second[key])
    # Check all keys in second dict to find missing
    for key in second.keys():
        if (not first.has_key(key)):
            diff[key] = (KEYNOTFOUND, second[key])
    return diff

def load_dict_from_json(obj_json):
    result_dict = {}
    try:
        result_dict = simplejson.loads(obj_json)
    except:
        try:
            import ast
            result_dict = ast.literal_eval(obj_json)
        except Exception, e:
            pass
    return result_dict

def get_current_obj_from_db(obj):
    if obj.pk:
        try:
            return get_object_or_404(obj.__class__, pk=obj.pk)
        except:
            return None
    else:
        return None

def get_current_obj_as_json_from_db(obj):
    """
    if obj contains m2m field, those values are evaluated during serialization.
    :param obj:
    :return:
    """
    from spectrum_api.shared_components.models import serialize_obj_to_json
    if obj.pk:
        try:
            obj = get_object_or_404(obj.__class__, pk=obj.pk)
            return serialize_obj_to_json(obj)
        except:
            return None
    else:
        return None


def queryset_iterator(queryset, chunksize=1000):
    '''''
    Iterate over a Django Queryset ordered by the primary key

    This method loads a maximum of chunksize (default: 1000) rows in it's
    memory at the same time while django normally would load all rows in it's
    memory. Using the iterator() method only causes it to not preload all the
    classes.

    Note that the implementation of the iterator does not support ordered query sets.
    '''
    pk = 0
    last_pk = queryset.order_by('pk')[0].pk
    queryset = queryset.order_by('-pk')
    while pk < last_pk:
        for row in queryset.filter(pk__gt=pk)[:chunksize]:
            pk = row.pk
            yield row
        gc.collect()

def queryset_asc_iterator(queryset, chunksize=1000):
    '''''
    Iterate over a Django Queryset ordered by the primary key

    This method loads a maximum of chunksize (default: 1000) rows in it's
    memory at the same time while django normally would load all rows in it's
    memory. Using the iterator() method only causes it to not preload all the
    classes.

    Note that the implementation of the iterator does not support ordered query sets.
    '''
    pk = 0
    last_pk = queryset.order_by('-pk')[0].pk
    queryset = queryset.order_by('pk')
    while pk < last_pk:
        for row in queryset.filter(pk__gt=pk)[:chunksize]:
            pk = row.pk
            yield row
        gc.collect()

def get_popcode_cities():
    try:
        pop_city_dict = cache.get(CACHE_KEY_POP_CITY_DICTS)
    except:
        pop_city_dict = None
    if pop_city_dict is None:
        pop_city_dict = {}
        try:
            sql = """select p.pop_code, c.city_name from ihms_pop p
                inner join ihms_pop_info pi on p.pop_id = pi.pop_id
              inner join ihms_idc idc on pi.idc_id = idc.idc_id
              inner join ihms_city c on idc.city_id = c.city_id"""
            cursor = connections['spectrum'].cursor()
            cursor.execute(sql)
            pop_cities = cursor.fetchall()
        except Exception,e:
            log_error(None,"unable to fetch pop city info", e)
        for pop_city in pop_cities:
            pop_city_dict.update({pop_city[0].upper():pop_city[1]})
        cache.set(CACHE_KEY_POP_CITY_DICTS, pop_city_dict, 60*30)
        #give 30 min of TTL since pop city info rarely changes.
    return pop_city_dict

def get_iatacode_cities():
    '''
    return {iatacode:city name} dictionary. IATA code: 'ICN','SJC'
    :return:
    '''
    try:
        iata_city_dict = cache.get(CACHE_KEY_IATA_CITY_DICTS)
    except:
        iata_city_dict = None
    if iata_city_dict is None:
        iata_city_dict = {}
        try:
            cursor = connections['spectrum'].cursor()
            cursor.execute("select airport_iata, airport_city from airport where airport_iata is not NULL and airport_iata <> ''")
            iata_cities = cursor.fetchall()
        except Exception,e:
            log_error(None,"unable to fetch iata city info", e)
        for iata_city in iata_cities:
            iata_city_dict.update({iata_city[0].upper():iata_city[1]})
        cache.set(CACHE_KEY_IATA_CITY_DICTS, iata_city_dict, 60*30)
        #give 30 min of TTL since pop city info rarely changes.
    return iata_city_dict

def get_mproxy_pop_status_by_popcode(pop_code):
    if pop_code is None or len(pop_code.strip()) ==0:
        return ''
    try:
        sql = "select pop_status from mproxy_pop_status where pop_name = %(pop_code)s"
        params = {'pop_code':pop_code}
        cursor = connection.cursor()
        cursor.execute(sql, params)
        row = cursor.fetchone()
        if row:
            return row[0]
        else:
            return ''
    except Exception,e:
        log_error(None,"unable to fetch mporxy pop status info", e)
        return ''

def get_cityname_by_popcode(pop_code):
    '''
    return cityname. first lookup ihms pop -ihms idc - ihms city relation, In case of customer pop lookup IATA code.
    :param pop_code:
    :return:
    '''
    if pop_code is None or len(pop_code.strip()) ==0:
        return ''
    pop_city_dict = get_popcode_cities()
    city_name = pop_city_dict.get(pop_code.upper(), None)
    if city_name is None:
        iata_city_dict = get_iatacode_cities()
        city_name = iata_city_dict.get(pop_code.split('-')[-1].upper(), '')
    return city_name

def query_to_dicts(query_string, *query_args):
    """Run a simple query and produce a generator
    that returns the results as a bunch of dictionaries
    with keys for the column values selected.
    """
    cursor = connection.cursor()
    cursor.execute(query_string, query_args)
    col_names = [desc[0] for desc in cursor.description]
    while True:
        row = cursor.fetchone()
        if row is None:
            break
        row_dict = dict(izip(col_names, row))
        yield row_dict
    return

def object_to_dicts(obj):
    itemdict = dict((key, smart_str(value).strip()) for key, value in obj.__dict__.iteritems()
                    if not callable(value) and not key.startswith('__'))
    return itemdict

def object_to_dicts_with_filters(obj, filter_list=[], filter_dict={}):
    """
    return only filtered items
    filters = {'key1':'key1_alias', 'key2':'key2_alias'}
    support callable function name with alias
    :param obj:
    :param filters:
    :return:
    """
    if not filter_list and not filter_dict:
        return object_to_dicts(obj)
    my_filters = filter_dict.copy() if filter_dict else {}
    if filter_list:
        my_filters.update(dict(zip(filter_list,filter_list)))
    itemdict = dict((get_alias_key(key, my_filters), get_eval_value_by_key_name(obj, key, my_filters)) for key in dir(obj)
                    if key in my_filters and not key.startswith('__'))
    return itemdict

def get_eval_value_by_key_name(obj, key_name, filters):
    result = None
    try:
        result = getattr(obj, key_name, None)
        if not filters:
            return result
        if isinstance(filters, dict) and key_name in filters:
            func = getattr(obj, key_name)
            return func() if callable(func) else smart_str(func).strip()
        return result
    except Exception,e:
        return result

def get_alias_key(key, filters):
    result = key
    if not filters:
        return result
    try:
        if isinstance(filters, dict) and key in filters:
            return filters[key]
    except:
        pass
    return result

def run_command_from_local(cmd):
    '''
    return tuple result, error
    :param cmd:
    :return:
    '''
    import subprocess
    result = ''

    try:
        # p = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        result, err = p.communicate()
        # use communicate rather than read, which may cause dead lock
        status = p.returncode

        return result, err
    except Exception, e:
        return result, str(e)

def get_url_result(url, params, timeout):
    result = ''
    error = ''
    try:
        try:
            timeout = int(timeout)
        except:
            timeout = None  # use default socket timeout
        if params:
            postdata = urllib.quote(params)
            response = urllib2.urlopen(url, postdata, timeout)
        else:
            response = urllib2.urlopen(url, None, timeout)
        result = response.read()
    except urllib2.HTTPError, err:
        errmsg = "%s timeout:%s url:%s" % (str(err), str(timeout), url)
        log_error(None, errmsg, err)
        error = 'error: HTTPError %s' % (err.code)
    except urllib2.URLError, err:
        errmsg = "%s timeout:%s url:%s" % (str(err), str(timeout), url)
        log_error(None, errmsg, err)
        if hasattr(err, 'reason'):
            error = 'error: URLError %s' % (err.reason)
        elif hasattr(err, 'code'):
            error = 'error: URLError %s' % (err.code)
        else:
            error = 'error: URLError %s' % (str(err))
    except IOError, (err):
        errmsg = "%s timeout:%s url:%s" % (str(err), str(timeout), url)
        log_error(None, errmsg, err)
        if hasattr(err, 'errno'):
            error = 'error: IOError %s' % (err.errno)
        elif hasattr(err, 'code'):
            error = 'error: IOError %s' % (err.code)
        else:
            error = 'error: IOError %s' % (str(err))
    except Exception, err:
        errmsg = "%s timeout:%s url:%s" % (str(err), str(timeout), url)
        log_error(None, errmsg, err)
        error = 'error: Unknown %s' % (str(err)[:20])
    return error, result;

def is_valid_ipv4(ip):
    """Validates IPv4 addresses.
    """
    pattern = re.compile(r"""
        ^
        (?:
          # Dotted variants:
          (?:
            # Decimal 1-255 (no leading 0's)
            [3-9]\d?|2(?:5[0-5]|[0-4]?\d)?|1\d{0,2}
          |
            0x0*[0-9a-f]{1,2}  # Hexadecimal 0x0 - 0xFF (possible leading 0's)
          |
            0+[1-3]?[0-7]{0,2} # Octal 0 - 0377 (possible leading 0's)
          )
          (?:                  # Repeat 0-3 times, separated by a dot
            \.
            (?:
              [3-9]\d?|2(?:5[0-5]|[0-4]?\d)?|1\d{0,2}
            |
              0x0*[0-9a-f]{1,2}
            |
              0+[1-3]?[0-7]{0,2}
            )
          ){0,3}
        |
          0x0*[0-9a-f]{1,8}    # Hexadecimal notation, 0x0 - 0xffffffff
        |
          0+[0-3]?[0-7]{0,10}  # Octal notation, 0 - 037777777777
        |
          # Decimal notation, 1-4294967295:
          429496729[0-5]|42949672[0-8]\d|4294967[01]\d\d|429496[0-6]\d{3}|
          42949[0-5]\d{4}|4294[0-8]\d{5}|429[0-3]\d{6}|42[0-8]\d{7}|
          4[01]\d{8}|[1-3]\d{0,9}|[4-9]\d{0,8}
        )
        $
    """, re.VERBOSE | re.IGNORECASE)
    return pattern.match(ip) is not None

def is_valid_ipv6(ip):
    """Validates IPv6 addresses.
    """
    if ip == None or len(ip.strip()) == 0:
        False
    else:
        pattern = re.compile(r"""
            ^
            \s*                         # Leading whitespace
            (?!.*::.*::)                # Only a single whildcard allowed
            (?:(?!:)|:(?=:))            # Colon iff it would be part of a wildcard
            (?:                         # Repeat 6 times:
                [0-9a-f]{0,4}           #   A group of at most four hexadecimal digits
                (?:(?<=::)|(?<!::):)    #   Colon unless preceeded by wildcard
            ){6}                        #
            (?:                         # Either
                [0-9a-f]{0,4}           #   Another group
                (?:(?<=::)|(?<!::):)    #   Colon unless preceeded by wildcard
                [0-9a-f]{0,4}           #   Last group
                (?: (?<=::)             #   Colon iff preceeded by exacly one colon
                 |  (?<!:)              #
                 |  (?<=:) (?<!::) :    #
                 )                      # OR
             |                          #   A v4 address with NO leading zeros
                (?:25[0-4]|2[0-4]\d|1\d\d|[1-9]?\d)
                (?: \.
                    (?:25[0-4]|2[0-4]\d|1\d\d|[1-9]?\d)
                ){3}
            )
            \s*                         # Trailing whitespace
            $
        """, re.VERBOSE | re.IGNORECASE | re.DOTALL)
        return pattern.match(ip) is not None


def getIPidbyipaddr(value):
    result = None
    try:
        if value:
            if type(value) is str:
                value = value.strip()
            result = struct.unpack('>L', socket.inet_aton(value))[0]
    except:
        pass
    return result

def get_ip_pop_dicts():
    from spectrum_api.configuration.models.base import VipSearch
    try:
        ipdict = cache.get(CACHE_KEY_IP_POP_DICTS)
    except:
        ipdict = None

    if ipdict is None:
        ipdict = {}
        ip_pops = VipSearch.objects.all().values('ip','pop_name')
        for vip in ip_pops:
            ipdict.update({vip.get('ip'):vip.get('pop_name')})
        cache.set(CACHE_KEY_IP_POP_DICTS, ipdict, 60)
        #give 60 sec of TTL since ip's pop info rarely changes. 60 sec is enough for the time when changes are pushed
    return ipdict

def get_vips_by_ipaddr(value):
    from spectrum_api.configuration.models.base import Vip
    from spectrum_api.configuration.models.ihms import IhmsVip
    vips = None
    if value:
        if type(value) is str:
            value = value.strip()
        if value.find('.') > 0:
            ihmsvip = IhmsVip.objects.filter(ip_id=struct.unpack('>L', socket.inet_aton(value))[0])
            if ihmsvip:
                vips = Vip.objects.filter(ihms_vip__in=ihmsvip)
            else:
                vips = Vip.objects.filter(vip_addr=value)
        else:
            vips = get_vips_by_ipid(value)
    return vips

def get_vips_by_ipid(value):
    from spectrum_api.configuration.models.base import Vip
    from spectrum_api.configuration.models.ihms import IhmsVip
    vips = None
    if value:
        if type(value) is str:
            value = value.strip()
        try:
            ipid = int(value)
            ihmsvip = IhmsVip.objects.filter(ip_id=ipid)
            if ihmsvip:
                vips = Vip.objects.filter(ihms_vip__in=ihmsvip)
            else:
                vips = Vip.objects.filter(vip_addr=socket.inet_ntoa(struct.pack('!L', ipid)))
        except:
            vips = get_vips_by_ipaddr(value)
    return vips

def get_vips_by_vipname(value):
    from spectrum_api.configuration.models.base import Vip
    from spectrum_api.configuration.models.ihms import IhmsVip
    vips = None
    if value:
        if type(value) is str:
            value = value.strip()
        try:
            ipid = int(value)
            ihmsvip = IhmsVip.objects.filter(ip_id=ipid)
            if ihmsvip:
                vips = Vip.objects.filter(ihms_vip__in=ihmsvip)
            else:
                vips = Vip.objects.filter(vip_addr=socket.inet_ntoa(struct.pack('!L', ipid)))
        except:
            vips = get_vips_by_ipaddr(value)
    return vips

def getsystemsbysystemname(value):
    from spectrum_api.configuration.models.base import Pop, System
    from spectrum_api.configuration.models.ihms import IhmsPop, IhmsSystem
    systems = None
    if value:
        if type(value) is str:
            value = value.strip()
        try:
            if value.find('.') > 0:
                names = value.split(".")
                if len(names) == 2:
                    if names[0].find("-") > 0:
                        raise Exception("Invalid system name %s. It should be sxx.pxx." % (value))
                    pops = Pop.objects.filter(pop_name=names[1])
                    ihmspop = IhmsPop.objects.filter(pop_code=names[1])
                    if pops:
                        pass
                    else:
                        pops = Pop.objects.filter(ihms_pop=ihmspop)

                    if not pops:
                        raise Exception("Invalid systemname %s. no such pop as %s" % (value, names[1]))

                    if ihmspop:
                        ihmssystems = IhmsSystem.objects.filter(system_name=names[0], pop=int(ihmspop[0].pk))
                    else:
                        ihmssystems = None

                    if ihmssystems:
                        systems = System.objects.filter(ihms_system=ihmssystems[0])
                    else:
                        systems = System.objects.filter(system_name=names[0], pop=pops[0])

                    if not systems:
                        raise Exception("systemname %s not exists.  no such system as %s" % (value, names[0]))
                else:
                    raise Exception("Invalid systemname %s. It should be full name. eg)sxx.pxx" % (value))
            else:
                raise Exception("Invalid systemname %s. It should be full name. eg)sxx.pxx" % (value))
        except Exception, e:
            raise e
    return systems

def gethostsbyhostname(value):
    from spectrum_api.configuration.models.base import Pop, System, Host
    from spectrum_api.configuration.models.ihms import IhmsPop, IhmsSystem, IhmsHost
    hosts = None
    if value:
        if type(value) is str:
            value = value.strip()
        try:
            if value.find('.') > 0:
                names = value.split(".")
                if len(names) == 2:
                    subnames = names[0].split("-")
                    pops = Pop.objects.filter(pop_name=names[1])
                    ihmspop = IhmsPop.objects.filter(pop_code=names[1])
                    if pops:
                        pass
                    else:
                        pops = Pop.objects.filter(ihms_pop=ihmspop)
                    if not pops:
                        raise Exception("Invalid popname %s. no such pop as %s" % (value, names[1]))

                    if ihmspop:
                        ihmssystems = IhmsSystem.objects.filter(system_name=subnames[1], pop=int(ihmspop[0].pk))
                    else:
                        ihmssystems = None

                    if ihmssystems:
                        systems = System.objects.filter(ihms_system=ihmssystems[0])
                    else:
                        systems = System.objects.filter(system_name=subnames[1], pop=pops[0])

                    if not systems:
                        raise Exception("invalid systemname %s.  no such system as %s.%s" % (value, subnames[1], names[1]))

                    if ihmssystems:
                        ihmshosts = IhmsHost.objects.filter(host_name=subnames[0], system=ihmssystems[0])
                    else:
                        ihmshosts = None
                    if ihmshosts:
                        hosts = Host.objects.filter(ihms_host=ihmshosts[0])
                    else:
                        hosts = Host.objects.filter(host_name=subnames[0], system=systems[0])

                    if hosts:
                        return hosts
                    else:
                        raise Exception("hostname %s not exists. no such hostname as %s.%s.%s" % (value, subnames[0], subnames[1], names[1]))
                else:
                    raise Exception("Invalid hostname %s. It should be full name. eg)hxx-sxx.pxx" % (value))
            else:
                raise Exception("Invalid hostname %s. It should be full name. eg)hxx-sxx.pxx" % (value))
        except Exception, e:
            raise e
    return hosts

def getvipsbyvipname(value):
    from spectrum_api.configuration.models.base import Pop, System, Host, Vip
    from spectrum_api.configuration.models.ihms import IhmsPop, IhmsSystem, IhmsHost, IhmsVip
    vips = None
    if value:
        if type(value) is str:
            value = value.strip()
        try:
            if value.find('.') > 0:
                names = value.split(".")
                if len(names) == 2:
                    subnames = names[0].split("-")
                    if len(subnames) != 3:
                        raise Exception("Invalid vipname %s. It should be ixx-hxx-sxx.pxx." % (value))

                    # hostname = "%s-%s.%s" % (subnames[1],subnames[2],names[1])
                    # hosts = gethostsbyhostname(hostname)
                    pops = Pop.objects.filter(pop_name=names[1])
                    ihmspop = IhmsPop.objects.filter(pop_code=names[1])
                    if pops:
                        pass
                    else:
                        pops = Pop.objects.filter(ihms_pop=ihmspop)
                    if not pops:
                        raise Exception("Invalid popname %s. no such pop as %s" % (value, names[1]))

                    if ihmspop:
                        ihmssystems = IhmsSystem.objects.filter(system_name=subnames[2], pop=int(ihmspop[0].pk))
                    else:
                        ihmssystems = None

                    if ihmssystems:
                        systems = System.objects.filter(ihms_system=ihmssystems[0])
                    else:
                        systems = System.objects.filter(system_name=subnames[2], pop=pops[0])

                    if not systems:
                        raise Exception("invalid systemname %s.  no such system as %s.%s" % (value, subnames[2], names[1]))

                    if ihmssystems:
                        ihmshosts = IhmsHost.objects.filter(host_name=subnames[1], system=ihmssystems[0])
                    else:
                        ihmshosts = None

                    if ihmshosts:
                        hosts = Host.objects.filter(ihms_host=ihmshosts[0])
                    else:
                        hosts = Host.objects.filter(host_name=subnames[1], system=systems[0])

                    if not hosts:
                        raise Exception("Invalid hostname %s. no such vipname as %s-%s.%s" % (value, subnames[1], subnames[2], names[1]))

                    if ihmshosts:
                        ihmsvips = IhmsVip.objects.filter(vip_name=subnames[0], host=ihmshosts[0])
                    else:
                        ihmsvips = None

                    if ihmsvips:
                        vips = Vip.objects.filter(ihms_vip=ihmsvips[0])
                    else:
                        vips = Vip.objects.filter(vip_name=subnames[0], host=hosts[0])

                    if not vips:
                        raise Exception("vipname %s not exists. no such vipname as %s-%s-%s.%s" % (value, subnames[0], subnames[1], subnames[2], names[1]))

                else:
                    raise Exception("Invalid vipname %s. It should be full name. eg)ixx-hxx-sxx.pxx" % (value))
            else:
                raise Exception("Invalid vipname %s. It should be full name. eg)ixx-hxx-sxx.pxx" % (value))
        except Exception, e:
            raise e
    return vips

def get_error_messages(obj):
    """ this is for ModelForm """
    response = []
    label = ""
    for key, value in obj.errors.iteritems():
        label = ""
        if hasattr(obj, '_meta') and hasattr(obj._meta, 'model'):
            for field in obj._meta.model._meta.fields:
                if field.name == key:
                    label = field.verbose_name + ":"
        response.append("{label}{value}<br />".format(label=label, value=value.as_text().replace('*', '')))
    return ''.join(response)

#deprecated
def update_action_history(request, obj, actiontype):
    pass


def get_parameter_info_from_request(request):
    postquery_parameters = []
    try:
        if request is None:
            request = get_request()
        if request.POST:
            for param, value in request.POST.iteritems():
                if param == 'password':
                    value = '*******'
                postquery_parameters.append('%s=%s,' % (param, value))
        return ''.join(postquery_parameters)
    except:
        # Fakerequest has no post attribute
        return ''

def _send_mail(request, title, message, e=None):
    if e:
        send_error_email(request, title, message, e)
    else:
        send_notice_email(request, title, message)

def get_parsed_log_level(loglevel):
    if loglevel == None or loglevel < 0:
        log_level = 1
    else:
        try:
            log_level = int(loglevel)
        except:
            log_level = 1
    return log_level

def get_event_action_id_from_request(request):
    try:
        return request.eventid
    except:
        return None

#deprecated
def insert_action_event(request, message=None, username=None, app_name=None, error_message=None):
    context = {'username':username}
    return update_action_event(request=request, message=message, app_name=app_name,
                               context=context, error_message=error_message)

def update_action_event(request=None, message=None, e=None, loglevel=None, eventid=None, title=None,
                        app_name=None, sendemail=False, context=None, error_message=''):
    from spectrum_api.shared_components.models import ActionEventLog
    try:
        if not title:
            title = message[:50] if len(message) > 50 else message

        if not request:
            request = get_request()

        if sendemail:
            _send_mail(request, title, message, e)

        error_message = traceback.format_exc(e) if e else error_message
        post_message = get_parameter_info_from_request(request)

        user_info = get_userinfo_from_context(request)
        app_name = app_name if app_name else user_info.get('app_name','')
        message = message[:2047] if len(message) > 2047 else message

        event_sender = '%s' % (request.META['PATH_INFO']) if hasattr(request, 'META') else ''
        request_message = '%s' % (request.META['QUERY_STRING']) if hasattr(request, 'META') else ''
        loglevel = get_parsed_log_level(loglevel)

        return ActionEventLog.create_action_event(message=message,
                                           error_message=error_message,
                                           request=request,
                                           context=context,
                                           user_info=user_info,
                                           request_message=request_message,
                                           event_sender=event_sender,
                                           app_name=app_name,
                                           post_message=post_message,
                                           log_level=loglevel)
    except Exception, e:
        email_alert(request, e, 'fail to log event. message: %s' % (message))

def log_event(username, message, app_name=None, e=None):
    try:
        context = {'username':username}
        return update_action_event(message=message, e=e, app_name=app_name, context=context)
    except Exception, e:
        email_alert(None, e, 'fail to log event. message: %s' % (message))
        return -1

def log_debug(request=None, message='', e=None, eventid=None, title=None, app_name=None, sendemail=False):
    try:
        return update_action_event(request=request, message=message, e=e,loglevel=0,
                                   title=title, app_name=app_name, sendemail=sendemail)
    except Exception,e:
        print e
        return -1

def log_info(request=None, message='', e=None, eventid=None, title=None, app_name=None, sendemail=False):
    try:
        return update_action_event(request=request, message=message, e=e,  loglevel=1,
                                   title=title, app_name=app_name, sendemail=sendemail)
    except Exception,e:
        print e
        return -1

def log_warn(request=None, message='', e=None, eventid=None, title=None, app_name=None, sendemail=False):
    try:
        return update_action_event(request=request, message=message, e=e,  loglevel=2,
                                   title=title, app_name=app_name, sendemail=sendemail)
    except Exception,e:
        print e
        return -1

def log_error(request=None, message='', e=None, eventid=None, title=None, app_name=None, context=None, sendemail=True):
    try:
        log_level = 3
        if not request:
            request = get_request()
        if title is None:
            title = message
        if e is None:
            curframe = inspect.currentframe()
            callerframe = inspect.getouterframes(curframe,2)

            message_list = get_message_list_from_caller(callerframe)
            message = "%s \n\n%s\n\n" % (message, "\n".join(message_list))
        else:
            try:
                if hasattr(e, 'code') and e.code == 400: #do not send email when request is invalid
                    sendemail = False
                    log_level = 2
            except:
                pass
    except:
        pass
    return update_action_event(request, message, e, log_level, eventid, title, app_name, sendemail)

def log_critical(request, message, e=None, eventid=None, title=None, app_name=None, sendemail=True):
    try:

        if title is None:
            title = message
        if e is None:
            curframe = inspect.currentframe()
            callerframe = inspect.getouterframes(curframe,2)

            message_list = get_message_list_from_caller(callerframe)
            message = "%s \n\n%s\n\n" % (message, "\n".join(message_list))
    except:
        pass
    return update_action_event(request, message, e, 4, eventid, title, app_name, sendemail)

def get_message_list_from_caller(callerframes):
    message_list = []
    inspect_skipped = False
    for callerframe in callerframes:
        if not inspect_skipped:
            inspect_skipped = True
        else:
            frameobj,filename,line_no,func_name,contextlines,contextindex = callerframe
            message_list.append("%s within %s. line %d" % (filename,func_name,line_no))
            for iline,srcline in enumerate(contextlines or []):
                message_list.append("%3s : %s" % ('>>' if iline==contextindex else '',srcline.replace('\n','')))

    return message_list

def send_error_email(request, title, content, e, project_name='', default_from_email='', email_alerts='', fail_silently=False):
    try:
        contentlist = []
        contentlist.append(content)
        if project_name == None or project_name == '':
            project_name = settings.PROJECT_NAME
        if default_from_email == None or default_from_email == '':
            default_from_email = settings.DEFAULT_FROM_EMAIL
        if email_alerts == None or email_alerts == '':
            email_alerts = settings.EMAIL_ALERTS
        title = '[%s] %s' % (project_name, title)
        if request:
            contentlist.append('HTTP HOST: %s \r\n' % (request.get_host()))
            contentlist.append('Server Name: %s \r\n' % (request.META['SERVER_NAME']))
            contentlist.append('username: %s \n\n' % (request.user))
        if e:
            contentlist.append('Trace Back: \n %s' % (traceback.format_exc(e)))
        send_mail(title, ''.join(contentlist), default_from_email, email_alerts, fail_silently=False)
    except Exception, e:
        pass

def send_notice_email(request, title, content='', project_name='', default_from_email='', email_alerts='', fail_silently=False):
    try:
        contentlist = []
        contentlist.append(content)
        if project_name == None or project_name == '':
            project_name = settings.PROJECT_NAME
        if default_from_email == None or default_from_email == '':
            default_from_email = settings.DEFAULT_FROM_EMAIL
        if email_alerts == None or email_alerts == '':
            email_alerts = settings.EMAIL_ALERTS
        title = '[%s] %s' % (project_name, title)
        if request:
            contentlist.append('HTTP HOST: %s \r\n' % (request.get_host()))
            contentlist.append('Server Name: %s \r\n' % (request.META['SERVER_NAME']))
            contentlist.append('username: %s \n\n' % (request.user))

        send_mail(title, ''.join(contentlist), default_from_email, email_alerts, fail_silently=False)
    except Exception, e:
        pass

def email_alert(request, e, subject):
    try:
        recipent_list = []
        for (k, v) in settings.ADMINS:
            recipent_list.append(v)
        subject = '[%s] %s' % (settings.PROJECT_NAME, subject)
        message = ''
        if request:
            message = 'HTTP HOST: {host}\nSERVER NAME: {server}\n\nStack Trace:\n{trace}'.format(host=request.get_host(),
                                                                                            server=request.META['SERVER_NAME'],
                                                                                            trace=traceback.format_exc(e))
        else:
            message = 'Stack Trace:\n{trace}'.format(trace=traceback.format_exc(e))
        send_mail(subject, message,
            from_email='%s' % settings.DEFAULT_FROM_EMAIL,
            recipient_list=recipent_list,
            fail_silently=False)
    except:
        pass

def is_ihms_sync_running():
    from spectrum_api.ihms.models.ihmsdiff import IhmsSyncManager
    running_jobs = IhmsSyncManager.objects.filter(sync_running_type=2)
    if running_jobs.count() > 0:
        return True
    else:
        return False
# Workaround for using reverse with success_url in class based generic views
# because direct usage of it throws an exception.
reverse_lazy = lambda name = None, *args : lazy(reverse, str)(name, args=args)

def notice_operator_event_email(request, email, title, content):
    from django.template.loader import render_to_string
    from spectrum_api.config_constants import IS_PRODUCTION
    from spectrum_api.shared_components.utils.send_mail import MailObject

    try:
        receive_mail = email
        try:
            from_email = settings.SERVER_EMAIL
            if from_email.lower().startswith("root"):  # this is rejected at smtp server
                from_email = settings.DEFAULT_FROM_EMAIL
        except:
            from_email = settings.DEFAULT_FROM_EMAIL

        contents = []
        try:
            if not IS_PRODUCTION:
                contents.append("<font color='red'>This is a test mail which was intended to be sent to %s. </font>" % str(receive_mail))
                contents.append("")
                receive_mail = settings.EMAIL_ALERTS
        except:
            pass

        contents.append(content)

        msg = "<br>".join(contents)
        email_msg = render_to_string("operator_email_template.html", {'title':title,
                                                            'domain':settings.AURORA_URL,
                                                            'contents':msg})


        mailobj = MailObject(from_email, receive_mail, title, email_msg)
        mailobj.send_mail()
    except Exception, e:
        log_error(request, "fail to send notice email", e=e)
        raise e

# Bulk insert/update DB operations for the Django ORM. Useful when
# inserting/updating lots of objects where the bottleneck is overhead
# in talking to the database.
#   l = []
#   for x in seq:
#       o = SomeObject()
#       o.foo = x
#       l.append(o)
#   insert_many(l)
#
# Note that these operations are really simple. They won't work with
# many-to-many relationships, and you may have to divide really big
# lists into smaller chunks before sending them through.
#
# History
# 2010-12-10: quote column names, reported by Beres Botond.
#TODO: beginning django 1.4, bulk_create function has been introduced. Need to replace insert_many with bulk_create

def insert_many(objects, using="default"):
    """Insert list of Django objects in one SQL query. Objects must be
    of the same Django model. Note that save is not called and signals
    on the model are not raised."""
    if not objects:
        return

    import django.db.models
    from django.db import connections
    con = connections[using]

    model = objects[0].__class__
    fields = [f for f in model._meta.fields if not isinstance(f, django.db.models.AutoField)]
    parameters = []
    for o in objects:
        parameters.append(tuple(f.get_db_prep_save(f.pre_save(o, True), connection=con) for f in fields))

    table = model._meta.db_table
    column_names = ",".join(con.ops.quote_name(f.column) for f in fields)
    placeholders = ",".join(("%s",) * len(fields))
    con.cursor().executemany(
        "insert into %s (%s) values (%s)" % (table, column_names, placeholders),
        parameters)

def update_many(objects, fields=[], using="default"):
    """Update list of Django objects in one SQL query, optionally only
    overwrite the given fields (as names, e.g. fields=["foo"]).
    Objects must be of the same Django model. Note that save is not
    called and signals on the model are not raised."""
    if not objects:
        return

    import django.db.models
    from django.db import connections
    con = connections[using]

    names = fields
    meta = objects[0]._meta
    fields = [f for f in meta.fields if not isinstance(f, django.db.models.AutoField) and (not names or f.name in names)]

    if not fields:
        raise ValueError("No fields to update, field names are %s." % names)

    fields_with_pk = fields + [meta.pk]
    parameters = []
    for o in objects:
        parameters.append(tuple(f.get_db_prep_save(f.pre_save(o, True), connection=con) for f in fields_with_pk))

    table = meta.db_table
    assignments = ",".join(("%s=%%s"% con.ops.quote_name(f.column)) for f in fields)
    con.cursor().executemany(
        "update %s set %s where %s=%%s" % (table, assignments, con.ops.quote_name(meta.pk.column)),
        parameters)