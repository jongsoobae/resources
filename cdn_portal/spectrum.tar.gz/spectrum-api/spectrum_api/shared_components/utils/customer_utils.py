# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Customer utils
"""

region_dict = {
    1000: "KR",
    2000: "JP",
    3000: "CN",
    4000: "US",     # US
    5000: "US",     # EMEA
    6000: "SG",
    7000: "UK"
}


def get_region_nm(value):
    return region_dict.get(value, 'Unknown')
