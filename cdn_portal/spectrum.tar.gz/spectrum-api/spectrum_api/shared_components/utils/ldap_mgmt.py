from ldap.ldapobject import ReconnectLDAPObject
from ldapurl import LDAPUrl
import ldap

LDAP_VERSION = ldap.__version__


class LDAPManager:
    def __init__(self, protocol=None, ldap_host=None, ldap_port=None,
                 ldap_base_dn=None, ldap_base_user=None, ldap_base_pass=None):
        try:
            ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
            self.ldap_url = LDAPUrl(urlscheme='%s' % protocol,
                                    hostport='%s:%s' % (ldap_host, ldap_port),
                                    dn=ldap_base_dn,
                                    who=ldap_base_user,
                                    cred=ldap_base_pass)
            self.ldapconn = ReconnectLDAPObject(self.ldap_url.initializeUrl(),
                                                trace_level=0, retry_max=10, retry_delay=2)

            self.ldapconn.protocol_version = 3
            self.ldapconn.set_option(ldap.OPT_REFERRALS, 0)
            self.ldapconn.simple_bind_s(ldap_base_user, ldap_base_pass)
        except Exception, e:
            raise e

    def get_all_users(self, dn, user_filter, attrib):
        user_list = []
        try:
            if not user_filter:
                user_filter = 'objectClass=person'
            base_dn = 'DC=cdnetworks,DC=kr'
            if dn and len(dn) > 0:
                base_dn = dn

            # Send search request
            results = self.ldapconn.search_s(base_dn, ldap.SCOPE_SUBTREE, filterstr=user_filter, attrlist=attrib)
            for result in results:
                user_list.append(result[1])

            return user_list
        except Exception, e:
            raise e

    def unbind(self):
        try:
            self.ldapconn.unbind()
        except Exception, e:
            pass