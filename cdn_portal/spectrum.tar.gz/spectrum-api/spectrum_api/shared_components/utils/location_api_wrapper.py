
import hashlib
import urllib2
import socket

from collections import namedtuple

# Location Search API Schema
# ( <= Location Search API Schema
#     ([scheme_name], [scheme_type]), <= Location Search API Response Scheme
#     ...
# )

LOCATION_SEARCH_API_SCHEMA = (
    ('country', str),
    ('hit', long),
    ('success_hit', long),
    ('error_hits', long),
    ('ok_hits_ratio', float),
    ('visitor', long),
    ('transfer', long),
    ('page_views', long)
)

LocationSearchAPIResponse = namedtuple(
    'LocationAPIResponse',
    'request_url status status_code body')

LocationSearchAPIResponseBody = namedtuple(
    'LocationSearchAPIResponseBody',
    'stat_id_list report_type from_date, to_date is_contract_stat country_code state_code series_data')

LocationSearchAPIReportItem = namedtuple(
    'LocationSearchAPIReportItem',
    'country hit success_hit error_hits ok_hits_ratio visitor transfer page_views')

class LocationSearchAPIWrapper(object):
    ''' Location Search API Wrapper Class
        @dependencies : hashlib, urllib2, socket
    '''

    # basic api information
    _url = None
    api_request_url = None
    _timeout = 30
    _api_key = None
    _default_route = 'list_location'

    # location search api report information
    _stat_list = []
    _is_contract_stat_item = False
    _country_code = None
    _state_code = None
    _from_date = None
    _to_date = None

    def __init__(self, url, timeout=30, api_key=''):
        # check construct values
        if any([url, timeout, api_key]) is None:
            raise Exception('Location Search API Wrapper Error. (api connection info is not satisfied.)')

        # throws Value Error
        self._url = str(url)
        self._timeout = int(timeout)
        self._api_key = str(api_key)

    def _get_api_request_key(self, request_url):

        request_url = str(request_url)

        api_request_key = hashlib.sha1(
            ','.join([repr(request_url), self._api_key])
        ).hexdigest()

        return api_request_key

    def _raise_location_api_exception(self, api_exception):
        if type(api_exception) == socket.timeout:
            error_code = 011
            detail = 'Location Search API Error : Request is Timeout (url:%s) (code:%s - timeout is %s sec)' % (
                self.api_request_url, error_code, self._timeout)

        elif type(api_exception) == urllib2.HTTPError:
            error_code = api_exception.code
            detail = 'Location Search API Error : HTTP Response Error (url:%s) (code:%s)' % (
                self.api_request_url, error_code)

        elif type(api_exception) == urllib2.URLError:
            error_instance = api_exception.args[0]
            error_code = error_instance.errno
            detail = 'Location Search API Error : TCP Socket Error (url:%s) (code:%s - %s)' % (
                self.api_request_url, error_code, error_instance.strerror)

        else:
            error_code = -1
            detail = 'Location Search API Error : Unkown Error (url:%s) (code:%s - %s)' % (
                self.api_request_url, error_code, api_exception)

        raise Exception(error_code, detail, api_exception)


    def set_stat_list(self, stat_list=[]):
        self._stat_list = [str(stat_id) for stat_id in stat_list]

    def get_stat_list(self):
        return self._stat_list


    def set_from_date(self, from_date=None):
        self._from_date = from_date

    def get_from_date(self):
        return self._from_date


    def set_to_date(self, to_date=None):
        self._to_date = to_date

    def get_to_date(self):
        return self._to_date


    def set_country_code(self, country_code=None):
        self._country_code = str(country_code) if country_code else None

    def get_country_code(self):
        return self._country_code


    def set_state_code(self, state_code=None):
        self._state_code = str(state_code) if state_code else None

    def get_state_code(self):
        return self._state_code


    def get_report_type(self):
        return 'state' if self.get_state_code() else (
            'country' if self.get_country_code() else 'world')

    @staticmethod
    def _generate_api_response_dict(api_response_content):
        entity_delimiter = '#?'
        value_delimiter = '|'

        raw_entity_list = [entity for entity in api_response_content.split(entity_delimiter) if entity != '']
        for value in [row.split(value_delimiter) for row in raw_entity_list]:

            location_report = {}
            for i in range(len(LOCATION_SEARCH_API_SCHEMA)):
                location_report[LOCATION_SEARCH_API_SCHEMA[i][0]] = LOCATION_SEARCH_API_SCHEMA[i][1](value[i])

            yield LocationSearchAPIReportItem(**location_report)

    def set_contract_stat_item(self, is_contract_stat=False):
        self._is_contract_stat_item = is_contract_stat

    def is_contract_stat_item(self):
        return self._is_contract_stat_item

    def _get_api_uri(self):

        from_date = self.get_from_date().strftime('%Y%m%d')
        to_date = self.get_to_date().strftime('%Y%m%d')
        country = self.get_country_code()
        state = self.get_state_code()

        is_contract_stat = self.is_contract_stat_item()
        item_prefix = 'item_id_' if is_contract_stat else ''
        stat_list = [item_prefix + stat_id for stat_id in self._stat_list]

        query_param_string = {
            'stat_id': '|'.join(stat_list),
            'from': from_date,
            'to': to_date,
            'country': country,
            'state': state
        }
        param_sequence = ('stat_id', 'from', 'to', 'country', 'state')

        request_uri = '/%s?%s' % (self._default_route, '&'.join([
            '%s=%s' % (key, query_param_string[key]) for key in param_sequence
            if query_param_string[key] != None
        ]))

        api_request_key = self._get_api_request_key(request_uri)

        request_uri += '&key=%s' % api_request_key
        request_uri = request_uri.replace('|', '%7c')

        return request_uri

    def get_location_report(self, from_date=None, to_date=None, stat_list=None,
                            country=None, state=None, is_contract_stat=False):

        if is_contract_stat:
            self.set_contract_stat_item(is_contract_stat)
        if stat_list:
            self.set_stat_list(stat_list)
        if country:
            self.set_country_code(country)
        if state:
            self.set_state_code(state)
        if from_date:
            self.set_from_date(from_date)
        if to_date:
            self.set_to_date(to_date)

        stat_list = self.get_stat_list()
        country = self.get_country_code()
        state = self.get_state_code()
        from_date = self.get_from_date()
        to_date = self.get_to_date()

        api_uri = self._get_api_uri()

        self.api_request_url = '{api_url}{uri}'.format(api_url=self._url, uri=api_uri)

        try:

            api_response = urllib2.urlopen(self.api_request_url, timeout=self._timeout)

            api_status_code = api_response.getcode()
            api_response_body = api_response.read()

            report_type = self.get_report_type()

            api_result_body = LocationSearchAPIResponseBody(
                report_type=report_type, country_code=country, state_code=state, is_contract_stat=is_contract_stat,
                from_date=from_date, to_date=to_date, stat_id_list=[str(stat_id) for stat_id in stat_list],
                series_data=[i for i in self._generate_api_response_dict(api_response_body)]
            )

            api_status = 'success'

        # catch location search api request Exception
        except Exception as api_exception:
            self._raise_location_api_exception(api_exception)

        # wrap api response information
        api_result = LocationSearchAPIResponse(
            request_url=self.api_request_url,
            status=api_status, status_code=api_status_code,
            body=api_result_body
        )

        return api_result


class LocationSearchAPIISPWrapper(LocationSearchAPIWrapper):
    _default_route = 'list_isp'
