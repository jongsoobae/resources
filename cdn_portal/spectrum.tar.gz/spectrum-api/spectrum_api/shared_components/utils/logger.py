import logging

from spectrum_api import settings


class loggingCustomParams():
    loggingParams = None

    def __init__(self):
        self.loggingParams = {
            'requestuser':'',
            'app_name':'',
            'actualuser':'',
            'actualuserip':'',
            'requestpath':'',
            'requestmethod':'',
            'requestmeta':'',
            'requestparams':'',
            'responsecode':'',
            'responsedetail':'',
            'responsedump':''
        }

    def makeloggingParam(self, record):
        if hasattr(record, 'request'):
            if hasattr(record.request, 'user'):
                self.loggingParams['requestuser'] = record.request.user.username
            if hasattr(record.request, 'enduser'):
                self.loggingParams['app_name'] = record.request.enduser.app_name
                self.loggingParams['actualuser'] = record.request.enduser.username
                self.loggingParams['actualuserip'] = record.request.enduser.ip
            self.loggingParams['requestpath'] = record.request.path
            self.loggingParams['requestmethod'] = record.request.method

            if hasattr(record.request, 'QUERY_PARAMS'):
                self.loggingParams['requestparams'] = record.request.QUERY_PARAMS.items()

            if record.levelno >= logging.WARNING:
                self.loggingParams['requestmeta'] = record.request.META

        if hasattr(record, 'response'):
            self.loggingParams['responsecode'] = '%s/%s' % (record.response.status_code, record.response.status_text)

            if hasattr(record.response, 'data') and isinstance(record.response.data, dict):
                self.loggingParams['responsedetail'] = record.response.data.get('detail')

            if record.levelno >= logging.ERROR:
                self.loggingParams['responsedump'] = record.response.data

        for k, v in self.loggingParams.iteritems():
            record.__dict__[k] = v

        return record

class RequireDebugTrue(logging.Filter):
    def filter(self, record):
        debugStatus = settings.DEBUG

        if debugStatus:
            loggingCustomParams().makeloggingParam(record)

        return debugStatus

class RequireDebugFalse(logging.Filter):
    def filter(self, record):
        debugStatus = settings.DEBUG

        if not debugStatus:
            loggingCustomParams().makeloggingParam(record)

        return not debugStatus
