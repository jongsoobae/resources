'''
 Copyright (c) 2011 CDNetworks Co., Ltd.
 All rights reserved.

 $Id: regex.py 12207 2014-02-20 00:29:29Z hyejun.yim $
'''
import re
from django.utils.translation import ugettext as _
from django.core import exceptions

domain_rex = '^([A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)*[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.?$|^\.$'

# PRISMUI-1578 better domain name validation
ALLOW_ASTERISK_DOMAIN_REGEX = re.compile(r'(?=^.{1,254}$)(^([a-zA-Z0-9\-\_\,\*]{1,63}(\.|$))+$)')
NOT_ALLOW_ASTERISK_DOMAIN_REGEX = re.compile(r'(?=^.{1,254}$)(^([a-zA-Z0-9\-\_\,]{1,63}(\.|$))+$)')

gslb_domain_rex = '^([A-Za-z0-9\*]([A-Za-z0-9-\*\_]{0,61}[A-Za-z0-9\*])?\.)*[A-Za-z0-9\*]([A-Za-z0-9\-\*\_]{0,61}[A-Za-z0-9\*])?\.?$|^\.$'

signature_rex = '^0x[a-f0-9][a-f0-9][a-f0-9][a-f0-9][a-f0-9][a-f0-9][a-f0-9][a-f0-9]'  # 0xcd102010
# 10.10.10.10, 10.10.10.10/32 10.10.10.10-10.10.10.20
ip_range_rex = '^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)((\/(?:[012]\d?|3[012]?){0,1})|(\-(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){0,1})$'
oid_rex = '(^(\.[0-9]+)+$|^[0-9]+(\.[0-9]+)*$)'
customerpop_rex = '(^C|^V)[A-Z0-9]+-[A-Z0-9]+$'
stepfunc_rex = '^(([ \t]*-?[0-9]+\.?[0-9]*[ \t]*:[ \t]*-?[0-9]+\.?[0-9]*)?[ \t]*\r?\n)*([ \t]*-?[0-9]+\.?[0-9]*[ \t]*:[ \t]*-?[0-9]+\.?[0-9]*)?[ \t]*(\r?\n)?$'
customer_vip_rex = '^i[0-9]+$'
customersystem_rex = '(^s)[0-9]+$'
customerhost_rex = '(^h)[0-9]+$'
default_name_rex = '^\w+(\s\w+)?$'
default_password_rex = '^\w+(\s\w+|\S*)?$'
edge_name_rex = '^\w+[\-\s\:\(\)\w+]+$'
path_rex = '^(/\w+)+$'
rtmp_stream_name_rex = '^[\w\*\+\.\~\-\=\:\/]+$'
rtmp_app_rex = '^[\w\*\+\.\~\-\=\:\/]+$'
txt_prefix_rex = '^[\w\.\-]+$'
probe_name_rex = '^[\w\*\+\.\~\-\=\:\/]+$'
rtmp_flashver_rex = '^[\s\w\[\\\^\$\.\|\?\*\+\(\)`~!@#%-=\]{};\':",/]+$'
default_password_rex = '^[\s\w\[\\\^\$\.\|\?\*\+\(\)`~!@#%-=\]{};\':",/]+$'

REGEX_IPV4 = '^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$'
REGEX_CIDR = '^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])(\/(\d|[1-2]\d|3[0-2]))$'

REGEX_APP_NAME = r'^[\w\*\+\.\~\-\=\:\/]+$'
REGEX_POP_NAME = '[A-Z0-9]+-[A-Z0-9]+$'
REGEX_POP_GROUP_NAME = '^[\w\+\.\-]+$'

REGEX_DOMAIN_NAME = r'(?=^.{1,254}$)(^(?:(?!-)[a-zA-Z0-9\-]{1,63}(?<!-)\.?)+(?:[a-zA-Z]{2,})$)'
REGEX_DOMAIN_NAME_FLEXIBLE = r'(?=^.{1,254}$)(^(?:(?!-)[a-zA-Z0-9\-_]{1,63}(?<!-)\.?)+(?:[a-zA-Z]{2,})$)'

# REGEX_PATH_NAME = r'^(/\w+)+$'
# REGEX_PATH_NAME = r'^((/\w+)|(/\w+\.*\w+))+$'
# REGEX_PATH_NAME = r'^(/(?![-_\.])[a-zA-Z0-9-_\.]+(?<![-_\.]))+$'
REGEX_PATH_NAME = r'(^[/]$)|(^(/(?![-\.\'])[a-zA-Z0-9-_\.\']+(?<![-_\.\']))+$)'
REGEX_PARAM_NAME = r'^(|(|(?!-)[a-zA-Z0-9-_]{1,63}(?<!-))((\.)(?!-)[a-zA-Z0-9-_]{1,63}(?<!-))*)$'

# REGEX_PARAM_VALUE = r'^[\s\w\[\\\^\$\.\|\?\*\+\(\)`~!@#%-=\]{};\':",/]+$'
REGEX_PARAM_VALUE = r'[^<>\"\'&]+$'
REGEX_USER_NAME = r'^(|(|(?!-)[a-zA-Z0-9-_]{1,63}(?<!-))((\.)(?!-)[a-zA-Z0-9-_]{1,63}(?<!-))*)$'
REGEX_CLUSTER_NAME = r'^(|(|(?!-)[a-zA-Z0-9]{1,63}(?<!-))((?!-)[a-zA-Z0-9]{1,63}(?<!-))*)$'
REGEX_STORAGE_NAME = r'^(|(|(?!-)[a-zA-Z0-9]{1,63}(?<!-))((?!-)[a-zA-Z0-9]{1,63}(?<!-))*)$'
REGEX_STORAGE_NAME_RENEW = r'^(|(|(?!-)[a-zA-Z0-9-]{1,63}(?<!-))((?!-)[a-zA-Z0-9-]{1,63}(?<!-))*)$'
REGEX_STORAGE_NAME_FLEXIBLE = r'^(|(|(?!-)[a-zA-Z0-9-_]{1,63}(?<!-))((\.)(?!-)[a-zA-Z0-9-_]{1,63}(?<!-))*)$'
REGEX_STORAGE_NAME_NS = r'^(|(|(?!-)[a-zA-Z0-9-_]{1,63}(?<!-))((\.)(?!-)[a-zA-Z0-9-_]{1,63}(?<!-))*)$'

REGEX_EMAIL_VALUE = r'^[a-zA-Z0-9._%-]+@[a-zA-Z0-9._%-]+.[a-zA-Z]{2,6}$'
REGEX_MOBILE_NUMBER = r'^[0-9-+() ]*[0-9]+[0-9-+()]*$'
REGEX_PHONE_NUMBER = r'[\+]*[0-9-()# ]*$'

# regex compile area
regex_pop_name = re.compile(REGEX_POP_NAME)
regex_system_name = re.compile(customersystem_rex)
regex_host_name = re.compile(customerhost_rex)
regex_vip_name = re.compile(customer_vip_rex)
regex_ipv4 = re.compile(REGEX_IPV4)
regex_path = re.compile(path_rex)
regex_stepfunc = re.compile(stepfunc_rex)
regex_oid = re.compile(oid_rex)
regex_default_name = re.compile(default_name_rex)
regex_default_password = re.compile(default_password_rex)
regex_rtmp_app = re.compile(rtmp_app_rex)
regex_rtmp_flashver = re.compile(rtmp_flashver_rex)
regex_rtmp_stream_name = re.compile(rtmp_stream_name_rex)
regex_gslb_domain = re.compile(gslb_domain_rex)

EMAIL_RE = re.compile(
    r"(^[-!#$%&'*+/=?^_`{}|~0-9A-Z]+(\.[-!#$%&'*+/=?^_`{}|~0-9A-Z]+)*"  # dot-atom
    r'|^"([\001-\010\013\014\016-\037!#-\[\]-\177]|\\[\001-\011\013\014\016-\177])*"'  # quoted-string
    r')@(?:[A-Z0-9-]+\.)+[A-Z]{2,6}$', re.IGNORECASE)  # domain
