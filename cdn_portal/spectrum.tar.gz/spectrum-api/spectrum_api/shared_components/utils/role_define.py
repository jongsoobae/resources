#
# Copyright (c) 2011 CDNetworks Co., Ltd.
# All rights reserved.
#
# $Id$
#

MPROXY_ROLE = 'MPROXY'
