#!/usr/local/cdnet/shared/python/python2.6/bin/python
# from django.core.mail import send_mail, SMTPConnection, EmailMessage
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.header import Header
from email import Encoders
import smtplib
from email.Utils import parseaddr, formataddr

seconds_to_sleep = 60
SMTP_SERVER = 'send.mx.cdnetworks.com'
SMTP_PORT = 25
USERNAME = None
PASSWORD = None
DEBUG_MODE = 0

class MailObject(object):

    def __init__(self, from_email, receive_mail, title, content, attached_files=None):
        self.from_email = from_email
        self.receive_mail = receive_mail
        self.title = title
        self.content = content

        self.username = USERNAME
        self.password = PASSWORD
        self.message_list = []
        self.html_flag = 1
        self.attached_files = attached_files

    def get_attached_files_count(self):
        file_list = self.get_attached_files()
        if file_list:
            return len(file_list)
        else:
            return 0

    def get_attached_files(self):
        return self.attached_files

    def send_mail(self, html_flag=1):
        self.html_flag = html_flag
        smtp_obj = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        try:
            if smtp_obj.has_extn('STARTTLS'):
                smtp_obj.starttls()
                smtp_obj.ehlo()  # re-identify ourselves over TLS connection

            if self.username and self.password:
                smtp_obj.login(USERNAME, PASSWORD)

            body = self.content

            header_charset = 'ISO-8859-1'
            for body_charset in 'US-ASCII', 'ISO-8859-1', 'UTF-8':
                try:
                    body.encode(body_charset)
                except UnicodeError:
                    pass
                else:
                    break

            sender_name, sender_addr = parseaddr(self.from_email)
            sender_name = str(Header(unicode(sender_name), header_charset))
            sender_addr = sender_addr.encode('ascii')

            if DEBUG_MODE == 0:
                recipient_name, recipient_addr = parseaddr(self.receive_mail)
                recipient_name = str(Header(unicode(recipient_name), header_charset))
                recipient_addr = recipient_addr.encode('ascii')
            else:
                recipient_name, recipient_addr = parseaddr(self.from_mail)
                recipient_name = str(Header(unicode(recipient_name), header_charset))
                recipient_addr = recipient_addr.encode('ascii')
                # TO = self.from_email

            import os
            if self.get_attached_files_count() > 0:
                msg = MIMEMultipart()
                if self.html_flag == 0:
                    msgtxt = MIMEText(body.encode(body_charset), 'plain', body_charset)
                else:
                    msgtxt = MIMEText(body.encode(body_charset), 'html', body_charset)
                msg.attach(msgtxt)
                for notifile in self.get_attached_files():
                    filename = os.path.normpath(os.path.join(notifile.notification_content_file.filepath,
                                                              notifile.notification_content_file.filename))
                    # msg.attach(MIMEImage(file("image.png").read()))
                    part = MIMEBase('application', "octet-stream")
                    fp = open(filename, "rb")
                    part.set_payload(fp.read())
                    fp.close()

                    part.add_header('Content-transfer-encoding', 'base64')
                    attached_filename = (Header(notifile.notification_content_file.filename, 'utf-8').encode())
                    if attached_filename.find(" ") > 0:
                        attached_filename = '\"' + attached_filename + '\"'
                    part.add_header('Content-Disposition', 'attachment; filename=' + attached_filename)
                    Encoders.encode_base64(part)
                    msg.attach(part)
            else:
                if self.html_flag == 0:
                    msg = MIMEText(body.encode(body_charset), 'plain', body_charset)
                else:
                    msg = MIMEText(body.encode(body_charset), 'html', body_charset)
            msg['From'] = formataddr((sender_name, sender_addr))
            msg['To'] = formataddr((recipient_name, recipient_addr))
            msg['Subject'] = Header(unicode(self.title), header_charset)

            try:
                rets = smtp_obj.sendmail(self.from_email, self.receive_mail, msg.as_string())
                if rets == {}:
                    ret = 1
                else:
                    self.message_list.append(rets)
            except Exception, e:
                raise e
        except Exception, e:
            raise e
        finally:
            try:
                smtp_obj.quit()
            except:
                pass



