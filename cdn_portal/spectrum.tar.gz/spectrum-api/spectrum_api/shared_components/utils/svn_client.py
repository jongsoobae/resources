from django.conf import settings

def get_login(realm, username, may_save):
    '''
    retcode - boolean, False if no username and password are available. True if subversion is to use the username and password.
    username - string, the username to use
    password - string, the password to use
    save - boolean, return True if you want subversion to remember the username and password in the configuration directory.
    return False to prevent saving the username and password.
    '''
    return True, settings.CONFIG_SVN_USER, settings.CONFIG_SVN_PASS, True

def ssl_server_trust_prompt(trust_dict):
    ''' The callback_ssl_server_trust_prompt is called each time an HTTPS server presents a certificate and subversion is not sure if it should be trusted.
        callback_ssl_server_trust_prompt is called with information about the certificate in trust dict.
        failures - int - a bitmask of failures - [What do these bits mean?]
        hostname - string - the hostname the certificate was presented from
        finger_print - string - certificate finger print
        valid_from - string - valid from this ISO8601 date
        valid_until - string - valid util this ISO8601 date
        issuer_dname - stirng - the issued dname
        realm - string - the realm
    '''
    retcode = True  # boolean, False if no username and password are available. True if subversion is to use the username and password.
    accepted_failures = trust_dict['failures']  # int, the accepted failures allowed
    save = True  # boolean, return True if you want subversion to remember the certificate in the configuration directory. return False to prevent saving the certificate.
    return retcode, accepted_failures, save
