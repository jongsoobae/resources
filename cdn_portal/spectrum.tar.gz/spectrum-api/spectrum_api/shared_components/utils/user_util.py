# -*- coding: utf-8 -*-
import re
import logging

from django.contrib.auth.models import User
from django.utils.translation import ugettext as _
from rest_framework import exceptions
from rest_framework.status import HTTP_500_INTERNAL_SERVER_ERROR


log = logging.getLogger(__name__)

class UserInfoException(exceptions.APIException):
    status_code = HTTP_500_INTERNAL_SERVER_ERROR
    default_detail = _('Fail to identify actual user information')

__META_END_USER_KEY__ = "HTTP_X_ENDUSER"
__META_HOST_NAME_KEY__ = "HTTP_X_HOSTNAME"
__META_PROJECT_NAME__ = "HTTP_X_PROJECT_NAME"
__META_REMOTE_ADDR__ = "HTTP_X_REMOTE_ADDR"
__AURORA_PROJECT_NAME__ = "aurora_fe"
__AURORA_API_PROJECT_NAME__ = "aurora_api"
__PRISM_PROJECT_NAME__ = "prism_fe"
__PRISM_API_PROJECT_NAME__ = "prism_api"
__TELCO_PROJECT_NAME__ = "telco_fe"

def putActualUserInfo(request, userobj):
    try:
        end_user = request.META.get(__META_END_USER_KEY__, None)
        project_name = request.META.get(__META_PROJECT_NAME__, None)
        host_name = request.META.get(__META_HOST_NAME_KEY__, request.META['HTTP_HOST'])
        pos = host_name.find(":")
        host_name = host_name[:pos] if pos > 0 else host_name
        if end_user:
            if project_name in [__AURORA_PROJECT_NAME__, __AURORA_API_PROJECT_NAME__, __TELCO_PROJECT_NAME__]:
                request.enduser = User.objects.using('aurora').get(username=end_user)
                request.enduser.db_name = 'aurora'
                request.enduser.app_name = project_name
                request.enduser.host_name = host_name
            else:
                request.enduser = User.objects.get(username=end_user)
                request.enduser.db_name = 'default'
                request.enduser.app_name = project_name
                request.enduser.host_name = host_name
        else:
            request.enduser = userobj
            request.enduser.db_name = 'default'
            request.enduser.app_name = 'spectrum_api'
            request.enduser.host_name = host_name

        request.enduser.ip = getEndUserIP(request)

    except:
        raise UserInfoException

def getEndUserIP(request):
    end_ip = request.META.get(__META_REMOTE_ADDR__, None)

    if not end_ip:
        end_ip = request.META.get('HTTP_X_FORWARDED_FOR',
                        request.META.get('HTTP_X_FORWARDED_IP',
                             request.META.get('REMOTE_ADDR', None)))

    return end_ip

def getPrismUserObj(request):
    if request.enduser.db_name == 'default':
        return request.enduser
    else:
        return request.user


def _check_product_name(request, check_product_name):
    try:
        regex_limit_request = re.compile("^%s"%(check_product_name), re.IGNORECASE)
        _project_name = request.META.get("HTTP_X_PROJECT_NAME", None)
        if regex_limit_request.match(_project_name):
            is_matched = True
        else:
            is_matched = False
    except Exception as e:
        log.warning(e)
        is_matched = False

    return is_matched


def is_request_from_aurora(request):
    return _check_product_name(request, 'aurora')
