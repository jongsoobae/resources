# Location Search API Call
from spectrum_api.shared_components.utils.location_api_wrapper import LocationSearchAPIWrapper
from spectrum_api.config_constants import LOCATION_SEARCH_API_INFO

def get_location_api_response(stat_list, from_date, to_date, country=None, state=None, is_contract_stat=False):

    api_wrapper = LocationSearchAPIWrapper(**LOCATION_SEARCH_API_INFO)

    location_api_response = api_wrapper.get_location_report(
        stat_list=stat_list, from_date=from_date, to_date=to_date,
        country=country, state=state, is_contract_stat=is_contract_stat)

    return location_api_response.body.series_data
