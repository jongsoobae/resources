# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Rest API Token
"""
from __future__ import absolute_import

from rest_framework import mixins, exceptions
from rest_framework.status import HTTP_404_NOT_FOUND

from spectrum_api.shared_components.models.customer import CustomerDisplay, \
    CustomerAccount, \
    CustomerContract, CustomerItem
from spectrum_api.shared_components.serializers.customer import CustomerDisplaySerializer, \
    CustomerAccountSerializer, \
    CustomerContractSerializer, \
    CustomerDisplaySimpleSerializer, CustomerItemSerializer, \
    CustomerItemSimpleSerializer
from spectrum_api.shared_components.generics import SpectrumGenericAPIView


class CustomerDoseNotExist(exceptions.APIException):
    status_code = HTTP_404_NOT_FOUND
    default_detail = 'You access does not exists Customer'


__CUSTOMER_URL_LOOKUP_KEY__ = "customer_id"
__CUSTOMER_ACCOUNT_URL_LOOKUP_KEY__ = "account_no"
__CUSTOMER_CONTRACT_URL_LOOKUP_KEY__ = "contract_no"
__CUSTOMER_ITEM_URL_LOOKUP_KEY__ = "item_id"


class CustomerAPI(mixins.ListModelMixin, SpectrumGenericAPIView, ):
    """Get Customer Display list"""
    queryset = CustomerDisplay.objects.all()
    serializer_class = CustomerDisplaySerializer
    lookup_url_kwarg = __CUSTOMER_URL_LOOKUP_KEY__
    search_fields = ("customer_name", "account",)
    filter_fields = ("customer_name", "account", "account_name_eng", "account",
                     {"account_name_local": "account__account_name_local"},
                     {"account_name_eng": "account__account_name_engl"},
                     {"material_no": "account__customercontract__customeritem__material_no"},
                     {"description": "account__description"},)
    ordering = 'customer_name'

    def get(self, request, *args, **kwargs):
        """Get Customer Display list"""
        lite = request.QUERY_PARAMS.get("lite", None)
        if lite:
            self.serializer_class = CustomerDisplaySimpleSerializer
        else:
            pass
        return super(CustomerAPI, self).list(request, *args, **kwargs)


class CustomerDetailAPI(mixins.RetrieveModelMixin, SpectrumGenericAPIView, ):
    """Customer Display by customer ID"""
    queryset = CustomerDisplay.objects.all()
    serializer_class = CustomerDisplaySerializer
    lookup_url_kwarg = __CUSTOMER_URL_LOOKUP_KEY__

    def get(self, request, *args, **kwargs):
        """Customer Display by customer ID"""
        return super(CustomerDetailAPI, self).retrieve(request, *args, **kwargs)


class CustomerAccountAPI(mixins.ListModelMixin, SpectrumGenericAPIView, ):
    """Get Customer Account list"""
    queryset = CustomerAccount.objects.all()
    serializer_class = CustomerAccountSerializer
    lookup_url_kwarg = __CUSTOMER_ACCOUNT_URL_LOOKUP_KEY__
    search_fields = ("account_name_eng", "account_name_local", "account_no",)
    filter_fields = ("account_name_eng", "account_no", "account_name_local", "description",
                     {"material_no": "customercontract__customeritem__material_no"},)

    def get(self, request, *args, **kwargs):
        """Get Customer Display list"""
        return super(CustomerAccountAPI, self).list(request, *args, **kwargs)


class CustomerAccountDetailAPI(mixins.RetrieveModelMixin, SpectrumGenericAPIView, ):
    """Customer Account by customer ID"""
    queryset = CustomerAccount.objects.all()
    serializer_class = CustomerAccountSerializer
    lookup_url_kwarg = __CUSTOMER_ACCOUNT_URL_LOOKUP_KEY__

    def get(self, request, *args, **kwargs):
        """Customer Display by customer ID"""
        return super(CustomerAccountDetailAPI, self).retrieve(request, *args, **kwargs)


class CustomerContractAPI(mixins.ListModelMixin, SpectrumGenericAPIView, ):
    """Get Customer Contract list"""
    queryset = CustomerContract.objects.all()
    serializer_class = CustomerContractSerializer
    lookup_url_kwarg = __CUSTOMER_CONTRACT_URL_LOOKUP_KEY__
    search_fields = ("contract_name", "contract_no",)
    filter_fields = ("contract_name", "contract_no", "account",
                     {"customer_id": "account__customerdisplay"},
                     {"customer_name": "account__customerdisplay__customer_name"},
                     {"customer_item": "customeritem"},
                     {"material_no": "customeritem__material_no"}
    )

    def get(self, request, *args, **kwargs):
        """Get Customer Contract list"""
        contract_response = super(CustomerContractAPI, self).list(request, *args, **kwargs)

        # Wrap Contract Expired Condition to Customer Contract Response
        if type(contract_response.data) == list:
            contract_list_data = contract_response.data
        else:
            contract_list_data = contract_response.data.get('results')

        for contract_dict, contract_object in zip(contract_list_data, self.object_list):

            valid = contract_object.is_valid_contract(request.GET.get('material_no'))

            contract_dict.update({
                'expired': not valid
            })

        return contract_response


class CustomerContractDetailAPI(mixins.RetrieveModelMixin, SpectrumGenericAPIView, ):
    """Customer Display by customer ID"""
    queryset = CustomerContract.objects.all()
    serializer_class = CustomerContractSerializer
    lookup_url_kwarg = __CUSTOMER_CONTRACT_URL_LOOKUP_KEY__

    def get(self, request, *args, **kwargs):
        """Customer Display by customer ID"""
        return super(CustomerContractDetailAPI, self).retrieve(request, *args, **kwargs)


class CustomerItemAPI(mixins.ListModelMixin, SpectrumGenericAPIView, ):
    """Get Customer Item list"""
    queryset = CustomerItem.objects.all()
    serializer_class = CustomerItemSerializer
    lookup_url_kwarg = __CUSTOMER_CONTRACT_URL_LOOKUP_KEY__
    search_fields = ("contract_name", "contract_no",)
    filter_fields = ("contract_name", "contract_no",
                     {"customer_id": "contract__account__customerdisplay"},
                     "material_no")

    def get(self, request, *args, **kwargs):
        """Get Customer Item list"""
        lite = request.QUERY_PARAMS.get("lite", None)
        if lite:
            self.serializer_class = CustomerItemSimpleSerializer

        return super(CustomerItemAPI, self).list(request, *args, **kwargs)


class CustomerItemDetailAPI(mixins.RetrieveModelMixin, SpectrumGenericAPIView, ):
    """Customer Item by customer ID"""
    queryset = CustomerItem.objects.all()
    serializer_class = CustomerItemSerializer
    lookup_url_kwarg = __CUSTOMER_ITEM_URL_LOOKUP_KEY__

    def get(self, request, *args, **kwargs):
        """Customer Item by customer ID"""
        return super(CustomerItemDetailAPI, self).retrieve(request, *args, **kwargs)