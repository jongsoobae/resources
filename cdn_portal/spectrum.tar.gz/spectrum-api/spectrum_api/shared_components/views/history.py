# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Rest API
"""
from spectrum_api.shared_components.models import ActionHistory
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.mixins import ListModelMixin
from spectrum_api.shared_components.serializers.history import ActionHistorySerializer

class ChangeHistoryAPI(ListModelMixin,
            SpectrumGenericAPIView):
    queryset = ActionHistory.objects.all()
    serializer_class = ActionHistorySerializer
    lookup_url_kwarg = "action_id"
    search_fields = ("action_model", "action_pk",)
    filter_fields = ("action_model", "action_pk", "action_type", "user_ip",)

    def get_queryset(self):
        queryset = self.queryset.using(self.request.enduser.db_name)
        return queryset

    def get(self, request, *args, **kwargs):
        return super(ChangeHistoryAPI, self).list(request, *args, **kwargs)
