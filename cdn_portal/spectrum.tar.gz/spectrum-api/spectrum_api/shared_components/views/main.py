# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Spectrum Rest API version monitoring
"""
from rest_framework.views import APIView
from rest_framework.response import Response
from spectrum_api.settings import __version__, IS_PRODUCTION

class SpectrumVersionAPI(APIView):
    def get(self, request):
        if IS_PRODUCTION :
            flag = "stable"
        else:
            flag = "devel"

        context = {"app" : "Spectrum API",
                    "version" : __version__,
                    "flag" : flag}
        return Response(context)
