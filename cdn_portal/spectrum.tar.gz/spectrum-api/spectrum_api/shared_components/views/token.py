# -*- coding: utf-8 -*-
"""
    Copyright (c) 2014 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Rest API Token
"""
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.authtoken.models import Token

class TokenAPI(APIView):
    def get(self, request):
        try:
            token, created = Token.objects.get_or_create(user=request.user)
            result = {"user": request.user.username, "token":token.key}
        except Exception as e:
            raise e
        return Response(result)

    def post(self, request):
        try:
            token, created = Token.objects.get_or_create(user=request.user)
            result = {"user": request.user.username, "token":token.key}
        except Exception as e:
            raise e
        return Response(result)
