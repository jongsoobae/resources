from spectrum_api.shared_components.utils.common import log_error
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.mixins \
    import UpdateModelMixin, RetrieveModelMixin
from spectrum_api.shared_components.models.user import AuroraUser
from spectrum_api.shared_components.serializers.user import AuroraUserSerializer
from rest_framework.status import HTTP_500_INTERNAL_SERVER_ERROR
from rest_framework.exceptions import APIException
from django.utils.translation import ugettext as _


class AuroraUserAPI500Exception(APIException):
    status_code = HTTP_500_INTERNAL_SERVER_ERROR
    default_detail = _(u'API call failed.')


class AuroraUserAPI(UpdateModelMixin, RetrieveModelMixin,
                    SpectrumGenericAPIView):
    queryset = AuroraUser.objects.all()
    serializer_class = AuroraUserSerializer
    lookup_url_kwarg = "id"
    paginate_by = None

    def __init__(self):
        super(AuroraUserAPI, self).__init__()

    def get(self, request, *args, **kwargs):
        try:
            return super(AuroraUserAPI, self).retrieve(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle GET request on 'AuroraUserAPI'."
            log_error(request, msg, e=e)
            raise AuroraUserAPI500Exception

    def put(self, request, *args, **kwargs):
        try:
            return super(AuroraUserAPI, self).update(request, *args, **kwargs)
        except Exception as e:
            msg = "Failed to handle PUT request on 'AuroraUserAPI'."
            log_error(request, msg, e=e)
            raise AuroraUserAPI500Exception