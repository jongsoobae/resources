# -*- coding: utf-8 -*-
"""
    Copyright (c) 2012 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
"""
