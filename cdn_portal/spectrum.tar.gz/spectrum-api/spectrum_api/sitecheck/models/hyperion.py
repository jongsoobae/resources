# -*- coding: utf-8 -*-
"""
    Copyright (c) 2012 CDNetworks Co., Ltd.
    All rights reserved.

    $Id$

    Description
        Sitechecker(hyperion) Models
"""
from django.core.validators import MaxValueValidator, MinValueValidator, \
        MaxLengthValidator
from django.db import models

from spectrum_api.configuration.models.base import Vip
from spectrum_api.shared_components.models import BaseModel

U_INTEGER32_MAX = 4294967295

AGENT_TYPE_CHOICES = (
    (0, 'HTTP_GET'),
    (1, 'DNS'),
    (2, 'CONNECT'),
    (3, 'HTTP_HEAD')
)

AGENT_MEASURE_STATUS = (
    (0, 'Running'),
    (1, 'Idle'),
    (2, 'Error'),
    (3, 'Maintenance'),
    (4, 'Inactive'),
    (5, 'Upcoming'),
    (6, 'Suspended'),
)

BOOL_AGENT_STATUS_CHOICES = (
    (1, 'Active'),
    (0, 'Suspend'),
)

class HyperionBase(BaseModel):
    """
    Definition of
        Commonly used columns in (abstract) Hyperion Model(s)
    """
    id = models.AutoField(primary_key=True)
    obj_state = models.BooleanField("State", editable=False, default=True)
    date_created = models.DateTimeField(auto_now_add=True, editable=False)
    date_modified = models.DateTimeField(auto_now=True, editable=False)

    class Meta:
        abstract = True

class HyperionAgent(HyperionBase):
    agent_type = models.SmallIntegerField(default=0, choices=AGENT_TYPE_CHOICES)
    ipid = models.ForeignKey(Vip, db_column='ipid',
                                        verbose_name='VIP',
                                        unique=True,
                                        help_text='')  # model check~
    debug_port = models.PositiveIntegerField(null=True, blank=True,
                                                verbose_name='Debug port',
                                                validators=[MinValueValidator(1), MaxValueValidator(65535)],
                                                help_text="""The debug port that hyperion listens on.

                                                                    Default: 2121
                                                                    Value range: integer 1 ~ 65535

                                                                    <span class="highlight">Change requires hyperion restart.</span>""")
    num_threads = models.SmallIntegerField(null=True, blank=True,
                                        verbose_name='Number of thread',
                                        validators=[MinValueValidator(0), MaxValueValidator(16)],
                                        help_text="""The number of concurrent tester threads.

                                                        0 means as same as the number of CPU cores.

                                                        Default: 0
                                                        Value range: integer 0 ~ 16

                                                        <span class="highlight">Change requires hyperion restart.</span>""")
    measuring_timeout = models.PositiveIntegerField(null=True, blank=True,
                                                            verbose_name='Timeout',
                                                            validators=[MinValueValidator(1), MaxValueValidator(U_INTEGER32_MAX)],
                                                            help_text="""If hyperion does not receive a request on an open
                                                                            connection for this timeout, it will close the connection.

                                                                            Default: 30 seconds
                                                                            Value range: integer 1 ~ 4294967295

                                                                            <span class="highlight">Change requires hyperion restart.</span>""")
    log_rotate_interval = models.PositiveIntegerField(null=True, blank=True,
                                                            verbose_name='Log rotate interval',
                                                            validators=[MinValueValidator(1), MaxValueValidator(U_INTEGER32_MAX)],
                                                            help_text="""The time interval (in seconds) after which
                                                                        the temporary log file is moved to a permanent file.

                                                                        Default: 60 seconds
                                                                        Value range: integer 1 ~ 4294967295

                                                                        <span class="highlight">Change requires hyperion restart.</span>""")
    enabled = models.SmallIntegerField(default=1,
                                                verbose_name='Active state',
                                                help_text='',
                                                choices=BOOL_AGENT_STATUS_CHOICES)
    measuring_status = models.SmallIntegerField(default=0,
                                                choices=AGENT_MEASURE_STATUS,
                                                verbose_name='Agent status',
                                                help_text='Agent measuring status',)
    description = models.TextField(max_length=200,
                                    validators=[MaxLengthValidator(200)],
                                    verbose_name='Agent Description',
                                    null=True,
                                    blank=True,
                                    help_text='')

    class Meta:
        app_label = 'sitecheck'
        db_table = 'hyperion_agent'
        verbose_name = 'Agent'

    class SpectrumMeta:
        allow_delete = True

    def __unicode__(self):
        return "%s : %s" % (self.ipid.host.system.pop, self.ipid)

    def save(self, request):
        super(HyperionAgent, self).save(request=request)