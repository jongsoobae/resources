import os, sys
import unittest
from datetime import datetime
if 'DJANGO_SETTINGS_MODULE' not in os.environ or os.environ['DJANGO_SETTINGS_MODULE'] is None:
    os.environ['DJANGO_SETTINGS_MODULE'] = 'spectrum_api.settings'
from django.test.client import RequestFactory
from django.test import Client
from django.conf import settings
from django.contrib.auth.models import User as AuthUser
import json
from django.utils.importlib import import_module
from spectrum_api.shared_components.utils.common import get_userinfo_from_context, get_current_obj_as_json_from_db, \
    get_userinfo_as_tuple_from_context, get_parameter_info_from_request, log_error

USERNAME = 'injune.hwang'
PASSWORD = 'cdnadmin'

def is_authenticated():
    return True


class TestRequestContext(unittest.TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.request = self.factory.get('')
        self.request.user = AuthUser.objects.get(username=USERNAME)
        self.request.user.is_authenticated = is_authenticated

    def tearDown(self):
        pass


    def test_get_userinfo_as_tuple_from_context(self):
        user_info_tuple = get_userinfo_as_tuple_from_context(self.request)
        self.assertIn(USERNAME, user_info_tuple[1])

    def test_get_userinfo_from_context(self):
        user_info = get_userinfo_from_context(self.request)
        self.assertIn(USERNAME,user_info.get('user_email'))

    def test_get_parameter_info_from_request(self):
        self.request = self.factory.post(path='/login',data={'username':USERNAME,'password':PASSWORD})
        self.request.user = AuthUser.objects.get(username=USERNAME)
        self.request.user.is_authenticated = is_authenticated
        param_string = get_parameter_info_from_request(self.request)
        self.assertEqual(param_string, "username=%s,password=*******," % USERNAME)

    def test_log_error(self):
        self.request = self.factory.post(path='/login',data={'username':USERNAME,'password':PASSWORD})
        self.request.user = AuthUser.objects.get(username=USERNAME)
        self.request.user.is_authenticated = is_authenticated
        result = log_error(request=self.request, message='test message', e=Exception('my error'))
        print result
        self.assertTrue(int(result) > 0 and result is not None)
