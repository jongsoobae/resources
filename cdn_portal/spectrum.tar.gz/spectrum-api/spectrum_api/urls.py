# -*- coding: utf-8 -*-
from django.conf.urls.defaults import patterns, include
URL_PREFIX = "api/"
urlpatterns = patterns('',
    # Shared Components
    (r'^' + URL_PREFIX, include('spectrum_api.shared_components.urls')),
    # configuration
    (r'^' + URL_PREFIX, include('spectrum_api.configuration.urls')),
    # gslb_domain
    (r'^' + URL_PREFIX, include('spectrum_api.dna.urls')),
    # wpo
    (r'^' + URL_PREFIX, include('spectrum_api.wpo.urls')),
    # cloud dns
    (r'^' + URL_PREFIX, include('spectrum_api.dns.urls')),
    # help desk
    (r'^' + URL_PREFIX, include('spectrum_api.helpdesk.urls')),
    # mail notification
    (r'^' + URL_PREFIX, include('spectrum_api.mail_notification.urls')),
    # report
    (r'^' + URL_PREFIX, include('spectrum_api.report.urls')),
    # cloud storage
    (r'^' + URL_PREFIX, include('spectrum_api.cloudstorage.urls')),
    # cloud security
    (r'^' + URL_PREFIX, include('spectrum_api.cloudsecurity.urls')),
    # proactive alert
    (r'^' + URL_PREFIX, include('spectrum_api.proactive_alert.urls')),
    # rms
    (r'^' + URL_PREFIX, include('spectrum_api.rms.urls')),
    # customer
    (r'^' + URL_PREFIX, include('spectrum_api.customer.urls')),
)
