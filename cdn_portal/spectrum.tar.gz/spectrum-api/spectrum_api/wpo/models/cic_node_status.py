
from django.db import models


class CicNodeStatus(models.Model):
    ''' CIC Monitoring API - Node Status version snapshot model

        It has base's config revision number,
        and IC node's config revision number.

        This data is not created in SpectrumAPI.
        Served from Backend Module.
    '''

    node_id = models.PositiveIntegerField(db_column='ic_node_id')
    start_time = models.DateTimeField(primary_key=True)
    base_version = models.IntegerField()
    config_version = models.IntegerField()

    class Meta(object):
        unique_together = ('node_id', 'start_time')
        ordering = ['-start_time']
        db_table = 'cic_snapshot_node_status'

    class SpectrumMeta(object):
        read_only = True
        router = 'spectrum'
