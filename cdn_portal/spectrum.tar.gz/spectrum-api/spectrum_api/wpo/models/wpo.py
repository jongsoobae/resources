import json
import logging
from datetime import datetime, timedelta, date

from django.core import serializers
from django.core.exceptions import ObjectDoesNotExist
from django.conf import settings
from django.db import models
from django.db import transaction
from django.db.models import Q
from rest_framework import status

from spectrum_api.configuration.models import Model
from spectrum_api.configuration.views.config import config_push, joint_push, ConfigAPIException
from spectrum_api.configuration.models.config import ConfigPhase, ConfigJoint
from spectrum_api.configuration.models.base import Vip, Edge, BaseProbeConfig, BaseVipEdge, ProbeConfigAggregate, \
    VipProbeConfigs
from spectrum_api.configuration.models.node_mon import DomainVipStatus, DomainStatus
from spectrum_api.dna.models import WPO_DOMAIN
from spectrum_api.dna.models.domain import Domain, DomainEdge, DomainVip
from spectrum_api.shared_components.models import BaseModel
from spectrum_api.shared_components.models.customer import CustomerDisplay, CustomerItem, CustomerContract
from spectrum_api.shared_components.models.snapshot import ProductionSnapshot
from spectrum_api.wpo.views.wpo_common import WPOAPIException, WPOAPICustomException
from spectrum_api.wpo.models.cic_node_status import CicNodeStatus
from spectrum_api.rms.models.gslb_rms import RMSMessage
from spectrum_api.rms.models.gslb_rms import get_translated_rms_message


logger = logging.getLogger(__name__)

FEO_CLUSTER_DOMAIN_SUFFIX = ".wpo-cluster.cdngp.net"
FEO_CLUSTER_DOMAIN_PREFIX = "staging."

IC_CLUSTER_DOMAIN_SUFFIX = ".ic-cluster.cdngp.net"
IC_CLUSTER_DOMAIN_PREFIX = "staging."

FEO_WID_DOMAIN_STAGING_SUFFIX = ".wpo.cdngp.net"
FEO_WID_DOMAIN_STAGING_PREFIX = "staging."

IC_WID_DOMAIN_STAGING_SUFFIX = ".ic.cdngp.net"
IC_WID_DOMAIN_STAGING_PREFIX = "staging."

WPO_SHARD_DOMAIN_CODE_ID = 705

WID_BACKUP_DOMAIN_SUFFIX = ".wpo.cdngp.net"
WID_BACKUP_DOMAIN_PREFIX = "backup."
WID_BACKUP_DOMAIN_STAGING_SUFFIX = ".cdngp.net"
WID_BACKUP_DOMAIN_STAGING_PREFIX = "staging.backup."

H_WPO_CLUSTER_DOMAIN = ''
H_WPO_STAGING_CLUSTER_DOMAIN = ''
H_WPO_LOCATION = ''

STAGING_EDGE_NAME = 'wpo_staging_edge'
AGGREGATE_PROBE_NAME = "wpo_aggregate_probe"
IC_NODE_AGGREGATE_PROBE_NAME = "IC_NODE_AGGREGATE_PROBE"
IC_APP_AGGREGATE_PROBE_NAME = "IC_APP_AGGREGATE_PROBE"

TIMEOUT = 30  # deploy time out minutes
DEV_LOCK_TIMEOUT = 30

WPO_NODE_TYPE = (
    (0, 'WPO'),
    (1, 'STAGING'),
)
WPO_CUSTOMER_DOMAIN_TYPE = (
    (0, 'MAIN_DOMAIN'),
    (1, 'SUB_DOMAIN'),
    (2, 'REWRITE_DOMAIN'),
)

WPO_HISTORY_TYPE = (
    (1, 'ADD'),
    (2, 'MODIFY'),
    (3, 'DELETE'),
    (4, 'RESTORED'),
    (5, 'ROLLBACK')
)


WPO_TYPE_FEO = (1, 'FEO')
WPO_TYPE_IC = (2, 'Image Converter')
WPO_TYPES = (
    WPO_TYPE_FEO,
    WPO_TYPE_IC
)

CLUSTER_DOMAIN_SUFFIX_FOR_TYPE = {
    WPO_TYPE_FEO[0]: FEO_CLUSTER_DOMAIN_SUFFIX,
    WPO_TYPE_IC[0]: IC_CLUSTER_DOMAIN_SUFFIX,
}

CLUSTER_DOMAIN_PREFIX_FOR_TYPE = {
    WPO_TYPE_FEO[0]: FEO_CLUSTER_DOMAIN_PREFIX,
    WPO_TYPE_IC[0]: IC_CLUSTER_DOMAIN_PREFIX,
}

WID_DOMAIN_SUFFIX_FOR_TYPE = {
    WPO_TYPE_FEO[0]: FEO_WID_DOMAIN_STAGING_SUFFIX,
    WPO_TYPE_IC[0]: IC_WID_DOMAIN_STAGING_SUFFIX,
}

WID_DOMAIN_PREFIX_FOR_TYPE = {
    WPO_TYPE_FEO[0]: FEO_WID_DOMAIN_STAGING_PREFIX,
    WPO_TYPE_IC[0]: IC_WID_DOMAIN_STAGING_PREFIX,
}

WPO_TYPES_DICT = dict((key, value) for key, value in WPO_TYPES)

WPO_JOINT_PUSH_NAME = 'WPO Staging push'
CIC_JOINT_PUSH_NAME = 'CIC Staging push'


class WPOType(BaseModel):
    wpo_type_id = models.AutoField(primary_key=True, db_column='wpo_type_id')
    name = models.CharField(max_length=255)
    description = models.CharField(max_length=1024, blank=True)
    obj_state = models.PositiveSmallIntegerField(default=1)
    date_created = models.DateTimeField('Date Created', auto_now_add=True)
    date_modified = models.DateTimeField('Date Modified', auto_now=True)
    latest_updater = models.CharField(max_length=128, blank=True)

    class Meta:
        db_table = 'wpo_type'

    def __unicode__(self):
        return '%s' % self.name


class WPOLocation(BaseModel):
    location_id = models.AutoField(primary_key=True)
    location_name = models.CharField(max_length=255, unique=True, blank=False)
    config_phase = models.ForeignKey(ConfigPhase, db_column='config_phase_id')
    wpo_type = models.ForeignKey(WPOType, db_column='wpo_type_id')
    obj_state = models.PositiveSmallIntegerField(default=1)
    date_created = models.DateTimeField('Date Created', auto_now_add=True)
    date_modified = models.DateTimeField('Date Modified', auto_now=True)
    latest_updater = models.CharField(max_length=128, blank=True)
    description = models.CharField(max_length=1024, blank=True)

    class Meta:
        db_table = 'wpo_location'
        ordering = ['location_name']

    # noinspection PyClassHasNoInit
    class SpectrumMeta:
        allow_delete = True

    def __unicode__(self):
        return '%s' % self.location_name

    def clean(self):
        pass

    def is_deletable(self):
        if WPOCluster.objects.filter(wpo_location=self).exists():
            return False
        if WPOWid.objects.filter(location=self).exists():
            return False
        return True

    def get_related_objects(self):
        dsp_deps_limit = 10

        return ((WPOCluster, WPOCluster.objects.filter(wpo_location=self.pk)[:dsp_deps_limit]),
                (WPOWid, WPOWid.objects.filter(location=self.pk)[:dsp_deps_limit][:dsp_deps_limit]))

    def delete_related(self, request=None):
        pass

    def is_modifiable(self):
        return True

    def save(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        if self.pk and not self.is_modifiable():
            raise WPOAPIException(status.HTTP_400_BAD_REQUEST, "%s is not modifiable." % (str(self)))

        super(WPOLocation, self).save(request=request)

    def delete(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        self.delete_related(request=request)
        if self.is_deletable():
            super(WPOLocation, self).delete()
        else:
            raise WPOAPIException(status.HTTP_400_BAD_REQUEST, "%s is not deletable." % (str(self)))


class WPOCluster(Model):
    cluster_id = models.AutoField(primary_key=True)
    cluster_name = models.CharField(max_length=229, unique=True)
    primary_cluster_domain = models.ForeignKey(Domain,
                                               db_column='primary_cluster_domain_id',
                                               help_text=H_WPO_CLUSTER_DOMAIN)
    staging_cluster_domain = models.ForeignKey(Domain,
                                               db_column='staging_cluster_domain_id',
                                               help_text=H_WPO_STAGING_CLUSTER_DOMAIN)
    edge = models.ForeignKey(Edge, db_column='edge_id')
    wpo_location = models.ForeignKey(WPOLocation,
                                     db_column='location_id',
                                     help_text=H_WPO_LOCATION)
    generate_gslb = models.PositiveSmallIntegerField(default=1)

    config_state = models.SmallIntegerField(default=0)
    obj_state = models.PositiveSmallIntegerField(default=1)
    date_created = models.DateTimeField('Date Created', auto_now_add=True)
    date_modified = models.DateTimeField('Date Modified', auto_now=True)
    latest_updater = models.CharField(max_length=128, blank=True)
    description = models.CharField(max_length=1024, blank=True)

    class Meta:
        db_table = 'wpo_cluster'
        ordering = ['cluster_name']

    # noinspection PyClassHasNoInit
    class SpectrumMeta:
        allow_delete = True
        track = True

    def __unicode__(self):
        return '%s' % self.cluster_name

    def clean(self):
        pass

    @staticmethod
    def get_primary_domain_name_rule(cluster_name, wpo_type=WPO_TYPE_FEO[0]):
        return '%s%s' % (cluster_name, CLUSTER_DOMAIN_SUFFIX_FOR_TYPE[wpo_type])

    @staticmethod
    def get_staging_domain_name_rule(cluster_name, wpo_type=WPO_TYPE_FEO[0]):
        suffix = CLUSTER_DOMAIN_SUFFIX_FOR_TYPE[wpo_type]
        prefix = CLUSTER_DOMAIN_PREFIX_FOR_TYPE[wpo_type]
        return '%s%s%s' % (prefix, cluster_name, suffix)

    @staticmethod
    def get_primary_edge_name_rule(cluster_name):
        return 'wpo_%s_edge' % cluster_name

    @staticmethod
    def get_staging_edge():
        try:
            edge = Edge.objects.get(name=STAGING_EDGE_NAME)
        except Edge.DoesNotExist:
            edge = Edge.objects.create(name=STAGING_EDGE_NAME, description='for staging wpo_cluster')
        return edge

    def get_connectivity(self):
        try:
            domainstatus = DomainStatus.objects.get(domain_id=self.primary_cluster_domain.pk)
            #return "%s/%s" % (str(domainstatus.active_count), str(self.get_production_vips_count()))

            return "S: %s P: %s / T: %s" % (
                WPONode.objects.filter(wpo_cluster=self, node_type=1).count(),
                domainstatus.active_count,
                WPONode.objects.filter(wpo_cluster=self).count()
            )

            #return str(domainstatus.active_count)
        except DomainStatus.DoesNotExist:
            return "N/A"

    def get_status_display(self):
        try:
            domainstatus = DomainStatus.objects.get(domain_id=self.primary_cluster_domain.pk)
            return domainstatus.get_status_display()
        except DomainStatus.DoesNotExist:
            return "Unknown"

    def get_staging_status_display(self):
        try:
            domainstatus = DomainStatus.objects.get(domain_id=self.staging_cluster_domain.pk)
            return domainstatus.get_status_display()
        except DomainStatus.DoesNotExist:
            return "Unknown"

    def get_production_vips_count(self):
        # nodes = WPONode.objects.filter(wpo_cluster=self, node_type=0)
        return len(self.primary_cluster_domain.get_related_vips())

    def get_wpo_node_count(self):
        return WPONode.objects.filter(wpo_cluster=self, node_type=0).count()

    def get_staging_node_count(self):
        return WPONode.objects.filter(wpo_cluster=self, node_type=1).count()

    def b_activate(self):
        b_exist_wpo_node = self.get_wpo_node_count() >= 1
        b_exist_staging_node = self.get_staging_node_count() >= 1
        if b_exist_wpo_node and b_exist_staging_node:
            return True
        else:
            return False

    def is_deletable(self):
        if WPOWid.objects.filter(cluster=self).exists():
            return False
        if WPOWid.objects.filter(backup_cluster=self).exists():
            return False
        return True

    def get_related_objects(self):
        dsp_deps_limit = 10
        today = date.today()
        wids = WPOWid.objects.filter(Q(cluster=self) | Q(backup_cluster=self))

        #customers = CustomerDisplay.objects.filter(pk__in=wids.values('customer'))
        customer_contracts = []
        wid_objects = []

        for wid in wids:
            try:
                contract = wid.customer_item.contract
                valid_contract = ' (expired)'
                if contract and contract.contract_end:
                    if ((contract.contract_terminate
                         and today <= contract.contract_terminate)
                        and today <= contract.contract_end) \
                            or (today <= contract.contract_end and contract.contract_terminate is None):
                            valid_contract = ''

                customer_contracts.append([wid.wid_name, wid.customer.customer_name, contract.contract_name + valid_contract])
                wid_objects.append([wid, wid.pk])
            except Exception:
                pass
        return (
            (CustomerContract, customer_contracts[:dsp_deps_limit]),
            (WPOWid, wid_objects)
        )

    def delete_related(self, request=None):
        try:
            self.primary_cluster_domain.delete(request=request)
            self.staging_cluster_domain.delete(request=request)
            self.edge.delete(request=request)
        except Exception, e:
            print e

    def is_modifiable(self):
        return True

    def touch_edge(self, request=None):
        if self.edge_id:
            if self.edge.name != self.get_primary_edge_name_rule(self.cluster_name):
                self.edge.name = self.get_primary_edge_name_rule(self.cluster_name)
                self.edge.save(request=request)
        else:
            edge = Edge.objects.create(
                name=self.get_primary_edge_name_rule(self.cluster_name),
                description='for wpo cluster')
            self.edge = edge

    def touch_staticrule_condition(self, request=None):
        wids = WPOWid.objects.filter(cluster=self)
        for wid in wids:
            wid.set_domain_status_and_staticrule(request=request)
            wid.touch_staging_domains_for_gslb(request=request)

    def save(self, *args, **kwargs):
        request = kwargs.pop('request', None)

        if self.pk and not self.is_modifiable():
            raise WPOAPIException(status.HTTP_400_BAD_REQUEST, "%s is not modifiable." % (str(self)))

        if not self.b_activate():
            self.config_state = 0
        else:
            self.config_state = 1

        self.touch_edge(request=request)
        super(WPOCluster, self).save(request=request)
        self.touch_staticrule_condition(request=request)

    def delete(self, *args, **kwargs):
        request = kwargs.pop('request', None)

        if self.is_deletable():
            super(WPOCluster, self).delete()
        else:
            raise WPOAPIException(status.HTTP_400_BAD_REQUEST, "%s is not deletable." % (str(self)))
        self.delete_related(request=request)

    @property
    def wpo_nodes(self):

        return [
            node.node_info for node in WPONode.objects.filter(wpo_cluster=self)
        ]


class WPONode(Model):
    node_id = models.AutoField(primary_key=True)
    wpo_cluster = models.ForeignKey(WPOCluster, db_column='wpo_cluster_id')
    node_name = models.CharField(max_length=255)
    node_type = models.PositiveSmallIntegerField(default=0, choices=WPO_NODE_TYPE)
    domain = models.ForeignKey(Domain, db_column='domain_id')
    # edge = models.ForeignKey(Edge, db_column='edge_id')  # models.PositiveIntegerField()
    vip = models.ForeignKey(Vip, db_column='vip_id')
    description = models.CharField(max_length=1024, blank=True)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    date_created = models.DateTimeField(null=True, auto_now_add=True)
    latest_updater = models.CharField(max_length=128, blank=True)
    obj_state = models.PositiveSmallIntegerField(default=1)

    def __init__(self, *args, **kwargs):
        super(WPONode, self).__init__(*args, **kwargs)

        # if wpo cluster's type is 2 (Image Converter Cluster)
        if self.wpo_cluster.wpo_location.wpo_type.wpo_type_id == 2:
            self.probe_name = IC_NODE_AGGREGATE_PROBE_NAME
        else:
            self.probe_name = AGGREGATE_PROBE_NAME

        self.node_name = '%s_node_%s' % (self.wpo_cluster.cluster_name, self.vip)

    class Meta:
        db_table = 'wpo_node'
        ordering = ['node_name']

    # noinspection PyClassHasNoInit
    class SpectrumMeta:
        allow_delete = True
        track = True

    def __unicode__(self):
        return '%s -> %s Node (%s)' % (str(self.wpo_cluster), str(WPO_NODE_TYPE[self.node_type][1]), str(self.vip))

    def get_domain(self):
        if self.node_type == 0:
            domain = self.wpo_cluster.primary_cluster_domain
        else:
            domain = self.wpo_cluster.staging_cluster_domain
        return domain

    def get_edge(self):
        if self.node_type == 0:
            edge = self.wpo_cluster.edge
        else:
            edge = self.wpo_cluster.get_staging_edge()
        return edge

    def get_aggregate_probe(self, request=None):
        try:
            probe = ProbeConfigAggregate.objects.get(name=self.probe_name)
        except ProbeConfigAggregate.DoesNotExist:
            probe = ProbeConfigAggregate(name=self.probe_name)
            probe.save(request=request)
        return probe

    def get_domain_edge(self):
        try:
            domain_edge = DomainEdge.objects.get(domain=self.wpo_cluster.primary_cluster_domain,
                                                 edge=self.wpo_cluster.edge)
        except (DomainEdge.DoesNotExist, Exception):
            domain_edge = None
        return domain_edge

    def touch_domain_edge(self, probe, prev_node=None):
        if prev_node:
            domain_edge = prev_node.get_domain_edge()
        else:
            domain_edge = self.get_domain_edge()

        if domain_edge is None:
            domain_edge = DomainEdge()

        domain_edge.domain = self.wpo_cluster.primary_cluster_domain
        domain_edge.edge = self.wpo_cluster.edge
        domain_edge.probe = probe
        domain_edge.save()

    def remove_domain_edge(self, probe):
        # do not use node delete
        if self.pk and probe and self.node_type == 0:
            domain_edge = DomainEdge.objects.filter(
                domain=self.wpo_cluster.primary_cluster_domain,
                edge=self.wpo_cluster.edge,
                probe=probe
            )
            domain_edge.delete()

    def touch_vip_probe(self, probe, request=None):
        probeconfigs = BaseProbeConfig.objects.filter(pk=probe.pk)
        self.vip.add_required_probeconfigs(request, probeconfigs)

    def remove_vip_probe(self, probe):
        if not self.pk:
            return
        try:
            if WPONode.objects.filter(vip=self.vip).exclude(pk=self.pk).exists():
                #do not delete
                return
            try:
                vipprobeconfig = VipProbeConfigs.objects.filter(vip=self.vip, probe=probe)
                vipprobeconfig.delete()
            except (Exception, ):
                pass
        except (Exception, ):
            pass

    def get_domain_vip(self, probe):
        try:
            domain_vip = DomainVip.objects.get(domain=self.wpo_cluster.staging_cluster_domain,
                                               vip=self.vip,
                                               probe=probe)
        except (DomainVip.DoesNotExist, Exception):
            domain_vip = None
        return domain_vip

    def touch_domain_vip(self, probe, prev_node=None):
        if prev_node:
            domain_vip = prev_node.get_domain_vip(probe=probe)
        else:
            domain_vip = self.get_domain_vip(probe=probe)

        if domain_vip is None:
            domain_vip = DomainVip()
        try:
            domain_vip.domain = self.wpo_cluster.staging_cluster_domain
            domain_vip.vip = self.vip
            domain_vip.probe = probe
            domain_vip.save()
        except:
            pass

    def remove_domain_vip(self, probe):
        if self.pk and self.node_type != 0:
            try:
                domain_vip = DomainVip.objects.filter(domain=self.wpo_cluster.staging_cluster_domain,
                                                      vip=self.vip,
                                                      probe=probe)
                domain_vip.delete()
            except:
                pass

    def get_vipedge(self):
        try:
            vip_edge = BaseVipEdge.objects.get(vip=self.vip, edge=self.wpo_cluster.edge)
        except (BaseVipEdge.DoesNotExist, Exception):
            vip_edge = None
        return vip_edge

    def touch_vipedge(self, prev_node=None):
        if prev_node:
            vip_edge = prev_node.get_vipedge()
        else:
            vip_edge = self.get_vipedge()

        if vip_edge is None:
            vip_edge = BaseVipEdge()

        vip_edge.vip = self.vip
        vip_edge.edge = self.wpo_cluster.edge
        vip_edge.save()

    def remove_vipedge(self):
        if self.pk and self.node_type == 0:
            try:
                vip_edge = BaseVipEdge.objects.filter(vip=self.vip, edge=self.wpo_cluster.edge)
                vip_edge.delete()
            except:
                pass

    def is_validate_vip(self):
        culster_duplicate = WPONode.objects.filter(wpo_cluster=self.wpo_cluster, vip=self.vip)
        if self.pk:
            culster_duplicate = culster_duplicate.exclude(pk=self.pk)
        if culster_duplicate.exists():
            return False, 'This IP(%s) is used in this cluster.' % self.vip

        other_node_type = [1, 0][self.node_type]
        other_node_type_duplicate = WPONode.objects.filter(vip=self.vip, node_type=other_node_type)
        if self.pk:
            other_node_type_duplicate = other_node_type_duplicate.exclude(pk=self.pk)
        if other_node_type_duplicate.exists():
            used_culster = [e.wpo_cluster.cluster_name for e in other_node_type_duplicate]

            return (
                False,
                'You cannot use this IP(%s) as %s type node. Because This IP is %s node in other cluster [%s].'
                % (self.vip, ['WPO', 'STAGING'][self.node_type], ['WPO', 'STAGING'][other_node_type], ','.join(used_culster))
            )

        return True, ''

    def get_status_display(self):
        try:
            if self.node_type == 0:
                domainvipstatus = \
                    DomainVipStatus.objects.get(domain=self.wpo_cluster.primary_cluster_domain, vip=self.vip)
            else:
                domainvipstatus = \
                    DomainVipStatus.objects.get(domain=self.wpo_cluster.staging_cluster_domain, vip=self.vip)
            return domainvipstatus.get_status_display()
        except DomainVipStatus.DoesNotExist:
            return "Unknown"

    def is_deletable(self):
        if self.node_type == 0 and self.wpo_cluster.get_wpo_node_count() <= 1:
            #delete wpo_node and wpo_node_count <= 1
            if WPOWid.objects.filter(Q(cluster=self.wpo_cluster) | Q(backup_cluster=self.wpo_cluster)).exists():
                return False

        if self.node_type == 1 and self.wpo_cluster.get_staging_node_count() <= 1:
            #delete staging_node and staging_node_count <= 1
            if WPOWid.objects.filter(Q(cluster=self.wpo_cluster) | Q(backup_cluster=self.wpo_cluster)).exists():
                return False

        return True

    def get_related_objects(self):
        pass

    def delete_related(self, request=None):
        probe = self.get_aggregate_probe(request=request)
        self.remove_vipedge()
        self.remove_domain_vip(probe=probe)
        self.remove_vip_probe(probe=probe)

    def is_modifiable(self):
        return True

    def save(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        if self.pk and not self.is_modifiable():
            raise Exception("%s is not modifiable." % (str(self)))

        is_valid, error_message = self.is_validate_vip()
        if not is_valid:
            raise WPOAPIException(status.HTTP_400_BAD_REQUEST, error_message)

        prev_node = None
        if self.pk:
            prev_node = WPONode.objects.get(pk=self.pk)
        probe = self.get_aggregate_probe(request=request)

        if prev_node:
            prev_node.remove_vip_probe(probe=probe)
            if self.node_type != prev_node.node_type:
                prev_node.remove_vipedge()
                prev_node.remove_domain_vip(probe=probe)

        if str(self.node_type) == str(WPO_NODE_TYPE[0][0]):
            self.touch_domain_edge(probe=probe, prev_node=prev_node)
            self.touch_vipedge(prev_node=prev_node)
        else:
            self.touch_domain_vip(probe=probe, prev_node=prev_node)

        self.touch_vip_probe(probe=probe, request=request)

        super(WPONode, self).save(request=request)

    def delete(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        self.delete_related(request=request)
        if self.is_deletable():
            super(WPONode, self).delete()
        else:
            raise WPOAPIException(status.HTTP_400_BAD_REQUEST, "%s is not deletable." % (str(self)))

    @property
    def node_status(self):
        return self.get_status_display()

    @property
    def ic_config_revision(self):

        cic_node_status = CicNodeStatus.objects.filter(node_id=self.node_id)

        if cic_node_status.exists():
            # returns latest object (CicNodeStatus is ordered by '-start_time')
            return cic_node_status[0]

        # if not exists,
        # then returns CicNodeStatus with both revision number is -1. (error)
        return CicNodeStatus(node_id=self.node_id, base_version=-1, config_version=-1)

    @property
    def ic_status(self):
        ''' Get IC node's probe value to check application status.
        '''

        try:

            rms_message = RMSMessage.objects.get(
                vip__ip=self.vip.get_ipaddr(),
                vip_probe__name=IC_APP_AGGREGATE_PROBE_NAME)

            message_value = get_translated_rms_message(rms_message.val)

        except RMSMessage.DoesNotExist:

            message_value = 'probe not found'

        return message_value

    @property
    def node_info(self):

        ''' Returns WPO Node list which belongs to this cluster (self).
            For IC Monitoring Page.
        '''

        cic_node_revision = self.ic_config_revision
        vip = self.vip

        return {
            'node_id': self.node_id,
            'node_name': self.node_name,
            'node_type': self.node_type,
            'ic_status': self.ic_status,
            'node_status': self.node_status,
            'ip_address': vip.get_ipaddr(),
            'hostname': vip.host.get_fullhostname(),
            'base_version': cic_node_revision.base_version,
            'config_version': cic_node_revision.config_version
        }


class WPOCode(Model):
    code_id = models.AutoField(primary_key=True)
    code_name = models.CharField(max_length=128, db_column='wpo_code_name')
    code_value = models.CharField(max_length=128, db_column='wpo_code_value')
    code_alias = models.CharField(max_length=128, db_column='wpo_code_alias')
    parent_wpo_code = models.PositiveIntegerField()
    sort_order = models.PositiveSmallIntegerField()
    mapping_rule = models.CharField(max_length=4096, blank=True)
    staging_mapping_rule = models.CharField(max_length=4096, blank=True)
    https_mapping_rule = models.CharField(max_length=4096, blank=True)
    staging_https_mapping_rule = models.CharField(max_length=4096, blank=True)
    mapping_keywords = models.CharField(max_length=1024, blank=True)
    description = models.CharField(max_length=1024, blank=True)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    date_created = models.DateTimeField(null=True, auto_now_add=True)
    latest_updater = models.CharField(max_length=128, blank=True)
    obj_state = models.PositiveSmallIntegerField(default=1)

    class Meta:
        db_table = 'wpo_codes'
        ordering = ['code_alias', 'sort_order']

    # noinspection PyClassHasNoInit
    class SpectrumMeta:
        allow_delete = True
        track = True

    def __unicode__(self):
        return self.code_name

    def is_deletable(self):
        return True

    def get_related_objects(self):
        pass

    def delete_related(self, request=None):
        pass

    def is_modifiable(self):
        return True

    def save(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        if self.pk and not self.is_modifiable():
            raise WPOAPIException(status.HTTP_400_BAD_REQUEST, "%s is not modifiable." % (str(self)))

        super(WPOCode, self).save(request=request)

    def delete(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        self.delete_related(request=request)
        if self.is_deletable():
            super(WPOCode, self).delete()
        else:
            raise WPOAPIException(status.HTTP_400_BAD_REQUEST, "%s is not deletable." % (str(self)))


protocol_choices = (
    ('http', 'http'),
    ('https', 'https'),
    ('both', 'both'),
)


class WPOWid(BaseModel):
    wid_id = models.AutoField(primary_key=True)
    wid_name = models.CharField(max_length=128, db_column='wid_name')
    customer = models.ForeignKey(CustomerDisplay, db_column='customer_id')
    host_domain = models.ForeignKey(Domain, db_column='wpo_host_domain_id', null=True)
    staging_host_domain = models.ForeignKey(Domain, db_column='wpo_staging_host_domain_id', null=True)
    backup_host_domain = models.ForeignKey(Domain, db_column='wpo_host_backup_domain_id', null=True)
    location = models.ForeignKey(WPOLocation, db_column='location_id')
    cluster = models.ForeignKey(WPOCluster, db_column='wpo_cluster_id', null=True)
    backup_cluster = models.ForeignKey(WPOCluster, db_column='wpo_backup_cluster_id', blank=True, null=True)
    generate_gslb = models.PositiveSmallIntegerField(default=1, db_column='')
    generate_backup = models.PositiveSmallIntegerField(default=1, db_column='generate_backup_enabled')
    rule_optimization_enabled = models.PositiveSmallIntegerField(default=1, db_column='optimization_rule_enabled')
    optimization_rule_text = models.CharField(db_column='optimization_rule_text')
    staging_optimization_rule_text = models.CharField(db_column='staging_optimization_rule_text')

    status_code = models.PositiveSmallIntegerField(default=0)
    description = models.CharField(max_length=1024, blank=True)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    time_deployed = models.DateTimeField(null=True)
    date_created = models.DateTimeField(null=True, auto_now_add=True)
    latest_updater = models.CharField(max_length=128, blank=True)
    obj_state = models.PositiveSmallIntegerField(default=1)

    wpo_type = models.ForeignKey(WPOType, db_column='wpo_type_id')
    domain_protocol = models.CharField(max_length=20, default='http', choices=protocol_choices)

    class Meta:
        db_table = 'wpo_wid'
        ordering = ['wid_name']

    def __unicode__(self):
        return self.wid_name

    # noinspection PyClassHasNoInit
    class SpectrumMeta:
        track = True

    def get_host_domain_name(self):
        try:
            return self.host_domain.name
        except (Domain.DoesNotExist, Exception):
            return ''

    def get_backup_host_domain_name(self):
        try:
            return self.backup_host_domain.name
        except (Domain.DoesNotExist, Exception):
            return ''

    def get_staging_host_domain_name(self):
        try:
            return self.staging_host_domain.name
        except (Domain.DoesNotExist, Exception):
            return ''

    @staticmethod
    def _get_parent_rule_text(parent_code):
        try:
            code = WPOCode.objects.get(pk=parent_code)
            return code.code_name
        except WPORule.DoesNotExist:
            return ''

    def _get_common_parameter_rule_text(self, is_staging=False, domain_protocol='http'):
        cdomains = self.wpocustomerdomain_set.all()
        main_domain_name = ''
        for cdomain in cdomains:
            if cdomain.wpo_domain_type == 0:
                main_domain_name = cdomain.customer_domain_name

        cache_fragment_name = main_domain_name.replace('.', '_')
        try:
            if self.wpo_type_id == WPO_TYPE_FEO[0]:
                wpo_code = WPOCode.objects.get(code_name='common_parameter')
            else:
                wpo_code = WPOCode.objects.get(code_name='ic_common_parameter')
            if is_staging:
                if domain_protocol == 'http':
                    mapping_rule = wpo_code.staging_mapping_rule
                else:
                    mapping_rule = wpo_code.staging_https_mapping_rule
            else:
                if domain_protocol == 'http':
                    mapping_rule = wpo_code.mapping_rule
                else:
                    mapping_rule = wpo_code.https_mapping_rule
            if self.rule_optimization_enabled == 1:
                ret_str = mapping_rule.replace('iconoff', 'On')
                ret_str = ret_str.replace('onoff', 'On')
            else:
                ret_str = mapping_rule.replace('iconoff', 'Off')
                ret_str = ret_str.replace('onoff', 'unplugged')

            ret_str = ret_str.replace('MAIN_DOMAIN_NAME', main_domain_name)
            ret_str = ret_str.replace('CACHE_FRAGMENT_NAME', cache_fragment_name)

            return ret_str
        except WPOCode.DoesNotExist:
            return ''

    def _get_staging_common_parameter_rule_text(self, domain_protocol='http'):
        return self._get_common_parameter_rule_text(is_staging=True, domain_protocol=domain_protocol)

    def generate_rule_text(self):
        rule_list = []
        if self.domain_protocol == 'http':
            rule_list.append(self._create_virtual_host_conf())
        elif self.domain_protocol == 'https':
            rule_list.append(self._create_virtual_host_conf(domain_protocol='https'))
        else:
            rule_list.append(self._create_virtual_host_conf())
            rule_list.append('')
            rule_list.append('')
            rule_list.append(self._create_virtual_host_conf(domain_protocol='https'))

        return "\n".join(rule_list)

    def generate_staging_rule_text(self):
        rule_list = []
        if self.domain_protocol == 'http':
            rule_list.append(self._create_virtual_host_conf(is_staging=True))
        elif self.domain_protocol == 'https':
            rule_list.append(self._create_virtual_host_conf(is_staging=True, domain_protocol='https'))
        else:
            rule_list.append(self._create_virtual_host_conf(is_staging=True))
            rule_list.append('')
            rule_list.append('')
            rule_list.append(self._create_virtual_host_conf(is_staging=True, domain_protocol='https'))

        return "\n".join(rule_list)

    def _create_virtual_host_conf(self, is_staging=False, domain_protocol='http'):
        if is_staging:
            common_rule_text = self._get_staging_common_parameter_rule_text(domain_protocol=domain_protocol)
        else:
            common_rule_text = self._get_common_parameter_rule_text(domain_protocol=domain_protocol)

        virtual_host_conf = """
<VirtualHost *:#port#>
#common_rule_text#
ModPagespeedDomainSupportProtocol #domain_protocol#

# customer_domains

#ruletext_of_wpo_customer_domains#

# rules
#ruletext_of_wpo_rule#

</VirtualHost>
"""

        # port
        port = '80' if domain_protocol == 'http' else '443'

        # customer_domains
        wpo_customer_domains = WPOCustomerDomain.objects.filter(wid=self)
        domain_rule_list = []
        for wpo_customer_domain in wpo_customer_domains:
            domain_rule_list.append(wpo_customer_domain.generate_rule_text(domain_protocol=domain_protocol))

        # wpo_rules
        wpo_rules = WPORule.objects.filter(wid=self).order_by('wpo_code__parent_wpo_code')
        wpo_rule_list = []
        cur_parent_code = 0
        for wpo_rule in wpo_rules:
            if not wpo_rule.wpo_code:
                wpo_rule.wpo_code = WPOCode.objects.get(code_name=wpo_rule.rule_name)
            this_parent_code = wpo_rule.wpo_code.parent_wpo_code

            wpo_rule_list.append('')
            if this_parent_code != cur_parent_code:
                prtext = self._get_parent_rule_text(parent_code=this_parent_code)
                wpo_rule_list.append('# %s' % prtext)

            rule_text = wpo_rule.generate_rule_text(domain_protocol=domain_protocol)
            wpo_rule_list.append(rule_text)
            cur_parent_code = this_parent_code

        # replace rules
        virtual_host_conf = virtual_host_conf.replace('#port#', port)
        virtual_host_conf = virtual_host_conf.replace('#common_rule_text#', common_rule_text)
        virtual_host_conf = virtual_host_conf.replace('#domain_protocol#', self.domain_protocol)
        virtual_host_conf = virtual_host_conf.replace('#ruletext_of_wpo_customer_domains#', '\n'.join(domain_rule_list))
        virtual_host_conf = virtual_host_conf.replace('#ruletext_of_wpo_rule#', '\n'.join(wpo_rule_list))

        return virtual_host_conf

    def set_domain_status_and_staticrule(self, request):
        self._set_domain_status_and_staticrule(domain=self.host_domain,
                                               cluster_domain=self.cluster.primary_cluster_domain,
                                               request=request)

        try:
            if self.backup_cluster and self.backup_host_domain:
                self._set_domain_status_and_staticrule(domain=self.backup_host_domain,
                                                       cluster_domain=self.backup_cluster.primary_cluster_domain,
                                                       request=request)
        except ObjectDoesNotExist:
            pass

    def touch_staging_domains_for_gslb(self, request):
        domains = self.wpocustomerdomain_set.all()
        if not domains.exists():
            return

        for domain in domains:
            # if not exist staging_domain, create new instance.
            try:
                gslb_domain = domain.staging_domain
                if not gslb_domain:
                    gslb_domain = Domain()
            except Domain.DoesNotExist:
                gslb_domain = Domain()

            # rewrite_domain, use other cdn pass this loop
            if domain.wpo_domain_type == 2 and domain.use_cdnw_cdn == 0:
                if gslb_domain.pk:
                    gslb_domain.delete(request=request)
                    domain.staging_domain = None
                    domain.save(request=request)
                continue

            # update or create staging_domain.
            # if error(duplicate, ) occured, send error message.
            try:
                gslb_domain.name = '%s%s%s' % (
                    WID_DOMAIN_PREFIX_FOR_TYPE[self.wpo_type_id],
                    domain.customer_domain_name,
                    WID_DOMAIN_SUFFIX_FOR_TYPE[self.wpo_type_id]
                )
                gslb_domain.domain_type = 6
                gslb_domain.save(request=request)
                domain.staging_domain = gslb_domain
                domain.save(request=request)
                self._set_domain_status_and_staticrule(domain=gslb_domain,
                                                       cluster_domain=self.cluster.staging_cluster_domain,
                                                       request=request)
            except Exception, e:
                raise WPOAPIException(status.HTTP_500_INTERNAL_SERVER_ERROR, str(e))

    def _set_domain_status_and_staticrule(self, domain, cluster_domain, request):
        if domain:
            domain.customer = self.customer
            domain.cutoff = 0
            domain.domain_type = WPO_DOMAIN
            domain.update_domain_config_status(request=request)
            if not self.pk:
                domain.create_or_replace_cname_static_rule(cluster_domain, request)

    def get_related_items(self):
        return WPOWidItems.objects.filter(wid=self)

    def get_related_rules(self):
        return WPORule.objects.filter(wid=self)

    def get_related_domains(self):
        return WPOCustomerDomain.objects.filter(wid=self)

    def is_deletable(self):
        if self.status_code == 0:
            return True
        return False

    def get_related_objects(self):
        pass

    # noinspection PyBroadException
    def delete_related(self, request=None):
        try:
            customer_domains = self.wpocustomerdomain_set.all()
            for customer_domain in customer_domains:
                customer_domain.delete()
            self.wporule_set.all().delete()
            self.wpowiditems_set.all().delete()

            try:
                if self.backup_host_domain:
                    self.backup_host_domain.delete(request=request)
                if self.host_domain:
                    self.host_domain.delete(request=request)
                if self.staging_host_domain:
                    self.staging_host_domain.delete(request=request)
            except:
                pass
        except:
            transaction.rollback()

    def is_modifiable(self):
        if not (self.status_code == 1 or self.status_code == 3):
            return True
        return False

    def get_timeout(self):
        right_now = datetime.now()
        date_modified = self.date_modified
        if settings.DEBUG:
            time2compare = timedelta(minutes=DEV_LOCK_TIMEOUT)
        else:
            time2compare = timedelta(minutes=TIMEOUT)
        timeout = False
        if (right_now - date_modified) > time2compare:
            timeout = True
        return timeout

    def get_staging_push_type(self):
        return WPO_JOINT_PUSH_NAME if self.wpo_type_id == WPO_TYPE_FEO[0] else CIC_JOINT_PUSH_NAME

    def push_to_staging(self, request=None):
        if self.status_code != 0 and self.status_code != -2:
            raise WPOAPIException(
                status.HTTP_400_BAD_REQUEST,
                '%s is not in (new, modified, pending falied) status, cannot push to stage.' % str(self))
        wids = WPOWid.objects.filter(pk=self.pk)
        wids.update(status_code=1)

        try:
            config_joint_name = self.get_staging_push_type()
            config_joint = ConfigJoint.objects.get(config_joint_name=config_joint_name)
            joint_push(request, config_joint.config_joint_id)
        except ConfigJoint.DoesNotExist:
            raise WPOAPIException(
                status.HTTP_500_INTERNAL_SERVER_ERROR, 'There is no joint push configuration')
        except ConfigJoint.MultipleObjectsReturned:
            raise WPOAPIException(
                status.HTTP_500_INTERNAL_SERVER_ERROR, 'Joint push configuration duplicated.')
        except ConfigAPIException, cae:
            raise WPOAPIException(status_code=cae.status_code, detail=cae.detail)
        except Exception:
            raise WPOAPIException(status.HTTP_500_INTERNAL_SERVER_ERROR, 'Unknown error.')

    def push_to_production(self, request=None):
        if self.status_code != 2 and self.status_code != -4:
            raise WPOAPIException(
                status.HTTP_400_BAD_REQUEST,
                '%s is not stage status, cannot push to production.' % str(self))
        wids = WPOWid.objects.filter(pk=self.pk)
        wids.update(status_code=3)
        result = config_push(request=request,
                             config_group_id=self.location.config_phase.config_type.config_group.pk,
                             config_type_id=self.location.config_phase.config_type.pk,
                             action_keyword="",
                             desc="")
        if result['status_code'] != status.HTTP_200_OK:
            raise WPOAPIException(result['status_code'], result['detail'])

    def save_to_snapshot(self, request=None):
        wid = WPOWid.objects.get(pk=self.pk)
        data = serializers.serialize('json', [wid])
        data_obj = json.loads(data)
        fields = data_obj[0]['fields']
        fields['host_domain_name'] = ''
        if wid.host_domain and 'host_domain' in fields:
            fields['host_domain_name'] = wid.host_domain.name
        fields['backup_host_domain_name'] = ''
        if wid.backup_host_domain and 'backup_host_domain' in fields:
            fields['backup_host_domain_name'] = wid.backup_host_domain.name
        fields['staging_host_domain_name'] = ''
        if wid.staging_host_domain and 'staging_host_domain' in fields:
            fields['staging_host_domain_name'] = wid.staging_host_domain.name
        data_obj[0]['fields'] = fields
        data = json.dumps(data_obj)

        try:
            snapshot = ProductionSnapshot.objects.get(
                snapshot_model=unicode(WPOWid.__name__),
                model_pk=wid.pk
            )
        except ProductionSnapshot.DoesNotExist:
            snapshot = ProductionSnapshot(
                snapshot_model=unicode(WPOWid.__name__),
                model_pk=wid.pk
            )
        except ProductionSnapshot.MultipleObjectsReturned:
            snapshot = ProductionSnapshot(
                snapshot_model=unicode(WPOWid.__name__),
                model_pk=wid.pk
            )
            ProductionSnapshot.objects.filter(
                snapshot_model=unicode(WPOWid.__name__),
                model_pk=wid.pk
            ).delete()

        snapshot.username = request.enduser.username
        snapshot.user_ip = request.enduser.ip
        snapshot.snapshot_obj = data
        snapshot.snapshot_model = unicode(WPOWid.__name__)
        snapshot.model_pk = wid.pk
        snapshot.obj_state = 1
        snapshot.save()

        self._save_item_snapshot(request=request)
        self._save_rule_snapshot(request=request)
        self._save_cdomain_snapshot(request=request)

    def _save_item_snapshot(self, request=None):
        ProductionSnapshot.objects.filter(
            snapshot_model=unicode(WPOWidItems.__name__),
            parent_model=unicode(WPOWid.__name__),
            parent_model_pk=self.pk
        ).delete()

        items = self.get_related_items()
        for item in items:
            item.save_to_snapshot(request=request)

    def _save_rule_snapshot(self, request=None):

        ProductionSnapshot.objects.filter(
            snapshot_model=unicode(WPORule.__name__),
            parent_model=unicode(WPOWid.__name__),
            parent_model_pk=self.pk
        ).delete()

        rules = self.get_related_rules()
        for rule in rules:
            rule.save_to_snapshot(request=request)
            if rule.wpo_code.pk == WPO_SHARD_DOMAIN_CODE_ID:
                rule.save_shard_snapshot(request=request)

    def _save_cdomain_snapshot(self, request=None):
        ProductionSnapshot.objects.filter(
            snapshot_model=unicode(WPOCustomerDomain.__name__),
            parent_model=unicode(WPOWid.__name__),
            parent_model_pk=self.pk
        ).delete()

        cdomains = self.get_related_domains()
        for cd in cdomains:
            cd.save_to_snapshot(request=request)

    def _touch_host_domain_for_rollback(self, p_request, snapshot, snapshot_domains):
        def __remove_host_domain(current_wid, domain_gubun=0):
            """
            :param domain_gubun: 0: host_domain, 1: backup_host_domain, 2: staging_host_domain
            :return:
            """
            target_domain = [
                current_wid.host_domain,
                current_wid.backup_host_domain,
                current_wid.staging_host_domain][domain_gubun]

            try:
                target_domain.delete()
            except (Domain.DoesNotExist, Exception):
                pass

        def __save_host_domain(wid, _snapshot_domain, domain_gubun=0):
            """
            :param domain_gubun: 0: host_domain, 1: backup_host_domain, 2: staging_host_domain
            :return:
            """
            current_host_domain_name = [
                self.get_host_domain_name(),
                self.get_backup_host_domain_name(),
                self.get_staging_host_domain_name()][domain_gubun]

            current_object = [
                wid.host_domain, wid.backup_host_domain, wid.staging_host_domain
            ][domain_gubun]

            if current_host_domain_name:
                current_object.name = _snapshot_domain
                current_object.save(request=p_request)
                return current_object
            else:
                return Domain(name=_snapshot_domain).save(request=p_request)

        """
        :param request:
        :param snapshot:
        :param snapshot_domains:
        """
        snapshot_host_domain_name = snapshot_domains[0]
        snapshot_backup_host_domain_name = snapshot_domains[1]
        snapshot_staging_host_domain_name = snapshot_domains[2]
        if snapshot_host_domain_name:
            snapshot.host_domain = __save_host_domain(self, snapshot_host_domain_name)
        else:
            __remove_host_domain(self)
            snapshot.host_domain = None

        if snapshot_backup_host_domain_name:
            snapshot.host_domain = __save_host_domain(self, snapshot_backup_host_domain_name, domain_gubun=1)
        else:
            __remove_host_domain(self, domain_gubun=1)
            snapshot.backup_host_domain = None

        if snapshot_staging_host_domain_name:
            snapshot.host_domain = __save_host_domain(self, snapshot_staging_host_domain_name, domain_gubun=2)
        else:
            __remove_host_domain(self, domain_gubun=2)
            snapshot.staging_host_domain = None

        snapshot.save(request=p_request, b_rollback=True)

    def rollback_from_snapshot(self, request=None):
        snapshot = ProductionSnapshot.objects.filter(
            model_pk=self.pk,
            snapshot_model=unicode(WPOWid.__name__)
        ).order_by('id')[:1]
        if snapshot.exists():
            snapshot_json_obj = json.loads(snapshot[0].snapshot_obj)
            host_domain_name = snapshot_json_obj[0]['fields'].pop('host_domain_name')
            backup_host_domain_name = snapshot_json_obj[0]['fields'].pop('backup_host_domain_name')
            staging_host_domain_name = snapshot_json_obj[0]['fields'].pop('staging_host_domain_name')

            snapshot_obj = json.dumps(snapshot_json_obj)
            for obj in serializers.deserialize('json', snapshot_obj):
                self._touch_host_domain_for_rollback(
                    p_request=request,
                    snapshot=obj.object,
                    snapshot_domains=(host_domain_name, backup_host_domain_name, staging_host_domain_name))

                #obj.object.save(request=request, b_rollback=True)
        else:
            raise WPOAPIException(status.HTTP_400_BAD_REQUEST, "There is no backup data.")

        self._rollback_item_snapshot(request=request)
        self._rollback_rule_snapshot(request=request)
        self._rollback_cdomain_snapshot(request=request)

    def _rollback_item_snapshot(self, request=None):
        WPOWidItems.objects.filter(wid=self.pk).delete()
        item_snapshots = ProductionSnapshot.objects.filter(
            snapshot_model=unicode(WPOWidItems.__name__),
            parent_model=unicode(WPOWid.__name__),
            parent_model_pk=self.pk)

        for item_snapshot in item_snapshots:
            for obj in serializers.deserialize('json', item_snapshot.snapshot_obj):
                obj.object.save(request=request)

    def _rollback_rule_snapshot(self, request=None):
        WPORule.objects.filter(wid=self.pk).delete()
        rule_snapshots = ProductionSnapshot.objects.filter(
            snapshot_model=unicode(WPORule.__name__),
            parent_model=unicode(WPOWid.__name__),
            parent_model_pk=self.pk)

        for rule_snapshot in rule_snapshots:
            for obj in serializers.deserialize('json', rule_snapshot.snapshot_obj):
                # WPORule
                obj.object.save(request=request)
                if obj.object.wpo_code.pk == WPO_SHARD_DOMAIN_CODE_ID:
                    obj.object.rollback_shard_snapshot(request=request)

    def _rollback_cdomain_snapshot(self, request=None):
        cdomains = WPOCustomerDomain.objects.filter(wid=self.pk)
        for cdomain in cdomains:
            cdomain.delete(request=request)
        cdomain_snapshots = ProductionSnapshot.objects.filter(
            snapshot_model=unicode(WPOCustomerDomain.__name__),
            parent_model=unicode(WPOWid.__name__),
            parent_model_pk=self.pk)

        for cdomain_snapshot in cdomain_snapshots:
            for obj in serializers.deserialize('json', cdomain_snapshot.snapshot_obj):
                # WPOCustomerDomain
                obj.object.staging_domain = None
                obj.object.save(request=request)

    def get_items(self):
        if self.pk:
            return self.wpowiditems_set.all()
        return []

    def save(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        b_rollback = kwargs.pop('b_rollback', None)
        self.b_rollback = kwargs.pop('b_rollback', None)
        self.latest_updater = request.enduser.username

        if not self.is_modifiable():
            raise WPOAPIException(status.HTTP_400_BAD_REQUEST, "%s is in pending status and not modifiable." % (str(self)))

        if self.status_code == 4 and not b_rollback:
            self.save_to_snapshot(request)

        if not b_rollback:
            self.status_code = 0
        if self.cluster:
            self.set_domain_status_and_staticrule(request=request)

        super(WPOWid, self).save(request=request)

    def delete(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        self.delete_related(request=request)
        if self.is_deletable():

            WPOWid.objects.filter(pk=self.pk).update(
                obj_state=0,
                cluster=None,
                host_domain=None,
                backup_host_domain=None,
                staging_host_domain=None
            )
        else:
            raise WPOAPIException(
                status.HTTP_400_BAD_REQUEST,
                "%s is not deletable, because it is not in [new/modified] status." % (str(self)))


class WPOWidItems(BaseModel):
    id = models.AutoField(primary_key=True)
    wid = models.ForeignKey(WPOWid, db_column='wid_id')
    item = models.ForeignKey(CustomerItem, db_column='item_id')

    class Meta:
        db_table = 'wpo_wid_items'
        ordering = ['wid']

    def save_to_snapshot(self, request=None):
        try:
            item = WPOWidItems.objects.get(pk=self.pk)
            data = serializers.serialize('json', [item])
            ProductionSnapshot.objects.create(
                username=request.enduser.username,
                snapshot_obj=data,
                user_ip=request.enduser.ip,
                snapshot_model=unicode(WPOWidItems.__name__),
                model_pk=item.pk,
                obj_state=1,
                parent_model=unicode(WPOWid.__name__),
                parent_model_pk=self.wid.pk
            )
        except WPOWidItems.DoesNotExist:
            pass

    def save(self, *args, **kwargs):
        if not WPOWidItems.objects.filter(wid=self.wid_id, item=self.item_id).exists():
            super(WPOWidItems, self).save()


class WPORule(Model):
    rule_id = models.AutoField(primary_key=True)
    wid = models.ForeignKey(WPOWid, db_column='wid_id')
    wpo_code = models.ForeignKey(WPOCode, db_column='wpo_code_id', blank=True, null=True)
    rule_name = models.CharField(max_length=128, db_column='rule_name')
    rule_value = models.CharField(max_length=1024, db_column='rule_value', blank=True)
    rule_text = models.CharField(db_column='rule_text')
    staging_rule_text = models.CharField(db_column='staging_rule_text')
    description = models.CharField(max_length=1024, blank=True)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    date_created = models.DateTimeField(null=True, auto_now_add=True)
    latest_updater = models.CharField(max_length=128, blank=True)
    obj_state = models.PositiveSmallIntegerField(default=1)

    class Meta:
        db_table = 'wpo_rules'
        ordering = ['rule_name']

    # noinspection PyClassHasNoInit
    class SpectrumMeta:
        allow_delete = True
        track = True

    def __init__(self, *args, **kwargs):
        super(WPORule, self).__init__(*args, **kwargs)
        if not self.wpo_code and self.rule_name:
            self.wpo_code = WPOCode.objects.get(code_name=self.rule_name)

    def __unicode__(self):
        return "%s >> %s" % (str(self.wid), self.rule_name)

    def manage_gslb_domain_when_a_rule_is_domain_sharding(self, request=None):
        try:
            if self.wpo_code_id == WPO_SHARD_DOMAIN_CODE_ID:  # Check if this rule is domain sharding.
                sharding_domains = WPODomainSharding.objects.filter(rule=self)
                gslb_domains = Domain.objects.filter(domain_id__in=[obj.gslb_domain.pk for obj in sharding_domains])
                to_shard_domain_string = self.rule_value.split(",")[2]
                to_shard_domains = []

                for domain in to_shard_domain_string.split("\n"):
                    # Attach prefix and suffix string.
                    to_shard_domains.append(
                        WID_DOMAIN_PREFIX_FOR_TYPE[self.wid.wpo_type_id] +
                        domain +
                        WID_DOMAIN_SUFFIX_FOR_TYPE[self.wid.wpo_type_id])

                for gslb_domain in gslb_domains:
                    if gslb_domain.name not in to_shard_domains:  # delete gslb domain for domain sharding
                        WPODomainSharding.objects.filter(gslb_domain=gslb_domain).delete()
                        gslb_domain.delete(request=request)
                    try:
                        to_shard_domains.remove(gslb_domain.name)
                    except ValueError:
                        pass

                for new_domain_name in to_shard_domains:  # add new gslb domain for domain sharding
                    new_gslb_domain = Domain(name=new_domain_name)
                    new_gslb_domain.domain_type = WPO_DOMAIN
                    new_gslb_domain.save(request=request)
                    new_shard_map = WPODomainSharding(gslb_domain=new_gslb_domain, rule=self)
                    new_shard_map.save()
        except Exception as e:
            raise e

    def delete_related_shard_domains(self, request=None):
        try:
            sharding_domains = WPODomainSharding.objects.filter(rule=self)
            gslb_domains = Domain.objects.filter(domain_id__in=[obj.gslb_domain.pk for obj in sharding_domains])
            sharding_domains.delete()
            for domain in gslb_domains:
                domain.delete(request=request)
        except Exception as e:
            raise e

    def _generate_rule_text_domain_sharding(self, b_staging=False, domain_protocol='http', request=None):
        rule_list = []

        domain_string = ('\n'
                         'ServerAlias SHARD_DOMAIN_NAME\n'
                         'RewriteCond %{HTTP_HOST} ^SHARD_DOMAIN_NAME$ [NC]\n'
                         'RewriteRule ^/(.*)  http://ORIGIN_DOMAIN_NAME/$1 [P,L]\n'
                         '        ')

        mode_string = 'ModPagespeedShardDomain SHARD_FROM_DOMAIN #SHARD_DOMAINS#'

        if domain_protocol == 'https':
            domain_string = ('\n'
                             'ServerAlias SHARD_DOMAIN_NAME\n'
                             'RewriteCond %{HTTP_HOST} ^SHARD_DOMAIN_NAME$ [NC]\n'
                             'RewriteRule ^/(.*)  https://ORIGIN_DOMAIN_NAME/$1 [P,L]\n'
                             '        ')

            mode_string = 'ModPagespeedShardDomain https://SHARD_FROM_DOMAIN #SHARD_DOMAINS#'
        try:
            original_domain, from_domain, shard_domains = self.rule_value.split(',')
            if not original_domain or not from_domain or not shard_domains:
                raise WPOAPICustomException({'domain_sharding': ['There is empty input.']})
            domain_string = domain_string.replace('ORIGIN_DOMAIN_NAME', original_domain)

            shard_domain_list = []
            for shard_domain in shard_domains.split('\n'):
                if b_staging:
                    shard_domain_str = '%s%s%s' % (WID_DOMAIN_PREFIX_FOR_TYPE[self.wid.wpo_type_id],
                                                   shard_domain,
                                                   WID_DOMAIN_SUFFIX_FOR_TYPE[self.wid.wpo_type_id])

                else:
                    shard_domain_str = shard_domain
                if domain_protocol == 'https':
                    shard_domain_str = 'https://' + shard_domain_str
                rule_list.append(
                    domain_string.replace('SHARD_DOMAIN_NAME', shard_domain_str)
                )
                shard_domain_list.append(shard_domain_str)
            if b_staging:
                from_domain_str = '%s%s%s' % (WID_DOMAIN_PREFIX_FOR_TYPE[self.wid.wpo_type_id],
                                              from_domain,
                                              WID_DOMAIN_SUFFIX_FOR_TYPE[self.wid.wpo_type_id])
            else:
                from_domain_str = from_domain
            mode_string = mode_string.replace('#SHARD_DOMAINS#', ','.join(shard_domain_list))
            mode_string = mode_string.replace('SHARD_FROM_DOMAIN', from_domain_str)
            rule_list.append(mode_string)
            return "\n".join(rule_list)

        except ValueError:
            return ''

    @staticmethod
    def rule_digit_validation(rule_name, value):
        try:
            value = int(value)
            if value < 1:
                raise Exception
        except Exception:
            raise WPOAPICustomException({rule_name: ['byte value must >= 1']})

    @staticmethod
    def rule_quality_validation(rule_name, value):
        try:
            value = int(value)
            if value != -1 and (value < 1 or value > 100):
                raise Exception
        except Exception:
            raise WPOAPICustomException({rule_name: ['quality value must 1~100 or -1']})

    @staticmethod
    def rule_value_validation(rule_name, rule_values_string=''):
        try:
            wpo_code = WPOCode.objects.get(code_name=rule_name)
            mapping_keyword = wpo_code.mapping_keywords
            if rule_name in ['domain_sharding', 'extra_option', 'ic_command']:
                if rule_values_string == '' or rule_values_string.replace(',', ' ').isspace():
                    raise WPOAPICustomException({rule_name: ['Need input or default value.']})
                else:
                    return True

            if mapping_keyword == '':
                return True

            rule_values = []
            if rule_values_string:
                rule_values = rule_values_string.split(',')
            code_values = []
            if wpo_code.code_value:
                code_values = wpo_code.code_value.split(',')
            if rule_values_string == '' or rule_values_string.replace(',', ' ').isspace():
                rule_values = code_values

            if len(rule_values) == 0 or len(rule_values) != len(code_values):
                raise WPOAPICustomException({rule_name: ['Need input or default value.']})

            for i, rule_value in enumerate(rule_values):
                if mapping_keyword.find('digit') >= 0:
                    WPORule.rule_digit_validation(rule_name=rule_name, value=rule_value)
                elif mapping_keyword.find('quality') >= 0:
                    WPORule.rule_quality_validation(rule_name=rule_name, value=rule_value)

        except WPOCode.DoesNotExist:
            raise WPOAPICustomException({rule_name: ['there is no wpo_code_name.']})

    def generate_rule_text(self, request=None, domain_protocol='http'):
        if self.rule_name in ['extra_option', 'ic_command']:
            return self.rule_value
        if self.rule_name == 'domain_sharding':
            return self._generate_rule_text_domain_sharding(request=request, domain_protocol=domain_protocol)

        template_code_values = self.wpo_code.code_value.split(",")
        template_mapping_keywords = self.wpo_code.mapping_keywords.split(",")

        if self.rule_value and not self.rule_value.replace(',', ' ').isspace():
            rule_values = self.rule_value.split(",")
        else:
            self.rule_value = self.wpo_code.code_value
            rule_values = self.wpo_code.code_value.split(",")

        rule_text = self.wpo_code.mapping_rule
        if len(template_code_values) > 0:  # simple replace
            for i, mapping_keyword in enumerate(template_mapping_keywords):
                if mapping_keyword != '':
                    rule_text = rule_text.replace(mapping_keyword, rule_values[i], 1)
        else:  # nothing to replace
            pass

        return rule_text

    def generate_staging_rule_text(self, request=None):
        if self.rule_name in ['extra_option', 'ic_command']:
            return self.rule_value
        if self.rule_name == 'domain_sharding':
            return self._generate_rule_text_domain_sharding(b_staging=True, request=request)

        template_code_values = self.wpo_code.code_value.split(",")
        template_mapping_keywords = self.wpo_code.mapping_keywords.split(",")

        if self.rule_value:
            rule_values = self.rule_value.split(",")
        else:
            rule_values = self.wpo_code.code_value.split(",")

        if len(self.wpo_code.staging_mapping_rule.strip()) == 0:
            rule_text = self.wpo_code.mapping_rule
        else:
            rule_text = self.wpo_code.staging_mapping_rule

        if len(template_code_values) > 0:  # simple replace
            for i, mapping_keyword in enumerate(template_mapping_keywords):
                if mapping_keyword != '':
                    rule_text = rule_text.replace(mapping_keyword, rule_values[i], 1)
        else:  # nothing to replace
            pass
        return rule_text

    def save_to_snapshot(self, request=None):

        try:
            rule = WPORule.objects.get(pk=self.pk)
            data = serializers.serialize('json', [rule])
            ProductionSnapshot.objects.create(
                username=request.enduser.username,
                snapshot_obj=data,
                user_ip=request.enduser.ip,
                snapshot_model=unicode(WPORule.__name__),
                model_pk=rule.pk,
                obj_state=1,
                parent_model=unicode(WPOWid.__name__),
                parent_model_pk=self.wid.pk
            )
        except WPORule.DoesNotExist:
            pass

    def save_shard_snapshot(self, request=None):
        if not self:
            return
        shard_domains = self.wpodomainsharding_set.all()

        ProductionSnapshot.objects.filter(
            snapshot_model=unicode(WPODomainSharding.__name__),
            parent_model=unicode(WPORule.__name__),
            parent_model_pk=self.pk
        ).delete()

        for sd in shard_domains:
            sd.save_to_snapshot(request=request)

    def rollback_from_snapshot(self, request=None):
        try:
            snapshot = ProductionSnapshot.objects.filter(
                model_pk=self.pk,
                snapshot_model=unicode(WPORule.__name__)
            ).order_by('id')[:1]
            if snapshot.exists():
                for obj in serializers.deserialize('json', snapshot[0].snapshot_obj):
                    obj.object.save(request=request)
            else:
                raise WPOAPIException(status.HTTP_400_BAD_REQUEST, "There is no backup data." % (str(self)))
        except WPORule.DoesNotExist:
            pass

    def rollback_shard_snapshot(self, request=None):
        if not self or not self.pk:
            return
        shard_snapshots = ProductionSnapshot.objects.filter(
            snapshot_model=unicode(WPODomainSharding.__name__),
            parent_model=unicode(WPORule.__name__),
            parent_model_pk=self.pk
        )

        for shard_snapshot in shard_snapshots:
            for obj in serializers.deserialize('json', shard_snapshot.snapshot_obj):
                obj.object.save(request=request)

    def is_deletable(self):
        return True

    def get_related_objects(self):
        pass

    def delete_related(self, request=None):
        # PRISMUI-2060
        if self.wpo_code_id == WPO_SHARD_DOMAIN_CODE_ID:
            self.delete_related_shard_domains(request=request)

    def is_modifiable(self):
        if not (self.wid.status_code == 1 or self.wid.status_code == 3):
            return True
        else:
            return False

    def save(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        if self.pk and not self.is_modifiable():
            raise WPOAPIException(status.HTTP_400_BAD_REQUEST, "%s is not modifiable." % (str(self)))

        if self.rule_name == 'ic_command':
            self.rule_value = self.rule_value.replace('\r\n', '')
            self.rule_value = self.rule_value.replace('\n', '')
        self.rule_text = self.generate_rule_text(request=request)
        self.staging_rule_text = self.generate_staging_rule_text(request=request)
        super(WPORule, self).save(request=request)

    def delete(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        self.delete_related(request=request)
        if self.is_deletable():
            super(WPORule, self).delete()
        else:
            raise WPOAPIException(status.HTTP_400_BAD_REQUEST, "%s is not deletable." % (str(self)))


class WPOCustomerDomain(Model):
    wid = models.ForeignKey(WPOWid, db_column='wid_id')
    customer_domain_name = models.CharField(max_length=256, unique=False, db_column='customer_domain_name')
    customer_origin_domain_name = models.CharField(max_length=256, unique=False, db_column='origin_domain_name')
    wpo_domain_type = models.PositiveSmallIntegerField(default=0,
                                                       db_column='wpo_domain_type',
                                                       choices=WPO_CUSTOMER_DOMAIN_TYPE)
    use_cdnw_cdn = models.PositiveSmallIntegerField(default=0, db_column='use_cdnw_cdn')
    retry = models.SmallIntegerField(default=0, db_column='retry')
    description = models.CharField(max_length=1024, blank=True)
    domain_rule_text = models.CharField(blank=True)
    staging_domain_rule_text = models.CharField(blank=True)
    date_modified = models.DateTimeField(auto_now=True, auto_now_add=True)
    date_created = models.DateTimeField(null=True, auto_now_add=True)
    latest_updater = models.CharField(max_length=128, blank=True)
    obj_state = models.PositiveSmallIntegerField(default=1)
    staging_domain = models.ForeignKey(Domain, db_column='staging_domain_id', null=True)

    class Meta:
        db_table = 'wpo_customer_domain'
        ordering = ['customer_domain_name']

    # noinspection PyClassHasNoInit
    class SpectrumMeta:
        allow_delete = True
        track = True

    def generate_rule_text(self, domain_protocol='http'):
        domain_type = WPO_CUSTOMER_DOMAIN_TYPE[self.wpo_domain_type][1]
        wpocode = WPOCode.objects.get(code_name=str(domain_type).lower(), parent_wpo_code=100)
        rule_text = wpocode.mapping_rule
        if domain_protocol == 'https':
            rule_text = wpocode.https_mapping_rule
        mapping_keywords = wpocode.mapping_keywords.split(",")

        return self._get_mapping_rule_text(
            domain_type=domain_type, rule_text=rule_text, mapping_keywords=mapping_keywords, is_staging=True)

    def generate_staging_rule_text(self, domain_protocol='http'):
        domain_type = WPO_CUSTOMER_DOMAIN_TYPE[self.wpo_domain_type][1]
        wpocode = WPOCode.objects.get(code_name=str(domain_type).lower(), parent_wpo_code=100)
        if len(wpocode.staging_mapping_rule.strip()) >= 1:
            rule_text = wpocode.staging_mapping_rule
        else:
            rule_text = wpocode.mapping_rule
        if domain_protocol == 'https':
            if len(wpocode.staging_https_mapping_rule) >= 1:
                rule_text = wpocode.staging_https_mapping_rule
            else:
                rule_text = wpocode.https_mapping_rule
        mapping_keywords = wpocode.mapping_keywords.split(",")

        return self._get_mapping_rule_text(
            domain_type=domain_type, rule_text=rule_text, mapping_keywords=mapping_keywords, is_staging=True)

    def _get_mapping_rule_text(self, domain_type, rule_text, mapping_keywords, is_staging=False):
        result_list = ["# Customer Domain Setup: %s" % domain_type]
        rule_text = self._replace_mapping_keyword_for_rule_text(rule_text, mapping_keywords)

        if is_staging:
            if domain_type == 'REWRITE_DOMAIN' and self.use_cdnw_cdn == 0:
                rule_text = rule_text.replace("PREFIX.", '')
                rule_text = rule_text.replace(".SUFFIX", '')
            else:
                rule_text = rule_text.replace("PREFIX.", WID_DOMAIN_PREFIX_FOR_TYPE[self.wid.wpo_type_id])
                rule_text = rule_text.replace(".SUFFIX", WID_DOMAIN_SUFFIX_FOR_TYPE[self.wid.wpo_type_id])

        result_list.append(rule_text)
        result_list.append("")
        self.rule_text = rule_text
        return "\n".join(result_list)

    def _replace_mapping_keyword_for_rule_text(self, rule_text, mapping_keywords):

        # in case of main_domain type: MAIN_DOMAIN_NAME,ORIGIN_DOMAIN_NAME
        # in case of sub_domain type:SUB_DOMAIN_NAME,ORIGIN_DOMAIN_NAME
        # in case of rewrite_domain type:REWRITE_DOMAIN_NAME,ORIGIN_DOMAIN_NAME

        if str(self.wpo_domain_type) == '2' and str(self.use_cdnw_cdn) == '0':
            rule_text = '\n'.join(rule_text.split('\n')[1:])
        for mapping_keyword in mapping_keywords:
            if mapping_keyword.upper().startswith("RETRY"):
                rule_text = rule_text.replace(mapping_keyword, str(self.retry))
            elif mapping_keyword.upper().startswith("ORIGIN"):
                rule_text = rule_text.replace(mapping_keyword, self.customer_origin_domain_name)
            else:
                rule_text = rule_text.replace(mapping_keyword, self.customer_domain_name)

        return rule_text

    def save_to_snapshot(self, request=None):
        try:
            cdomain = WPOCustomerDomain.objects.get(pk=self.pk)
            data = serializers.serialize('json', [cdomain])

            ProductionSnapshot.objects.create(
                username=request.enduser.username,
                snapshot_obj=data,
                user_ip=request.enduser.ip,
                snapshot_model=unicode(WPOCustomerDomain.__name__),
                model_pk=cdomain.pk,
                obj_state=1,
                parent_model=unicode(WPOWid.__name__),
                parent_model_pk=self.wid.pk
            )
        except WPOCustomerDomain.DoesNotExist:
            pass

    def rollback_from_snapshot(self, request=None):
        try:
            snapshot = ProductionSnapshot.objects.filter(
                model_pk=self.pk,
                snapshot_model=unicode(WPOCustomerDomain.__name__)
            ).order_by('-id')[:1]
            if snapshot.exists():
                for obj in serializers.deserialize('json', snapshot[0].snapshot_obj):
                    obj.object.save(request=request)
            else:
                raise WPOAPIException(status.HTTP_400_BAD_REQUEST, "There is no backup data." % (str(self)))

        except WPOCustomerDomain.DoesNotExist:
            pass

    def is_deletable(self):
        return True

    def get_related_objects(self):
        pass

    def delete_related(self, request=None):
        if self.staging_domain:
            self.staging_domain.delete(request=request)

    def is_modifiable(self):
        if not (self.wid.status_code == 1 or self.wid.status_code == 3):
            return True
        else:
            return False

    def save(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        if self.pk and not self.is_modifiable():
            raise WPOAPIException(status.HTTP_400_BAD_REQUEST, "%s is not modifiable." % (str(self)))

        self.domain_rule_text = self.generate_rule_text()
        self.staging_domain_rule_text = self.generate_staging_rule_text()
        super(WPOCustomerDomain, self).save(request=request)

    def delete(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        self.delete_related(request=request)
        if self.is_deletable():
            super(WPOCustomerDomain, self).delete()
        else:
            raise WPOAPIException(status.HTTP_400_BAD_REQUEST, "%s is not deletable." % (str(self)))


class WPODomainSharding(Model):
    domain_sharding_id = models.AutoField(primary_key=True, db_column='domain_sharding_id')
    gslb_domain = models.ForeignKey(Domain, db_column='gslb_domain_id', blank=False)
    rule = models.ForeignKey(WPORule, db_column='rule_id', blank=False)

    class Meta:
        db_table = 'wpo_domain_sharding'
        ordering = ['domain_sharding_id']

    class SpectrumMeta:
        allow_delete = True
        track = False

    def save_to_snapshot(self, request=None):
        try:
            shard_domain = WPODomainSharding.objects.get(pk=self.pk)
            data = serializers.serialize('json', [shard_domain])
            snapshot = ProductionSnapshot(
                username=request.enduser.username,
                snapshot_obj=data,
                user_ip=request.enduser.ip,
                snapshot_model=unicode(WPODomainSharding.__name__),
                model_pk=shard_domain.pk,
                obj_state=1,
                parent_model=unicode(WPORule.__name__),
                parent_model_pk=self.rule.pk
            )

            snapshot.save()
        except WPODomainSharding.DoesNotExist:
            pass


class WPOHistory(Model):
    history_id = models.AutoField(primary_key=True, db_column='history_id')
    wid = models.ForeignKey(WPOWid, db_column='wid_id')
    date_created = models.DateTimeField('Date Created', auto_now_add=True)
    author = models.CharField(max_length=128, blank=True)
    obj_data = models.TextField()
    type = models.PositiveSmallIntegerField(default=1, db_column='type', choices=WPO_HISTORY_TYPE)

    class Meta:
        db_table = 'wpo_history'

    def get_previous(self):
        histories = WPOHistory.objects.filter(wid=self.wid, history_id__lt=self.history_id).order_by('-history_id')[:1]
        if len(histories) >= 1:
            return histories[0]
        else:
            return WPOHistory(obj_data='{}')

    def get_obj_data(self):
        ret_data = json.loads(self.obj_data)
        if type(ret_data) is dict:
            return ret_data
        else:
            raise WPOAPIException(status.HTTP_500_INTERNAL_SERVER_ERROR,
                                  "wid_history(%s)'s data is incorrect. Please check db data." % str(self.history_id))

    def get_diff(self):

        diff = DictDiffer(self.get_obj_data(), self.get_previous().get_obj_data())
        added, removed, changed = diff.get_added(), diff.get_removed(), diff.get_changed()
        diff_dict = {}
        for o_add in added:
            key, prev_value, cur_value = o_add[0], o_add[1], o_add[2]
            diff_dict[key] = [prev_value, cur_value, 'added']
        for o_rem in removed:
            key, prev_value, cur_value = o_rem[0], o_rem[1], o_rem[2]
            diff_dict[key] = [prev_value, cur_value, 'removed']
        for o_ch in changed:
            key, prev_value, cur_value = o_ch[0], o_ch[1], o_ch[2]
            diff_dict[key] = [prev_value, cur_value, 'changed']
        return diff_dict

    def _for_save_obj_data(self):
        if str(self.type) == '3':
            self.obj_data = json.dumps({})
            return
        try:
            obj_data = json.loads(self.wid.toJSON())
            rules = WPORule.objects.filter(wid=self.wid)
            cdomains = WPOCustomerDomain.objects.filter(wid=self.wid)

            remove_keys = ['staging_optimization_rule_text', 'optimization_rule_text',
                           'generate_backup', 'time_deployed', 'date_modified', 'date_created', 'wid_id']

            for o_key in obj_data.keys():
                if o_key in remove_keys and o_key in obj_data:
                    del obj_data[o_key]
                elif obj_data[o_key] == 'None' or obj_data[o_key] == '' or obj_data[o_key] is None:
                    del obj_data[o_key]

            if rules.exists():
                for rule in rules:
                    if not rule.rule_value:
                        rule.rule_value = 'on'  # rule is turn on. but no have value.
                    obj_data[rule.rule_name] = rule.rule_value

            if cdomains.exists():
                cdomain_types = {
                    '0': ['customer_domain', 'customer_domain_origin'],
                    '1': ['sub_domain', 'sub_domain_origin'],
                    '2': ['rewrite_domain', 'rewrite_domain_origin']
                }

                domain_key_idx = 1
                origin_domain_key_idx = 1

                for cdomain in cdomains:
                    if domain_key_idx == 1:
                        domain_key = cdomain_types[str(cdomain.wpo_domain_type)][0]
                    else:
                        domain_key = ''.join([cdomain_types[str(cdomain.wpo_domain_type)][0], '-', str(domain_key_idx)])
                    obj_data[domain_key] = cdomain.customer_domain_name
                    domain_key_idx += 1

                    if origin_domain_key_idx == 1:
                        origin_domain_key = cdomain_types[str(cdomain.wpo_domain_type)][1]
                    else:
                        origin_domain_key = ''.join(
                            [cdomain_types[str(cdomain.wpo_domain_type)][1], '-', str(origin_domain_key_idx)])
                    obj_data[origin_domain_key] = cdomain.customer_origin_domain_name
                    origin_domain_key_idx += 1

                obj_data_json = json.dumps(obj_data)
                self.obj_data = obj_data_json

        except WPOWid.DoesNotExist:
            raise WPOAPIException(status.HTTP_500_INTERNAL_SERVER_ERROR,
                                  "wid(%s) does not exist!" % str(self.wid.pk))

    def save(self, *args, **kwargs):
        request = kwargs.pop('request', None)
        self._for_save_obj_data()
        if request:
            self.author = request.enduser.username
        super(WPOHistory, self).save(request=request)


class DictDiffer(object):
    def __init__(self, current_dict, prev_dict):
        self.current_dict, self.prev_dict = current_dict, prev_dict
        self.set_current, self.set_prev = set(current_dict.keys()), set(prev_dict.keys())
        self.intersect = self.set_current.intersection(self.set_prev)

    def get_added(self, empty_str='N/A'):
        return [
            [key, 'off' if self.current_dict[key] == 'on' else empty_str, self.current_dict[key]]
            for key in (self.set_current - self.intersect)
        ]

    def get_removed(self, empty_str='removed!'):
        return [
            [key, self.prev_dict[key], 'off' if self.prev_dict[key] == 'on' else empty_str]
            for key in (self.set_prev - self.intersect)
        ]

    def get_changed(self):
        return [
            [key, self.prev_dict[key], self.current_dict[key]]
            for key in self.intersect if self.prev_dict[key] != self.current_dict[key]
        ]

    def get_unchanged(self):
        return [
            [key, self.prev_dict[key], self.current_dict[key]]
            for key in self.intersect if self.prev_dict[key] == self.current_dict[key]
        ]