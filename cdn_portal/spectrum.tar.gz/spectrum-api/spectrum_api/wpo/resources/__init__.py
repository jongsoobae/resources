help_text = {
    'Rewrite Domain': ':br'.join([
        'When FEO rewrites a resource, it updates the HTML to refer to the resource by its new name.',
        'Generally FEO leaves the resource at the same origin and path that was originally found in the HTML.',
        'However, it is possible to map the domain of rewritten resources. '
        'Examples of why this might be desirable include:',
        '',
        'Serving static content from cookieless domains, to reduce the size of HTTP requests from the browser.',
        'To move content to a Content Delivery Network (CDN)'
    ])
    , 'Inline Image': ':br'.join([
        'This optimization replaces references to small images by an inline data: '
        'URL, eliminating the need to initiate another connection to fetch the image data.',
        'So, can reduce the number of requests made by a web page.',
        '',
        '- Max Bytes ',
        '  MaxBytes, a positive integer, '
        'is the maximum size in bytes of any image that will be inlined into an HTML file. '
        'The current default value for MaxBytes is 2048.'
    ])
    , 'Inline Javascript': ':br'.join([
        'Insert the contents of small external JavaScript resources directly into the HTML document.',
        'So, can reduce the number of requests made by a web page.',
        '',
        '- Max Bytes ',
        '  This is the maximum size in bytes of any JavaScript file that will be inlined. '
    ])
    , 'Inline CSS': ':br'.join([
        'Insert the contents of small external CSS resources directly into the HTML document.',
        'So, can reduce the number of requests made by a web page.',
        '',
        '- Max Bytes ',
        '  This is the maximum size in bytes of any CSS file that will be inlined.'

    ])
    , 'Minify Html': ':br'.join([
        'Remove all comments and most whitespace in html code. So, can reduce the HTTP payload size.'
    ])
    , 'Combine Javascript': ':br'.join([
        'Replace multiple distinct JavaScript files with a single one. So, can reduce the number of HTTP requests.',
        '',
        '- Max Bytes ',
        '  MaxBytes is the maximum uncompressed size in bytes of the combined JavaScript files. '
        'JavaScript files larger than MaxBytes will be kept intact. '
        'The current default value for MaxBytes is 92160 (90K).'
    ])
    , 'Minify Javascript': ':br'.join([
        'Remove all comments and most whitespace in javascript code in html file or external javascript file.',
        'So, can reduce the HTTP payload size.'
    ])
    , 'Move CSS to Head': ':br'.join([
        'Ensuring that the CSS styles are all parsed in the head, before any body elements are introduced.'
    ])
    , 'Combine CSS': ':br'.join([
        'Replace multiple distinct CSS files with a single one. So, can reduce the number of HTTP requests.',
        '',
        '- Max Bytes',
        '  MaxBytes is the maximum uncompressed size in bytes of the combined JavaScript files. '
        'JavaScript files larger than MaxBytes will be kept intact. '
        'The current default value for MaxBytes is -1 (unlimited).'
    ])
    , 'Minify CSS': ':br'.join([
        'Remove all comments and most whitespace in CSS code in html file or external CSS file. '
        'So, can reduce the HTTP payload size.'
    ])
    , 'Flatten CSS': ':br'.join([
        'Parse linked and inlined CSS and flattens it by replacing all @import rules with the contents of the imported file. '
        'So, can reduce the number of HTTP requests.',
        '',
        '- Max Bytes',
        '  This is the maximum size in bytes of the flattened CSS; '
        'if flattening would result in CSS larger than this then flattening will be aborted  and the CSS will be left unchanged.',
        '',
        '- Requirement',
        '  To use this feature, Minify CSS feature must be enabled.',
        '- Not support CSS3'
    ])
    , 'Sprite Image': ':br'.join([
        'Detect GIF and PNG images used as backgrounds in CSS. '
        'It attempts to combine all such images referenced from a CSS file into a single large image.',
        '',
        '- Requirement',
        '  To use this feature, Minify CSS feature must be enabled.'
    ])
    , 'Recompress PNG': ':br'.join([
        'Replace pngs with ones encoded at a higher compression ratio.'
    ])
    , 'Recompress JPEG': ':br'.join([
        'Recompresses jpegs, depending on whether the input jpeg`s quality higher or lower than FEO`s default output quality. '
        'If the input image is higher quality than FEO is set to produce then recompress_jpeg will recompress the image to the lower quality setting.',
        'Otherwise FEO will attempt to improve the compression of the image but won`t reduce its quality.',
        '',
        '- Quality',
        '  Set the compression quality used when creating or re-compressing jpeg images.',
        '- Quality For Small Screens',
        '  Sets the compression quality used when creating or re-compressing jpeg images that will be viewed on devices with small screens (such as mobile phones).'
    ])
    , 'Recompress WEBP': ':br'.join([
        'Replace webp images with smaller webp images by re-encoding them at lower quality settings.',
        '',
        '- Quality',
        '  Sets the compression quality used when creating or re-compressing webp images.',
        '- Quality for Small Screens',
        'Sets the compression quality used when creating or re-compressing webp images that will be viewed on devices with small screens (such as mobile phones).'
    ])
    , 'Convert GIF to PNG': ':br'.join([
        'Convert gifs to pngs. Animated gifs won`t be converted because pngs can`t animate.'
    ])
    , 'Convert PNG to JPEG': ':br'.join([
        'Convert a rewritten gif or png image to a jpeg so long as it does not have an alpha channel or transparent pixels.'
    ])
    , 'Convert JPEG to WEBP': ':br'.join([
        'Create webp images whenever it would otherwise attempt to serve jpegs.'
    ])
    , 'Resize Image': ':br'.join([
        'Resize any image that is larger than the size called for by the width= and height= attributes on the img tag or an inline style= attribute. The original image is replaced only if the image file is smaller after resizing.'
    ])
    , 'Defer Javascript': ':br'.join([
        'Defer JavaScript execution until page load.'
    ])
    , 'Lazy Load Image': ':br'.join([
        'Defer loading of images until they are visible in the client`s viewport.'
    ])
    , 'Async Google Analytics': ':br'.join([
        'Convert synchronous use of Google Analytics API to asynchronous.'
    ])
    , 'Convert Progressive JPEG': ':br'.join([
        'Transform larger non-progressive jpeg images (those more than 10KB in size) into progressive jpegs. Large progressive jpegs generally compress better and permit incremental display by the browser.',
        '',
        '- Min Bytes',
        '  Use this setting to change the progressive jpeg threshold.'
    ])
    , 'Domain Sharding': ':br'.join([
        'Parallelizing downloads across hostnames.'
    ])
    , 'Allow only Mobile Browser': ':br'.join([
        'When we provide WPO service for customer, we can configure to process only requests received from mobile browser. In case of receiving request from other browser, bypass it without optimization. We have to configure the kind of browsers.'
    ])
    , 'Modify Object Cache': ':br'.join([
        'After FEO optimizes objects, change "max-age=one year" for cache control. Sometime, we need to preserve cache control of origin object.',
        'Default value is to preserve caching header of original object.'
    ])
    , 'Character Set': ':br'.join([
        'Default charset parameter to be added in httpd.conf when a response content-type is text/plain or text/html.',
        '',
        '- AddDefaultCharset On'
    ])
    , 'Options of File Cache': ':br'.join([
        'It is important to note that FileCacheSizeKb and FileCacheInodeLimit do not define absolute limits on the cache size and inode count.',
        'The cache cleaning process will run at the time interval defined by FileCacheCleanIntervalMs, and will only initiate cleaning if the cache size exceeds FileCacheSizeKb or the cache inode count exceeds FileCacheInodeLimit.',
        'When cache cleaning is initiated, the oldest files in the cache will be removed until the cache size is under 0.75 * FileCacheSizeKb and the inode count is under 0.75 * FileCacheInodeLimit.'
    ])
};