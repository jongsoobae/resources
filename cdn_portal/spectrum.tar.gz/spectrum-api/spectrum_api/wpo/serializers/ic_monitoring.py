
from rest_framework import serializers

from spectrum_api.wpo.models.wpo import WPOCluster
from spectrum_api.wpo.models.wpo import WPONode


class ICMonitoringClusterSerializer(serializers.ModelSerializer):

    wpo_nodes = serializers.Field()

    class Meta(object):
        model = WPOCluster
        fields = ('cluster_id', 'cluster_name', 'wpo_nodes')


class ICMonitoringClusterNodeSerializer(serializers.ModelSerializer):

    node_info = serializers.Field()

    class Meta(object):
        model = WPONode
        fields = ('node_info', )
