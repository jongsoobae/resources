from rest_framework import serializers
from spectrum_api.wpo.models.wpo import WPOHistory, WPO_HISTORY_TYPE


"""""""""""""""""""""""""""""""""""""""""""""
  WPO Audit
"""""""""""""""""""""""""""""""""""""""""""""


class WPOAuditSerializer(serializers.ModelSerializer):
    diff = serializers.Field('get_diff')
    wid_name = serializers.RelatedField('wid')
    type = serializers.ChoiceField(choices=WPO_HISTORY_TYPE, default=1)
    type_name = serializers.SerializerMethodField('get_type_display')

    class Meta:
        model = WPOHistory
        fields = (
            'history_id', 'wid', 'date_created', 'author', 'obj_data', 'diff', 'wid_name', 'type', 'type_name')

    @staticmethod
    def get_type_display(obj):
        return obj.get_type_display()