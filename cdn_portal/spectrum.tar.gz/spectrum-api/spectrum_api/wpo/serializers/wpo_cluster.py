from django.core.validators import RegexValidator
from rest_framework import serializers
from spectrum_api.configuration.models.base import Edge, Vip, VipSearch
from spectrum_api.shared_components.serializers import SpectrumModelSerializer
from spectrum_api.shared_components.utils.regex import gslb_domain_rex

from spectrum_api.wpo.models.wpo import WPOCluster, WPOLocation, WPONode, WPO_NODE_TYPE, WPOType, WPO_TYPE_FEO
from spectrum_api.dna.models.domain import Domain, DomainVip, DomainEdge


"""""""""""""""""""""""""""""""""""""""""""""
  WPO Location
"""""""""""""""""""""""""""""""""""""""""""""


class WPOLocationSerializer(serializers.ModelSerializer):
    config_name = serializers.RelatedField(source="config_phase", read_only=True)
    wpo_type_name = serializers.RelatedField(source="wpo_type", read_only=True)

    class Meta:
        model = WPOLocation
        fields = ("location_id",
                  "location_name",
                  "description",
                  "obj_state",
                  "date_created",
                  "date_modified",
                  "latest_updater",
                  "config_phase",
                  "config_name",
                  "wpo_type",
                  "wpo_type_name")

    def validate_location_name(self, attrs, source):
        location_name = attrs.get(source)
        if not location_name:
            raise serializers.ValidationError({source: '%s is required.' % source})

        if self.object:
            if WPOLocation.all_objects.filter(location_name=location_name).exclude(pk=self.object.pk).exists():
                raise serializers.ValidationError({source: '%s is duplicated.' % location_name})
        else:
            if WPOLocation.all_objects.filter(location_name=location_name).exists():
                raise serializers.ValidationError({source: '%s is duplicated.' % location_name})
        return attrs

    def validate_config_phase(self, attrs, source):
        config_phase = attrs.get(source)

        if not config_phase:
            raise serializers.ValidationError({source: '%s is required.' % source})

        return attrs


class WPOLocationDeletableSerializer(serializers.ModelSerializer):
    is_deletable = serializers.SerializerMethodField("get_deletable")
    #is_deletable = serializers.Field('is_deletable')

    class Meta:
        model = WPOLocation
        fields = ('location_id', 'is_deletable')

    @staticmethod
    def get_deletable(data):
        """

        :rtype : 0 : can't delete , 1 : can delete
        """
        try:
            location_id = data.location_id
            if WPOCluster.objects.filter(wpo_location=location_id).exists():
                return 0
        except Exception, e:
            raise e
        return 1


class WPOLocationRelatedSerializer(serializers.ModelSerializer):
    related_items = serializers.SerializerMethodField('get_related_items')

    class Meta:
        model = WPOLocation
        fields = ('location_id', 'related_items')

    def get_related_items(self, data):
        if self.object:
            related_objects = self.object.get_related_objects()
        else:
            related_objects = data.get_related_objects()

        related_items = {}

        for items in related_objects:
                key = unicode(items[0].__name__)
                sub_items = []
                for sub_item in items[1]:
                    sub_items.append("%s" % sub_item)

                if len(sub_items) > 0:
                    related_items.update({key: sub_items})
        return related_items


"""""""""""""""""""""""""""""""""""""""""""""
  WPO Cluster
"""""""""""""""""""""""""""""""""""""""""""""


class WPOClusterLocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = WPOLocation
        fields = ('location_id', 'location_name')


class WPODomainSerializer(serializers.ModelSerializer):
    name = serializers.CharField(validators=[RegexValidator(gslb_domain_rex)])

    class Meta:
        model = Domain
        fields = ('domain_id', 'name', 'domain_type')

    def get_identity(self, data):
        try:
            return data.get('domain_id', None)
        except AttributeError:
            return None


class WPOClusterSerializer(SpectrumModelSerializer):
    primary_cluster_domain = WPODomainSerializer(required=True,
                                                 read_only=False)

    staging_cluster_domain = WPODomainSerializer(required=True,
                                                 read_only=False)

    wpo_location_name = serializers.RelatedField(source="wpo_location", read_only=True)

    #connectivity = serializers.Field('get_connectivity')

    class Meta:
        model = WPOCluster
        fields = (
            "cluster_id",
            "cluster_name",
            "primary_cluster_domain",
            "staging_cluster_domain",
            "wpo_location",
            "wpo_location_name",
            "generate_gslb",
            "config_state",
            "obj_state",
            "date_created",
            "date_modified",
            "latest_updater",
            "description",
            #"connectivity"
        )

    def validate(self, attrs):
        p_domain = attrs.get('primary_cluster_domain')
        s_domain = attrs.get('staging_cluster_domain')

        if not p_domain or not s_domain:
            return attrs

        p_domain_error = []
        s_domain_error = []

        generate_gslb = attrs.get('generate_gslb')
        if generate_gslb == 1:
            try:
                if self.object:
                    wpo_type = self.object.wpo_location.wpo_type_id
                else:
                    wpo_type = attrs['wpo_location'].wpo_type_id
            except (Exception, ):
                wpo_type = WPO_TYPE_FEO[0]
            if p_domain.name != WPOCluster.get_primary_domain_name_rule(
                    attrs['cluster_name'], wpo_type=wpo_type):
                p_domain_error = [
                    {
                        'name': ['domain name is cluster_name + suffix']
                    }
                ]

            if s_domain.name != WPOCluster.get_staging_domain_name_rule(
                    attrs['cluster_name'], wpo_type=wpo_type):
                s_domain_error = [
                    {
                        'name': ['domain name is prefix + cluster_name + suffix']
                    }
                ]
        if p_domain.name == s_domain.name:
            if 'name' in s_domain_error:
                s_domain_error['name'].append('primary domain and staging domain must not be same.')
            else:
                s_domain_error = [
                    {
                        'name': ['primary domain and staging domain must not be same.']
                    }
                ]
        error = {}

        if p_domain_error:
            error['primary_cluster_domain'] = p_domain_error

        if s_domain_error:
            error['staging_cluster_domain'] = s_domain_error
        if len(error) >= 1:
            raise serializers.ValidationError(error)

        return attrs


class WPOClusterDeletableSerializer(serializers.ModelSerializer):
    is_deletable = serializers.Field("is_deletable")

    class Meta:
        model = WPOCluster
        fields = ('cluster_id', 'is_deletable')


class WPOClusterRelatedSerializer(serializers.ModelSerializer):
    items = serializers.SerializerMethodField("get_related_items")

    class Meta:
        model = WPOCluster
        fields = ('cluster_id', 'items')

    def get_related_items(self, data):
        if self.object:
            related_objects = self.object.get_related_objects()
        else:
            related_objects = data.get_related_objects()

        related_items = {}

        for items in related_objects:
            key = unicode(items[0].__name__)
            sub_items = []
            for sub_item in items[1]:
                sub_items.append(sub_item)

            if len(sub_items) > 0:
                related_items.update({key: sub_items})
        return related_items


"""""""""""""""""""""""""""""""""""""""""""""
  WPO Node
"""""""""""""""""""""""""""""""""""""""""""""


class WPOVipSerializer(serializers.ModelSerializer):
    full_vip_name = serializers.Field('get_fullvipname')
    vip_ip = serializers.Field('__unicode__')
    #vip_ip = serializers.RelatedField(source='vip', read_only=True)

    class Meta:
        model = Vip
        fields = ('full_vip_name', 'vip', 'vip_addr', 'ihms_vip', 'vip_name', 'vip_ip')


class WPONodeSerializer(SpectrumModelSerializer):
    wpo_cluster_name = serializers.RelatedField(source="wpo_cluster", read_only=True)
    vip_full_name = serializers.Field(source='vip.get_fullvipname')
    vip_ip = serializers.RelatedField(source='vip', read_only=True)
    connectivity = serializers.Field('get_status_display')

    class Meta:
        model = WPONode

        fields = (
            "node_id", "node_type", "description",
            "wpo_cluster", "wpo_cluster_name",
            "vip",
            "vip_full_name", "vip_ip",
            "date_modified", "date_created", "latest_updater", "obj_state",
            "connectivity"
        )

    def validate_node_type(self, attrs, source):
        node_type = attrs.get('node_type')
        if node_type is None or node_type == '':
            raise serializers.ValidationError({source: '%s is required.' % source})
        return attrs

    def validate_vip(self, attrs, source):
        vip = attrs.get('vip')
        if not vip:
            raise serializers.ValidationError({source: '%s is required.' % source})
        return attrs

