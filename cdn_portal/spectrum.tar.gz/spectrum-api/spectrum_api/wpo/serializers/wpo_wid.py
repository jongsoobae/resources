from django.core.validators import RegexValidator
from rest_framework import serializers
from spectrum_api.shared_components.models.customer import CustomerDisplay
from spectrum_api.shared_components.models.customer import CustomerItem

from spectrum_api.shared_components.serializers import SpectrumModelSerializer
from spectrum_api.shared_components.utils.regex import domain_rex
from spectrum_api.wpo.models.wpo import WPOCustomerDomain, WPOWid, \
    WPORule, WPOCode, WPONode, WPOWidItems
from spectrum_api.dna.models.domain import Domain


"""""""""""""""""""""""""""""""""""""""""""""
  WPO CustomerDomain
"""""""""""""""""""""""""""""""""""""""""""""


class WPOCustomerDomainSerializer(serializers.ModelSerializer):

    class Meta:
        model = WPOCustomerDomain
        fields = ('id', 'wid', 'customer_domain_name', 'customer_origin_domain_name',
                  'wpo_domain_type', 'use_cdnw_cdn', 'retry', 'description', 'date_created',
                  'date_modified', 'latest_updater', 'obj_state')


class WPOCustomerDomainDeletableSerializer(serializers.ModelSerializer):
    is_deletable = serializers.Field('is_deletable')

    class Meta:
        model = WPOCustomerDomain
        fields = ('id', 'is_deletable')


"""""""""""""""""""""""""""""""""""""""""""""
  WPO Wid
"""""""""""""""""""""""""""""""""""""""""""""


class WPOWidRuleTextSerializer(serializers.ModelSerializer):
    class Meta:
        model = WPOWid
        fields = ('wid_id', 'optimization_rule_text', 'staging_optimization_rule_text')


class WIDDomainSerializer(serializers.ModelSerializer):
    class Meta:
        model = Domain
        fields = (
            'domain_id', 'name', 'description', 'domain_type'
        )


class WIDCustomerDomainSerializer(serializers.ModelSerializer):
    customer_domain_name = serializers.CharField(validators=[RegexValidator(domain_rex)])
    customer_origin_domain_name = serializers.CharField(validators=[RegexValidator(domain_rex)])
    staging_domain = WIDDomainSerializer(read_only=True)

    class Meta:
        model = WPOCustomerDomain
        fields = (
            'id', 'wid', 'customer_domain_name',
            'customer_origin_domain_name', 'wpo_domain_type',
            'use_cdnw_cdn', 'retry', 'description', 'latest_updater', 'staging_domain'
        )
        read_only_fields = ('wid', )

    def validate(self, attrs):
        domain = attrs.get('customer_domain_name')
        origin_domain = attrs.get('customer_origin_domain_name')

        if domain and not origin_domain:
            raise serializers.ValidationError(
                {'customer_origin_domain_name': ['Both domain and origin domain are required.']})
        if not domain and origin_domain:
            raise serializers.ValidationError(
                {'customer_domain_name': ['Both domain and origin domain are required.']})

        return attrs


class WIDRulesSerializer(serializers.ModelSerializer):

    class Meta:
        model = WPORule
        fields = (
            'rule_id', 'wid', 'wpo_code', 'rule_name', 'rule_value',
            'description', 'latest_updater'
        )
        read_only_fields = ('wid', )

    def get_identity(self, data):
        try:
            return data.get('rule_id', None)
        except AttributeError:
            return None

    def validate(self, attrs):
        WPORule.rule_value_validation(rule_name=attrs.get('rule_name'),
                                      rule_values_string=attrs.get('rule_value'))
        return attrs


class WIDItemsSerializer(serializers.ModelSerializer):

    class Meta:
        model = WPOWidItems
        fields = (
            'wid', 'item',
        )
        read_only_fields = ('wid', )

    def get_identity(self, data):
        try:
            return data.get('id', None)
        except AttributeError:
            return None

    def validate(self, attrs):
        return attrs


class WPOWidSerializer(SpectrumModelSerializer):
    host_domain = WIDDomainSerializer(required=True, read_only=False)
    backup_host_domain = WIDDomainSerializer(required=False, read_only=False)

    customer_domains = WIDCustomerDomainSerializer(many=True, required=False, read_only=False,
                                                   source="wpocustomerdomain_set", allow_add_remove=True)

    staging_host_domain = WIDDomainSerializer(read_only=True)

    wpo_rules = WIDRulesSerializer(many=True, required=False, read_only=False,
                                   source="wporule_set", allow_add_remove=True)

    customer_name = serializers.RelatedField(source="customer", read_only=True)

    wid_items = WIDItemsSerializer(many=True, required=True, read_only=False,
                                   source="wpowiditems_set", allow_add_remove=True)

    class Meta:
        model = WPOWid
        fields = (
            'wid_id', 'wid_name',
            'customer', 'customer_name',
            'wid_items',
            'host_domain', 'backup_host_domain', 'staging_host_domain',
            'location',
            'cluster', 'backup_cluster',
            'customer_domains', 'wpo_rules',
            'generate_gslb', 'generate_backup',
            'rule_optimization_enabled',
            'description', 'latest_updater',
            'date_modified', 'date_created', 'obj_state', 'status_code',
            'wpo_type',
            'domain_protocol'
        )
        read_only_fields = ('status_code', )

    def validate_wid_items(self, attrs, source):
        if not attrs[source]:
            raise serializers.ValidationError('Contract item is required.')
        return attrs

    def validate(self, attrs):
        try:
            customer = attrs.get('customer')
            cluster = attrs.get('cluster')
            backup_cluster = attrs.get('backup_cluster')
            host_domain = attrs.get('host_domain')
            backup_host_domain = attrs.get('backup_host_domain')
            wid_name = attrs.get('wid_name')
            customer_domains = attrs.get('wpocustomerdomain_set')
            location = attrs.get('location')

            b_exist_customer_domain = False
            b_customer_domain_error = True
            b_customer_origin_domain_error = True
            for customer_domain in customer_domains:
                if str(customer_domain.wpo_domain_type) == '0':
                    if customer_domain.customer_domain_name:
                        b_customer_domain_error = False
                    if customer_domain.customer_origin_domain_name:
                        b_customer_origin_domain_error = False
                    if customer_domain.customer_domain_name and \
                            customer_domain.customer_origin_domain_name:
                        b_exist_customer_domain = True
                        break

            errors = {}
            if not customer:
                errors['customer'] = ['Customer is required.']

            if not b_exist_customer_domain:
                errors['customer_domains'] = []
                if b_customer_domain_error:
                    errors['customer_domains'].append({'customer_domain_name': ['Customer_domain is required.']})
                if b_customer_origin_domain_error:
                    errors['customer_domains'].append(
                        {'customer_origin_domain_name': ['Customer_domain is required.']})

            if not wid_name:
                errors['wid_name'] = ['Wid_name is required.']

            if not host_domain:
                errors['host_domain'] = ['Host_domain is required.']

            if not cluster:
                errors['cluster'] = ['Cluster is required.']

            if not location:
                errors['location'] = ['Location is required.']

            if len(errors) >= 1:
                raise serializers.ValidationError(errors)

            if not backup_cluster or not backup_host_domain:
                attrs['backup_cluster'] = None
                attrs['backup_host_domain'] = None

            if backup_cluster and cluster.pk == backup_cluster.pk:
                raise serializers.ValidationError({'cluster': ['Invalid. cluster and backup_cluster is same.']})
            if str(cluster.config_state) == '0':
                raise serializers.ValidationError({'cluster': ['Invalid cluster. this cluster cannot activate.']})
            if backup_cluster and str(backup_cluster.config_state) == '0':
                raise serializers.ValidationError(
                    {'backup_cluster': ['Invalid cluster. this cluster cannot activate.']})

            shard_domains = None
            wporule_set = attrs.get('wporule_set')

            if wporule_set:
                for wporule in wporule_set:
                    if wporule.rule_name == 'domain_sharding':
                        shard_domains = wporule.rule_value
                        try:
                            origin_domain, from_domain, to_domains = shard_domains.split(',')
                            main_domains = [cdomain.customer_domain_name for cdomain in customer_domains
                                            if cdomain.wpo_domain_type != 2]
                        except (ValueError, Exception):
                            raise serializers.ValidationError({
                                'domain_sharding': ['There is empty input.']
                            })
                        if from_domain not in main_domains:
                            raise serializers.ValidationError({
                                'domain_sharding': ['Sharding domain(from) must same with main domain or sub domain.']
                            })

            for o in attrs.get('wpocustomerdomain_set', []):
                if WPOCustomerDomain.objects.filter(
                        customer_domain_name=o.customer_domain_name,
                        wid__wpo_type=attrs.get('wpo_type').wpo_type_id).exclude(pk=o.pk).exists():
                    raise serializers.ValidationError({
                        'customer_domain_name': ['Customer_domain is duplicated.']
                    })
            return attrs
        except serializers.ValidationError, e:
            raise e
        except KeyError, e:
            raise serializers.ValidationError({'cluster': [e.message]})
        except Exception, e:
            raise serializers.ValidationError({'detail': [e.message]})


class WPOWidStatusSerializer(serializers.ModelSerializer):
    timeout = serializers.SerializerMethodField('get_timeout')
    staging_servers = serializers.SerializerMethodField('get_staging_servers')

    class Meta:
        model = WPOWid
        fields = (
            'wid_id', 'status_code', 'timeout', 'staging_servers'
        )

    def get_staging_servers(self, data):
        nodes = WPONode.objects.filter(node_type=1, wpo_cluster=self.object.cluster)
        return [e[0] for e in nodes.values_list('node_name')]

    def get_timeout(self, data):
        if self.object.is_modifiable():
            return False
        return data.get_timeout()


class WPOCodeSerializer(serializers.ModelSerializer):
    class Meta:
        model = WPOCode


class WPOCustomerSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerDisplay

    @staticmethod
    def transform_customer_name(obj, value):
        return "%s [%s]" % (value.strip(), obj.getRegionName())


class WPOContractSerializer(serializers.ModelSerializer):
    contract_name = serializers.RelatedField('contract')
    status_code_detail = serializers.SerializerMethodField('get_status_code_detail')

    class Meta:
        model = CustomerItem
        fields = (
            'item_id', 'item_no', 'contract', 'contract_name', 'option_code', 'option_name', 'status_code', 'status_code_detail'
        )

    def get_status_code_detail(self, data):
        if data.status_code in ['11', '92', '93']:
            return data.status_code_tx
        return ''
