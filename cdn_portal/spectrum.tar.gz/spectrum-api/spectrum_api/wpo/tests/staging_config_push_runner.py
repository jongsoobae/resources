import sys
import os
sys.path.insert(0, '../../../')
os.environ['DJANGO_SETTINGS_MODULE'] = 'spectrum_api.settings'


from staging_config_push_test import *


if __name__ == "__main__":
    unittest.main()
