from django.utils import unittest

from rest_framework import status
from rest_framework.test import APIClient
from rest_framework.authtoken.models import Token

from spectrum_api.wpo.models.wpo import WPOWid


class StagingPushTest(unittest.TestCase):
    def setUp(self):
        self.apiclient = APIClient()
        token = Token.objects.get(user__username='aurorauser')
        self.apiclient.credentials(HTTP_AUTHORIZATION='Token ' + token.key)
        self.wid_id = None

        self.cic_post_data = {
            "wid_name": "cic_staging_push_test",
            "customer": 1,
            "wid_items": [{'item': 2}],
            "host_domain":
                {"domain_type": 6, "description": "", "name": "cic-spush.wpo.cdngp.net"},
            "location": 3,
            "cluster": 3,
            "generate_gslb": "1", "generate_backup": "1", "rule_optimization_enabled": "1",
            "status_code": 0,
            "customer_domains": [
                {"customer_domain_name": "cic-spushtest.com",
                 "customer_origin_domain_name": "origin.cic-spushtest.com",
                 "use_cdnw_cdn": 1, "wpo_domain_type": 0}
            ],
            "wpo_rules": [{"rule_name": "inline_image", "rule_value": "2048"}]
        }

        self.feo_post_data = {
            "wid_name": "feo_staging_push_test",
            "customer": 1,
            "wid_items": [{'item': 2}],
            "host_domain":
                {"domain_type": 6, "description": "", "name": "feo-spush.wpo.cdngp.net"},
            "location": 3,
            "cluster": 3,
            "generate_gslb": "1", "generate_backup": "1", "rule_optimization_enabled": "1",
            "status_code": 0,
            "customer_domains": [
                {"customer_domain_name": "feo-spushtest.com",
                 "customer_origin_domain_name": "origin.feo-spushtest.com",
                 "use_cdnw_cdn": 1, "wpo_domain_type": 0}
            ],
            "wpo_rules": [{"rule_name": "inline_image", "rule_value": "2048"}]
        }

    def tearDown(self):
        if self.wid_id:
            try:
                wid = WPOWid.all_objects.get(pk=self.wid_id)
                wid.delete()
            except:
                pass

    def testFEOPush(self):
        """ add wid """
        response = self.apiclient.post('/api/wpo/wid/', self.feo_post_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.wid_id = str(response.data['wid_id'])
        wid = WPOWid.objects.get(pk=self.wid_id)
        self.assertEqual(wid.get_staging_push_type(), 'WPO Staging push')

        response = self.apiclient.delete('/api/wpo/wid/'+self.wid_id+'/', format='json')
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)

    def testCICPush(self):
        """ add wid """
        response = self.apiclient.post('/api/ic/wid/', self.cic_post_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.wid_id = str(response.data['wid_id'])
        wid = WPOWid.objects.get(pk=self.wid_id)
        self.assertEqual(wid.get_staging_push_type(), 'CIC Staging push')

        response = self.apiclient.delete('/api/ic/wid/'+self.wid_id+'/', format='json')
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)


if __name__ == "__main__":
    unittest.main()
