
import json
import unittest

from rest_framework.authtoken.models import Token
from rest_framework.test import APIClient


class TestICMonitoringClusterNodeAPI(unittest.TestCase):

    def setUp(self):

        self.auth_token = Token.objects.get(user__username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=self.auth_token.user)

    def test_cluster_node_api_response_should_be_ok(self):

        response = self.client.get('/api/ic/monitoring/node/9/')

        # response status code should be 200
        self.assertEqual(response.status_code, 200)

        response_dict = json.loads(response.content)

        node_info = response_dict.get('node_info')
        self.assertTrue(node_info is not None)

        node_info_keys = node_info.keys()
        self.assertTrue('hostname' in node_info_keys)
        self.assertTrue('node_status' in node_info_keys)
        self.assertTrue('node_name' in node_info_keys)
        self.assertTrue('node_type' in node_info_keys)
        self.assertTrue('node_id' in node_info_keys)
        self.assertTrue('ip_address' in node_info_keys)
