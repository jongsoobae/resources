

import json

import unittest

from rest_framework.authtoken.models import Token
from rest_framework.test import APIClient


class TestICMonitoringClusterAPI(unittest.TestCase):

    def setUp(self):

        self.auth_token = Token.objects.get(user__username='aurorauser')
        self.client = APIClient()
        self.client.force_authenticate(user=self.auth_token.user)

    def test_ic_monitoring_api_shows_all_cluster_info(self):

        response = self.client.get('/api/ic/monitoring/clusters/')

        # response status code should be 200
        self.assertEqual(response.status_code, 200)

        response_dict = json.loads(response.content)
        response_dict_keys = response_dict.keys()

        # "assertIsNotNone" is not supported in python 2.6 unittest
        # so use another way..
        self.assertTrue('count' in response_dict_keys)
        self.assertTrue('next' in response_dict_keys)
        self.assertTrue('previous' in response_dict_keys)
        self.assertTrue('results' in response_dict_keys)

        cluster_list = response_dict.get('results')

        # list api should returns list data
        self.assertTrue(type(cluster_list), list)
        self.assertEqual(len(cluster_list), response_dict.get('count'))

        for ic_cluster in cluster_list:
            self.assertEqual(type(ic_cluster), dict)

            # cluster_id and cluster_name should not be None
            self.assertTrue(ic_cluster.get('cluster_id') is not None)
            self.assertTrue(ic_cluster.get('cluster_name') is not None)
            self.assertTrue(ic_cluster.get('wpo_nodes') is not None)

            # test wpo_node value
            wpo_nodes = ic_cluster.get('wpo_nodes')
            self.assertEqual(type(wpo_nodes), list)

            for ic_node in wpo_nodes:
                self.assertEqual(type(ic_node), dict)
                ic_node_keys = ic_node.keys()

                self.assertTrue('node_id' in ic_node_keys)
                self.assertTrue('node_name' in ic_node_keys)
                self.assertTrue('node_type' in ic_node_keys)
                self.assertTrue('node_status' in ic_node_keys)
                self.assertTrue('ip_address' in ic_node_keys)
                self.assertTrue('hostname' in ic_node_keys)
