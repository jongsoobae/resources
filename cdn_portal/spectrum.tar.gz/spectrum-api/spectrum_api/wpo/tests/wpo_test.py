import sys, os

sys.path.insert(0, '/home/jongsoobae/portal3/spectrum-api/')
os.environ['DJANGO_SETTINGS_MODULE'] = 'spectrum_api.settings'

from django.utils import unittest
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.test import APIClient, APITransactionTestCase, APITestCase

from spectrum_api.configuration.models.config import ConfigPhase
from spectrum_api.shared_components.models import FakeRequest
from spectrum_api.shared_components.utils.user_util import putActualUserInfo
from spectrum_api.wpo.models.wpo import WPOLocation, WPOWid, WPOCustomerDomain

'''
class WPOLcationOK(unittest.TestCase):
    def setUp(self):
        test_data = {"location_name": "loc_name", "description": "desc", "obj_state": 1,
                     "date_created": "2014-06-23 00:00:00", "date_modified": "2014-06-23 00:00:00",
                     "latest_updater": "", "config_phase": 106}
        self.location = WPOLocation(
            location_name='TEST_LOCATION',
            description='for unittest',
            obj_state='1',
            date_created=datetime.now(),
            date_modified=datetime.now(),
            latest_updater='tester',
            config_phase=ConfigPhase(config_phase_id=106)
        )

    def tearDown(self):
        pass

    def test_serializer(self):
        pass
'''


class WPORollbackOK(unittest.TestCase):
    def setup(self):
        pass

    def tearDown(self):
        pass

    def test_wpo_rollback(self):
        wid_post_data = {
            "wid_name": "wpo-rollbacktest",
            "customer": 3039,
            "customer_item": 24394,
            "host_domain":
                {"domain_type": 6, "description": "", "name": "wpo-rollbacktest.wpo.cdngp.net"},
            "backup_host_domain":
                {"domain_type": 6, "description": "", "name": "backup.wpo-rollbacktest.wpo.cdngp.net"},
            "location": 33,
            "cluster": 74,
            "backup_cluster": 72,
            "generate_gslb": "1", "generate_backup": "1", "rule_optimization_enabled": "1",
            "status_code": 0,
            "customer_domains": [
                {"customer_domain_name": "wpo-rollbacktest.com",
                 "customer_origin_domain_name": "origin.wpo-rollbacktest.com",
                 "use_cdnw_cdn": 1, "wpo_domain_type": 0}
            ],
            "wpo_rules": [{"rule_name": "inline_image", "rule_value": "2048"}]
        }

        apiclient = APIClient()
        token = Token.objects.get(user__username='aurorauser')
        apiclient.credentials(HTTP_AUTHORIZATION='Token ' + token.key)

        try:
            wid = WPOWid.objects.get(wid_name='wpo-rollbacktest')
            response = apiclient.delete('/api/wpo/wid/'+str(wid.wid_id)+'/', format='json')
        except (WPOWid.DoesNotExist, Exception):
            pass

        request = FakeRequest()
        putActualUserInfo(request, token.user)

        ''' add wid '''
        response = apiclient.post('/api/wpo/wid/', wid_post_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        wid_id = str(response.data['wid_id'])
        wid = WPOWid.objects.get(wid_id=wid_id)

        ''' save snapshot '''
        wid.save_to_snapshot(request=request)

        ''' change values '''
        wid.wid_name = 'renew-wpo-rollbacktest'
        wid.generate_backup = 0
        wid.save(request=request)
        wid = WPOWid.objects.get(wid_id=wid_id)
        self.assertEqual(wid.wid_name, 'renew-wpo-rollbacktest')
        self.assertEqual(wid.generate_backup, 0)

        cdomain = wid.get_related_domains()[0]
        cdomain.customer_domain_name = 'renew-wpo-rollbacktest.com'
        cdomain.save(request=request)
        self.assertEqual(cdomain.customer_domain_name, 'renew-wpo-rollbacktest.com')

        rule = wid.get_related_rules()[0]
        rule.rule_value = '1024'
        rule.save(request=request)
        self.assertEqual(rule.rule_value, '1024')

        ''' rollback snapshot '''
        wid.rollback_from_snapshot(request=request)
        wid = WPOWid.objects.get(wid_id=wid_id)
        self.assertEqual(wid.wid_name, 'wpo-rollbacktest')
        self.assertEqual(wid.generate_backup, 1)

        cdomain = wid.get_related_domains()[0]
        self.assertEqual(cdomain.customer_domain_name, 'wpo-rollbacktest.com')

        rule = wid.get_related_rules()[0]
        self.assertEqual(rule.rule_value, '2048')

        ''' delete wid '''
        wid.save(request=request)
        response = apiclient.delete('/api/wpo/wid/'+wid_id+'/', format='json')
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)

    def test_wpo_rollback2(self):
        wid_post_data = {
            "wid_name": "wpo-rollbacktest2",
            "customer": 3039,
            "customer_item": 24394,
            "host_domain":
                {"domain_type": 6, "description": "", "name": "wpo-rollbacktest2.wpo.cdngp.net"},
            "backup_host_domain":
                {"domain_type": 6, "description": "", "name": "backup.wpo-rollbacktest2.wpo.cdngp.net"},
            "location": 33,
            "cluster": 74,
            "backup_cluster": 72,
            "generate_gslb": "1", "generate_backup": "1", "rule_optimization_enabled": "1",
            "status_code": 0,
            "customer_domains": [
                {"customer_domain_name": "wpo-rollbacktest2.com",
                 "customer_origin_domain_name": "origin.wpo-rollbacktest2.com",
                 "use_cdnw_cdn": 1, "wpo_domain_type": 0}
            ],
            "wpo_rules": [{"rule_name": "inline_image", "rule_value": "2048"}]
        }

        apiclient = APIClient()
        token = Token.objects.get(user__username='aurorauser')
        apiclient.credentials(HTTP_AUTHORIZATION='Token ' + token.key)

        try:
            wid = WPOWid.objects.get(wid_name='wpo-rollbacktest')
            response = apiclient.delete('/api/wpo/wid/'+str(wid.wid_id)+'/', format='json')
        except (WPOWid.DoesNotExist, Exception):
            pass

        request = FakeRequest()
        putActualUserInfo(request, token.user)

        ''' add wid '''
        response = apiclient.post('/api/wpo/wid/', wid_post_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        wid_id = str(response.data['wid_id'])
        wid = WPOWid.objects.get(wid_id=wid_id)

        ''' save snapshot '''
        wid.status_code = 4
        wid.save(request=request)

        ''' change values '''
        wid.wid_name = 'renew-wpo-rollbacktest2'
        wid.generate_backup = 0
        wid.save(request=request)
        wid = WPOWid.objects.get(wid_id=wid_id)
        self.assertEqual(wid.wid_name, 'renew-wpo-rollbacktest2')
        self.assertEqual(wid.generate_backup, 0)

        cdomain = wid.get_related_domains()[0]
        cdomain.customer_domain_name = 'renew-wpo-rollbacktest2.com'
        cdomain.save(request=request)
        self.assertEqual(cdomain.customer_domain_name, 'renew-wpo-rollbacktest2.com')

        rule = wid.get_related_rules()[0]
        rule.rule_value = '1024'
        rule.save(request=request)
        self.assertEqual(rule.rule_value, '1024')

        ''' rollback snapshot '''
        wid.rollback_from_snapshot(request=request)
        wid = WPOWid.objects.get(wid_id=wid_id)
        self.assertEqual(wid.wid_name, 'wpo-rollbacktest2')
        self.assertEqual(wid.generate_backup, 1)

        cdomain = wid.get_related_domains()[0]
        self.assertEqual(cdomain.customer_domain_name, 'wpo-rollbacktest2.com')

        rule = wid.get_related_rules()[0]
        self.assertEqual(rule.rule_value, '2048')

        ''' delete wid '''
        wid.save(request=request)
        response = apiclient.delete('/api/wpo/wid/'+wid_id+'/', format='json')
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)


if __name__ == "__main__":
    unittest.main()
