import sys
import os

sys.path.insert(0, '../../../')
os.environ['DJANGO_SETTINGS_MODULE'] = 'spectrum_api.settings'

from django.utils import unittest
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.test import APIClient

from spectrum_api.shared_components.models.snapshot import ProductionSnapshot
from spectrum_api.shared_components.models import FakeRequest
from spectrum_api.shared_components.utils.user_util import putActualUserInfo
from spectrum_api.wpo.models.wpo import WPOWid, WPOWidItems


class ICSuccessfulTest(unittest.TestCase):
    def setUp(self):
        self.apiclient = APIClient()
        token = Token.objects.get(user__username='aurorauser')
        self.apiclient.credentials(HTTP_AUTHORIZATION='Token ' + token.key)
        self.request = FakeRequest()
        putActualUserInfo(self.request, token.user)

        # need to change values by environment. ############################
        self.config_phase_id = 130  # used at add location
        self.modify_config_phase_id = 131  # used at modify location
        self.node_vip_id1 = 65306
        self.node_vip_id2 = 54672
        self.customer_id = 3132
        self.item_id = 27805
        self.item_id2 = 27954
        #####################################################################

        self.location_id = 0
        self.cluster_id = 0

    def tearDown(self):
        response = self.apiclient.delete('/api/ic/wid/'+str(self.wid_id)+'/', format='json')
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)

        response = self.apiclient.delete('/api/ic/clusters/'+str(self.cluster_id)+'/', format='json')
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)

        response = self.apiclient.delete('/api/ic/locations/'+str(self.location_id)+'/', format='json')
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)

    def _location(self):
        input_data = {"location_id": "0", "location_name": "test_ic_kr1", "config_phase": self.config_phase_id, "description": ""}
        response = self.apiclient.post('/api/ic/locations/', input_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.location_id = response.data['location_id']

        modify_data = {"location_id": self.location_id, "location_name": "test_ic_kr2", "config_phase": self.modify_config_phase_id, "description": ""}
        response = self.apiclient.patch('/api/ic/locations/'+str(self.location_id)+'/', modify_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def _cluster(self):
        input_data = {
            'description': '',
            'primary_cluster_domain': {'domain_type': 6, 'name': 'test_ic_cluster1.ic-cluster.cdngp.net'},
            'staging_cluster_domain': {'domain_type': 6, 'name': 'staging.test_ic_cluster1.ic-cluster.cdngp.net'},
            'cluster_name': 'test_ic_cluster1',
            'cluster_id': '0',
            'generate_gslb': '1',
            'wpo_location': self.location_id,
        }

        response = self.apiclient.post('/api/ic/clusters/', input_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.cluster_id = response.data['cluster_id']

    def _node1(self):
        input_data = {
            'description': '', 'node_type': 0, 'vip': self.node_vip_id1,
            'wpo_cluster': self.cluster_id}
        response = self.apiclient.post('/api/ic/nodes/', input_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.node_id1 = response.data['node_id']

        modify_data = {
            'node_id': self.node_id1,
            'wpo_cluster': self.cluster_id,
            'description': '', 'node_type': 1, 'vip': self.node_vip_id1}
        response = self.apiclient.patch('/api/ic/nodes/'+str(self.node_id1)+'/', modify_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def _node2(self):
        input_data = {
            'description': '', 'node_type': 0, 'vip': self.node_vip_id2, 'wpo_cluster': self.cluster_id}
        response = self.apiclient.post('/api/ic/nodes/', input_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.node_id2 = response.data['node_id']

    def _wid(self):
        input_data = {
            "customer": self.customer_id,
            "wid_name": "test_ic1_wid",
            "customer_domains": [
                {"use_cdnw_cdn": 1, "wpo_domain_type": 0, "customer_origin_domain_name": "test.ic1.origin.cdomain.com", "customer_domain_name": "test.ic1.cdomain.com", "retry": 10}],
            "rule_optimization_enabled": 1,
            "host_domain": {"domain_type": 6, "name": "test_ic1_wid.ic.cdngp.net"},
            "cluster": self.cluster_id,
            "domain_protocol": "http",
            "location": self.location_id,
            "generate_gslb": "1",
            "wid_items": [
                {"item": self.item_id},
                {"item": self.item_id2}
            ]
        }

        response = self.apiclient.post("/api/ic/wid/", input_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.wid_id = response.data['wid_id']

        wid = WPOWid.objects.get(pk=self.wid_id)

        items = ProductionSnapshot.objects.filter(snapshot_model=unicode(WPOWidItems.__name__),
                                                  parent_model=unicode(WPOWid.__name__),
                                                  parent_model_pk=self.wid_id)
        self.assertFalse(items.exists())
        wid.save_to_snapshot(request=self.request)

        items = ProductionSnapshot.objects.filter(snapshot_model=unicode(WPOWidItems.__name__),
                                                  parent_model=unicode(WPOWid.__name__),
                                                  parent_model_pk=self.wid_id)

        wid_items = WPOWidItems.objects.filter(wid=self.wid_id)
        self.assertEqual(items.count(), wid_items.count())
        wid_items.delete()

        ''' change values '''
        wid.wid_name = 'renew-ic-rollbacktest'
        wid.generate_backup = 0
        wid.save(request=self.request)
        wid = WPOWid.objects.get(wid_id=self.wid_id)
        self.assertEqual(wid.wid_name, 'renew-ic-rollbacktest')
        self.assertEqual(wid.generate_backup, 0)

        ''' rollback snapshot '''
        wid.rollback_from_snapshot(request=self.request)
        wid = WPOWid.objects.get(wid_id=self.wid_id)
        self.assertEqual(wid.wid_name, 'test_ic1_wid')
        self.assertEqual(wid.generate_backup, 1)

        wid_items = WPOWidItems.objects.filter(wid=self.wid_id)
        self.assertEqual(items.count(), wid_items.count())

    def test_successful_flow(self):
        self._location()
        self._cluster()
        self._node1()
        self._node2()
        self._wid()


if __name__ == "__main__":
    unittest.main()
