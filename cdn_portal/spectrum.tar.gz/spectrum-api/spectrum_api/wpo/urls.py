# -*- coding: utf-8 -*-
from django.conf.urls.defaults import *
from rest_framework.urlpatterns import format_suffix_patterns
from spectrum_api.wpo.views.ic_audit import ICAuditAPI
from spectrum_api.wpo.views.ic_cluster import ICLocationAPI, ICLocationDetailAPI, ICLocationDeletableAPI, \
    ICLocationRelatedAPI, ICClusterAPI, ICClusterDetailAPI, ICClusterDeletableAPI, ICClusterRelatedAPI, ICNodeAPI, \
    ICNodeDetailAPI
from spectrum_api.wpo.views.ic_wid import ICCustomerDomainAPI, ICCustomerDomainDetailAPI, ICCustomerDomainDeletableAPI, \
    ICWidAPI, ICWidDetailAPI, ICWidBackupAPI, ICWidRollbackAPI, ICWidRuleTextAPI, ICWidStatusAPI, ICWidRestoreAPI, \
    ICCodeAPI, ICResourceAPI, ICCustomerAPI, ICContractAPI, ICContractItemAPI
from spectrum_api.wpo.views.wpo_audit import WPOAuditAPI
from spectrum_api.wpo.views.wpo_cluster \
    import WPOLocationAPI, WPOLocationDetailAPI, WPOLocationDeletableAPI,\
    WPOClusterAPI, WPOClusterDetailAPI, WPOClusterDeletableAPI, WPOClusterRelatedAPI,\
    WPONodeAPI, WPONodeDetailAPI, WPOLocationRelatedAPI
from spectrum_api.wpo.views.wpo_wid import WPOCustomerDomainAPI, WPOCustomerDomainDetailAPI, \
    WPOCustomerDomainDeletableAPI, WPOWidAPI, WPOWidDetailAPI, WPOCodeAPI, WPOWidStatusAPI, WPOWidRollbackAPI, \
    WPOWidBackupAPI, WPOWidRuleTextAPI, WPOWidRestoreAPI, WPOResourceAPI, WPOCustomerAPI, WPOContractAPI, \
    WPOContractItemAPI

from spectrum_api.wpo.views.ic_monitoring import ICMonitoringClusterAPI
from spectrum_api.wpo.views.ic_monitoring import ICMonitoringClusterNodeAPI


restfw_api_urlpatterns = patterns(
    'spectrum_api.wpo.views',
    url(r'^wpo/locations/$', WPOLocationAPI.as_view(), name="wpo-locations"),
    url(r'^wpo/locations/(?P<location_id>[0-9]+)/$', WPOLocationDetailAPI.as_view(), name="wpo-locations-detail"),
    url(r'^wpo/locations/(?P<location_id>[0-9]+)/deletable/$',
        WPOLocationDeletableAPI.as_view(), name="wpo-locations-deletable"),
    url(r'^wpo/locations/(?P<location_id>[0-9]+)/related/$',
        WPOLocationRelatedAPI.as_view(), name="wpo-locations-related"),

    url(r'^wpo/clusters/$', WPOClusterAPI.as_view(), name="wpo-clusters"),
    url(r'^wpo/clusters/(?P<cluster_id>[0-9]+)/$', WPOClusterDetailAPI.as_view(), name="wpo-clusters-detail"),
    url(r'^wpo/clusters/(?P<cluster_id>[0-9]+)/deletable/$',
        WPOClusterDeletableAPI.as_view(), name="wpo-clusters-deletable"),
    url(r'^wpo/clusters/(?P<cluster_id>[0-9]+)/related/$',
        WPOClusterRelatedAPI.as_view(), name="wpo-clusters-related"),

    url(r'^wpo/nodes/$', WPONodeAPI.as_view(), name="wpo-nodes"),
    url(r'^wpo/nodes/(?P<node_id>[0-9]+)/$', WPONodeDetailAPI.as_view(), name="wpo-nodes-detail"),

    url(r'^wpo/customerdomains/$', WPOCustomerDomainAPI.as_view(), name="wpo-cdomains"),
    url(r'^wpo/customerdomains/(?P<id>[0-9]+)/$', WPOCustomerDomainDetailAPI.as_view(), name="wpo-cdomains-detail"),
    url(r'^wpo/customerdomains/(?P<id>[0-9]+)/deletable/$',
        WPOCustomerDomainDeletableAPI.as_view(), name="wpo-cdomains-deletable"),

    url(r'^wpo/wid/$', WPOWidAPI.as_view(), name="wpo-wid"),
    url(r'^wpo/wid/(?P<wid_id>[0-9]+)/$', WPOWidDetailAPI.as_view(), name="wpo-wid-detail"),
    url(r'^wpo/wid/(?P<wid_id>[0-9]+)/backup/$', WPOWidBackupAPI.as_view(), name="wpo-wid-backup"),
    url(r'^wpo/wid/(?P<wid_id>[0-9]+)/rollback/$', WPOWidRollbackAPI.as_view(), name="wpo-wid-rollback"),
    url(r'^wpo/wid/(?P<wid_id>[0-9]+)/ruletext/$', WPOWidRuleTextAPI.as_view(), name="wpo-wid-ruletext"),
    url(r'^wpo/wid_status/(?P<wid_id>[0-9]+)/$', WPOWidStatusAPI.as_view(), name="wpo-wid-status"),
    url(r'^wpo/wid/restore/$', WPOWidRestoreAPI.as_view(), name="wpo-wid-restore"),

    url(r'^wpo/code/$', WPOCodeAPI.as_view(), name="wpo-code"),

    url(r'^wpo/audit/$', WPOAuditAPI.as_view(), name="wpo-audit"),
    url(r'^wpo/resource/$', WPOResourceAPI.as_view(), name="wpo-resource"),

    url(r'^wpo/customer/$', WPOCustomerAPI.as_view(), name="wpo-customer"),
    url(r'^wpo/contract/$', WPOContractAPI.as_view(), name="wpo-contract"),
    url(r'^wpo/contract/items/$', WPOContractItemAPI.as_view(), name="wpo-contract-item"),

    # for Image Converter

    url(r'^ic/locations/$', ICLocationAPI.as_view(), name="ic-locations"),
    url(r'^ic/locations/(?P<location_id>[0-9]+)/$', ICLocationDetailAPI.as_view(), name="ic-locations-detail"),
    url(r'^ic/locations/(?P<location_id>[0-9]+)/deletable/$',
        ICLocationDeletableAPI.as_view(), name="ic-locations-deletable"),
    url(r'^ic/locations/(?P<location_id>[0-9]+)/related/$',
        ICLocationRelatedAPI.as_view(), name="ic-locations-related"),

    url(r'^ic/clusters/$', ICClusterAPI.as_view(), name="ic-clusters"),
    url(r'^ic/clusters/(?P<cluster_id>[0-9]+)/$', ICClusterDetailAPI.as_view(), name="ic-clusters-detail"),
    url(r'^ic/clusters/(?P<cluster_id>[0-9]+)/deletable/$',
        ICClusterDeletableAPI.as_view(), name="ic-clusters-deletable"),
    url(r'^ic/clusters/(?P<cluster_id>[0-9]+)/related/$',
        ICClusterRelatedAPI.as_view(), name="ic-clusters-related"),

    url(r'^ic/nodes/$', ICNodeAPI.as_view(), name="ic-nodes"),
    url(r'^ic/nodes/(?P<node_id>[0-9]+)/$', ICNodeDetailAPI.as_view(), name="ic-nodes-detail"),

    url(r'^ic/customerdomains/$', ICCustomerDomainAPI.as_view(), name="ic-cdomains"),
    url(r'^ic/customerdomains/(?P<id>[0-9]+)/$', ICCustomerDomainDetailAPI.as_view(), name="ic-cdomains-detail"),
    url(r'^ic/customerdomains/(?P<id>[0-9]+)/deletable/$',
        ICCustomerDomainDeletableAPI.as_view(), name="ic-cdomains-deletable"),

    url(r'^ic/wid/$', ICWidAPI.as_view(), name="ic-wid"),
    url(r'^ic/wid/(?P<wid_id>[0-9]+)/$', ICWidDetailAPI.as_view(), name="ic-wid-detail"),
    url(r'^ic/wid/(?P<wid_id>[0-9]+)/backup/$', ICWidBackupAPI.as_view(), name="ic-wid-backup"),
    url(r'^ic/wid/(?P<wid_id>[0-9]+)/rollback/$', ICWidRollbackAPI.as_view(), name="ic-wid-rollback"),
    url(r'^ic/wid/(?P<wid_id>[0-9]+)/ruletext/$', ICWidRuleTextAPI.as_view(), name="ic-wid-ruletext"),
    url(r'^ic/wid_status/(?P<wid_id>[0-9]+)/$', ICWidStatusAPI.as_view(), name="ic-wid-status"),
    url(r'^ic/wid/restore/$', ICWidRestoreAPI.as_view(), name="ic-wid-restore"),

    url(r'^ic/code/$', ICCodeAPI.as_view(), name="ic-code"),

    url(r'^ic/audit/$', ICAuditAPI.as_view(), name="ic-audit"),
    url(r'^ic/resource/$', ICResourceAPI.as_view(), name="ic-resource"),

    url(r'^ic/customer/$', ICCustomerAPI.as_view(), name="ic-customer"),
    url(r'^ic/contract/$', ICContractAPI.as_view(), name="ic-contract"),
    url(r'^ic/contract/items/$', ICContractItemAPI.as_view(), name="ic-contract-item"),

    # CIC Monitoring API
    url(
        ## GET : returns all of ic cluster node's metric data
        regex=r'^ic/monitoring/clusters/$',
        view=ICMonitoringClusterAPI.as_view(),
        name="ic-monitor-cluster-list"),

    url(
        ## GET : returns ic cluster node's metric data which is matched with [node_id]
        regex=r'^ic/monitoring/node/(?P<node_id>[0-9]+)/$',
        view=ICMonitoringClusterNodeAPI.as_view(),
        name="ic-monitor-cluster-detail")

)
urlpatterns = format_suffix_patterns(restfw_api_urlpatterns)