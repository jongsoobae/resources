from __future__ import absolute_import
from django.core.exceptions import ObjectDoesNotExist
from django.http import Http404
from spectrum_api.configuration.models.node_mon import DomainStatus
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.mixins \
    import CreateModelMixin, UpdateModelMixin, DestroyModelMixin, ListModelMixin, RetrieveModelMixin

from spectrum_api.wpo.models.wpo import WPOLocation, WPOCluster, WPONode, WPOWid, WPO_TYPE_IC
from spectrum_api.wpo.serializers.wpo_cluster \
    import WPOClusterSerializer, WPONodeSerializer, WPOLocationSerializer, \
    WPOLocationDeletableSerializer, WPOClusterDeletableSerializer, \
    WPOClusterRelatedSerializer, WPOLocationRelatedSerializer

from rest_framework import status
from rest_framework.response import Response

from django.db import transaction

from spectrum_api.configuration.models.base import BaseVipEdge
from spectrum_api.dna.models.domain import DomainEdge
from spectrum_api.wpo.views.wpo_common import WPOAPIException, WPOAPICustomException


"""""""""""""""""""""""""""""""""""""""""""""
  WPO Location
"""""""""""""""""""""""""""""""""""""""""""""


class ICLocationAPI(ListModelMixin,
                    CreateModelMixin,
                    SpectrumGenericAPIView):
    def __init__(self):
        super(ICLocationAPI, self).__init__()
        self.queryset = WPOLocation.objects.filter(wpo_type=2)
        self.serializer_class = WPOLocationSerializer
        self.lookup_url_kwarg = "location_id"
        self.search_fields = ("location_name", "description")

    def get(self, request, *args, **kwargs):
        return super(ICLocationAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        request.DATA['wpo_type'] = WPO_TYPE_IC[0]
        return super(ICLocationAPI, self).create(request, *args, **kwargs)


class ICLocationDetailAPI(RetrieveModelMixin,
                          UpdateModelMixin,
                          DestroyModelMixin,
                          SpectrumGenericAPIView):
    def __init__(self):
        super(ICLocationDetailAPI, self).__init__()
        self.queryset = WPOLocation.objects.filter(obj_state=1, wpo_type=2).all()
        self.serializer_class = WPOLocationSerializer
        self.lookup_url_kwarg = 'location_id'

    def get(self, request, *args, **kwargs):
        return super(ICLocationDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ICLocationDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ICLocationDetailAPI, self).partial_update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        return super(ICLocationDetailAPI, self).destroy(request, *args, **kwargs)


class ICLocationDeletableAPI(RetrieveModelMixin,
                             SpectrumGenericAPIView):
    def __init__(self):
        super(ICLocationDeletableAPI, self).__init__()
        self.queryset = WPOLocation.objects.filter(obj_state=1, wpo_type=2).all()
        self.serializer_class = WPOLocationDeletableSerializer
        self.lookup_url_kwarg = 'location_id'

    def get(self, request, *args, **kwargs):
        return super(ICLocationDeletableAPI, self).retrieve(request, *args, **kwargs)


class ICLocationRelatedAPI(RetrieveModelMixin,
                           SpectrumGenericAPIView):
    def __init__(self):
        super(ICLocationRelatedAPI, self).__init__()
        self.queryset = WPOLocation.objects.filter(obj_state=1, wpo_type=2).all()
        self.serializer_class = WPOLocationRelatedSerializer
        self.lookup_url_kwarg = 'location_id'

    def get(self, request, *args, **kwargs):
        return super(ICLocationRelatedAPI, self).retrieve(request, *args, **kwargs)


"""""""""""""""""""""""""""""""""""""""""""""
  IC Cluster
"""""""""""""""""""""""""""""""""""""""""""""


class ICClusterAPI(ListModelMixin,
                   CreateModelMixin,
                   SpectrumGenericAPIView):
    def __init__(self):
        super(ICClusterAPI, self).__init__()
        self.queryset = WPOCluster.objects.filter(wpo_location__wpo_type=2)
        self.serializer_class = WPOClusterSerializer
        self.lookup_url_kwarg = "cluster_id"
        self.search_fields = ("cluster_name",)
        self.filter_fields = ("wpo_location", "config_state",)

    def get(self, request, *args, **kwargs):
        self.object_list = self.filter_queryset(self.get_queryset())

        # Default is to allow empty querysets.  This can be altered by setting
        # `.allow_empty = False`, to raise 404 errors on empty querysets.
        if not self.allow_empty and not self.object_list:
            class_name = self.__class__.__name__
            error_msg = self.empty_error % {'class_name': class_name}
            raise Http404(error_msg)

        # Switch between paginated or standard style responses
        page = self.paginate_queryset(self.object_list)
        if page is not None:
            serializer = self.get_pagination_serializer(page)
        else:
            serializer = self.get_serializer(self.object_list, many=True)

        try:
            results = serializer.data['results']
        except (Exception, TypeError):
            results = serializer.data

        domain_ids = []
        cluster_lists = {}
        for result in results:
            res_domain_id = result['primary_cluster_domain']['domain_id']
            domain_ids.append(res_domain_id)

        for obj in self.object_list:
            cluster_lists[obj.primary_cluster_domain.pk] = obj

        active_counts = {}
        for active_count in DomainStatus.objects.filter(domain_id__in=domain_ids):
            active_counts[active_count.domain_id] = (active_count.active_count if active_count.active_count else 0)

        for result in results:
            res_domain_id = result['primary_cluster_domain']['domain_id']
            res_str = "S: %s P: %s / T: %s" % \
                      (
                          WPONode.objects.filter(wpo_cluster=cluster_lists[res_domain_id], node_type=1).count(),
                          str(active_counts[res_domain_id]),
                          WPONode.objects.filter(wpo_cluster=cluster_lists[res_domain_id]).count()
                      )
            result['connectivity'] = res_str

        return Response(serializer.data)

    @transaction.commit_on_success
    def post(self, request, *args, **kwargs):
        try:
            return super(ICClusterAPI, self).create(request, *args, **kwargs)
        except ObjectDoesNotExist, de:
            transaction.rollback()
            return Response(data=de.args, status=status.HTTP_400_BAD_REQUEST)


class ICClusterDetailAPI(RetrieveModelMixin,
                         UpdateModelMixin,
                         DestroyModelMixin,
                         SpectrumGenericAPIView):
    def __init__(self):
        super(ICClusterDetailAPI, self).__init__()
        self.queryset = WPOCluster.objects.filter(obj_state=1, wpo_location__wpo_type=2).all()
        self.serializer_class = WPOClusterSerializer
        self.lookup_url_kwarg = "cluster_id"

    def get(self, request, *args, **kwargs):
        return super(ICClusterDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ICClusterDetailAPI, self).update(request, *args, **kwargs)

    @transaction.commit_on_success
    def patch(self, request, *args, **kwargs):
        try:
            return super(ICClusterDetailAPI, self).update(request, *args, **kwargs)
        except ObjectDoesNotExist, de:
            transaction.rollback()
            return Response(data=de.args, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, *args, **kwargs):
        return super(ICClusterDetailAPI, self).destroy(request, *args, **kwargs)


class ICClusterDeletableAPI(RetrieveModelMixin,
                            SpectrumGenericAPIView):
    def __init__(self):
        super(ICClusterDeletableAPI, self).__init__()
        self.queryset = WPOCluster.objects.filter(obj_state=1, wpo_location__wpo_type=2).all()
        self.serializer_class = WPOClusterDeletableSerializer
        self.lookup_url_kwarg = 'cluster_id'

    def get(self, request, *args, **kwargs):
        return super(ICClusterDeletableAPI, self).retrieve(request, *args, **kwargs)


class ICClusterRelatedAPI(RetrieveModelMixin,
                          SpectrumGenericAPIView):
    def __init__(self):
        super(ICClusterRelatedAPI, self).__init__()
        self.queryset = WPOCluster.objects.filter(obj_state=1, wpo_location__wpo_type=2).all()
        self.serializer_class = WPOClusterRelatedSerializer
        self.lookup_url_kwarg = 'cluster_id'

    def get(self, request, *args, **kwargs):
        return super(ICClusterRelatedAPI, self).retrieve(request, *args, **kwargs)


"""""""""""""""""""""""""""""""""""""""""""""
  IC Node
"""""""""""""""""""""""""""""""""""""""""""""


class ICNodeAPI(ListModelMixin,
                CreateModelMixin,
                SpectrumGenericAPIView):
    def __init__(self):
        super(ICNodeAPI, self).__init__()
        self.queryset = WPONode.objects.filter(wpo_cluster__wpo_location__wpo_type=2)
        self.lookup_url_kwarg = "node_id"
        self.serializer_class = WPONodeSerializer
        self.filter_fields = ('node_name', 'wpo_cluster')

    def get(self, request, *args, **kwargs):
        return super(ICNodeAPI, self).list(request, *args, **kwargs)

    @transaction.commit_on_success
    def post(self, request, *args, **kwargs):
        try:
            return super(ICNodeAPI, self).create(request, *args, **kwargs)
        except ObjectDoesNotExist, de:
            transaction.rollback()
            return Response(data=de.args, status=status.HTTP_400_BAD_REQUEST)

    def post_save(self, obj, created=False):
        obj.wpo_cluster.save(request=self.request)


class ICNodeDetailAPI(RetrieveModelMixin,
                      UpdateModelMixin,
                      DestroyModelMixin,
                      SpectrumGenericAPIView):
    def __init__(self):
        super(ICNodeDetailAPI, self).__init__()
        self.queryset = WPONode.objects.filter(obj_state=1, wpo_cluster__wpo_location__wpo_type=2).all()
        self.serializer_class = WPONodeSerializer
        self.lookup_url_kwarg = "node_id"

    def get(self, request, *args, **kwargs):
        return super(ICNodeDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ICNodeDetailAPI, self).update(request, *args, **kwargs)

    @transaction.commit_on_success
    def patch(self, request, *args, **kwargs):
        try:
            return super(ICNodeDetailAPI, self).partial_update(request, *args, **kwargs)
        except ObjectDoesNotExist, de:
            transaction.rollback()
            return Response(data=de.args, status=status.HTTP_400_BAD_REQUEST)
        except WPOAPICustomException, we:
            transaction.rollback()
            return Response(data=we.fail_data, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, *args, **kwargs):
        return super(ICNodeDetailAPI, self).destroy(request, *args, **kwargs)

    def pre_save(self, obj):
        self.check_cluster_config_state(obj)

    def post_save(self, obj, created=False):
        # when modify, if cluster is in wid, it cannot deactivated.
        # if cluster is not in wid, change cluster's activate status.
        # when node change , cluster_nodes only remain (WPO or STAGING) type
        # cleanup domainedge and baseedge related edge
        if not created:
            try:
                if not WPONode.objects.filter(wpo_cluster=obj.wpo_cluster, node_type=0).exists():
                    DomainEdge.objects.filter(edge=obj.wpo_cluster.edge).delete()

                if not WPONode.objects.filter(wpo_cluster=obj.wpo_cluster, node_type=1).exists():
                    DomainEdge.objects.filter(edge=obj.wpo_cluster.get_staging_edge(),
                                              domain=obj.wpo_cluster.staging_cluster_domain).delete()
            except Exception, e:
                pass
            obj.wpo_cluster.save(request=self.request)

    def pre_delete(self, obj):
        self.check_cluster_config_state(obj)

    @staticmethod
    def check_cluster_config_state(obj):
        wpo_node_count = WPONode.objects.filter(node_type=0, wpo_cluster=obj.wpo_cluster)\
            .exclude(pk=obj.node_id).count()
        staging_node_count = WPONode.objects.filter(node_type=1, wpo_cluster=obj.wpo_cluster)\
            .exclude(pk=obj.node_id).count()
        if obj.node_type == 0:
            wpo_node_count += 1
        else:
            staging_node_count += 1

        cluster_exist = WPOWid.objects.filter(cluster=obj.wpo_cluster).exists()
        backup_cluster_exist = WPOWid.objects.filter(backup_cluster=obj.wpo_cluster).exists()
        if cluster_exist or backup_cluster_exist:
            #it cannot deactivated.
            if wpo_node_count <= 0 or staging_node_count <= 0:
                raise WPOAPIException(
                    status.HTTP_400_BAD_REQUEST,
                    'This cluster is used by WIDs. Cannot delete this node because cluster will be deactivated.')

    def post_delete(self, obj):
        obj.wpo_cluster.save(request=self.request)
        try:
            if obj.node_type == 0:
                vip_edge = BaseVipEdge.objects.get(vip=obj.vip, edge=obj.get_edge())
                vip_edge.delete()
            else:
                if not WPONode.objects.filter(vip=obj.vip, node_type=1).exists():
                    BaseVipEdge.objects.filter(vip=obj.vip, edge=obj.wpo_cluster.get_staging_edge()).delete()
        except BaseVipEdge.DoesNotExist:
            pass

        if not WPONode.objects.filter(wpo_cluster=obj.wpo_cluster, node_type=obj.node_type).exists():
            try:
                domain_edge = DomainEdge.objects.get(domain=obj.get_domain(), edge=obj.get_edge())
                domain_edge.delete()
            except DomainEdge.DoesNotExist:
                pass