
from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.mixins import ListModelMixin
from spectrum_api.shared_components.mixins import RetrieveModelMixin

from spectrum_api.wpo.models.wpo import WPOCluster
from spectrum_api.wpo.models.wpo import WPONode

from spectrum_api.wpo.serializers.ic_monitoring import ICMonitoringClusterSerializer
from spectrum_api.wpo.serializers.ic_monitoring import ICMonitoringClusterNodeSerializer


class ICMonitoringClusterAPI(SpectrumGenericAPIView,
                             ListModelMixin):

    queryset = WPOCluster.objects.filter(wpo_location__wpo_type=2)
    serializer_class = ICMonitoringClusterSerializer

    def get(self, request, *args, **kwargs):
        return super(ICMonitoringClusterAPI, self).list(request, *args, **kwargs)


class ICMonitoringClusterNodeAPI(SpectrumGenericAPIView,
                                 RetrieveModelMixin):

    queryset = WPONode.objects.filter(wpo_cluster__wpo_location__wpo_type=2)
    lookup_url_kwarg = "node_id"
    serializer_class = ICMonitoringClusterNodeSerializer

    def get(self, request, *args, **kwargs):
        return super(ICMonitoringClusterNodeAPI, self).retrieve(request, *args, **kwargs)
