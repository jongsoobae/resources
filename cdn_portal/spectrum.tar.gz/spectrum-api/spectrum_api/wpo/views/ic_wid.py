from __future__ import absolute_import
import copy
from datetime import datetime

from django.core.exceptions import ObjectDoesNotExist, ValidationError
from rest_framework import status
from rest_framework.response import Response
from django.db import transaction, IntegrityError
from spectrum_api.dna.models.domain import Domain
from spectrum_api.settings import IC_MATERIAL

from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.mixins \
    import CreateModelMixin, UpdateModelMixin, DestroyModelMixin, ListModelMixin, RetrieveModelMixin
from spectrum_api.shared_components.models.customer import CustomerDisplay
from spectrum_api.shared_components.models.customer import CustomerItem
from spectrum_api.wpo import resources
from spectrum_api.wpo.models.wpo import WPOCustomerDomain, WPOWid, \
    WPOCode, WPORule, WPOHistory, WPO_TYPES_DICT, WPO_TYPE_IC, WPOWidItems
from spectrum_api.wpo.serializers.wpo_wid import WPOCustomerDomainSerializer, WPOCustomerDomainDeletableSerializer, \
    WPOWidSerializer, WPOCodeSerializer, WPOWidStatusSerializer, WPOWidRuleTextSerializer, WPOCustomerSerializer, \
    WPOContractSerializer
from spectrum_api.wpo.views.wpo_common import WPOAPIException, WPOAPICustomException


WPO_SHARD_DOMAIN_CODE_ID = 705


"""""""""""""""""""""""""""""""""""""""""""""
  WPO Customer Domain
"""""""""""""""""""""""""""""""""""""""""""""


class ICCustomerDomainAPI(ListModelMixin,
                          CreateModelMixin,
                          SpectrumGenericAPIView):
    def __init__(self):
        super(ICCustomerDomainAPI, self).__init__()
        self.queryset = WPOCustomerDomain.objects.filter(wid__wpo_type=2)
        self.serializer_class = WPOCustomerDomainSerializer
        self.lookup_url_kwarg = "id"
        self.search_fields = ("customer_domain_name",)
        self.filter_fields = ('wid', 'customer_domain_name')

    def get(self, request, *args, **kwargs):
        return super(ICCustomerDomainAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(ICCustomerDomainAPI, self).create(request, *args, **kwargs)


class ICCustomerDomainDetailAPI(RetrieveModelMixin,
                                UpdateModelMixin,
                                DestroyModelMixin,
                                SpectrumGenericAPIView):
    def __init__(self):
        super(ICCustomerDomainDetailAPI, self).__init__()
        self.queryset = WPOCustomerDomain.objects.filter(obj_state=1, wid__wpo_type=2).all()
        self.serializer_class = WPOCustomerDomainSerializer
        self.lookup_url_kwarg = 'id'

    def get(self, request, *args, **kwargs):
        return super(ICCustomerDomainDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return super(ICCustomerDomainDetailAPI, self).update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return super(ICCustomerDomainDetailAPI, self).partial_update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        return super(ICCustomerDomainDetailAPI, self).destroy(request, *args, **kwargs)


class ICCustomerDomainDeletableAPI(RetrieveModelMixin,
                                   SpectrumGenericAPIView):
    def __init__(self):
        super(ICCustomerDomainDeletableAPI, self).__init__()
        self.queryset = WPOCustomerDomain.objects.filter(obj_state=1, wid__wpo_type=2).all()
        self.serializer_class = WPOCustomerDomainDeletableSerializer
        self.lookup_url_kwarg = 'id'

    def get(self, request, *args, **kwargs):
        return super(ICCustomerDomainDeletableAPI, self).retrieve(request, *args, **kwargs)


"""""""""""""""""""""""""""""""""""""""""""""
  WPO Wid
"""""""""""""""""""""""""""""""""""""""""""""


class ICWidRestoreAPI(CreateModelMixin,
                      SpectrumGenericAPIView):
    def __init__(self):
        super(ICWidRestoreAPI, self).__init__()
        self.queryset = WPOWid.all_objects.filter(wpo_type=2)
        self.serializer_class = WPOWidSerializer
        self.lookup_url_kwarg = "wid_id"

    @transaction.commit_on_success
    def post(self, request, *args, **kwargs):
        request.DATA['wpo_type'] = WPO_TYPE_IC[0]
        try:
            # select duplicated
            wids = WPOWid.all_objects.filter(wid_name=self.request.DATA['wid_name'], wpo_type=2,
                                             obj_state=0)

            if not wids.exists():
                return Response({'detail': 'There is no duplicated item.'}, status=status.HTTP_404_NOT_FOUND)
            wid = wids[0]

            serializer = self.get_serializer(data=request.DATA, files=request.FILES)
            if not serializer.is_valid():
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            if wid.customer.pk == request.DATA.get('customer'):
                self.restore_wid(wid=wid)
                self.post_save(wid)
                return Response(
                    {'detail': 'Wid(%s) is successfully restored.' % wid.pk,
                     'wid_id': wid.pk,
                     'wid_name': wid.wid_name},
                    status=status.HTTP_201_CREATED)
            else:
                wids.update(
                    wid_name='%s.deleted.%s'
                             % (wid.wid_name, datetime.utcnow().strftime('%Y%m%d%H%M%S'))
                )
                return super(ICWidRestoreAPI, self).create(request, *args, **kwargs)
        except IntegrityError, e:
            if e.args[0] == 1062:
                error_message = e.args[1]
            elif e.message:
                error_message = e.message
            else:
                error_message = e.args[1]
            raise WPOAPIException(status.HTTP_500_INTERNAL_SERVER_ERROR, error_message)
        except Exception, e:
            return Response({'detail': e.args}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def post_save(self, obj, created=False):
        try:
            WPOWid.objects.filter(pk=obj.pk).update(
                optimization_rule_text=obj.generate_rule_text(),
                staging_optimization_rule_text=obj.generate_staging_rule_text())
        except (Exception, ):
            pass
        WPOHistory(wid=obj, type=4).save(request=self.request)

    def restore_wid(self, wid, request=None):
        if request is None:
            request = self.request
        # create domain
        host_domain_data = request.DATA.get('host_domain')
        backup_host_domain_data = request.DATA.get('backup_host_domain')
        cluster_pk = request.DATA.get('cluster')
        backup_cluster_pk = request.DATA.get('backup_cluster')
        customer_pk = request.DATA.get('customer')
        item_pk = request.DATA.get('customer_item')
        location_pk = request.DATA.get('location')

        host_domain = Domain()
        host_domain.domain_type = host_domain_data.get('domain_type')
        host_domain.description = host_domain_data.get('description')
        host_domain.name = host_domain_data.get('name')

        backup_host_domain = None

        if backup_host_domain_data and backup_host_domain_data.get('name'):
            backup_host_domain = Domain()
            backup_host_domain.domain_type = backup_host_domain_data.get('domain_type')
            backup_host_domain.description = backup_host_domain_data.get('description')
            backup_host_domain.name = backup_host_domain_data.get('name')
            backup_host_domain.save(request=request)

        host_domain.save(request=request)

        # create customer_domain
        cdomains_data = request.DATA.get('customer_domains')

        if not isinstance(cdomains_data, list):
            raise WPOAPIException(status.HTTP_500_INTERNAL_SERVER_ERROR, 'customer_domains is invalid.')

        for cdomain_data in cdomains_data:
            cd = WPOCustomerDomain()
            cd.customer_domain_name = cdomain_data.get('customer_domain_name')
            cd.customer_origin_domain_name = cdomain_data.get('customer_origin_domain_name')
            cd.use_cdnw_cdn = cdomain_data.get('use_cdnw_cdn')
            cd.wpo_domain_type = cdomain_data.get('wpo_domain_type')
            cd.wid = wid
            cd.save(request=request)

        # update & restore
        wid.host_domain = host_domain
        if backup_host_domain:
            wid.backup_host_domain = backup_host_domain
        wid.cluster_id = cluster_pk
        wid.obj_state = 1
        wid.location_id = location_pk
        wid.customer_id = customer_pk
        wid.customer_item_id = item_pk
        wid.backup_cluster_id = backup_cluster_pk
        wid.save(request=request)

        wid.touch_staging_domains_for_gslb(request=request)
        WPOWid.objects.filter(pk=wid.pk).update(
            optimization_rule_text=wid.generate_rule_text(),
            staging_optimization_rule_text=wid.generate_staging_rule_text())


class ICWidAPI(ListModelMixin,
               CreateModelMixin,
               UpdateModelMixin,
               SpectrumGenericAPIView):
    def __init__(self):
        super(ICWidAPI, self).__init__()
        self.queryset = WPOWid.objects.filter(wpo_type=2)
        self.serializer_class = WPOWidSerializer
        self.lookup_url_kwarg = "wid_id"
        self.search_fields = ("wid_name", )
        self.filter_fields = ("customer", "customer_item", )

    def get(self, request, *args, **kwargs):
        return super(ICWidAPI, self).list(request, *args, **kwargs)

    @transaction.commit_on_success
    def post(self, request, *args, **kwargs):
        request.DATA['wpo_type'] = WPO_TYPE_IC[0]
        try:
            wids = WPOWid.all_objects.filter(wid_name=self.request.DATA['wid_name'],
                                             obj_state=0)
            if wids.exists():
                if wids[0].wpo_type and wids[0].wpo_type.pk != 2:
                    return Response(
                        {'detail': 'This wid(%s) configuration is duplicated at %s.' %
                                   (wids[0].pk, WPO_TYPES_DICT[wids[0].wpo_type.pk])},
                        status=status.HTTP_409_CONFLICT)
                if wids[0].customer.pk == request.DATA['customer']:
                    return Response(
                        {'detail': 'This wid(%s) configuration is duplicated. But recoverable.' % wids[0].pk},
                        status=status.HTTP_409_CONFLICT)
                else:
                    return Response(
                        {'detail': 'This wid(%s) configuration is duplicated.' % wids[0].pk},
                        status=status.HTTP_409_CONFLICT)

            return super(ICWidAPI, self).create(request, *args, **kwargs)
        except WPOAPICustomException, we:
            return Response(we.fail_data, status=status.HTTP_400_BAD_REQUEST)
        except IntegrityError, e:
            if e.args[0] == 1062:
                error_message = e.args[1]
            elif e.message:
                error_message = e.message
            else:
                error_message = e.args[1]
            raise WPOAPIException(status.HTTP_500_INTERNAL_SERVER_ERROR, error_message)

    def post_save(self, obj, created=False):
        WPOWid.objects.filter(pk=obj.pk).update(
            optimization_rule_text=obj.generate_rule_text(),
            staging_optimization_rule_text=obj.generate_staging_rule_text())
        obj.touch_staging_domains_for_gslb(request=self.request)

        WPOHistory(wid=obj, type=1).save(request=self.request)


class ICWidDetailAPI(RetrieveModelMixin,
                     UpdateModelMixin,
                     DestroyModelMixin,
                     SpectrumGenericAPIView):
    def __init__(self):
        super(ICWidDetailAPI, self).__init__()
        self.queryset = WPOWid.all_objects.filter(wpo_type=2)
        self.serializer_class = WPOWidSerializer
        self.lookup_url_kwarg = "wid_id"

    def get(self, request, *args, **kwargs):
        return super(ICWidDetailAPI, self).retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        request.DATA['wpo_type'] = WPO_TYPE_IC[0]
        return super(ICWidDetailAPI, self).update(request, *args, **kwargs)

    def pre_save(self, obj):
        try:
            WPOWidItems.objects.filter(wid=obj.wid_id).exclude(item__in=[_obj['item'] for _obj in self.request.DATA['wid_items']]).delete()
        except (Exception, ):
            pass

        # if backup_host_domain is None, delete gslb_domain table.
        try:
            db_wid = WPOWid.objects.get(wid_id=obj.wid_id)
            if db_wid.backup_host_domain and not obj.backup_host_domain:
                db_wid.backup_host_domain.delete(request=self.request)
        except WPOWid.DoesNotExist:
            pass

    def post_save(self, obj, created=False):
        WPOWid.objects.filter(pk=obj.pk).update(
            optimization_rule_text=obj.generate_rule_text(),
            staging_optimization_rule_text=obj.generate_staging_rule_text())
        obj.touch_staging_domains_for_gslb(request=self.request)
        # PRISMUI-2060
        if WPORule.objects.filter(wid=obj, wpo_code=WPO_SHARD_DOMAIN_CODE_ID).exists():
            wpo_rules = WPORule.objects.filter(wid=obj, wpo_code=WPO_SHARD_DOMAIN_CODE_ID)
            for wpo_rule in wpo_rules:
                try:
                    wpo_rule.manage_gslb_domain_when_a_rule_is_domain_sharding(request=self.request)
                except (Exception, ):
                    pass
        if obj.status_code == 4:
            obj.save_to_snapshot(self.request)

        WPOHistory(wid=obj, type=2).save(request=self.request)

    def pre_delete(self, obj):
        try:
            # PRISMUI-2060
            if WPORule.objects.filter(wid=obj, wpo_code=WPO_SHARD_DOMAIN_CODE_ID).exists():
                wpo_rules = WPORule.objects.filter(wid=obj, wpo_code=WPO_SHARD_DOMAIN_CODE_ID)
                for wpo_rule in wpo_rules:
                    try:
                        wpo_rule.delete_related_shard_domains(request=self.request)
                    except (Exception, ):
                        pass
        except Exception as e:
            raise e

    @transaction.commit_on_success
    def patch(self, request, *args, **kwargs):
        request.DATA['wpo_type'] = WPO_TYPE_IC[0]
        try:
            kwargs['partial'] = True
            partial = kwargs.pop('partial', False)
            self.object = self.get_object_or_none()
            serializer = self.get_serializer(self.object, data=request.DATA,
                                             files=request.FILES, partial=partial)
            if not serializer.is_valid():
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            try:
                self.pre_save(serializer.object)
            except ValidationError as err:
                # full_clean on model instance may be called in pre_save,
                # so we have to handle eventual errors.
                return Response(err.message_dict, status=status.HTTP_400_BAD_REQUEST)

            self.object = serializer.save(request=request)
            self.post_save(self.object, created=False)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except WPOAPICustomException, we:
            return Response(we.fail_data, status=status.HTTP_400_BAD_REQUEST)
        except IntegrityError, e:
            if e.args[0] == 1062:
                error_message = e.args[1]
            elif e.message:
                error_message = e.message
            else:
                error_message = e.args[1]
            raise WPOAPIException(status.HTTP_500_INTERNAL_SERVER_ERROR, error_message)

    @transaction.commit_on_success
    def delete(self, request, *args, **kwargs):
        try:
            return super(ICWidDetailAPI, self).destroy(request, *args, **kwargs)
        except WPOAPICustomException, we:
            transaction.rollback()
            return Response(we.fail_data, status=status.HTTP_400_BAD_REQUEST)

    def post_delete(self, obj):
        WPOHistory(wid=obj, type=3).save(request=self.request)


class ICWidBackupAPI(SpectrumGenericAPIView):
    def __init__(self):
        super(ICWidBackupAPI, self).__init__()
        self.queryset = WPOWid.objects.filter(obj_state=1, wpo_type=2).all()
        self.lookup_url_kwarg = "wid_id"

    def patch(self, request, *args, **kwargs):
        try:
            wid = self.get_object()
            wid.save_to_snapshot(request=request)
            return Response({}, status=status.HTTP_200_OK)
        except WPOAPICustomException, we:
            return Response({'detail': we.fail_data}, status=status.HTTP_400_BAD_REQUEST)


class ICWidRollbackAPI(SpectrumGenericAPIView):
    def __init__(self):
        super(ICWidRollbackAPI, self).__init__()
        self.queryset = WPOWid.objects.filter(obj_state=1, wpo_type=2).all()
        self.lookup_url_kwarg = "wid_id"

    def patch(self, request, *args, **kwargs):
        try:
            wid = self.get_object()
            wid.rollback_from_snapshot(request=request)
            wid.touch_staging_domains_for_gslb(request=request)
            WPOHistory(wid=wid, type=5).save(request=request)
            return Response({}, status=status.HTTP_200_OK)
        except WPOAPICustomException, we:
            return Response({'detail': we.fail_data}, status=status.HTTP_400_BAD_REQUEST)


class ICWidRuleTextAPI(RetrieveModelMixin,
                       SpectrumGenericAPIView):
    def __init__(self):
        super(ICWidRuleTextAPI, self).__init__()
        self.queryset = WPOWid.objects.filter(obj_state=1, wpo_type=2).all()
        self.lookup_url_kwarg = "wid_id"
        self.serializer_class = WPOWidRuleTextSerializer

    def get(self, request, *args, **kwargs):
        return super(ICWidRuleTextAPI, self).retrieve(request, *args, **kwargs)


class ICWidStatusAPI(RetrieveModelMixin,
                     SpectrumGenericAPIView):
    def __init__(self):
        super(ICWidStatusAPI, self).__init__()
        self.queryset = WPOWid.objects.filter(obj_state=1, wpo_type=2).all()
        self.serializer_class = WPOWidStatusSerializer
        self.lookup_url_kwarg = "wid_id"
        self.object = None

    def get(self, request, *args, **kwargs):
        return super(ICWidStatusAPI, self).retrieve(request, *args, **kwargs)

    #@transaction.commit_on_success
    def patch(self, request, *args, **kwargs):
        try:
            wid_id = self.kwargs.get(self.lookup_url_kwarg)
            push_state = request.DATA['push_state']
            wids = WPOWid.objects.filter(pk=wid_id)
            wid = wids[0]

            if push_state == 'staging':
                wid.push_to_staging(request=request)
            else:
                wid.push_to_production(request=request)

            return Response({'detail': 'updated'}, status=status.HTTP_202_ACCEPTED)

        except ObjectDoesNotExist, de:
            transaction.rollback()
            return Response({'detail': de.message}, status=status.HTTP_400_BAD_REQUEST)
        except WPOAPICustomException, we:
            transaction.rollback()
            return Response(we.fail_data, status=status.HTTP_400_BAD_REQUEST)


"""""""""""""""""""""""""""""""""""""""""""""
  WPO Resource
"""""""""""""""""""""""""""""""""""""""""""""


class ICResourceAPI(SpectrumGenericAPIView):
    def __init__(self):
        super(ICResourceAPI, self).__init__()

    def get(self, request, *args, **kwargs):
        types = ['html', 'text']
        return_type = request.GET.get('type', request.POST.get('type', ''))

        resource_dict = copy.deepcopy(resources.help_text)
        try:
            if not return_type or return_type.lower() not in types:
                raise WPOAPIException(status.HTTP_400_BAD_REQUEST, 'required type')

            if return_type == types[0]:
                lf = '<br/>'
                space = '&nbsp;'
            else:
                lf = '\n'
                space = ' '
            for key in resource_dict.keys():
                resource_dict[key] = resource_dict[key].replace(':br', lf)
                resource_dict[key] = resource_dict[key].replace(' ', space)
        except Exception, e:
            raise WPOAPIException(status.HTTP_400_BAD_REQUEST, e.message)

        return Response(resource_dict, status=status.HTTP_200_OK)


"""""""""""""""""""""""""""""""""""""""""""""
  WPO Code
"""""""""""""""""""""""""""""""""""""""""""""


class ICCodeAPI(ListModelMixin,
                CreateModelMixin,
                SpectrumGenericAPIView):
    def __init__(self):
        super(ICCodeAPI, self).__init__()
        self.queryset = WPOCode.objects.all()
        self.serializer_class = WPOCodeSerializer
        self.lookup_url_kwarg = "code_id"
        self.search_fields = ("wpo_code_name", )
        self.filter_fields = ("wpo_code_name", )

    def get(self, request, *args, **kwargs):
        return super(ICCodeAPI, self).list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return super(ICCodeAPI, self).create(request, *args, **kwargs)


class ICCustomerAPI(ListModelMixin,
                    SpectrumGenericAPIView):
    def __init__(self):
        super(ICCustomerAPI, self).__init__()
        self.queryset = CustomerDisplay.objects.filter(account__customercontract__customeritem__material_no=IC_MATERIAL).distinct('customer_id')
        self.serializer_class = WPOCustomerSerializer
        self.lookup_url_kwarg = 'customer_id'

    def get(self, request, *args, **kwargs):
        return super(ICCustomerAPI, self).list(request, *args, **kwargs)


class ICContractAPI(ListModelMixin,
                    SpectrumGenericAPIView):
    def __init__(self):
        super(ICContractAPI, self).__init__()
        self.queryset = CustomerItem.objects.all()
        self.serializer_class = WPOContractSerializer
        self.lookup_url_kwarg = 'item_id'
        self.filter_fields = ({"customer_id": "contract__account__customerdisplay"},)

    def get(self, request, *args, **kwargs):
        return super(ICContractAPI, self).list(request, *args, **kwargs)

    def filter_queryset(self, queryset):
        queryset = super(ICContractAPI, self).filter_queryset(queryset)
        return queryset.filter(customeritem__material_no=IC_MATERIAL)


class ICContractItemAPI(ListModelMixin,
                        SpectrumGenericAPIView):
    def __init__(self):
        super(ICContractItemAPI, self).__init__()
        self.queryset = CustomerItem.objects.all()
        self.serializer_class = WPOContractSerializer
        self.lookup_url_kwarg = 'item_id'
        self.filter_fields = ({"customer_id": "contract__account__customerdisplay"},)

    def get(self, request, *args, **kwargs):
        return super(ICContractItemAPI, self).list(request, *args, **kwargs)

    def filter_queryset(self, queryset):
        queryset = super(ICContractItemAPI, self).filter_queryset(queryset)
        return queryset.filter(material_no=IC_MATERIAL)
