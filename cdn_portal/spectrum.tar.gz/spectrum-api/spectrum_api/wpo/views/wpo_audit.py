from __future__ import absolute_import

from spectrum_api.shared_components.generics import SpectrumGenericAPIView
from spectrum_api.shared_components.mixins import ListModelMixin
from spectrum_api.wpo.models.wpo import WPOWid, WPOHistory
from spectrum_api.wpo.serializers.wpo_audit import WPOAuditSerializer


"""""""""""""""""""""""""""""""""""""""""""""
  WPO Audit
"""""""""""""""""""""""""""""""""""""""""""""


class WPOAuditAPI(ListModelMixin,
                  SpectrumGenericAPIView):
    def __init__(self):
        super(WPOAuditAPI, self).__init__()
        self.queryset = WPOHistory.objects.filter(wid__wpo_type=1)
        self.serializer_class = WPOAuditSerializer
        self.lookup_url_kwarg = "history_id"
        self.search_fields = ()
        self.filter_fields = ('wid',)

    def get(self, request, *args, **kwargs):
        return super(WPOAuditAPI, self).list(request, *args, **kwargs)

    def filter_queryset(self, queryset):
        queryset = super(WPOAuditAPI, self).filter_queryset(queryset)
        customer = self.request.QUERY_PARAMS.get('customer', None)
        if not customer:
            return queryset
        else:
            wids = WPOWid.all_objects.filter(customer=customer)
            return queryset.filter(wid__in=wids)
