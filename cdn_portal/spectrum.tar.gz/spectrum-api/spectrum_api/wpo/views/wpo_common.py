from rest_framework import exceptions

WPO_SHARD_DOMAIN_CODE_ID = 705


class WPOAPICustomException(Exception):
    def __init__(self, fail_data):
        super(WPOAPICustomException, self).__init__()
        self.fail_data = fail_data


class WPOAPIException(exceptions.APIException):
    def __init__(self, status_code, detail):
        if isinstance(detail, Exception):
            detail_message = detail.message
            if not detail_message:
                detail_message = detail.args[len(detail.args)-1]
        else:
            detail_message = detail

        self.status_code = status_code
        super(WPOAPIException, self).__init__(detail_message)
